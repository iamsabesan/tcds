import { UploadsModule } from '@progress/kendo-angular-upload';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { TreeListModule } from '@progress/kendo-angular-treelist';
import { GridModule, PDFModule } from '@progress/kendo-angular-grid';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule, DropDownTreesModule } from '@progress/kendo-angular-dropdowns';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IconModule } from '@progress/kendo-angular-icons';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountingComponent } from './accounting.component';
import { LedgerComponent } from './components/ledger/ledger.component';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { AccountingService } from './services/accounting.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { ContraComponent } from './components/contra/contra.component';
import { ExpenseComponent } from './components/expense/expense.component';
import { InfoModule } from "../../shared/components/info/info.module";
import { IncomeComponent } from './components/income/income.component';
import { JournalReportComponent } from './components/journal-report/journal-report.component';
import { ScrollViewModule } from '@progress/kendo-angular-scrollview';
import { DayBookDateComponent } from './components/daybook-date/daybook-date.component';
import { PDFExportModule } from '@progress/kendo-angular-pdf-export';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
// import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';


const routes: Routes = [
  {
    path: '',
    component: AccountingComponent,
    children: [
      {
        path: 'ledger-list',
        component: LedgerComponent
      },
      {
        path: 'contra-list',
        component: ContraComponent
      },
      {
        path: 'expense-posting',
        component: ExpenseComponent
      },
      {
        path: 'income-posting',
        component: IncomeComponent
      },
      {
        path: 'journal-report',
        component: JournalReportComponent
      },
      {
        path: 'daybook-date',
        component: DayBookDateComponent
      }
    ]
  }
]

@NgModule({
  declarations: [
    AccountingComponent,
    LedgerComponent,
    ContraComponent,
    ExpenseComponent,
    IncomeComponent,
    JournalReportComponent,
    DayBookDateComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule,
    ToolBarModule,
    LayoutModule,
    NavigationModule,
    LabelModule,
    InputsModule,
    IconModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    ButtonsModule,
    DialogModule,
    GridModule,
    TreeListModule,
    DateInputsModule,
    DropDownTreesModule,
    UploadsModule,
    InfoModule,
    ScrollViewModule,
    PDFExportModule,
    PDFModule,
    DateRangesModule,
    // PaymentGridModule
    // PaymentDialogModule,
  ],
  providers: [AccountingService, NotificationService, DatePipe],
})
export class AccountingModule { }
