import { NotificationService } from '@progress/kendo-angular-notification';
import { AccountingService } from './../../services/accounting.service';
import { Component, OnInit } from '@angular/core';
import { FilterExpandSettings } from '@progress/kendo-angular-treeview';
import { CompositeFilterDescriptor, orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { ContraJournalList, CreateContraPosting, TransactionLedgers, TransactionToLedgers } from '../../models/contra.model';
// import { CustomNotification } from '@src/app/shared/model/shared';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
// import { DateConversion, LocalString } from '@src/app/shared/app-global';
import { IntlService } from '@progress/kendo-angular-intl';
import {  LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';

@Component({
  selector: 'contra-list',
  templateUrl: './contra.component.html',
  styleUrls: ['./contra.component.scss']
})
export class ContraComponent implements OnInit {
  filterExpandSettings: FilterExpandSettings = {
    maxAutoExpandResults: 4
  };
  expandedNodeIndices: string[] = ["0", "1", "2", "3", "4"];
  transLedgers: TransactionLedgers[] = [];
  transToLedgers: TransactionToLedgers[] = [];
  transferFrom: any;
  transferTo: any;
  createContra: CreateContraPosting = new CreateContraPosting();

  transferDate: Date = new Date();
  gridView: ContraJournalList[] = [];
  filter!: CompositeFilterDescriptor;
  sort: SortDescriptor[] = [];
  IsDialogOpen: boolean = false;
  currencySymbol: string = "";
  dateFormat: string = "";
  showLedgerBal: boolean = false;
  ledgerBalance: number = 0;

  constructor(private _accSrv: AccountingService,
    private notificationService: NotificationService,
    public intlService: IntlService
  ) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.getContraJournalList();
  }

  getContraJournalList() {
    this._accSrv.GetContraJournalList().subscribe({
      next: (res) => {
        this.gridView = res.Data;
      }
    });
  }

  public isItemDisabled(item: any): boolean {
    return item.ParentLedgerID === undefined;
  }

  btnNew() {
    this.IsDialogOpen = true;
    this._accSrv.GetTransactionLedgers().subscribe({
      next: (res) => {
        this.transLedgers = res.Data;
        this.transLedgers = this.transLedgers.filter((e) => (e.ParentLedgerID));
        this.transToLedgers = res.Data.filter((e: any) => (e.ParentLedgerID));
      }
    });

    // this._accSrv.GetDayBookDate().subscribe({
    //   next: (res) => {
    //     this.createContra.TransferDate = res.Data;
    //     this.transferDate = new Date(DateConversion.ConvertStringToDate(res.Data));
    //   }
    // });
    this.createContra.TransferDate = this.DateToYYYYMMDD(new Date());
        // this.transferDate = new Date(DateConversion.ConvertStringToDate());

  }

  isDialogClose() {
    this.IsDialogOpen = false;
    this.transferFrom = null;
    this.transferTo = null;
    this.showLedgerBal = false;
    this.createContra = new CreateContraPosting();
  }

  btnSave() {
    if (this.createContra.TransferFrom !== "" && this.createContra.TransferTo !== "") {
      this._accSrv.CreateContraPosting(this.createContra).subscribe({
        next: (res: any) => {
          new CustomNotification(this.notificationService).ShowSuccess(res.Message);
          this.getContraJournalList();
          this.isDialogClose();
        },
        error: (err: any) => {
          new CustomNotification(this.notificationService).ShowError(err.Message);
        }
      });
    }
  }

  sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadData();
  }
  loadData(): void {
    this.gridView = orderBy(this.gridView, this.sort);
    this.gridView.length = this.gridView.length;
  }

  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: "contains",
  };

  transToDisable: boolean = true;
  public transFromselection(value: TransactionLedgers): void {
    this.transToLedgers.forEach((e) => e.Disabled = false);
    this.transferTo = undefined;
    this.createContra.TransferTo = this.createContra.ToLedger = "";
    if (value) {
      this.createContra.TransferFrom = value.LedgerID;
      this.createContra.FromLedger = value.LedgerName;
      this.transToDisable = false;
      const disableIndex = this.transToLedgers.findIndex((e) => e.LedgerID === value.LedgerID);
      this.transToLedgers[disableIndex].Disabled = true;
      this._accSrv.GetLedgerBalance(this.createContra.TransferFrom).subscribe((res) => {
        this.ledgerBalance = res.Data;
        this.showLedgerBal = true;
      });
    }
    else {
      this.createContra.TransferFrom = this.createContra.FromLedger = "";
      this.transToDisable = true;
      this.showLedgerBal = false;
    }
  }

  public itemDisabled(itemArgs: { dataItem: any; index: number }) {
    return itemArgs.dataItem.Disabled;
  }


  public transToselection(value: TransactionLedgers): void {
    if (value) {
      this.createContra.TransferTo = value.LedgerID;
      this.createContra.ToLedger = value.LedgerName;
    }
    else {
      this.createContra.TransferTo = this.createContra.ToLedger = "";
    }
  }
  DateToYYYYMMDD(Date: Date) {
    let DS = ('0' + (Date.getDate() + 1)).slice(-2) + '-' + ('0' + Date.getMonth()).slice(-2) + '-' + Date.getFullYear()
    return DS
  }
}
