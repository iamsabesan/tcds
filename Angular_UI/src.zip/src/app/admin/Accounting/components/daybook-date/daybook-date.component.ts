import { Component, OnInit } from '@angular/core';
import { Branch, BranchDetails, DayBookDetails, ReceiptDetails } from '../../models/daybook.model';
import { IntlService } from '@progress/kendo-angular-intl';
// import { CustomNotification } from '@src/app/shared/model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { AccountingService } from '../../services/accounting.service';
import { LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
// import { LocalString } from '@src/app/shared/app-global';

@Component({
  selector: 'daybook-date',
  templateUrl: './daybook-date.component.html',
  styleUrls: ['./daybook-date.component.scss']
})
export class DayBookDateComponent implements OnInit {

  dayBookDetails: DayBookDetails = new DayBookDetails();
  receiptDetails: ReceiptDetails = new ReceiptDetails();
  branch: Branch = new Branch();
  gridView: BranchDetails[] = [];
  IsDialogOpen: boolean = false;
  currencySymbol: string = '';

  constructor(public intl: IntlService, private notificationService: NotificationService, private _accSrv: AccountingService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getDayBookDetails();
  }


  getDayBookDetails() {
    this._accSrv.getReceiptDateDetails().subscribe({
      next: (res: any) => {
        this.receiptDetails = res.Data;
        this._accSrv.getBranchWiseCashDetails(this.receiptDetails.ReceiptDate).subscribe({
          next: (result: any) => {
            this.dayBookDetails = result.Data;
            this.gridView = this.dayBookDetails.BranchWiseCash;
          }
        });
      }
    });
  }

  closeDaybook() {
    this.IsDialogOpen = true;
  }

  isDialogClose() {
    this.IsDialogOpen = false;
  }

  Close(data: string) {
    this.IsDialogOpen = false;
    if (data === 'Yes') {
      this._accSrv.dayBookClose(this.branch).subscribe({
        next: (res: any) => {
          new CustomNotification(this.notificationService).ShowSuccess(res.Message);
          this.getDayBookDetails();
        },
        error: (err: any) => {
          new CustomNotification(this.notificationService).ShowError(err.Message);
        }
      });
    }
  }
}
