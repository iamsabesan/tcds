import { Component, OnInit, ViewChild } from '@angular/core';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { PaidToLedgers, TransactionLedgers } from '../../models/contra.model';
import { Attachments, ExpenseDate, ExpensePosting, ExpensePostingList, IExpenseUpdate, PayModeList, TransactionCurrency, expensePayments } from '../../models/expense.model';
import { AccountingService } from '../../services/accounting.service';
import { FileRestrictions, SelectEvent, FileInfo, } from '@progress/kendo-angular-upload';
import { NotificationService } from '@progress/kendo-angular-notification';
import { NgForm } from '@angular/forms';
import { AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, SortDescriptor, aggregateBy, orderBy, } from '@progress/kendo-data-query';
import { IntlService } from '@progress/kendo-angular-intl';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { onlyNumbers } from 'src/app/shared/components/regex';
import { DateConversion, DateSize, FileIcons, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IWebError } from 'src/core/model';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { PaymentInfo } from 'src/app/shared/model/payment';
import { CommonService } from 'src/app/shared/service/common.service';
import { PaymentService } from 'src/app/shared/service/payment.service';

@Component({
  selector: 'expense-posting',
  templateUrl: './expense.component.html',
  styleUrls: ['./expense.component.scss'],
})

export class ExpenseComponent implements OnInit {
  /* View Child */
  @ViewChild('ExpenseEntryForm') ExpenseEntryForm!: NgForm;

  /* List */
  public paidFromLedgers: TransactionLedgers[] = [];
  public paidToLedgers: PaidToLedgers[] = [];
  public gridView: ExpensePostingList[] = [];
  public sort: SortDescriptor[] = [];
  public aggregates: AggregateDescriptor[] = [];
  public PayModeList: PayModeList[] = [];
  public transactionCurrency: TransactionCurrency[] = [];
  public gridRowSelect: number[] = [];

  /* Model */
  public selectedDetails = new ExpensePostingList();
  public paymentDetails: expensePayments = new expensePayments();
  public expensePosting: ExpensePosting = new ExpensePosting();
  public Date: ExpenseDate = new ExpenseDate();
  public MlPaymentInfo = new PaymentInfo();
  public MlExpenseUpdate = new IExpenseUpdate();
  public paymentDate: Date = new Date();
  public TransactionDate = new Date();

  /* Dialog */
  public IsDialogOpen: boolean = false;
  public disableEnterAmount: boolean = false;
  public disableConRate: boolean = false;
  public paidFrom: any;
  public paidTo: any;

  /* Number Pattern */
  public onlyNumbers = onlyNumbers;

  /* Grid */
  public filter!: CompositeFilterDescriptor;
  public total!: AggregateResult;
  public selectableSettings!: SelectableSettings;

  public CashTotal: string = '';
  public BankTotal: string = '';
  public showFooter: boolean = false;
  public currencySymbol: string = "";
  public payModeType: any;
  public DisableTransDetails: boolean = true;
  public transactionDate!: any;
  public showDet: boolean = false;
  public TransactionCurrency: any;
  public currencyName: string = '';
  public dateFormat: string = '';
  public showPayment: boolean = false;
  public setPaymentInfo: any;
  public showLedgerBal: boolean = false;
  public ledgerBalance: number = 0;

  public setMinLen: number = 6;
  public setMaxLen: number = 6;

  /* Date Style */
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: false,
      mode: 'single',
      drag: false,
    };
  }

  public transCurrencyColumns = [
    {
      Field: 'CurrencySymbol',
      Title: 'Symbol',
      Width: 80
    },
    {
      Field: 'CurrencyCode',
      Title: 'Code',
      Width: 100
    },
    {
      Field: 'Currency',
      Title: 'Currency',
      Width: 150
    }
  ]

  constructor(
    private _srvAccounting: AccountingService,
    private _srvNotification: NotificationService,
    public intlService: IntlService, public _srvCom: CommonService, private _srvPayment: PaymentService
  ) {
    this.setSelectableSettings();
  }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.getExpensePostingList();
  }

  /* Date Change */
  dateChange(event: any) {
    this.MlDateRange = event
    if (event.duration == undefined) {
      this.gridView = [];
      this.showDet = false;
    }
  }

  getExpensePostingList() {
    this.gridRowSelect[0] = 0;
    const fromdate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
    const todate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);

    if (this.MlDateRange.duration == undefined)
      new CustomNotification(this._srvNotification).ShowError("Please select the date range");

    else if ((this.MlDateRange.startDate == null) || (this.MlDateRange.endDate == null))
      new CustomNotification(this._srvNotification).ShowError("Please fill the dates");

    else {
      this._srvAccounting.expensePostingList(fromdate, todate).subscribe({
        next: (res: any) => {
          this.gridView = res.Data;

          if (this.gridView.length > 0) {
            this.aggregates = [{ field: 'Bank', aggregate: 'sum' }, { field: 'Cash', aggregate: 'sum' }];
            this.total = aggregateBy(this.gridView, this.aggregates);
            this.CashTotal = this.intlService.formatNumber(Number(this.total['Cash'].sum), 'c0');
            this.BankTotal = this.intlService.formatNumber(Number(this.total['Bank'].sum), 'c0');
            this.showFooter = true;
            this.showPaymentDetails(this.gridView[0]);
          }
          else {
            this.showDet = false;
            this.selectedDetails = new ExpensePostingList();
            this.showFooter = false;
          }
        },
        error: (err: IWebError) => {
          this.gridView = [];
          this.showDet = false;
          this.selectedDetails = new ExpensePostingList();
          this.showFooter = false;
          new CustomNotification(this._srvNotification).ShowError(err.Message);
        }
      });
    }
  }

  addNewExpense() {
    this.IsDialogOpen = true;
    // * Get Daybook Date
    this._srvAccounting.GetDayBookDate().subscribe({
      next: (res: any) => {
        this.expensePosting.PostingDate = res.Data;
        this.paymentDate = new Date(DateConversion.ConvertStringToDate(res.Data));
      },
    });
    // * Get Available Payment Mode
    // this._srvAccounting.getAvailablePaymode('payments').subscribe({
    this._srvPayment.getPaymentType().subscribe({
      next: (response: any) => {
        this.PayModeList = response.Data;
      },
    });
    // * Get Paid To ledger list
    this._srvAccounting.paidToLedgers().subscribe({
      next: (res: any) => {
        this.paidToLedgers = res.Data.filter(
          (e: any) => e.ParentLedgerID !== null && e.IsLedgerGroup === false
        );
      },
    });

    this._srvAccounting.getCurrency().subscribe((res: any) => {
      this.transactionCurrency = res.Data;
      this.transactionCurrency.forEach((e) => {
        if (e.BaseCurrencyCode === e.CurrencyCode) {
          this.expensePosting.ConversionRate = e.BaseCurrencyRate;
          this.expensePosting.TransactionCurrency = e.Currency;
          this.TransactionCurrency = e;
        }
      });
      if (this.TransactionCurrency.CurrencySymbol == LocalString.CurrencySymbol && this.TransactionCurrency.CurrencyCode == LocalString.CurrencyCode && this.TransactionCurrency.Currency == LocalString.Currency)
        this.disableConRate = true
      else
        this.disableConRate = false;
    });
  }

  btnSave() {
    this.expensePosting.PostingDate = DateConversion.ConvertToYearMonthDate(this.paymentDate);
    // this.expensePosting.TransactionDate = this.datepipe.transform(this.TransactionDate, LocalString.DateFormat) ?? "";
    this._srvAccounting.createExpensePosting(this.expensePosting).subscribe({
      next: (res: any) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
        this.isDialogClose();
        this.getExpensePostingList();
      },
      error: (err: any) => {
        new CustomNotification(this._srvNotification).ShowError(err.Message);
      },
    });
  }

  isDialogClose() {
    this.IsDialogOpen = false;
    this.showLedgerBal = false;
    this.ExpenseEntryForm.resetForm();
    this.expensePosting = new ExpensePosting();
  }

  paidFromSelection(event: TransactionLedgers) {
    this.expensePosting.PaidThrough = event ? event.LedgerID : '';
    this.expensePosting.FromLedger = event ? event.LedgerName : '';
    if (event) {
      this._srvAccounting.GetLedgerBalance(this.expensePosting.PaidThrough).subscribe((res) => {
        this.showLedgerBal = true;
        this.ledgerBalance = res.Data;
      });
    }
    else {
      this.showLedgerBal = false;
    }

  }

  paidToSelection(event: TransactionLedgers) {
    this.expensePosting.PaidTo = event ? event.LedgerID : '';
    this.expensePosting.ToLedger = event ? event.LedgerName : '';
  }

  transNumLabel: string = 'Transaction #';
  transDateLabel: string = 'Transaction Date';
  payModeSelection(event: PayModeList) {
    if (event.Paymode !== 'CHEQUE') {
      this.setMaxLen = 16;
      this.setMinLen = 6;
    }
    else {
      this.setMaxLen = 6;
      this.setMinLen = 6;
    }
    this.paidFrom = undefined;
    this.expensePosting.PaidThrough = "";
    if (event) {
      switch (event.Paymode) {
        case 'CHEQUE':
          this.transNumLabel = 'Cheque #';
          this.transDateLabel = 'Cheque Date';
          break;
        case 'DEMAND DRAFT':
          this.transNumLabel = 'DD #';
          this.transDateLabel = 'DD Date';
          break;
        default:
          this.transNumLabel = 'Transaction #';
          this.transDateLabel = 'Transaction Date';
      }
      this.expensePosting.PayModeID = event.PaymodeID;
      this.expensePosting.PayMode = event.Paymode;
      this._srvAccounting.GetTransactionLedgers().subscribe({
        next: (res: any) => {
          if (this.expensePosting.PayMode === 'CASH') {
            this.paidFrom = undefined;
            this.expensePosting.TransactionNumber = '';
            this.transactionDate = undefined;
            const ledgerID = res.Data.find((e: TransactionLedgers) => e.LedgerName === this.expensePosting.PayMode)?.LedgerID;
            this.paidFromLedgers = res.Data.filter((e: TransactionLedgers) => e.ParentLedgerID === ledgerID && e.LedgerName !== 'UNDEPOSITED CASH');
            this.DisableTransDetails = true;
          }
          else {
            const ledgerID = res.Data.find((e: TransactionLedgers) => e.LedgerName === 'BANK')?.LedgerID;
            this.paidFromLedgers = res.Data.filter((e: TransactionLedgers) => e.ParentLedgerID === ledgerID);
            this.DisableTransDetails = false;
          }
        },
      });
    } else {
      this.expensePosting.PayModeID = '';
      this.expensePosting.PayMode = '';
      this.paidFromLedgers = [];
      this.DisableTransDetails = true;
      this.transNumLabel = 'Transaction #';
      this.transDateLabel = 'Transaction Date';
      this.showLedgerBal = false;
    }
  }

  transDateSelction(event: any) {
    console.log(event);
  }

  transCurrencySelection(event: TransactionCurrency) {
    if (event) {
      this.expensePosting.TransactionCurrency = event.CurrencyCode;
      this.currencyName = 'in ' + event.Currency;
      this.disableEnterAmount = this.expensePosting.TransactionCurrency ? false : true;
      this.expensePosting.ConversionRate = event.BaseCurrencyRate;
    } else {
      this.disableEnterAmount = true;
      this.expensePosting.ConversionRate = this.expensePosting.Amount = this.expensePosting.TransactionAmount = 0;
    }
  }

  transAmntChange(event: any) {
    this.expensePosting.TransactionAmount = event * this.expensePosting.ConversionRate;
  }

  conRateChange(event: any) {
    this.expensePosting.TransactionAmount = event * this.expensePosting.Amount;
  }

  gridRowSelection(event: any) {
    this.showPaymentDetails(event.selectedRows[0].dataItem);
  }

  //PostingDate: string = '';
  showPaymentDetails(data: ExpensePostingList) {
    this.showDet = data ? true : false;
    this.selectedDetails = data;
    this.paymentDetails = JSON.parse(data.Payments);
    this.paymentDetails.TransactionDate = (this.paymentDetails.TransactionDate) ? DateConversion.ConvertToYearMonthDate(this.paymentDetails.TransactionDate) : "";
    //this.PostingDate = formatDate(this.selectedDetails.TransferDateI18, LocalString.DateFormat, LocalString.LanguageCulture);
    //this.PostingDate = DateConversion.ConvertToDateMonthYear(this.selectedDetails.TransferDateI18);
    this.selectedDetails.Attachements.forEach((e: Attachments) => {
      const fileType = e.FileName.split('.').pop();
      e.Icon = FileIcons.getIcons(fileType);
    });
  }

  imageClick(event: Attachments) {
    this._srvAccounting.downloadAttachment(event);
  }

  filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
  };

  myRestrictions: FileRestrictions = {
    maxFileSize: 5000000,
    allowedExtensions: ['png', 'jpeg', 'jpg', 'svg', 'pdf', 'docx', 'xls', 'xlsx', 'csv', 'pptx', 'txt', 'zip']
  };

  select(e: SelectEvent): void {
    if (e.files.length > 10 || this.expensePosting.Attachments.length > 9) {
      alert('Please select max 10 files.');
      e.preventDefault();
    } else {
      e.files.forEach((file: FileInfo | any) => {
        const fileType = file.rawFile?.type.split('/', 1)[0];
        if (!file.validationErrors && fileType === 'image') {
          const reader = new FileReader();
          reader.readAsDataURL(file.rawFile);
        }
      });
    }
  }

  sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadData();
  }
  loadData(): void {
    this.gridView = orderBy(this.gridView, this.sort);
    this.gridView.length = this.gridView.length;
  }


  editExpense(data: any) {
    this._srvAccounting.VoucherID = data.VoucherID;

    this.showPayment = true;
    this.setPaymentInfo = JSON.parse(data.Payments);
    this.setPaymentInfo.LedgerID = data.TransferFromID;
    this.MlExpenseUpdate.VoucherID = data.VoucherID;
  }

  getResponse(data: any) {
    this.showPayment = data;
  }

  getPaymentInfo(data: any) {
    this.MlExpenseUpdate.Amount = this.MlExpenseUpdate.PayModeValue = data.Amount;
    this.MlExpenseUpdate.LedgerName = data.LedgerName;
    this.MlExpenseUpdate.LedgerID = data.LedgerID;
    this.MlExpenseUpdate.PaymentModeID = data.PaymentModeID;
    this.MlExpenseUpdate.PayModeType = data.PayModeType;
    this.MlExpenseUpdate.TransactionDate = data.TransactionDate;
    this.MlExpenseUpdate.TransactionNo = data.TransactionNo;



    this._srvAccounting.updatExpense(this.MlExpenseUpdate).subscribe({
      next: (res: any) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
        this.getExpensePostingList();
        this.showPayment = false;
      },
      error: (err: IWebError) => {
        new CustomNotification(this._srvNotification).ShowErrorMsg(err.Message)
      }
    })

  }
}
