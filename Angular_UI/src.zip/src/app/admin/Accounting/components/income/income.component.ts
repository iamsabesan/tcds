import { Component, OnInit, ViewChild } from '@angular/core';
import { AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, SortDescriptor, aggregateBy, orderBy } from '@progress/kendo-data-query';
// import { LocalString } from '@src/app/shared/app-global';
import { IncomeDate, IncomePosting, IncomePostingList } from '../../models/income.model';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { AccountingService } from '../../services/accounting.service';
import { IntlService } from '@progress/kendo-angular-intl';
import { NgForm } from '@angular/forms';
// import { CustomNotification } from '@src/app/shared/model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { PayModeList, TransactionCurrency } from '../../models/expense.model';
// import { onlyNumbers } from '@src/app/shared/components/regex';
import { PaidToLedgers, TransactionLedgers } from '../../models/contra.model';
import { formatDate } from '@angular/common';
import { onlyNumbers } from 'src/app/shared/components/regex';
import { LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';

@Component({
  selector: 'income-posting',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.scss']
})
export class IncomeComponent implements OnInit {
  @ViewChild('IncomeEntryForm') IncomeEntryForm!: NgForm;
  IsDialogOpen: boolean = false;
  disableEnterAmount: boolean = true;
  DepositToLedgers: TransactionLedgers[] = [];
  paidByLedgers: PaidToLedgers[] = [];
  DepositTo: any;
  paidTo: any;
  paymentDate: Date = new Date();

  Date: IncomeDate = new IncomeDate();
  incomePosting: IncomePosting = new IncomePosting();
  gridView: IncomePostingList[] = [];
  filter!: CompositeFilterDescriptor;
  sort: SortDescriptor[] = [];
  aggregates: AggregateDescriptor[] = [];
  total!: AggregateResult;
  CashTotal: string = '';
  BankTotal: string = '';
  showFooter: boolean = false;

  currencySymbol: string = "";
  PayModeList: PayModeList[] = [];
  payModeType: any;
  DisableTransDetails: boolean = true;
  transactionDate!: any;
  transactionCurrency: TransactionCurrency[] = [];
  transCurrencyColumns = [
    {
      Field: 'CurrencySymbol',
      Title: 'Symbol',
      Width: 80
    },
    {
      Field: 'CurrencyCode',
      Title: 'Phone',
      Width: 100
    },
    {
      Field: 'Currency',
      Title: 'Branch',
      Width: 150
    }
  ]
  TransactionCurrency: any;
  currencyName: string = '';
  onlyNumbers = onlyNumbers;

  selectableSettings!: SelectableSettings;
  setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: false,
      mode: 'single',
      drag: false,
    };
  }

  constructor(private _accSrv: AccountingService, public intlService: IntlService, private notificationService: NotificationService) {
    this.setSelectableSettings();
  }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getIncomePostingList(this.Date);
  }

  public gridRowSelect: number[] = [];
  getIncomePostingList(data: IncomeDate) {
    this.gridRowSelect[0] = 0;
    const fromdate = formatDate(data.FromDate, LocalString.DateFormat, LocalString.LanguageCulture);
    const todate = formatDate(data.ToDate, LocalString.DateFormat, LocalString.LanguageCulture);
    this._accSrv.incomePostingList(fromdate, todate).subscribe({
      next: (res) => {
        this.gridView = res.Data;
        if (this.gridView.length > 0) {
          this.showDet = true;
          this.selectedDetails = this.gridView[0];
          this.aggregates = [{ field: 'Bank', aggregate: 'sum' }, { field: 'Cash', aggregate: 'sum' }];
          this.total = aggregateBy(this.gridView, this.aggregates);
          this.CashTotal = this.intlService.formatNumber(Number(this.total['Cash'].sum), 'c0');
          this.BankTotal = this.intlService.formatNumber(Number(this.total['Bank'].sum), 'c0');
          this.showFooter = true;
        }
        else {
          this.showDet = false;
          this.selectedDetails = new IncomePostingList();
          this.showFooter = false;
        }
      },
      error: () => {
        this.gridView = [];
        this.showDet = false;
        this.selectedDetails = new IncomePostingList();
        this.showFooter = false;
      }
    });
  }

  selectedDetails = new IncomePostingList();
  showDet: boolean = false;
  gridRowSelection(event: any) {
    this.showDet = event ? true : false;
    this.selectedDetails = event.selectedRows[0].dataItem;
  }

  addNewIncome() {
    this.IsDialogOpen = true;
    // Get Daybook Date
    this._accSrv.GetDayBookDate().subscribe({
      next: (res) => {
        this.incomePosting.PostingDate = res.Data;
        // this.paymentDate = new Date(
        //   DateConversion.ConvertToYearDateMonth(res.Data)
        // );
      },
    });
    // Get Available Payment Mode
    this._accSrv.getAvailablePaymode('payments').subscribe({
      next: (response: any) => {
        this.PayModeList = response.Data;
      },
    });
    // Get Paid By ledger list
    this._accSrv.paidByLedgers().subscribe({
      next: (res) => {
        this.paidByLedgers = res.Data.filter(
          (e: any) => e.ParentLedgerID !== null && e.IsLedgerGroup === false
        );
      },
    });

    this._accSrv.getCurrency().subscribe((res) => {
      this.transactionCurrency = res.Data;
    });
  }

  btnSave() {
    this._accSrv.createIncomePosting(this.incomePosting).subscribe({
      next: (res) => {
        new CustomNotification(this.notificationService).ShowSuccess(
          res.Message
        );
        this.isDialogClose();
        this.getIncomePostingList(this.Date);
      },
      error: (err) => {
        new CustomNotification(this.notificationService).ShowError(err.Message);
      },
    });
  }

  isDialogClose() {
    this.IsDialogOpen = false;
    this.IncomeEntryForm.resetForm();
    this.incomePosting = new IncomePosting();
  }

  depositToSelection(event: TransactionLedgers) {
    this.incomePosting.PaidTo = event ? event.LedgerID : '';
  }

  paidBySelection(event: TransactionLedgers) {
    this.incomePosting.PaidThrough = event ? event.LedgerID : '';
  }

  transNumLabel: string = 'Transaction #';
  transDateLabel: string = 'Transaction Date';
  payModeSelection(event: PayModeList) {
    if (event) {
      switch (event.PaymentModeName) {
        case 'CHEQUE':
          this.transNumLabel = 'Cheque #';
          this.transDateLabel = 'Cheque Date';
          break;
        case 'DEMAND DRAFT':
          this.transNumLabel = 'DD #';
          this.transDateLabel = 'DD Date';
          break;
        default:
          this.transNumLabel = 'Transaction #';
          this.transDateLabel = 'Transaction Date';
      }
      this.incomePosting.PayModeID = event.PaymentModeID;
      this.incomePosting.PayMode = event.PaymentModeName;
      this._accSrv.GetTransactionLedgers().subscribe({
        next: (res) => {
          if (this.incomePosting.PayMode === 'CASH') {
            this.DepositTo = undefined;
            this.incomePosting.TransactionNumber = '';
            this.transactionDate = undefined;
            const ledgerID = res.Data.find((e: TransactionLedgers) => e.LedgerName === this.incomePosting.PayMode)?.LedgerID;
            this.DepositToLedgers = res.Data.filter((e: TransactionLedgers) => e.ParentLedgerID === ledgerID);
            this.DisableTransDetails = true;
          } else {
            const ledgerID = res.Data.find((e: TransactionLedgers) => e.LedgerName === 'BANK')?.LedgerID;
            this.DepositToLedgers = res.Data.filter((e: TransactionLedgers) => e.ParentLedgerID === ledgerID);
            this.DisableTransDetails = false;
          }
        },
      });
    } else {
      this.incomePosting.PayModeID = '';
      this.incomePosting.PayMode = '';
      this.DepositToLedgers = [];
      this.DisableTransDetails = true;
      this.transNumLabel = 'Transaction #';
      this.transDateLabel = 'Transaction Date';
    }
  }

  transDateSelction(event: any) {
    this.incomePosting.TransactionDate = formatDate(event, LocalString.DateFormat, LocalString.LanguageCulture);
  }

  transCurrencySelection(event: TransactionCurrency) {
    if (event) {
      this.incomePosting.TransactionCurrency = event.CurrencyCode;
      this.currencyName = 'in ' + event.Currency;
      this.disableEnterAmount = this.incomePosting.TransactionCurrency ? false : true;
      this.incomePosting.ConversionRate = event.BaseCurrencyRate;
    } else {
      this.disableEnterAmount = true;
      this.incomePosting.ConversionRate = 0;
      this.incomePosting.Amount = 0;
      this.incomePosting.TransactionAmount = 0;
    }
  }

  transAmntChange(event: any) {
    this.incomePosting.TransactionAmount =
      event * this.incomePosting.ConversionRate;
  }

  conRateChange(event: any) {
    this.incomePosting.TransactionAmount = event * this.incomePosting.Amount;
  }

  filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
  };

  sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadData();
  }
  loadData(): void {
    this.gridView = orderBy(this.gridView, this.sort);
    this.gridView.length = this.gridView.length;
  }
}
