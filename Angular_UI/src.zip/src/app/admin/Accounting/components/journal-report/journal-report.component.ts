import { Component, OnInit } from '@angular/core';
import { ContraPaymentDetails, JournalDetailsList, ReceiptPaymentDetails, SalesPaymentDetails } from '../../models/journal-report.model';
import { IntlService } from '@progress/kendo-angular-intl';
import { CompositeFilterDescriptor, SortDescriptor, } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { AccountingService } from '../../services/accounting.service';
import { DateConversion, DateSize, LocalString } from 'src/app/shared/app-global';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';

@Component({
  selector: 'journal-report',
  templateUrl: './journal-report.component.html',
  styleUrls: ['./journal-report.component.scss'],
})

export class JournalReportComponent implements OnInit {

  /* List */
  public gridData: any[] = [];
  public gridRowSelect: number[] = [0];

  /* Model */
  public selectedDetails: JournalDetailsList = new JournalDetailsList();
  public salesPaymentDetails: SalesPaymentDetails = new SalesPaymentDetails();
  public receiptPaymentDetails: ReceiptPaymentDetails = new ReceiptPaymentDetails();
  public contraPaymentDetails: ContraPaymentDetails = new ContraPaymentDetails();

  /* Grid Option */
  public filter!: CompositeFilterDescriptor;
  public selectableSettings!: SelectableSettings;
  public sort: SortDescriptor[] = [];

  public DebitTotal: number = 0;
  public CreditTotal: number = 0;
  public showFooter: boolean = false;
  public currencySymbol: string = '';
  public showDet: boolean = false;

  public showEditJournel: boolean = false;
  public dateFormat: string = '';
  public showPlotDetails: boolean = false;
  public showPaymentDetails: boolean = false;
  public showContraDetails: boolean = false;

  /* Date Style */
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: false,
      mode: 'single',
      drag: false,
    };
  }

  /* Form Group */
  FrmEdit = new FormGroup({
    JournalDate: new FormControl('', [Validators.required]),
    Narration: new FormControl('')
  })

  constructor(public intl: IntlService, private _srvAccunting: AccountingService, private _srvNotification: NotificationService) {
    this.setSelectableSettings();
  }


  ngOnInit(): void {
    this.dateFormat = LocalString.DateFormat;
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getJournalList();
  }

  /* Date Change */
  dateChange(event: any) {
    this.MlDateRange = event
    if (event.duration == undefined) {
      this.gridData = [];
      this.showDet = false;
    }
  }

  /* Get Journal List */
  getJournalList() {
    const fromdate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
    const todate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);

    if (this.MlDateRange.duration == undefined) this.errorMsg("Please select the date range");

    else if ((this.MlDateRange.startDate == null) || (this.MlDateRange.endDate == null)) this.errorMsg("Please fill the dates");

    else {
      this._srvAccunting.getJournalReportList(fromdate, todate).subscribe({
        next: (res: any) => {
          this.DebitTotal = this.CreditTotal = 0;
          this.gridData = res.Data;

          if (this.gridData.length > 0) {
            this.showJournalDetails(this.gridData[0]);
            this.gridData.forEach((e) => {
              e.Ledgers.DebitLedgers.forEach((f: any) => {
                this.DebitTotal += f.DebitAmount;
              });
              e.Ledgers.CreditLedgers.forEach((j: any) => {
                this.CreditTotal += j.CreditAmount;
              });
              e.JournalDate = DateConversion.ConvertStringToDate(e.JournalDateI18);
            });
            this.showFooter = true;
          }
          else {
            this.DebitTotal = this.CreditTotal = 0;
            this.showDet = this.showFooter = false;
            this.selectedDetails = new JournalDetailsList();

          }
        },
        error: (err) => {
          this.errorMsg(err.Message)
          this.DebitTotal = this.CreditTotal = 0;
          this.gridData = [];
          this.showDet = this.showFooter = false;
          this.selectedDetails = new JournalDetailsList();
        },
      });
    }
  }

  gridRowSelection(event: any) {
    this.showJournalDetails(event.selectedRows[0].dataItem);
  }

  showJournalDetails(data: JournalDetailsList) {
    this.showDet = data ? true : false;
    this.selectedDetails = data;

    switch (this.selectedDetails.JournalType) {
      case 'SALES':
      case 'SALES RETURN': {
        this.showPlotDetails = true;
        this.showContraDetails = this.showPaymentDetails = false;
        if (this.selectedDetails.Ledgers.CreditLedgers[0].PaymentDetail !== '') {
          this.salesPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.CreditLedgers[0].PaymentDetail) as SalesPaymentDetails;
        }
        else if (this.selectedDetails.Ledgers.DebitLedgers.length !== 0) {
          if (this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail !== '') this.salesPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail) as SalesPaymentDetails;
        }
        else {
          this.salesPaymentDetails = new SalesPaymentDetails();
        }
        break;
      }
      case 'RECEIPT':
      case 'PAYMENT': {
        this.showPaymentDetails = true;
        this.showContraDetails = this.showPlotDetails = false;
        if (this.selectedDetails.Ledgers.CreditLedgers.length !== 0) {
          this.receiptPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.CreditLedgers[0].PaymentDetail) as ReceiptPaymentDetails;
          this.receiptPaymentDetails.TransactionDate = (this.receiptPaymentDetails.TransactionDate) ? DateConversion.ConvertToDateMonthYear(this.receiptPaymentDetails.TransactionDate) : "";
        }
        else if (this.selectedDetails.Ledgers.DebitLedgers.length !== 0) {
          if (this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail !== '') {
            this.receiptPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail) as ReceiptPaymentDetails;
            this.receiptPaymentDetails.TransactionDate = (this.receiptPaymentDetails.TransactionDate) ? DateConversion.ConvertToDateMonthYear(this.receiptPaymentDetails.TransactionDate) : "";
          }
        }
        else this.receiptPaymentDetails = new ReceiptPaymentDetails();
        
        break;
      }
      case 'CONTRA': {
        this.showContraDetails = true;
        this.showPaymentDetails = this.showPlotDetails = false;
        if (this.selectedDetails.Ledgers.CreditLedgers[0].PaymentDetail !== '')
          this.contraPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.CreditLedgers[0].PaymentDetail) as ContraPaymentDetails;

        else if (this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail !== '')
          this.contraPaymentDetails = JSON.parse(this.selectedDetails.Ledgers.DebitLedgers[0].PaymentDetail) as ContraPaymentDetails;

        else {
          this.contraPaymentDetails.FromLedger = this.selectedDetails.Ledgers.CreditLedgers[0].CreditLedgerName;
          this.contraPaymentDetails.ToLedger = this.selectedDetails.Ledgers.DebitLedgers[0].DebitLedgerName;
        }
        break;
      }
      default: {
        this.showPlotDetails = this.showPaymentDetails = this.showContraDetails = false;
      }
    }
  }

  editJournel(data: any) {
    this.showEditJournel = true;
    this.FrmEdit.controls['JournalDate'].setValue(data.JournalDate);
    this.FrmEdit.controls['Narration'].setValue(data.Narration);
  }

  btnEditCancel() {
    this.showEditJournel = false;
  }

  btnEditUpdate(FrmEdit: FormGroup) {
    FrmEdit.status === 'VALID' ? console.log(FrmEdit.value) : FrmEdit.markAllAsTouched();
  }

  /* Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }

}
