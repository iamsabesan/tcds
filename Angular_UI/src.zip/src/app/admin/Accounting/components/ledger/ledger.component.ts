import { NotificationService } from '@progress/kendo-angular-notification';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FilterExpandSettings } from '@progress/kendo-angular-treeview';
import { Category, CreateLedger, LedgerList } from '../../models/ledger.model';
import { AccountingService } from '../../services/accounting.service';
import { NgForm } from '@angular/forms';
import { SelectableSettings, SelectionChangeEvent } from '@progress/kendo-angular-treelist';
import { CustomNotification } from 'src/app/shared/model/shared';
import { DropDownFilter } from 'src/app/shared/app-global';

@Component({
  selector: 'ledger-list',
  templateUrl: './ledger.component.html',
  styleUrls: ['./ledger.component.scss']
})
export class LedgerComponent implements OnInit {
  @ViewChild('LedgerForm') LedgerForm!: NgForm;
  filterExpandSettings: FilterExpandSettings = {
    maxAutoExpandResults: 4
  };

  IsDialogOpen: boolean = false;
  ledgerList: LedgerList[] = [];
  categoryList: Category[] = [];
  parentLedgerList: LedgerList[] = [];
  createLedger: CreateLedger = new CreateLedger();

  parentLedger: LedgerList = new LedgerList();
  IncreasedByList = ["CREDIT", "DEBIT"];

  constructor(private accSrv: AccountingService, private notificationService: NotificationService) {
  }

  ngOnInit(): void {
    this.getLedgerList();
  }

  public settings: SelectableSettings = {
    mode: "row",
    multiple: true,
  };

  public expandedNodeIndices: string[] = ["0", "1", "2", "3", "4"];

  getLedgerList() {
    this.accSrv.GetLedgerList().subscribe({
      next: (res: any) => {
        this.ledgerList = res.Data;
        this.ledgerList.forEach((e: LedgerList) => {
          e.ParentLedgerID = this.ledgerList.find((f: LedgerList) => f.LedgerID === e.ParentLedgerID)?.SlNo;
        });
        this.parentLedgerList = this.ledgerList.filter((f: LedgerList) => (f.IsLedgerGroup == true && f.AllowCustomSubLedger == true));
      }
    });
  }

  selectParentLedger(event: LedgerList) {
    if (event) {
      this.createLedger.ParentLedgerID = this.parentLedger.LedgerID;
      this.createLedger.CategoryID = this.parentLedger.CategoryID;
    }
    else {
      this.parentLedger = new LedgerList();
      this.createLedger.ParentLedgerID = this.createLedger.CategoryID = "";
    }
  }

  isDialogClose() {
    this.IsDialogOpen = false;
    this.LedgerForm.resetForm();
  }

  NewLedger() {
    this.IsDialogOpen = true;
    this.showError = this.createLedger.IsLedgerGroup = false;
    this.createLedger.OpeningBalance = 0;
    this.accSrv.GetDayBookDate().subscribe({
      next: (res) => this.createLedger.JournalDate = res.Data,
      error: (err) => new CustomNotification(this.notificationService).ShowError(err.Message)
    });
  }

  createNewLedger() {
    if (this.createLedger.ParentLedgerID === "") this.showError = true;
    else {
      this.showError = false;
      this.accSrv.CreateLedger(this.createLedger).subscribe({
        next: (res) => {
          new CustomNotification(this.notificationService).ShowSuccess(res.Message);
          this.LedgerForm.resetForm();
          this.createLedger.IsLedgerGroup = false;
          this.parentLedgerList = [];
          this.getLedgerList();
          this.isDialogClose();
        },
        error: (err) => new CustomNotification(this.notificationService).ShowError(err.Message)
      });
    }
  }

  showError = false;
  LedgerSelection(e: SelectionChangeEvent): void {
    console.log(e);
  }

  public filterSettings = DropDownFilter.StartWithfilterSettings;
}
