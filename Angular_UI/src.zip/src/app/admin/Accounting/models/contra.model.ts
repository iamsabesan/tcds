export class TransactionLedgers {
  SlNo: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  ParentLedgerID: any;
}
export class TransactionToLedgers {
  SlNo: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  ParentLedgerID: string = "";
  Disabled: boolean = false;
}

export class PaidToLedgers {
  SlNo: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  IsLedgerGroup: boolean = false;
  ParentLedgerID: any;
  ParentLedgerName: any;
}


export class CreateContraPosting {
  TransferFrom: string = "";
  FromLedger: string = "";
  TransferTo: string = "";
  ToLedger: string = "";
  TransferAmount!: number;
  TransferDate: string = "";
  Notes: string = "";
}

export class ContraJournalList {
  SlNo: number = 0;
  VoucherID: string = "";
  VoucherNo: string = "";
  TransferDateI18: string = "";
  TransferFromID: string = "";
  TransferFrom: string = "";
  TransferToID: string = "";
  TransferTo: string = "";
  Amount: number = 0;
}

