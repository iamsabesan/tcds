export class DayBookDetails {
  FinancialYear: string = "";
  CashInHand: CashInHand = new CashInHand();
  BranchWiseCash: BranchDetails[] = [];
}

export class ReceiptDetails {
  ReceiptDate: string = "";
  CurrentDate: string = "";
}

export class BranchDetails {
  TenantBranchID: string = '';
  TenantBranchName: string = '';
  TenantBranchTypeID: number = 0;
  State: string = '';
  District: string = '';
  UndepositedCash: number = 0;
  PettyCash: number = 0;
  Denomination: string = '';
}

export class CashInHand {
  UndepositedCash: number = 0;
  PettyCash: number = 0;
}


export class Branch {
  BranchID: string = '35185B74-92F8-4B90-BA67-027835E7723A';
}
