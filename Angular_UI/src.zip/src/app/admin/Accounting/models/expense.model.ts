export class ExpensePosting {
  PaidThrough: string = '';
  PaidTo: string = '';
  FromLedger: string = '';
  ToLedger: string = '';
  TransactionCurrency: string = '';
  Amount!: number;
  ConversionRate!: number;
  TransactionAmount!: number;
  PostingDate: string = '';
  Notes: string = '';
  Attachments: Array<File> = [];
  PayMode: string = '';
  PayModeID: string = '';
  TransactionNumber: string = '';
  TransactionDate = new Date();
}

export class ExpensePostingList {
  SlNo: number = 0;
  VoucherID: string = '';
  VoucherNo: string = '';
  TransferDateI18: Date = new Date();
  TransferFromID: string = '';
  TransferFrom: string = '';
  TransferToID: string = '';
  TransferTo: string = '';
  BaseAmount: number = 0;
  Amount: number = 0;
  Bank: number = 0;
  Cash: number = 0;
  TransactionCurrency: string = "";
  ConversionRate: number = 0;
  Payments: string = '';
  Attachements: Attachments[] = [];
}

export class expensePayments {
  PayModeType: string = "";
  PayModeValue: number = 0;
  Amount: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  TransactionNo: string = "";
  //TransactionDate: string = "";
  TransactionDate: string = "";
}
export class Attachments {
  SlNo: number = 0;
  DocumentID: string = "";
  DocumentType: string = "";
  FileName: string = "";
  Icon: string = "";
}

export class PayModeList {
  SlNo: number = 0;
  PaymentModeID: string = '';
  PaymentModeName: string = '';
  PaymodeID: string = '';
  Paymode: string = '';
}

export class TransactionCurrency {
  SlNo: number = 0;
  BaseCurrencyCode: string = '';
  BaseCurrencyRate: number = 0;
  ConvertionDateI18: string = '';
  Currency: string = '';
  CurrencyCode: string = '';
  CurrencyID: string = '';
  CurrencySymbol: string = '';
}

export class ExpenseDate {
  FromDate = new Date();
  ToDate = new Date();
}
export class IExpenseUpdate {
  VoucherID: string = '';
  PaymentModeID: string = '';
  PayModeType: string = '';
  PayModeValue: string = '';
  Amount: string = '';
  LedgerID: string = '';
  LedgerName: string = '';
  TransactionNo: string = '';
  TransactionDate: string = '';
}


