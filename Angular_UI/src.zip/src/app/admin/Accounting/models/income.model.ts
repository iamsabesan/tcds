export class IncomePosting {
  PaidThrough: string = '';
  PaidTo: string = '';
  TransactionCurrency: string = '';
  Amount!: number;
  ConversionRate!: number;
  TransactionAmount!: number;
  PostingDate: string = '';
  Notes: string = '';
  PayMode: string = '';
  PayModeID: string = '';
  TransactionNumber: string = '';
  TransactionDate: string = '';
}

export class IncomePostingList {
  SlNo: number = 0;
  VoucherID: string = '';
  VoucherNo: string = '';
  TransferDateI18: string = '';
  TransferFromID: string = '';
  TransferFrom: string = '';
  TransferToID: string = '';
  TransferTo: string = '';
  BaseAmount: number = 0;
  Amount: number = 0;
  Bank: number = 0;
  Cash: number = 0;
  TransactionCurrency: string = "";
  ConversionRate: number = 0;
  Payments: IncomePayments = new IncomePayments();
}

export class IncomePayments{
  PayModeType: string = "";
  PayModeValue: number = 0;
  Amount: number = 0;
  BankName: string = "";
  TransactionNo: string = "";
  TransactionDateI18: string = "";
}

export class IncomeDate{
  FromDate = new Date();
  ToDate = new Date();
}
