export class JournalDate {
  FromDate = new Date();
  ToDate = new Date();
}

export class JournalDetailsList {
  SlNo: number = 0;
  JournalDate = new Date();
  JournalDateI18: string = "";
  JournalType: string = "";
  VoucherID: string = "";
  Ledgers: Ledgers = new Ledgers();
  Narration: string = "";
}

export class Ledgers {
  DebitLedgers: DebitLedgers[] = [];
  CreditLedgers: CreditLedgers[] = [];
}

export class DebitLedgers {
  DebitLedgerID: string = "";
  DebitLedgerName: string = "";
  DebitAmount: number = 0;
  //Notes: PaymentDetails = new PaymentDetails();
  PaymentDetail: string = '';
}
export class CreditLedgers {
  CreditLedgerID: string = "";
  CreditLedgerName: string = "";
  CreditAmount: number = 0;
  //Notes: PaymentDetails = new PaymentDetails();
  PaymentDetail: string = '';
}

// export class PaymentDetails {
//   PayModeType: string = "";
//   PayModeValue: number = 0;
//   Amount: number = 0;
//   BankName: string = "";
//   TransactionNo: string = "";
//   TransactionDateI18: string = "";
// }


// Receipt & Payment Journal payment details
export class ReceiptPaymentDetails {
  PayModeType: string = "";
  PayModeValue: number = 0;
  Amount: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  TransactionNo: string = "";
  TransactionDate: string = "";
}

// Sales & Sales return payment(plot) details
export class SalesPaymentDetails {
  FullName: string = '';
  BlockName: string = '';
  PlotNo: string = '';
}

// Contra payment details
export class ContraPaymentDetails {
  TransferFrom: string = '';
  TransferTo: string = '';
  FromLedger: string = '';
  ToLedger: string = '';
  TransferAmount: number = 0;
  TransferDate: string = '';
}
