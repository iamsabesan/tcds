export class LedgerList {
  SlNo: number = 0;
  LedgerID: string = "";
  LedgerName: string = "";
  ParentLedgerID: any;
  CategoryID: string = "";
  IsLedgerGroup: boolean = false;
  AllowCustomSubLedger: boolean = false;
}

export class CreateLedger {
  LedgerName: string = '';
  CategoryID: string = '';
  ParentLedgerID: string = '';
  IsLedgerGroup: boolean = false;
  ContactID: string = "";
  OpeningBalance: number = 0;
  IncreasedBy: string = "CREDIT";
  JournalDate: string = "";
}

export class Category {
  SlNo: number = 0;
  CategoryID: string = "''";
  CategoryName: string = "''";
  IncreaseBy: string = "''";
}

