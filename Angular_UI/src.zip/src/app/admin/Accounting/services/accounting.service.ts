import { Injectable } from '@angular/core';
// import { IRequestType } from '@src/core/model';
// import { HttpService } from '@src/core/service';
import { ContraJournalList, CreateContraPosting, TransactionLedgers } from '../models/contra.model';
import { Category, CreateLedger, LedgerList } from '../models/ledger.model';
import { Attachments, ExpensePosting, IExpenseUpdate, PayModeList } from '../models/expense.model';
// import { AppConfigService } from '@src/core/service/appconfig.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IncomePosting } from '../models/income.model';
import { saveAs } from 'file-saver';
import { Branch } from '../models/daybook.model';
import { HttpService } from 'src/core/service';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { IRequestType } from 'src/core/model';
import { DateConversion } from 'src/app/shared/app-global';
import { CrazyKey } from 'src/core/helper';
import { environment } from 'src/environments/environment';
// import { DateConversion } from '@src/app/shared/app-global';

@Injectable({
  providedIn: 'root'
})

export class AccountingService {

  public VoucherID: string = '';

  constructor(private http: HttpService, private httpDef: HttpClient, private appConfigService: AppConfigService) { }

  // * Ledger API Start
  GetLedgerList() {
    return this.http.get<LedgerList>("/accounting-service/ledgerhierarchy", { RequestType: IRequestType.Protected });
  }

  GetCategoryList() {
    return this.http.get<Category>("/accounting-service/chartofaccount", { RequestType: IRequestType.Protected });
  }

  CreateLedger(data: CreateLedger) {
    return this.http.post<CreateLedger>("/accounting-service/ledgercreate", data, { RequestType: IRequestType.Protected });
  }
  // * Ledger API End

  // * Contra API start
  GetContraJournalList() {
    return this.http.get<ContraJournalList>("/accounting-service/ContraPostedList", { RequestType: IRequestType.Protected });
  }

  GetTransactionLedgers() {
    return this.http.get<TransactionLedgers>("/accounting-service/ContraledgerList", { RequestType: IRequestType.Protected });
  }

  GetDayBookDate() {
    return this.http.get('/compass/v1/Payment/CurrentDayBookDate', { RequestType: IRequestType.Protected });
  }

  CreateContraPosting(data: CreateContraPosting) {
    return this.http.post<CreateContraPosting>("/accounting-service/ContraPosting", data, { RequestType: IRequestType.Protected });
  }
  // * Contra API End

  // * Expense API start
  GetLedgerBalance(ledgerID: string) {
    return this.http.get('/accounting-service/get-ledger-balance', { params: { ledgerID }, RequestType: IRequestType.Protected });
  }

  paidToLedgers() {
    return this.http.get('/accounting-service/Expenseledger', { RequestType: IRequestType.Protected });
  }

  createExpensePosting(data: ExpensePosting) {
    const formData = new FormData();
    formData.append('Paidthrough', data.PaidThrough);
    formData.append('PaidTo', data.PaidTo);
    formData.append('FromLedger', data.FromLedger);
    formData.append('ToLedger', data.ToLedger);
    formData.append('TransactionCurrency', data.TransactionCurrency);
    formData.append('ConvertionRate', data.ConversionRate as any);
    formData.append('TransactionAmount', data.TransactionAmount as any);
    formData.append('Amount', data.Amount as any);
    formData.append('PostingDate', data.PostingDate);
    formData.append('Notes', data.Notes);
    formData.append('PayMode', data.PayMode);
    formData.append('PayModeID', data.PayModeID);
    formData.append('TransactionNumber', data.TransactionNumber);
    formData.append('TransactionDate', data.TransactionDate as any);
    data.Attachments.forEach((e) => {
      formData.append('Documents', e);
    });
    return this.http.post<ExpensePosting>('/accounting-service/ExpenPosting', formData, { RequestType: IRequestType.Protected });
  }

  expensePostingList(fromdate: string, todate: string) {
    return this.http.get('/accounting-service/ExpensePostedList', { params: { fromdate, todate }, RequestType: IRequestType.Protected });
  }

  downloadAttachment(data: Attachments) {
    const token = 'Bearer ' + this.http._getRolloutApiKey();
    const headers = new HttpHeaders().set('Authorization', token);
    const baseUrl = CrazyKey.decrypt(this.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
    return this.httpDef.get(baseUrl + `/accounting-service/download/${data.DocumentID}`, { headers, responseType: "blob" }).subscribe({
      next: (res: Blob) => {
        saveAs(res, data.FileName);
      }
    });
  }

  getAvailablePaymode(moduleName: string) {
    return this.http.get<PayModeList[]>('/compass/v1/Payment/GetPaymodeType', {
      params: { moduleName },
      RequestType: IRequestType.Protected,
    });
  }

  getCurrency() {
    return this.http.get('/accounting-service/currency-rate', { RequestType: IRequestType.Protected });
  }
  // * Expense API End

  // * Income API Start
  incomePostingList(fromdate: string, todate: string) {
    const postingType = "income";
    return this.http.get('/accounting-service/posting-list', { params: { fromdate, todate, postingType }, RequestType: IRequestType.Protected });
  }

  createIncomePosting(data: IncomePosting) {
    const formData = new FormData();
    formData.append('Paidthrough', data.PaidTo);
    formData.append('PaidTo', data.PaidThrough);
    formData.append('TransactionCurrency', data.TransactionCurrency);
    formData.append('ConvertionRate', data.ConversionRate as any);
    formData.append('TransactionAmount', data.TransactionAmount as any);
    formData.append('Amount', data.Amount as any);
    formData.append('PostingDate', data.PostingDate);
    formData.append('Notes', data.Notes);
    formData.append('PayMode', data.PayMode);
    formData.append('PayModeID', data.PayModeID);
    formData.append('TransactionNumber', data.TransactionNumber);
    formData.append('TransactionDate', data.TransactionDate);
    return this.http.post('/accounting-service/income-posting', formData, { RequestType: IRequestType.Protected });
  }

  paidByLedgers() {
    return this.http.get('/accounting-service/income-ledger', { RequestType: IRequestType.Protected });
  }
  // * Income API End

  // * Journal-report API Start
  getJournalReportList(fromdate: string, todate: string) {
    return this.http.get('/accounting-service/journal-list', { params: { fromdate, todate }, RequestType: IRequestType.Protected });
  }
  // * Journal-report API End

  // * DayBook API Start
  getReceiptDateDetails() {
    return this.http.get('/compass/v1/Receipt/PaymentReceipt/current-daybook', { RequestType: IRequestType.Protected });
  }

  getBranchWiseCashDetails(data: any) {
    const res = DateConversion.ConvertStringToDate(data);
    const receiptDate = DateConversion.ConvertToYearMonthDate(res);
    return this.http.get('/accounting-service/getBranchWiseCash', { params: { receiptDate }, RequestType: IRequestType.Protected });
  }

  dayBookClose(data: Branch) {
    return this.http.post<Branch>('/compass/v1/Payment/Daybookclosing', data, { RequestType: IRequestType.Protected });
  }

  updatExpense(data: IExpenseUpdate) {
    return this.http.post<IExpenseUpdate>('/accounting-service/paymentEdit', data, { RequestType: IRequestType.Protected })
  }
  //  *DayBook API End
}
