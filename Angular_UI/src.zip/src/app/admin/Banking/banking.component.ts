import { BankingService } from './services/banking.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor, orderBy, SortDescriptor, } from '@progress/kendo-data-query';
import { BankDetailsList, CreateBank } from './models/banking.model';
import { BankList } from 'src/app/shared/model/payment';
import { CustomNotification } from 'src/app/shared/model/shared';
import { InputRegex } from 'src/app/shared/components/regex';
import { IWebError } from 'src/core/model';
import { DateConversion, ShowInactive } from 'src/app/shared/app-global';

@Component({
  selector: 'banking',
  templateUrl: './banking.component.html',
  styleUrls: ['./banking.component.scss'],
})
export class BankingComponent implements OnInit {

  /* View Child */
  @ViewChild('BankingForm') BankingForm!: NgForm;
  @ViewChild('accountName') private _accountName!: ElementRef;

  /* List */
  public gridView: BankDetailsList[] = [];
  public BankDetailsList: BankDetailsList[] = [];
  public ActiveBankDetailsList: BankDetailsList[] = [];
  public BankList: string[] = [];

  public IsDialogOpen: boolean = false;
  public createBank: CreateBank = new CreateBank();

  /* Grid Column Filter */
  public filter!: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];

  public IncreasedByList = ["CREDIT", "DEBIT"];
  public BankName: string = '';
  public checked = ShowInactive.ShowInactiveBank;

  /* Savings Account */
  public SavingsAccount: string = 'Savings Account';

  /* Form Group */
  FrmBanking = new FormGroup({
    AccountType: new FormControl(this.SavingsAccount),
    AccountName: new FormControl('', [Validators.minLength(3)]),
    AccountNumber: new FormControl(null, [Validators.required, Validators.minLength(9)]),
    BankName: new FormControl(null, [Validators.required]),
    IFSC: new FormControl(null, [Validators.required, Validators.minLength(11)]),
    OpeningBalance: new FormControl(0),
    Credit: new FormControl('CREDIT', [Validators.required]),
    Description: new FormControl(null),
  });

  constructor(private _srvNotification: NotificationService, private _srvBank: BankingService) { }

  ngOnInit() {
    this.getAccountList();
    this._srvBank.GetBankList().subscribe({
      next: (res: any) => {
        res.Data.forEach((e: BankList) => {
          this.BankList.push(e.BankName);
        });
      },
      error: (err: IWebError) => this.errorMsg(err)
    })
  }

  accounttypeChange() {
    setTimeout(() => {
      this._accountName.nativeElement.focus();
    }, 100);
  }

  getAccountList() {
    this._srvBank.GetBankAccountList().subscribe((res) => {
      this.BankDetailsList = res.Data;
      this.ActiveBankDetailsList = this.BankDetailsList.filter((e) => e.IsActive == true);
      if (ShowInactive.ShowInactiveBank == true) this.gridView = this.BankDetailsList;
      else this.gridView = this.ActiveBankDetailsList;
    });
  }

  /* check true or false based config type */
  modeSwitcher(value: string): void {
    if (!value) {
      this.gridView = this.ActiveBankDetailsList;
      ShowInactive.ShowInactiveBank = this.checked = false;
    } else {
      this.gridView = this.BankDetailsList;
      ShowInactive.ShowInactiveBank = this.checked = true;
    }
  }

  /* Account Type Change Event */
  public isDisabledIFSCCode: boolean = false;
  changeAccountType(event: any) {
    this.accounttypeChange();
    this.isDisabledIFSCCode = event.target.defaultValue === 'Credit Card' ? true : false;
    if (this.isDisabledIFSCCode) {
      this.FrmBanking.controls.IFSC.reset();
      this.FrmBanking.controls['IFSC'].clearValidators();
      this.FrmBanking.controls['IFSC'].updateValueAndValidity();
    }
    else {
      this.FrmBanking.controls['IFSC'].setValidators([Validators.required, Validators.minLength(11), Validators.pattern(this.IFSCRegex)]);
      this.FrmBanking.controls['IFSC'].updateValueAndValidity();
    }
  }

  /* Add New Bank Account */
  btnaddNew() {
    this.IsDialogOpen = true;
    this.FrmBanking.controls['Credit'].setValue('CREDIT');
    this.FrmBanking.controls['OpeningBalance'].setValue(0);
    this.createBank.AccountType = this.SavingsAccount;
    this.isDisabledIFSCCode = this.createBank.AccountType.toLowerCase() == 'credit card' ? true : false;
  }

  /* Close Dialog */
  btnCloseDialog() {
    this.IsDialogOpen = false;
    this.FrmBanking.reset();
  }

  btnSave(data: FormGroup) {
    this.FrmBanking.controls['AccountName'].setValidators([Validators.required]);
    this.FrmBanking.controls['AccountName'].updateValueAndValidity();

    if (data.invalid) this.FrmBanking.markAllAsTouched();
    else {
      const FrmValue = data.value;
      this.createBank.AccountName = FrmValue.AccountName;
      this.createBank.AccountNumber = FrmValue.AccountNumber;
      this.createBank.Bank = FrmValue.BankName;
      this.createBank.IFSC = this.createBank.AccountType === 'Credit Card' ? "" : FrmValue.IFSC;
      this.createBank.IncreasedBy = FrmValue.Credit;
      this.createBank.OpeningBalance = FrmValue.OpeningBalance;
      this.createBank.JournalDate = DateConversion.ConvertToDateMonthYear(new Date())
      this.createBank.Description = FrmValue.Description == null ? "" : FrmValue.Description;

      this._srvBank.AddBankAccount(this.createBank).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.getAccountList();
          this.btnCloseDialog();
        },
        error: (err) => this.errorMsg(err)
      });
    }
  }

  sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadData();
  }

  loadData(): void {
    this.gridView = orderBy(this.gridView, this.sort);
    this.gridView.length = this.gridView.length;
  }

  public MaxLength: number = 40;
  public IFSCRegex = InputRegex.IFSC;

  /* Dropdown Maxlength */
  maxLength(event: any) {
    const inputElement = event.target;
    if (inputElement.value.length > this.MaxLength) inputElement.value = inputElement.value.slice(0, this.MaxLength);
  }

  errorMsg(err: IWebError) {
    new CustomNotification(this._srvNotification).ShowError(err.Message);
  }
}
