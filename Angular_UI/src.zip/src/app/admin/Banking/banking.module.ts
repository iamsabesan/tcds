import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { IconModule } from '@progress/kendo-angular-icons';
import { GridModule } from '@progress/kendo-angular-grid';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogService } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
import { BankingService } from './services/banking.service';
import { BankingComponent } from './banking.component';
import { AppBarModule } from '@progress/kendo-angular-navigation';
import { LabelModule } from '@progress/kendo-angular-label';

const routes: Routes = [
  {
    path: '',
    component: BankingComponent
  }
];

@NgModule({
  declarations: [
    BankingComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    LayoutModule,
    AppBarModule,
    ToolBarModule,
    DialogModule,
    LabelModule,
    InputsModule,
    ButtonsModule,
    GridModule,
    IconModule,
    DropDownsModule,
    Ng2SearchPipeModule
  ],
  providers: [BankingService, NotificationService, DialogService]
})
export class BankingModule { }
