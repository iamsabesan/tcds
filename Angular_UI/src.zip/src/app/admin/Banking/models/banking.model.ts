export class CreateBank {
  AccountType: string = "Bank";
  AccountName: string = "";
  AccountNumber: string = "";
  Bank: string = "";
  IFSC: string = "";
  OpeningBalance: number = 0;
  IncreasedBy: string = "CREDIT";
  Description: string = "";
  JournalDate: string = "";
}

export class BankDetailsList {
  SlNo: number = 0;
  AccountID: string = "";
  AccountType: string = "";
  AccountName: string = "";
  AccountNumber: string = "";
  Bank: string = "";
  IFSC: string = "";
  LedgerID: string = "";
  IsActive: boolean = false;
}
