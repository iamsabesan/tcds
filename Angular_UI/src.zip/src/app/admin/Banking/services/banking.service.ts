import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { CreateBank } from '../models/banking.model';

@Injectable()

export class BankingService {
  constructor(public _srvHttp: HttpService) { }

  GetBankList() {
    return this._srvHttp.get('/common/Bank', { RequestType: IRequestType.Protected });
  }

  AddBankAccount(data: CreateBank) {
    return this._srvHttp.post('/accounting-service/AddBankAccount', data, { RequestType: IRequestType.Protected });
  }

  GetBankAccountList() {
    return this._srvHttp.get('/accounting-service/branch/bank-account', { RequestType: IRequestType.Protected });
  }
}
