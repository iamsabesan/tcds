import { Component } from '@angular/core';
import { BatchService } from './services/batch.service';
@Component({
  selector: 'app-batch',
  templateUrl: './batch.component.html',
  styleUrls: ["./batch.component.scss"],
  providers: [BatchService]
})
export class BatchComponent {
  public actions = '';
  constructor(private _srvBatch: BatchService) {
    this._srvBatch.batch.subscribe((res: any) => {
      this.actions = res.Mode;
    })
  }
} 
