import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { BatchService } from './services/batch.service';
import { BatchComponent } from './batch.component';
import { BatchCreateComponent } from './components/batch-create/batch-create.component';
import { BatchListComponent } from './components/batch-list/batch-list.component';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
const routes: Routes = [
  {
    path: '',
    component: BatchComponent,
    children: [
      {
        path: 'batch-create',
        component: BatchCreateComponent,
      },
      {
        path: 'batch-list',
        component: BatchListComponent,
      }
    ]
  }
];

@NgModule({
  declarations: [
    BatchComponent,
    BatchCreateComponent,
    BatchListComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,

    /* Kendo Component */
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    DropDownsModule,
    GridModule,
    LabelModule,
    DateInputsModule,
    DialogsModule,
    TelerikReportingModule,
  ],
  providers: [BatchService, DatePipe]
})
export class BatchModule { }
