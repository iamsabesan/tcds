import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, DropDownFilter, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { BatchCourse, CreateBatch } from '../../models/batch';
import { BatchService } from '../../services/batch.service';
import { DatePipe } from '@angular/common';
import { addMonths } from '@progress/kendo-date-math';
import { addDays } from '@progress/kendo-date-math';
import { CommonService } from 'src/app/shared/service/common.service';
import { UserList } from 'src/app/admin/user/models/user.model';

@Component({
  selector: 'batch-create',
  templateUrl: './batch-create.component.html',
  styleUrls: ['./batch-create.component.scss'],
})
export class BatchCreateComponent implements OnInit {

  /* List */
  public LstCourse: BatchCourse[] = [];
  public LstStoreCourse: BatchCourse[] = [];
  public LstFaculty: UserList[] = [];
  public LstStoreFaculty: UserList[] = [];

  /* Model */
  public MlCreateBacth: CreateBatch = new CreateBatch();
  public MlCourse: BatchCourse = new BatchCourse();

  /* Date & Time Format */
  public dateFormat: string = '';
  public timeFormat: string = '';
  public dateTime: string = '';
  public EndDate = new Date();
  public StartDate: string = '';
  public endDates: string = '';
  public min: Date = addDays(new Date(), 1);

  public courseNames: string = '';
  public endDateDisabled: boolean = false;

  /* Dropdown Filter */
  filterSettings = DropDownFilter.filterSettings;

  /* Form Group */
  FrmEntry = new FormGroup({
    course: new FormControl(null, [Validators.required]),
    type: new FormControl("Online", [Validators.required]),
    faculty: new FormControl(null, [Validators.required]),
    startDate: new FormControl(null, [Validators.required]),
    endDate: new FormControl(null, [Validators.required]),
    startTime: new FormControl(null, [Validators.required]),
    endTime: new FormControl(null, [Validators.required]),
    track: new FormControl("Regular", [Validators.required]),
    monday: new FormControl(false),
    tuesday: new FormControl(false),
    wednesday: new FormControl(false),
    thursday: new FormControl(false),
    friday: new FormControl(false),
    saturday: new FormControl(false),
    sunday: new FormControl(false),
  });

  constructor(
    private _srvBatch: BatchService, private _srvCommon: CommonService,
    private _srvNotification: NotificationService, private _datePipe: DatePipe) { }

  ngOnInit(): void {
    this.dateFormat = LocalString.DateFormat;
    this.timeFormat = LocalString.TimeFormat;

    /* Get Course List */
    this._srvBatch.getCourseBasicData().subscribe({
      next: (e) => this.LstCourse = this.LstStoreCourse = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });

    /* Get Faculty Data */
    this._srvCommon.getEmployees().subscribe({
      next: (e) => this.LstFaculty = this.LstStoreFaculty = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Faculty Filter */
  facultyFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.ContactName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery) ||
      data.Department.toLowerCase().includes(normalizedQuery) ||
      data.JobTitle.toLowerCase().includes(normalizedQuery);
    this.LstFaculty = this.LstStoreFaculty.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.ShortName.toLowerCase().includes(normalizedQuery) ||
      data.Course.toLowerCase().includes(normalizedQuery) ||
      data.CourseType.toLowerCase().includes(normalizedQuery);
    this.LstCourse = this.LstStoreCourse.filter(filterExpression);
  }

  /* Choose the Course Detail */
  courseName(event: any) {
    this.courseNames = event;
    this.MlCourse = this.LstCourse.find((e) => e.CourseID == event);
  }

  // Start to end date no reduce
  startDateChoose(event: any) {
    if (event) {
      // const Duration = this.MlCourse.Duration.split(" ");
      // this.checkDuration(Duration[1], +Duration[0], event);
      // this.endDateDisabled = false;
      this.EndDate = addDays(event, 1)
    }
    else {
      // this.endDateDisabled = true
      this.EndDate = new Date();
    }
  }

  /* Start Date Choose and Calculate the auto calculate the end date */
  checkDuration(durationType: string, duration: number, StartDate?: Date) {
    var date = new Date();
    if (durationType.toLowerCase() == "months") date = addDays(addMonths(StartDate, duration), 1);
    this.FrmEntry.controls['endDate'].setValue(date)
  }

  /* Go to Batch List Component */
  goBack() {
    this._srvBatch.batch.next({ Mode: 'list' });
  }

  /* Reset Data */
  reset() {
    this.FrmEntry.reset();
    this.EndDate = new Date();
    this.FrmEntry.controls['type'].setValue("Online");
    this.FrmEntry.controls['track'].setValue("Regular");
  }

  // create Batch Data save
  save(data: any) {
    if (!this.FrmEntry.valid) this.FrmEntry.markAllAsTouched();
    else if (data.startDate > data.endDate) this.errorMsg('Please select valid date');
    else {
      if ((data.monday || data.tuesday || data.wednesday || data.thursday || data.friday || data.saturday || data.sunday) === true) {
        this.MlCreateBacth.courseID = data.course;
        this.MlCreateBacth.batchType = data.type;
        this.MlCreateBacth.facultyID = data.faculty.ContactID;
        this.MlCreateBacth.startDate = DateConversion.ConvertToMonthDateYear(data.startDate);
        this.MlCreateBacth.endDate = DateConversion.ConvertToMonthDateYear(data.endDate);
        this.MlCreateBacth.monday = data.monday;
        this.MlCreateBacth.tuesday = data.tuesday;
        this.MlCreateBacth.wednesday = data.wednesday;
        this.MlCreateBacth.thursday = data.thursday;
        this.MlCreateBacth.friday = data.friday;
        this.MlCreateBacth.saturday = data.saturday;
        this.MlCreateBacth.sunday = data.sunday;
        this.MlCreateBacth.batchTrack = data.track;
        this.MlCreateBacth.startTime = this.getTimeFormat(data.startTime)
        this.MlCreateBacth.endTime = this.getTimeFormat(data.endTime)

        this._srvBatch.createBatch(this.MlCreateBacth).subscribe({
          next: (res) => {
            new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
            this.reset();
            this._srvBatch.batch.next({ Mode: 'list' });
          },
          error: (err) => this.errorMsg(err.Message)
        })
      }
      else this.errorMsg('Please select the batch schedule');
    }
  }

  /* Convert Time Format to String */
  getTimeFormat(date: Date): string {
    return this._datePipe.transform(date, 'shortTime') || '';
  }

  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}