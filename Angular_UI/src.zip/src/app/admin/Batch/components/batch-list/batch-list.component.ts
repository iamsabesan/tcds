import { Component, OnInit, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { ShowInactive, gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { BathList } from '../../models/batch';
import { BatchService } from '../../services/batch.service';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CookieService } from 'ngx-cookie-service';
import { CookieKey } from 'src/core/helper';
import { TelerikReportViewerComponent } from '@progress/telerik-angular-report-viewer';

@Component({
  selector: 'batch-list',
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.scss']
})
export class BatchListComponent implements OnInit {

  /* List */
  public LstBatch: BathList[] = [];
  public LstBatchStoreData: BathList[] = [];
  public edit: string[] = ['Edit', 'View'];

  public filter!: CompositeFilterDescriptor;
  public todayDate: Date = new Date();

  /* Date Format */
  public time: string = '';
  public grid = true;
  public gridStyle = new gridFontStyle('small');

  /* Grid Pagination */
  public buttonCount = 5;
  public pageSize: number = 15;
  public skip: number = 0;
  public sizes: number[] = [15, 25, 50, 100];

  /* Inactive Batch */
  public IsChecked: boolean = false;

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";

  constructor(private _srvBatch: BatchService, private _srvNotification: NotificationService, private layout: LayoutComponent, private _srvCookie: CookieService,) { }

  ngOnInit(): void {
    this.getBatchList();
    if (this._srvBatch.IsPagination) {
      this.pageSize = this._srvBatch.PageSize;
      this.skip = this._srvBatch.Skip;
    }
    this.IsChecked = ShowInactive.ShowInactiveBatch;
  }

  /* Get Batch List */
  getBatchList() {
    this._srvBatch.getBatchList().subscribe({
      next: (e) => {
        this.LstBatchStoreData = e.Data;
        if (ShowInactive.ShowInactiveBatch) this.LstBatch = this.LstBatchStoreData;
        else this.LstBatch = this.LstBatchStoreData.filter((e: any) => e.IsActive === true);
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    })
  }

  /* Page Change Event */
  pageEvent(event: PageChangeEvent) {
    this.pageSize = event.take;
    this.skip = event.skip;
  }

  /* Move to Batch Create Component */
  newbatch() {
    ShowInactive.ShowInactiveBatch = this.IsChecked;
    this._srvBatch.IsPagination = true;
    this._srvBatch.PageSize = this.pageSize;
    this._srvBatch.Skip = this.skip;
    this._srvBatch.batch.next({ Mode: 'create' });
  }

  /* Active & Inactive Batch Filter */
  modeSwitcher(event: boolean) {
    this.LstBatch = event == true ? this.LstBatchStoreData : this.LstBatchStoreData.filter((e: any) => e.IsActive === true);
  }

  view(data: BathList) {
    this.opened = true;
    this.title = 'Student Id Card';
    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;
    const parameter = {
      Authorization: this.bearerToken, Agent: window.navigator.userAgent, courseBatchID: data.CourseBatchID
    }

    this.Reportsource = {
      report: 'iCloud/StudentID',
      parameters: parameter
    };

  }

  close() {
    this.opened = false;
  }

  @ViewChild('viewer') viewer: TelerikReportViewerComponent;

  onViewerReady(e: any) {
    // Hide export buttons
    const toolbar = e.args.viewer.toolbar;
    
    toolbar.items.forEach(item => {
      if (item.name && item.name.toLowerCase().includes('export')) {
        item.visible(false);
      }
    });
  }
}
