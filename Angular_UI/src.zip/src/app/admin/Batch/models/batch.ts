import { dateRange } from "src/app/shared/model/info.model";

export class Batch {
  Mode = 'create' || 'list';
}

// Faculty Info
//E9536447-8F44-482A-93CF-F21B6429AC57
export const faculty = [
  {
    name: 'E9536447-8F44-482A-93CF-F21B6429AC57',
    designation: 'Web Development',
    dept: 'Information Technology',
  },
  {
    name: 'Sakthi',
    designation: '.NET',
    dept: 'Information Technology',
  },
  {
    name: 'Vinoth',
    designation: '.NET',
    dept: 'Information Technology',
  },
  {
    name: 'Sowmiya',
    designation: 'Digital Marketing',
    dept: 'Marketing',
  },
];

export class studentListFilter {
  batch: any;
  course: any;
  dateRange!: dateRange
}

/* Batch List */
export class BathList {
  CourseBatchID: string = "";
  BatchNumber: string = "";
  CourseName: string = "";
  Duration: string = "";
  FacultyID: string = "";
  FacultyName: string = "";
  BatchType: string = "";
  Timing: string = "";
  BatchTrack: string = "";
  StartDate: string = "";
  EndDate: string = "";
  IsActive: boolean = false;
  startTime: Date = new Date();
  endTime: Date = new Date();
}

/* Create a New Batch */
export class CreateBatch {
  courseID: string = '';
  batchType: string = '';
  facultyID: string = '';
  startDate: string = '';
  endDate: string = '';
  startTime: string = '';
  endTime: string = '';
  monday: boolean = false;
  tuesday: boolean = false;
  wednesday: boolean = false;
  thursday: boolean = false;
  friday: boolean = false;
  saturday: boolean = false;
  sunday: boolean = false;
  batchTrack: string = '';
}

/* Course List */
export class BatchCourse {
  CourseID: string = '';
  ShortName: string = '';
  Course: string = '';
  CourseType: string = '';
  Semester: number = 0;
  Duration: string = '';
  CourseFees: number = 0;
  AdmissionFees: number = 0;
  TotalFees: number = 0;
}