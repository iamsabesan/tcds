import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { Batch } from '../models/batch';

@Injectable({
  providedIn: 'root'
})
export class BatchService {

  public batch = new BehaviorSubject<Batch>({ Mode: 'list' });

  /* Pagination */
  public IsPagination: boolean = false;
  public PageSize: number = 0;
  public Skip: number = 0;

  constructor(private _srvHttp: HttpService) { }

  /* Get Batch List */
  getBatchList() {
    return this._srvHttp.get("/icloud-admission/v1/batch/list", { RequestType: IRequestType.Protected });
  }

  /* Create a New Bacth */
  createBatch(data: any) {
    return this._srvHttp.post("/icloud-admission/v1/batch/create", data, { RequestType: IRequestType.Protected })
  }

  /* Admin Approved Get Course Detail by franchisee */
  getCourseBasicData() {
    return this._srvHttp.get("/icloud-academic/v1/course/info/list/byfranchisee", { RequestType: IRequestType.Protected })
  }


}


