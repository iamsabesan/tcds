import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';
import { NotificationService } from '@progress/kendo-angular-notification';
import { InputRegex } from 'src/app/shared/components/regex';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CourseCreate, CreateCourse, CourseType, CreateCourseSubject, SubjectCreate, Subject, CourseList, CourseUpdateMl } from '../../models/course';
import { CourseServiceService } from '../../services/course-service.service';
import { DropDownFilter } from 'src/app/shared/app-global';
import { IWebError } from 'src/core/model';
import { SubjectService } from 'src/app/admin/Subject/services/subject.service';
import { SubjectData } from 'src/app/admin/Subject/models/subject';

@Component({
  selector: 'course-create',
  templateUrl: './course-create.component.html',
  styleUrls: ['./course-create.component.scss']
})
export class CourseCreateComponent {

  /* List */
  public LstCourseType: CourseType[] = [];
  public LstDurationType: string[] = ['Days', 'Weeks', 'Months', 'Years'];
  public LstSemester: number[] = [1, 2, 3, 4];
  public LstSubject: SubjectData[] = [];
  public LstSubjectBackup: SubjectData[] = [];

  /* Model */
  public MlCreateCourse: CourseCreate = new CourseCreate();
  public MlSubject: SubjectCreate = new SubjectCreate();
  public MlNewCourse: CreateCourse = new CreateCourse();
  public MlSubjectMappingCourse: CreateCourseSubject = new CreateCourseSubject();
  public MlCourseUpdate: CourseUpdateMl = new CourseUpdateMl();

  public currentStep: number = 0;

  /* Regex */
  public Name = InputRegex.alphaNumericOnly;
  public Number = InputRegex.Numeric;
  public StringNumSpec = InputRegex.StrNumSpec;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  public CheckEdit = false;

  public CourseType: string = '';

  // Course Form Group
  courseDetails = new FormGroup({
    shortName: new FormControl(null, [Validators.required, Validators.pattern(this.StringNumSpec)]),
    fullName: new FormControl(null, [Validators.required, Validators.pattern(this.StringNumSpec)]),
    courseName: new FormControl(null, [Validators.required, Validators.pattern(this.StringNumSpec)]),
    courseType: new FormControl(null, [Validators.required]),
    eligibility: new FormControl(null, [Validators.required]),
    duration: new FormControl(null, [Validators.required]),
    durationType: new FormControl(null, [Validators.required]),
    semester: new FormControl(null, [Validators.required, Validators.min(1), Validators.max(4)]),
    coursefees: new FormControl(null, [Validators.required, Validators.min(1)]),
    examfees: new FormControl(null, [Validators.required, Validators.min(1)]),
    admissionfees: new FormControl(null, [Validators.required, Validators.min(1)]),
  });

  constructor(private _srvCourse: CourseServiceService, private _srvNotification: NotificationService,
    private _srvSubject: SubjectService) {
    /* Course Type */
    this._srvCourse.getCourseTypeList().subscribe({
      next: (res: any) => this.LstCourseType = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  ngOnInit() {

    /* Subject List */
    this._srvSubject.getSubjectList().subscribe({
      next: (res: any) => this.LstSubject = this.LstSubjectBackup = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });


    // this._srvCourse.getCourseTypeList().subscribe({
    //   next: (res: any) => this.LstCourseType = res.Data,
    //   error: (err: IWebError) => this.errorMsg(err.Message)
    // });

    if (this._srvCourse.CheckCourseEdit) {
      this.FormEntryCourseEditData(this._srvCourse.CourseEditData);
      this.CheckEdit = true;
      this.CourseType = "Edit"
      this._srvCourse.CheckCourseEdit = false;
    } else this.CourseType = 'New'
  }

  /* Add a Subject */
  addNew() {
    this.MlSubject = new SubjectCreate();
    this.MlCreateCourse.subjectData.push(this.MlSubject);
  }

  /* Subject filter and book values getting */
  subjectFilter(event: any, index: number) {
    if (event === undefined) this.MlCreateCourse.subjectData[index].books = [];
    else {
      this.LstSubject.filter((e: Subject) => {
        if (e.SubjectID === event.SubjectID) this.MlCreateCourse.subjectData[index].books = e.Materials
      });
    }
  }

  public subjectFilterData(searchTerm: string): void {
    if (!searchTerm) {
      this.LstSubject = [...this.LstSubjectBackup];
      return;
    }

    const normalizedQuery = searchTerm.toLowerCase();

    this.LstSubject = this.LstSubjectBackup.filter(item =>
      item.SubjectName?.toLowerCase().includes(normalizedQuery) ||
      item.Materials?.some((m: any) =>
        m.MaterialName?.toLowerCase().includes(normalizedQuery)
      )
    );
  }


  // step validation
  private isStepValid = (index: number) => {
    return this.getGroupAt(index).valid || this.courseDetails.untouched;
  };

  private shouldValidate = (index: number) => {
    return this.getGroupAt(index).touched && this.currentStep >= index;
  };

  public stepActivate(e: StepperActivateEvent) {
    if (!this.courseDetails.valid) {
      e.preventDefault();
      this.courseDetails.markAllAsTouched();
    }
  }

  step = [
    {
      label: 'Course Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
    },
    {
      label: 'Subject Mapping',
    }
  ];

  /* Subject row delete */
  deletes(index: number) {
    this.MlCreateCourse.subjectData.splice(index, 1);
  }

  /* Go back on the Course list Component */
  goBack() {
    this._srvCourse.Mode.next({ Mode: 'LIST' });
  }

  /* Stepper next step with validation  */
  next() {
    if (this.courseDetails.valid && this.currentStep < this.step.length) {
      this.currentStep = this.currentStep + 1;
      return;
    }
    this.courseDetails.markAllAsTouched();
  }

  /* stepper pervious step */
  prev() {
    if (this.currentStep > 0) this.currentStep = this.currentStep - 1;
  }




  /* Create a new Course With Subject */
  save(data: any, subject: CourseCreate) {
    const validation = this.MlCreateCourse.subjectData.every(item => item.materialID && item.subjectID && item.semester);
    // const markValidation = this.MlCreateCourse.subjectData.every(item => (item.theoryMark + item.practicalMark) === 200);
    const markValidation = this.MlCreateCourse.subjectData.every(item => (item.theoryMark + item.practicalMark) <= 200);

    if (!this.courseDetails.valid) this.courseDetails.markAllAsTouched();

    else if (this.MlCreateCourse.subjectData.length > 0) {
      if (validation) {
        if (markValidation) {
          this.MlNewCourse.shortName = data.shortName;
          this.MlNewCourse.fullName = data.fullName;
          this.MlNewCourse.certificateName = data.courseName;
          this.MlNewCourse.courseType = data.courseType.CourseType;
          this.MlNewCourse.duration = data.duration;
          this.MlNewCourse.durationType = data.durationType;
          this.MlNewCourse.totalSemester = data.semester;
          this.MlNewCourse.courseFees = data.coursefees;
          this.MlNewCourse.examFees = data.examfees;
          this.MlNewCourse.admissionFees = data.admissionfees;
          this.MlNewCourse.Eligibility = data.eligibility;

          subject.subjectData.map((e: any) => {
            e.materialID = e.materialID.MaterialID;
            e.subjectID = e.subjectID.SubjectID;
          });

          subject.subjectData.forEach((e) => {
            this.MlSubjectMappingCourse = new CreateCourseSubject();
            this.MlSubjectMappingCourse.materialID = e.materialID;
            this.MlSubjectMappingCourse.practicalMark = e.practicalMark;
            this.MlSubjectMappingCourse.semester = e.semester;
            this.MlSubjectMappingCourse.subjectID = e.subjectID;
            this.MlSubjectMappingCourse.theoryMark = e.theoryMark;
            this.MlNewCourse.subjectMapping.push(this.MlSubjectMappingCourse);
          });

          this._srvCourse.createCourse(this.MlNewCourse).subscribe({
            next: (res) => {
              new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
              this.goBack();
            },
            error: (err) => this.errorMsg(err.Message)
          })
        }
        else this.errorMsg('Please fill correct mark')
      }
      else this.errorMsg('Please fill subject details')
    }
    else if (this.MlCreateCourse.subjectData.length == 0) this.errorMsg('Minimum One subject must be added')
  }

  public get currentGroup() {
    return this.getGroupAt(this.currentStep);
  }

  public getGroupAt(index: number) {
    var groups = Object.keys(this.courseDetails.controls).map((groupName) =>
      this.courseDetails.get(groupName)) as FormGroup[];
    return groups[index];
  }

  FormEntryCourseEditData(data: CourseList) {
    this.courseDetails.controls.admissionfees.setValue(data.AdmissionFees)
    this.courseDetails.controls.courseName.setValue(data.CertificatePrintName)
    setTimeout(() => {
      this.courseDetails.controls.courseType.setValue(this.LstCourseType.find(e => e.CourseType.toUpperCase() == data.CourseType.toUpperCase()));
    }, 200);
    this.courseDetails.controls.coursefees.setValue(data.CourseFees)
    // var duration = +data.Duration;
    this.courseDetails.controls.duration.setValue(+data.Duration)
    this.courseDetails.controls.durationType.setValue(this.LstDurationType.find(e => e == data.DurationType))
    this.courseDetails.controls.examfees.setValue(data.ExamFees)
    this.courseDetails.controls.fullName.setValue(data.Course)
    this.courseDetails.controls.semester.setValue(data.Semester)
    this.courseDetails.controls.shortName.setValue(data.ShortName)
    this.courseDetails.controls.eligibility.setValue(data.Eligibility);

    this.MlCourseUpdate.courseID = data.CourseID;
  }

  reset() {
    this.FormEntryCourseEditData(this._srvCourse.CourseEditData);

  }

  CourseUpdate() {
    this.MlCourseUpdate = new CourseUpdateMl();
    if (this.courseDetails.valid) {
      const FrmVal = this.courseDetails.value;
      this.MlCourseUpdate.admissionFees = FrmVal.admissionfees;
      this.MlCourseUpdate.certificateName = FrmVal.courseName;
      this.MlCourseUpdate.courseFees = FrmVal.coursefees;
      this.MlCourseUpdate.courseID = this._srvCourse.CourseEditData.CourseID;
      this.MlCourseUpdate.courseType = FrmVal.courseType.CourseType;
      this.MlCourseUpdate.duration = FrmVal.duration;
      this.MlCourseUpdate.durationType = FrmVal.durationType;
      this.MlCourseUpdate.examFees = FrmVal.examfees;
      this.MlCourseUpdate.fullName = FrmVal.fullName;
      this.MlCourseUpdate.shortName = FrmVal.shortName;
      this.MlCourseUpdate.totalSemester = FrmVal.semester;
      this.MlCourseUpdate.Eligibility = FrmVal.eligibility;

      this._srvCourse.PostUpdateCourse(this.MlCourseUpdate).subscribe({
        next: val => {
          new CustomNotification(this._srvNotification).ShowSuccess(val.Message);
          this.goBack()
        }, error: err => this.errorMsg(err.Message)
      })
    }
    this.courseDetails.markAllAsTouched();
  }

  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}

