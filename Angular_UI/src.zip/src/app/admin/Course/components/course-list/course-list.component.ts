import { Component, OnInit } from '@angular/core';
import { aggregateBy, AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, orderBy, SortDescriptor } from '@progress/kendo-data-query';
import { CourseList, ExpandedRow } from '../../models/course';
import { CourseServiceService } from '../../services/course-service.service';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DetailExpandEvent } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { CustomNotification } from 'src/app/shared/model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PageChangeEvent } from '@progress/kendo-angular-pager';

@Component({
  selector: 'course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.scss']
})
export class CourseListComponent implements OnInit {

  /* List */
  public LstCourse: CourseList[] = [];
  public btnOptions = ['Edit', 'Active'];

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();

  public buttonCount = 5;
  public pageSize: number = 15;
  public skip: number = 0;
  public sizes: any[] = [15, 25, 50, 100, "All"];

  /* Grid Filter & Aggregate */
  public filter!: CompositeFilterDescriptor;
  public tota!: AggregateResult;
  public total2!: AggregateResult;
  public aggregates: AggregateDescriptor[] = [];
  public aggregates2: AggregateDescriptor[] = [];
  public sort: SortDescriptor[] = [];
  public expandedDetailKeys = ExpandedRow.SubjectExpanded;

  /* Show or Not Footer */
  public showFooter: boolean = false;

  /* Show or Not Create Button Option */
  public showButton = LocalString.showAddButton;

  /* Currency Symbol Format */
  public currencySymbol = '';

  /* Grid Footer Sum Value */
  public totalValue: any[] = [];
  public totalTheory: number = 0;
  public totalPractical: number = 0;
  public totalMark: number = 0;
  public totals: number = 0;

  constructor(public _srvCourse: CourseServiceService, public intlService: IntlService, public _srvNotification: NotificationService) {
    this.showFooter = true;
    this.showButton = LocalString.showAddButton;
  }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.courseListDataValues();

    if (this._srvCourse.IsPagination) {
      this.pageSize = this._srvCourse.PageSize;
      this.skip = this._srvCourse.Skip;
    }
  }

  /* Get Course List Data */
  courseListDataValues() {
    if (this.showButton) {
      this._srvCourse.getCourseList().subscribe({
        next: (res) => this.aggregateGridData(res),
        error: (err) => this.errorMsg(err.Message)
      });
    }
    else {
      this._srvCourse.getFranchiseeCourseList().subscribe({
        next: (res) => this.aggregateGridData(res),
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Aggreate the grid data */
  aggregateGridData(res: any) {
    this.LstCourse = res.Data;
    this.LstCourse.map((res: any) => {
      this.aggregates2 = [{ field: "TheoryMarks", aggregate: "sum" }, { field: "PracticalMarks", aggregate: "sum" }, { field: "TotalMarks", aggregate: "sum" },]
      this.total2 = aggregateBy(res.SubjectMapping, this.aggregates2);
      res.courseTotal = Number(res.ExamFees) + Number(res.AdmissionFees);
      res.totalTheory = res.SubjectMapping.reduce((sum: any, current: any) => sum + current.TheoryMarks, 0);
      res.totalPractical = res.SubjectMapping.reduce((sum: any, current: any) => sum + current.PracticalMarks, 0);
      res.totalMark = res.SubjectMapping.reduce((sum: any, current: any) => sum + current.TotalMarks, 0);
    })
  }


  /* Page Change Event */
  pageEvent(event: PageChangeEvent) {
    this.pageSize = event.take
    this.skip = event.skip;
  }

  sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.loadData();
  }

  loadData() {
    this.LstCourse = orderBy(this.LstCourse, this.sort);
    this.LstCourse.length = this.LstCourse.length;
  }

  /* Course subject and other details expand */
  detailExpand(data: DetailExpandEvent) {
    this.totalValue = data.dataItem.SubjectMapping;
    this.expandedDetailKeys.push(data.dataItem.CourseID);
    ExpandedRow.SubjectExpanded = this.expandedDetailKeys = [...new Set(this.expandedDetailKeys)];
  }

  public expandDetailsBy = (dataItem: CourseList): any => {
    return dataItem.CourseID;
  }

  /* Go to New Course Component */
  newCourse() {
    this._srvCourse.IsPagination = true;
    this._srvCourse.PageSize = this.pageSize;
    this._srvCourse.Skip = this.skip;
    this._srvCourse.Mode.next({ Mode: 'CREATE' });
  }

  view(data: CourseList) {
    this._srvCourse.CheckCourseEdit = true;
    this._srvCourse.CourseEditData = data;
    this._srvCourse.Mode.next({ Mode: 'CREATE' });
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
