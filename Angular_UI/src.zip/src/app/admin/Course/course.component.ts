import { Component } from '@angular/core';
import { CourseServiceService } from "./services/course-service.service";
@Component({
  selector: 'course',
  templateUrl: './course.component.html',
  styleUrls: ["./course.component.scss"],
  providers: [CourseServiceService]
})

export class CourseComponent {
  public actions = '';

  constructor(private _srvCourse: CourseServiceService) {
    this._srvCourse.Mode.subscribe((res: any) => this.actions = res.Mode)
  }
}
