import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { CourseComponent } from './course.component';
import { CourseCreateComponent } from './components/course-create/course-create.component';
import { CourseListComponent } from './components/course-list/course-list.component';
import { CourseServiceService } from './services/course-service.service';
import { TooltipModule } from "@progress/kendo-angular-tooltip";
import { SubjectService } from '../Subject/services/subject.service';

const routes: Routes = [
  {
    path: '',
    component: CourseComponent,
    children: [
      {
        path: 'course-create',
        component: CourseCreateComponent
      },
      {
        path: 'course-list',
        component: CourseListComponent
      }
    ]
  }
];

@NgModule({
  declarations: [
    CourseComponent,
    CourseCreateComponent,
    CourseListComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,

    /* Kendo Component */
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    TooltipModule,
    DropDownsModule,
    PopupModule,
    GridModule,
    LabelModule,
  ],
  providers: [CourseServiceService, SubjectService]
})
export class CourseModule { }
