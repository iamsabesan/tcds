export interface Course {
    Mode: 'LIST' | 'CREATE';
}

/* Course list Expanded Subject Data */
export class ExpandedRow {
    static SubjectExpanded: string[] = [];
}


//#region Course List
/* Course List */
export class CourseList {
    CourseID: string = '';
    ShortName: string = '';
    Course: string = '';
    CourseType: string = '';
    Duration: string = '';
    DurationType: string = '';
    CertificatePrintName: string = '';
    CourseFees: number = 0;
    ExamFees: number = 0;
    AdmissionFees: number = 0;
    TotalFees: number = 0;
    Semester: number = 0;
    Eligibility: string = '';
    SubjectMapping: CourseSubject[] = [];
}

/* Course List Subject */
export class CourseSubject {
    CourseID: string = '';
    SubjectID: string = '';
    SubjectName: string = '';
    Semester: number = 0;
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
    TotalMarks: number = 0;
}
//#endregion

//#region Create Course
/* Create a New Course */
export class CreateCourse {
    shortName: string = '';
    fullName: string = '';
    certificateName: string = '';
    courseType: string = '';
    duration: number = 0;
    durationType: string = '';
    totalSemester: number = 0;
    courseFees: number = 0;
    examFees: number = 0;
    admissionFees: number = 0;
    Eligibility: string = '';
    subjectMapping: CreateCourseSubject[] = [];
}

/* Create a New Course With add Subject */
export class CreateCourseSubject {
    subjectID: string = '';
    materialID: string = '';
    semester: number = 0;
    theoryMark: number = 0;
    practicalMark: number = 0;
}

/* Subject */
export class Subject {
    SubjectID: string = '';
    SubjectName: string = '';
    Materials: SubjectMaterial[] = [];
}

/* Subject Material */
export class SubjectMaterial {
    MaterialID: string = '';
    MaterialName: string = '';
}

/* Course Type */
export class CourseType {
    CourseTypeID: string = '';
    CourseType: string = '';
}

/* Create a course */
export class CourseCreate {
    id: number;
    shortName: string = '';
    fullName: string = '';
    courseName: string = '';
    courseType: any;
    duration: number = 0;
    durationType: string = '';
    coursefees: number = 0;
    examfees: number = 0;
    admissionfees: number = 0;
    semester: number = 0;
    courseTotal: number = 0;
    theoryTotal: number = 0;
    subjectData: SubjectCreate[] = [];
}

export class SubjectCreate {
    subjectID: string = '';
    materialID: string = '';
    semester: number = 0
    books?: SubjectMaterial[] = [];
    theoryMark: number = 0;
    practicalMark: number = 0;
}
//#endregion

export class CourseUpdateMl {
    courseID: string = '';
    shortName: string = '';
    fullName: string = '';
    certificateName: string = '';
    courseType: string = '';
    duration: number = 0;
    durationType: string = '';
    totalSemester: number = 0;
    courseFees: number = 0;
    examFees: number = 0;
    admissionFees: number = 0;
    Eligibility: string = '';
}
