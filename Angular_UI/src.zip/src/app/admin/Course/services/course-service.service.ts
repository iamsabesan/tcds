import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { Course, CourseList, CourseUpdateMl, CreateCourse } from '../models/course';
import { Master } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})

export class CourseServiceService {

  public Mode = new BehaviorSubject<Course>({ Mode: 'LIST' });
  // public courseCreate = new BehaviorSubject<CourseCreate[]>([]);

  public IsPagination: boolean = false;
  public PageSize: number = 0;
  public Skip: number = 0;

  public CourseEditData: CourseList = new CourseList();
  public CheckCourseEdit: boolean = false;

  constructor(private _srvHttp: HttpService) { }

  //#region Course
  /* Get Course List */
  getCourseList() {
    return this._srvHttp.get(Master.getAdmninCourse, { RequestType: IRequestType.Protected })
  }

  /* Get Course List (Franchisee) */
  getFranchiseeCourseList() {
    return this._srvHttp.get(Master.getFranchiseeCourse, { RequestType: IRequestType.Protected })
  }
  //#endregion

  //#region Course Create
  /* Get Course Type (CERTIFICATE or SUMMER , etc) */
  getCourseTypeList() {
    return this._srvHttp.get(Master.getCourseType, { RequestType: IRequestType.Protected })
  }

  /* Create New Course */
  createCourse(createCourse: CreateCourse) {
    return this._srvHttp.post(Master.createCourse, createCourse, { RequestType: IRequestType.Protected })
  }

  /* Update Course */
  PostUpdateCourse(data: CourseUpdateMl) {
    return this._srvHttp.post(Master.updateCourse, data, { RequestType: IRequestType.Protected })
  }
  //#endregion
}
