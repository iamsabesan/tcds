import { Component, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { gridFontStyle } from 'src/app/shared/app-global';
import { DeliveryModeComponent } from 'src/app/shared/components/delivery-mode/delivery-mode.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CertificateAndMarksheetList, CertificateAndMaterial } from '../../models/despatch';
import { DespatchService } from '../../services/despatch.service';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { IWebError } from 'src/core/model';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'certificate-marksheet-despatch-list',
  templateUrl: 'certificate-marksheet-despatch-list.component.html',
  styleUrls: ['certificate-marksheet-despatch-list.component.scss']
})

export class CertificateMarksheetDespatchListComponent {

  /* ViewChild */
  @ViewChild(DeliveryModeComponent) DeliveryModeComponent!: DeliveryModeComponent;

  /* List */
  public LstCertificateMarksheet: CertificateAndMarksheetList[] = [];
  public LstCertificateDespatch: CertificateAndMaterial[] = [];

  /* Model */
  public MlCertificateDespatch: CertificateAndMaterial = new CertificateAndMaterial();
  public gridStyle = new gridFontStyle();

  /* Delivery Mode Value */
  public selectedValue: number = 0;
  public deliveryID: string = '';

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  constructor(private _srvNotification: NotificationService,
    private _srvDespatch: DespatchService,
    private _srvCommon: CommonService) { }

  ngOnInit() {
    this.getCertificateDespatch();
  }

  /* Get Certificate Despatch List */
  getCertificateDespatch() {
    this._srvDespatch.getCertificateAndMarkSheetList().subscribe({
      next: (e) => {
        this.LstCertificateMarksheet = e.Data;
        this.LstCertificateMarksheet.forEach((e) => {
          e.FranchiseeName = e.FranchiseeName.toUpperCase();
          e.TrackingID = '';
          e.Address = this._srvCommon.concatAddress(e);
          e.IsDespatched = false
        });
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Select the Delivery Mode  */
  onComboboxSelected(data: any) {
    this.deliveryID = this.selectedValue = data;
  }

  /* Enter the Delivery tracking ID */
  inputData(event: any, index: number) {
    this.LstCertificateMarksheet[index].TrackingID = event;
  }

  /* Reset */
  btnResetCertificate() {
    this.DeliveryModeComponent.clearCombo();
    this.selectedValue = 0;
    this.LstCertificateMarksheet.forEach((E: CertificateAndMarksheetList) => {
      E.IsDespatched = false;
      E.TrackingID = "";
    });
  }

  /* Certificate Marksheet Despatching */
  btnSubmit() {
    this.LstCertificateDespatch = [];

    this.LstCertificateDespatch = this.LstCertificateMarksheet.filter(e => e.IsDespatched).map(E => ({
      deliveryModeID: this.deliveryID,
      examIndentTransID: E.ExamIndentTransID,
      trackingID: E.TrackingID
    }));

    const isCheckSelected = this.LstCertificateMarksheet.every((e) => e.IsDespatched == false);
    const isCheckTrackingID = this.LstCertificateMarksheet.some((e) => e.IsDespatched == true && (e.TrackingID == null || e.TrackingID == ''));

    if (this.selectedValue == undefined || this.selectedValue == 0) this.errorMsg("Please select delivery mode");
    else if (isCheckSelected) this.errorMsg("Please select atleast one record");
    else if (isCheckTrackingID) this.errorMsg("Please fill the delivery tracking ID");

    else {
      this._srvDespatch.despatchCertificateAndMarksheet(this.LstCertificateDespatch).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.getCertificateDespatch();
          this.btnResetCertificate();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}

