import { Component, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DeliveryModeComponent } from 'src/app/shared/components/delivery-mode/delivery-mode.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { DespatchMaterials, DespatchMaterial, MaterialDespatchList } from '../../models/despatch';
import { DespatchService } from '../../services/despatch.service';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'app-despatch-material',
  templateUrl: './despatch-material.component.html',
  styleUrls: ['./despatch-material.component.scss']
})
export class DespatchMaterialComponent {
  /* View Child */
  @ViewChild(DeliveryModeComponent) DeliveryModeComponent!: DeliveryModeComponent;

  /* List */
  public LstDespathMaterial: MaterialDespatchList[] = [];

  /* Model */
  public MlDespatchMaterial: DespatchMaterial = new DespatchMaterial();
  public MlDespatch: DespatchMaterials = new DespatchMaterials();

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  public selectedValue: string = "";
  public currencySymbol: string = '';

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  constructor(private _srvNotification: NotificationService,
    private _srvDespatch: DespatchService,
    private _srvCommon: CommonService) { }

  ngOnInit() {
    this.getMaterialDispatch();
    this.currencySymbol = LocalString.CurrencySymbol;
  }

  /* Get Material Despacth */
  getMaterialDispatch() {
    this._srvDespatch.getMaterialDispatchList().subscribe({
      next: (e) => {
        this.LstDespathMaterial = e.Data;
        this.LstDespathMaterial.forEach((e: MaterialDespatchList) => {
          e.isSelected = false;
          e.trackId = '';
          e.Address = this._srvCommon.concatAddress(e);
          e.FranchiseeName = e.FranchiseeName.toUpperCase();
        });
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Reset */
  resets() {
    this.LstDespathMaterial.forEach((e: any) => e.isSelected = false);
    this.DeliveryModeComponent.clearCombo();
    this.selectedValue = undefined;
  }

  /* Despatch Dropdown */
  onComboboxSelected(data: any) {
    if (data == undefined) this.selectedValue = '';
    else this.selectedValue = data;
  }

  /* Delivery mode track ID */
  onKey(event: any, index: number) {
    this.LstDespathMaterial[index].trackId = event.target.value;
  }

  /* Despatch Indent Material */
  despatch() {
    this.MlDespatchMaterial.despatchMaterial = [];
    this.LstDespathMaterial.filter((e: MaterialDespatchList) => {
      if (e.isSelected) {
        this.MlDespatch = new DespatchMaterials();
        this.MlDespatch.materialIndentTransID = e.MaterialIndentTransID;
        this.MlDespatch.deliveryModeID = this.selectedValue;
        this.MlDespatch.trackingID = e.trackId;
        this.MlDespatchMaterial.despatchMaterial.push(this.MlDespatch);
      }
    });

    const isCheckSelected = this.LstDespathMaterial.every((e) => e.isSelected == false);
    const isCheckTrackingID = this.LstDespathMaterial.some((e) => e.isSelected == true && (e.trackId == null || e.trackId == ''));

    if (this.selectedValue == "") this.errorMsg("Choose the delivery mood");
    else if (isCheckSelected) this.errorMsg("Please select atleast one record");
    else if (isCheckTrackingID) this.errorMsg("Please fill the delivery tracking ID");
    else {
      this._srvDespatch.despatchMaterial(this.MlDespatchMaterial).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.resets();
          this.getMaterialDispatch();
          this.selectedValue = '';
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}