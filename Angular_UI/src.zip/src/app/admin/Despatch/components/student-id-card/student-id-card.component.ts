import { Component, ViewChild } from '@angular/core';
import { LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { CommonService } from 'src/app/shared/service/common.service';
import { IDCardDespatch, StudentIDCardDespatch } from '../../models/despatch';
import { DespatchService } from '../../services/despatch.service';
import { IWebError } from 'src/core/model';
import { DeliveryModeComponent } from 'src/app/shared/components/delivery-mode/delivery-mode.component';

@Component({
  selector: 'app-student-id-card',
  templateUrl: './student-id-card.component.html',
  styleUrls: ['./student-id-card.component.scss']
})
export class StudentIDCardComponent {

  /* ViewChild */
  @ViewChild(DeliveryModeComponent) DeliveryModeComponent!: DeliveryModeComponent;

  /* List */
  public LstDespathIDCard: StudentIDCardDespatch[] = [];

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();
  public MlDespatchStudentIDCard: IDCardDespatch = new IDCardDespatch();

  /* Delivery Mode Select */
  public selectedValue: string = "";

  /* Currency Symbol */
  public currencySymbol: string = '';

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;

  constructor(private _srvCommon: CommonService,
    private _srvDespatch: DespatchService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getDespatchData();
  }

  /* Get Student ID Card Despatch List */
  getDespatchData() {
    this._srvDespatch.getStudentDespatch().subscribe({
      next: (res: any) => {
        this.LstDespathIDCard = res.Data;
        res.Data.forEach((E) => {
          // E.franchiseeDetails.Address = E.franchiseeDetails.Area + ", " + E.franchiseeDetails.District + ", " + E.franchiseeDetails.State + " - " + E.franchiseeDetails.Pincode;
          E.franchiseeDetails.Address = this._srvCommon.concatAddress(E.franchiseeDetails);
        });
        if (this.LstDespathIDCard.length) {
          this.LstDespathIDCard.forEach((e) => {
            e.TrackingID = '';
            e.isSelected = false;
            e.franchiseeDetails.FranchiseeName = e.franchiseeDetails.FranchiseeName.toUpperCase();
          });
        }
      },
      error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
    });
  }


  /* Despatch Dropdown */
  onComboboxSelected(data: any) {
    if (data == undefined) this.selectedValue = '';
    else this.selectedValue = data;
  }

  /* Reset Data */
  btnReset() {
    this.DeliveryModeComponent.clearCombo();
    this.selectedValue = '';
    this.LstDespathIDCard.forEach((e) => {
      e.TrackingID = '';
      e.isSelected = false;
    });
  }

  /* Despatch */
  btnDespatchIndent() {
    const isCheckSelected = this.LstDespathIDCard.every((e) => e.isSelected == false);
    const isCheckTrackingID = this.LstDespathIDCard.some((e) => e.isSelected == true && (e.TrackingID == null || e.TrackingID == ''));

    if (this.selectedValue == "") this._srvCommon.errorMsg("Choose the delivery mood");
    else if (isCheckSelected) this._srvCommon.errorMsg("Please select atleast one record");
    else if (isCheckTrackingID) this._srvCommon.errorMsg("Please fill the delivery tracking ID");
    else {
      this.MlDespatchStudentIDCard.DespatchMaterial = [];
      this.MlDespatchStudentIDCard.DespatchMaterial = this.LstDespathIDCard.filter((e) => e.isSelected == true).map(e => ({
        IDCardIndentID: e.IDCardIndentID,
        deliveryModeID: this.selectedValue,
        trackingID: e.TrackingID,
      }));
      this._srvDespatch.postStudentIDCardDespatch(this.MlDespatchStudentIDCard).subscribe({
        next: (res: any) => {
          this._srvCommon.successMsg(res.Data);
          this.getDespatchData();
          this.btnReset();
        },
        error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
      })
    }
  }
}