import { Component } from '@angular/core';

@Component({
  selector: 'app-despatch',
  templateUrl: './despatch.component.html',
  styleUrls: ["./despatch.component.scss"],
})
export class DespatchComponent {
  constructor() { }
} 
