import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DespatchService } from './services/despatch.service';
import { DespatchComponent } from './despatch.component';
import { DespatchMaterialComponent } from './components/despatch-material/despatch-material.component';
import { CertificateMarksheetDespatchListComponent } from './components/certificate-marksheet-despatch-list/certificate-marksheet-despatch-list.component';
import { DeliveryModule } from 'src/app/shared/components/delivery-mode/delivery.module';
import { StudentIDCardComponent } from './components/student-id-card/student-id-card.component';

const routes: Routes = [
  {
    path: '',
    component: DespatchComponent,
    children: [
      {
        path: 'material-despatch-list',
        component: DespatchMaterialComponent,
      },
      {
        path: 'certificate-marksheet-despatch-list',
        component: CertificateMarksheetDespatchListComponent
      },
      {
        path: 'student-ID-Card',
        component: StudentIDCardComponent
      }
    ]
  }
];

@NgModule({
  declarations: [
    DespatchComponent,
    DespatchMaterialComponent,
    CertificateMarksheetDespatchListComponent,
    StudentIDCardComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),

    /* Kendo Component */
    ButtonsModule,
    InputsModule,
    FormsModule,
    GridModule,

    /* Shared Module */
    DeliveryModule
  ],
  providers: [DespatchService]
})
export class DespatchModule { }
