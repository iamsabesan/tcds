//#region Certificate Despatch
export class Despatch {
  DeliveryMode: string = '';
}

//#region Certificate Despatch List
export class CertificateAndMarksheetList {
  IsDespatched: boolean;
  TenantBranchID: string = '';
  ExamIndentTransID: string = '';
  IndentDate: string = '';
  IndentNumber: string = '';
  FranchiseeID: string = '';
  FranchiseeName: string = '';
  Address?: string = "";
  Address1: string = '';
  Address2: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Area: string = '';
  Pincode: string = '';
  StudentID: string = '';
  StudentName: string = '';
  Course: string = '';
  Semester: string = '';
  Type: string = '';
  TrackingID?: string = '';
}

/* Despatch Certificate & Marksheet */
export class CertificateAndMaterial {
  examIndentTransID: string = '';
  deliveryModeID: string = '';
  trackingID: string = '';
}
//#endregion


//#region Material Despatch
export class MaterialDespatchList {
  isSelected: boolean = false;
  TenantBranchID: string = '';
  BranchMaterialIndentID: string = '';
  MaterialIndentTransID: string = '';
  MaterialName: string = '';
  Quantity: number = 0;
  Price: number = 0;
  Total: number = 0;
  ConfirmedDate: string = '';
  FranchiseeID: string = '';
  FranchiseeName: string = '';
  Address?: string = '';
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  District: string = '';
  State: string = '';
  Country: string = '';
  Pincode: string = '';
  trackId?: string = '';
}

export class DespatchMaterial {
  despatchMaterial: DespatchMaterials[] = [];
}

export class DespatchMaterials {
  materialIndentTransID: string = '';
  deliveryModeID: string = '';
  trackingID: string = '';
}
//#endregion

//#region Student ID Card
export class StudentIDCardDespatch {
  IDCardIndentID: string = '';
  TenantBranchID: string = '';
  IndentNumber: string = '';
  IndentFees: number = 0;
  TotalIndent: number = 0;
  Printed: number = 0;
  IndentDate: string = '';
  PrintedDate: string = '';
  isSelected: boolean = false
  TrackingID: string = '';
  franchiseeDetails: FranchiseeDetails = new FranchiseeDetails();
}

export class FranchiseeDetails {
  TenantBranchID: string = '';
  FranchiseeCode: string = '';
  FranchiseeName: string = '';
  ContactName: string = '';
  Phone: string = '';
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  Taluk: string = '';
  State: string = '';
  District: string = '';
  Pincode: string = '';
}

export class IDCardDespatch {
  DespatchMaterial: IDCard[] = [];
}

export class IDCard {
  IDCardIndentID: string = '';
  deliveryModeID: string = '';
  trackingID: string = '';
}


//#endregion