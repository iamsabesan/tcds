import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { CertificateAndMaterial, DespatchMaterial, IDCardDespatch } from '../models/despatch';
import { Despatch } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class DespatchService {

  constructor(private _srvHttp: HttpService) { }

  //#region List
  /* Get Despatch Material Indent List */
  getMaterialDispatchList() {
    return this._srvHttp.get("/icloud-inventory/v1/indent/despatch/list", { RequestType: IRequestType.Protected });
  }

  /* Get Despatch Certificate & Marksheet */
  getCertificateAndMarkSheetList() {
    return this._srvHttp.get("/icloud-admission/v1/student/certificate/despatch/list", { RequestType: IRequestType.Protected });
  }
  //#endregion

  //#region Despatch
  /* Material Indent */
  despatchMaterial(data: DespatchMaterial) {
    return this._srvHttp.post("/icloud-inventory/v1/indent/material/despatch/new", data, { RequestType: IRequestType.Protected })
  }

  /* Certificate */
  despatchCertificateAndMarksheet(despatchCertificateAndMarksheet: CertificateAndMaterial[]) {
    return this._srvHttp.post("/icloud-admission/v1/student/certificate/despatch", despatchCertificateAndMarksheet, { RequestType: IRequestType.Protected })
  }
  //#endregion

  //#region Student ID Card
  getStudentDespatch() {
    return this._srvHttp.get(Despatch.getAdminIDCardDespatch, { RequestType: IRequestType.Protected });
  }

  postStudentIDCardDespatch(despatchData: IDCardDespatch) {
    return this._srvHttp.post(Despatch.postStudentIDCardDespatch, despatchData, { RequestType: IRequestType.Protected });
  }
  //#endregion
}
