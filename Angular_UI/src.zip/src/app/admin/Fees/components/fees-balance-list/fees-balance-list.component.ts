import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, State, aggregateBy, process } from '@progress/kendo-data-query';
import { directStudentViewDataType } from 'src/app/admin/Student/models/student-profile';
import { StudentService } from 'src/app/admin/Student/services/student.service';
import { DateConversion, DateSize, getUrl, gridFontStyle, LocalString, ZeroGUID } from 'src/app/shared/app-global';
import { BatchColumn, batchBasicData } from 'src/app/shared/model/common';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
import { balanceListDataType } from '../../models/fees';
import { FeesService } from '../../services/fees.service';
import { DataStateChangeEvent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { AppService } from 'src/core/service';
import { MultiColComboComponent } from 'src/app/shared/components/multi-col-combo/multi-col-combo.component';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { DateRanges } from 'src/app/shared/model/date-ranges';

@Component({
  selector: 'app-fees-balance-list',
  templateUrl: './fees-balance-list.component.html',
  styleUrls: ['./fees-balance-list.component.scss'],
})
export class FeesBalanceListComponent implements OnInit {
  @ViewChild(MultiColComboComponent) batchDropDown: MultiColComboComponent;
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  public LstFeesBalanceStudent: balanceListDataType[] = [];
  public LstBatchSession = ['Morning', 'Afternoon', 'Evening'];
  public LstAllBatch: batchBasicData[] = [];
  public LstStatus: string[] = [];

  /* Model */
  public MlStudentViewData: directStudentViewDataType = new directStudentViewDataType();
  public gridStyle = new gridFontStyle();
  public MlDateRange: DateRanges = new DateRanges();
  public MlStatus: any;


  /* Multi Column Dropdown */
  public BatchColumns = BatchColumn;

  /* Batch */
  public batchValue: any;

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  /* Grid Footer (SUM) */
  public IsShowFooterTotalAmount: boolean = false;
  public total!: AggregateResult;
  public aggregates: AggregateDescriptor[] = [];

  /* Grid Pagination */
  public buttonCount = 5;
  public skip = 0;
  public pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100];

  public currencySymbol: string = '';
  public batchLabel: string = '';

  public WholePerStrDate: Date;

  public MobileAndName: string = '';

  public MobileNameFilter: any;

  public dateFormat: string = '';
  public dateWholePeriod: boolean;
  public dateStyle = new DateSize('medium');

  /* grid group aggreate using the state */
  public state: State = {
    skip: 0,
    take: 5,
    filter: {
      logic: "and",
      filters: [],
    },
  };

  constructor(private _routes: Router, public _srvValueShare: ValueShareService,
    private _srvCommon: CommonService, private _srvFees: FeesService,
    private _srvNotification: NotificationService, public intlService: IntlService,
    public _srvApp: AppService, public _srvStudent: StudentService,
  ) {
    const tenentBranchid = LocalString.TenantBranchID;

    this._srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    });
  }

  ngOnInit(): void {
    this.MobileAndName = '';
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateWholePeriod = true;
    this.dateFormat = LocalString.DateFormat;
    this.getAllBatch();
    this._srvFees.getStudentFeesStatus().subscribe({
      next: val => {
        this.LstStatus = val.Data;
        if (this.LstStatus.length) this.MlStatus = this.LstStatus.find((e: any) => e.toLowerCase() == "all")
      }
    })

  };

  ngAfterViewInit() {
    if (this._srvApp.checkGoBack) {
      setTimeout(() => {
        this.batchDropDown.value = this._srvFees.MLFeesbalanaceBatch;
        this.batchValue = this._srvFees.MLFeesbalanaceBatch;
        this.submit();
        this.pageSize = this._srvFees.listPageSize;
        this.skip = this._srvFees.listPageSkip;
        this._srvApp.checkGoBack = false;
      }, 100);
    }
    else this.submit();
  }

  /* Date Change */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Get batch basic data */
  getAllBatch() {
    this._srvCommon.getBatchBasicInfo().subscribe({
      next: (e) => {
        this.LstAllBatch = e.Data;
        if (this._srvApp.FeesCheckGoBack && this.LstAllBatch !== undefined) {
          // this.batchValue = this.LstAllBatch[0]
          // this.submit()
        }
        else {
          this._srvApp.FeesCheckGoBack = true
        }
      },

      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });

  }


  /* Choose Batch*/
  selectBatch(event: any) {
    this.batchValue = event;
  }

  /* Date Wise Filter Fees Balance List */
  submit() {
    this.IsShowFooterTotalAmount = false;
    this.LstFeesBalanceStudent = [];
    var CourseBatchID: string = '';
    var NameMobile: string = '';
    var FromDate: string = '';
    var ToDate: string = '';
    var Status: string = '';
    // if (this.batchValue !== undefined) {
    if (this.MobileNameFilter && (this.MobileNameFilter.length < 3)) this._srvCommon.errorMsg('Please enter the correct name / mobile ')
    else if ((this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate) || (!this.dateRanges.dateRange.startDate && this.dateRanges.dateRange.endDate)) this._srvCommon.errorMsg('Please enter the correct date')
    else

      NameMobile = this.MobileNameFilter ?? '';
    FromDate = this.dateRanges.dateRange.startDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.startDate) : '';
    ToDate = this.dateRanges.dateRange.endDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.endDate) : '';
    Status = this.MlStatus ?? '';
    CourseBatchID = this.batchValue ? this.batchValue.CourseBatchID : ZeroGUID.guid;

    if (Status && Status.toLowerCase() != 'all') {
      Status = Status.split(' ').join('');
    }
    this._srvFees.getStudentBalance(CourseBatchID, NameMobile, FromDate, ToDate, Status).subscribe({
      next: (e) => {
        this.LstFeesBalanceStudent = e.Data;
        if (this.LstFeesBalanceStudent.length !== 0) {
          this.IsShowFooterTotalAmount = true;
          this.aggregates = [, { field: "TotalFees", aggregate: 'sum' }, { field: "PaidFees", aggregate: 'sum' }, { field: "BalanceFees", aggregate: 'sum' }];
          this.total = aggregateBy(this.LstFeesBalanceStudent, this.aggregates);
        }
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
    // }
  }

  /* Student fees balance view and student profile page go */
  view(dataItem: any) {
    this.MlStudentViewData = dataItem;
    this._srvApp.val = this.MlStudentViewData;
    this._srvApp.ContactID = this.MlStudentViewData.ContactID
    this._srvFees.listPageSize = this.pageSize;
    this._srvFees.listPageSkip = this.skip;
    this._routes.navigate(['/iCloud/student/student-profile']);
    this._srvApp.checkStudentView = true;
    getUrl.invokingUrl = '/iCloud/fees/balance-list';
    this._srvFees.MLFeesbalanaceBatch = this.batchDropDown.value;
  }

  /* Batch filter */
  handleFilterChange(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.CourseBatchID.toLowerCase().includes(normalizedQuery) ||
      data.CourseName.toLowerCase().includes(normalizedQuery) ||
      data.FacultyID.toLowerCase().includes(normalizedQuery) ||
      data.Timing.toLowerCase().includes(normalizedQuery) ||
      data.BatchType.toLowerCase().includes(normalizedQuery);
    this.LstAllBatch = this.LstAllBatch.filter(filterExpression);
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
  }


  /* Grid Filter the record Dynamic change Total Amount */
  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    const LstFees = process(this.LstFeesBalanceStudent, this.state);
    this.IsShowFooterTotalAmount = false;
    if (LstFees.data.length !== 0) {
      this.total = aggregateBy(LstFees.data, this.aggregates);
      this.IsShowFooterTotalAmount = true;
    }
  }


}
