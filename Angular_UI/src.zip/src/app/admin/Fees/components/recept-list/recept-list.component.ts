import { Component, HostListener } from '@angular/core';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { aggregateBy, AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, State, SortDescriptor, process } from '@progress/kendo-data-query';
import { CookieService } from 'ngx-cookie-service';
import { DateConversion, DateSize, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CookieKey } from 'src/core/helper/CookieKey.model';
import { feesDataType } from '../../models/fees';
import { FeesService } from '../../services/fees.service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'app-recept-list',
  templateUrl: './recept-list.component.html',
  styleUrls: ['./recept-list.component.scss'],
})

export class ReceptListComponent {

  /* List */
  public LstFeesReceipt: feesDataType[] = [];
  public LstFees: GridDataResult;

  /* Model */
  public MlDateRange: DateRanges = new DateRanges();
  public gridStyle = new gridFontStyle();
  public dateStyle = new DateSize('medium');

  public currencySymbol = '';
  public dateFormat: string = '';
  public dateWholePeriod: boolean;

  /* Grid Filter & Aggregate */
  public filter!: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];
  public aggregates!: AggregateDescriptor[];
  public total!: AggregateResult;

  /* grid group aggreate using the state */
  public state: State = {
    skip: 0,
    take: 5,
    filter: {
      logic: "and",
      filters: [],
    },
  };

  /* Grid Footer */
  public IsShowFooterTotalAmount: boolean = false;

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: number[] = [25, 50, 100];

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";

  public WholePerStrDate: Date;

  public MobileAndName: string = '';

  /* For Responsiveness */
  getScreenWidth: any;
  getScreenHeight: any;
  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight - 75;
  }

  constructor(public intlService: IntlService, private _srvCookie: CookieService,
    private layout: LayoutComponent, private _srvNotification: NotificationService,
    private _srvFees: FeesService, private _srvCommon: CommonService) {
    const tenentBranchid = LocalString.TenantBranchID;
    this._srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    });
  }

  ngOnInit() {
    this.dateWholePeriod = true;
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.searchFeesReceipt();
    this.getWindowDimesion(window);
  }

  /* Date Change */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Date Wise Filter Fees Receipt */
  searchFeesReceipt() {
    this.LstFeesReceipt = [];
    if (!this.MlDateRange.startDate || !this.MlDateRange.endDate || (this.MobileAndName && this.MobileAndName.length < 3)) this.errorMsg("Please fill the details");
    else {
      const fromDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
      const endDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);
      const nameOrPhone = this.MobileAndName ?? '';

      this._srvFees.getStudentFees(fromDate, endDate, nameOrPhone).subscribe({
        next: (e) => {
          this.LstFeesReceipt = e.Data;
          this.IsShowFooterTotalAmount = this.LstFeesReceipt.length !== 0 ? true : false;
          this.aggregates = [{ field: "Amount", aggregate: "sum" }];
          this.total = aggregateBy(this.LstFeesReceipt, this.aggregates);

          if (this.LstFeesReceipt.length) {
            this.LstFeesReceipt.forEach(val => {
              val.Date = DateConversion.ConvertStringToDate(val.ReceiptDate);

            })
          }
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  };

  /* Grid Filter the record Dynamic change Total Amount */
  dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.LstFees = process(this.LstFeesReceipt, this.state);
    this.IsShowFooterTotalAmount = false;
    if (this.LstFees.data.length !== 0) {
      this.total = aggregateBy(this.LstFees.data, this.aggregates);
      this.IsShowFooterTotalAmount = true;
    }
  }

  close() {
    this.opened = false;
  }

  receipt(data: any) {
    this.opened = true;
    this.title = 'Receipt';
    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;
    const parameter = {
      Authorization: this.bearerToken, Agent: window.navigator.userAgent, TenantBranchTransID: data.TenantBranchTransID, Amount: this.convertAmountToWord(data.Amount)
    }

    if (data.PaymentType.toUpperCase() === "DOWN PAYMENT") {
      this.Reportsource = {
        report: 'iCloud/FeesReceipt(DownPayment)',
        parameters: parameter
      };
    }
    else {
      this.Reportsource = {
        report: 'iCloud/FeesReceipt(PartPayment)',
        parameters: parameter
      };
    }
  }

  /* Convert the Currecny number to Words */
  private convertAmountToWord(n: number): string {
    if (n === 0) return 'Zero';

    const first_twenty = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    const convert3 = (num: number): string => {
      if (num === 0) return '';
      if (num < 20) return first_twenty[num] + ' ';
      if (num < 100) return tens[Math.floor(num / 10)] + ' ' + first_twenty[num % 10];
      return first_twenty[Math.floor(num / 100)] + ' Hundred ' + convert3(num % 100);
    };

    let result = '';
    let value = n;
    const places = ['', 'Thousand', 'Million', 'Billion', 'Trillion'];
    let placeIndex = 0;

    while (value > 0) {
      if (value % 1000 !== 0) {
        result = convert3(Math.floor(value % 1000)) + places[placeIndex] + ' ' + result;
      }
      value = Math.floor(value / 1000);
      placeIndex++;
    }

    return result.trim();
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
} 
