import { Component } from '@angular/core';
import { StudentService } from '../Student/services/student.service';
import { FeesService } from './services/fees.service';
@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ["./fees.component.scss"],
})
export class FeesComponent{
  actions = '';
  constructor(public service :FeesService, public student_service:StudentService){ }
}
