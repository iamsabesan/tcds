import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogService, DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CourseDetailModule } from 'src/app/shared/components/course-detail/course-detail.module';
// import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';
import { ReceptListComponent } from './components/recept-list/recept-list.component';
import { FeesBalanceListComponent } from './components/fees-balance-list/fees-balance-list.component';
import { StudentCourseDetailModule } from 'src/app/shared/components/student-course-detail/student-course-detail.module';
import { FeesService } from './services/fees.service';
import { FeesComponent } from './fees.component';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { NotificationService } from '@progress/kendo-angular-notification';
import { StudentModule } from '../Student/student.module';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { MultiColComboComponentModule } from 'src/app/shared/components/multi-col-combo/multi-col-combo.module';
import { AdminService } from 'src/core/service';
import { StudentService } from '../Student/services/student.service';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
// import { StudentModule } from '../Student/student.module';

const routes: Routes = [
    {
        path: '',
        component: FeesComponent,
        children: [
            {
                path: 'receipt-list',
                component: ReceptListComponent
            },
            {
                path: 'balance-list',
                component: FeesBalanceListComponent
            }
        ]
    }
];

@NgModule({
    declarations: [
        FeesComponent,
        ReceptListComponent,
        FeesBalanceListComponent,
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,
        ReactiveFormsModule,

        /* Kendo Component */
        ButtonsModule,
        IconsModule,
        GridModule,
        DialogsModule,
        TelerikReportingModule,
        InputsModule,
        LabelModule,
        DropDownsModule,

        /* Shared Component */
        StudentModule,
        MultiColComboComponentModule,
        StudentCourseDetailModule,
        CourseDetailModule,
        DateRangesModule,

    ],
    providers: [FeesService, NotificationService, DialogService, AdminService, StudentService],
    //schemas: [NO_ERRORS_SCHEMA]
})
export class FeesModule { }
