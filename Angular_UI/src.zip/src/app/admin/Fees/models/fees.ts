// Fees Balance list
export class balanceListDataType {
    StudentID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    StartDate: string = '';
    EndDate: string = '';
    StartTime: Date = new Date();
    EndTime: Date = new Date();
    TotalFees: number = 0;
    PaidFees: number = 0;
    BalanceFees: number = 0;
    BatchMappingID: string = '';
    ContactID: string = '';
    CourseTypeName: string = '';
    ShortName: string = '';
    Status: string = '';
}

//  Fees Receipt List
export class feesDataType {
    TenantBranchTransID: string = '';
    StudentID: string = '';
    ReceiptDate: string = '';
    ReceiptNo: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    PaymentType: string = '';
    Amount: number = 0;
    Date: Date;
}