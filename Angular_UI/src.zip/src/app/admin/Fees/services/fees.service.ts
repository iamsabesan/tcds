import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
// import { shareStudentValue } from '../../Student/models/student-profile';
import { StudentService } from '../../Student/services/student.service';
import { batchBasicData } from 'src/app/shared/model/common';
import { Fees } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class FeesService {
  public srvStore: any;
  public checkGoBack = false;
  public listPageSize: any = 15;
  public listPageSkip: any = 0;
  // public directStudentData = new BehaviorSubject<shareStudentValue>({});
  public MLFeesbalanaceBatch = new batchBasicData();
  constructor(public http_service: HttpService, public student_service: StudentService) { }
  ngOnInit() { }

  getStudentBalance(batchMappingID: string, NamePhone: string, FromDate: string, ToDate: string, Status: string) {
    return this.http_service.get(`/icloud-admission/v1/student/receipt/outstandingbalance?batchMappingID=${batchMappingID}&nameOrPhone=${NamePhone}&fromDate=${FromDate}&toDate=${ToDate}&status=${Status}`, { RequestType: IRequestType.Protected })
  }

  getStudentFees(fromDate: string, toDate: string, nameOrPhone: string) {
    return this.http_service.get('/icloud-admission/v1/student/receipt/list', { params: { fromDate, toDate, nameOrPhone }, RequestType: IRequestType.Protected })
  }

  getcertificatePrint(examIndentTransiD: string) {
    return this.http_service.get("/icloud-admission/v1/student/certificate/print", { params: { examIndentTransiD }, RequestType: IRequestType.Protected })
  }

  getStudentFeesStatus() {
    return this.http_service.get(Fees.getStudentFeesStatus, { RequestType: IRequestType.Protected });
  }
}
