import { Component } from '@angular/core';
import { RequestListService } from './services/request-list.service';

@Component({
  selector: 'app-franchisee-request-list',
  templateUrl: './franchisee-request-list.component.html',
  styleUrls: ["./franchisee-request-list.component.scss"],
  providers: [RequestListService]
})
export class FrachiseeRequestListComponent {
  public action: string = '';
  constructor(public service: RequestListService) {
    service.request.subscribe((res: any) => {
      this.action = res.Mode
    });
  }

}