import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DialogService, DialogsModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { GridModule } from '@progress/kendo-angular-grid';
import { IconsModule } from '@progress/kendo-angular-icons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { NotificationModule, NotificationService } from '@progress/kendo-angular-notification';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { RequestListService } from './services/request-list.service';
import { FrachiseeRequestListComponent } from './Franchisee-request-list.component';
import { RequestListComponent } from './components/request-list/request-list.component';
import { FranchiseeDetailComponent } from './components/franchisee-detail/franchisee-detail.component';
import { FranchiseePaymentDetailsComponent } from './components/franchisee-payment-details/franchisee-payment-details.component';
import { RejectViewComponent } from './components/reject-view/reject-view.component';
import { ApprovedViewComponent } from './components/approved-view/approved-view.component';
import { PaymentInfoModule } from 'src/app/shared/components/payment-info/payment-info.module';
import { FranchiseeRequestDetailsModule } from 'src/app/shared/components/franchisee-request-details/franchisee-request-details.module';
import { RejectModule } from 'src/app/shared/components/reject/reject.module';
import { LabelModule } from '@progress/kendo-angular-label';

const routes: Routes = [
  {
    path: '',
    component: FrachiseeRequestListComponent,
    children: [
      {
        path: 'franchisee-request-list',
        component: RequestListComponent,
      },

      {
        path: 'franchisee-detail',
        component: FranchiseeDetailComponent,
      },
      {
        path: 'franchisee-payment-details',
        component: FranchiseePaymentDetailsComponent,
      },
      {
        path: 'reject-view',
        component: RejectViewComponent,
      },
    ]
  }
];

@NgModule({
  declarations: [
    FrachiseeRequestListComponent,
    FranchiseePaymentDetailsComponent,
    FranchiseeDetailComponent,
    RequestListComponent,
    RejectViewComponent,
    ApprovedViewComponent

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,

    /* Kendo Component */
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    DialogsModule,
    InputsModule,
    GridModule,
    NotificationModule,
    DialogsModule,
    LabelModule,

    /* Shared Component */
    RejectModule,
    FranchiseeRequestDetailsModule,
    PaymentInfoModule,
  ],
  providers: [RequestListService, NotificationService, DialogService],
})
export class FrachiseeRequestListModule { }
