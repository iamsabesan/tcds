import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { LocalString } from 'src/app/shared/app-global';
import { InputRegex } from 'src/app/shared/components/regex';
import { feesDataType, franchiseeRequests } from '../../models/request-list';
import { RequestListService } from '../../services/request-list.service';

@Component({
  selector: 'app-approved-view',
  templateUrl: './approved-view.component.html',
  styleUrls: ['./approved-view.component.scss']
})
export class ApprovedViewComponent {
  /* List */
  public LstSubscribe: feesDataType[] = [];

  /* Model */
  public MlFranchiseeDetail: franchiseeRequests = new franchiseeRequests();

  public setMinAmt: number = 1;
  public value: number = 0;
  public decemial: number = 0;
  public Name = InputRegex.Name;
  public aproval: number = 0;
  public currencySymbol: string = '';

  constructor(public fb: FormBuilder, private _srvRequest: RequestListService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this._srvRequest.request.subscribe((e: any) => {
      if (e.Mode.toLowerCase() !== 'list') {
        this.MlFranchiseeDetail = e.data;
        this.LstSubscribe = e.data.FeesDetails;
        this.MlFranchiseeDetail.FeesDetails.filter((e: any) => {
          this.value = +e.NewFees;
        });
      }
    });
  }

  back() {
    this._srvRequest.request.next({ Mode: 'list' });
  }
}
