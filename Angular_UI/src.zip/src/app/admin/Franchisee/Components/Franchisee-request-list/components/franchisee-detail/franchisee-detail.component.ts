import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogService } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
import { LocalString } from 'src/app/shared/app-global';
import { RejectComponent } from 'src/app/shared/components/reject/reject.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { approvalFees, approvalFreesDataType, feesDataType, franchiseeRequests, rejectReasonType } from '../../models/request-list';
import { RequestListService } from '../../services/request-list.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-franchisee-detail',
  templateUrl: './franchisee-detail.component.html',
  styleUrls: ['./franchisee-detail.component.scss']
})
export class FranchiseeDetailComponent implements OnInit {

  /* List */
  public LstSubscribe: feesDataType[] = [];

  /* Model */
  public MlFranchiseeApproval: approvalFreesDataType = new approvalFreesDataType();
  public MlFees: feesDataType = new feesDataType();
  public MlFranchiseeDetails: franchiseeRequests = new franchiseeRequests();
  public MlApprovalFeesData: approvalFees = new approvalFees();
  public MlFranchiseerejectReason: rejectReasonType = new rejectReasonType();

  /* Numeric TextBox Format */
  public setMinAmt: number = 1;
  public value: number = 0;
  public decemial: number = 0;

  public franchiseeId: string = '';
  public dialog: boolean = false;
  public aproval: number = 0;
  public currencySymbol = '';
  public temp: boolean = false;
  public packageID: string = '';
  public franchiseeRequestID: string = '';

  feesDetail = this.fb.group({
    NewFees: [],
  });

  constructor(public fb: FormBuilder, private _srvRequest: RequestListService, private _srvNotification: NotificationService, public srvdialog: DialogService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;

    this.getData();
  }

  // Franchisee Request Details 
  getData() {
    this._srvRequest.request.subscribe((e: any) => {
      if (e.Mode.toLowerCase() !== 'list') {
        this.MlFranchiseeDetails = e.data;
        this.MlFranchiseeDetails.FeesDetails.filter((e: any) => {
          this.MlFees.ActualFees = +e.ActualFees;
          this.MlFees.Duration = e.Duration;
          this.MlFees.NewFees = +e.NewFees;
          this.MlFees.PackageID = e.PackageID;
          this.MlFees.TenantBranchID = e.TenantBranchID;
          this.aproval = +e.ActualFees;
          this.packageID = e.PackageID
        })
        this.LstSubscribe.push(this.MlFees);
        if (this.MlFranchiseeDetails) this.temp = true;
      }

      this.franchiseeId = this.MlFranchiseeDetails.BranchRequestID;
      this.franchiseeRequestID = this.MlFranchiseeDetails.FranchiseeRequestID;
    });
  }

  requestAproval() {
    if (this.feesDetail.valid === true) { }
    else this.feesDetail.markAllAsTouched();
  }

  dialogOpen() {
    const dialogRef = this.srvdialog.open({
      title: "Reject Franchisee",
      content: RejectComponent,
      width: 400
    });

    const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

    rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
      this.MlFranchiseerejectReason.franchiseeRequestID = this.franchiseeRequestID;
      this.MlFranchiseerejectReason.reason = formData.Reason;

      this._srvRequest.postRejectReason(this.MlFranchiseerejectReason).subscribe({
        next: (response) => {
          new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
          this.back();
          dialogRef.close();
        },
        error: (error) => new CustomNotification(this._srvNotification).ShowError(error.Message),
      });
    });



    // dialog.rejectionID = this.franchiseeRequestID;

    // dialogRef.result.subscribe((result: any) => {
    //   if (!(result instanceof DialogCloseResult)) {
    //     this._srvRequest.request.next({ Mode: 'list' });
    //   }
    // });
  };


  // Franchisee Request Approval
  approval(data: any) {
    if (this.feesDetail.valid === true) {

      this.MlApprovalFeesData.newFees = data.NewFees;
      this.MlApprovalFeesData.packageID = this.packageID;
      this.MlFranchiseeApproval.packageItems.push(this.MlApprovalFeesData);

      this.MlFranchiseeApproval.FranchiseeRequestID = this.franchiseeRequestID;

      this._srvRequest.postApprovalFees(this.MlFranchiseeApproval).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this._srvRequest.request.next({ Mode: 'list' });
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }

    else {
      this.feesDetail.markAllAsTouched();
      this.errorMsg("Fill the fees");
    }
  }

  back() {
    this._srvRequest.request.next({ Mode: 'list' });
  }


  /* Show Error Message */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}


