import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DialogService } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
import { LocalString } from 'src/app/shared/app-global';
import { RejectComponent } from 'src/app/shared/components/reject/reject.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { franchiseeActivateDataType, franchiseeRequests, fransPaymentRej } from '../../models/request-list';
import { RequestListService } from '../../services/request-list.service';
import { PaymentDetailViewListMl } from 'src/app/shared/model/common';

@Component({
  selector: 'app-franchisee-payment-details',
  templateUrl: './franchisee-payment-details.component.html',
  styleUrls: ['./franchisee-payment-details.component.scss']
})
export class FranchiseePaymentDetailsComponent implements OnInit {

  /* Model */
  public MlFranchiseeDetails: franchiseeRequests = new franchiseeRequests();
  public MlFranchiseeActivate: franchiseeActivateDataType = new franchiseeActivateDataType();
  public MlFranchiseePay: fransPaymentRej = new fransPaymentRej();

  /* List */
  public LstPaymentInfo: PaymentDetailViewListMl[] = [];

  public total: number = 0;
  public currencySymbol = '';
  public dialog = false;
  public FranchiseeRequestID = '';

  /* Dynamic change text color */
  public isRejected: boolean = false;

  constructor(private _srvRequest: RequestListService, public routes: Router, public notificationService: NotificationService, public dialogservice: DialogService) { }

  ngOnInit(): void {
    if (this._srvRequest.request) {
      this.total = this.LstPaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
      this.currencySymbol = LocalString.CurrencySymbol;

      this._srvRequest.request.subscribe((e: any) => {
        if (e.Mode.toLowerCase() !== 'list') {
          this.MlFranchiseeDetails = e.data;
          this.isRejected = this.MlFranchiseeDetails.Status.toUpperCase() == 'REJECTED(PAYMENT)' ? true : false;
          this.LstPaymentInfo = e.data.PaymentDetails;
        }

      });
    }
  }



  // Franchisee Request Active
  activate() {
    this.MlFranchiseeActivate.franchiseeRequestID = this.MlFranchiseeDetails.FranchiseeRequestID;
    this._srvRequest.postFranchiseeActivate(this.MlFranchiseeActivate).subscribe({
      next: (e) => {
        new CustomNotification(this.notificationService).ShowSuccess(e.Message);
        this.routes.navigate(['/iCloud/franchisee/franchisee-list']);
      },
      error: (err) => new CustomNotification(this.notificationService).ShowError(err.Message)
    })
  }

  // Franchisee Payment Request reject
  dialogOpen() {
    const dialogRef = this.dialogservice.open({
      title: "Reject Franchisee",
      content: RejectComponent,
      width: 400
    });
    // const dialog = dialogRef.content.instance;

    const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

    rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
      this.MlFranchiseePay.franchiseeRequestID = this.MlFranchiseeDetails.FranchiseeRequestID;
      this.MlFranchiseePay.packageLogID = this.MlFranchiseeDetails.PackageLogID;
      this.MlFranchiseePay.reason = formData.Reason;

      this._srvRequest.postFransPaymentReject(this.MlFranchiseePay).subscribe({
        next: (response) => {
          new CustomNotification(this.notificationService).ShowSuccess(response.Message);
          this.goBack();
          dialogRef.close();
        },
        error: (error) => new CustomNotification(this.notificationService).ShowError(error.Message),
      });
    });



    // dialog.franchiseeRequestID = this.MlFranchiseeDetails.FranchiseeRequestID;
    // dialog.packageID = this.MlFranchiseeDetails.PackageLogID;
    // dialogRef.result.subscribe((result: any) => {
    //   if (!(result instanceof DialogCloseResult)) {
    //     this._srvRequest.request.next({ Mode: 'list' });
    //   }
    // });
  };
  goBack() {
    this._srvRequest.request.next({ Mode: 'list' })
  }
}
