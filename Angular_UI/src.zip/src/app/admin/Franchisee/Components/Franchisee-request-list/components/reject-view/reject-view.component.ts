import { Component } from '@angular/core';
import { franchiseeRequests, rejectReason } from '../../models/request-list';
import { RequestListService } from '../../services/request-list.service';

@Component({
  selector: 'app-reject-view',
  templateUrl: './reject-view.component.html',
  styleUrls: ['./reject-view.component.scss']
})
export class RejectViewComponent {
  public MlRequestReject: rejectReason = new rejectReason();
  public MlFranchiseeRejectData: franchiseeRequests = new franchiseeRequests()
  public MlFranchiseeDetail: franchiseeRequests = new franchiseeRequests()

  constructor(public service: RequestListService) { }

  ngOnInit(): void {
    this.service.request.subscribe((e: any) => {
      this.MlFranchiseeDetail = e.data;
    })
  }

  goBack() {
    this.service.request.next({ Mode: 'list' })
  }
}
