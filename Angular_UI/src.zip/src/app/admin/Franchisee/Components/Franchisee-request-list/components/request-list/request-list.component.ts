import { Component } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { franchiseeRequests } from '../../models/request-list';
import { RequestListService } from '../../services/request-list.service';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
@Component({
  selector: 'app-request-list',
  templateUrl: './request-list.component.html',
  styleUrls: ['./request-list.component.scss'],
})
export class RequestListComponent {

  /* List */
  public LstRequestFranchisee: franchiseeRequests[] = [];

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  /* Date Format */
  public dateFormat: string = '';

  /* Grid Header Column Style */
  public gridStyle = new gridFontStyle();

  public buttonCount = 5;
  public skip = 0;
  public pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];

  constructor(private _srvRequest: RequestListService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.getFranchiseeRequest();
    if (this._srvRequest.listPageSize) {
      this.pageSize = this._srvRequest.listPageSize;
      this.skip = this._srvRequest.listPageSkip;
    }
  }

  // Franchisee Request List
  getFranchiseeRequest() {
    this._srvRequest.getInactiveList().subscribe({
      next: (res) => {
        this.LstRequestFranchisee = res.Data;
      },
      error: (err) => {
        new CustomNotification(this._srvNotification).ShowError(err.Message);
      }
    });
  }

  // Franchisee Request Details View
  btnview(event: franchiseeRequests) {
    this._srvRequest.listPageSize = this.pageSize;
    this._srvRequest.listPageSkip = this.skip;
    if (event.Status.toUpperCase() === 'PENDING') this._srvRequest.request.next({ Mode: 'franchisee-detail', data: event });
    else if (event.Status.toUpperCase() === 'PAID REQUEST' || event.Status.toUpperCase() === 'REJECTED(PAYMENT)') this._srvRequest.request.next({ Mode: 'franchisee-payment-details', data: event });
    else if (event.Status.toUpperCase() === 'REJECTED') this._srvRequest.request.next({ Mode: 'reject-view', data: event });
    else if (event.Status.toUpperCase() === 'APPROVED') this._srvRequest.request.next({ Mode: 'approval', data: event });
  }
  // Pagenation
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
  }
}
