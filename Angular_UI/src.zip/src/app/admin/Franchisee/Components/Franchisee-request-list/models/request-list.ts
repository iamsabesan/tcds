export class RequestList {
  Mode =
    'list' ||
    'franchisee-detail' ||
    'franchisee-payment-details' ||
    'reject-view' || 'approval';

  data?: franchiseeRequests;
}

// #region Inactive Franchise
/* Franchisee List */
export class franchiseeRequests {
  AlternatePhone: string = '';
  PackageLogID: string = '';
  FranchiseeName: string = '';
  FranchiseeEnquiryID: string = '';
  FranchiseeRequestID: string = '';
  BranchRequestID: string = '';
  ContactID: string = '';
  ContactName: string = '';
  FeesDetails: feesDataType[] = [];
  FranchiseeID: string = '';
  Gender: string = '';
  Phone: string = '';
  Reason: string = '';
  RequestDate: Date = new Date();
  Status: string = '';
  StatusDate: Date = new Date();
  Email: string = '';
  Address: inactiveAddress[] = [];
  FranchiseeImgs: imageType[] = [];
  PaymentDetails: paymentList[] = [];

}
// Franchisee Address
export class inactiveAddress {
  AddTypeID: string = '';
  AddressTypeID?: string = '';
  Address1: string = '';
  Address2: string = '';
  AddressType: string = '';
  Area: string = '';
  Taluk: string = '';
  Country: string = '';
  District: string = '';
  Latitude: any;
  Longitude: any;
  ShortName: string = '';
  Pincode: number = 0;
  State: string = '';
}

// Franchisee Image
export class imageType {
  ContentUrl: any;
  DocumentName: any;
  DocumentType: any;
  FileName: any;
  TenantBranchID: any;
  TransactionDate?: Date = new Date();
}

// Franchisee Payment Paid
export class paymentList {
  Amount: number = 0;
  Summary: string = '';
  TenantBranchID: any;
  TransactionDate: Date = new Date();
}

// Franchisee Approval Fees Data
export class feesDataType {
  ActualFees: number = 0;
  Duration: string = '';
  NewFees: number = 0;
  PackageID: any;
  TenantBranchID: any;
}

// Franchisee Reject Reason
export class rejectReason {
  reject: string = '';
}
// Paid Franchisee Active
export class franchiseeActivateDataType {
  franchiseeRequestID: string = '';
}

// Franchisee Approval
export class approvalFreesDataType {
  FranchiseeRequestID: string = '';
  packageItems: approvalFees[] = [];
};

// Franchisee Request Approval
export class approvalFees {
  packageID: string = '';
  newFees: number = 0;
};

// Franchisee Request Reject
export class rejectReasonType {
  franchiseeRequestID: any;
  reason: any;
}

// Franchisee Payment Paid Request Reject
export class fransPaymentRej {
  franchiseeRequestID: string = '';
  packageLogID: string = '';
  reason: string = '';
}
