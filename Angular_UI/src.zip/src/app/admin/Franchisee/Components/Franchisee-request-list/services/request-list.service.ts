import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { RequestList, fransPaymentRej, rejectReasonType } from '../models/request-list';

@Injectable({
  providedIn: 'root'
})
export class RequestListService {

  public request = new BehaviorSubject<RequestList>({ Mode: 'list' });
  public listPageSize: any;
  public listPageSkip: any;
  constructor(public http: HttpService) { }

  // Franchisee Request List
  getInactiveList() {
    return this.http.get('/icloud-franchisee/v1/franchisee/list/inactive', { RequestType: IRequestType.Protected })
  }

  // Franchisee Request Approval
  postApprovalFees(data: any) {
    return this.http.post('/icloud-franchisee/v1/subscription/update/franchiseefees', data, { RequestType: IRequestType.Protected })
  }

  // Franchisee Activate
  postFranchiseeActivate(data: any) {
    return this.http.post('/icloud-franchisee/v1/franchisee/activate', data, { RequestType: IRequestType.Protected })
  }

  // Franchisee Request Reject
  postRejectReason(data: rejectReasonType) {
    return this.http.post('/icloud-franchisee/v1/franchisee/reject', data, { RequestType: IRequestType.Protected })
  }

  // Franchisee Payment Reject
  postFransPaymentReject(data: fransPaymentRej) {
    return this.http.post('/icloud-franchisee/v1/franchisee/reject/paid/request', data, { RequestType: IRequestType.Protected });
  }
}
