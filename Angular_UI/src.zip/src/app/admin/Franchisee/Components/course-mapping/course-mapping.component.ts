import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { CourseBasicData } from 'src/app/shared/model/common';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { FranchiseeServiceService } from '../../services/franchisee-service.service';
import { IWebError } from 'src/core/model';
import { ExpandedRow, courseMappingCourseDataType, courseMappingListDataType, franchiseeCourse, franchiseeCourseMapping } from '../../models/franchisee-model';

@Component({
  selector: 'app-course-mapping',
  templateUrl: './course-mapping.component.html',
  styleUrls: ['./course-mapping.component.scss']
})
export class CourseMappingComponent {

  /* List */
  public LstCourseMappingData: courseMappingListDataType[] = [];
  public LstCourseBasicData: CourseBasicData[] = [];
  public LstFilterCourseData: courseMappingCourseDataType[] = []

  /* Model */
  public MlCourseMappingDatas: courseMappingListDataType = new courseMappingListDataType();
  public MlFranchiseeCourseMappingDataType: franchiseeCourseMapping = new franchiseeCourseMapping();
  public MlFranchiseCourseDataType: franchiseeCourse = new franchiseeCourse();

  /* Grid Header Column Style */
  public gridStyle = new gridFontStyle('medium');
  public smallgridStyle = new gridFontStyle('small');

  /* Grid Filter and Expand Column*/
  public filter!: CompositeFilterDescriptor;
  public expandedDetailKeys = ExpandedRow.SubjectExpanded;

  public IsChecked: boolean = false;
  public tenantBranchID: string = '';

  /* Open the Course Mapping Dialog Box */
  public coureseDialog = false;

  constructor(public fb: FormBuilder, private _srvNotification: NotificationService, private _srvCommon: CommonService, public http: HttpClient, private _srvFranchisee: FranchiseeServiceService) { }

  ngOnInit(): void {
    this.getCourse();
    this.getCourseMappingData();
  }

  // #region Course Mapping List
  getCourseMappingData() {
    this._srvFranchisee.getCourseMapping().subscribe({
      next: (e) => {
        this.LstCourseMappingData = e.Data;
        this.LstCourseMappingData.map((e: any) => {
          e.FranchiseeName = e.FranchiseeName.toUpperCase();
          e.Address = this._srvCommon.concatAddress(e);
        })
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  // #region Course List
  getCourse() {
    this._srvCommon.getCourseBasicInfo().subscribe({
      next: (res: any) => this.LstCourseBasicData = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  // Course Mapping Edit
  edit(data: any) {
    this.coureseDialog = true;
    this.MlCourseMappingDatas = data;
    this.tenantBranchID = data.TenantBranchID;

    var coureseData1 = this.LstCourseBasicData.filter((obj: any) => {
      return !data.Courses.some((obj2: any) => {
        return obj.CourseID == obj2.CourseID;
      });
    });

    var coureseData2 = data.Courses.filter((obj: any) => {
      return !this.LstCourseBasicData.some((obj2: any) => {
        return obj.CourseID == obj2.CourseID;
      });
    });

    this.LstFilterCourseData = coureseData1.concat(coureseData2);
  }

  dialogClose() {
    this.coureseDialog = false;
    this.LstFilterCourseData.forEach((e: any) => e.IsSelected = false);
  }

  public expandDetailsBy = (dataItem: courseMappingListDataType): any => {
    return dataItem.TenantBranchID;
  };

  ngModelChange(event: boolean, index: number) {
    this.LstFilterCourseData[index].IsSelected = event == true ? true : false;
  }

  // Course Mapping Save
  submit() {
    if (this.LstFilterCourseData.filter((e: courseMappingCourseDataType) => e.IsSelected === true).length > 0) {
      this.LstFilterCourseData.filter((e: courseMappingCourseDataType) => {
        if (e.IsSelected == true) {
          this.MlFranchiseCourseDataType = new franchiseeCourse();
          this.MlFranchiseCourseDataType.courseID = e.CourseID;
          this.MlFranchiseeCourseMappingDataType.tenantBranchID = this.tenantBranchID;
          this.MlFranchiseeCourseMappingDataType.courses.push(this.MlFranchiseCourseDataType);
        }
      })

      this._srvFranchisee.postAdminCourseMapping(this.MlFranchiseeCourseMappingDataType).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.getCourse();
          this.getCourseMappingData();
          this.MlFranchiseeCourseMappingDataType = new franchiseeCourseMapping();
          this.dialogClose();
        }
      })
    }
    else this.errorMsg("Please select atleast one course");
  };

  /* SHow Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
