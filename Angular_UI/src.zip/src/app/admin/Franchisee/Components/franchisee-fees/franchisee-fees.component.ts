import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NumericTextBoxComponent } from '@progress/kendo-angular-inputs';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CustomNotification } from 'src/app/shared/model/shared';
import { adminSubscribtionPlanDataType, feesCreate, feesValueType } from '../../models/franchisee-model';
import { FranchiseeServiceService } from '../../services/franchisee-service.service';
import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'app-franchisee-fees',
  templateUrl: './franchisee-fees.component.html',
  styleUrls: ['./franchisee-fees.component.scss']
})
export class FranchiseeFeesComponent {

  @ViewChild('focus', { static: false }) focus!: NumericTextBoxComponent;

  /* List */
  public LstAdminSubscriptionPlanData: adminSubscribtionPlanDataType[] = [];

  /* Model */
  public MlFeesValue: feesCreate = new feesCreate();
  public MlNewFeesValue: feesValueType = new feesValueType();

  public LstNewFeesValue: feesValueType[] = [];
  result: any;

  /* FormGroup */
  FrmEntry = this.fb.group({
    registrationFees: [0, [Validators.required]],
    approvalFees: [0, [Validators.required]],
    oneMonth: [0, [Validators.required]],
    threeMonth: [0, [Validators.required]],
    sixMonth: [0, [Validators.required]],
    oneYear: [0, [Validators.required]],
    checkOneMonth: [],
    checkThreeMonths: [],
    checkSixMonths: [],
    checkOneyear: [],
  });

  CourierFrmEntry = this.fb.group({
    CourierCharge: [0],
    StudentIDFees: [0]
  })

  /* Numeric Textbox allow specific point */
  public setMinAmt: number = 1;
  public value: number = 0;
  public decemial: number = 0;

  public IDCardCharge: number = 0;
  public CourierCharge: number = 0;

  constructor(public fb: FormBuilder, private _srvFranchisee: FranchiseeServiceService, private _srvNotification: NotificationService, private dialogService: DialogService, private _Cd: ChangeDetectorRef, private _srvCom: CommonService) { }

  ngOnInit(): void {
    this.getAdminSubscription();
    this.getCourierCharge();
    this.getIDCardCharge();
  }

  // Get Franchisee Fees Data
  getAdminSubscription() {
    this._srvFranchisee.getAdminSubscriptionFeesList().subscribe({
      next: (e) => {
        this.LstAdminSubscriptionPlanData = e.Data;
        if (this.LstAdminSubscriptionPlanData.length !== 0) {
          this.LstAdminSubscriptionPlanData.filter((e: any) => {
            if (e.PackageName.toUpperCase() == "REGISTRATION") this.MlFeesValue.registraionFees = e;
            else if (e.PackageName.toUpperCase() == "APPROVAL") this.MlFeesValue.approvalFees = e;
            else if (e.PackageName.toUpperCase() == "SILVER") this.MlFeesValue.oneMonth = e;
            else if (e.PackageName.toUpperCase() == "GOLD") this.MlFeesValue.threeMonth = e;
            else if (e.PackageName.toUpperCase() == "DIAMOND") this.MlFeesValue.sixMonth = e
            else if (e.PackageName.toUpperCase() == "EMARALD") this.MlFeesValue.oneYear = e;
          });
          this.formGroupValueBinding(this.MlFeesValue);
        }
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    })
  }

  /* Form Group Value Binding */
  formGroupValueBinding(data: feesCreate) {
    this.FrmEntry.controls['registrationFees'].setValue(data.registraionFees.Fees);
    this.FrmEntry.controls['approvalFees'].setValue(data.approvalFees.Fees);
    this.FrmEntry.controls['oneMonth'].setValue(data.oneMonth.Fees);
    this.FrmEntry.controls['threeMonth'].setValue(data.threeMonth.Fees);
    this.FrmEntry.controls['sixMonth'].setValue(data.sixMonth.Fees);
    this.FrmEntry.controls['oneYear'].setValue(data.oneYear.Fees);
    this.FrmEntry.controls['checkOneMonth'].setValue(data.oneMonth.IsActive);
    this.FrmEntry.controls['checkThreeMonths'].setValue(data.threeMonth.IsActive);
    this.FrmEntry.controls['checkSixMonths'].setValue(data.sixMonth.IsActive);
    this.FrmEntry.controls['checkOneyear'].setValue(data.oneYear.IsActive);
    this._Cd.markForCheck();
  }

  ngAfterViewInit() {
    this.focus.focus();
  }

  // Update Franchisee Fees
  btnFrmSubmit() {
    if (this.FrmEntry.valid) {
      const FrmValue = this.FrmEntry.value;
      this.LstNewFeesValue = [];

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.registraionFees.PackageID;
      this.MlNewFeesValue.Fees = FrmValue.registrationFees ? FrmValue.registrationFees : this.MlFeesValue.registraionFees.Fees;
      this.MlNewFeesValue.IsActive = this.MlFeesValue.registraionFees.IsActive;
      this.LstNewFeesValue.push(this.MlNewFeesValue);

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.approvalFees.PackageID;
      this.MlNewFeesValue.IsActive = this.MlFeesValue.approvalFees.IsActive;
      this.MlNewFeesValue.Fees = FrmValue.approvalFees ? FrmValue.approvalFees : this.MlFeesValue.approvalFees.Fees;
      this.LstNewFeesValue.push(this.MlNewFeesValue);

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.oneMonth.PackageID;
      this.MlNewFeesValue.IsActive = FrmValue.checkOneMonth;
      this.MlNewFeesValue.Fees = FrmValue.oneMonth ? FrmValue.oneMonth : this.MlFeesValue.oneMonth.Fees;
      this.LstNewFeesValue.push(this.MlNewFeesValue);

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.threeMonth.PackageID;
      this.MlNewFeesValue.IsActive = FrmValue.checkThreeMonths;
      this.MlNewFeesValue.Fees = FrmValue.threeMonth ? FrmValue.threeMonth : this.MlFeesValue.threeMonth.Fees;
      this.LstNewFeesValue.push(this.MlNewFeesValue);

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.sixMonth.PackageID;
      this.MlNewFeesValue.IsActive = FrmValue.checkSixMonths;
      this.MlNewFeesValue.Fees = FrmValue.sixMonth ? FrmValue.sixMonth : this.MlFeesValue.sixMonth.Fees;
      this.LstNewFeesValue.push(this.MlNewFeesValue);

      this.MlNewFeesValue = new feesValueType();
      this.MlNewFeesValue.PackageID = this.MlFeesValue.oneYear.PackageID;
      this.MlNewFeesValue.IsActive = FrmValue.checkOneyear;
      this.MlNewFeesValue.Fees = FrmValue.oneYear ? FrmValue.oneYear : this.MlFeesValue.oneYear.Fees;
      this.LstNewFeesValue.push(this.MlNewFeesValue);


      const dialog: DialogRef = this.dialogService.open({
        title: 'Update',
        content: 'Do you update the renewal fees?',
        actions: [
          { text: 'No' },
          { text: 'Yes', themeColor: 'primary' }
        ],
        width: 300,
        height: 150,
      });
      dialog.result.subscribe((result) => {
        this.result = result;
        if (this.result.text == "Yes") {
          this._srvFranchisee.postUpdateFees(this.LstNewFeesValue).subscribe({
            next: (res) => {
              new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
              this.getAdminSubscription()
            },
            error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
          });
        }
      });
    }
    else this.FrmEntry.markAllAsTouched();
  }

  clickOneMonth() {
    if (this.FrmEntry.value.checkOneMonth) {
      this.FrmEntry.controls.oneMonth.setValue(this.MlFeesValue.oneMonth.Fees);
      this.FrmEntry.controls.oneMonth.disable();
    } else {
      this.FrmEntry.controls.oneMonth.enable();
    }
  }

  clickThreeMonths() {
    if (this.FrmEntry.value.checkThreeMonths) {
      this.FrmEntry.controls.threeMonth.setValue(this.MlFeesValue.threeMonth.Fees);
      this.FrmEntry.controls.threeMonth.disable();
    } else {
      this.FrmEntry.controls.threeMonth.enable();
    }

  }
  clickSixMonths() {
    if (this.FrmEntry.value.checkSixMonths) {
      this.FrmEntry.controls.sixMonth.setValue(this.MlFeesValue.sixMonth.Fees);
      this.FrmEntry.controls.sixMonth.disable();
    } else {
      this.FrmEntry.controls.sixMonth.enable();
    }
  }
  clickOneYear() {
    if (this.FrmEntry.value.checkOneyear) {
      this.FrmEntry.controls.oneYear.setValue(this.MlFeesValue.oneYear.Fees);
      this.FrmEntry.controls.oneYear.disable();
    } else {
      this.FrmEntry.controls.oneYear.enable();
    }
  }

  UpdateIndentFees() {
    const INDENTFEES = {
      "Courier": this.CourierFrmEntry.value.CourierCharge,
      "IDCard": this.CourierFrmEntry.value.StudentIDFees
    }
    if (this.CourierFrmEntry.valid) {
      this._srvFranchisee.postUpdateCourierCharge(INDENTFEES).subscribe({
        next: res => {
          this._srvCom.successMsg(res.Message);
          this.CourierCharge = this.CourierFrmEntry.value.CourierCharge;
          this.IDCardCharge = this.CourierFrmEntry.value.StudentIDFees;
        },
        error: err => this._srvCom.errorMsg(err.Message)
      });
    }
    this.CourierFrmEntry.markAllAsTouched();
  }

  getCourierCharge() {
    this._srvCom.getCourierChargeAmount().subscribe(e => {
      this.CourierCharge = e.Data;
      this.btnResetIndentFees();
    });
  }

  getIDCardCharge() {
    this._srvCom.getIDCardChargeAmount().subscribe(e => {
      this.IDCardCharge = e.Data;
      this.btnResetIndentFees()
    });
  }

  btnResetIndentFees() {
    this.CourierFrmEntry.controls.CourierCharge.setValue(this.CourierCharge)
    this.CourierFrmEntry.controls.StudentIDFees.setValue(this.IDCardCharge)
  }

  /* Fees Form Reset */
  btnResetFormFees() {
    this.formGroupValueBinding(this.MlFeesValue);
  }
}
