import { Component } from "@angular/core";
import { NotificationService } from "@progress/kendo-angular-notification";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { DateConversion, ShowInactive, gridFontStyle } from "src/app/shared/app-global";
import { CustomNotification } from "src/app/shared/model/shared";
import { FranchiseeListService } from "../../service/franchisee-list.service";
import { PageChangeEvent } from "@progress/kendo-angular-grid";
import { franchiseeActivateListDataType } from "../../model/franchisee-list";
import { LayoutComponent } from "src/app/layouts/layout.component";
import { CookieService } from "ngx-cookie-service";
import { CookieKey, CrazyKey } from "src/core/helper";
import { environment } from "src/environments/environment";

@Component({
    selector: 'list',
    templateUrl: "list.component.html",
    styleUrls: ['list.component.scss']
})
export class ListComponent {

    /* List */
    public LstFranchisee: franchiseeActivateListDataType[] = [];
    public LstStoreFranchisee: franchiseeActivateListDataType[] = [];
    public edit: string[] = ['View', "Certificate"];

    /* Grid Filter */
    public filter!: CompositeFilterDescriptor;

    /* Grid Header Column Style */
    public gridStyle = new gridFontStyle();

    /* Switch Toggle */
    public checked: boolean = true;

    public skip = 0;
    public pageSize: any = 15;
    public sizes: any[] = [15, 25, 50, 100, "All"];
    public buttonCount = 5;


    /* Telerik Report Viewer */
    public viewerContainerStyle: any;
    public ServerUrl: any;
    public opened = false;
    public Reportsource: any;
    public title: string = '';
    public bearerToken = "";

    constructor(private _srvNotification: NotificationService, private _srvFranchiseeList: FranchiseeListService, private layout: LayoutComponent, private _srvCookie: CookieService,) { }

    ngOnInit(): void {
        this.getFranchiseeActive();
        if (this._srvFranchiseeList.listPageSize) {
            this.pageSize = this._srvFranchiseeList.listPageSize;
            this.skip = this._srvFranchiseeList.listPageSkip;
        }
    }

    /* Get Franchisee Profile */
    getFranchiseeActive() {
        this.checked = ShowInactive.ShowActiveFranchisee;
        this._srvFranchiseeList.getFranchiseeActivteList().subscribe({
            next: (e) => {
                this.LstFranchisee = this.LstStoreFranchisee = e.Data;
                this.LstFranchisee.filter((e: any) => {
                    e.SubStatus = e.SubscriptionStatus == "Alert" ? "Live" : e.SubscriptionStatus;
                    e.Lock = e.Status == true ? "Active" : "Locked";
                });
                this.LstStoreFranchisee = this.LstFranchisee;
                if (ShowInactive.ShowActiveFranchisee) this.LstFranchisee = this.LstStoreFranchisee.filter((e) => e.Lock === "Active");
                else this.LstFranchisee = this.LstStoreFranchisee;
            },
            error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
    }

    rowCallback(dataItem: any): string {
        if (dataItem.dataItem.SubscriptionStatus == 'Expired') return 'expired';
        else if (dataItem.dataItem.SubscriptionStatus == 'Alert') return 'alert';
        else return 'normal';
    }

    /* View Franchisee Profile */
    view(event: string, data: franchiseeActivateListDataType) {
        if (event == 'View') {
            var tenent = data.TenantBranchID;
            const date = DateConversion.ConvertToYearMonthDate(new Date());
            this._srvFranchiseeList.getFranchiseeProfile(tenent, date, date).subscribe({
                next: (val) => {
                    this._srvFranchiseeList.franchiseeActiveListDataShare.subscribe((e: any) => {
                        e.tenent = tenent;
                        e.data = val.Data;
                        e.locked = data.Lock;
                        this._srvFranchiseeList.onMode.next({ mode: 'VIEW' });

                        this._srvFranchiseeList.listPageSize = this.pageSize;
                        this._srvFranchiseeList.listPageSkip = this.skip;
                        ShowInactive.ShowActiveFranchisee = this.checked;
                    });
                },
                error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
            });
        }
        else if (event == 'Certificate') {
            this.printCertificate(data)
        }
    }

    printCertificate(data: franchiseeActivateListDataType) {
        this.opened = true;
        this.title = 'Certificate';
        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;
        const baseURL = CrazyKey.decrypt(this.layout.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
        const parameter = {
            Authorization: this.bearerToken, Agent: window.navigator.userAgent, tenantBranchID: data.TenantBranchID, BaseUrl: baseURL
        }

        this.Reportsource = {
            report: 'iCloud/Affiliation_Certificate',
            parameters: parameter
        };
    }


    close() {
        this.opened = false;
    }

    franchiseeStatus(data: boolean) {
        ShowInactive.ShowActiveFranchisee = data;
        if (data) this.LstFranchisee = this.LstFranchisee.filter((e) => e.Lock === "Active")
        else this.LstFranchisee = this.LstStoreFranchisee;
    }

    /* Pagination Value Assign */
    pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
        this.pageSize = event.take;
    }
}