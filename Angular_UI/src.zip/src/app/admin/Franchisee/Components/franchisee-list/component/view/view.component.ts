import { Component, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { IntlService } from "@progress/kendo-angular-intl";
import { NotificationService } from "@progress/kendo-angular-notification";
import { DateConversion, DateSize, LocalString, gridFontStyle } from "src/app/shared/app-global";
import { CustomNotification } from "src/app/shared/model/shared";
import { IWebError } from "src/core/model";
import { FranchiseeListService } from "../../service/franchisee-list.service";
import { franchiseeProfileDataType } from "../../model/franchisee-list";
import { DateRanges } from "src/app/shared/model/date-ranges";

@Component({
    selector: 'view',
    templateUrl: 'view.component.html',
    styleUrls: ['view.component.scss']
})
export class ViewComponent {


    @ViewChild("form") public form?: NgForm; // daterange component value assign the form 

    /* Model */
    public MlProfileData: franchiseeProfileDataType = new franchiseeProfileDataType();

    /* Grid Header Column Style */
    public gridStyle = new gridFontStyle('medium');

    /* Date */
    public dateWholePeriod!: boolean;
    public MlDateRange: DateRanges = new DateRanges();
    public dateStyle = new DateSize();

    public dateSelected: any;
    public currencySymbol: string = '';
    public tenentID: string = '';

    /* Header Active or Locked */
    public checked: boolean = true;

    public skip = 0;
    public pageSize = 10;
    public sizes: any[] = [25, 50, 100, "All"];
    public buttonCount = 5;


    constructor(public routes: Router, public intlService: IntlService, private _srvNotification: NotificationService,
        private _srvFranchiseeList: FranchiseeListService,) { }

    ngOnInit() {
        this.getActiveFranchiseData();
        this.dateWholePeriod = true;
        this.currencySymbol = LocalString.CurrencySymbol;
    }

    // Get Franchisee View Detail
    getActiveFranchiseData() {
        this._srvFranchiseeList.franchiseeActiveListDataShare.subscribe((e: any) => {
            this.MlProfileData = e.data;
            this.MlProfileData.Status = e.data.Status == true ? 'Active' : 'Expired';
            this.tenentID = e.tenent;
            this.checked = e.locked.toLowerCase() == "locked" ? false : true;
        });
    }

    /* Active or Locked Franchisee Event */
    modeSwitcher(event: boolean) {
        this._srvFranchiseeList.franchiseeProfileActiveInactive(this.tenentID, event).subscribe({
            next: (e) => new CustomNotification(this._srvNotification).ShowSuccess(e.Message),
            error: (err: IWebError) => this.errorMsg(err.Message)
        });
    }

    /* Choose the Date */
    dateChange(event: any) {
        this.MlDateRange = event;
    }

    searchDate() {
        if (!this.MlDateRange.startDate || !this.MlDateRange.endDate) this.errorMsg("Please fill the dates");
        else {
            const fromDate = DateConversion.ConvertToYearMonthDate(this.MlDateRange.startDate);
            const toDate = DateConversion.ConvertToYearMonthDate(this.MlDateRange.endDate);

            this._srvFranchiseeList.getFranchiseeProfile(this.tenentID, fromDate, toDate).subscribe({
                next: (e) => this.MlProfileData.TotalPurchases = e.Data.TotalPurchases,
                error: (err: IWebError) => this.errorMsg(err.Message)
            });
        }
        // if (((this.MlDateRange.startDate && this.MlDateRange.endDate) != null) || ((this.form?.form.value.startDate && this.form?.form.value.endDate) != null)) {
        //     if ((this.MlDateRange.startDate && this.MlDateRange.endDate) != null) {
        //         this._srvFranchiseeList.getFranchiseeProfile(this.tenentID, fromDate, toDate).subscribe({
        //             next: (e) => {
        //                 this.MlProfileData.TotalPurchases = e.Data.TotalPurchases;
        //             },
        //             error: (err: IWebError) => this.errorMsg(err.Message)
        //         });
        //     }
        //     else {
        //         var fromDate = DateConversion.ConvertToYearMonthDate(this.form?.form.value.startDate);
        //         var toDate = DateConversion.ConvertToYearMonthDate(this.form?.form.value.endDate);
        //         this._srvFranchiseeList.getFranchiseeProfile(this.tenentID, fromDate, toDate).subscribe({
        //             next: (e) => this.MlProfileData.TotalPurchases = e.Data.TotalPurchases,
        //             error: (err: IWebError) => this.errorMsg(err.Message)
        //         });
        //     }
        // }
        // else this.errorMsg("Please fill currect date!")
    }

    goBack() {
        this._srvFranchiseeList.onMode.next({ mode: 'LIST' })
        // this.routes.navigate(['/iCloud/franchisee/franchisee-list']);
    }



    /* Show Error Msg */
    errorMsg(err: string) {
        new CustomNotification(this._srvNotification).ShowError(err)
    }
}