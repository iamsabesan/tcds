import { Component } from '@angular/core';
import { FranchiseeListService } from './service/franchisee-list.service';

@Component({
  selector: 'app-franchisee-list',
  templateUrl: './franchisee-list.component.html',
  styleUrls: ['./franchisee-list.component.scss'],
  providers: [FranchiseeListService]
})

export class FranchiseeListComponent {
  mode: string;
  constructor(public srvRenewal: FranchiseeListService) {
    srvRenewal.onMode.subscribe(res => this.mode = res.mode)
  }
}
