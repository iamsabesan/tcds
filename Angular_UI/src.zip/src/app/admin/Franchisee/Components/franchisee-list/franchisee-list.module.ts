import { NgModule } from "@angular/core";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { FranchiseeListService } from "./service/franchisee-list.service";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { FranchiseeRequestDetailsModule } from "src/app/shared/components/franchisee-request-details/franchisee-request-details.module";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IconsModule } from "@progress/kendo-angular-icons";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { FormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { FranchiseeListComponent } from "./franchisee-list.component";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";
import { DialogsModule } from "@progress/kendo-angular-dialog";
const routes: Routes = [
    {
        path: '',
        component: FranchiseeListComponent,

    }
];

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,

        /* Kendo Component */
        DateRangesModule,
        GridModule,
        ToolBarModule,
        InputsModule,
        LayoutModule,
        IconsModule,
        NavigationModule,
        ButtonsModule,
        DialogsModule,
        TelerikReportingModule,

        /* Shared Component */
        FranchiseeRequestDetailsModule,

    ],
    declarations: [
        ListComponent,
        ViewComponent,
        FranchiseeListComponent
    ],
    providers: [
        FranchiseeListService
    ],

})
export class FranchiseeListModule { }