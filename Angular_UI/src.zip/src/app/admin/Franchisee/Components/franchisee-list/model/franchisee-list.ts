
import { imageType, inactiveAddress } from "../../Franchisee-request-list/models/request-list";



export class RutMode {
    mode = 'LIST' || 'VIEW';
}

//#region Active Franchisee
// Franchisee Profile
export class franchiseeProfileDataType {
    TenantBranchID?: string = '';
    BranchRequestID: string = '';
    FranchiseeID: string = '';
    BranchName: string = '';
    ContactID: string = '';
    ContactName: string = '';
    Gender: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    ApprovalEndDate: string = '';
    ApprovalStartDate: string = '';
    SubscriptionEndDate: string = '';
    SubscriptionStartDate: string = '';
    Status: string = '';
    Address: inactiveAddress[] = [];
    FranchiseeImgs: imageType[] = [];
    TotalPurchases: totalPurchaseDataType = new totalPurchaseDataType();
    RenewalTrans: renewtransDatas[] = [];
    WalletTrans: WalletTransDataType[] = [];
}

export class totalPurchaseDataType {
    Books: number = 0;
    ExamIndent: number = 0;
    Others: number = 0;
}

export class WalletTransDataType {
    PaidDate: Date = new Date();
    Description: string = '';
    Amount: number = 0;
    Balance: number = 0;
}

export class renewtransDatas {
    Duration: string = '';
    Fees: number = 0;
    PackageID: string = '';
    PackageType: string = '';
    PaidDate: Date = new Date();
    Period: string = '';
    PackageStartDate: string = '';
    PackageEndDate: string = '';
}


// Franchisee List
export class franchiseeActivateListDataType {
    TenantBranchID: string = '';
    FranchiseeCode: string = '';
    BranchName: string = '';
    ContactName: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    ApprovalEndDate: Date = new Date();
    SubscriptionEndDate: Date = new Date();
    RegistrationDate: Date = new Date();
    SubscriptionStatus: string = '';
    Status!: boolean;
    Lock: string = '';
    SubStatus: string = '';
};

export class franchiseActiveDataShare {
    data?: franchiseeProfileDataType;
    tenent?: string = '';
    locked?: string = '';
};


