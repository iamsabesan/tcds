import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RutMode, franchiseActiveDataShare } from "../model/franchisee-list";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";

@Injectable()

export class FranchiseeListService {

    public franchiseeActiveListDataShare = new BehaviorSubject<franchiseActiveDataShare>({});

    public onMode = new BehaviorSubject<RutMode>({ mode: 'LIST' });
    public listPageSize: any;
    public listPageSkip: any;

    constructor(public http: HttpService) { }

    /* Franchisee List */
    getFranchiseeActivteList() {
        return this.http.get('/icloud-franchisee/v1/franchisee/list/active', { RequestType: IRequestType.Protected });
    }

    /* Franchisee profile */
    getFranchiseeProfile(tenantBranchID: string, fromDate: string, toDate: string) {
        return this.http.get(`/icloud-franchisee/v1/franchisee/getbyid?tenantBranchID=${tenantBranchID}&fromDate=${fromDate}&toDate=${toDate}`, { RequestType: IRequestType.Protected })
    }

    /* Franchisee Active or Franchisee Locked */
    franchiseeProfileActiveInactive(tenantBranchID: string, isActive: boolean) {
        return this.http.get(`/icloud-franchisee/v1/franchisee/lock?tenantBranchID=${tenantBranchID}&isActive=${isActive}`, { RequestType: IRequestType.Protected });
    }
}

