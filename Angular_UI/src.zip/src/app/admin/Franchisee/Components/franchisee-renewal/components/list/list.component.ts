import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { NotificationService } from "@progress/kendo-angular-notification";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { LocalString } from "src/app/shared/app-global";
import { CustomNotification } from "src/app/shared/model/shared";
import { FranchiseeRenewalService } from "../../service/franchisee-renewal.service";
import { franchiseeRenewalListDataType } from "../../model/franchisee-renewal";
import { CommonService } from "src/app/shared/service/common.service";

@Component({
    selector: 'list',
    templateUrl: './list.component.html',
    styleUrls: ['./list.component.scss']
})
export class ListComponent {

    /* List */
    public LstGridView: franchiseeRenewalListDataType[] = [];

    /* Grid Filter */
    public filter!: CompositeFilterDescriptor;

    /* Currency and Date Format */
    public currencySymbol: string = '';

    public buttonCount = 5;
    public pageSize: number = 15;
    public skip: number = 0;
    public sizes: any[] = [15, 25, 50, 100, "All"];

    constructor(public routes: Router,
        private _srvRenewal: FranchiseeRenewalService,
        private _srvNotification: NotificationService,
        private _srvCommon: CommonService) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvRenewal.getFranchiseeRenewalList().subscribe({
            next: (e) => {
                this.LstGridView = e.Data;
                this.LstGridView.filter((e: any) => {
                    e.Address = this._srvCommon.concatAddress(e)
                    // if (e.Address2 !== "" || null)
                    //     e.Address = e.Address1 + ", " + e.Address2 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
                    // else e.Address = e.Address1 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
                    e.total = e.PaymentDetails.reduce((sum: any, current: any) => sum + current.Amount, 0);
                })
            },
            error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
    }

    /* Franchisee Renewal Request Details View */
    view(data: any) {
        this._srvRenewal.renewalData = data;
        this._srvRenewal.onMode.next({ mode: 'VIEW' });
    }
}