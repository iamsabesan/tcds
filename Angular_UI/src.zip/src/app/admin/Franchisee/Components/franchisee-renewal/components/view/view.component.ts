import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { DialogService } from "@progress/kendo-angular-dialog";
import { NotificationService } from "@progress/kendo-angular-notification";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import { CustomNotification } from "src/app/shared/model/shared";
import { FranchiseeRenewalService } from "../../service/franchisee-renewal.service";
import { franchiseeRenewalListDataType, fransRenewalReject } from "../../model/franchisee-renewal";

@Component({
    selector: 'view',
    templateUrl: './view.component.html',
    styleUrls: ['./view.component.scss']
})
export class ViewComponent {

    /* Model */
    public MlGridView: franchiseeRenewalListDataType = new franchiseeRenewalListDataType();
    public MlFranchiseeDetails: franchiseeRenewalListDataType = new franchiseeRenewalListDataType();
    public MlRenewalDetails: franchiseeRenewalListDataType = new franchiseeRenewalListDataType();
    public MlFransRenewalReject = new fransRenewalReject();
    public franchiseeRenewalRequestListReject: string = '';

    public total: number = 0;
    public renewalPaymentInfo: boolean = true;

    constructor(public routes: Router, private _srvRenewal: FranchiseeRenewalService, private _srvDialog: DialogService, public _srvNotification: NotificationService) {
        this.renewalPaymentInfo = true;
    }

    ngOnInit() {
        this.MlGridView = this.MlRenewalDetails = this.MlFranchiseeDetails = this._srvRenewal.renewalData;
    }


    // Franchisee Renewal Request Reject
    reject() {
        const dialogRef = this._srvDialog.open({
            title: "Reject Renewal Request",
            content: RejectComponent,
            width: 400,
        });

        const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

        rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
            this.MlFransRenewalReject.packageLogID = this.MlGridView.PackageLogID;
            this.MlFransRenewalReject.reason = formData.Reason;

            this._srvRenewal.postFranRewalReject(this.MlFransRenewalReject).subscribe({
                next: (response) => {
                    new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
                    this.goBack();
                    dialogRef.close();
                },
                error: (error) => new CustomNotification(this._srvNotification).ShowError(error.Message),
            });
        });
    }

    // Freanchisee Renewal Request Approval
    approve() {
        this._srvRenewal.postFranchiseeRenewalRequestApproval(this.MlGridView.PackageLogID).subscribe({
            next: (e) => {
                new CustomNotification(this._srvNotification).ShowSuccess(e.Message)
                this.goBack();
            },
            error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
    }

    // Go Back List
    goBack() {
        // this.routes.navigate(['/iCloud/franchisee/renewal-request-list']);
        this._srvRenewal.onMode.next({ mode: 'LIST' })
    }
}