import { Component } from "@angular/core";
import { FranchiseeRenewalService } from "./service/franchisee-renewal.service";

@Component({
    selector: 'franchisee-renewal',
    templateUrl: './franchisee-renewal.component.html',
    providers: [FranchiseeRenewalService]
})
export class FranchiseeRenewalComponent {
    mode: string;
    constructor(public srvRenewal: FranchiseeRenewalService) {
        srvRenewal.onMode.subscribe(res => this.mode = res.mode)
    }
}