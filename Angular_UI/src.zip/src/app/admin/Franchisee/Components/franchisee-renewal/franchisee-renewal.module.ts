import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from "@angular/core";
import { FranchiseeRenewalService } from "./service/franchisee-renewal.service";
import { GridModule } from "@progress/kendo-angular-grid";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { InfoModule } from "src/app/shared/components/info/info.module";
import { FranchiseeServiceService } from "../../services/franchisee-service.service";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { FranchiseeRenewalComponent } from "./franchisee-renewal.component";
import { Routes } from "@angular/router";
import { ViewComponent } from "./components/view/view.component";
import { ListComponent } from "./components/list/list.component";
const routes: Routes = [
    {
        path: '',
        component: FranchiseeRenewalComponent,

    }
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),

        /* Kendo Component */
        ButtonsModule,
        IconsModule,
        GridModule,

        /* Shared Component */
        PaymentInfoModule,
        InfoModule,
        RejectModule
    ],
    declarations: [
        FranchiseeRenewalComponent,
        ViewComponent,
        ListComponent
    ],
    providers: [
        FranchiseeRenewalService,
        FranchiseeServiceService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FranchiseeRenewalModule { }