import { PaymentDetailViewListMl } from "src/app/shared/model/common";

export class RutMode {
    mode = 'LIST' || 'VIEW';
}
//   Franchisee Renewal List
export class franchiseeRenewalListDataType {
    RequestDate: Date = new Date();
    TenantBranchID: string = '';
    FranchiseeCode: string = '';
    FranchiseeName: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    Address: string = '';
    Address1: string = '';
    Address2: string = '';
    Country: string = '';
    State: string = '';
    District: string = '';
    Area: string = '';
    Pincode: string = '';
    PackageLogID: string = '';
    PackageType: string = '';
    PackageName: string = '';
    Duration: string = '';
    Amount: number = 0;
    total!: number;
    SubscriptionPeroid: string = '';
    PaymentDetails: PaymentDetailViewListMl[] = []
}

// Franchisee Renewal View
export class franchiseeRenewalShareDataType {
    data?: franchiseeRenewalListDataType;
}

// Franchisee Renewal Reject
export class fransRenewalReject {
    packageLogID = '';
    reason = '';
}