import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RutMode, franchiseeRenewalListDataType, franchiseeRenewalShareDataType, fransRenewalReject } from "../model/franchisee-renewal";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";

@Injectable({
    providedIn: 'root'
})
export class FranchiseeRenewalService {

    onMode = new BehaviorSubject<RutMode>({ mode: 'LIST' });
    public renewalShareData = new BehaviorSubject<franchiseeRenewalShareDataType>({});
    public renewalData: franchiseeRenewalListDataType = new franchiseeRenewalListDataType();

    constructor(public http: HttpService) { }

    /* Franchisee Renewal List */
    getFranchiseeRenewalList() {
        return this.http.get('/icloud-franchisee/v1/franchisee/renewal/list', { RequestType: IRequestType.Protected });
    }

    /* Franchisee Renewal Approval */
    postFranchiseeRenewalRequestApproval(packageLogID: string) {
        return this.http.post(`/icloud-franchisee/v1/franchisee/renewal/approve?packageLogID=${packageLogID}`, { RequestType: IRequestType.Protected });
    }
    /* Franchisee Renewal Reject */
    postFranRewalReject(data: fransRenewalReject) {
        return this.http.post('/icloud-franchisee/v1/franchisee/renewal/reject', data, { RequestType: IRequestType.Protected });
    }
}
