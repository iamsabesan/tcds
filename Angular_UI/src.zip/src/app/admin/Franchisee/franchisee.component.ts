import { Component } from '@angular/core';
import { FranchiseeServiceService } from './services/franchisee-service.service';

@Component({
  selector: 'app-franchisee',
  templateUrl: './franchisee.component.html',
  styleUrls: ["./franchisee.component.scss"],
  providers: [FranchiseeServiceService]
})
export class FrachiseeComponent {
  constructor() { }
}