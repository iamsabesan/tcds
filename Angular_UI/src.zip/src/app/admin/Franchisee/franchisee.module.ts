import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DialogService, DialogsModule } from '@progress/kendo-angular-dialog';
import { FrachiseeComponent } from './franchisee.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { GridModule } from '@progress/kendo-angular-grid';
import { IconsModule } from '@progress/kendo-angular-icons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NotificationModule, NotificationService } from '@progress/kendo-angular-notification';
import { FranchiseeServiceService } from './services/franchisee-service.service';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { FranchiseeFeesComponent } from './Components/franchisee-fees/franchisee-fees.component';
import { RequestListService } from './Components/Franchisee-request-list/services/request-list.service';
import { CourseMappingComponent } from './Components/course-mapping/course-mapping.component';

const routes: Routes = [
  {
    path: '',
    component: FrachiseeComponent,
    children: [
      {
        path: 'franchisee-list',
        loadChildren: () => import('./Components/franchisee-list/franchisee-list.module').then(m => m.FranchiseeListModule)

      },
      {
        path: 'fees-and-charges',
        component: FranchiseeFeesComponent,
      },
      {
        path: 'renewal-request-list',
        loadChildren: () => import('./Components/franchisee-renewal/franchisee-renewal.module').then(m => m.FranchiseeRenewalModule)

      },
      {
        path: 'franchisee-request-list',
        loadChildren: () => import('./Components/Franchisee-request-list/Franchisee-request-list.module').then(m => m.FrachiseeRequestListModule)
      },
      {
        path: 'course-mapping',
        component: CourseMappingComponent,
      },
    ]
  }
];

@NgModule({
  declarations: [
    FrachiseeComponent,
    FranchiseeFeesComponent,
    CourseMappingComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,

    /* Kendo Component */
    ButtonsModule,
    LayoutModule,
    IconsModule,
    DialogsModule,
    LabelModule,
    NotificationModule,
    InputsModule,
    GridModule,

  ],
  providers: [FranchiseeServiceService, NotificationService, DialogService, RequestListService],
})
export class FrachiseeModule { }
