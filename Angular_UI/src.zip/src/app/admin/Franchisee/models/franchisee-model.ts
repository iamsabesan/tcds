
export class FranchiseeModel {
   mode = 'franchisee-detail' || 'payment-details';
}

// #region Renewal Fees
/* Updated Code 06-05-2024 */
/* Franchisee Renewal Fees */
export class adminSubscribtionPlanDataType {
   PackageID: string = '';
   PackageName: string = '';
   Fees: number = 0;
   IsActive: boolean;
}

/* Admin Renewal Fees Form */
export class feesCreate {
   registraionFees: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
   approvalFees: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
   oneMonth: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
   threeMonth: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
   sixMonth: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
   oneYear: adminSubscribtionPlanDataType = new adminSubscribtionPlanDataType();
}

/* Updated the Renewal Fees */
// export class feesValueType {
//    registrationFees: number = 0;
//    oneMonthFees: number = 0;
//    approvalFees: number = 0
//    threeMonthFees: number = 0
//    sixMonthFees: number = 0
//    oneYearFees: number = 0
// }

export class feesValueType {
   PackageID: string = '';
   Fees: number = 0;
   IsActive: boolean;
}
//#endregion

//#region Course Mapping
/* Udpated Code 06-05-2024 */

// Franchisee Coursing Mapping List
export class courseMappingListDataType {
   TenantBranchID: string = '';
   FranchiseeID: string = '';
   FranchiseeName: string = '';
   Address1: string = '';
   Address2: string = '';
   Area: string = '';
   District: string = '';
   State: string = '';
   Country: string = '';
   Pincode: string = '';
   Courses: courseMappingCourseDataType[] = [];
   Address?: string = '';
}
// Mapping courses
export class courseMappingCourseDataType {
   IsSelected?: boolean = false;
   TenantBranchID?: string = '';
   CourseID: string = '';
   CourseName: string = '';
   CourseType: string = '';
   Duration: string = '';
   Semester: number = 0;
}

/* Updated the Franchisee Course Mapping */
export class franchiseeCourseMapping {
   tenantBranchID: string = '';
   courses: franchiseeCourse[] = []
}

export class franchiseeCourse {
   courseID: string = '';
}

export class ExpandedRow {
   static SubjectExpanded: string[] = [];
}
//#endregion


export class CourierAndIDCardChargeUpdateMl {
   amount: number = 0;
}