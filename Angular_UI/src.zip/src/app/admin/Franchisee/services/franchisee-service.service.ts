import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { feesValueType, FranchiseeModel } from '../models/franchisee-model';
import { Fees } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class FranchiseeServiceService {

  public request = new BehaviorSubject<FranchiseeModel>({ mode: 'request' });

  constructor(public http: HttpService) { }

  // #region Franchisee Course Mapping
  // List
  getCourseMapping() {
    return this.http.get('/icloud-academic/v1/course/mapping/list', { RequestType: IRequestType.Protected })
  }

  //Course Mapping 
  postAdminCourseMapping(data: any) {
    return this.http.post('/icloud-academic/v1/course/mapping', data, { RequestType: IRequestType.Protected });
  }

  // #region Franchise Fees
  getAdminSubscriptionFeesList() {
    return this.http.get('/icloud-franchisee/v1/subscription/list', { RequestType: IRequestType.Protected });
  }

  // Update the Fees
  postUpdateFees(data: feesValueType[]) {
    return this.http.post<feesValueType[]>('/icloud-franchisee/v1/subscription/update/subscriptionfees', data, { RequestType: IRequestType.Protected })
  }

  /* Update Indent Fees Amount (Courier & ID Card Fees) */
  postUpdateCourierCharge(data: any) {
    // const CourierFees = new CourierAndIDCardChargeUpdateMl();
    // CourierFees.amount = data;
    return this.http.post(Fees.postIndentFeesUpdate, data, { RequestType: IRequestType.Protected });
  }

  // postUpdateIDCardCharge(data: number) {
  //   // const IDFees = new CourierAndIDCardChargeUpdateMl();
  //   // IDFees.amount = data;
  //   return this.http.post(Fees.postIDCardCharegeUpdate + data, { RequestType: IRequestType.Protected });
  // }

} 
