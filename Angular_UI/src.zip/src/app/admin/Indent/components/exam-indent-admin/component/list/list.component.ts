import { Component } from "@angular/core";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import { CustomNotification } from "src/app/shared/model/shared";
import { ExamIndentAdminService } from "../../service/exam-indent-admin.service";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { DialogRef, DialogService } from "@progress/kendo-angular-dialog";
import { NotificationService } from "@progress/kendo-angular-notification";
import { PagerPosition } from "@progress/kendo-angular-grid";
import { adminExamIndentListDataType, examIndentReject } from "../../model/exam-indent-admin";
import { CommonService } from "src/app/shared/service/common.service";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html',
    styleUrls: ['list.component.scss']
})
export class ListComponent {
    public LstExamIndent: adminExamIndentListDataType[] = [];
    public MlAdminExamIndentRejectData: examIndentReject = new examIndentReject()

    public Option: any[] | undefined;
    public currencySymbol = '';
    public gridStyle = new gridFontStyle();

    /* Grid Pagination */
    public buttonCount: number = 5;
    public sizes: any[] = [25, 50, 100, "All"];
    public info: boolean = true;
    public previousNext: boolean = true;
    public position: PagerPosition = "bottom";

    result: any;

    constructor(public _srvExamIndent: ExamIndentAdminService,
        public dialogservice: DialogService,
        public notificationService: NotificationService,
        private _srvCommon: CommonService) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this.Option = ['View', 'Reject'];
        if (this._srvExamIndent.isOldRecord) this.LstExamIndent = this._srvExamIndent.LstExamIndent;
        else this.getExamInednt();
        this._srvExamIndent.isOldRecord = false;
    }
    // exam indent list
    getExamInednt() {
        this._srvExamIndent.getAdminExamIndentList().subscribe({
            next: (res) => {
                this.LstExamIndent = res.Data;
                if (this.LstExamIndent.length) {
                    this.LstExamIndent.filter((e: any) => {

                        // e.FranchiseeName = "TCDS COMPUTER EDUCATION";
                        e.BranchDetail.Address = this._srvCommon.concatAddress(e.BranchDetail);
                        e.editOptions = [
                            { text: "Approve", disabled: e.ExamIndentDetail.Status == 'PENDING' ? false : true },
                            { text: "View", disabled: false },
                            { text: "Reject", disabled: e.ExamIndentDetail.Status == 'PENDING' ? false : true }
                        ];
                        e.ExamIndentDetail.TotalAmount = e.ExamIndentDetail.TotalAmount + e.ExamIndentDetail.CourierAmount
                    })
                }
            },
            error: (err) => {
                new CustomNotification(this.notificationService).ShowError(err.Message);

            }
        })
    }
    // View exam indent and go on view exam indent component
    View(event: any, data: any) {
        if (event.text == 'View') {
            this._srvExamIndent.adminExamIndentData = data;
            this._srvExamIndent.onMode.next({ mode: 'VIEW' });
            this._srvExamIndent.LstExamIndent = this.LstExamIndent;
        }
        else if ((event.text == 'Approve') && !event.disabled) {
            const dialog: DialogRef = this.dialogservice.open({
                title: 'Approve',
                content: `Are you approve the exam indent with ID ${data.ExamIndentDetail.IndentNumber}?`,
                actions: [
                    { text: 'No', themeColor: 'error' },
                    { text: 'Yes', themeColor: 'success' }
                ],
                width: 380,
                height: 170,
                cssClass: 'Approval-css'

            });
            dialog.result.subscribe((result) => {
                this.result = result;
                if (this.result.text == "Yes") {

                    this._srvExamIndent.getExamIndentApproval(data.ExamIndentDetail.ExamIndentID).subscribe({
                        next: (res) => {
                            new CustomNotification(this.notificationService).ShowSuccess(res.Message);
                            this.getExamInednt()
                        },
                        error: (err) => new CustomNotification(this.notificationService).ShowError(err.Message)
                    });
                }
            });
        }
        else if ((event.text == 'Reject') && !event.disabled) {
            const dialogRef = this.dialogservice.open({
                title: "Exam Indent Reject",
                content: RejectComponent,
                width: 400
            });

            // dialogRef.result.subscribe(() => {
            //   this.getExamInednt();
            // });
            // const dialog = dialogRef.content.instance;
            // dialog.examIndentReportReject = data.ExamIndentDetail.ExamIndentID;
            // dialog.showSuccessMsg = 'Exam Indent Rejected';

            const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

            rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
                this.MlAdminExamIndentRejectData.examIndentID = data.ExamIndentDetail.ExamIndentID;
                this.MlAdminExamIndentRejectData.reason = formData.Reason;

                this._srvExamIndent.postExamIndentReportReject(this.MlAdminExamIndentRejectData).subscribe({
                    next: (response) => {
                        new CustomNotification(this.notificationService).ShowSuccess(response.Message);
                        this.getExamInednt();
                        dialogRef.close();
                    },
                    error: (error) => new CustomNotification(this.notificationService).ShowError(error.Message),
                });
            });
        }
    }
}