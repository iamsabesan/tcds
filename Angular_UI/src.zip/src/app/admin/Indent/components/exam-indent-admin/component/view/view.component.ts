import { Component } from "@angular/core";
import { ExamIndentTransDetailsDataType, adminExamIndentActivateDataType, adminExamIndentListDataType, examIndentDataType, studentInfo } from "../../model/exam-indent-admin";
import { PaymentDetailViewListMl } from "src/app/shared/model/common";
import { AggregateDescriptor, AggregateResult, CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { ExamIndentAdminService } from "../../service/exam-indent-admin.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { IntlService } from "@progress/kendo-angular-intl";
import { CustomNotification } from "src/app/shared/model/shared";
import { CommonService } from "src/app/shared/service/common.service";

@Component({
  selector: 'view',
  templateUrl: 'view.component.html'
})
export class ViewComponent {

  /* List */
  public gridData: ExamIndentTransDetailsDataType[] = [];
  public PaymentInfo: PaymentDetailViewListMl[] = [];
  public MlstudentDetails: studentInfo[] = [];

  /* Model */
  public activateList: adminExamIndentActivateDataType = new adminExamIndentActivateDataType();
  public activateIDData: examIndentDataType = new examIndentDataType();
  public examIntentData: adminExamIndentListDataType = new adminExamIndentListDataType();
  public franchiseeDetails: adminExamIndentListDataType = new adminExamIndentListDataType();

  /* Grid Filter */
  public aggregates!: AggregateDescriptor[];
  public total!: AggregateResult;
  public filter!: CompositeFilterDescriptor;

  public showFranchiseeDetails: boolean = true;
  public showfranchisee: boolean = true;

  /* Grid Footer Sum Value */
  public totalFees: number = 0;
  public totalValue: number = 0;
  public totals: number = 0;

  /* CurrencySymbol Format */
  public currencySymbol: string = '';

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();

  /* Activate Button Show or Not */
  public IsApproved: boolean = false;
  public ExamIndentStatus: string = '';

  public checkBox: any;

  public pageSize: number = 10;
  public skip: number = 0;

  constructor(private _srvExamIndent: ExamIndentAdminService, private _srvNotification: NotificationService, public intlService: IntlService, private _srvCom: CommonService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.examIntentData = this.franchiseeDetails = this._srvExamIndent.adminExamIndentData;
    this._srvExamIndent.getExamIndentViewDetails(this.examIntentData.ExamIndentDetail.ExamIndentID).subscribe({
      next: val => {
        this.examIntentData.ExamIndentTransDetails = val.Data.ExamIndentTransDetails
        this.examIntentData.PaymentDetails = val.Data.PaymentDetails;

        this.gridData = this.examIntentData.ExamIndentTransDetails;
        this.PaymentInfo = this.examIntentData.PaymentDetails;

        if (this._srvExamIndent.adminExamIndentData.ExamIndentDetail.Status != "PENDING") this.ExamIndentStatus = this._srvExamIndent.adminExamIndentData.ExamIndentDetail.Status;

        this.IsApproved = this.examIntentData.ExamIndentTransDetails.every((e: any) => e.Status.toLowerCase() == 'approved');
        this.totalValue = this.PaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
        this.totals = this.gridData.reduce((sum: any, current: any) => sum + current.ExamFees, 0);
        this.totalValue = this.PaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
        this.gridData.forEach((E: ExamIndentTransDetailsDataType) => E.isDisabled = false);
      }, error: err => this._srvCom.errorMsg(err.Message)
    })
  }

  /* Checked the checkbox */
  toggle(event: any, index: number): void {
    this.gridData[index].isDisabled = event.target.checked;
  }

  activateIndent() {
    this.gridData.filter((e: any) => {
      if (e.isDisabled) {
        this.activateIDData = new examIndentDataType();
        this.activateIDData.examIndentTransID = e.ExamIndentTransID
        this.activateList.examIndent.push(this.activateIDData)
      }
    });
    const isChecked = this.gridData.every((e) => e.isDisabled == false);

    if (isChecked) new CustomNotification(this._srvNotification).ShowError("Please select atleast one record");
    else {
      this._srvExamIndent.postExamIndentActivate(this.activateList).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.goBack(false);
        },
        error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
      });
    }
  }

  goBack(data: boolean) {
    this._srvExamIndent.isOldRecord = data;
    this._srvExamIndent.onMode.next({ mode: 'LIST' })
  }


}