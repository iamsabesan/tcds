import { Component } from "@angular/core";
import { ExamIndentAdminService } from "./service/exam-indent-admin.service";

@Component({
    selector:'exam-indent-admin',
    templateUrl:'exam-indent-admin.component.html',
    providers:[ExamIndentAdminService]
})
export class ExamIndentAdminComponent{
    
    mode: string;
    constructor(public _srvMatIndentAdmin: ExamIndentAdminService) {
        _srvMatIndentAdmin.onMode.subscribe(res => this.mode = res.mode)
    }
}