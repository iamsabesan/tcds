import { NgModule } from "@angular/core";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { ExamIndentAdminComponent } from "./exam-indent-admin.component";
import { ExamIndentAdminService } from "./service/exam-indent-admin.service";
import { RouterModule, Routes } from "@angular/router";
import { GridModule } from "@progress/kendo-angular-grid";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { InfoModule } from "src/app/shared/components/info/info.module";

const routes: Routes = [
    {
        path: '',
        component: ExamIndentAdminComponent,

    }
];
@NgModule({
    imports: [

        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),

        /* Kendo Component */
        ButtonsModule,
        IconsModule,
        GridModule,
        NavigationModule,
        InputsModule,
        LabelModule,
        DialogsModule,

        /* Shared Compoennt */
        PaymentInfoModule,
        InfoModule,
        RejectModule,
    ],
    declarations: [
        ListComponent,
        ViewComponent,
        ExamIndentAdminComponent
    ],
    providers: [ExamIndentAdminService]
})
export class ExamIndentAdminModule { }