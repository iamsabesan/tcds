import { basicAddressDataType, PaymentDetailViewListMl, } from "src/app/shared/model/common";

export class RutMode {
    mode = 'LIST' || 'VIEW';
}


//#region Exam Indent
// List
export class adminExamIndentListDataType {
    FranchiseeCode: string = '';
    FranchiseeName?: string = "";
    BranchDetail: basicAddressDataType = new basicAddressDataType();
    ExamIndentDetail: ExamIndentDetailDataType = new ExamIndentDetailDataType();
    ExamIndentTransDetails: ExamIndentTransDetailsDataType[] = [];
    PaymentDetails: PaymentDetailViewListMl[] = [];
    editOptions = [];
}

export class ExamIndentDetailDataType {
    IsRejected?: boolean;
    Reason?: string;
    ExamIndentID: string = '';
    TenantBranchID: string = '';
    IndentDate: string = '';
    IndentNumber: string = '';
    TotalAmount: number = 0;
    TotalItem: number = 0;
    ActiveItem: number = 0;
    InactiveItem: number = 0;
    Status = '';
    CourierAmount: number = 0;
}

export class ExamIndentTransDetailsDataType {
    isDisabled?: boolean;
    StudentID: string = '';
    StudentName: string = '';
    Course: string = '';
    ExamIndentID: string = '';
    StudentBatchMapping: string = '';
    Semester: number = 0;
    ExamFees: number = 0;
    Status: string = '';
    AcivateDate: string = '';
    startTime?: Date = new Date();
    endTime?: Date = new Date();
}

// Indent Reject
export class examIndentReject {
    examIndentID: string = '';
    reason: string = '';
}

// View
export class adminExamIndentActivateDataType {
    examIndent: examIndentDataType[] = [];
}
export class examIndentDataType {
    examIndentTransID: string = '';
}

// Student Data
export class studentInfo {
    studentID: number = 0;
    studentName: string = '';
    course: string = '';
    semester: number = 0;
    examFees: number = 0;
    status: string = '';
}