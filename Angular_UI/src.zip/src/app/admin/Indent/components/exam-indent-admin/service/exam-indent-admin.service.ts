import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RutMode, adminExamIndentListDataType, examIndentReject } from "../model/exam-indent-admin";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";

@Injectable()
export class ExamIndentAdminService {
    onMode = new BehaviorSubject<RutMode>({ mode: 'LIST' });
    public adminExamIndentData: adminExamIndentListDataType = new adminExamIndentListDataType();

    public LstExamIndent: any[] = [];
    public isOldRecord: boolean = false;

    constructor(public http: HttpService) { }

    /* Exam Indent List */
    getAdminExamIndentList() {
        return this.http.get("/icloud-inventory/v1/indent/exam/list", { RequestType: IRequestType.Protected })
    }

    /* Exam Indent Reject */
    postExamIndentReportReject(data: examIndentReject) {
        return this.http.post('/icloud-inventory/v1/indent/exam/reject', data, { RequestType: IRequestType.Protected })
    }

    /* Exam Indent Activate */
    postExamIndentActivate(data: any) {
        return this.http.post("/icloud-inventory/v1/indent/exam/activate", data, { RequestType: IRequestType.Protected })
    }

    getExamIndentApproval(data: string) {
        return this.http.get(`/icloud-inventory/v1/indent/exam-indent/approved?examIndentID=${data}`, { RequestType: IRequestType.Protected })
    }

    getExamIndentViewDetails(ID: string) {
        return this.http.get(`/icloud-inventory/v1/indent/exam/details?examIndentID=` + ID, { RequestType: IRequestType.Protected })
    }

}