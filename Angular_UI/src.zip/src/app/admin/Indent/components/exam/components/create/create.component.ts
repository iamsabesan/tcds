import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { IntlService } from '@progress/kendo-angular-intl';
import { StepperActivateEvent, StepperComponent } from '@progress/kendo-angular-layout';
import { NotificationService } from '@progress/kendo-angular-notification';
import { AggregateDescriptor, AggregateResult, State, aggregateBy } from '@progress/kendo-data-query';
import { DateConversion, DropDownFilter, LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { BatchColumn, BatchMapping, CourseColumn, CourseInfoListByFranchisee, CreateExamIndent, StudentExamIndent } from '../../model/exam';
import { CourseBasicData, MultiDropdownColumn, StudentListCourseBatchID, batchByIDDataType, CourseTypeListMl } from 'src/app/shared/model/common';
import { ExamService } from '../../service/exam.service';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { PaymentPayVal } from 'src/app/shared/model/payment';
import { IWebError } from 'src/core/model';
import { CookieService } from 'ngx-cookie-service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CookieKey } from 'src/core/helper';

@Component({
  selector: 'create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent {

  /* ViewChild */
  @ViewChild('stepper', { static: true }) public stepper!: StepperComponent;

  /* List */
  public LstStudentExamIndent: StudentExamIndent[] = [];
  public LstBatchDetail: batchByIDDataType[] = [];
  public LstStudentDetail: StudentListCourseBatchID[] = [];
  public LstStoreStudentDetail: StudentListCourseBatchID[] = [];
  public LstStudentExamIndentPayment: StudentExamIndent[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public aggregates: AggregateDescriptor[] = [];
  public LstCourseInfo: CourseInfoListByFranchisee[] = [];
  public LstCourseType: CourseTypeListMl[] = [];

  /* Model */
  public MlStudentExamIndent: StudentExamIndent = new StudentExamIndent();
  public studentBatchMapping: BatchMapping = new BatchMapping();
  public MlPayment: PaymentPayVal = new PaymentPayVal();
  public MlCreateExamIndent: CreateExamIndent = new CreateExamIndent();
  public gridStyle = new gridFontStyle('small');


  /* Multicolumn Dropdown */
  public LstCourseColumn: MultiDropdownColumn[] = CourseColumn;
  public LstBatchColumn: MultiDropdownColumn[] = BatchColumn;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.StartWithfilterSettings;

  /* Stepper */
  public isLinear: boolean = false;
  public currentStep: number = 0;

  public batchComboValue: any;
  public studentValue: any;

  /* Payment Transaction */
  public paymentamount: number = 0;
  public totalFees: number = 0;
  public total!: AggregateResult;
  public Totalamount: number = 0;
  public ErrorNotification: string = 'Please Enter Valid Total Amount';
  public ErrorNotify: string = 'Exam Fees amount must be equal with Total Amount';

  public currencySymbol: string = '';
  public dateFormat: string = '';
  public timeFormate: string = "";
  public minDate = new Date();

  public CourierChargeAmount: number = 0;
  public TotalAmount: number = 0;

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";

  public examIndentForm = this.fb.group({
    firstStep: this.fb.group({
      courseType: [],
      course: [],
      batch: [],
      studentName: [],
      examDate: []
    }),
  });

  public state: State = {
    skip: 0,
    take: 5,
    filter: {
      logic: "and",
      filters: []
    }
  };

  constructor(public currencyService: IntlService, private _srvCommon: CommonService,
    public fb: FormBuilder, private _cd: ChangeDetectorRef, private _srvExam: ExamService,
    private _srvNotification: NotificationService, private _srvCookie: CookieService, private layout: LayoutComponent,) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    // this.getCourse();

    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

    this._srvCommon.getCourierChargeAmount().subscribe({ next: res => this.CourierChargeAmount = res.Data });

  }

  /* Get Course Detail */
  getCourse() {
    this._srvExam.getCourseInfoListByFranchisee().subscribe({
      next: (e) => this.LstCourseInfo = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Get Batch Detail With Using CourseID */
  getBatch(event: CourseBasicData) {
    this.LstBatchDetail = this.LstStudentDetail = [];
    this.batchComboValue = this.studentValue = undefined;
    this.examIndentForm.controls['firstStep'].controls['batch'].setValue(null);
    this.examIndentForm.controls['firstStep'].controls['studentName'].setValue(null);
    if (event) {
      var CourseID = event.CourseID;

      this._srvCommon.getActiveBatchCourseID(CourseID).subscribe({
        next: (e) => this.LstBatchDetail = e.Data,
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Get Student Detail With Using BatchID */
  getStudentDetail(event: any) {
    this.LstStudentDetail = [];
    this.batchComboValue = this.studentValue = undefined;
    this.examIndentForm.controls['firstStep'].controls['studentName'].setValue(null);

    if (event) {
      this.batchComboValue = event.CourseBatchID;
      this._srvCommon.getStudentListCourseBatchId(this.batchComboValue).subscribe({
        next: (e) => {
          this.LstStudentDetail = this.LstStoreStudentDetail = e.Data;
          if (this.LstStudentDetail.length !== 0) this.LstStudentDetail = this.compareTwoArray(this.LstStudentDetail, this.LstStudentExamIndent);
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
  }

  StudentValue(event: any) {
    if (event) this.studentValue = event;
    else this.studentValue = undefined;
  }

  /* Add Exam Indent in List */
  addStudent(data: any) {
    if (this.examIndentForm.status == 'INVALID') this.examIndentForm.markAllAsTouched();
    else {
      this.MlStudentExamIndent.course = data.firstStep.course.Course;
      this.MlStudentExamIndent.examFees = data.firstStep.course.ExamFees;
      this.MlStudentExamIndent.batch = data.firstStep.batch.Timing;
      this.MlStudentExamIndent.examDate = data.firstStep.examDate;

      data.firstStep.studentName.filter((e: any) => {

        const studentGrid: StudentExamIndent = new StudentExamIndent();
        studentGrid.BatchMappingID = e.BatchMappingID;
        studentGrid.studentID = e.RollNumber;
        studentGrid.studentName = e.ContactName;
        studentGrid.semester = e.Semester;
        studentGrid.course = this.MlStudentExamIndent.course;
        studentGrid.examFees = this.MlStudentExamIndent.examFees;
        studentGrid.batch = this.MlStudentExamIndent.batch;
        studentGrid.ShortName = data.firstStep.course.ShortName;
        studentGrid.CourseType = data.firstStep.course.CourseType;

        studentGrid.examDate = DateConversion.ConvertToDateMonthYear(data.firstStep.examDate);
        this.LstStudentExamIndent.push(studentGrid);
        this.examIndentForm.reset();
        this.LstBatchDetail = this.LstStudentDetail = [];
      });
    }
  }

  /* Step Validation */
  private getGroupAt(index: number): FormGroup {
    const groups = Object.keys(this.examIndentForm.controls).map(groupName =>
      this.examIndentForm.get(groupName)
    ) as FormGroup[];
    return groups[index];
  }

  public get currentGroup(): FormGroup {
    return this.getGroupAt(this.currentStep);
  }

  public steps = [
    {
      label: "Select Student",
    },
    {
      label: "Make Payment",
    },
  ];

  public onStepActivate(ev: StepperActivateEvent): void {
    if (!this.examIndentForm.valid) {
      ev.preventDefault();
      this.examIndentForm.markAllAsTouched();
    }
  }

  next() {
    if (this.examIndentForm.status == 'INVALID' && this.LstStudentExamIndent.length == 0) this.examIndentForm.markAllAsTouched();
    else if (this.LstStudentExamIndent.length == 0) this.errorMsg("Please add details");

    else if (this.LstStudentExamIndent.length > 0 && this.currentStep !== this.steps.length) {
      this.LstStudentExamIndentPayment = this.LstStudentExamIndent;
      this.aggregates = [{ field: "examFees", aggregate: "sum" }];
      this.total = aggregateBy(this.LstStudentExamIndentPayment, this.aggregates);
      this.totalFees = this.LstStudentExamIndentPayment.reduce((sum: any, current: any) => sum + current.examFees, 0);
      this.TotalAmount = this.totalFees + this.CourierChargeAmount;
      this.paymentamount = this.TotalAmount;
      this.currentStep += 1;
      return;
    }

    this.stepper.validateSteps();
    this._cd.markForCheck();
  }

  /* Exam total payment value */
  totalAmount(total: number): void {
    this.Totalamount = total;
  }

  /* Go back on the Exam Indent List Component */
  goBack() {
    this._srvExam.action.next({ Mode: 'LIST' });
    this._srvExam.examIndentDateRange = true;
  }

  prev(): void {
    this.currentStep -= 1;
    this._cd.markForCheck();
  }

  /* Delete the Record in Exam Indent List */
  deleteRow(row: number) {
    this.LstStudentExamIndent.splice(row, 1);
    this.LstStudentDetail = this.compareTwoArray(this.LstStoreStudentDetail, this.LstStudentExamIndent);
  }

  /* Delete the Record in Exam Indent List */
  rowDelete(row: number, data: any) {
    this.LstStudentExamIndentPayment.splice(row, 1);
    this.LstStudentDetail = this.compareTwoArray(this.LstStoreStudentDetail, this.LstStudentExamIndent);
    this.totalFees = this.totalFees - data.examFees;
    this.TotalAmount = this.totalFees + this.CourierChargeAmount;
    this.paymentamount = this.TotalAmount;
    if (this.LstStudentExamIndentPayment.length == 0) this.PaymentDetails = [];
  }

  /* Compare Two Array Value (Student Detail & LstExamIndent) */
  compareTwoArray(array1: any, array2: any) {
    return array1.filter((object1: any) => {
      return !array2.some((object2: any) => {
        return object1.RollNumber === object2.studentID && object1.BatchMappingID == object2.BatchMappingID;
      });
    });
  }

  /* Create Exam Indent */
  submit() {
    const LstStudentExamIdnent = [], LstPayment = [];
    this.MlCreateExamIndent.batchMapping = this.MlCreateExamIndent.paymentItems = [];
    if (this.LstStudentExamIndentPayment.length == 0) this.errorMsg("Please add detail");
    else if (this.PaymentDetails.length == 0) this.errorMsg("Please add payment");
    else if (this.Totalamount < this.paymentamount) this.errorMsg("Please pay full amount");
    else if (this.Totalamount > this.paymentamount) this.errorMsg("Please pay currect amount");

    else if (this.Totalamount == this.paymentamount) {
      this.LstStudentExamIndentPayment.filter((e: any) => {
        this.studentBatchMapping = new BatchMapping();
        this.studentBatchMapping.batchMappingID = e.BatchMappingID;
        const EXAMDATE = DateConversion.ConvertStringToDate(e.examDate);
        this.studentBatchMapping.examDate = DateConversion.ConvertMonthDateYear(EXAMDATE);
        this.studentBatchMapping.examFees = e.examFees;
        this.studentBatchMapping.semester = e.semester;
        LstStudentExamIdnent.push(this.studentBatchMapping);
      });
      this.MlCreateExamIndent.batchMapping = LstStudentExamIdnent;

      this.PaymentDetails.filter((e: any) => {

        this.MlPayment = new PaymentPayVal();
        this.MlPayment.PaymentModeID = e.PaymentModeID;
        this.MlPayment.PayModeType = e.PayModeType;
        this.MlPayment.PayModeValue = e.PayModeValue;
        this.MlPayment.Amount = e.Amount;
        this.MlPayment.FromLedgerID = e.FromLedger.LedgerID;
        this.MlPayment.FromLedgerName = e.FromLedger.LedgerName;
        this.MlPayment.ToLedgerID = e.ToLedger.LedgerID;
        this.MlPayment.ToLedgerName = e.ToLedger.LedgerName;
        this.MlPayment.TransactionNo = e.TransactionNo;
        this.MlPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
        this.MlPayment.RoundOff = 0;
        this.MlPayment.BankCommission = 0;
        e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID : delete this.MlPayment.DocumentID;

        LstPayment.push(this.MlPayment)
      });
      this.MlCreateExamIndent.paymentItems = LstPayment;
      this.MlCreateExamIndent.totalAmount = this.Totalamount;
      this.MlCreateExamIndent.CourierAmount = this.CourierChargeAmount;

      this._srvExam.postCreateExamIndent(this.MlCreateExamIndent).subscribe({
        next: (e: any) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.PrintReceipt(e.Data)
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      })
    }
  }

  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourseInfo = [];
    this.LstBatchDetail = this.LstStudentDetail = [];

    this.examIndentForm.controls.firstStep.controls.course.setValue(null);
    this.examIndentForm.controls['firstStep'].controls['batch'].setValue(null);
    this.examIndentForm.controls['firstStep'].controls['studentName'].setValue(null);

    if (event && event.CourseTypeID) {
      this._srvCommon.getCourseListInCourseType(event.CourseTypeID).subscribe({
        next: val => {
          this.LstCourseInfo = val.Data || [];
        }
      });
    }
  }

  PrintReceipt(ID: string) {
    this.opened = true;
    this.title = 'Receipt';
    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;

    const parameter = {
      Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentID: ID, CourerCharge: this.CourierChargeAmount
    }

    this.Reportsource = {
      report: 'iCloud/Exam_Indent_Receipt',
      parameters: parameter
    };
  }

  close() {
    this.opened = false;
    this.goBack();
  }


  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
