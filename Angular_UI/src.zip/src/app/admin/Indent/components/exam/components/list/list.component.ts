import { Component, HostListener, ViewChild } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CookieService } from 'ngx-cookie-service';
import { DateConversion, DateSize, LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CookieKey } from 'src/core/helper';
import { ExamService } from '../../service/exam.service';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { FranchiseeExamIndentList } from '../../model/exam';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {

  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  public LstExamIndent: FranchiseeExamIndentList[] = [];

  /* Model */
  public gridStyle: gridFontStyle = new gridFontStyle();
  public dateStyle: DateSize = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  /* Store Currency Symbol */
  public currencySymbol: string = '';

  /* Date Format */
  public dateWholePeriod: boolean;

  /* Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = this._srvCookie.get(CookieKey.Api);

  /* Grid Pagination */
  public pageSize: number = 15;
  public skip: number = 0;
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  WholePerStrDate: Date;
  /* For Responsiveness */
  getScreenWidth: any;
  getScreenHeight: any;
  @HostListener('window:resize', ['$event'])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight - 75;
  }

  constructor(private _srvExam: ExamService, private _srvCookie: CookieService, public _srvCommon: CommonService,
    private layout: LayoutComponent, private _srvNotification: NotificationService, private sanitizer: DomSanitizer) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = false;
    this.currencySymbol = LocalString.CurrencySymbol;

    // this.MlDateRange = this._srvExam.MllstFliterData;

    if (this._srvExam.examIndentDateRange) {
      this.MlDateRange = this._srvExam.MllstFliterData;
      this.pageSize = this._srvExam.listPageSize;
      this.skip = this._srvExam.listPageSkip;
    }

    this._srvExam.isOldRecord == true ? this.LstExamIndent = this._srvExam.LstExamIndent : this.searchDate();
    this._srvExam.isOldRecord = false;

    this.getWindowDimesion(window);
  }

  ngAfterViewInit() {
    if (this._srvExam.examIndentDateRange) {
      setTimeout(() => {
        this.MlDateRange = this._srvExam.MllstFliterData;
        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          }
          else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        }
        else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateRange)
        }
        else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvExam.examIndentDateRange = false;
        this._srvExam.listPageSize = 15;
        this._srvExam.listPageSkip = 0;
      });
    }
  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;
  }

  /* Select Date */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Date Wise Filter Exam Indent */
  searchDate() {
    if (!this.MlDateRange.startDate || !this.MlDateRange.endDate) this.errorMsg("Please fill the date");
    else this.getExamIndent();
  }

  /* Get Exam Indent Detail */
  getExamIndent() {
    const fromDate = DateConversion.ConvertToYearMonthDate(this.MlDateRange.startDate);
    const toDate = DateConversion.ConvertToYearMonthDate(this.MlDateRange.endDate);
    this._srvExam.getFranchiseeExamIndentList(fromDate, toDate).subscribe({
      next: (e) => {
        this.LstExamIndent = e.Data;
        if (this.LstExamIndent.length) {
          this.LstExamIndent.forEach(e => {
            e.ExamIndentDetail.Option = [
              { text: 'View', disabled: false },
              { text: 'Download Hall Ticket', disabled: e.ExamIndentDetail.Status == 'PENDING' ? true : false }
            ]
            e.ExamIndentDetail.TotalAmount = e.ExamIndentDetail.TotalAmount + e.ExamIndentDetail.CourierAmount;
          })
          this.lstflitervalue();
        }
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  /* Go to Create Exam Indent Component */
  addNew() {
    this.setPagenation();
    this._srvExam.action.next({ Mode: 'CREATE' });
  }

  /* Go to View Component */
  View(event: any, data: any) {
    if (event.text == 'View') {
      this.setPagenation()
      this._srvExam.franchiseeExamIndentDataShare.subscribe((e: any) => e.data = data);
      this._srvExam.LstExamIndent = this.LstExamIndent;
      this._srvExam.action.next({ Mode: 'VIEW' });
    }
    else if ((event.text == 'Download Hall Ticket') && !event.disabled) {
      this.opened = true;
      const ExamID = data.ExamIndentTransDetails[0].ExamIndentID;
      this.title = 'Hall Ticket';
      this.viewerContainerStyle = this.layout.viewerContainerStyle;
      this.bearerToken = this._srvCookie.get(CookieKey.Api);
      this.ServerUrl = this.layout.ServerUrl;
      this.Reportsource = {
        report: 'iCloud/HallTicket',
        parameters: {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentID: ExamID
        }
      };
    }
  }

  lstflitervalue() {
    setTimeout(() => {
      this._srvExam.MllstFliterData.duration = this.MlDateRange.duration;
      this._srvExam.MllstFliterData.startDate = this.dateRanges.dateRange.startDate;
      this._srvExam.MllstFliterData.endDate = this.dateRanges.dateRange.endDate;
    }, 100)
  }
  /* Report Viewer Close Dialog */
  close() {
    this.opened = false;
  }

  /* Exam indent status color different */
  colorCode(code: string): SafeStyle {
    let result: string;
    switch (code.toLowerCase()) {
      case 'pending':
        result = 'expired';
        break;
      case 'rejected':
        result = 'expired';
        break;
      case 'approved':
        result = 'success';
        break;
      default:
        result = 'normal';
        break;
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

  setPagenation() {
    this._srvExam.listPageSize = this.pageSize;
    this._srvExam.listPageSkip = this.skip;
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }
}
