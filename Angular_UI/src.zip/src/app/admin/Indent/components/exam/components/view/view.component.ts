import { Component } from '@angular/core';
import { LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { ExamService } from '../../service/exam.service';
import { ExamIndentTransDetailsDataType, FranchiseeExamIndentList } from '../../model/exam';
import { PaymentDetailViewListMl } from 'src/app/shared/model/common';
import { CookieService } from 'ngx-cookie-service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CookieKey } from 'src/core/helper';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent {

  /* List */
  public studentExamIndent: ExamIndentTransDetailsDataType[] = [];
  public PaymentInfo: PaymentDetailViewListMl[] = [];

  /* Model */
  public MlexamIndent: FranchiseeExamIndentList = new FranchiseeExamIndentList();
  public gridStyle = new gridFontStyle();

  /* Total Amount */
  public total: number = 0;

  /* If Rejected Show reason */
  public showReason: boolean = false;

  public currencySymbol: string = '';

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";

  constructor(private _srvExam: ExamService, private _srvCookie: CookieService, private layout: LayoutComponent, public intlService: IntlService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;

    this._srvExam.franchiseeExamIndentDataShare.subscribe((e: any) => {
      this.MlexamIndent = e.data;
      this.studentExamIndent = this.MlexamIndent.ExamIndentTransDetails;
      this.PaymentInfo = this.MlexamIndent.PaymentDetails
    });
    this.showReason = this.MlexamIndent.ExamIndentDetail.Status.toUpperCase() == 'REJECTED' ? true : false;
    this.total = this.PaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
  }

  PrintReceipt() {
    this.opened = true;
    this.title = 'Receipt';
    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;

    const parameter = {
      Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentID: this.MlexamIndent.ExamIndentDetail.ExamIndentID, CourerCharge: this.MlexamIndent.ExamIndentDetail.CourierAmount
    }

    this.Reportsource = {
      report: 'iCloud/Exam_Indent_Receipt',
      parameters: parameter
    };
  }

  close() {
    this.opened = false;
  }

  /* Go to Exam Indent List Component */
  goBack() {
    this._srvExam.action.next({ Mode: 'LIST' });
    this._srvExam.examIndentDateRange = this._srvExam.isOldRecord = true;
  }
}
