import { Component } from "@angular/core";
import { ExamService } from "./service/exam.service";

@Component({
    selector: 'exam',
    templateUrl: './exam.component.html',
    providers: [ExamService]
})

export class ExamComponents {
    public actions: string = '';
    constructor(private _srvExam: ExamService) {
        this._srvExam.action.subscribe(e => this.actions = e.Mode);
    }
}