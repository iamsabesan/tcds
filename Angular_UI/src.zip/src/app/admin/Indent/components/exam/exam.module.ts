import { CommonModule } from '@angular/common';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { MultiColComboComponentModule } from 'src/app/shared/components/multi-col-combo/multi-col-combo.module';
import { PaymentInfoModule } from 'src/app/shared/components/payment-info/payment-info.module';
import { RejectModule } from 'src/app/shared/components/reject/reject.module';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { ExamComponents } from './exam.component';
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { ViewComponent } from './components/view/view.component';
import { ExamService } from './service/exam.service';
import { RouterModule } from '@angular/router';
import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';

const routes = [
    {
        path: '',
        component: ExamComponents,
        
    }
]

@NgModule({
    declarations: [
        ExamComponents,
        ListComponent,
        CreateComponent,
        ViewComponent
    ],

    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        ReactiveFormsModule,
        DateInputModule,
        PopupModule,
        GridModule,
        LabelModule,
        DialogsModule,
        DateInputsModule,
        MultiColComboComponentModule,
        PaymentInfoModule,
        RejectModule,
        DateRangesModule,
        TelerikReportingModule,
        PaymentGridModule

    ],

    providers: [ExamService],
    schemas: [NO_ERRORS_SCHEMA]
})
export class ExamModule { }
