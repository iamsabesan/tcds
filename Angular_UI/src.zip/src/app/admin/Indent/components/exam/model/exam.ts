import { MultiDropdownColumn, PaymentDetailViewListMl, basicAddressDataType } from "src/app/shared/model/common";
import { PaymentPayVal } from "src/app/shared/model/payment";

export interface Exam {
    Mode: 'LIST' | 'CREATE' | 'VIEW'
}

//#region View Exam Indent (Franchisee) & Exam Indent List (Franchisee)
export class adminExamIndentListDataType {
    FranchiseeCode: string = '';
    FranchiseeName?: string = "";
    BranchDetail: basicAddressDataType = new basicAddressDataType();
    ExamIndentDetail: ExamIndentDetailDataType = new ExamIndentDetailDataType();
    ExamIndentTransDetails: ExamIndentTransDetailsDataType[] = [];
    PaymentDetails: PaymentDetailViewListMl[] = [];
}

export class ExamIndentDetailDataType {
    IsRejected?: boolean;
    CourierAmount: number = 0;
    Reason?: string;
    ExamIndentID: string = '';
    TenantBranchID: string = '';
    IndentDate: string = '';
    IndentNumber: string = '';
    TotalAmount: number = 0;
    TotalItem: number = 0;
    ActiveItem: number = 0;
    InactiveItem: number = 0;
    Status?: String;
    Option = [];
}

export class ExamIndentTransDetailsDataType {
    isDisabled?: boolean;
    StudentID: string = '';
    StudentName: string = '';
    Course: string = '';
    ExamIndentID: string = '';
    StudentBatchMapping: string = '';
    Semester: number = 0;
    ExamFees: number = 0;
    Status: string = '';
    AcivateDate: string = '';
    startTime?: Date = new Date();
    endTime?: Date = new Date();
}

/* Exam Indent List (Franchisee) */
export class FranchiseeExamIndentList {
    ExamIndentDetail: ExamIndentDetailDataType = new ExamIndentDetailDataType();
    ExamIndentTransDetails: ExamIndentTransDetailsDataType[] = [];
    PaymentDetails: PaymentDetailViewListMl[] = [];
}

export class franchiseeExamIndentShareDataValue {
    data?: FranchiseeExamIndentList;
}
//#endregion


//#region Add Exam Indent
/* Create Exam Indent */
export class CreateExamIndent {
    batchMapping: BatchMapping[] = [];
    totalAmount: number = 0;
    CourierAmount: number = 0;
    paymentItems: PaymentPayVal[] = [];
}

export class BatchMapping {
    batchMappingID: string = '';
    examFees: number = 0;
    semester: number = 0;
    examDate: string = '';
}

export class StudentExamIndent {
    BatchMappingID: string = '';
    studentID: string = '';
    studentName: string = '';
    course: string = '';
    semester: number = 0;
    batch: any;
    examFees: number = 0;
    examDate?: string = '';
    activateDate?: Date = new Date();
    status?: string = '';
    startTime: Date = new Date();
    endTime: Date = new Date();
    ShortName: string = '';
    CourseType: string = '';
}

/* Course Info */
export class CourseInfoListByFranchisee {
    CourseID: string = '';
    ShortName: string = '';
    Course: string = '';
    CourseType: string = '';
    Duration: string = '';
    CourseFees: number = 0;
    ExamFees: number = 0;
    AdmissionFees: number = 0;
    TotalFees: number = 0;
}


/* Add Exam Indent */
export const CourseColumn: MultiDropdownColumn[] = [
    {
        Field: "ShortName",
        Title: "Short Name",
        Width: 150,
    },
    {
        Field: "Course",
        Title: "Full Name",
        Width: 250,
    },
    // {
    //     Field: "CourseType",
    //     Title: "Course Type",
    //     Width: 200
    // }
];

export const BatchColumn: MultiDropdownColumn[] = [
    {
        Field: "BatchNumber",
        Title: "ID",
        Width: 150
    },
    {
        Field: "Timing",
        Title: "Time",
        Width: 150,
    },
    {
        Field: "FacultyName",
        Title: "Faculty",
        Width: 200
    }
];
//#endregion
