import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Exam, FranchiseeExamIndentList, franchiseeExamIndentShareDataValue } from '../model/exam';
import { HttpService } from 'src/core/service';
import { IRequestType } from 'src/core/model';
import { DateRanges } from 'src/app/shared/model/date-ranges';

@Injectable({
  providedIn: 'root'
})
export class ExamService {

  constructor(private _srvHttp: HttpService) { }

  public action = new BehaviorSubject<Exam>({ Mode: 'LIST' });
  public MllstFliterData = new DateRanges();
  public listPageSize: any = 15;
  public listPageSkip: any = 0;
  public examIndentDateRange = false;

  public LstExamIndent: FranchiseeExamIndentList[] = [];
  public isOldRecord: boolean = false;

  public franchiseeExamIndentDataShare = new BehaviorSubject<franchiseeExamIndentShareDataValue>({});

  /* List */
  getFranchiseeExamIndentList(fromDate: string, toDate: string) {
    return this._srvHttp.get("/icloud-inventory/v1/indent/exam/list/byfranchisee", { params: { fromDate, toDate }, RequestType: IRequestType.Protected });
  }

  /* Create */
  getCourseInfoListByFranchisee() {
    return this._srvHttp.get('/icloud-academic/v1/course/info/list/byfranchisee', { RequestType: IRequestType.Protected });
  }

  /* Create a New Exam Indent */
  postCreateExamIndent(data: any) {
    return this._srvHttp.post('/icloud-inventory/v1/indent/exam/create', data, { RequestType: IRequestType.Protected });
  }
}
