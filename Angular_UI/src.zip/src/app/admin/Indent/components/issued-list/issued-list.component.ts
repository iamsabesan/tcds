import { Component, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, LocalString, gridFontStyle, ZeroGUID } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MaterialIssuedList } from '../../models/material-indent';
import { IndentService } from '../../services/indent.service';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { CommonService } from 'src/app/shared/service/common.service';
import { CourseCodeNameColumn, CourseListByCourseTypeMl, CourseTypeListMl } from 'src/app/shared/model/common';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';

@Component({
  selector: 'app-issued-list',
  templateUrl: './issued-list.component.html',
  styleUrls: ['./issued-list.component.scss']
})
export class IssuedListComponent {
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;


  /* List */
  public LstIssuedMaterialIndent: MaterialIssuedList[] = [];
  public LstCourseDropDown = CourseCodeNameColumn;
  public LstCourseType: CourseTypeListMl[] = [];
  public LstCourse: CourseListByCourseTypeMl[] = [];

  /* DateRange Model */
  public MlDateRange: DateRanges = new DateRanges();
  public MlCourseType: CourseTypeListMl = new CourseTypeListMl();
  public MlCourseValue: CourseListByCourseTypeMl = new CourseListByCourseTypeMl();

  /* Grid Data Filter */
  public filter: CompositeFilterDescriptor;

  /* Date Format */
  public dateWholePeriod: boolean;

  /* Grid Header Style & DateRange Component Width */
  public gridStyle = new gridFontStyle('medium');
  public dateStyle = new DateSize('medium');

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  public MobileNameFilter: string = '';
  WholePerStrDate: Date;
  constructor(private _srvNotification: NotificationService, private _srvIndent: IndentService, public _srvCommon: CommonService) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = true;
    this.MlCourseType = null;
    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

  }

  ngAfterViewInit() {
    this.getIssuedList();
  }

  dateChange(event: DateRanges) {
    this.MlDateRange = event;
  }

  /* Get Material Issued List */
  getIssuedList() {
    this.LstIssuedMaterialIndent = [];
    if ((!this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate) && (!this.MobileNameFilter || this.MobileNameFilter.length < 3) && (!this.MlCourseType.CourseType)) new CustomNotification(this._srvNotification).ShowError("Please fill the inputs");
    else if ((!this.dateRanges.dateRange.startDate && this.dateRanges.dateRange.endDate) || (this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate)) new CustomNotification(this._srvNotification).ShowError("Invalid Date");
    else if (this.MobileNameFilter && this.MobileNameFilter.length < 3) new CustomNotification(this._srvNotification).ShowError("Invalid name / mobile");
    else {
      const fromDate = this.dateRanges.dateRange.startDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.startDate) : '';
      const toDate = this.dateRanges.dateRange.endDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.endDate) : '';
      const nameOrPhone = this.MobileNameFilter ?? '';
      const courseTypeID = this.MlCourseType ? this.MlCourseType.CourseTypeID : ZeroGUID.guid;
      const shortName = this.MlCourseValue ? this.MlCourseValue.ShortName : '';
      this._srvIndent.getMaterialIssueList(fromDate, toDate, nameOrPhone, courseTypeID, shortName).subscribe({
        next: (e) => this.LstIssuedMaterialIndent = e.Data,
        error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
      });
    }
  }
  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourse = [];
    this.MlCourseValue = null;

    if (event && event.CourseTypeID) {
      this.MlCourseType = event;

      this._srvCommon.getCourseListInCourseType(event.CourseTypeID).subscribe({
        next: val => {
          this.LstCourse = val.Data || [];
        }
      });
    }
  }

  selectCourse(event) {
    console.log(event);
  }
}
