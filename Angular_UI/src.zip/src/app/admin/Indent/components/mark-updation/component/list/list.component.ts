import { Component } from "@angular/core";
import { NgModel } from "@angular/forms";
import { NotificationService } from "@progress/kendo-angular-notification";
import { CookieService } from "ngx-cookie-service";
import { MarkUpdate, StudentMarksUpdation, StudentMarkUpdation } from "src/app/admin/Indent/models/material-indent";
import { UpdationService } from "src/app/admin/Indent/services/updation.service";
import { LayoutComponent } from "src/app/layouts/layout.component";
import { gridFontStyle } from "src/app/shared/app-global";
import { batchBasicData, MultiDropdownColumn } from "src/app/shared/model/common";
import { CustomNotification } from "src/app/shared/model/shared";
import { CommonService } from "src/app/shared/service/common.service";
import { CookieKey } from "src/core/helper";
import { IWebError } from "src/core/model";
import { MarkUpdationResultMl, PreviewMarksheetID } from "../../model/mark-updation";

@Component({
  selector: 'list',
  templateUrl: 'list.component.html',
  styleUrls: ['list.component.scss']

})

export class ListComponent {

  Step = 0;

  /* List */
  public LstStudentMarkUpdation: StudentMarkUpdation[] = [];
  public LstStudentMarkUpdate: StudentMarksUpdation[] = [];
  public LstCourseBatch: batchBasicData[] = [];
  public LstStudentMarksheet: any[] = [];
  public LstPreviewID: PreviewMarksheetID[] = [];
  public LstStudentMarkUpdationResult: MarkUpdationResultMl[] = [];

  /* Model */
  public MlStudentMark: StudentMarksUpdation = new StudentMarksUpdation();
  public gridStyle = new gridFontStyle();
  public MlStudentMarksheet: any;
  public MlCourse: batchBasicData = new batchBasicData()

  /* Multi Column Dropdown */
  public CourseColumns: MultiDropdownColumn[] = [
    {
      Field: 'ShortName',
      Title: 'Course Code',
      Width: 120
    },
    {
      Field: 'CourseName',
      Title: 'Course',
      Width: 220
    },
    {
      Field: 'Timing',
      Title: 'Batch Time',
      Width: 180
    }
  ];

  /* Batch */
  public CourseValue: any;

  /* Disabled the Save Button */
  public IsBtnDisabled: boolean = true;

  public previewType: boolean = true;

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public MarksheetReportsource: any;
  public CertificateReportsource: any;
  public title: string = '';
  public bearerToken = "";

  AlreadyGoingCrossStep: boolean = false;


  constructor(private _srvUpdation: UpdationService, private layout: LayoutComponent, private _srvCookie: CookieService,
    private _srvNotification: NotificationService, private _srvCom: CommonService) { }

  ngOnInit() {
    this.getCourseList();
  }

  getCourseList() {
    this._srvUpdation.getMarkUpdationCourseList().subscribe({
      next: (e: any) => this.LstCourseBatch = e.Data,
      error: (err: IWebError) => this._errorMsg(err.Message)
    });
  }

  /* Choose the Course */
  selectCourse(event: batchBasicData) {
    this.CourseValue = event;
  }

  /* Reset the Grid Data */
  btnResetList() {
    this.LstStudentMarkUpdation.filter((e: any) => {
      e.IsChecked = false;
      e.newTheoryMarks = e.newPracticalMarks = 0;
    });
  }

  btnSearch() {
    if (this.CourseValue != undefined) this.getStudentMarkList(this.CourseValue.CourseBatchID);
  }

  /* Get Student Mark Updation List */
  getStudentMarkList(data: string) {
    this.MlCourse = this.CourseValue;
    this._srvUpdation.getStudentMarkUpdationList(data).subscribe({
      next: (e) => {
        this.LstStudentMarkUpdation = e.Data;
        this.IsBtnDisabled = this.LstStudentMarkUpdation.length !== 0 ? false : true;
        this.btnResetList();
      },
      error: (err) => this._errorMsg(err.Message)
    });
  }

  btnFrmSubmit() {
    const IsChecked = this.LstStudentMarkUpdation.some(e => !e.newTheoryMarks && !e.newPracticalMarks);
    const IsTheoryMarkCheck = this.LstStudentMarkUpdation.some(e => e.newTheoryMarks > e.TheoryMarks);
    const IsPracticalMarkCheck = this.LstStudentMarkUpdation.some(e => e.newPracticalMarks > e.PracticalMarks);
    const IsMarkLessThan = this.LstStudentMarkUpdation.some(e => (e.newTheoryMarks || e.newPracticalMarks) < 0);

    if (!this.CourseValue) this._errorMsg("Please select the course");
    else if (IsChecked) this._errorMsg("Mark cannot be empty");
    else if (IsTheoryMarkCheck) this._errorMsg("Mark cannot be greater than actual Theory Mark");
    else if (IsPracticalMarkCheck) this._errorMsg("Mark cannot be greater than actual Practical Mark");
    else if (IsMarkLessThan) this._errorMsg("Mark cannot be less than zero");
    else {
      this.LstStudentMarkUpdate = [];
      this.LstStudentMarkUpdation.forEach((e: StudentMarkUpdation) => {
        this.MlStudentMark = new StudentMarksUpdation();
        this.MlStudentMark.ExamIndentTransID = e.ExamIndentTransID;
        this.MlStudentMark.SubjectMappingID = e.SubjectMappingID;
        this.MlStudentMark.TheoryMarks = e.TheoryMarks;
        this.MlStudentMark.PracticalMarks = e.PracticalMarks;
        this.MlStudentMark.BatchMappingID = e.BatchMappingID;
        this.MlStudentMark.Semester = e.Semester;
        this.MlStudentMark.ObtainedTheoryMarks = e.newTheoryMarks ?? 0;
        this.MlStudentMark.ObtainedPracticalMarks = e.newPracticalMarks ?? 0;
        this.LstStudentMarkUpdate.push(this.MlStudentMark);
      });

      var Student: MarkUpdate = new MarkUpdate();
      Student.preview = 1;
      Student.marks = this.LstStudentMarkUpdate;

      this._srvUpdation.updateStudentMark(Student).subscribe({
        next: (res: any) => {
          if (res.Data && res.Data.length) {
            this.LstStudentMarkUpdationResult = res.Data;

            const PreviewIDList: PreviewMarksheetID[] = [];
            const PreviewList: any[] = res.Data;

            PreviewList.forEach(e => {
              const PreviewIDMl = new PreviewMarksheetID();
              PreviewIDMl.ExamIndentTransID = e.ExamIndentTransID;
              PreviewIDList.push(PreviewIDMl);
            });

            this.LstPreviewID = PreviewIDList;

            this.viewerContainerStyle = this.layout.viewerContainerStyle;
            this.bearerToken = this._srvCookie.get(CookieKey.Api);
            this.ServerUrl = this.layout.ServerUrl;
            const parameter = {
              Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(this.LstPreviewID)
            }
            this.MarksheetReportsource = {
              report: 'iCloud/Student_Marksheet_Preview',
              parameters: parameter
            };
            this.Step += 1;
            this.AlreadyGoingCrossStep = false;
          }

        },
        error: (err: IWebError) => this._errorMsg(err.Message)
      });
    }
  }

  btnNext() {
    this.Step += 1;

    if (!this.AlreadyGoingCrossStep) {
      if (this.MlCourse.CourseTypeName == 'CERTIFICATE') {

        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;
        const parameter = {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(this.LstPreviewID)
        }

        this.CertificateReportsource = {
          report: 'iCloud/Student_Certificate_Preview',
          parameters: parameter
        };
      }
      else if (this.MlCourse.CourseTypeName == 'DIPLOMA') {
        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;
        const parameter = {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(this.LstPreviewID)
        }

        this.CertificateReportsource = {
          report: 'iCloud/Student_Diploma_Preview',
          parameters: parameter
        };
      }
      else if (this.MlCourse.CourseTypeName == 'SUMMER') {
        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;
        const parameter = {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(this.LstPreviewID)
        }

        this.CertificateReportsource = {
          report: 'iCloud/Student_Junior_diploma_Preview',
          parameters: parameter
        };
      }
      this.AlreadyGoingCrossStep = true;
    }

  }

  btnSendPrint() {
    var Student: MarkUpdate = new MarkUpdate();
    Student.preview = 0;
    Student.marks = this.LstStudentMarkUpdate;

    this._srvUpdation.updateStudentMark(Student).subscribe({
      next: (res: any) => {
        this._srvCom.successMsg(res.Message);
        this.CourseValue = undefined;
        this.Step = 0;
        this.LstStudentMarkUpdation = [];
        this.getCourseList();
        this.IsBtnDisabled = true;
      }, error: err => this._srvCom.errorMsg(err.Message)
    })

  }

  showValidation = false;
  btnSearchMarksheet(model: NgModel) {
    this.showValidation = true;

    if (model.invalid) {
      return;
    }
  }

  btnGoBack() {
    this.Step += -1
  }


  /* Show Error Msg */
  private _errorMsg = (err: string) => new CustomNotification(this._srvNotification).ShowError(err)

}