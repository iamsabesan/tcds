import { Component } from '@angular/core';
import { MarkUpdationService } from './service/mark-updation.service';

@Component({
  selector: 'mark-updation-entry',
  templateUrl: 'mark-updation.component.html',
  styleUrls: ["mark-updation.component.scss"],
})

export class MarkUpdationEntryComponent {

  public actions: string = '';
  constructor(private _srvMark: MarkUpdationService) {
    this._srvMark.action.subscribe(e => this.actions = e.Mode);
  }

}
