import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { GridModule } from "@progress/kendo-angular-grid";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";
import { MultiColComboComponentModule } from "src/app/shared/components/multi-col-combo/multi-col-combo.module";
import { UpdationService } from "../../services/updation.service";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { MarkUpdationEntryComponent } from "./mark-updation.component";
import { MarkUpdationService } from "./service/mark-updation.service";

const routes: Routes = [
    {
        path: '',
        component: MarkUpdationEntryComponent,

    }
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild(routes),

        /* Kendo Component */
        ButtonsModule,
        IconsModule,
        NavigationModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        GridModule,
        LabelModule,
        TelerikReportingModule,

        MultiColComboComponentModule,


    ],
    declarations: [
        MarkUpdationEntryComponent,
        ViewComponent,
        ListComponent
    ],
    providers: [
        MarkUpdationService,
        UpdationService
    ]
})

export class MarkUpdationModule { }