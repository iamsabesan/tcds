export class RutMode {
    Mode = 'CREATE' || 'LIST' || 'VIEW';
}


export class PreviewMarksheetID {
    ExamIndentTransID: string = '';
}

export class MarkUpdationResultMl {
    ExamIndentTransID: string = '';
    BatchMappingID: string = '';
    Course: string = '';
    StudentName: string = '';
    RollNumber: string = '';
    Semester: number = 0;
    SemesterResult: string = '';
}