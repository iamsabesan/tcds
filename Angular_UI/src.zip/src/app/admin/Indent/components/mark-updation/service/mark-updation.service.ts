import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { RutMode } from "../model/mark-updation";

@Injectable()

export class MarkUpdationService {
    public action = new BehaviorSubject<RutMode>({ Mode: 'LIST' });
}