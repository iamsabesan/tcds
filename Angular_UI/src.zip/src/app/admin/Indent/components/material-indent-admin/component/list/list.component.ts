import { Component } from "@angular/core";
import { MlIndentReject, adminMaterialListDataType } from "../../model/material-indent-admin";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { InputRegex } from "src/app/shared/components/regex";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { PagerPosition } from "@progress/kendo-angular-grid";
import { MaterialIndentAdminService } from "../../service/material-indent-admin.service";
import { DialogService } from "@progress/kendo-angular-dialog";
import { NotificationService } from "@progress/kendo-angular-notification";
import { CustomNotification } from "src/app/shared/model/shared";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import { CommonService } from "src/app/shared/service/common.service";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html',
    styleUrls: ['list.component.scss']
})
export class ListComponent {
    /* List */
    public LstMaterialIndent: adminMaterialListDataType[] = [];
    MlMaterialIndentReject = new MlIndentReject()

    /* Grid Fiter */
    filter!: CompositeFilterDescriptor;

    /* Pattern */
    Name = InputRegex.Name;

    /* Date and Currency format */
    public currencySymbol = '';
    public gridStyle = new gridFontStyle();
    public todayDate: Date = new Date();

    /* Grid Pagination */
    public buttonCount: number = 5;
    public sizes: any[] = [25, 50, 100, "All"];
    public info: boolean = true;
    public previousNext: boolean = true;
    public position: PagerPosition = "bottom";


    constructor(private _srvMatIndentAdmin: MaterialIndentAdminService,
        public dialogservice: DialogService, public _srvNotification: NotificationService,
        private _srvCommon: CommonService) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvMatIndentAdmin.isOldRecord == true ? this.LstMaterialIndent = this._srvMatIndentAdmin.LsttMaterialIndent : this.getMaterialList();
        this._srvMatIndentAdmin.isOldRecord = false;
    }

    getMaterialList() {
        this._srvMatIndentAdmin.getAdminMaterialIndentList().subscribe({
            next: (e) => {
                this.LstMaterialIndent = e.Data;
                this.LstMaterialIndent.filter((res: any) => {
                    // res.FranchiseeName = "TCDS COMPUTER EDUCATION";
                    res.BranchDetail.Address = this._srvCommon.concatAddress(res.BranchDetail);
                    // if (res.BranchDetail.Address2 !== "" || null) {
                    //     res.BranchDetail.Address = res.BranchDetail.Address1 + ", " + res.BranchDetail.Address2 + ", " + res.BranchDetail.Area + ", " + res.BranchDetail.District + ", " + res.BranchDetail.State + ", " + res.BranchDetail.Country + " - " + res.BranchDetail.Pincode;
                    // } else {
                    //     res.BranchDetail.Address = res.BranchDetail.Address1 + ", " + res.BranchDetail.Area + ", " + res.BranchDetail.District + ", " + res.BranchDetail.State + ", " + res.BranchDetail.Country + " - " + res.BranchDetail.Pincode;
                    // }
                    res.editOptions = [
                        { text: "Approve", disabled: res.IndentDetails.Status !== "PENDING" },
                        { text: "View", disabled: false },
                        { text: "Reject", disabled: res.IndentDetails.Status !== "PENDING" }
                    ];
                })
            },
            error: (err) => this._srvCommon.errorMsg(err.Message)
        });
    }

    OpenApproveDialog: boolean = false;

    dialogClose() {
        this.OpenApproveDialog = false;
    }
    /* View the Material Indent */
    view(event: any, data: adminMaterialListDataType) {
        if (event.text === 'View') {
            this._srvMatIndentAdmin.materialIntentOrderConformation.subscribe((e: any) => e.value = data)
            this._srvMatIndentAdmin.onMode.next({ mode: 'VIEW' });
            this._srvMatIndentAdmin.LsttMaterialIndent = this.LstMaterialIndent;
        }

        else if ((event.text == 'Approve') && !event.disabled) {
            const dialogRef = this.dialogservice.open({
                title: "Approve Material Indent",
                content: `Are you sure to approve the material indent ${data.IndentDetails.IndentNo} ?`,
                actions: [
                    { text: 'No', themeColor: 'error' },
                    { text: 'Yes', themeColor: 'success' }
                ],
                width: 450,
                height: 200,
                minWidth: 380,
                cssClass: "custom-css-class",
            });
            dialogRef.result.subscribe((result: any) => {
                if (result.text == "Yes") {
                    this._srvMatIndentAdmin.approveMaterialIndent(data.IndentDetails.BranchMaterialIndentID).subscribe({
                        next: (res: any) => {
                            new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                            this.getMaterialList();
                        },
                        error: (err) => this._srvCommon.errorMsg(err.Message)
                    })
                }
            })
        }

        else if ((event.text == 'Reject') && !event.disabled) {
            this.MlMaterialIndentReject = new MlIndentReject()

            const dialogRef = this.dialogservice.open({
                title: "Reject Material Indent",
                content: RejectComponent,
                width: 400,

            });
            const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

            rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
                this.MlMaterialIndentReject.BranchMaterialIndentID = data.IndentDetails.BranchMaterialIndentID;
                this.MlMaterialIndentReject.Reason = formData.Reason;

                this._srvMatIndentAdmin.postRejectMaterialIndent(this.MlMaterialIndentReject).subscribe({
                    next: (response) => {
                        new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
                        this.getMaterialList();
                        dialogRef.close();
                    },
                    error: (error) => new CustomNotification(this._srvNotification).ShowError(error.Message),
                });
            });
        }
    }

}