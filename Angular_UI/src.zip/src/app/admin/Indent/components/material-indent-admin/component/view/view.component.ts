import { Component, ViewChild } from "@angular/core";
import { PaymentDetailViewListMl } from "src/app/shared/model/common";
import { adminMaterialListDataType, indentId, indentTransDetailsDataType, materialIndent, materialSpliteCreateDataType } from "../../model/material-indent-admin";
import { AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, aggregateBy } from "@progress/kendo-data-query";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { MaterialIndentAdminService } from "../../service/material-indent-admin.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { Router } from "@angular/router";
import { IntlService } from "@progress/kendo-angular-intl";
import { NumericTextBoxComponent } from "@progress/kendo-angular-inputs";
import { CustomNotification } from "src/app/shared/model/shared";

@Component({
  selector: 'view',
  templateUrl: 'view.component.html',
  styleUrls: ['view.component.scss']
})
export class ViewComponent {


  /* List */
  public payment: any[] = [];
  public PaymentInfo: PaymentDetailViewListMl[] = [];

  /* Model */
  public franchiseeDetails: adminMaterialListDataType = new adminMaterialListDataType();
  public materialIndentListData: adminMaterialListDataType = new adminMaterialListDataType();
  public materialSplitData: indentTransDetailsDataType = new indentTransDetailsDataType();
  public MlSplitMaterialIndent: materialSpliteCreateDataType = new materialSpliteCreateDataType();
  public materialIndentId: indentId = new indentId();
  public totalss!: AggregateResult;
  public filter!: CompositeFilterDescriptor;

  public totalsPayment: number = 0;
  public todayDate: Date = new Date();

  public currencySymbol = '';
  public splitDialog: boolean = false;
  public renewalPaymentInfo = false;
  public decimals = 0;
  public value = 0;
  public QuantityMax: number = 0;

  public totalAmount: number = 0;
  public total: number = 0;
  public quantityValue: number = 0;
  public gridStyle = new gridFontStyle();
  public indentId: string = '';

  /* Is Approved Indent */
  public isApproved: boolean = false;

  /* Submit Btn Disabled */
  public IsBtnDisabled: boolean = false

  public IsShowGridFooter: boolean = false;
  reject = new FormGroup({
    quantity: new FormControl(null, [Validators.required]),
  })

  constructor(public _srvMatIndentAdmin: MaterialIndentAdminService, public _srvNotification: NotificationService, public router: Router, public intlService: IntlService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this._srvMatIndentAdmin.materialIntentOrderConformation.subscribe((e: any) => {
      this.materialIndentListData = e.value;
    });

    this.isApproved = this.materialIndentListData.IndentDetails.Status.toUpperCase() == "APPROVED" ? true : false;
    this.IsBtnDisabled = this.materialIndentListData.IndentTransDetail.every((e) => e.Status.toUpperCase() == 'PENDING');

    this.PaymentInfo = this.materialIndentListData.PaymentDetails;
    this.total = this.materialIndentListData.IndentTransDetail.reduce((sum: any, current: any) => sum + current.Total, 0);
    this.totalAmount = this.PaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
    this.IsShowGridFooter = this.totalAmount == 0 ? false : true;
    this.totalss = aggregateBy(this.payment, this.aggregate);
    this.franchiseeDetails = this.materialIndentListData;
    this.indentId = this.materialIndentListData.IndentDetails.BranchMaterialIndentID;
  }

  materialIndentView() {
    this._srvMatIndentAdmin.getAdminMaterialIndentList().subscribe({
      next: (val) => {
        if (val.Data.find(e => e.IndentDetails.BranchMaterialIndentID == this.indentId)) {
          val.Data.filter((res: any) => {
            if (this.indentId == res.IndentDetails.BranchMaterialIndentID) {
              this.materialIndentListData.IndentTransDetail = res.IndentTransDetail;
              this.IsBtnDisabled = this.materialIndentListData.IndentTransDetail.every((e) => e.Status.toUpperCase() == 'PENDING');
            }
          });
        } else this.goBack(false);
      }
    });
  }

  public aggregates: AggregateDescriptor[] = [
    { field: "total", aggregate: "sum" },
  ];
  public aggregate: AggregateDescriptor[] = [
    { field: "amount", aggregate: "sum" },
  ];

  @ViewChild('focus', { static: false }) focus!: NumericTextBoxComponent;
  split(events: any) {
    this.materialSplitData = events;
    this.QuantityMax = events.Quantity;
    this.reject.controls['quantity'].setValidators([Validators.required, Validators.min(1), Validators.max(this.QuantityMax - 1)]);
    this.reject.controls['quantity'].updateValueAndValidity();
    this.splitDialog = true;
    this.quantityFocus();
  }

  quantityFocus() {
    setTimeout(() => {
      this.focus.focus();
    }, 50)
  }

  changequantity(data: number) {
    this.quantityValue = data;
  }

  splitQuantity(data: any) {
    if (!this.reject.valid) this.reject.markAllAsTouched();
    else {
      this.MlSplitMaterialIndent.indentQuantity = data.quantity;
      this.MlSplitMaterialIndent.materialIndentTransID = this.materialSplitData.MaterialIndentTransID;

      this._srvMatIndentAdmin.postMaterialSplit(this.MlSplitMaterialIndent).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.splitDialog = false;
          this.reject.reset();
          this.materialIndentView();
        },
        error: (err) => {
          new CustomNotification(this._srvNotification).ShowError(err.Message);
        }
      });
    }
  }
  dialogClose() {
    this.splitDialog = false;
    this.reject.reset();
  }

  goBack(data: boolean) {
    this._srvMatIndentAdmin.isOldRecord = data;
    this._srvMatIndentAdmin.onMode.next({ mode: 'LIST' });
  }

  reset() {
    this.materialIndentListData.IndentTransDetail.forEach((e) => e.isSelected = false);
  }

  confirm() {
    var matIndent = new materialIndent();
    this.materialIndentListData.IndentTransDetail.forEach(e => {
      if (e.isSelected) {
        const indent = new indentId();
        indent.materialIndentTransID = e.MaterialIndentTransID;
        matIndent.materialIndent.push(indent);
      }
    })
    if (matIndent.materialIndent.length) {
      this._srvMatIndentAdmin.postAdminMaterialIndentConfirm(matIndent).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.materialIndentView();
        },
        error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
      });
    } else new CustomNotification(this._srvNotification).ShowError("Select atleast one material");
  }
}