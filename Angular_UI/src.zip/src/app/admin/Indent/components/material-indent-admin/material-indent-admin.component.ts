import { Component } from "@angular/core";
import { MaterialIndentAdminService } from "./service/material-indent-admin.service";

@Component({
    selector: 'material-indent-admin',
    templateUrl: 'material-indent-admin.component.html',
    providers: [MaterialIndentAdminService]
})
export class MaterialIndentAdminComponent {

    mode: string;
    constructor(public _srvMatIndentAdmin: MaterialIndentAdminService) {
        _srvMatIndentAdmin.onMode.subscribe(res => this.mode = res.mode)
    }
}