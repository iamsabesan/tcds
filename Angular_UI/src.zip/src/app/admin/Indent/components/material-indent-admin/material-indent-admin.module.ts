import { NgModule } from "@angular/core";
import { MaterialIndentAdminComponent } from "./material-indent-admin.component";
import { MaterialIndentAdminService } from "./service/material-indent-admin.service";
import { ViewComponent } from "./component/view/view.component";
import { ListComponent } from "./component/list/list.component";
import { GridModule } from "@progress/kendo-angular-grid";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { InfoModule } from "src/app/shared/components/info/info.module";
import { AutoCompleteModule } from "@progress/kendo-angular-dropdowns";

const routes: Routes = [
    {
        path: '',
        component: MaterialIndentAdminComponent,

    }
];

@NgModule({
    imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    /* Kendo Component */
    ButtonsModule,
    IconsModule,
    GridModule,
    NavigationModule,
    InputsModule,
    LabelModule,
    DialogsModule,
    /* Shared Component */
    PaymentInfoModule,
    InfoModule,
    RejectModule,
    AutoCompleteModule
],
    declarations: [
        MaterialIndentAdminComponent,
        ViewComponent,
        ListComponent
    ],
    providers: [MaterialIndentAdminService]
})
export class MaterialIndentAdminModule { }