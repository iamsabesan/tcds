import { basicAddressDataType, PaymentDetailViewListMl } from "src/app/shared/model/common";

export class RutMode {
    mode = 'LIST' || 'VIEW';
}


//#region  Order Confirmation 
export class adminMaterialListDataType {
    FranchiseeID: string = '';
    FranchiseeName?: string = "";
    IndentDetails: IndentDetailsDataType = new IndentDetailsDataType();
    IndentTransDetail: indentTransDetailsDataType[] = [];
    BranchDetail: basicAddressDataType = new basicAddressDataType();
    PaymentDetails: PaymentDetailViewListMl[] = [];
    editOptions = [];
}


export class IndentDetailsDataType {
    PendingItem: number = 0;
    IndentDate: string = '';
    IndentNo: string = '';
    BranchMaterialIndentID: string = '';
    TenantBranchID: string = '';
    TotalItem: number = 0;
    DespatchItem: number = 0;
    Status: string = '';
    CourierAmount: number = 0;
}

export class indentTransDetailsDataType {
    MaterialIndentTransID: string = '';
    BranchMaterialIndentID: string = '';
    MaterialType: string = '';
    MaterialName: string = '';
    Price: number = 0;
    Quantity: number = 0;
    Total: number = 0;
    Status: string = '';
    isSelected: boolean = false;
}

// list to view data share
export class adminMaterialDataShareValue {
    value?: adminMaterialListDataType;
}

/* Split Order */
export class materialSpliteCreateDataType {
    materialIndentTransID: string = '';
    indentQuantity: number = 0;
}

export class materialIndent {
    materialIndent: indentId[] = [];
}
export class indentId {
    materialIndentTransID: string = '';
}
export class MlIndentReject {
    BranchMaterialIndentID: string = '';
    Reason: string = '';
}
