import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { MlIndentReject, RutMode, adminMaterialDataShareValue, adminMaterialListDataType, materialIndent } from "../model/material-indent-admin";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";

@Injectable()
export class MaterialIndentAdminService {

    onMode = new BehaviorSubject<RutMode>({ mode: 'LIST' });
    public materialIntentOrderConformation = new BehaviorSubject<adminMaterialDataShareValue>({});

    public LsttMaterialIndent:adminMaterialListDataType[]=[];
    public isOldRecord:boolean = false;

    constructor(private http: HttpService) { }

    /* Material Indent List */
    getAdminMaterialIndentList() {
        return this.http.get("/icloud-inventory/v1/indent/material/list", { RequestType: IRequestType.Protected })
    }

    /* Order Confirmation Material Indent Split (Admin) */
    postMaterialSplit(data: any) {
        return this.http.post("/icloud-inventory/v1/indent/material/split", data, { RequestType: IRequestType.Protected });
    }

    /* Order Confirmation in (Admin) */
    postAdminMaterialIndentConfirm(data: materialIndent) {
        return this.http.post("/icloud-inventory/v1/indent/material/accept", data, { RequestType: IRequestType.Protected })
    }

    /* Material Indent Reject */
    postRejectMaterialIndent(data: MlIndentReject) {
        return this.http.post('/icloud-inventory/v1/indent/material/reject', data, { RequestType: IRequestType.Protected });
    }

    /* Appoved Material Indent */
    approveMaterialIndent(materialIndentID: string) {
        return this.http.get(`/icloud-inventory/v1/indent/material/approved?branchMaterialIndentID=${materialIndentID}`, { RequestType: IRequestType.Protected });
    }

}