import { Component } from "@angular/core";
import { IndentMaterial, MaterialIndentCreate, Materials, materialItems, materialTypeList, materials, newMaterialIndentCeratDataType } from "../../model/material-indent-franchisee";
import { PaymentInfo } from "src/app/shared/model/payment-grid.model";
import { PaymentPayVal } from "src/app/shared/model/payment";
import { DateConversion, DropDownFilter, LocalString, getUrl } from "src/app/shared/app-global";
import { IndentService } from "src/app/admin/Indent/services/indent.service";
import { MaterialService } from "src/app/admin/Indent/services/material.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { Router } from "@angular/router";
import { IntlService } from "@progress/kendo-angular-intl";
import { CustomNotification } from "src/app/shared/model/shared";
import { MaterialIndentFranchiseeService } from "../../service/material-indent-franchisee.service";
import { currentStockDataType } from "src/app/admin/Stock/models/stock";
import { CommonService } from "src/app/shared/service/common.service";
import { LayoutComponent } from "src/app/layouts/layout.component";
import { CookieKey } from "src/core/helper";
import { CookieService } from "ngx-cookie-service";

@Component({
  selector: 'create',
  templateUrl: 'create.component.html',
  styleUrls: ['create.component.scss']
})
export class CreateComponent {


  /* View Child */
  // @ViewChild(PaymentGridComponent, { static: false }) childRef!: PaymentGridComponent;

  /* List */
  public LstMaterialType: materialTypeList[] = [];
  public LstMaterialName: materials[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public LstAdminStock: currentStockDataType[] = [];

  /* Model */
  public MlIndent: Materials = new Materials();
  public MlIndentCreate: MaterialIndentCreate = new MaterialIndentCreate();
  public MlMaterialIndentCreate: newMaterialIndentCeratDataType = new newMaterialIndentCeratDataType();
  public MlIndentMaterials: materialItems = new materialItems();
  public MlIndentMaterialPayment: PaymentPayVal = new PaymentPayVal();

  public materialTypes = '';
  public totalAmount: number = 0;
  public totals: number = 0;
  public maxMaterialTotal = 0;
  public currencySymbol = '';


  /* Payment Transaction */
  public paymentamount = 0;
  public ErrorNotification = 'Please enter valid Amount';
  public ErrorNotify = 'Fees amount must be equal with total amount';
  public Totalamount: number = 0;

  public CourierChargeAmount: number = 0;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  public IsShowBack: boolean = true;
  public IsOtherShowBack: boolean = false;

  /* Telerik Report Viewer */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";


  constructor(private _srvIndent: IndentService, private _srvMaterial: MaterialService, private _srvCookie: CookieService,
    private _srvNotification: NotificationService, public router: Router, private layout: LayoutComponent,
    public intlService: IntlService, public _srvMaterialIndentFranchisee: MaterialIndentFranchiseeService, private _srvCom: CommonService) { }

  ngOnInit() {
    this.getMaterialList();
    this.currencySymbol = LocalString.CurrencySymbol;

    this._srvCom.getAdminCurrentStock().subscribe({
      next: res => this.LstAdminStock = res.Data
    })

    if (getUrl.invokingUrl == '/iCloud/indent/required-list') {
      setTimeout(() => {
        this.getMaterialName();
      }, 100)
    }



    this._srvCom.getCourierChargeAmount().subscribe({ next: res => this.CourierChargeAmount = res.Data });
  }

  /* Get All Material Type & Material Name */
  getMaterialList() {
    this._srvMaterial.getMaterialTypeListAndMaterials().subscribe({
      next: (e) => this.LstMaterialType = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  getMaterialName() {
    this._srvMaterial.getMaterialTypeListAndMaterials().subscribe({
      next: (e) => {
        this.LstMaterialType = e.Data;
        this._srvIndent.selectedValue.forEach((res: any) => {
          this.MlIndentCreate.Material.MaterialType = res.MaterialType,
            this.MlIndentCreate.Material.MaterialTypeID = res.MaterialTypeID,
            this.LstMaterialType.forEach((e: any) => {
              if (e.MaterialTypeID == res.MaterialTypeID) this.MlIndentCreate.materials = e.Materials
            })

          this.MlIndentCreate.MaterialNames1.MaterialID = res.MaterialID;
          this.MlIndentCreate.MaterialNames1.MaterialName = res.MaterialName;
          this.MlIndentCreate.MaterialNames1.MaterialTypeID = res.MaterialTypeID;
          this.MlIndentCreate.materialNames = res.MaterialName;
          this.MlIndentCreate.stock = this.LstAdminStock.find(e => e.MaterialID == res.MaterialID).CurrentStock;
          this.MlIndentCreate.quantity = this.MlIndentCreate.stock && this.MlIndentCreate.stock >= res.ToIssue ? res.ToIssue : this.MlIndentCreate.stock;
          this.MlIndentCreate.price = res.Price;
          this.MlIndentCreate.gstPercent = res.GST;
          this.MlIndentCreate.isQutDis = false;
          this.MlIndentCreate.total = res.ToIssue * res.Price
          this.MlIndentCreate.gstAmount = (this.MlIndentCreate.total * this.MlIndentCreate.gstPercent) / 100;
          this.MlIndentCreate.total = this.MlIndentCreate.total + this.MlIndentCreate.gstAmount;
          this.MlIndent.materials.push(this.MlIndentCreate);
          this.MlIndentCreate = new MaterialIndentCreate();
        })
        this.totalAmount = this.MlIndent.materials.reduce((sum: any, current: any) => sum + current.total, 0);
        this.maxMaterialTotal = Math.round(this.totalAmount)
        // this.maxMaterialTotal = this.totalAmount
      },
      error: (err) => {
        new CustomNotification(this._srvNotification).ShowError(err.Message)
      }
    })
  }

  getReqMat() {
    if (this._srvIndent.selectedValue.length !== 0) {
      this._srvIndent.selectedValue.forEach((e: any) => {
        this.MlIndentCreate.MaterialType = e.MaterialType,
          this.MlIndentCreate.MaterialNames = e.MaterialName,
          this.MlIndentCreate.quantity = e.ToIssue
        this.MlIndentCreate = new MaterialIndentCreate();
      })
      this.MlIndent.materials.push(this.MlIndentCreate);
    }
  }

  /* Add New Indent */
  addNewIndent() {
    this.MlIndentCreate = new MaterialIndentCreate();
    this.MlIndent.materials.push(this.MlIndentCreate);
  }

  /* Choose Material Type */
  changeMaterialType(event: any, index: number) {
    this.MlIndent.materials[index].MaterialNames1 = null;
    this.MlIndent.materials[index].quantity = this.MlIndent.materials[index].price = this.MlIndent.materials[index].total = this.MlIndent.materials[index].gstAmount = this.MlIndent.materials[index].gstPercent = 0;
    this.totalAmountChange(index);
    this.MlIndent.materials[index].materials = event.Materials;

    if (!event) {
      this.totalAmountChange(index);
      this.MlIndent.materials[index] = new MaterialIndentCreate();
    }
    else {
      let filteredMaterials = [];

      const validation = this.MlIndent.materials.find(matItem => matItem.MaterialNames1?.MaterialName);

      this.MlIndent.materials.forEach((materialItem, index) => {
        if (event.MaterialType === materialItem.Material?.MaterialType) {

          if (validation) {
            if (materialItem.MaterialNames1?.MaterialName) event.Materials = filteredMaterials = event.Materials.filter(mat => mat.MaterialName != materialItem.MaterialNames1?.MaterialName);
            if (!materialItem.MaterialNames1?.MaterialName) {
              this.MlIndent.materials[index].materials = filteredMaterials;
            }
          } else {
            this.MlIndent.materials[index].materials = event.Materials;
          }
        }
      });
      this.MlIndent.materials[index].materials = event.Materials;
    }
  }

  get materialIndent(): IndentMaterial {
    const Indent = new IndentMaterial();
    if (this.MlIndent.materials.length) {
      this.MlIndent.materials.forEach((res) => {

        res.gstAmount = parseFloat((((res.price * res.gstPercent) / 100) * res.quantity).toFixed(2));
        res.total = parseFloat((res.gstAmount + (res.price * res.quantity)).toFixed(2));
        Indent.Amount = Indent.Amount + res.total;
      });
      Indent.TotalAmount = Indent.Amount + this.CourierChargeAmount;
    } else {
      Indent.TotalAmount = 0;
    }
    return Indent;

  }

  /* Choose Material Name */
  changeMaterialName(event: any, index: number) {
    if (!event) {
      this.totalAmountChange(index);
      this.MlIndent.materials[index].quantity = this.MlIndent.materials[index].price = this.MlIndent.materials[index].gstPercent =
        this.MlIndent.materials[index].gstAmount = this.MlIndent.materials[index].total = 0;
    }
    else {
      this.MlIndent.materials[index].stock = this.LstAdminStock.find(e => e.MaterialID == event.MaterialID).CurrentStock;

      this.MlIndent.materials[index].isQutDis = false;
      this.MlIndent.materials[index].price = event.Price;
      this.MlIndent.materials[index].gstPercent = event.GST;
    }
  }

  /* Change Instant Total Amount */
  totalAmountChange(index: number) {
    this.paymentamount = this.totalAmount = this.totalAmount - this.MlIndent.materials[index].total;
  }

  total(total: number): void {
    this.Totalamount = total;
  }

  /* Delete the Particular record */
  bntDeleteRecord(i: number, data: MaterialIndentCreate) {
    this.MlIndent.materials.splice(i, 1);
    this.MlIndent.materials.forEach(e => e.materials.push(data.MaterialNames1))
  }

  btnSubmitIndent() {
    const LstMaterial = [], LstPayment = [];
    const validation = this.MlIndent.materials.every((item: MaterialIndentCreate) => item.Material && item.MaterialNames1 && item.quantity);
    if (this.MlIndent.materials.length == 0) this.errorMsg("Minimum one indent must be added");
    else {
      if (validation) {
        if (this.Totalamount == 0) this.errorMsg("Please Add Payment");
        else if (this.materialIndent.TotalAmount !== this.Totalamount) this.errorMsg("Please enter full payment");
        else {
          this.MlMaterialIndentCreate.totalAmount = this.materialIndent.TotalAmount;
          this.MlMaterialIndentCreate.CourierAmount = this.CourierChargeAmount;
          this.MlIndent.materials.forEach((e: MaterialIndentCreate) => {
            this.MlIndentMaterials = new materialItems();
            this.MlIndentMaterials.materialID = e.MaterialNames1.MaterialID
            this.MlIndentMaterials.quantity = e.quantity;
            LstMaterial.push(this.MlIndentMaterials);
          });
          this.MlMaterialIndentCreate.materialItem = LstMaterial;

          this.PaymentDetails.forEach((e: any) => {
            this.MlIndentMaterialPayment = new PaymentPayVal();
            this.MlIndentMaterialPayment.Amount = e.Amount;
            this.MlIndentMaterialPayment.PaymentModeID = e.PaymentModeID;
            this.MlIndentMaterialPayment.PayModeType = e.PayModeType;
            this.MlIndentMaterialPayment.PayModeValue = e.PayModeValue;
            this.MlIndentMaterialPayment.FromLedgerID = e.FromLedger.LedgerID;
            this.MlIndentMaterialPayment.FromLedgerName = e.FromLedger.LedgerName;
            this.MlIndentMaterialPayment.ToLedgerID = e.ToLedger.LedgerID;
            this.MlIndentMaterialPayment.ToLedgerName = e.ToLedger.LedgerName;
            this.MlIndentMaterialPayment.TransactionNo = e.TransactionNo;
            this.MlIndentMaterialPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
            this.MlIndentMaterialPayment.BankCommission = 0;
            this.MlIndentMaterialPayment.RoundOff = 0;
            e.DocumentID ? this.MlIndentMaterialPayment.DocumentID = e.DocumentID : delete this.MlIndentMaterialPayment.DocumentID;
            LstPayment.push(this.MlIndentMaterialPayment);
          });
          this.MlMaterialIndentCreate.paymentItems = LstPayment;

          this._srvMaterialIndentFranchisee.createMaterialIndent(this.MlMaterialIndentCreate).subscribe({
            next: (e) => {
              new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
              setTimeout(() => {

                this.opened = true;
                this.title = 'Receipt';
                this.viewerContainerStyle = this.layout.viewerContainerStyle;
                this.bearerToken = this._srvCookie.get(CookieKey.Api);
                this.ServerUrl = this.layout.ServerUrl;

                const parameter = {
                  Authorization: this.bearerToken, Agent: window.navigator.userAgent, branchMaterialIndentID: e.Data
                }

                this.Reportsource = {
                  report: 'iCloud/Material_Indent_Receipt',
                  parameters: parameter
                };

              }, 500);
            },
            error: (err) => this.errorMsg(err.Message)
          })
        }
      }
      else this.errorMsg("Please fill indent details")
    }
  }

  onKeyDown(event: KeyboardEvent, field: any): void {
    const allowedKeys = [
      'Backspace', 'Tab', 'ArrowLeft', 'ArrowRight', 'Delete'
    ];

    if (allowedKeys.includes(event.key)) {
      return; // allow navigation and control keys
    }

    // Prevent non-digit input
    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
      return;
    }

    // Simulate the value after key press
    const inputEl = event.target as HTMLInputElement;
    const currentValue = inputEl.value;
    const selectionStart = inputEl.selectionStart || 0;
    const selectionEnd = inputEl.selectionEnd || 0;

    const newValue = currentValue.substring(0, selectionStart) + event.key + currentValue.substring(selectionEnd);
    const numericValue = Number(newValue);

    if (numericValue > field.stock) {
      event.preventDefault(); // prevent value above max
    }
  }


  onQuantityChange(field: any): void {
    const min = 1;
    const max = field.stock;

    // If user deletes input
    if (field.quantity === null || field.quantity === undefined || field.quantity === '') {
      field.quantity = 0; // Set to 0 if blank
      return;
    }

    // Convert to number safely
    const qty = Number(field.quantity);

    // Enforce range limits
    if (qty < min) {
      field.quantity = min;
    } else if (qty > max) {
      field.quantity = max;
    }
  }

  onQuantityBlur(field: any): void {
    if (field.quantity === null || field.quantity === undefined || field.quantity === '') {
      field.quantity = 0;
    }
  }

  reset() {
    this.PaymentDetails = this.MlIndent.materials = [];
    // this.totals = this.childRef.Totalamount = this.Totalamount = this.totalAmount = 0;
  }

  goBack() {
    this._srvMaterial.IsAction = 'list';
    this._srvMaterial.checkFranchiseeMaterialIndent = true;
    if (!this._srvMaterial.CheckMaterialIndentCreateGoBack) {
      this.router.navigate(['/iCloud/indent/required-list']);
    } else {
      this._srvMaterialIndentFranchisee.onMode.next({ mode: 'LIST' })
      this._srvMaterial.CheckMaterialIndentCreateGoBack = false;
    }
    // this.router.navigate([localStorage.getItem('createMaterial')]);

    // this.router.navigate([getUrl.invokingUrl]);
  }

  close() {
    this.opened = false;
    this.goBack();
  }

  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }

}
