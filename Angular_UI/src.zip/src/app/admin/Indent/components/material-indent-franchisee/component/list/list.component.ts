import { Component, ViewChild } from "@angular/core";
import { DateRangesComponent } from "src/app/shared/components/date-ranges/date-ranges.component";
import { FilterMaterialIndentMl, FranchiseeMaterialIndentListDataType, MaterialIndentStatus, MaterialStatus, materialIndentDate } from "../../model/material-indent-franchisee";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { DateConversion, DateSize, LocalString, getUrl, gridFontStyle } from "src/app/shared/app-global";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { PageChangeEvent, PagerPosition } from "@progress/kendo-angular-grid";
import { MaterialService } from "src/app/admin/Indent/services/material.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { NavigationEnd, Router } from "@angular/router";
import { CommonService } from "src/app/shared/service/common.service";
import { CustomNotification } from "src/app/shared/model/shared";
import { MaterialIndentFranchiseeService } from "../../service/material-indent-franchisee.service";

@Component({
  selector: 'list',
  templateUrl: 'list.component.html',
  styleUrls: ['list.component.scss']
})
export class ListComponent {


  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  public LstStatus: MaterialIndentStatus[] = MaterialStatus;
  public LstMaterialIndent: FranchiseeMaterialIndentListDataType[] = [];

  /* Model */
  public MlMaterialIndentDateFilter: materialIndentDate = new materialIndentDate();
  public MlFilterMaterialIndent: FilterMaterialIndentMl = new FilterMaterialIndentMl();

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  public currencySymbol = '';
  public dateWholePeriod!: boolean;

  public gridStyle = new gridFontStyle();

  /* Date */
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();
  WholePerStrDate: Date;
  /* Grid Pagination */
  public buttonCount = 5;
  skip = 0;
  pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";


  constructor(private _srvMaterial: MaterialService, public _srvMaterialIndentFranchisee: MaterialIndentFranchiseeService,
    private _srvNotification: NotificationService, public _router: Router, public _srvCommon: CommonService) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = true;
    this.currencySymbol = LocalString.CurrencySymbol;

    // if (this._srvMaterial.IsAction == 'list') {
    //   this.MlDateRange = this._srvMaterial.MlDateRange;
    //   this.MlMaterialIndentDateFilter.status = this._srvMaterial.Status;
    // }

    // if (this._srvMaterial.listPageSize && this._srvMaterial.listPageSkip) {
    //   this.pageSize = this._srvMaterial.listPageSize;
    //   this.skip = this._srvMaterial.listPageSkip;
    // }
    var date = new Date();
    var todate = new Date();
    var status = this.MlMaterialIndentDateFilter.status = this._srvMaterial.MllstFliterData.status == undefined ? this.LstStatus[0] : this._srvMaterial.MllstFliterData.status;

    if (this._srvMaterial.checkFranchiseeMaterialIndent) {
      date = this._srvMaterial.MllstFliterData.dateRange.startDate;
      todate = this._srvMaterial.MllstFliterData.dateRange.endDate;
      status = this._srvMaterial.MllstFliterData.status;
      this.pageSize = this._srvMaterial.listPageSize;
      this.skip = this._srvMaterial.listPageSkip;
    }

    this.getMaterialIndentList(date, todate, status);


  }

  ngAfterViewInit() {
    if (this._srvMaterial.checkFranchiseeMaterialIndent) {
      setTimeout(() => {
        this.MlDateRange = this._srvMaterial.MllstFliterData.dateRange;
        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          }
          else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        }
        else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateRange)
        }
        else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvMaterial.checkFranchiseeMaterialIndent = false;
        this._srvMaterial.listPageSize = 15;
        this._srvMaterial.listPageSkip = 0;
      });
    }
  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;
  }

  /* Choose the Date */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Date and Status Wise Filter the Material Indent */
  searchDate() {
    if (!this.MlDateRange.startDate || !this.MlDateRange.endDate) this.errorMsg("Please fill the date");
    else this.getMaterialIndentList(this.dateRanges.dateRange.startDate, this.dateRanges.dateRange.endDate, this.MlMaterialIndentDateFilter.status);
  }

  /* Get Material Indent (Franchisee) */
  getMaterialIndentList(FromDate: Date, ToDate: Date, status: any) {
    const fromDate = DateConversion.ConvertToYearMonthDate(FromDate);
    const toDate = DateConversion.ConvertToYearMonthDate(ToDate);
    var Status = status;
    Status = Status == undefined ? "ALL" : Status.Status;
    this.MlFilterMaterialIndent.FromDate = fromDate;
    this.MlFilterMaterialIndent.ToDate = toDate;
    this.MlFilterMaterialIndent.Status = Status
    this._srvMaterialIndentFranchisee.getFranchiseeMaterialIndentList(this.MlFilterMaterialIndent).subscribe({
      next: (e) => {
        this.LstMaterialIndent = e.Data;
        if (this.LstMaterialIndent.length) {
          this.LstMaterialIndent.forEach(e => {
            e.Indent.Amount = e.Indent.Amount + e.Indent.CourierAmount
          })
        }
      },
      error: (err) => this.errorMsg(err.Message)
    });
    this.lstflitervalue();
  }

  /* Go to Create Material Indent  */
  createIndent() {
    this.shareValueToService();
    this.setPagenation();
    localStorage.setItem('createMaterial', '/iCloud/indent/indent-list')
    getUrl.invokingUrl = '/iCloud/indent/indent-list';
    this._router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
      }
    });
    // this._router.navigate(['/iCloud/indent/indent-create']);
    this._srvMaterialIndentFranchisee.onMode.next({ mode: 'CREATE' })
    this._srvMaterial.CheckMaterialIndentCreateGoBack = true;
    // if (getUrl.invokingUrl == '/iCloud/indent/indent-list') document.body.classList.add('side-nav-link-ref sub-sidemenu active');
  }

  /* View the Material Indent */
  viewIndent(data: any) {
    this.shareValueToService();
    this.setPagenation();
    this._srvMaterial.materialListDataShare.subscribe((e: any) => {
      e.data = data;
    });
    // this._router.navigate(['/iCloud/indent/indent-view']);
    this._srvMaterialIndentFranchisee.onMode.next({ mode: 'VIEW' })

  }

  shareValueToService() {
    // this._srvMaterial.listPageSize = this.pageSize;
    // this._srvMaterial.listPageSize = this.skip;
    // this._srvMaterial.MlDateRange = this.MlDateRange;
    // this._srvMaterial.Status = this.MlMaterialIndentDateFilter.status == undefined ? "" : this.MlMaterialIndentDateFilter.status;
  }

  lstflitervalue() {
    setTimeout(() => {
      this._srvMaterial.MllstFliterData.dateRange.duration = this.MlDateRange.duration;
      this._srvMaterial.MllstFliterData.dateRange.startDate = this.dateRanges.dateRange.startDate;
      this._srvMaterial.MllstFliterData.dateRange.endDate = this.dateRanges.dateRange.endDate;
      this._srvMaterial.MllstFliterData.status = this.MlMaterialIndentDateFilter.status;
    }, 100)
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
  setPagenation() {
    this._srvMaterial.listPageSize = this.pageSize;
    this._srvMaterial.listPageSkip = this.skip;
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
  }

}