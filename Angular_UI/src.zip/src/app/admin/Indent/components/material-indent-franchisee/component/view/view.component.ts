import { Component } from "@angular/core";
import { FranchiseeMaterialIndentListDataType } from "../../model/material-indent-franchisee";
import { CompositeFilterDescriptor, GroupDescriptor } from "@progress/kendo-data-query";
import { Router } from "@angular/router";
import { MaterialService } from "src/app/admin/Indent/services/material.service";
import { LocalString } from "src/app/shared/app-global";
import { MaterialIndentFranchiseeService } from "../../service/material-indent-franchisee.service";
import { CookieService } from "ngx-cookie-service";
import { LayoutComponent } from "src/app/layouts/layout.component";
import { CookieKey } from "src/core/helper";
import { IntlService } from "@progress/kendo-angular-intl";

@Component({
    selector: 'view',
    templateUrl: 'view.component.html',
    styleUrls: ['view.component.scss']
})
export class ViewComponent {


    /* Model */
    public gridView: FranchiseeMaterialIndentListDataType = new FranchiseeMaterialIndentListDataType();

    public filter!: CompositeFilterDescriptor;
    public currencySymbol: string = '';
    public totalAmount: number = 0;

    /* Grid */
    public groups: GroupDescriptor[] = [{ field: 'MaterialType' }];

    /* Telerik Report Viewer */
    public viewerContainerStyle: any;
    public ServerUrl: any;
    public opened = false;
    public Reportsource: any;
    public title: string = '';
    public bearerToken = "";


    constructor(public _routes: Router, public intlService: IntlService, private _srvMaterial: MaterialService, public _srvMaterialIndentFranchisee: MaterialIndentFranchiseeService, private _srvCookie: CookieService, private layout: LayoutComponent,) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvMaterial.materialListDataShare.subscribe((e: any) => {
            this.gridView = e.data;
            this.totalAmount = this.gridView.PaymentDetails.reduce((sum: any, current: any) => sum + current.Amount, 0);
        });
    }

    /* Go to Indent List */
    back() {
        this._srvMaterial.IsAction = 'list';
        this._srvMaterial.checkFranchiseeMaterialIndent = true;
        // this._routes.navigate(['/iCloud/indent/indent-list']);
        this._srvMaterialIndentFranchisee.onMode.next({ mode: 'LIST' })
    }

    PrintReceipt() {
        this.opened = true;
        this.title = 'Receipt';
        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;

        const parameter = {
            Authorization: this.bearerToken, Agent: window.navigator.userAgent, branchMaterialIndentID: this.gridView.Indent.BranchMaterialIndentID
        }

        this.Reportsource = {
            report: 'iCloud/Material_Indent_Receipt',
            parameters: parameter
        };
    }

    close() {
        this.opened = false;
    }


}