import { Component } from "@angular/core";
import { MaterialIndentFranchiseeService } from "./service/material-indent-franchisee.service";
import { MaterialService } from "../../services/material.service";

@Component({
    selector: 'material-indent-franchisee',
    templateUrl: 'material-indent-franchisee.component.html',
    providers: [MaterialIndentFranchiseeService]
})
export class MaterialIndentFranchiseeComponent {
    mode: string;
    constructor(public _srvMaterialIndentFranchisee: MaterialIndentFranchiseeService, public _srvMaterial: MaterialService,) {
        if (_srvMaterial.CheckMaterialRequiredList) {
            this.mode = 'CREATE';
            _srvMaterial.CheckMaterialRequiredList = false;
        } else {
            _srvMaterialIndentFranchisee.onMode.subscribe(res => {
                this.mode = res.mode
            })
        }
    }
}