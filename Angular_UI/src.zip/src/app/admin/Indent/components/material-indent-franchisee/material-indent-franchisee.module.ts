import { NgModule } from "@angular/core";
import { MaterialIndentFranchiseeComponent } from "./material-indent-franchisee.component";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { CreateComponent } from "./component/create/create.component";
import { PaymentGridModule } from "src/app/shared/components/payment-grid/payment-grid.module";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { ListComponent } from "./component/list/list.component";
import { LabelModule } from "@progress/kendo-angular-label";
import { MaterialIndentFranchiseeService } from "./service/material-indent-franchisee.service";
import { ViewComponent } from "./component/view/view.component";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { CommonService } from "src/app/shared/service/common.service";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";
import { DialogModule } from "@progress/kendo-angular-dialog";

const routes: Routes = [
    {
        path: '',
        component: MaterialIndentFranchiseeComponent,

    }
];

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild(routes),

        /* Kendo Component */
        ButtonsModule,
        IconsModule,
        NavigationModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        GridModule,
        LabelModule,
        DialogModule,
        TelerikReportingModule,


        DateRangesModule,
        PaymentGridModule,
        PaymentInfoModule,

    ],
    declarations: [
        MaterialIndentFranchiseeComponent,
        CreateComponent,
        ListComponent,
        ViewComponent,
    ],
    providers: [
        MaterialIndentFranchiseeService,
        CommonService
    ]
})
export class MaterialIndentFranchiseeModule { }