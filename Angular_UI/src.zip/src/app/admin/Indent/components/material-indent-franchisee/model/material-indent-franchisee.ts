//#region  Material Create

import { materialListDataType, PaymentDetailViewListMl } from "src/app/shared/model/common";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { PaymentPayVal } from "src/app/shared/model/payment";

export class RutMode {
    mode = 'CREATE' || 'LIST' || 'VIEW';
}


export class franchiseeMaterial {
    data?: FranchiseeMaterialIndentListDataType;
}


export class materialTypeList {
    MaterialTypeID: string = '';
    MaterialType: string = '';
    Materials: materials[] = [];
}

export class materials {
    MaterialTypeID: string = '';
    MaterialID: string = '';
    MaterialName: string = '';
}

export class Materials {
    materials: MaterialIndentCreate[] = [];
}

export class MaterialIndentCreate {
    pointerId = "";
    Material: Material = new Material();
    MaterialNames1: MaterialName = new MaterialName();
    MaterialType: string = '';
    MaterialTypeID: string = '';
    materialNames: string = '';
    quantity: number = 0;
    gstPercent: number = 0;
    gstAmount: number = 0;
    price: number = 0;
    stock: number = 0;
    total: number = 0;
    isQutDis = true;
    MaterialNames: materialListDataType[] = [];
    materials: materials[] = [];
}

export class Material {
    MaterialType: string = '';
    MaterialTypeID: string = ''
}

export class MaterialName {
    MaterialID: string = '';
    MaterialName: string = '';
    MaterialType: string = '';
    MaterialTypeID: string = '';
}

export class materialCreateDataType {
    materialID: string = '';
    quantity: number = 0;
}

export class newMaterialIndentCeratDataType {
    totalAmount: number = 0;
    CourierAmount: number = 0;
    materialItem: materialItems[] = [];
    paymentItems: PaymentPayVal[] = []
}

export class materialItems {
    materialID: string = '';
    quantity: number = 0;
}

export class IndentMaterial {
    Amount: number = 0;
    TotalAmount: number = 0;
}


//#region Material Indent List (Franchisee)

export class MaterialIndentStatus {
    Status: string = "";
    Value: number = 0
}

export const MaterialStatus: MaterialIndentStatus[] = [
    {
        Status: 'ALL',
        Value: 1
    },
    {
        Status: 'RECEIVED',
        Value: 2
    },
    {
        Status: 'ORDERED',
        Value: 3
    },
    {
        Status: 'DISPATCHED',
        Value: 4
    },
]

/* Material Indent Date Wise Filter */
export class materialIndentDate {
    status: any;
    dateRange = new DateRanges();
}

/* Material Indent List */
export class FranchiseeMaterialIndentListDataType {
    Indent: franchiseeMaterialIndent = new franchiseeMaterialIndent();
    IndentTrans: franchiseeMaterialIndentTrans[] = [];
    PaymentDetails: PaymentDetailViewListMl[] = [];
}

export class franchiseeMaterialIndent {
    BranchMaterialIndentID: string = '';
    CourierAmount: number = 0;
    IndentNumber: string = '';
    IndentDate: Date = new Date();
    InvoiceNo: number = 0;
    InvoiceDate: Date = new Date();
    Total: number = 0;
    Received: number = 0;
    Pending: number = 0;
    Amount: number = 0;
    Status: string = '';
}

export class franchiseeMaterialIndentTrans {
    BranchMaterialIndentID: string = '';
    MaterialIndentTransID: string = '';
    MaterialType: string = '';
    MaterialName: string = '';
    Price: number = 0;
    Quantity: number = 0;
    GST: number = 0;
    GSTPrice: number = 0;
    Total: number = 0;
    DispatchDate: Date = new Date();
    ReceivedDate: Date = new Date();
    Status: string = '';
}

export class FilterMaterialIndentMl {
    FromDate: string = '';
    ToDate: string = '';
    Status: string = '';
}
//#endregion