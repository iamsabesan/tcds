import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { FilterMaterialIndentMl, RutMode } from "../model/material-indent-franchisee";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";

@Injectable()

export class MaterialIndentFranchiseeService {

    onMode = new BehaviorSubject<RutMode>({ mode: 'LIST' });

    constructor(public _srvHttp: HttpService) { }

    /* New Indent Create (Franchisee) */
    createMaterialIndent(data: any) {
        return this._srvHttp.post("/icloud-inventory/v1/indent/material/new", data, { RequestType: IRequestType.Protected });
    }


    /* Date and Status Wise Filter the Material Indent List (Franchisee) */
    // getFranchiseeMaterialIndentList(fromDate: string, toDate: string, status: string) {
    getFranchiseeMaterialIndentList(data: FilterMaterialIndentMl) {
        return this._srvHttp.post("/icloud-inventory/v1/indent/material/listbyfranchisee", data, { RequestType: IRequestType.Protected });
    }
}