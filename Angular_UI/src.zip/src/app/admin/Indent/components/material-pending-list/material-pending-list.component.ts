import { Component, OnInit } from '@angular/core';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { Router } from '@angular/router';
import { getUrl, gridFontStyle } from 'src/app/shared/app-global';
import { MaterialPendingList } from '../../models/material-indent';
import { IndentService } from '../../services/indent.service';
import { CustomNotification } from 'src/app/shared/model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
import { directStudentViewDataType } from 'src/app/admin/Student/models/student-profile';
import { AppService } from 'src/core/service';
import { MaterialService } from '../../services/material.service';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
@Component({
  selector: 'app-material-pending-list',
  templateUrl: './material-pending-list.component.html',
  styleUrls: ['./material-pending-list.component.scss'],
})
export class MaterialPendingListComponent implements OnInit {

  /* List */
  public LstMaterialPending: MaterialPendingList[] = [];

  /* Model */
  public gridStyle = new gridFontStyle();
  public MlStudentData: directStudentViewDataType = new directStudentViewDataType();

  /* Pagination */
  public buttonCount = 5;
  skip = 0;
  pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];

  public filter: CompositeFilterDescriptor;

  constructor(private _routes: Router, private _srvIndent: IndentService,
    private _srvNotification: NotificationService, public _srvValueShare: ValueShareService,
    public _srvApp: AppService, public _srvMaterial: MaterialService
  ) { }

  ngOnInit() {
    this._srvIndent.getMaterialPendingList().subscribe({
      next: (e) => this.LstMaterialPending = e.Data,
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });

    this.pageSize = this._srvMaterial.listPageSize;
    this.skip = this._srvMaterial.listPageSkip;
  }

  view(dataItem: any) {
    this.MlStudentData = dataItem;
    this._srvApp.val = this.MlStudentData;
    this._srvMaterial.listPageSize = this.pageSize;
    this._srvMaterial.listPageSkip = this.skip;
    this._routes.navigate(['/iCloud/student/student-profile']);
    getUrl.invokingUrl = '/iCloud/indent/pending-list';
    this._srvApp.checkStudentView = true;
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }

}
