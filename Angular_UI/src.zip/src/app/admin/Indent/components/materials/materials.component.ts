import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DropDownFilter, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { InputRegex } from 'src/app/shared/components/regex';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MaterialList, MaterialType, CreateMaterial } from '../../models/indent';
import { IndentService } from '../../services/indent.service';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-materials',
  templateUrl: './materials.component.html',
  styleUrls: ['./materials.component.scss']
})
export class MaterialsComponent {

  /* List */
  public LstMaterialType: MaterialType[] = [];
  public LstMaterialList: MaterialList[] = [];
  public LstStoreMaterialType: MaterialType[] = [];

  /* Model */
  public MlCreateMaterialList: CreateMaterial = new CreateMaterial();
  public matType: MaterialType = new MaterialType();
  public MlMaterial: MaterialList = new MaterialList();
  // public MlEditMaterial: EditMaterialMl = new EditMaterialMl();

  /* Material List Edit Options */
  public btnOptions: string[] = ['Edit', 'Active'];

  /* Material Type Selection */
  public MaterialTypeSelection: number[] = [0];

  /* Get Material TypeID */
  public materialTypeID: string = '';

  /* Dialog */
  public IsOpenListDialog: boolean = false;
  public IsOpenTypeDialog: boolean = false;
  public MatDialog:string="Add Material"

  /* Grid Filter */
  public filter: CompositeFilterDescriptor;

  /* Regex */
  public Name = InputRegex.alphaNumericOnly;

  /* Currency Symbol */
  public currencySymbol: string = '';

  /* Percentage Calculation (IGST, CGST, SGST) */
  public igstPercentange: number = 0;
  public cgstPercentage: number = 0;
  public sgstPercentage: number = 0;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('medium');

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  public checkMaterialEdit: boolean = false;

  /* Material Type */
  type = new FormGroup({
    materialType: new FormControl(null, [Validators.required])
  });

  /* Material Create */
  materialLists = new FormGroup({
    materialTypeID: new FormControl(null, [Validators.required]),
    materialNames: new FormControl(null, [Validators.required]),
    price: new FormControl(null, [Validators.required]),
    miniStock: new FormControl(null, [Validators.required]),
    opening: new FormControl(null, [Validators.required]),
    sgst: new FormControl(null, [Validators.required, Validators.min(0), Validators.max(100), Validators.maxLength(3)]),
    cgst: new FormControl(null, [Validators.required, Validators.min(0), Validators.max(100), Validators.maxLength(3)]),
    igst: new FormControl(null),
  });

  constructor(private _srvIndent: IndentService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getMaterialType();
  }

  /* Get Material Type */
  getMaterialType() {
    this._srvIndent.getMaterialType().subscribe({
      next: (res) => {
        this.LstMaterialType = this.LstStoreMaterialType = res.Data;

        if (this.LstStoreMaterialType.length !== 0) {
          this.matType = this.LstMaterialType[0];
          this.materialTypeID = this.LstStoreMaterialType[0].MaterialTypeID;
          this.getMaterialValues(this.materialTypeID);
        }
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Get Material List */
  getMaterialValues(MaterialTypeID: string) {
    this._srvIndent.getMaterial(MaterialTypeID).subscribe({
      next: (res) => this.LstMaterialList = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Material Type */
  materialTypeSelection(event: any) {
    this.matType = event.selectedRows[0].dataItem;
    this.materialTypeID = event.selectedRows[0].dataItem.MaterialTypeID
    this.getMaterialValues(this.materialTypeID);
  }

  /* Open Material Type Dialog */
  addMaterialType() {
    this.IsOpenTypeDialog = true;
  }

  /* Close Material Type Dialog */
  btnCloseMaterilaType() {
    this.btnResetMaterialType();
    this.IsOpenTypeDialog = false;
  }

  btnResetMaterialType() {
    this.type.reset();
  }

  /* Create New Material Type */
  btnSaveMaterialType(type: any) {
    if (!this.type.valid) this.type.markAllAsTouched();
    else {
      this._srvIndent.createMaterialType(type).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.btnCloseMaterilaType();
          this.getMaterialType();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* GST Calculation */
  cgst(data: number) {
    this.cgstPercentage = data;
    this.igstPercentange = this.cgstPercentage + this.sgstPercentage;
    this.materialLists.controls['igst'].setValue(this.igstPercentange);
  }

  sgst(data: number) {
    this.sgstPercentage = data;
    this.igstPercentange = this.cgstPercentage + this.sgstPercentage;
    this.materialLists.controls['igst'].setValue(this.igstPercentange);
  }

  /* Open Material List Dialog */
  addMaterialList() {
    this.IsOpenListDialog = true;
    this.materialLists.controls['materialTypeID'].setValue(this.matType.MaterialTypeID);
    this.materialLists.controls['igst'].setValue(0);
  }

  /* Reset Material List Form */
  btnResetMaterialList() {
    this.materialLists.reset();
    this.igstPercentange = this.cgstPercentage = this.sgstPercentage = 0;
    this.materialLists.controls['igst'].setValue(0);

    this.FrmEditMaterial(this.MlMaterial);

  }

  /* Close Material Type Dialog */
  btnCloseDialogMaterialList() {
    this.IsOpenListDialog = false;
    this.btnResetMaterialList();
    this.checkMaterialEdit = false;
  }

  /* Create New Material List */
  btnSaveMaterialList(data: any) {
    if (!this.materialLists.valid) this.materialLists.markAllAsTouched();
    else {
      this.MlCreateMaterialList.MaterialTypeID = typeof data.materialTypeID == "string" ? data.materialTypeID : data.materialTypeID.MaterialTypeID;
      this.MlCreateMaterialList.MaterialName = data.materialNames;
      this.MlCreateMaterialList.OpeningStock = data.opening;
      this.MlCreateMaterialList.Price = data.price;
      this.MlCreateMaterialList.MinimumStock = data.miniStock;
      this.MlCreateMaterialList.CGST = data.cgst;
      this.MlCreateMaterialList.SGST = data.sgst;
      if (this.checkMaterialEdit) {
        this.MlCreateMaterialList.materialID = this.MlMaterial.MaterialID;

        this._srvIndent.PostEditMaterial(this.MlCreateMaterialList).subscribe({
          next: (res) => {
            new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
            this.btnCloseDialogMaterialList();
            this.getMaterialValues(this.materialTypeID);
          },
          error: (err: IWebError) => this.errorMsg(err.Message)
        })

      } else {
        delete this.MlCreateMaterialList.materialID;

        this._srvIndent.createMaterial(this.MlCreateMaterialList).subscribe({
          next: (res) => {
            new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
            this.btnCloseDialogMaterialList();
            this.getMaterialValues(this.materialTypeID);
          },
          error: (err: IWebError) => this.errorMsg(err.Message)
        });
      }

    }
  }

  // view(event: string, data: MaterialList) {
  view(data: MaterialList) {
    this.MlMaterial = new MaterialList();
    this.MatDialog ="Edit Material"
    this.checkMaterialEdit = true;
    this.MlMaterial = data;
    this.FrmEditMaterial(this.MlMaterial);
    this.IsOpenListDialog = true;
  }

  FrmEditMaterial(data: MaterialList) {
    this.materialLists.controls['materialTypeID'].setValue(this.matType.MaterialTypeID);
    this.materialLists.controls.cgst.setValue(data.CGST);
    this.materialLists.controls.materialNames.setValue(data.MaterialName);
    this.materialLists.controls.miniStock.setValue(data.MinimumStock);
    this.materialLists.controls.opening.setValue(data.OpeningStock);
    this.materialLists.controls.price.setValue(data.Price);
    this.materialLists.controls.sgst.setValue(data.SGST);

    this.sgst(data.SGST);
    this.cgst(data.CGST);
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
