import { Component, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, DateSize, LocalString, gridFontStyle, ZeroGUID } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IWebError } from 'src/core/model';
import { StudentCertificateMarkUpdation, misDate, receiveCerMark, statusInfo } from '../../model/mis-report';
import { MisReportService } from '../../service/mis-report.service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { CourseCodeNameColumn, CourseListByCourseTypeMl, CourseTypeListMl } from 'src/app/shared/model/common';

@Component({
  selector: 'certificate-marksheet-list',
  templateUrl: './certificate-marksheet-list.component.html',
  styleUrls: ['./certificate-marksheet-list.component.scss']
})
export class CertificateMarksheetListComponent {


  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  public IsOpenDateRanges: boolean = false;

  /* List */
  public LstCertification: StudentCertificateMarkUpdation[] = [];
  public LstReceviceIndent: receiveCerMark[] = [];
  public LstCourseDropDown = CourseCodeNameColumn;
  public LstStatus = statusInfo;
  public LstCourseType: CourseTypeListMl[] = [];
  public LstCourse: CourseListByCourseTypeMl[] = [];

  /* Model */
  public MlCertificate: receiveCerMark = new receiveCerMark();
  public MlStatus: misDate = new misDate();
  public gridStyle = new gridFontStyle();
  public MlDateValue: DateRanges = new DateRanges();

  public MlCourseType: CourseTypeListMl = new CourseTypeListMl();
  public MlCourseValue: CourseListByCourseTypeMl = new CourseListByCourseTypeMl();

  WholePerStrDate: Date;
  /* Format */
  public dateWholePeriod: boolean;
  public dateStyle = new DateSize('medium');

  public MobileNameFilter: string = '';


  constructor(private _srvNotification: NotificationService, private _srvMisReport: MisReportService, public _srvCommon: CommonService) { }

  ngOnInit() {
    this.IsOpenDateRanges = true;
    this.dateWholePeriod = true;
    this.MlCourseType = null;

    this.MlStatus.status = this._srvMisReport.Status == undefined ? this.LstStatus[3] : this._srvMisReport.Status
    if (this._srvMisReport.certificateMarksheetCheck) {
      this.MlDateValue = this._srvMisReport.MlDateRange;
      this.MlStatus.status = this._srvMisReport.Status;
    }

    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

    const tenentBranchid = LocalString.TenantBranchID;
    this._srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
        this.dateRanges.dateRange.startDate = this.WholePerStrDate;
        this.getCertificateMIS();
      }
    })
  }

  ngAfterViewInit() {
    if (this._srvMisReport.certificateMarksheetCheck) {
      setTimeout(() => {
        this.MlDateValue = this._srvMisReport.MlDateRange;
        if (this.MlDateValue.duration && this.dateRanges.dateData) {
          if (this.MlDateValue.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateValue.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          }
          else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateValue);
          }
        }
        else if (!this.MlDateValue.duration && (this.MlDateValue.startDate && this.MlDateValue.endDate)) {
          if (this.MlDateValue.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateValue)
        }
        else {
          this.AssignDate(this.MlDateValue)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvMisReport.certificateMarksheetCheck = false;
      });
    }

  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;
  }


  /* Choose Date */
  dateChange(event: any) {
    this.MlDateValue = event;
  }

  /* View Mark */
  btnViewMark(data: any) {
    this._srvMisReport.FranchiseeMISCertificate.subscribe((e: any) => e.data = data);
    this._srvMisReport.Mode.next({ Mode: 'MARK-INFORMATION' });
  }

  /* Update the Indent Status */
  receive() {
    this.LstReceviceIndent = [];
    this.LstCertification.forEach((e: StudentCertificateMarkUpdation) => {
      if (e.Ischecked == true) {
        this.MlCertificate = new receiveCerMark();
        this.MlCertificate.examIndentTransID = e.ExamIndentTransID;
        this.MlCertificate.printType = e.Type;
        this.LstReceviceIndent.push(this.MlCertificate);
      }
    });

    const IsChecked = this.LstCertification.every((E) => E.Ischecked == false);
    if (IsChecked) this.errorMsg("Please select atleast one row");
    else {
      this._srvMisReport.receiveCertificateMarksheet(this.LstReceviceIndent).subscribe({
        next: (e) => {
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
          this.getCertificateMIS();
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Date Wise Filter the Mis Report */
  searchDate() {
    if ((!this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate) && (!this.MobileNameFilter || this.MobileNameFilter.length < 3) && (!this.MlCourseType) && (!this.MlStatus.status)) this.errorMsg("Please fill the inputs");
    else if ((!this.dateRanges.dateRange.startDate && this.dateRanges.dateRange.endDate) || (this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate)) new CustomNotification(this._srvNotification).ShowError("Invalid Date");
    else if (this.MobileNameFilter && this.MobileNameFilter.length < 3) new CustomNotification(this._srvNotification).ShowError("Invalid name / mobile");
    else this.getCertificateMIS();
  }

  /* Get Mis Report */
  getCertificateMIS() {

    const fromDate = this.dateRanges.dateRange.startDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.startDate) : '';
    const toDate = this.dateRanges.dateRange.endDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.endDate) : '';
    var Status = this.MlStatus.status == undefined || this.MlStatus.status.status == "ALL" ? "" : this.MlStatus.status.status;
    const nameOrPhone = this.MobileNameFilter ?? '';
    const courseTypeID = this.MlCourseType ? this.MlCourseType.CourseTypeID : ZeroGUID.guid;
    const shortName = this.MlCourseValue ? this.MlCourseValue.ShortName : '';

    this._srvMisReport.getStudentCertificateMisReport(fromDate, toDate, Status, courseTypeID, shortName, nameOrPhone).subscribe({
      next: (res: any) => {
        this.LstCertification = res.Data;
        this.lstflitervalue();
        this.btnReset();
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  lstflitervalue() {
    setTimeout(() => {
      this._srvMisReport.MlDateRange.duration = this.MlDateValue.duration;
      this._srvMisReport.MlDateRange.startDate = this.dateRanges.dateRange.startDate;
      this._srvMisReport.MlDateRange.endDate = this.dateRanges.dateRange.endDate;
      this._srvMisReport.Status = this.MlStatus.status;
    }, 100)
  }

  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourse = [];
    this.MlCourseValue = null;

    if (event && event.CourseTypeID) {
      this.MlCourseType = event;
      this._srvCommon.getCourseListInCourseType(event.CourseTypeID).subscribe({
        next: val => {
          this.LstCourse = val.Data || [];
        }
      });
    }
  }

  btnReset() {
    this.LstCertification.forEach((e) => e.Ischecked = false);
  }

  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
