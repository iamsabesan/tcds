import { Component } from '@angular/core';
import { gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IWebError } from 'src/core/model';
import { EditExamMark, MarkInfo, StudentCertificateMarkUpdation } from '../../model/mis-report';
import { NotificationService } from '@progress/kendo-angular-notification';
import { MisReportService } from '../../service/mis-report.service';

@Component({
  selector: 'mark-information',
  templateUrl: './mark-information.component.html',
  styleUrls: ['./mark-information.component.scss']
})

export class MarkInformationComponent {

  /* List */
  public LstUpdateMark: EditExamMark[] = [];

  /* Model */
  public MlCertificateMark: StudentCertificateMarkUpdation = new StudentCertificateMarkUpdation();
  public MlUpdateMark: EditExamMark = new EditExamMark();

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('medium');

  /* Hide 'Update' Button */
  public Status: string = '';

  /* Disabled Mark Inputs */
  public IsDisabledMarks: boolean = false;

  constructor(private _srvMisReport: MisReportService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this._srvMisReport.FranchiseeMISCertificate.subscribe((e: any) => {
      this.MlCertificateMark = e.data;
      this.Status = e.data.Status;
      this.IsDisabledMarks = this.Status.toLowerCase() === "pending" ? false : true;
    });
  }


  btnUpdate() {
    this.LstUpdateMark = [];
    this.MlCertificateMark.MarkInfo.forEach((e: MarkInfo) => {
      this.MlUpdateMark = new EditExamMark();
      this.MlUpdateMark.ExamIndentTransID = e.ExamIndentTransID;
      this.MlUpdateMark.SubjectMappingID = e.SubjectMappingID;
      this.MlUpdateMark.ObtainedTheoryMarks = e.ObtainedTheoryMarks;
      this.MlUpdateMark.ObtainedPracticalMarks = e.ObtainedPracticalMarks;
      this.LstUpdateMark.push(this.MlUpdateMark);
    });

    const IsCheckedMark = this.MlCertificateMark.MarkInfo.some((e) => (e.ObtainedTheoryMarks > e.TheoryMarks) || (e.ObtainedPracticalMarks > e.PracticalMarks))
    if (this.MlCertificateMark.MarkInfo.some((E) => !E.ObtainedTheoryMarks || !E.ObtainedPracticalMarks)) this.errorMsg("Please fill Mark");
    else if (IsCheckedMark) this.errorMsg("Please fill correct mark");
    else {
      this._srvMisReport.updateMark(this.LstUpdateMark).subscribe({
        next: (res: any) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.goBack();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  goBack() {
    this._srvMisReport.Mode.next({ Mode: 'CERTIFICATE' });
    this._srvMisReport.certificateMarksheetCheck = true;
      this._srvMisReport.IsCloseDateRanges = false
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
