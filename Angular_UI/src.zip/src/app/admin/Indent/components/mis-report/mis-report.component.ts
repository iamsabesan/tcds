import { Component } from "@angular/core";
import { MisReportService } from "./service/mis-report.service";

@Component({
    selector: 'mis-report',
    templateUrl: './mis-report.component.html',
    providers: [MisReportService]
})
export class MisReportComponent {
    public Action: string = '';
    
    constructor(private _srvMisReport: MisReportService) {
        this._srvMisReport.Mode.subscribe(e => this.Action = e.Mode);
    }
}