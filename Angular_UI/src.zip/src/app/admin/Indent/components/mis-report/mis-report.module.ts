import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { MisReportComponent } from "./mis-report.component";
import { MarkInformationComponent } from "./components/mark-information/mark-information.component";
import { CommonModule } from "@angular/common";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { GridModule } from "@progress/kendo-angular-grid";
import { LabelModule } from "@progress/kendo-angular-label";
import { TooltipsModule } from "@progress/kendo-angular-tooltip";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { MisReportService } from "./service/mis-report.service";
import { CertificateMarksheetListComponent } from "./components/certificate-marksheet-list/certificate-marksheet-list.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { PopupModule } from "@progress/kendo-angular-popup";

const routes: Routes = [
    {
        path: '',
        component: MisReportComponent
    }
]
@NgModule({
    declarations: [
        MisReportComponent,
        CertificateMarksheetListComponent,
        MarkInformationComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        FormsModule,
        ReactiveFormsModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        DateInputModule,
        GridModule,
        LabelModule,
        DateInputsModule,
        DateRangesModule,
        TooltipsModule,
        PopupModule
    ],
    providers: [MisReportService]
})
export class MisReportModule { }