export interface Mode {
    Mode: 'CERTIFICATE' | 'MARK-INFORMATION'
}

export class MISCertificate {
    data?: StudentCertificateMarkUpdation;
}

//#region MIS List
/* Certificate Status */
export const statusInfo = [
    {
        status: 'ALL',
        value: 1
    },
    {
        status: "PENDING",
        value: 2
    },
    {
        status: "PRINTED",
        value: 3
    },
    {
        status: 'DESPATCHED',
        value: 4
    },
    {
        status: "RECEIVED",
        value: 5
    },
    {
        status: "ISSUED",
        value: 6
    }
];

/* Update Receive Certificate Status */
export class receiveCerMark {
    examIndentTransID: string = '';
    printType: string = '';
}

/* Get Certificate Status */
export class misDate {
    status: any;
}
//#endregion

//#region Edit Marks
/* Edit Marks */
export class StudentCertificateMarkUpdation {
    Ischecked: boolean = false;
    ExamIndentTransID: string = '';
    IndentNumber: string = '';
    IndentDate: Date = new Date();
    DespatchDate: Date = new Date();
    ReceivedDate: Date = new Date();
    IssuedDate: Date = new Date();
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    ShortName: string = '';
    BatchNumber: string = '';
    BatchTiming: string = '';
    Semester: number = 0;
    Type: string = '';
    DeliveryMode: string = '';
    TrackingID: string = '';
    Status: string = '';
    FacultyName: string = '';
    isDisabled: boolean = false;
    MarkInfo: MarkInfo[] = [];
}

export class MarkInfo {
    ExamIndentTransID: string = '';
    SubjectName: string = '';
    SubjectMappingID: string = '';
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
}
//#endregion

/* Edit Exam Mark */
export class EditExamMark {
    ExamIndentTransID: string = "";
    SubjectMappingID: string = "";
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
}