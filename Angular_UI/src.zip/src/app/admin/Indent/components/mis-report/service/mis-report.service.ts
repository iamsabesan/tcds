import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { EditExamMark, Mode, MISCertificate } from '../model/mis-report';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { DateRanges } from 'src/app/shared/model/date-ranges';

@Injectable({
  providedIn: 'root'
})
export class MisReportService {

  public Mode = new BehaviorSubject<Mode>({ Mode: 'CERTIFICATE' });

  public FranchiseeMISCertificate = new BehaviorSubject<MISCertificate>({});

  public MlDateRange = new DateRanges();
  public Status: any;
  certificateMarksheetCheck = false;
  // i did
  public IsCloseDateRanges = true

  constructor(private _srvHttp: HttpService) { }

  receiveCertificateMarksheet(data: any) {
    return this._srvHttp.post("/icloud-admission/v1/student/certificate/receive", data, { RequestType: IRequestType.Protected });
  }

  /* Mark Edit (Franchisee) */
  updateMark(data: EditExamMark[]) {
    return this._srvHttp.post("/icloud-admission/v1/student/mark/edit", data, { RequestType: IRequestType.Protected });
  }

  getStudentCertificateMisReport(fromDate: any, toDate: any, status: string, courseTypeId: string, shortName: string, nameOrPhone: string) {
    return this._srvHttp.get(`/icloud-inventory/v1/indent/certificate/list?fromDate=${fromDate}&toDate=${toDate}&status=${status}&courseTypeId=${courseTypeId}&shortName=${shortName}&nameOrPhone=${nameOrPhone}`, { RequestType: IRequestType.Protected });
  }

}
