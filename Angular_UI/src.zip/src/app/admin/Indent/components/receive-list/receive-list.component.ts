import { Component, OnInit } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MaterialReceiveList, ReceiveMaterial, ReceiveMaterialIndent } from '../../models/material-indent';
import { IndentService } from '../../services/indent.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-receive-list',
  templateUrl: './receive-list.component.html',
  styleUrls: ['./receive-list.component.scss']
})
export class ReceiveListComponent implements OnInit {

  /* List */
  public LstReceiveMaterial: MaterialReceiveList[] = [];

  /* Model */
  public MlReceiveMaterial: ReceiveMaterial = new ReceiveMaterial();
  public MlReceiveIndent: ReceiveMaterialIndent = new ReceiveMaterialIndent();
  public gridStyle = new gridFontStyle();

  public filter!: CompositeFilterDescriptor;
  public todayDate: Date = new Date();
  public currencySymbol = '';

  /* Disabled Receive Button */
  Isbtndisabled: boolean = false;

  constructor(private _srvIndent: IndentService, private _srvNotification: NotificationService) { }
  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getReceiveMaterialIndent();
  }

  /* Get Receive Material Indent List */
  getReceiveMaterialIndent() {
    this._srvIndent.getMaterialReceivableList().subscribe({
      next: (e) => {
        this.LstReceiveMaterial = e.Data;
        this.btnResetData();
        this.Isbtndisabled = this.LstReceiveMaterial.length == 0 ? true : false;
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Set Value of IsChecked Default False */
  btnResetData() {
    this.LstReceiveMaterial.forEach((e: MaterialReceiveList) => e.IsChecked = false);
  }

  /* Update the Receive Material Indent */
  btnReceiveIndent() {
    this.MlReceiveMaterial.materialIndent = [];
    this.LstReceiveMaterial.filter((e: MaterialReceiveList) => {
      if (e.IsChecked) {
        this.MlReceiveIndent = new ReceiveMaterialIndent();
        this.MlReceiveIndent.materialIndentTransID = e.MaterialIndentTransID;
        this.MlReceiveMaterial.materialIndent.push(this.MlReceiveIndent);
      }
    });

    const IsChecked = this.LstReceiveMaterial.every(e => !e.IsChecked);
    if (IsChecked) this.errorMsg("Please select atleast one record");
    else {
      this._srvIndent.receiveMaterialIndent(this.MlReceiveMaterial).subscribe({
        next: (res: any) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.getReceiveMaterialIndent();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}