import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { getUrl, gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { materialRequiredListDataType } from '../../models/material-indent';
import { IndentService } from '../../services/indent.service';
import { IWebError } from 'src/core/model';
import { MaterialIndentFranchiseeService } from '../material-indent-franchisee/service/material-indent-franchisee.service';
import { MaterialService } from '../../services/material.service';

@Component({
  selector: 'app-required-list',
  templateUrl: './required-list.component.html',
  styleUrls: ['./required-list.component.scss']
})

export class RequiredListComponent {

  /* List */
  public LstRequiredIndent: materialRequiredListDataType[] = [];

  /* Model */
  public selectedMaterial = new materialRequiredListDataType();

  public filter!: CompositeFilterDescriptor;
  public gridStyle = new gridFontStyle('medium');

  public mySelection: number[] = [];

  constructor(private _srvNotification: NotificationService, public _srvMaterial: MaterialService, public _srvMaterialIndentFranchisee: MaterialIndentFranchiseeService, private _routes: Router, private _srvIndent: IndentService) { }

  ngOnInit() {
    this._srvIndent.selectedValue = [];
    this.getRequiredIndent();
  }

  /* Get Required Material Indent */
  getRequiredIndent() {
    this._srvIndent.getMaterialRequiredList().subscribe({
      next: (e) => {
        this.LstRequiredIndent = e.Data;
        this.btnResetData();
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  btnResetData() {
    this.LstRequiredIndent.forEach(e => e.IsChecked = false);
    this._srvIndent.selectedValue = [];
  }


  btnRequiredIndent() {
    this._srvIndent.selectedValue = [];

    this.LstRequiredIndent.filter((E) => {
      if (E.IsChecked) this._srvIndent.selectedValue.push(E)
    });

    if (this.LstRequiredIndent.every(e => !e.IsChecked)) this.errorMsg("Please select atleast one record")
    else {
      getUrl.invokingUrl = this._routes.url;
      // localStorage.setItem('createMaterial', '/iCloud/indent/required-list')
      // this._srvMaterial.onMode.next({ mode: 'CREATE' });
      this._srvMaterial.CheckMaterialIndentCreateGoBack = false;
      this._srvMaterial.CheckMaterialRequiredList = true;
      this._routes.navigate(['/iCloud/indent/indent-list']);
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
