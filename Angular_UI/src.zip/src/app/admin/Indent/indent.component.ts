import { Component } from '@angular/core';
import { IndentService } from './services/indent.service';
@Component({
  selector: 'app-indent',
  templateUrl: './indent.component.html',
  styleUrls: ["./indent.component.scss"],
})
export class IndentComponent{
  actions = '';
  constructor(public service :IndentService){}
}
