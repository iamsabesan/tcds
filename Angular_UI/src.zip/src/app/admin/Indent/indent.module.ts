import { CommonModule } from '@angular/common';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { IndentComponent } from './indent.component';
import { IndentService } from './services/indent.service';
import { ReceiveListComponent } from './components/receive-list/receive-list.component';
import { MaterialPendingListComponent } from './components/material-pending-list/material-pending-list.component';
import { RequiredListComponent } from './components/required-list/required-list.component';
import { IssuedListComponent } from './components/issued-list/issued-list.component';
import { MaterialsComponent } from './components/materials/materials.component';
import { MultiColComboComponentModule } from 'src/app/shared/components/multi-col-combo/multi-col-combo.module';
import { PaymentInfoModule } from 'src/app/shared/components/payment-info/payment-info.module';
import { RejectModule } from 'src/app/shared/components/reject/reject.module';
import { InfoModule } from 'src/app/shared/components/info/info.module';
import { UpdationService } from './services/updation.service';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { MaterialService } from './services/material.service';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { TooltipsModule } from '@progress/kendo-angular-tooltip';
// import { MarkUpdationEntryComponent } from './components/mark-updation/mark-updation.component';
import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';
import { MaterialIndentFranchiseeService } from './components/material-indent-franchisee/service/material-indent-franchisee.service';

const routes: Routes = [
  {
    path: '',
    component: IndentComponent,
    children: [
      {
        path: 'material',
        component: MaterialsComponent,
      },
      {
        path: 'material-indent-list',
        // component: MaterialIndentComponent,
        loadChildren: () => import('./components/material-indent-admin/material-indent-admin.module').then(e => e.MaterialIndentAdminModule),

      },
      {
        path: 'receivable-list',
        component: ReceiveListComponent,
      },
      {
        path: 'pending-list',
        component: MaterialPendingListComponent,
      },
      {
        path: 'required-list',
        component: RequiredListComponent,
      },
      {
        path: 'issued-list',
        component: IssuedListComponent,
      },
      {
        path: 'indent-list',
        // component: MaterialIndentListComponent,
        loadChildren: () => import('./components/material-indent-franchisee/material-indent-franchisee.module').then(e => e.MaterialIndentFranchiseeModule),

      },
      {
        path: "exam-indent",
        loadChildren: () => import('./components/exam/exam.module').then(e => e.ExamModule),
      },
      {
        path: 'ceritificate-mis',
        loadChildren: () => import('./components/mis-report/mis-report.module').then(m => m.MisReportModule),
      },
      {
        path: 'mark-updation',
        // component: MarkUpdationEntryComponent
        loadChildren: () => import('./components/mark-updation/mark-updation.module').then(m => m.MarkUpdationModule)
      },
      {
        path: 'exam-indent-list',
        loadChildren: () => import('./components/exam-indent-admin/exam-indent-admin.module').then(m => m.ExamIndentAdminModule),

      }
    ]
  }
];

@NgModule({
  declarations: [
    IndentComponent,
    ReceiveListComponent,
    RequiredListComponent,
    IssuedListComponent,
    MaterialPendingListComponent,
    MaterialsComponent,
  ],

  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    DropDownsModule,
    FormsModule,
    ReactiveFormsModule,
    DateInputModule,
    PopupModule,
    GridModule,
    LabelModule,
    DialogsModule,
    DateInputsModule,
    MultiColComboComponentModule,
    PaymentInfoModule,
    RejectModule,
    InfoModule,
    DateRangesModule,
    TelerikReportingModule,
    TooltipsModule,
    PaymentGridModule
  ],

  providers: [IndentService, UpdationService, MaterialService, MaterialIndentFranchiseeService],
  schemas: [NO_ERRORS_SCHEMA]
})
export class IndentModule { }
