import { dateRange } from "src/app/shared/model/info.model";

export class ExamIndent {
  indentDate: Date = new Date();
  indentNo: number = 0;
  Amount: number = 0;
  Total: number = 0;
  Active: number = 0;
  Inactive: number = 0;
  Status: string = '';
  Reason?: string = '';
}

export class searchExamIndent {
  fromdate: Date = new Date();
  todate: Date = new Date();
}

export class courseDetails {
  courseID: string = '';
  shortName: string = '';
  fullName: string = '';
  courseType: string = '';
  semester: number = 0;
  examFees: number = 0;
}
export class batchDetails {
  batchID: string = '';
  batchTime: string = '';
  facultyName: string = '';
}
export class studentDetails {
  studentID: string = '';
  studentName: string = '';
}

//Markupdation
export class IBatchSearch {
  Course: string = '';
  Batch: number = 0;
  BatchTime: string = '';
}
export class searchBatch {
  Batch: string = '';
}
export class IBatch {
  IsUpdated: boolean = false;
  Course: string = '';
  Batch: number = 0;
  BatchTime: string = '';
  StudentID: number = 0;
  StudentName: string = '';
  Subject: string = '';
  Semester: number = 0;
  existingTheory: number = 0;
  existingPractical: number = 0;
  TheoryMark: number = 0;
  PracticalMark: number = 0;
  Status: string = '';

}


export class ISearch {
  FromDate: Date = new Date();
  ToDate: Date = new Date();
  Status: string = '';
  dateRange!: dateRange;
}

export class misDate {
  status: any;
}

export class ICertificate {
  IsDespatched: boolean = false;
  IndentNo: number = 0;
  IndentDate: Date = new Date();
  DespatchedDate: Date = new Date();
  ReceivedDate: Date = new Date();
  IssuedDate: Date = new Date();
  StudentID: string = '';
  StudentName: string = '';
  Course: string = '';
  BatchID: string = '';
  BatchTime: string = '';
  Semester: string = '';
  DeliveryMode: string = '';
  TrackingID: string = '';
  Status: string = '';
  FacultyName: string = ''
  Type: string = '';
  MlMarkUpdation?: IMarkUpdation[] = [];
}

export class IMarkUpdation {
  Subject: string = '';
  TheoryMark: number = 0;
  PracticalMark: number = 0;
  NewTheoryMark: number = 0;
  NewPracticalMark: number = 0;
}

export class Status {
  text: string = '';
  value: number = 0;
}

export const statusInfo = [
  {
    status: 'ALL',
    value: 1
  },
  {
    status: "PENDING",
    value: 2
  },
  {
    status: "PRINTED",
    value: 3
  },
  {
    status: 'DESPATCHED',
    value: 4
  },
  {
    status: "RECEIVED",
    value: 5
  },
  {
    status: "ISSUED",
    value: 6
  }
];


//Admin Exam Indent
export class AdminIndent {
  Mode = 'list' || 'view';
}
export class adminExamIndent {
  indentDate: Date = new Date();
  indentNo: number = 0;
  franchiseeID: string = '';
  franchiseeName: string = '';
  location: string = '';
  Amount: number = 0;
  Total: number = 0;
  Active: number = 0;
  Inactive: number = 0;
}



//#region Add Exam Indent
/* Create Exam Indent */
export class CreateExamIndent {
  batchMapping: BatchMapping[] = [];
  totalAmount: number = 0;
  paymentItems: PaymentItems[] = [];
}

export class BatchMapping {
  batchMappingID: string = '';
  examFees: number = 0;
  semester: number = 0;
  examDate: string = '';
}

export class PaymentItems {
  paymentModeID: string = '';
  paymodeType: string = '';
  paymodeValue: number = 0;
  amount: number = 0;
  ledgerID: string = '';
  ledgerName: string = '';
  transactionNo: string = '';
  transactionDate: string = '';
  roundOff: number = 0;
  bankCommision: number = 0;
}

export class StudentExamIndent {
  BatchMappingID: string = '';
  studentID: string = '';
  studentName: string = '';
  course: string = '';
  semester: number = 0;
  batch: any;
  examFees: number = 0;
  examDate?: Date = new Date();
  activateDate?: Date = new Date();
  status?: string = '';
  startTime: Date = new Date();
  endTime: Date = new Date();
}

/* Course Info */
export class CourseInfoListByFranchisee {
  CourseID: string = '';
  ShortName: string = '';
  Course: string = '';
  CourseType: string = '';
  Duration: string = '';
  CourseFees: number = 0;
  ExamFees: number = 0;
  AdmissionFees: number = 0;
  TotalFees: number = 0;
}
//#endregion

export class receiveCerMark {
  examIndentTransID: string = '';
  printType: string = '';
}

/* Edit Exam Mark */
export class EditExamMark {
  ExamIndentTransID: string = "";
  SubjectMappingID: string = "";
  ObtainedTheoryMarks: number = 0;
  ObtainedPracticalMarks: number = 0;
}


/* Add Exam Indent */
export const CourseColumn = [
  {
    Field: "ShortName",
    Title: "Short Name",
    Width: 200,
  },
  {
    Field: "Course",
    Title: "Full Name",
    Width: 200,
  },
  {
    Field: "CourseType",
    Title: "Course Type",
    Width: 200
  }
];

export const BatchColumn = [
  {
    Field: "BatchNumber",
    Title: "ID",
    Width: 100
  },
  {
    Field: "Timing",
    Title: "Time",
    Width: 200,
  },
  {
    Field: "FacultyID",
    Title: "Faculty",
    Width: 200
  }
];


