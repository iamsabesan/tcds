import { materialListDataType } from "src/app/shared/model/common";

export class dateType {
  fromDate = '';
  toDate = '';
}
export class Materials {
  materials: MaterialIndentCreate[] = [];
}
export class Material {
  MaterialType: string = '';
  MaterialTypeID: string = ''
}
export class MaterialName {
  MaterialID: string = '';
  MaterialName: string = '';
  MaterialType: string = '';
  MaterialTypeID: string = '';
}
export class MaterialIndentCreate {
  pointerId = "";
  Material: Material = new Material();
  MaterialNames1: MaterialName = new MaterialName();
  MaterialType: string = '';
  MaterialTypeID: string = '';
  materialNames: string = '';
  quantity: number = 0;
  gstPercent: number = 0;
  gstAmount: number = 0;
  price: number = 0;
  total: number = 0;
  isQutDis = true;
  MaterialNames: materialListDataType[] = [];
  materials: materials[] = [];
}
export class MaterialCreate {
  materialType: string = '';
  materialName: string = '';
  price: number = 0;
  minimumStock: number = 0;
  openingStock: number = 0;
}
//Example
export interface Employee {
  id: number;
  title: string;
  name: string;
  phone: string;
  country: string;
}

//#region Material (Admin)
/* Material Type */
export class MaterialType {
  MaterialType: string = '';
  MaterialTypeID: any;
}

/* Material List */
export class MaterialList {
  MaterialID: string = '';
  MaterialName: string = '';
  Price: number = 0;
  MinimumStock: number = 0;
  OpeningStock: number = 0;
  CGST: number = 0;
  SGST: number = 0;
}

/* Create a New Material Type */
export class CreateMaterialType {
  materialType: string = '';
}

/* Create a New Material List */
export class CreateMaterial {
  materialID: string = '';
  MaterialTypeID: string = '';
  MaterialName: string = '';
  Price: number = 0;
  MinimumStock: number = 0;
  OpeningStock: number = 0;
  SGST: number = 0;
  CGST: number = 0;
}

/* Edit Material */
// export class EditMaterialMl {
//   materialID: string = '';
//   MaterialTypeID: string = '';
//   MaterialName: string = '';
//   Price: number = 0;
//   MinimumStock: number = 0;
//   OpeningStock: number = 0;
//   SGST: number = 0;
//   CGST: number = 0;
// }
//#endregion


export class materialTypeList {
  MaterialTypeID: string = '';
  MaterialType: string = '';
  Materials: materials[] = [];
}

export class materials {
  MaterialTypeID: string = '';
  MaterialID: string = '';
  MaterialName: string = '';
}
export class newMaterialIndentCeratDataType {
  materialItem: materialItems[] = [];
  totalAmount: number = 0;
  paymentItems: paymentItems[] = []
}
export class materialItems {
  materialID: string = '';
  quantity: number = 0;
}
export class paymentItems {
  paymentModeID: string = '';
  paymodeType: string = '';
  paymodeValue: number = 0;
  amount: number = 0;
  ledgerID: string = '';
  ledgerName: string = '';
  transactionNo: string = '';
  transactionDate: string = '';
  // voucherID:string='';
  roundOff: number = 0;
  bankCommision: string = '';
}