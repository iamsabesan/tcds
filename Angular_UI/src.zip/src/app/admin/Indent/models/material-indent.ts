
export class certificateMisDataShare {
    data?: StudentCertificateMarkUpdation;
}


export class materiaShareDate {
    data?: materialRequiredListDataType;
}




// /* Exam Indent List (Franchisee) */
// export class FranchiseeExamIndentList {
//     ExamIndentDetail: ExamIndentDetailDataType = new ExamIndentDetailDataType();
//     ExamIndentTransDetails: ExamIndentTransDetailsDataType[] = [];
//     PaymentDetails: paymentDetailsDataType[] = [];
// }
//#endregion

export class MarkUpdate {
    preview: number = 0;
    marks: StudentMarksUpdation[] = []
}


export class StudentMarkUpdation {
    IsChecked: boolean = false;
    isDisabled?: boolean;
    IsUpdated?: boolean;
    StudentID: string = '';
    ExamIndentTransID: string = '';
    ContactID: string = '';
    StudentName: string = '';
    BatchMappingID: string = '';
    SubjectMappingID: string = '';
    SubjectName: String = '';
    RollNumber: string = '';
    MaterialID: string = '';
    Semester: number = 0;
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
    newTheoryMarks: number = 0;
    newPracticalMarks?: number = 0;
    Status: string = '';
}
//#region Edit Marks
/* Edit Marks */
export class StudentCertificateMarkUpdation {
    Ischecked: boolean = false;
    ExamIndentTransID: string = '';
    IndentNumber: string = '';
    IndentDate: Date = new Date();
    DespatchDate: Date = new Date();
    ReceivedDate: Date = new Date();
    IssuedDate: Date = new Date();
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    BatchNumber: string = '';
    BatchTiming: string = '';
    Semester: number = 0;
    Type: string = '';
    DeliveryMode: string = '';
    TrackingID: string = '';
    Status: string = '';
    FacultyName: string = '';
    isDisabled: boolean = false;
    MarkInfo: MarkInfo[] = [];
}

export class MarkInfo {
    ExamIndentTransID: string = '';
    SubjectName: string = '';
    SubjectMappingID: string = '';
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
}
//#endregion



export class materialRequiredListDataType {
    IsChecked: boolean = false;
    MaterialID: string = '';
    MaterialName: string = '';
    ToIssue: number = 0;
    CurrentStock: number = 0;
    Required: number = 0;
    isDisabled?: boolean = false
}


//#region Student Mark Updation
export class StudentMarksUpdation {
    ExamIndentTransID: string = '';
    SubjectMappingID: string = '';
    BatchMappingID: string = '';
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
    Semester: number = 0;
}
//#endregion






//#endregion








//#endregion


//#region Receive Material
/* Receive Material List */
export class MaterialReceiveList {
    IsChecked: boolean = false;
    MaterialIndentTransID: string = '';
    IndentDate: string = '';
    IndentNumber: string = '';
    MaterialType: string = '';
    MaterialName: string = '';
    Total: number = 0;
    DespatchDate: string = '';
    DeliveryMode: string = '';
    TrackingID: string = '';
}

/* Receive Material Update */
export class ReceiveMaterial {
    materialIndent: ReceiveMaterialIndent[] = [];
}

export class ReceiveMaterialIndent {
    materialIndentTransID: string = '';
}
//#endregion


//#region Material Pending List
export class MaterialPendingList {
    StudentID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    BatchTime: string = '';
    Total: number = 0;
    Issued: number = 0;
    Pending: number = 0;
}
//#endregion


//#region Issued Material Indent
export class MaterialIssuedList {
    StudentID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    MaterialName: string = '';
    IssuedDate: string = '';
}
//#endregion