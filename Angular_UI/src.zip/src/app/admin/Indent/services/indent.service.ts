import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { AdminIndent } from '../models/exam-indent';
// import { Indent } from '../models/indent';
import { MaterialIssuedList, materialRequiredListDataType, ReceiveMaterial } from '../models/material-indent';
import { CreateMaterial, CreateMaterialType } from '../models/indent';
import { Master } from 'src/app/shared/ServiceUrl';

@Injectable()
export class IndentService {

  public selectedValue: materialRequiredListDataType[] = [];

  public adminExamIndent = new BehaviorSubject<AdminIndent>({ Mode: "list" });

  constructor(public _srvHttp: HttpService) { }

  //#region Material Type & Material List
  /* Get Material Type List */
  getMaterialType() {
    return this._srvHttp.get(Master.getMaterialType, { RequestType: IRequestType.Protected });
  }

  /* Get Material List with using Material TypeID */
  getMaterial(MaterialTypeID: string) {
    return this._srvHttp.get(`${Master.getMaterial}${MaterialTypeID}`, { RequestType: IRequestType.Protected });
  }

  /* Create Material Type */
  createMaterialType(data: CreateMaterialType) {
    return this._srvHttp.post(Master.createMaterialType, data, { RequestType: IRequestType.Protected });
  }

  /* Create Material List */
  createMaterial(data: CreateMaterial) {
    return this._srvHttp.post(Master.createMaterial, data, { RequestType: IRequestType.Protected });
  }

  /* Edit Material */
  PostEditMaterial(data: CreateMaterial) {
    return this._srvHttp.post(Master.updateMaterial, data, { RequestType: IRequestType.Protected })
  }
  //#endregion

  getMaterialPendingList() {
    return this._srvHttp.get('/icloud-inventory/v1/indent/issued/material/list', { RequestType: IRequestType.Protected });
  }

  postCreateExamIndent(data: any) {
    return this._srvHttp.post('/icloud-inventory/v1/indent/exam/create', data, { RequestType: IRequestType.Protected });
  }

  getCourseInfoListByFranchisee() {
    return this._srvHttp.get('/icloud-academic/v1/course/info/list/byfranchisee', { RequestType: IRequestType.Protected });
  }

  getMaterialRequiredList() {
    return this._srvHttp.get('/icloud-inventory/v1/indent/material/required/list', { RequestType: IRequestType.Protected });
  }

  /* Get Receive Material Indent List */
  getMaterialReceivableList() {
    return this._srvHttp.get('/icloud-inventory/v1/indent/material/receivable/list', { RequestType: IRequestType.Protected });
  }

  /* Received Updated Material Indent */
  receiveMaterialIndent(data: ReceiveMaterial) {
    return this._srvHttp.post('/icloud-inventory/v1/indent/material/received', data, { RequestType: IRequestType.Protected });
  }

  /* Get Issued Material Indent List */
  getMaterialIssueList(fromDate: string, toDate: string, nameOrPhone: string, courseTypeID: string, shortName: string) {
    return this._srvHttp.get<MaterialIssuedList>(`/icloud-inventory/v1/indent/material/issued/list?fromDate=${fromDate}&toDate=${toDate}&nameOrPhone=${nameOrPhone}&courseTypeID=${courseTypeID}&shortName=${shortName}`, { RequestType: IRequestType.Protected });
  }


}
