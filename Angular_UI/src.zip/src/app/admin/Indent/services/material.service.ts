import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { certificateMisDataShare } from '../models/material-indent';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import {  franchiseeMaterial, materialIndentDate } from '../components/material-indent-franchisee/model/material-indent-franchisee';

@Injectable()
export class MaterialService {
    public franchiseeCertificateMisShareData = new BehaviorSubject<certificateMisDataShare>({});
    public materialListDataShare = new BehaviorSubject<franchiseeMaterial>({})
    CheckMaterialIndentCreateGoBack = true;
    CheckMaterialRequiredList = false;
    MllstFliterData = new materialIndentDate();

    public MlDateRange: DateRanges = new DateRanges();
    public listPageSize: any = 15;
    public listPageSkip: any = 0;
    public Status: string = '';
    public IsAction: string = '';
    public checkFranchiseeMaterialIndent = false;
    constructor(private _srvHttp: HttpService) { }

    getFranchiseeExamIndentList(fromDate: string, toDate: string) {
        return this._srvHttp.get("/icloud-inventory/v1/indent/exam/list/byfranchisee", { params: { fromDate, toDate }, RequestType: IRequestType.Protected });
    }

    getStudentCertificateMis(fromDate: any, toDate: any, status: string) {
        return this._srvHttp.get("/icloud-inventory/v1/indent/certificate/list", { params: { fromDate, toDate, status }, RequestType: IRequestType.Protected });
    }


    getMaterialTypeListAndMaterials() {
        return this._srvHttp.get("/icloud-inventory/v1/material/types/materials", { RequestType: IRequestType.Protected });
    }





}