import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { IRequestType } from "src/core/model";
import { HttpService } from "src/core/service";
import { ICertificate, IMarkUpdation } from "../models/exam-indent";
import { MarkUpdate } from "../models/material-indent";


@Injectable()
export class UpdationService {
  public mailData = new BehaviorSubject<IMarkUpdation[]>([]);
  public CertificateInfo = new BehaviorSubject<ICertificate[]>([]);
  public data: any[] = [];

  constructor(private _srvHttp: HttpService) { }

  /* Get Student Mark Updation List (Franchisee) */
  getStudentMarkUpdationList(CourseBatchID: string) {
    return this._srvHttp.get("/icloud-admission/v1/student/mark/info", { params: { CourseBatchID }, RequestType: IRequestType.Protected });
  }

  /* Student Mark Updation (Franchisee) */
  // updateStudentMark(data: StudentMarksUpdation[]) {
  updateStudentMark(data: MarkUpdate) {
    // return this._srvHttp.post("/icloud-admission/v1/student/mark/update", data, { RequestType: IRequestType.Protected })
    return this._srvHttp.post("/icloud-admission/v1/student/preview/mark/update", data, { RequestType: IRequestType.Protected })
  }

  /* Get Student Mark Updation List (Franchisee) */
  getMarkUpdationCourseList() {
    return this._srvHttp.get("/icloud-admission/v1/batch/basicinfo/intented", { RequestType: IRequestType.Protected });
  }

}
