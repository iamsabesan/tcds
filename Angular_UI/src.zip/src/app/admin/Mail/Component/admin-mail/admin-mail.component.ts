import { Component, Output } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';
import { getUrl } from 'src/app/shared/app-global';
import { AppService } from 'src/core/service/app.service';

@Component({
  selector: 'admin-mail',
  templateUrl: './admin-mail.component.html',
  styleUrls: ['./admin-mail.component.scss']
})
export class AdminMailComponent {
  public menuList: CustomMenu[] = [];
  @Output() drawerClass = '';
  constructor(public routes: Router, private _appService: AppService) {
    this.menuList = this._appService.menus;
    this.routes.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: any) => {
      getUrl.currentUrl = event.url;
    });
  }

  ngOnInit() {
    if (getUrl.currentUrl === '/iCloud/mail/admin-mail') {
      this.drawerClass = 'k-drawer-item.k-selected';
    }
  }
} 
