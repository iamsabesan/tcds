import { Component } from '@angular/core';

@Component({
  selector: 'franchisee-mail',
  templateUrl: './franchisee-mail.component.html',
  styleUrls: ['./franchisee-mail.component.scss']
})
export class FranchiseeMailComponent {

}
 