import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { MailComponent } from './mail.component';
import { MailService } from './service/mail.service';
import { FranchiseeMailComponent } from './Component/franchisee-mail/franchisee-mail.component';
import { AdminMailComponent } from './Component/admin-mail/admin-mail.component';
import { MailboxModule } from 'src/app/shared/components/Mailbox/mailbox.module';
import { MailboxService } from 'src/app/shared/service/mailbox.service';

const routes: Routes = [
  {
    path: '',
    component: MailComponent,
    children: [
      {
        path: 'admin-mail',
        component: AdminMailComponent,
      },
      {
        path: 'franchisee-mail',
        component: FranchiseeMailComponent,
      },
    ]
  }
];

@NgModule({
  declarations: [
    MailComponent,
    FranchiseeMailComponent,
    AdminMailComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MailboxModule
  ],
  providers: [MailService,MailboxService,NotificationService],
})
export class MailModule { }
