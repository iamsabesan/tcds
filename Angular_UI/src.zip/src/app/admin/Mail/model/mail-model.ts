export class MailModel {
}
 