import { Component, HostListener } from '@angular/core';
import { DetailExpandEvent } from '@progress/kendo-angular-grid';
import { CookieService } from 'ngx-cookie-service';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global'
import { CookieKey } from 'src/core/helper/CookieKey.model';
import { PrintCertificate, ExpandedRow, ICertificationPrint, StudentIndoDataType, CertificateAndMarksheet } from '../../model/certificate-print-list.model';
import { CertificatePrintService } from '../../services/certificate-print-list.service';
import { CompositeFilterDescriptor, SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'certificate-print-list',
  templateUrl: 'certificate-print-list.component.html',
  styleUrls: ['certificate-print-list.component.scss']
})
export class CertificatePrintListComponent {

  /* List */
  public CertificationPrintList: PrintCertificate[] = [];
  public studentMarkDet: StudentIndoDataType[] = [];
  public LstStudentInfo: StudentIndoDataType[] = [];
  public MlCertificateAndMarksheetID: CertificateAndMarksheet[] = [];

  /* Model */
  public MlICertificationPrint: ICertificationPrint = new ICertificationPrint()
  public gridStyle: gridFontStyle = new gridFontStyle();
  public MlCertificateAndMarsheet: CertificateAndMarksheet = new CertificateAndMarksheet();

  /* Date & Time Format */
  public dateFormat: string = '';
  public timeFormat: string = '';
  public dateTime: string = '';
  public time: string = '';
  public isDisabled: boolean = true;

  /* Telerik Report */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened: boolean = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken: string = "";

  /* Grid Filter and Expand */
  public filter!: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];
  public expandedDetailKeys = ExpandedRow.SubjectExpanded;

  /* For Responsiveness */
  getScreenWidth: any;
  getScreenHeight: any;
  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight - 75;
  }

  constructor(
    public _srvCertificate: CertificatePrintService,
    private _srvCookie: CookieService, private layout: LayoutComponent,
    private _srvCommon: CommonService) { }

  ngOnInit() {
    this.getCertificateList();
    this.dateFormat = LocalString.DateFormat;
    this.timeFormat = LocalString.TimeFormat.replace("tt", "a");
    this.dateTime = this.dateFormat + ' ' + this.timeFormat;
  }

  getCertificateList() {
    this._srvCertificate.getCertificatePrintList().subscribe({
      next: (e) => {
        // e.Data.map((val: any) => {
        //   val.IndentDate = new Date(val.IndentDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"));
        //   val.StudentInfo.map((res: any) => {
        //     res.ExamDate = new Date(res.ExamDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"));
        //   })
        // });

        this.CertificationPrintList = e.Data;
        if (this.CertificationPrintList.length !== 0) {
          this.CertificationPrintList.filter((e: PrintCertificate) => {
            if (e.StudentInfo.length) e.StudentInfo.filter(e => e.IsChecked = false);
            e.Address = this._srvCommon.concatAddress(e)
            e.FranchiseeName = e.FranchiseeName.toUpperCase();
          });
          this.reset();
        }
      },
      error: (err) => this._srvCommon.errorMsg(err.Message)
    });
  }

  /* Expand Sub Grid */
  sortChange(sort: SortDescriptor[]) {
    this.sort = sort;
    this.loadData();
  }

  loadData() {
    this.CertificationPrintList = orderBy(this.CertificationPrintList, this.sort);
    this.CertificationPrintList.length = this.CertificationPrintList.length;
  }

  /* Course subject and other details expand */
  detailExpand(data: DetailExpandEvent) {
    this.expandedDetailKeys.push(data.dataItem.CertificateIndentID);
    ExpandedRow.SubjectExpanded = this.expandedDetailKeys = [...new Set(this.expandedDetailKeys)];
  }

  expandDetailsBy = (dataItem: any): any => {
    return dataItem.CertificateIndentID;
  }

  /* Update the certificate despatch */
  UpdateCertificateDespatch() {
    this.MlCertificateAndMarksheetID = this.LstStudentInfo = [];
    let student = [];
    student = this.CertificationPrintList.flatMap(e => e.StudentInfo || []).filter(si => si.IsChecked).map(si => ({ ...si }));
    this.LstStudentInfo = student;
    const isCheckSelected = this.LstStudentInfo.every((e) => e.IsChecked == false);
    if (isCheckSelected) this._srvCommon.errorMsg("Please select atleast one record");
    else {
      let certificate = [];
      certificate = this.LstStudentInfo.map(e => ({ CertificateAndMarksheetID: e.CertificateAndMarksheetID }));
      this.MlCertificateAndMarksheetID = certificate;
      this.updateCertificateStatus();
    }
  }


  /* Update the Certificate Status */
  updateCertificateStatus() {
    this._srvCertificate.postMarksheetPrint(this.MlCertificateAndMarksheetID).subscribe({
      next: (e) => {
        this.getCertificateList();
        this._srvCommon.errorMsg(e.Message);
        this.LstStudentInfo = [];
      },
      error: (err) => this._srvCommon.errorMsg(err.Message)
    });
  }

  changeStatus(data: any) {
    this.MlCertificateAndMarksheetID = [];
    this.MlCertificateAndMarsheet.CertificateAndMarksheetID = data.CertificateAndMarksheetID;
    this.MlCertificateAndMarksheetID.push(this.MlCertificateAndMarsheet)

    this.cerPrint(data.ExamIndentTransID, data.CourseTypeName);
  }

  updateStatus(examIndentTransID: string) {
    this._srvCertificate.getCertificatePrintValue(examIndentTransID).subscribe({
      next: (res: any) => {
        this._srvCommon.errorMsg(res.Message);
        this.getCertificateList();
      },
      error: (err) => this._srvCommon.errorMsg(err.Message)
    })
  }

  /* Open Certificate Report */
  cerPrint(ExamIndentID: string, CourseType: string) {
    this.getWindowDimesion(window);

    const ReportName = CourseType == "DIPLOMA" ? 'iCloud/Certificates' : 'iCloud/Student_Course_Certificate'

    if (ReportName == 'iCloud/Student_Course_Certificate') {

      this.opened = true;
      this.title = 'Certificate';
      this.viewerContainerStyle = this.layout.viewerContainerStyle;
      this.bearerToken = this._srvCookie.get(CookieKey.Api);
      this.ServerUrl = this.layout.ServerUrl;
      this.Reportsource = {
        report: ReportName,
        parameters: {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentTransiD: ExamIndentID
        }
      };


    } else {
      this.opened = true;
      this.title = 'Certificate';
      this.viewerContainerStyle = this.layout.viewerContainerStyle;
      this.bearerToken = this._srvCookie.get(CookieKey.Api);
      this.ServerUrl = this.layout.ServerUrl;
      this.Reportsource = {
        report: ReportName,
        parameters: {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentTransiD: ExamIndentID
        }
      };
    }
  }

  /* Reset of All Data */
  reset = () => this.CertificationPrintList.forEach((E) => E.StudentInfo.forEach((e) => e.IsChecked = false));

  /* Report Dialog Close */
  close = () => this.opened = false;
}