import { Component, HostListener } from '@angular/core';
import { DetailExpandEvent } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CookieService } from 'ngx-cookie-service';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CookieKey } from 'src/core/helper/CookieKey.model';
import { CertificateAndMarksheet, MarksheetExpandedRow, PrintCertificate, StudentIndoDataType } from '../../model/certificate-print-list.model';
import { CertificatePrintService } from '../../services/certificate-print-list.service';
import { CompositeFilterDescriptor, SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { LayoutComponent } from 'src/app/layouts/layout.component';

@Component({
  selector: 'marksheet-print-list',
  templateUrl: 'marksheet-print-list.component.html',
  styleUrls: ['marksheet-print-list.component.scss']
})
export class MarksheetPrintListComponent {

  /* List */
  public MarksheetPrintList: PrintCertificate[] = [];
  public studentMarkDet: StudentIndoDataType[] = [];
  private _lstStudentInfo: StudentIndoDataType[] = [];

  /* Model */
  public gridStyle: gridFontStyle = new gridFontStyle();
  public MlCertificateAndMarksheet: CertificateAndMarksheet = new CertificateAndMarksheet();
  public MlCertificateAndMarksheetID: CertificateAndMarksheet[] = [];

  /* Date & Time Format */
  public dateFormat: string = '';
  public timeFormat: string = '';
  public dateTime: string = '';
  public time: string = '';

  /* Telerik Report */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened: boolean = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken: string = "";

  /* Grid Filter and Expand */
  public filter!: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];
  public expandedDetailKeys = MarksheetExpandedRow.SubjectExpanded;

  /* For Responsiveness */
  getScreenWidth: any;
  getScreenHeight: any;
  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight - 75;
  }

  constructor(private _srvNotification: NotificationService,
    private _srvCertificate: CertificatePrintService,
    private _srvCookie: CookieService, private layout: LayoutComponent) { }


  ngOnInit(): void {
    this.getMaterialList();
    this.dateFormat = LocalString.DateFormat;
    this.timeFormat = LocalString.TimeFormat.replace("tt", "a");
    this.dateTime = this.dateFormat + ' ' + this.timeFormat;
  }

  /* Get the Marksheet */
  getMaterialList() {
    this._srvCertificate.getMarkSheetPrintList().subscribe({
      next: (e) => {
        // e.Data.map((val: any) => {
        //   val.IndentDate = new Date(val.IndentDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"));
        //   val.StudentInfo.map((res: any) => {
        //     res.ExamDate = new Date(res.ExamDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"));
        //   })
        // })
        this.MarksheetPrintList = e.Data;
        this.MarksheetPrintList.filter((e: any) => {
          if (e.StudentInfo.length) e.StudentInfo.filter(e => e.IsChecked = false);
          if (e.Address2 !== "" || null) {
            e.Address = e.Address1 + ", " + e.Address2 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
          } else {
            e.Address = e.Address1 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
          }
        });
        this.btnReset();
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Expand Sub Grid */
  sortChange(sort: SortDescriptor[]) {
    this.sort = sort;
    this.loadData();
  }

  loadData() {
    this.MarksheetPrintList = orderBy(this.MarksheetPrintList, this.sort);
    this.MarksheetPrintList.length = this.MarksheetPrintList.length;
  }

  /* Course subject and other details expand */
  detailExpand(data: DetailExpandEvent) {
    this.expandedDetailKeys.push(data.dataItem.CertificateIndentID);
    MarksheetExpandedRow.SubjectExpanded = this.expandedDetailKeys = [...new Set(this.expandedDetailKeys)];
  }

  expandDetailsBy(dataItem: any) {
    return dataItem.CertificateIndentID;
  }


  /* Reset Data */
  btnReset() {
    this.MarksheetPrintList.forEach((res) => res.StudentInfo.forEach((e) => e.IsChecked = false));
  }

  /* Despatch the Marksheet */
  updateMarksheet() {
    this.MlCertificateAndMarksheetID = this._lstStudentInfo = [];

    let student = [];
    this.MarksheetPrintList.filter((e) => {
      if (e.StudentInfo.length) {
        e.StudentInfo.filter((si) => {
          if (si.IsChecked) student.push(si);
        })
      }
    });

    this._lstStudentInfo = student;

    const isCheckSelected = this._lstStudentInfo.every((e) => e.IsChecked == false);
    if (isCheckSelected) this.errorMsg("Please select atleast one record");
    else {

      let certificate = [];
      this._lstStudentInfo.filter((e: StudentIndoDataType) => {
        if (e.IsChecked) {
          this.MlCertificateAndMarksheet = new CertificateAndMarksheet();
          this.MlCertificateAndMarksheet.CertificateAndMarksheetID = e.CertificateAndMarksheetID;
          certificate.push(this.MlCertificateAndMarksheet);
        }
      });
      this.MlCertificateAndMarksheetID = certificate;
      this.updateMarksheetStatus();
    }

  }

  /* Update the Marksheet Status */
  updateMarksheetStatus() {
    this._srvCertificate.postMarksheetPrint(this.MlCertificateAndMarksheetID).subscribe({
      next: (e) => {
        new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
        this.getMaterialList();
        this._lstStudentInfo = [];
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Open Telerik Report Viewer the Marksheet */
  printMarksheet(data: any) {
    this.mrkPrint(data.ExamIndentTransID);
  }

  /* Open the Telerik Report Marksheet */
  mrkPrint(ID: string) {
    this.title = 'Marksheet';
    this.opened = true;
    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;
    this.Reportsource = {
      report: 'iCloud/Marksheet',
      parameters: {
        Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentTransiD: ID
      }
    };
  }

  /* Report Dialog Close */
  close() {
    this.opened = false;
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
