import { Component } from "@angular/core";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { IWebError } from "src/core/model";
import { CommonService } from "src/app/shared/service/common.service";
import { StudentIDCardIndent } from "src/app/admin/stuent-id/component/admin/model/admin";
import { AdminService } from "src/app/admin/stuent-id/component/admin/service/admin.service";
import { CertificatePrintService } from "src/app/admin/Print/services/certificate-print-list.service";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html',
    styleUrls: ['list.component.scss']
})

export class ListComponent {

    /* List */
    public LstIDCardIndent: StudentIDCardIndent[] = [];

    /* Model */
    public gridStyle = new gridFontStyle();

    /* Grid Pagination */
    public buttonCount: number = 5;
    public sizes: any[] = [25, 50, 100, "All"];
    public info: boolean = true;
    public previousNext: boolean = true;

    public currencySymbol = '';

    constructor(private _srvAdminIDCard: AdminService,
        private _srvCommon: CommonService, private _srvPrint: CertificatePrintService) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvAdminIDCard.getStudentIDCardPrintList().subscribe({
            next: (res: any) => {
                this.LstIDCardIndent = res.Data;
                res.Data.forEach((E) => {
                    // E.franchiseeDetails.Address = E.franchiseeDetails.Area + ", " + E.franchiseeDetails.District + ", " + E.franchiseeDetails.State + " - " + E.franchiseeDetails.Pincode + '.';
                   E.franchiseeDetails.Address = this._srvCommon.concatAddress(E.franchiseeDetails)
                });
            },
            error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        })
    }

    /* View the Detail */
    btnViewDetail(data: StudentIDCardIndent) {
        this._srvPrint.MlStudentIDCardDetail = new StudentIDCardIndent();
        this._srvPrint.MlStudentIDCardDetail = data;
        this._srvPrint.Mode.next({ Mode: 'VIEW' });
    }
}