import { Component } from "@angular/core";
import { IntlService } from "@progress/kendo-angular-intl";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { DialogService } from "@progress/kendo-angular-dialog";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import { IWebError } from "src/core/model";
import { CommonService } from "src/app/shared/service/common.service";
import { CookieService } from "ngx-cookie-service";
import { LayoutComponent } from "src/app/layouts/layout.component";
import { CookieKey, CrazyKey } from "src/core/helper";
import { TelerikReportViewer } from "src/app/shared/ServiceUrl";
import { StudentDetail, StudentIDCardIndent, StudentInfo, UpdatePrintedStatus } from "src/app/admin/stuent-id/component/admin/model/admin";
import { AdminService } from "src/app/admin/stuent-id/component/admin/service/admin.service";
import { CertificatePrintService } from "src/app/admin/Print/services/certificate-print-list.service";
import { environment } from "src/environments/environment";

@Component({
    selector: 'view',
    templateUrl: 'view.component.html',
    styleUrls: ['view.component.scss']
})

export class ViewComponent {

    /* List */
    public LstStudentDetail: StudentInfo[] = [];
    public LstPayment: any[] = [];

    /* Model */
    public MlStudentIDCardDetail: StudentIDCardIndent = new StudentIDCardIndent();
    public MlStudentIDCardIndentDetail: StudentDetail = new StudentDetail();
    public gridStyle = new gridFontStyle();
    public MlUpdatePrintedStatus: UpdatePrintedStatus = new UpdatePrintedStatus();
    public MlFranchisee: any;

    /* Currecncy Symbஃol */
    public currencySymbol = '';

    /* Payment */
    public totalAmount: number = 0;
    public feesAmount: number = 0;
    public indentAmount: number = 0;
    public courierChargeAmount: number = 0;

    /* Format */
    public numberFormat: string = 'n2'
    public currencyFormat: string = 'c2'

    /* Select All Checkbox */
    public allSelected: boolean = false;
    public someSelected: boolean = false;
    public IsEnableSelectAll: boolean = false;

    /* Telerik Report Viewer */
    public viewerContainerStyle: any;
    public ServerUrl: any;
    public isOpenIDCardDialog: boolean = false;
    public Reportsource: any;
    public title: string = '';
    public bearerToken: string = '';

    /* Disable Icon */
    public isDisablePrintIcon: boolean = false

    constructor(public intlService: IntlService,
        private _srvAdminStudentIDCard: AdminService,
        private _srvDialog: DialogService,
        private _srvCommon: CommonService,
        private layout: LayoutComponent,
        private _srvCookie: CookieService, private _srvPrint: CertificatePrintService,) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this.MlStudentIDCardDetail = this._srvPrint.MlStudentIDCardDetail;
        this.MlUpdatePrintedStatus.IDCardIndentID = this._srvPrint.MlStudentIDCardDetail.IDCardIndentID;
        this._srvAdminStudentIDCard.getAdminStudentIDCardDetail(this._srvPrint.MlStudentIDCardDetail.IDCardIndentID).subscribe({
            next: (res: any) => {
                this.MlStudentIDCardIndentDetail = res.Data;
                this.LstPayment = this.MlStudentIDCardIndentDetail.PaymentDetails;
                this.LstStudentDetail = this.MlStudentIDCardIndentDetail.StudentInfo;
                this.IsEnableSelectAll = this.LstStudentDetail.some((e) => e.Status == 'PENDING' || e.Status == 'APPROVED');
                this.feesAmount = this.LstStudentDetail.reduce((sum: any, current: any) => sum + current.IDCardFees, 0);
                this.LstStudentDetail.forEach((e) => e.IsChecked = false);
                this.totalAmount = this.LstPayment.reduce((sum: any, current: any) => sum + current.Amount, 0);
                this.indentAmount = this.feesAmount + this.MlStudentIDCardIndentDetail.CourierAmount;
                this.MlFranchisee = this.MlStudentIDCardIndentDetail.franchiseeDetails;
                this.MlFranchisee.IndentNumber = this.MlStudentIDCardIndentDetail.IndentNumber;
                this.MlFranchisee.IndentDate = this.MlStudentIDCardIndentDetail.IndentDate;
                this.MlFranchisee.Status = this._srvPrint.MlStudentIDCardDetail.Status;
                this.MlFranchisee.Address = this._srvPrint.MlStudentIDCardDetail.franchiseeDetails.Address;
            },
            error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        });
    }

    /* Print ID Card */
    btnViewIDCard() {
        const BATCHMAPPINGID = this.LstStudentDetail.filter(e => e.Status.toUpperCase() == 'PENDING' || e.Status.toUpperCase() == 'APPROVED').map(data => ({ BatchMappingID: data.BatchMappingID }));
        this.isOpenIDCardDialog = true;
        this.title = 'Student ID Card';
        this.viewerContainerStyle = this.layout.viewerContainerStyle;
        this.bearerToken = this._srvCookie.get(CookieKey.Api);
        this.ServerUrl = this.layout.ServerUrl;
        const baseURL = CrazyKey.decrypt(this.layout.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
        const parameter = {
            BaseUrl: baseURL, Authorization: this.bearerToken, Agent: window.navigator.userAgent, BatchMappingID: JSON.stringify(BATCHMAPPINGID)
        }

        this.Reportsource = {
            report: TelerikReportViewer.getStudentIDCard,
            parameters: parameter
        };
    }


    /* Reject Indent */
    btnRejectIndent() {
        const dialogRef = this._srvDialog.open({
            title: 'Reject Student ID Card Indent',
            content: RejectComponent,
            width: 400
        })

        const rejectComponentInstance = dialogRef.content.instance as RejectComponent;
        rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
            this._srvAdminStudentIDCard.rejectIndent(this._srvPrint.MlStudentIDCardDetail.IDCardIndentID, formData.Reason).subscribe({
                next: (res: any) => {
                    this._srvCommon.successMsg(res.Message);
                    setTimeout(() => {
                        this.btnGoBack();
                    }, 500);
                },
                error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
            });
        });
    }

    /* Approve Student ID Card Indent */
    btnApprove() {
        const approveIndent = { "IDCardIndentID": this._srvPrint.MlStudentIDCardDetail.IDCardIndentID };
        this._srvAdminStudentIDCard.approveIndent(approveIndent).subscribe({
            next: (res: any) => {
                this._srvCommon.successMsg(res.Message);
                setTimeout(() => {
                    this.btnGoBack();
                }, 500);
            },
            error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        })
    }


    // Toggle all items
    selectAllCheckBox(event: any): void {
        const checked = event.target.checked;
        this.LstStudentDetail.filter(item => {
            if (item.Status.toUpperCase() == 'PENDING' || item.Status.toUpperCase() == 'APPROVED') item.IsChecked = checked;
        });
        this.updateSelectionState();
    }

    // Update header checkbox states
    updateSelectionState(): void {
        this.MlUpdatePrintedStatus.TransIDs = [];
        this.MlUpdatePrintedStatus.TransIDs = this.LstStudentDetail.filter(item => item.IsChecked).map((e) => ({ IDCardIndentTransID: e.IDCardIndentTransID }));
        this.allSelected = this.MlUpdatePrintedStatus.TransIDs.length === this.LstStudentDetail.filter((e) => (e.Status.toUpperCase() == 'PENDING') || (e.Status.toUpperCase() == 'APPROVED')).length;
        this.someSelected = this.MlUpdatePrintedStatus.TransIDs.length > 0 && !this.allSelected;
    }

    /* Student ID Card Printed Status Updated */
    btnPrintIDCard() {
        this._srvAdminStudentIDCard.updatePrintedStatus(this.MlUpdatePrintedStatus).subscribe({
            next: (res: any) => {
                this._srvCommon.successMsg(res.Data);
                setTimeout(() => {
                    this.btnGoBack();
                }, 500);
            },
            error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        });
    }

    btnGoBack() {
        this._srvPrint.Mode.next({ Mode: 'LIST' });
    }
}