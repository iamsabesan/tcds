import { Component } from "@angular/core";
import { CertificatePrintService } from "../../services/certificate-print-list.service";

@Component({
    selector: 'student-id',
    templateUrl: 'student-id.component.html',
    providers: [CertificatePrintService]
})

export class StudentIdComponent {


    public Actions: string = '';

    constructor(private _srvPrint: CertificatePrintService) {
        this._srvPrint.Mode.subscribe(res => this.Actions = res.Mode)
    }
}