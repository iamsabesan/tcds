import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { GridModule } from "@progress/kendo-angular-grid";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";
import { AdminService } from "src/app/admin/stuent-id/component/admin/service/admin.service";
import { InfoModule } from "src/app/shared/components/info/info.module";
import { CertificatePrintService } from "../../services/certificate-print-list.service";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { StudentIdComponent } from "./student-id.component";

const routes: Routes = [
    {
        path: '',
        component: StudentIdComponent,
    }
]

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,

        /* Kendo Component */
        GridModule,
        TelerikReportingModule,
        DialogsModule,
        ButtonsModule,
        InputsModule,
        LayoutModule,
        IconsModule,
        NavigationModule,

        InfoModule,
    ],
    declarations: [
        ListComponent,
        ViewComponent,
        StudentIdComponent
    ],
    providers: [
        AdminService,
        CertificatePrintService
    ]
})

export class StudentIDModule {

}