export class ICertificationPrint {
  IndentDate = new Date();
  IndentNo: number = 0;
  FranchieeseID: string = '';
  FranchieeseName: string = '';
  FranchieeseLocation: string = '';
  ExamDate = new Date();
  TotalStudent?: number = 0;
  PrintedStudent?: number = 0;
  PendingStudent?: number = 0;
  Status: string = '';
  MlStudent: IStudent[] = [];

}
export class IStudent {
  StudentID: string = '';
  StudentName: string = '';
  Course: string = '';
  Semester: string = '';
  Batch: string = '';
  TotalMarks: number = 0;
  Grade?: string = '';
  TheoryMark?: number = 0;
  PracticalMark?: number = 0;
  Status: string = '';
}
export class ExpandedRow {
  static SubjectExpanded: string[] = [];
}

export class MarksheetExpandedRow {
  static SubjectExpanded: string[] = [];
}

export const LstCertificationPrint: ICertificationPrint[] = [
  {
    IndentDate: new Date(2023, 2, 11, 2, 10, 34),
    IndentNo: 1,
    FranchieeseID: '00001',
    FranchieeseName: 'TCDS Computer Education',
    FranchieeseLocation: 'Ariyanoor,Salem',
    ExamDate: new Date(2023, 5, 3),
    TotalStudent: 2,
    PrintedStudent: 2,
    PendingStudent: 0,
    Status: 'Printed',
    MlStudent: [
      {
        StudentID: '0421AC001',
        StudentName: 'Hema Sri',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 480,
        Grade: 'First',
        TheoryMark: 430,
        PracticalMark: 50,
        Status: 'Printed',
      },
      {
        StudentID: '0421AC002',
        StudentName: 'Anis Pathima',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 425,
        Grade: 'First',
        TheoryMark: 350,
        PracticalMark: 75,
        Status: 'Printed',
      }
    ]
  },
  {

    IndentDate: new Date(2023, 2, 11, 2, 10, 34),
    IndentNo: 2,
    FranchieeseID: '00002',
    FranchieeseName: 'TCDS Computer Education',
    FranchieeseLocation: 'Pollachi,Coimbatore',
    ExamDate: new Date(2023, 5, 3),
    TotalStudent: 2,
    PrintedStudent: 0,
    PendingStudent: 2,
    Status: 'Pending',
    MlStudent: [
      {
        StudentID: '0421AC001',
        StudentName: 'Hema Sri',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 450,
        Grade: 'First',
        TheoryMark: 400,
        PracticalMark: 50,
        Status: 'Pending',
      },
      {
        StudentID: '0421AC002',
        StudentName: 'Anis Pathima',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 450,
        Grade: 'First',
        TheoryMark: 430,
        PracticalMark: 20,
        Status: 'Pending',
      }
    ]
  },
  {

    IndentDate: new Date(2023, 2, 11, 2, 10, 34),
    IndentNo: 3,
    FranchieeseID: '00003',
    FranchieeseName: 'TCDS Computer Education',
    FranchieeseLocation: 'Guindy,Chennai',
    ExamDate: new Date(2023, 5, 3),
    TotalStudent: 3,
    PrintedStudent: 0,
    PendingStudent: 3,
    Status: 'Pending',
    MlStudent: [
      {
        StudentID: '0421AC001',
        StudentName: 'Hema Sri',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 450,
        Grade: 'First',
        TheoryMark: 430,
        PracticalMark: 20,
        Status: 'Pending',
      },
      {
        StudentID: '0421AC002',
        StudentName: 'Anis Pathima',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 450,
        Grade: 'First',
        TheoryMark: 418,
        PracticalMark: 32,
        Status: 'Pending',
      },
      {
        StudentID: '0421AC003',
        StudentName: 'Jeenath',
        Course: 'Web Development',
        Semester: '1/1',
        Batch: '10:00 AM - 12:00 PM',
        TotalMarks: 460,
        Grade: 'First',
        TheoryMark: 400,
        PracticalMark: 60,
        Status: 'Pending',
      }
    ]
  }
]

//#region  Print  Certificate & Marksheet
export class PrintCertificate {
  CertificateIndentID: string = '';
  IndentDate: string = '';
  IndentNumber: string = '';
  TenantBranchID: string = '';
  FranchiseeID: string = '';
  FranchiseeName: string = '';
  Address1: string = '';
  Address?: string = '';
  Address2: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Area: string = '';
  Pincode: string = '';
  Total: number = 0;
  Printed: number = 0;
  Pending: number = 0;
  Status: string = '';
  StudentInfo: StudentIndoDataType[] = [];
}

export class StudentIndoDataType {
  IsChecked: boolean = false;
  StudentID: string = '';
  ExamIndentTransID: string = '';
  CertificateAndMarksheetID: string = '';
  RollNumber: string = '';
  StudentName: string = '';
  Course: string = '';
  CourseTypeName: string = '';
  Semester: string = '';
  ExamDate: Date | string = new Date();
  Batch: string = '';
  Type: string = '';
  ToatlMarks: number = 0;
  TheoryMarks?: number = 0;
  PracticalMarks?: number = 0;
  Grade: string = '';
  Status: string = '';
}

/* Update the Certificate & Marksheet Status */
export class CertificateAndMarksheet {
  CertificateAndMarksheetID: string = "";
}
//#endregion