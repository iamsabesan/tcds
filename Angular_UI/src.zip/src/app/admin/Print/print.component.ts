import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'certificate-print',
  templateUrl: 'print.component.html',
})
export class CertificatePrintComponent implements OnInit {

  constructor() {

  }
  ngOnInit(): void {

  }

}
