import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { CertificatePrintListComponent } from './components/certificate-print-list/certificate-print-list.component';
import { MarksheetPrintListComponent } from './components/marksheet-print-list/marksheet-print-list.component';
import { CertificatePrintComponent } from './print.component';
import { CertificatePrintService } from './services/certificate-print-list.service';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';

const routes: Routes = [
  {
    path: '',
    component: CertificatePrintComponent,
    children: [
      {
        path: 'certificate-print-list',
        component: CertificatePrintListComponent
      },
      {
        path: 'marksheet-print-list',
        component: MarksheetPrintListComponent
      },
      {
        path: 'student-ID-card',
        loadChildren: () => import('./components/student-id/student-id.module').then(m => m.StudentIDModule)
      }
    ]
  }
];


@NgModule({
  declarations: [
    CertificatePrintComponent,
    CertificatePrintListComponent,
    MarksheetPrintListComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
    FormsModule,

    /* Kendo Component */
    GridModule,
    TelerikReportingModule,
    DialogsModule,
    ButtonsModule,
    InputsModule,
  ],
  providers: [CertificatePrintService],
})
export class CertificatePrintListModule { }
