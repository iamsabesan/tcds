import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { StudentIDCardIndent } from '../../stuent-id/component/admin/model/admin';
// import { UpdatePrintStatus } from '../model/certificate-print-list.model';

@Injectable({
    providedIn: 'root'
})
export class CertificatePrintService {

    public Mode = new BehaviorSubject({ Mode: 'LIST' });
    MlStudentIDCardDetail = new StudentIDCardIndent();

    public certificatePrintListUrl = "/icloud-admission/v1/student/certificate/print/list";
    public markSheetPrintListUrl = "/icloud-admission/v1/student/marksheet/print/list";
    public marksheetPrintUrl = "/icloud-admission/v1/student/print";
    constructor(public http_service: HttpService) { }

    getCertificatePrintList() {
        return this.http_service.get(this.certificatePrintListUrl, { RequestType: IRequestType.Protected });
    }

    getMarkSheetPrintList() {
        return this.http_service.get(this.markSheetPrintListUrl, { RequestType: IRequestType.Protected });
    }

    /* Update the Certificate Status */
    postMarksheetPrint(MlUpdatePrintStatus: any) {
        return this.http_service.post("/icloud-admission/v1/student/print", MlUpdatePrintStatus, { RequestType: IRequestType.Protected });
    }

    getCertificatePrintValue(IntentID: string) {
        return this.http_service.get(`/icloud-admission/v1/student/certificate/print?examIndentTransiD=${IntentID}`, { RequestType: IRequestType.Protected })
    }

    /* 28-11-2025 (Ramesh) */
    updatePrintedStatus(examIndentTransID: string, printType: string) {
        return this.http_service.post(`/icloud-admission/v1/student/print?examIndentTransID=${examIndentTransID}&printType=${printType}`, { RequestType: IRequestType.Protected });
    }
} 