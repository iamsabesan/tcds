import { NgModule } from "@angular/core";
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { GridModule } from "@progress/kendo-angular-grid";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { RePrintingService } from "./service/re-printing.service";
import { RouterModule, Routes } from "@angular/router";
import { LabelModule } from "@progress/kendo-angular-label";
import { PaymentGridModule } from "src/app/shared/components/payment-grid/payment-grid.module";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";

const routes: Routes = [
    {
        path: '',
        component: CreateComponent
    }
]

@NgModule({
    declarations: [
        ListComponent,
        CreateComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(routes),

        ButtonsModule,
        InputsModule,
        LayoutModule,
        GridModule,
        NavigationModule,
        DropDownsModule,
        LabelModule,
        TelerikReportingModule,

        PaymentGridModule
    ],
    exports: [],
    providers: [RePrintingService],
})
export class ReprintingModule { }
