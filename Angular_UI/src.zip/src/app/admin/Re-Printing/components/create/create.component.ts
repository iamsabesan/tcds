import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { LocalString, Virtual, gridFontStyle, DateConversion } from 'src/app/shared/app-global';
import { CourseColumn, MultiDropdownColumn, StudentColumn } from 'src/app/shared/model/common';
import { CommonService } from 'src/app/shared/service/common.service';
import { IWebError } from 'src/core/model';
import { RePrintingService } from '../../service/re-printing.service';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';
import { CourseDetail, EditExamMark, MarkSheetCertificate, MarkUpdate, ReprintingMl, Student, StudentMarkPrint, StudentMarksUpdation, StudentReprintingMl, Subject } from '../../model/re-printing';
import { IntlService } from '@progress/kendo-angular-intl';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CookieService } from 'ngx-cookie-service';
import { CookieKey } from 'src/core/helper';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { PaymentPayVal } from 'src/app/shared/model/payment';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent {

  /* List */
  public LstStudent: Student[] = [];
  public LstTempStudent: Student[] = [];
  public LstCourse: CourseDetail[] = [];
  public LstMarkCertificateStudent: any[] = [];
  public LstMarkUpdation: Subject[] = [];
  public LstMarkCertification: MarkSheetCertificate[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public LstMarkUpdate: StudentMarksUpdation[] = []
  public LstMarkUpdation1: Subject[] = [];
  public LstFinalUpdateMark: EditExamMark[] = [];

  /* Multi Dropdown Column */
  public StudentColumns: MultiDropdownColumn[] = StudentColumn;
  public CourseColumns: MultiDropdownColumn[] = CourseColumn;

  /* Model */
  public gridHeaderStyle = new gridFontStyle('medium');
  public MlMarkSheetCertificate: MarkSheetCertificate = new MarkSheetCertificate();
  public MlMarkSheet: Subject = new Subject();
  public MlStudentMarkUpdate: MarkUpdate = new MarkUpdate();
  public virtual = Virtual.virtual;
  public MlStudentReprinting: StudentReprintingMl = new StudentReprintingMl();

  /* Student Form Value */
  public studentValue: any = undefined;

  //#region Form
  FrmEntry = new FormGroup({
    StudentName: new FormControl(null, [Validators.required]),
    Course: new FormControl(null, [Validators.required]),
    Type: new FormControl('Marksheet', [Validators.required]),
  });

  StudentFrm = new FormGroup({
    StudentName: new FormControl(null, [Validators.required])
  });
  //#endregion


  /* Student Detail */
  public filteredValue = '';
  public timerStop: any;

  /* Currency Symbol */
  public CurrencySymbol: string = ''

  /* Disable Add Button */
  public IsDisableAddButton: boolean = false;

  /* Re-Printing Amount */
  public totalFees: number = 0;
  public CourierChargeAmount: number = 0;
  public TotalAmount: number = 0;


  /* Payment Details */
  public paymentamount: number = 0;
  public ErrorNotification: string = 'Please enter valid Amount';
  public ErrorNotify: string = 'Fees amount must be equal with total amount';
  public Totalamount: number = 0;
  public Balanceamount: number = 0;
  public disbledDepositFrom = true;


  /* Telerik Report */
  public dataList: any;
  public viewerContainerStyle: any;
  public bearerToken: string = "";
  public ServerUrl: any;
  public CertificateCertificateReportsource: any;
  public DiplomaCertificateReportsource: any;
  public SummerCertificateReportsource: any;
  public MarksheetReportsource: any;

  //#region Stepper
  public currentStep: number = 0;
  public step = [
    {
      label: 'Student Detail',
      disabled: false
    },
    {
      label: 'Marksheet',
      disabled: false
    },
    {
      label: 'Certificate',
      disabled: false
    },
    {
      label: 'Payment',
      disabled: false
    }
  ];
  //#endregion

  StudentFilter: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
    fields: this.StudentColumns.map((e) => e.Field)
  };

  CourseFilter: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
    fields: this.CourseColumns.map((e) => e.Field)
  };

  constructor(private _srvCommon: CommonService,
    private _srvReprinting: RePrintingService,
    public currencyService: IntlService,
    private _layout: LayoutComponent,
    private _srvCookie: CookieService,) { }

  ngOnInit() {
    // this.viewerContainerStyle = this._layout.viewerContainerStyle;
    // this.ServerUrl = this._layout.ServerUrl;
    // this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.CurrencySymbol = LocalString.CurrencySymbol;
    this.resetFrmValue();
    this.InitalDataLoad();
  }

  InitalDataLoad() {
    this._srvCommon.getCourierChargeAmount().subscribe(res => this.CourierChargeAmount = res.Data);

    this._srvReprinting.getStudentDetail().subscribe({
      next: (res: any) => this.LstStudent = this.LstTempStudent = res.Data,
      error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
    });
  }

  resetFrmValue() {
    this.FrmEntry.reset();
    this.FrmEntry.controls['Type'].setValue('Marksheet');
  }

  onFilterChange(value: string): void {
    this.filteredValue = value;
    if (!value || value.trim() === '') {
      this.LstStudent = [];
    }
  }

  /* Student ID, Name, Mobile any one of them is required */
  onKeyDown(): void {
    clearTimeout(this.timerStop);

    this.timerStop = setTimeout(() => {
      const query = this.filteredValue;
      if (query && query.length > 3) {
        this._srvReprinting.getStudentDetail().subscribe({
          next: (res: any) => {
            this.LstStudent = res?.Data || [];
            this.LstTempStudent = [...this.LstStudent];
          },
          error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        });
      }
      else this.LstStudent = this.LstTempStudent = [];
    }, 500);
  }

  /* Select the student */
  studentSelection(data: Student): void {
    this.FrmEntry.controls['Course'].setValue(null);
    this.LstCourse = [];
    if (data) this.LstCourse = data.CourseDetails;
  }
  public LstStudentMarkCertification: StudentMarkPrint[] = [];

  /* Add Marksheet / Certificate */
  btnAdd() {
    if (this.FrmEntry.invalid) this.FrmEntry.markAllAsTouched();
    else {
      const FrmValue = this.FrmEntry.value;
      const IsUser = this.LstMarkCertification.some((e => e.RollNumber == FrmValue.StudentName?.RollNumber && e.CourseName == FrmValue.Course?.CourseName && e.PrintType == FrmValue.Type && e.Semester == FrmValue.Course.Semester));
      if (IsUser) this._srvCommon.latererrorMsg("Student already has a marksheet/certificate for this type.");
      else {
        this._srvReprinting.getStudentCourseDetail(FrmValue.Course.BatchMappingID, FrmValue.Course.Semester).subscribe({
          next: (res: any) => {
            const CourseDetail: StudentMarkPrint[] = res.Data;

            if (FrmValue.Type == 'Certificate') {
              CourseDetail.forEach((e) => {
                this.MlMarkSheetCertificate = new MarkSheetCertificate();
                this.MlMarkSheetCertificate.RollNumber = e.RollNumber
                this.MlMarkSheetCertificate.StudentName = FrmValue.StudentName?.StudentName;
                this.MlMarkSheetCertificate.Semester = e.Semester;
                this.MlMarkSheetCertificate.CourseCode = FrmValue.Course?.ShortName;
                this.MlMarkSheetCertificate.CourseName = e.CourseName;
                this.MlMarkSheetCertificate.CourseType = FrmValue.Course?.CourseType;
                this.MlMarkSheetCertificate.Semester = e.Semester;
                this.MlMarkSheetCertificate.PrintType = FrmValue.Type;
                this.MlMarkSheetCertificate.ReprintCharges = FrmValue.Course.ReprintCharges;
                this.MlMarkSheetCertificate.ExamIndentTransID = e.ExamIndentTransID;
                this.MlMarkSheetCertificate.BatchMappingID = e.BatchMappingID;
                this.LstMarkCertification.push(this.MlMarkSheetCertificate);
              })
            }

            else {
              this.MlMarkSheet = new Subject();
              CourseDetail.forEach((e) => this.LstMarkUpdation = e.Subjects)
              this.LstMarkUpdation.forEach((e) => {
                e.RollNumber = FrmValue.StudentName?.RollNumber;
                e.StudentName = FrmValue.StudentName?.StudentName;
                e.Semester = CourseDetail[0].Semester;
                e.CourseCode = FrmValue.Course.ShortName;
                e.CourseName = FrmValue.Course.CourseName;
                e.CourseType = FrmValue.Course.CourseType;
                e.ReprintCharges = FrmValue.Course.ReprintCharges;
                e.ExamIndentTransID = CourseDetail[0].ExamIndentTransID;
                e.BatchMappingID = CourseDetail[0].BatchMappingID;
              });

              this.IsDisableAddButton = this.LstMarkUpdation.length ? true : false;
            }
          },
          error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        });
      }

    }
  }

  /* Stepper Activate */
  stepActivate(e: StepperActivateEvent) {
    if (this.FrmEntry.invalid) {
      e.preventDefault();
      this.FrmEntry.markAllAsTouched();
    }
  }

  btnResetMark() {
    this.LstMarkUpdation = [];
    this.IsDisableAddButton = false;
  }

  AddMark() {
    // this.LstMarkCertification.push();
    const IsChecked = this.LstMarkUpdation.some(e => !e.ObtainedTheoryMarks && !e.ObtainedPracticalMarks);
    const IsTheoryMarkCheck = this.LstMarkUpdation.some(e => e.ObtainedTheoryMarks > e.TheoryMark);
    const IsPracticalMarkCheck = this.LstMarkUpdation.some(e => e.ObtainedPracticalMarks > e.PracticalMark);
    const IsMarkLessThan = this.LstMarkUpdation.some(e => (e.ObtainedTheoryMarks || e.ObtainedPracticalMarks) < 0);

    if (IsChecked) this._srvCommon.errorMsg("Mark cannot be empty");
    else if (IsTheoryMarkCheck) this._srvCommon.errorMsg("Mark cannot be greater than actual Theory Mark");
    else if (IsPracticalMarkCheck) this._srvCommon.errorMsg("Mark cannot be greater than actual Practical Mark");
    else if (IsMarkLessThan) this._srvCommon.errorMsg("Mark cannot be less than zero");
    else {
      this.MlMarkSheet = new Subject();
      this.MlMarkSheet.RollNumber = this.LstMarkUpdation[0].RollNumber;
      this.MlMarkSheet.ExamIndentTransID = this.LstMarkUpdation[0].ExamIndentTransID;
      this.MlMarkSheet.StudentName = this.LstMarkUpdation[0].StudentName;
      this.MlMarkSheet.CourseCode = this.LstMarkUpdation[0].CourseCode;
      this.MlMarkSheet.CourseName = this.LstMarkUpdation[0].CourseName;
      this.MlMarkSheet.CourseType = this.LstMarkUpdation[0].CourseType;
      this.MlMarkSheet.Semester = this.LstMarkUpdation[0].Semester;
      this.MlMarkSheet.PrintType = 'Marksheet';
      this.MlMarkSheet.ReprintCharges = this.LstMarkUpdation[0].ReprintCharges;
      this.LstMarkCertification.push(this.MlMarkSheet as any);

      if (this.LstMarkUpdation.length) {
        this.LstMarkUpdation.forEach(mark => {
          const index = this.LstMarkUpdation1.findIndex(mark1 =>
            mark.SubjectMappingID === mark1.SubjectMappingID &&
            mark.ExamIndentTransID === mark1.ExamIndentTransID &&
            mark.SubjectName === mark1.SubjectName
          );

          if (index !== -1) {
            this.LstMarkUpdation1.splice(index, 1, mark);
          } else {
            this.LstMarkUpdation1.push(mark);
          }
        });
      }
      this.LstMarkUpdation = [];
      this.IsDisableAddButton = this.LstMarkUpdation.length ? true : false;
    }
  }

  deleteRow(index: number) {
    this.LstMarkCertification.splice(index, 1);
  }

  /* Marksheet / Certificate Student Selection */
  studentMakSelection(event: any) {
    this.studentValue = event;
  }

  searchStudent() {
    if (this.StudentFrm.invalid) this.StudentFrm.markAllAsTouched();
    else { }
  }

  /* Remanining Balance */
  total(total: number): void {
    this.Totalamount = total;
  }

  /* Previous Step */
  btnPrev() {
    // this.currentStep -= 1;
    if (this.step[this.currentStep - 1].disabled === true) this.currentStep = this.currentStep - 2;
    else this.currentStep = this.currentStep - 1;
  }

  /* Next Step */
  btnNext() {
    if (this.FrmEntry.valid && this.LstMarkCertification.length && !this.LstMarkUpdation.length) {
      const marksheet = this.LstMarkCertification.some(record => record.PrintType === 'Marksheet')
      const certificate = this.LstMarkCertification.some(record => record.PrintType === 'Certificate')
      if (this.currentStep == 0 && (marksheet && certificate)) this.step.forEach((E) => E.disabled = false);
      else if (this.currentStep == 0 && this.LstMarkCertification.some((e) => e.PrintType !== 'Certificate')) this.step[2].disabled = true;
      else if (this.currentStep == 0 && this.LstMarkCertification.some((e) => e.PrintType !== 'Marksheet')) this.step[1].disabled = true;

      // this.currentStep += this.step[this.currentStep + 1].disabled === true ? 2 : 1;
      this.totalFees = this.LstMarkCertification.reduce((sum, total) => sum + total.ReprintCharges, 0);
      this.TotalAmount = this.CourierChargeAmount + this.totalFees;
      this.paymentamount = this.TotalAmount;

      const LstMarkUpdation = this.LstMarkCertification.filter(e => e.PrintType.toLowerCase() === 'marksheet').map(e => ({ ExamIndentTransID: e.ExamIndentTransID }));
      const LstCertificateCertificate = this.LstMarkCertification.filter(e => e.PrintType.toLowerCase() === 'certificate' && e.CourseType.toUpperCase() == "CERTIFICATE").map(e => ({ ExamIndentTransID: e.ExamIndentTransID }));
      const LstDiplomaCertificate = this.LstMarkCertification.filter(e => e.PrintType.toLowerCase() === 'certificate' && e.CourseType.toUpperCase() == "DIPLOMA").map(e => ({ ExamIndentTransID: e.ExamIndentTransID }));
      const LstSummerCertificate = this.LstMarkCertification.filter(e => e.PrintType.toLowerCase() === 'certificate' && e.CourseType.toUpperCase() == "SUMMER").map(e => ({ ExamIndentTransID: e.ExamIndentTransID }));

      if (this.currentStep == 0) {
        if (this.LstMarkCertification.find(e => e.PrintType.toLowerCase() == "marksheet")) {
          var MarkUpdates: StudentMarksUpdation[] = [];
          this.LstMarkUpdate = [];
          this.LstMarkCertification.forEach(Mark => {
            this.LstMarkUpdation1.forEach(Update => {
              if (Mark.PrintType.toLowerCase() == "marksheet") {
                if ((Mark.ExamIndentTransID == Update.ExamIndentTransID) && (Mark.StudentName == Update.StudentName)) {
                  var MlUpdate = new StudentMarksUpdation();
                  MlUpdate.ExamIndentTransID = Update.ExamIndentTransID;
                  MlUpdate.SubjectMappingID = Update.SubjectMappingID;
                  MlUpdate.BatchMappingID = Update.BatchMappingID;
                  MlUpdate.TheoryMarks = Update.TheoryMark;
                  MlUpdate.PracticalMarks = Update.PracticalMark;
                  MlUpdate.ObtainedTheoryMarks = Update.ObtainedTheoryMarks;
                  MlUpdate.ObtainedPracticalMarks = Update.ObtainedPracticalMarks;
                  MlUpdate.Semester = Update.Semester;
                  MarkUpdates.push(MlUpdate);
                }
              }
            })
          })

          this.LstMarkUpdate = MarkUpdates;
          this.MlStudentMarkUpdate = new MarkUpdate();
          this.MlStudentMarkUpdate.marks = this.LstMarkUpdate;
          this.MlStudentMarkUpdate.preview = 1

          this._srvReprinting.postUpdateStudentMark(this.MlStudentMarkUpdate).subscribe({
            next: () => {
              this.viewerContainerStyle = this._layout.viewerContainerStyle;
              this.bearerToken = this._srvCookie.get(CookieKey.Api);
              this.ServerUrl = this._layout.ServerUrl;

              if (LstMarkUpdation.length) {
                const parameter = {
                  Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstMarkUpdation)
                }

                this.MarksheetReportsource = {
                  report: 'iCloud/Student_Marksheet_Reprinting_Preview',
                  parameters: parameter
                };

              } else {
                this.viewerContainerStyle = this._layout.viewerContainerStyle;
                this.bearerToken = this._srvCookie.get(CookieKey.Api);
                this.ServerUrl = this._layout.ServerUrl;

                if (LstCertificateCertificate.length) {
                  const parameter = {
                    Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstCertificateCertificate)
                  }

                  this.CertificateCertificateReportsource = {
                    report: 'iCloud/Student_Certificate_Reprinting_Preview',
                    parameters: parameter
                  };
                }
                if (LstDiplomaCertificate.length) {
                  const parameter = {
                    Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstDiplomaCertificate)
                  }

                  this.DiplomaCertificateReportsource = {
                    report: 'iCloud/Student_Diploma_Reprinting_Preview',
                    parameters: parameter
                  };
                }
                if (LstSummerCertificate.length) {

                  const parameter = {
                    Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstSummerCertificate)
                  }

                  this.SummerCertificateReportsource = {
                    report: 'iCloud/Student_Junior_diploma_Reprinting_Preview',
                    parameters: parameter
                  };
                }
              }

              this.currentStep += this.step[this.currentStep + 1].disabled === true ? 2 : 1;


            }, error: err => this._srvCommon.errorMsg(err.Message)
          })

        } else {

          this.viewerContainerStyle = this._layout.viewerContainerStyle;
          this.bearerToken = this._srvCookie.get(CookieKey.Api);
          this.ServerUrl = this._layout.ServerUrl;

          if (LstCertificateCertificate.length) {
            const parameter = {
              Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstCertificateCertificate)
            }

            this.CertificateCertificateReportsource = {
              report: 'iCloud/Student_Certificate_Reprinting_Preview',
              parameters: parameter
            };
          }
          if (LstDiplomaCertificate.length) {
            const parameter = {
              Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstDiplomaCertificate)
            }

            this.DiplomaCertificateReportsource = {
              report: 'iCloud/Student_Diploma_Reprinting_Preview',
              parameters: parameter
            };
          }
          if (LstSummerCertificate.length) {

            const parameter = {
              Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstSummerCertificate)
            }

            this.SummerCertificateReportsource = {
              report: 'iCloud/Student_Junior_diploma_Reprinting_Preview',
              parameters: parameter
            };
          }
          this.currentStep += this.step[this.currentStep + 1].disabled === true ? 2 : 1;

        }


      } else if (this.currentStep == 1) {
        if (LstCertificateCertificate.length) {
          const parameter = {
            Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstCertificateCertificate)
          }

          this.CertificateCertificateReportsource = {
            report: 'iCloud/Student_Certificate_Reprinting_Preview',
            parameters: parameter
          };
        }
        if (LstDiplomaCertificate.length) {
          const parameter = {
            Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstDiplomaCertificate)
          }

          this.DiplomaCertificateReportsource = {
            report: 'iCloud/Student_Diploma_Reprinting_Preview',
            parameters: parameter
          };
        }
        if (LstSummerCertificate.length) {

          const parameter = {
            Authorization: this.bearerToken, Agent: window.navigator.userAgent, ExamIndentTransID: JSON.stringify(LstSummerCertificate)
          }

          this.SummerCertificateReportsource = {
            report: 'iCloud/Student_Junior_diploma_Reprinting_Preview',
            parameters: parameter
          };
        }

        this.currentStep += this.step[this.currentStep + 1].disabled === true ? 2 : 1;
      }
      else this.currentStep += this.step[this.currentStep + 1].disabled === true ? 2 : 1;


    }
    else if (this.FrmEntry.invalid) this.FrmEntry.markAllAsTouched();
    else if (!this.LstMarkCertification.length) this._srvCommon.latererrorMsg("Please add atleast one marksheet / certificate.");
    else if (this.LstMarkUpdation.length) this._srvCommon.latererrorMsg("Please add marksheet.");

  }

  public MlPayment: PaymentPayVal = new PaymentPayVal();


  /* Re-Print Request */
  btnSubmit() {
    if (this.Totalamount == 0) this._srvCommon.errorMsg("Please Add Payment");
    else if (this.paymentamount !== this.Totalamount) this._srvCommon.errorMsg("Please enter full payment");
    else {
      this.LstFinalUpdateMark = [];
      var FinalMark: EditExamMark[] = [];
      if (this.LstMarkUpdate.length && this.LstMarkCertification.some(record => record.PrintType === 'Marksheet')) {
        this.LstMarkUpdate.forEach(e => {
          var Mark = new EditExamMark();
          Mark.ExamIndentTransID = e.ExamIndentTransID;
          Mark.SubjectMappingID = e.SubjectMappingID;
          Mark.ObtainedTheoryMarks = e.ObtainedTheoryMarks;
          Mark.ObtainedPracticalMarks = e.ObtainedPracticalMarks;
          FinalMark.push(Mark);
        })

        this.LstFinalUpdateMark = FinalMark;

        this._srvReprinting.updateMark(this.LstFinalUpdateMark).subscribe({
          next: () => {
            this.ReprintingIndent()
          }
        })
      } else {
        this.ReprintingIndent()
      }

    }
  }

  ReprintingIndent() {
    this.MlStudentReprinting = new StudentReprintingMl();

    var Student: ReprintingMl[] = [];
    const LstPayment = [];
    this.LstMarkCertification.forEach(e => {
      var Update = new ReprintingMl()
      Update.ExamIndentTransID = e.ExamIndentTransID;
      Update.PrintType = e.PrintType;
      Student.push(Update)
    })

    this.MlStudentReprinting.reprint = Student

    this.PaymentDetails.filter((e: any) => {

      this.MlPayment = new PaymentPayVal();
      this.MlPayment.PaymentModeID = e.PaymentModeID;
      this.MlPayment.PayModeType = e.PayModeType;
      this.MlPayment.PayModeValue = e.PayModeValue;
      this.MlPayment.Amount = e.Amount;
      this.MlPayment.FromLedgerID = e.FromLedger.LedgerID;
      this.MlPayment.FromLedgerName = e.FromLedger.LedgerName;
      this.MlPayment.ToLedgerID = e.ToLedger.LedgerID;
      this.MlPayment.ToLedgerName = e.ToLedger.LedgerName;
      this.MlPayment.TransactionNo = e.TransactionNo;
      this.MlPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
      this.MlPayment.RoundOff = 0;
      this.MlPayment.BankCommission = 0;
      e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID : delete this.MlPayment.DocumentID;

      LstPayment.push(this.MlPayment)
    });
    this.MlStudentReprinting.paymentItems = LstPayment;
    this.MlStudentReprinting.TotalAmount = this.Totalamount;
    this.MlStudentReprinting.CourierAmount = this.CourierChargeAmount;

    this._srvReprinting.updateRePrint(this.MlStudentReprinting).subscribe({
      next: val => {
        this._srvCommon.successMsg(val.Message);
        this.currentStep = 0;
        this.LstMarkCertification = [];
        this.FrmEntry.reset();
      }, error: err => this._srvCommon.errorMsg(err.Message)
    })
  }
}
