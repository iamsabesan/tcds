import { PaymentPayVal } from "src/app/shared/model/payment";

export class RePrinting {
}

export class Student {
    StudentID: string = '';
    ContactID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Phone: string = '';
    CourseDetails: CourseDetail[] = [];
}

export class CourseDetail {
    CourseBatchID: string = '';
    CourseID: string = '';
    BatchMappingID: string = '';
    RollNumber: string = '';
    CourseName: string = '';
    ShortName: string = '';
    CourseType: string = '';
    TotalSemesters: number = 0;
    IsCompleted: boolean = false;
    ReprintCharges: number = 0;
}


export class StudentMarkPrint {
    StudentID: string = '';
    ContactID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    CourseCode: string = '';
    CourseName: string = '';
    CourseType: string = '';
    ReprintCharges: number = 0
    ExamIndentTransID: string = '';
    BatchMappingID: string = '';
    Semester: number = 0;
    Subjects: Subject[] = [];
}

export class Subject {
    ExamIndentTransID: string = '';
    SubjectMappingID: string = '';
    StudentMarkID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    TheoryMark: number = 0;
    PracticalMark: number = 0;
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
    SubjectName: string = '';
    Semester: number = 0;
    CourseCode: string = '';
    CourseName: string = '';
    CourseType: string = '';
    ReprintCharges: number = 0
    PrintType: string = '';
    BatchMappingID: string = '';
}



export class MarkSheet {
    RollNumber: string = '';
    StudentName: string = '';
    // Subject: string = '';
    // Semester: string = '';
    TheoryActual: number = 0;
    TheoryObtained: number = 0;
    PracticalActual: number = 0;
    PracticalObtained: number = 0;
}

export class MarkSheetCertificate {
    ExamIndentTransID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    CourseCode: string = '';
    CourseName: string = '';
    CourseType: string = '';
    PrintType: string = '';
    PrintingFees: number = 0;
    ReprintCharges: number = 0;

    Subject: string = '';
    Semester: number = 0;
    TheoryActual: number = 0;
    TheoryObtained: number = 0;
    PracticalActual: number = 0;
    PracticalObtained: number = 0;
    BatchMappingID: string = '';
}

export class MarkUpdate {
    preview: number = 0;
    marks: StudentMarksUpdation[] = []
}

export class StudentMarksUpdation {
    ExamIndentTransID: string = '';
    SubjectMappingID: string = '';
    BatchMappingID: string = '';
    TheoryMarks: number = 0;
    PracticalMarks: number = 0;
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
    Semester: number = 0;
}



/* Edit Exam Mark */
export class EditExamMark {
    ExamIndentTransID: string = "";
    SubjectMappingID: string = "";
    ObtainedTheoryMarks: number = 0;
    ObtainedPracticalMarks: number = 0;
}


export class StudentReprintingMl {
    reprint: ReprintingMl[] = [];
    TotalAmount: number = 0;
    CourierAmount: number = 0;
    paymentItems: PaymentPayVal[] = [];
}

export class ReprintingMl {
    ExamIndentTransID: string = '';
    PrintType: string = '';
}
