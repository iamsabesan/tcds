import { Injectable } from '@angular/core';
import { RePrintRequest } from 'src/app/shared/ServiceUrl';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { EditExamMark, MarkUpdate, StudentReprintingMl } from '../model/re-printing';

@Injectable({
  providedIn: 'root'
})
export class RePrintingService {

  constructor(private _srvHttp: HttpService) { }

  /* Type Event */
  getStudentDetail() {
    return this._srvHttp.get(RePrintRequest.getStudentDetail, { RequestType: IRequestType.Protected });
  }

  /* Get Student Course Detail With Using of StudentID */
  getStudentCourseDetail(batchMappingID: string, semester: number) {
    return this._srvHttp.get(`${RePrintRequest.getStudentCertificateMarksheet}${batchMappingID}&semester=${semester}`, { RequestType: IRequestType.Protected });
  }

  postUpdateStudentMark(data: MarkUpdate) {
    return this._srvHttp.post("/icloud-admission/v1/student/reprint/mark/update", data, { RequestType: IRequestType.Protected })
  }

  getMarksheet() { }

  getCertificate() { }

  /* Update the Re-Print Request */
  updateRePrint(data: StudentReprintingMl) {
    return this._srvHttp.post('/icloud-inventory/v1/indent/reprint/certificate-marksheet', data, { RequestType: IRequestType.Protected });
  }


  /* Mark Edit (Franchisee) */
  updateMark(data: EditExamMark[]) {
    return this._srvHttp.post("/icloud-admission/v1/student/mark/edit/rerequest", data, { RequestType: IRequestType.Protected });
  }
}
