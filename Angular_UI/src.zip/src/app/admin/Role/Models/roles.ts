export class IDepartments {
  DepartmentID: string = '';
  DepartmentName: string = '';
  IsActive: boolean = false;
  DesignationList: IDesignationList[] = [];
}
export class IDesignationList {
  SlNo: number = 0;
  DesignationID: string = '';
  Designation: string = '';
  AuthRoleID: number = 0;
  Levels: number = 0;
  IsActive: boolean = false;
  ParentID: any;
}

export class IMenuList {
  SlNo: number = 0;
  menuID: number = 0;
  MenuTitle: string = '';
  ParentMenuID: number = 0;
  IsSelected: boolean = false;
}

export class IUpdateRoleMenu {
  AuthRoleID: number = 0;
  MenuIDList: IGetRoleMenu[] = [];
}

export class IGetRoleMenu {
  MenuID: any;
}



