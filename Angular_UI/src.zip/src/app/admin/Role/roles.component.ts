import { Component, OnInit } from '@angular/core';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { SelectionChangeEvent } from '@progress/kendo-angular-treelist';
import { IDepartments, IDesignationList, IGetRoleMenu, IMenuList, IUpdateRoleMenu, } from './Models/roles';
import { RolesService } from './service/roles.service';
import { IWebError } from 'src/core/model';
import { CustomNotification } from 'src/app/shared/model/shared';

@Component({
  selector: 'roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss'],
})
export class RolesComponent implements OnInit {

  /* List */
  public LstDepartmentJT: IDepartments[] = [];
  public LstAgentDesignation: IDesignationList[] = [];
  public LstMenu: IMenuList[] = [];
  public LstRoleMenu: any[] = [];
  public selectedMenu: IMenuList[] = [];
  public ActiveDesignationList: IDesignationList[] = [];
  public DesignationData: IDesignationList[] = [];

  /* Model */
  public MlRoleMenu: IUpdateRoleMenu = new IUpdateRoleMenu();
  public MlMenu: IGetRoleMenu = new IGetRoleMenu();
  public roleMenu: IMenuList = new IMenuList();

  /* Selected Grid */
  public planSelect: number[] = [0];
  public selectedJT: any[] = [{ itemKey: 1 }];

  public selectableSettings!: SelectableSettings;

  /* Save Button Disabled */
  public isBtnDisabled: boolean = true;

  setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: false,
      mode: 'single',
      drag: false,
    };
  }

  constructor(private _srvRole: RolesService, private _srvNotificationService: NotificationService) {
    this.setSelectableSettings();
  }

  ngOnInit(): void {
    this._srvRole.GetDepartmentJobTitle().subscribe({
      next: (res: any) => {
        this.LstDepartmentJT = res.Data;
        if (this.LstDepartmentJT.length !== 0) {
          for (var i = 0; i < this.LstDepartmentJT.length; i++) {
            this.LstDepartmentJT[i].DesignationList.forEach((e) => {
              e.ParentID = this.LstDepartmentJT[i].DesignationList.find(
                (f) => f.DesignationID === e.ParentID
              )?.SlNo;
            });
          }

          this.LstAgentDesignation = this.LstDepartmentJT[0].DesignationList;
          this.DesignationData = this.LstDepartmentJT[0].DesignationList;
          this.MlRoleMenu.AuthRoleID = this.LstAgentDesignation[0].AuthRoleID;
          this.getRoleMenu(this.MlRoleMenu.AuthRoleID);
          if (this.LstDepartmentJT[0].IsActive === true) this.ActiveDesignationList = this.LstAgentDesignation.filter((e) => e.IsActive === true);
        }
        else this.LstAgentDesignation = this.LstMenu = [];
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotificationService).ShowError(err.Message)
    });
  }

  getRoleMenu(authRoleID: number) {
    this._srvRole.GetRoleMenu(authRoleID).subscribe({
      next: (res: any) => {
        this.LstRoleMenu = res.Data;
        this.LstRoleMenu.filter((e: any) => {
          if (e.ParentMenuID === 0) {
            e.ParentMenuID = null;
            this.LstMenu = this.LstRoleMenu;
          }
        });
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotificationService).ShowError(err.Message)
    });
  }

  deptSelection(event: any) {
    this.isBtnDisabled = true;
    this.LstAgentDesignation = event.selectedRows[0].dataItem.DesignationList;
    this.selectedJT = [{ itemKey: 1 }];
    if (this.LstAgentDesignation.length !== 0) {
      this.getRoleMenu(this.LstAgentDesignation[0].AuthRoleID);
      this.MlRoleMenu.AuthRoleID = this.LstAgentDesignation[0].AuthRoleID;
    }
    else this.LstMenu = [];
  }

  DesignationSelection(e: SelectionChangeEvent): void {
    this.LstMenu = [];
    this.MlRoleMenu.AuthRoleID = e.items[0].dataItem.AuthRoleID;
    this.getRoleMenu(this.MlRoleMenu.AuthRoleID);
  }

  RoleSelection(event: any, dataItem: IMenuList) {
    this.isBtnDisabled = false;
    if (event.target.checked === true) {
      if (dataItem.ParentMenuID === null) {
        dataItem.IsSelected = true;
        this.LstRoleMenu.forEach((f: IMenuList) => {
          if (f.ParentMenuID === dataItem.menuID) f.IsSelected = true;
        });
      } else {
        this.roleMenu = this.LstRoleMenu.find((e: IMenuList) => e.menuID === dataItem.ParentMenuID);
        if (!this.roleMenu.IsSelected) this.roleMenu.IsSelected = true;
        dataItem.IsSelected = true;
      }
    } else {
      if (dataItem.ParentMenuID === null) {
        dataItem.IsSelected = false;
        this.LstRoleMenu.forEach((f: IMenuList) => {
          if (f.ParentMenuID === dataItem.menuID) f.IsSelected = false;
        });
      } else {
        dataItem.IsSelected = false;
        this.roleMenu = this.LstRoleMenu.find((e: IMenuList) => e.menuID === dataItem.ParentMenuID);
        const every = this.LstRoleMenu.filter((f: IMenuList) => f.ParentMenuID === this.roleMenu.menuID).every((g: IMenuList) => g.IsSelected === false);
        if (this.roleMenu.IsSelected && every) this.roleMenu.IsSelected = false;
      }
    }
    this.MlRoleMenu.MenuIDList = [];
    this.selectedMenu = this.LstRoleMenu.filter((e: IMenuList) => e.IsSelected === true);
    this.selectedMenu.forEach((e: IMenuList) => {
      this.MlMenu = new IGetRoleMenu();
      this.MlMenu.MenuID = e.menuID;
      this.MlRoleMenu.MenuIDList.push(this.MlMenu);
    });
  }

  /* Save the role menu */
  btnRoleMenuSave(): void {
    this._srvRole.SaveRoleMenu(this.MlRoleMenu).subscribe({
      next: (res: any) => {
        new CustomNotification(this._srvNotificationService).ShowSuccess(res.Message);
        this.getRoleMenu(this.MlRoleMenu.AuthRoleID);
        this.isBtnDisabled = true;
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotificationService).ShowError(err.Message),
    });
  }
}
