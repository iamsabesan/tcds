import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { TreeListModule } from '@progress/kendo-angular-treelist';
import { GridModule } from '@progress/kendo-angular-grid';
import { RolesComponent } from './roles.component';
import { RolesService } from './service/roles.service';


const routes: Routes = [
  {
    path: '',
    component: RolesComponent
  }
];

@NgModule({
  declarations: [
    RolesComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    NavigationModule,
    ToolBarModule,
    IconsModule,
    LayoutModule,
    DialogsModule,
    LabelModule,
    InputsModule,
    ButtonsModule,
    DropDownsModule,
    TooltipModule,
    TreeListModule,
    GridModule
  ],
  providers: [RolesService]
})
export class RolesModule { }
