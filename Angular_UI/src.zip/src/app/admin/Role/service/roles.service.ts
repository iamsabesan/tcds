import { Injectable } from '@angular/core';
import { IDepartments, IMenuList, IUpdateRoleMenu } from '../Models/roles';
import { HttpService } from 'src/core/service';
import { IRequestType } from 'src/core/model';
import { Admin } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class RolesService {

  constructor(public http: HttpService) { }

  /* Get Departments and Job Title */
  GetDepartmentJobTitle() {
    return this.http.get<IDepartments>(Admin.getDepartment, { RequestType: IRequestType.Protected })
  }

  /* */
  GetRoleMenu(AuthRoleID: string | number) {
    return this.http.get<IMenuList>(`${Admin.getRoleMenu}${AuthRoleID}`, { RequestType: IRequestType.Protected });
  }

  /* Save Role Menu */
  SaveRoleMenu(data: IUpdateRoleMenu) {
    return this.http.post<IUpdateRoleMenu>(Admin.updateRoleMenu, data, { RequestType: IRequestType.Protected })
  }


}
