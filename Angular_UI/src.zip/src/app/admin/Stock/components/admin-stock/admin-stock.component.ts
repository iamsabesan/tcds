import { Component } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor, GroupDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { currentStockDataType } from '../../models/stock';
import { StockService } from '../../services/stock.service';

@Component({
  selector: 'app-admin-stock',
  templateUrl: './admin-stock.component.html',
  styleUrls: ['./admin-stock.component.scss']
})
export class AdminStockComponent {

  public LstStockBalance: currentStockDataType[] = []
  public gridStyle = new gridFontStyle('medium');
  public filter!: CompositeFilterDescriptor;
  public groups: GroupDescriptor[] = [{ field: "MaterialType" }];
  public currencySymbol = '';

  constructor(public intlService: IntlService, private _srvNotification: NotificationService, private _srvStock: StockService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;

    this._srvStock.getAdminCurrentStock().subscribe({
      next: (e) => this.LstStockBalance = e.Data,
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }
}
