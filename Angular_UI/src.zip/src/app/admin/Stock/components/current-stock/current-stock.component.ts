import { Component } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { CompositeFilterDescriptor, GroupDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { currentStockDataType } from '../../models/stock';
import { StockService } from '../../services/stock.service';
import { CustomNotification } from 'src/app/shared/model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';

@Component({
  selector: 'app-current-stock',
  templateUrl: './current-stock.component.html',
  styleUrls: ['./current-stock.component.scss']
})
export class CurrentStockComponent {

  public LstStockBalance: currentStockDataType[] = [];

  public filter!: CompositeFilterDescriptor;
  public currencySymbol = '';
  public gridStyle = new gridFontStyle('medium');
  public groups: GroupDescriptor[] = [{ field: "MaterialType" }];

  constructor(public intlService: IntlService, private _srvStock: StockService, private _srvNotification: NotificationService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this._srvStock.getAdminCurrentStock().subscribe({
      next: (e) => this.LstStockBalance = e.Data,
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }
}
