import { Component, OnInit } from '@angular/core';
import { CompositeFilterDescriptor, GroupDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { localStockDataType } from '../../models/stock';
import { StockService } from '../../services/stock.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { IWebError } from 'src/core/model';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'app-local-stock',
  templateUrl: './local-stock.component.html',
  styleUrls: ['./local-stock.component.scss']
})

export class LocalStockComponent implements OnInit {

  public LstLocalStock: localStockDataType[] = [];
  public filter!: CompositeFilterDescriptor;
  public gridStyle = new gridFontStyle('medium');
  public groups: GroupDescriptor[] = [{ field: "MaterialType" }];
  public currencySymbol = '';

  constructor(public intlService: IntlService, public _srvStock: StockService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;


    this._srvStock.getlocalStock().subscribe({
      next: (res: any) => this.LstLocalStock = res.Data,
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }
}
