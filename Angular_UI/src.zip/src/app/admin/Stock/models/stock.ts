export class localStockDataType {
    MaterialID: string = '';
    CurrentStock: number = 0;
    MaterialType: string = '';
    MaterialName: string = '';
}

export class currentStockDataType {
    MaterialID: string = '';
    MaterialType: string = '';
    MaterialName: string = '';
    MinimumStock: number = 0;
    Price: number = 0;
    CurrentStock: number = 0;
}