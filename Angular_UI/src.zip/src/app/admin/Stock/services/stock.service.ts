import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';

@Injectable({
  providedIn: 'root'
})
export class StockService {
  constructor(private _srvHttp: HttpService) { }

  getlocalStock() {
    return this._srvHttp.get("/icloud-inventory/v1/indent/localstock/list", { RequestType: IRequestType.Protected });
  }
  
  getAdminCurrentStock() {
    return this._srvHttp.get("/icloud-inventory/v1/indent/currentstock/list", { RequestType: IRequestType.Protected });
  }
}
