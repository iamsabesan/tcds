import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { GridModule } from "@progress/kendo-angular-grid";
import { StockService } from './services/stock.service';
import { StockComponent } from './stock.component';
import { LocalStockComponent } from './components/local-stock/local-stock.component';
import { AdminStockComponent } from './components/admin-stock/admin-stock.component';
import { CurrentStockComponent } from './components/current-stock/current-stock.component';

const routes: Routes = [
  {
    path: '',
    component: StockComponent,
    children: [
      {
        path: 'local-stock',
        component: LocalStockComponent
      },
      {
        path: 'admin-stock',
        component: AdminStockComponent
      },
      {
        path: 'current-stock',
        component: CurrentStockComponent
      },
    ]
  }
];

@NgModule({
  declarations: [
    StockComponent,
    LocalStockComponent,
    AdminStockComponent,
    CurrentStockComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    GridModule,
  ],
  providers: [StockService]
})
export class StockModule { }
