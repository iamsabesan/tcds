import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, DropDownFilter, LocalString, getUrl, gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
// import { studentListDataType } from '../../models/Alumnus';
import { directStudentViewDataType } from '../../models/student-profile';
import { StudentService } from '../../services/student.service';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { batchByIDDataType, CourseTypeListMl, StudentFilterDataMl } from 'src/app/shared/model/common';
import { CourseBasicInfo, MlCurrectStdList, StudentList, studentListfilterData } from '../student/model/student';
import { IWebError } from 'src/core/model';
import { CommonService } from 'src/app/shared/service/common.service';
import { AppService } from 'src/core/service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';

@Component({
  selector: 'app-alumnus-list',
  templateUrl: './alumnus-list.component.html',
  styleUrls: ['./alumnus-list.component.scss']
})
export class AlumnusListComponent {

  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;
  @ViewChild("form") public form?: NgForm;

  /* List */
  public LstAlumniStudent: StudentList[] = [];
  public LstCourse: CourseBasicInfo[] = [];
  public LstStoreCourse: CourseBasicInfo[] = [];
  public LstBatch: batchByIDDataType[] = [];
  public LstStoreBatch: batchByIDDataType[] = [];
  public edit: string[] = ['Edit', 'View', 'Active'];
  public LstCourseType: CourseTypeListMl[] = [];

  /* Model */
  public MlAlumnuscourse: studentListfilterData = new studentListfilterData();
  public gridStyle: gridFontStyle = new gridFontStyle();
  public studentViewData: directStudentViewDataType = new directStudentViewDataType();
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();
  public todayDate: Date = new Date();
  public FilterData: StudentFilterDataMl = new StudentFilterDataMl();


  /* Date & Time Format */
  public dateWholePeriod!: boolean;

  public filter!: CompositeFilterDescriptor;
  public course: string = "";
  public batch: string = "";
  public batchDisabled: boolean = true;
  // public CourseType: string = '';


  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Grid Pagination */
  public buttonCount = 5;
  skip = 0;
  pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  WholePerStrDate: Date;
  constructor(private _srvStudent: StudentService, private _srvCommon: CommonService,
    public _srvValueShare: ValueShareService, private _srvNotification: NotificationService,
    private _routes: Router, public _srvApp: AppService
  ) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = true;

    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

    // this.getCourseBaseData();

    /* Default API Call */
    var date: any = DateConversion.ConvertMonthDateYear(new Date());
    var todate: any = DateConversion.ConvertMonthDateYear(new Date());
    setTimeout(() => {
      if (this._srvStudent.checkGoBack) {
        date = this._srvStudent.MllstFliterData.date.startDate;
        todate = this._srvStudent.MllstFliterData.date.endDate;
        if (this._srvStudent.MllstFliterData.courseType) {
          this.MlAlumnuscourse.courseType = this._srvStudent.MllstFliterData.courseType;
          this.CourseType = this._srvStudent.MllstFliterData.courseType.CourseTypeID;
          this.getCourseList(this.CourseType);

          if (this._srvStudent.MllstFliterData.course) {
            this.course = this._srvStudent.MllstFliterData.course.CourseID;
            this.MlAlumnuscourse.course = this._srvStudent.MllstFliterData.course;
          }
        }
        // this.MlAlumnuscourse.course = this.course = this._srvStudent.MllstFliterData.course;
        if (this._srvStudent.MllstFliterData.batch) this.batch = this._srvStudent.MllstFliterData.batch.CourseBatchID;
        if (this.MlAlumnuscourse.course) this.getBatch(this.MlAlumnuscourse.course.CourseID);
        this.pageSize = this._srvStudent.listPageSize;
        this.skip = this._srvStudent.listPageSkip;
      } else {
        this._srvStudent.MllstFliterData = new MlCurrectStdList();
      }
      this.getAlumnusList(date, todate, this.course, this.batch, this.CourseType);
    },);

  }

  /* Date Value  Bind */
  ngAfterViewInit() {
    if (this._srvStudent.checkGoBack) {
      setTimeout(() => {
        this.MlDateRange = this._srvStudent.MllstFliterData.date;
        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          } else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        } else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateRange)
        } else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvStudent.checkGoBack = false;
      });
    }


  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;

  }

  /* Get Course */
  getCourseBaseData() {
    this._srvCommon.getCourseBasicData().subscribe({
      next: (e) =>
        this.LstCourse = this.LstStoreCourse = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourse = this.LstStoreCourse = [];
    this.LstBatch = [];
    this.MlAlumnuscourse.batch = this.MlAlumnuscourse.course = null;

    if (event && event.CourseTypeID) {
      this.getCourseList(event.CourseTypeID);
    }
  }

  getCourseList(Id: string) {
    this._srvCommon.getCourseListInCourseType(Id).subscribe({
      next: val => {
        this.LstCourse = this.LstStoreCourse = val.Data || [];
      }
    });
  }

  /* Get Course By Batch Detail */
  getCourse(event: any) {
    this.MlAlumnuscourse.batch = undefined;
    this.LstBatch = this.LstStoreBatch = [];
    if (event) this.getBatch(event.CourseID);
  }

  getBatch(event: string) {
    this._srvCommon.getBatchByCourseById(event).subscribe({
      next: (e) => {
        this.batchDisabled = false;
        this.LstBatch = this.LstStoreBatch = e.Data;

        this.MlAlumnuscourse.batch = this.LstBatch.find(e => e.CourseBatchID == this.batch);
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Batch Filter */
  batchFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: batchByIDDataType) =>
      data.CourseBatchID.toLowerCase().includes(normalizedQuery) ||
      data.BatchNumber.toLowerCase().includes(normalizedQuery) ||
      data.FacultyID.toLowerCase().includes(normalizedQuery) ||
      data.Timing.toLowerCase().includes(normalizedQuery) ||
      data.BatchType.toLowerCase().includes(normalizedQuery);

    this.LstBatch = this.LstStoreBatch.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: CourseBasicInfo) =>
      data.CourseID.toLowerCase().includes(normalizedQuery) ||
      data.Course.toLowerCase().includes(normalizedQuery) ||
      data.ShortName.toLowerCase().includes(normalizedQuery) ||
      data.CourseType.toLowerCase().includes(normalizedQuery);

    this.LstCourse = this.LstStoreCourse.filter(filterExpression);
  }

  view(data: any) {
    this._srvApp.val = data;
    this._srvApp.checkStudentView = true;
    this._routes.navigate(['/iCloud/student/student-profile']);
    getUrl.invokingUrl = '/iCloud/student/alumnus';

    this._srvStudent.listPageSize = this.pageSize;
    this._srvStudent.listPageSkip = this.skip;
  }

  /* Get Alumni Student List */
  getAlumnusList(fromDate: Date, toDate: Date, courseID: string, batchID: string, courseType: string) {
    this.FilterData = new StudentFilterDataMl();

    const startDate = fromDate == null || fromDate == undefined ? "" : DateConversion.ConvertMonthDateYear(fromDate);
    const endDate = toDate == null || toDate == undefined ? "" : DateConversion.ConvertMonthDateYear(toDate);
    const Course = (courseID == null || courseID == undefined) ? "" : courseID;
    const Batch = (batchID == null || batchID == undefined) ? "" : batchID;
    const CourseType = courseType ? courseType : '';

    startDate ? this.FilterData.StartDate = startDate : delete this.FilterData.StartDate;
    endDate ? this.FilterData.EndDate = endDate : delete this.FilterData.EndDate;
    Batch ? this.FilterData.CourseBatchID = Batch : delete this.FilterData.CourseBatchID;
    Course ? this.FilterData.CourseID = Course : delete this.FilterData.CourseID;
    CourseType ? this.FilterData.CourseTypeID = CourseType : delete this.FilterData.CourseTypeID;

    this._srvStudent.getAlumnsStudent(this.FilterData).subscribe({
      next: (e: any) => {
        this.LstAlumniStudent = e.Data;
        if (this.LstAlumniStudent.length) {
          this.LstAlumniStudent.forEach(val => {
            val.RegDate = DateConversion.ConvertStringToDateTime(val.RegisteredDate);
          })
        }
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  dateChange(event: any) {
    this.MlDateRange = event;
  }

  public startDate: Date = new Date();
  public endDate: Date = new Date();
  public Course: string = '';
  public Batch: string = '';
  public CourseType: string = '';

  /* Search value assign in service */
  lstflitervalue() {
    this._srvStudent.MllstFliterData.date.startDate = this.dateRanges.dateRange.startDate;
    this._srvStudent.MllstFliterData.date.endDate = this.dateRanges.dateRange.endDate;
    this._srvStudent.MllstFliterData.date.duration = this.MlDateRange.duration;
    this._srvStudent.MllstFliterData.course = this.MlAlumnuscourse.course;
    this._srvStudent.MllstFliterData.batch = this.MlAlumnuscourse.batch;
    this._srvStudent.MllstFliterData.courseType = this.MlAlumnuscourse.courseType;
  }


  search() {
    this.startDate = this.dateRanges.dateRange.startDate;
    this.endDate = this.dateRanges.dateRange.endDate;
    this.Course = this.MlAlumnuscourse.course ? this.MlAlumnuscourse.course.CourseID : '';
    this.Batch = this.MlAlumnuscourse.batch == undefined ? "" : this.MlAlumnuscourse.batch.CourseBatchID;
    this.CourseType = this.MlAlumnuscourse.courseType ? this.MlAlumnuscourse.courseType.CourseTypeID : '';

    if ((!this.startDate || !this.endDate) && (!this.Course && !this.Batch && !this.CourseType)) this.errorMsg("Please fill the details");
    else if (((!this.startDate && this.endDate) || (this.startDate && !this.endDate)) && ((this.Course || !this.Course) && (this.Batch || !this.Batch) && (!this.CourseType || this.CourseType))) this.errorMsg("Please fill the date");
    else {
      this.getAlumnusList(this.startDate, this.endDate, this.Course, this.Batch, this.CourseType);
      this.lstflitervalue()
    }
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
