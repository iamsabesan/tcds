import { Component, ViewChild } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, DateSize, LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CommonService } from 'src/app/shared/service/common.service';
import { ReportService } from '../../service/report.service';
import { ReportFilterMl, StudentEnquirylistMl } from '../../model/report';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {

  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  LstStdEnquiry: StudentEnquirylistMl[] = [];
  LstStatus: string[] = [];


  /* Model */
  public gridStyle: gridFontStyle = new gridFontStyle();
  public dateStyle: DateSize = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();
  public MlFilter: ReportFilterMl = new ReportFilterMl();

  /* Store Currency Symbol */
  public currencySymbol: string = '';

  /* Date Format */
  public dateWholePeriod: boolean;


  /* Grid Pagination */
  public pageSize: number = 25;
  public skip: number = 0;
  public buttonCount: number = 5;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  WholePerStrDate: Date;
  public Status: string = '';

  /* For Responsiveness */


  constructor(private _srvRep: ReportService, public _srvCommon: CommonService,
    private _srvNotification: NotificationService, private sanitizer: DomSanitizer) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = false;
    this.currencySymbol = LocalString.CurrencySymbol;

    this._srvRep.getStatusList().subscribe({
      next: val => {
        this.LstStatus = val.Data;
        this.Status = this.LstStatus.find(e => e.toUpperCase() == "ALL");
      }


    });

    // this.MlDateRange = this._srvExam.MllstFliterData;

    if (this._srvRep.stdEnquiryDateRange) {
      this.MlDateRange = this._srvRep.MllstFliterData;
      this.pageSize = this._srvRep.listPageSize;
      this.skip = this._srvRep.listPageSkip;
    }

    this.searchDate();
  }

  ngAfterViewInit() {
    if (this._srvRep.stdEnquiryDateRange) {
      setTimeout(() => {
        this.MlDateRange = this._srvRep.MllstFliterData;
        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          }
          else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        }
        else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateRange)
        }
        else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvRep.stdEnquiryDateRange = false;
        this._srvRep.listPageSize = 15;
        this._srvRep.listPageSkip = 0;
      });
    }
  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;
  }

  /* Select Date */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Date Wise Filter Exam Indent */
  searchDate() {
    if ((!this.MlDateRange.startDate && !this.MlDateRange.endDate) && (!this.Status)) this.errorMsg("Please fill the details");
    else if (this.Status && (!this.MlDateRange.startDate && this.MlDateRange.endDate) || (this.MlDateRange.startDate && !this.MlDateRange.endDate)) this.errorMsg("Please fill the correct date");
    else this.getStudentEnquiry();
  }

  /* Get Exam Indent Detail */
  getStudentEnquiry() {
    const fromDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
    const toDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);
    fromDate && toDate ? this.MlFilter.FromDate = fromDate : delete this.MlFilter.FromDate;
    fromDate && toDate ? this.MlFilter.ToDate = toDate : delete this.MlFilter.ToDate;
    this.MlFilter.Status = this.Status;
    this._srvRep.postReportList(this.MlFilter).subscribe({
      next: (e) => {
        this.LstStdEnquiry = e.Data;

        if (this.LstStdEnquiry.length) {
          this.LstStdEnquiry.forEach(val => {
            val.ReqDate = DateConversion.ConvertStringToDateTime(val.RequestedDate);
          })
        }
        this.lstflitervalue();
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  /* Go to Create Exam Indent Component */
  addNew() {
    this.setPagenation();
  }

  /* Go to View Component */
  View(event: StudentEnquirylistMl) {
    console.log(event);
    this.setPagenation()
    this._srvRep.action.next({ Mode: 'VIEW' });
  }

  lstflitervalue() {
    setTimeout(() => {
      this._srvRep.MllstFliterData.duration = this.MlDateRange.duration;
      this._srvRep.MllstFliterData.startDate = this.dateRanges.dateRange.startDate;
      this._srvRep.MllstFliterData.endDate = this.dateRanges.dateRange.endDate;
    }, 100)
  }
  /* Report Viewer Close Dialog */

  /* Exam indent status color different */
  colorCode(code: string): SafeStyle {
    let result: string;
    switch (code.toLowerCase()) {
      case 'pending':
        result = 'expired';
        break;
      case 'rejected':
        result = 'expired';
        break;
      case 'approved':
        result = 'success';
        break;
      default:
        result = 'normal';
        break;
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

  setPagenation() {
    this._srvRep.listPageSize = this.pageSize;
    this._srvRep.listPageSkip = this.skip;
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
  }
}
