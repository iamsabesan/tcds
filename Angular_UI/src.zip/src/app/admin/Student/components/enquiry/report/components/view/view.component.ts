import { Component } from '@angular/core';
import { LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { ReportService } from '../../service/report.service';

@Component({
  selector: 'view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent {

  /* List */
  public studentExamIndent = [];
  public PaymentInfo = [];

  /* Model */
  public MlexamIndent: any;
  public gridStyle = new gridFontStyle();

  /* Total Amount */
  public total: number = 0;

  /* If Rejected Show reason */
  public showReason: boolean = false;

  public currencySymbol: string = '';

  constructor(private _srvExam: ReportService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;

    // this._srvExam.franchiseeExamIndentDataShare.subscribe((e: any) => {
    //   this.MlexamIndent = e.data;
    //   this.studentExamIndent = this.MlexamIndent.ExamIndentTransDetails;
    //   this.PaymentInfo = this.MlexamIndent.PaymentDetails
    // });
    this.showReason = this.MlexamIndent.ExamIndentDetail.Status.toUpperCase() == 'REJECTED' ? true : false;
    this.total = this.PaymentInfo.reduce((sum: any, current: any) => sum + current.Amount, 0);
  }

  /* Go to Exam Indent List Component */
  goBack() {
    this._srvExam.action.next({ Mode: 'LIST' });
    this._srvExam.stdEnquiryDateRange = true;
  }
}
