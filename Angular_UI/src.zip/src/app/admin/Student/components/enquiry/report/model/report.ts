
export interface PathRoute {
  Mode: 'LIST' | 'VIEW'
}

export class ReportFilterMl {
  Status: string = '';
  FromDate: string = '';
  ToDate: string = '';
}


export class StudentEnquirylistMl {
  StudentEnquiryID: string = '';
  TenantBranchID: string = '';
  CourseID: string = '';
  Course: string = '';
  StudentName: string = '';
  Gender: string = '';
  DateOfBirth: string = '';
  PhoneCode: string = '';
  Phone: string = '';
  AlternatePhoneCode: string = '';
  AlternatePhone: string = '';
  Email: string = '';
  Qualification: string = '';
  GuardianType: string = '';
  GuardianName: string = '';
  Occupation: string = '';
  ReasonToSelect: string = '';
  Status: string = '';
  IsRejected: boolean
  RejectedDate: string = '';
  Reason: string = '';
  CourseTypeName: string = '';
  DurationType: string = '';
  Duration: number = 0;
  TotalSemesters: number = 0;
  CourseFees: number = 0;
  DocumentID: string = '';
  RequestedDate: string = '';
  ReqDate: Date;
  Address: Address[] = [];
}

export class Address {
  StudentAddressID: string = '';
  StudentEnquiryID: string = '';
  AddressType: string = '';
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Pincode: string = '';
}