import { Component } from "@angular/core";
import { ReportService } from "./service/report.service";

@Component({
    selector: 'report',
    templateUrl: 'report.component.html',

})

export class RequestComponent {
    public actions: string = '';
    constructor(private _srvRep: ReportService) {
        this._srvRep.action.subscribe(e => this.actions = e.Mode);
    }
}