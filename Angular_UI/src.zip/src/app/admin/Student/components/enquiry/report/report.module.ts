import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule } from "@angular/forms";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { LabelModule } from "@progress/kendo-angular-label";
import { ReportService } from "./service/report.service";
import { RequestComponent } from "./report.component";
import { ListComponent } from "./components/list/list.component";
import { ViewComponent } from "./components/view/view.component";

const routes = [
    {
        // path: '',
        // component: RequestComponent,
        // children: [
        //     {
                path: 'report',
                component: ListComponent,
        //     },
        // ]
    }
]

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        GridModule,
        LabelModule,

        RejectModule,
        DateRangesModule,
    ],
    declarations: [
        RequestComponent,
        ListComponent,
        ViewComponent
    ],
    providers: [
        ReportService
    ]
})
export class ReportModuel { }