import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";
import { PathRoute, ReportFilterMl } from "../model/report";

@Injectable()

export class ReportService {

    public MllstFliterData = new DateRanges();
    public listPageSize: any = 15;
    public listPageSkip: any = 0;
    stdEnquiryDateRange = false;

    public action = new BehaviorSubject<PathRoute>({ Mode: 'LIST' });

    constructor(private http: HttpService) { }

    postReportList(data: ReportFilterMl) {
        return this.http.post(`/icloud-admission/v1/student/enquiry/report`, data, { RequestType: IRequestType.Protected })
    }

    getStatusList() {
        return this.http.get('/icloud-admission/v1/student/enquiry/report/status', { RequestType: IRequestType.Protected })
    }
}