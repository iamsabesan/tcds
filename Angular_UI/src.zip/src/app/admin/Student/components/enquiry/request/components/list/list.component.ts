import { Component, ViewChild } from '@angular/core';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, DateSize, LocalString, gridFontStyle } from 'src/app/shared/app-global';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { CustomNotification } from 'src/app/shared/model/shared';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CommonService } from 'src/app/shared/service/common.service';
import { RequestService } from '../../service/request.service';
import { StudentService } from 'src/app/admin/Student/services/student.service';
import { StudentEnquirylistMl, StudentRejectMl } from '../../model/request';
import { DialogService } from '@progress/kendo-angular-dialog';
import { RejectComponent } from 'src/app/shared/components/reject/reject.component';
// import { StudentEnquirylistMl } from '../../../report/model/report';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {

  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  LstStdEnquiry: StudentEnquirylistMl[] = [];
  LstViewData = ['Admission', 'Closed']

  /* Model */
  public MlStudentReject: StudentRejectMl = new StudentRejectMl();
  public gridStyle: gridFontStyle = new gridFontStyle();
  public dateStyle: DateSize = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  /* Store Currency Symbol */
  public currencySymbol: string = '';

  /* Date Format */
  public dateWholePeriod: boolean;


  /* Grid Pagination */
  public pageSize: number = 15;
  public skip: number = 0;
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  WholePerStrDate: Date;
  /* For Responsiveness */

  public MobileAndName: string = '';


  constructor(private _srvReq: RequestService, public _srvCommon: CommonService,
    private _srvNotification: NotificationService, private sanitizer: DomSanitizer,
    public _srvStd: StudentService, private _srvDialog: DialogService,) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = false;
    this.currencySymbol = LocalString.CurrencySymbol;
    if (this._srvReq.stdEnquiryDateRange) {
      this.MlDateRange = this._srvReq.MllstFliterData;
      this.pageSize = this._srvReq.listPageSize;
      this.skip = this._srvReq.listPageSkip;
    }

    // setTimeout(() => this.searchDate())
  }

  ngAfterViewInit() {
    if (this._srvReq.stdEnquiryDateRange) {
      setTimeout(() => {
        this.MlDateRange = this._srvReq.MllstFliterData;
        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          }
          else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        }
        else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            this.dateRanges.selectedValue = undefined;
          }
          this.AssignDate(this.MlDateRange)
        }
        else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }
        this._srvReq.stdEnquiryDateRange = false;
        this._srvReq.listPageSize = 15;
        this._srvReq.listPageSkip = 0;

        this.searchDate();
      });
    }
    else this.searchDate();
  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;
  }

  /* Select Date */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Date Wise Filter Exam Indent */
  searchDate() {
    if ((!this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate) && (!this.MobileAndName || (this.MobileAndName && this.MobileAndName.length < 3))) this.errorMsg("Please fill the correct details");
    else if ((!this.dateRanges.dateRange.startDate && this.dateRanges.dateRange.endDate) || (this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate)) this.errorMsg("Invalid date");
    else if (this.MobileAndName && this.MobileAndName.length < 3) this.errorMsg("Invalid name / mobile");
    else this.getStudentEnquiry();
  }

  /* Get Exam Indent Detail */
  getStudentEnquiry() {
    const fromDate = this.dateRanges.dateRange.startDate ? DateConversion.ConvertMonthDateYear(this.dateRanges.dateRange.startDate) : '';
    const toDate = this.dateRanges.dateRange.endDate ? DateConversion.ConvertMonthDateYear(this.dateRanges.dateRange.endDate) : '';
    const nameOrPhone = this.MobileAndName ?? '';
    this._srvReq.getEnquiryList(fromDate, toDate, nameOrPhone).subscribe({
      next: (e) => {
        this.LstStdEnquiry = e.Data;

        if (this.LstStdEnquiry.length) {
          this.LstStdEnquiry.forEach(val => {
            val.ReqDate = DateConversion.ConvertStringToDateTime(val.RequestedDate);
          })
        }
        this.lstflitervalue();
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }



  /* Go to View Component */
  View(event: any, data: StudentEnquirylistMl) {
    if (event == 'Admission') {
      this.setPagenation();
      this._srvReq.action.next({ Mode: 'VIEW' });
      // this._routes.navigate(['/iCloud/student/student-list']);
      // this._srvStd.checkStudentCreate = false;
      // this._srvStd.checkStudentEnquiry = true;
      this._srvReq.MlStudentEnquiryData = data;
    } else if (event == 'Closed') {
      this.reject(data.StudentEnquiryID);
    }

  }

  lstflitervalue() {
    setTimeout(() => {
      this._srvReq.MllstFliterData.duration = this.MlDateRange.duration;
      this._srvReq.MllstFliterData.startDate = this.dateRanges.dateRange.startDate;
      this._srvReq.MllstFliterData.endDate = this.dateRanges.dateRange.endDate;
    }, 100)
  }
  /* Report Viewer Close Dialog */

  /* Exam indent status color different */
  colorCode(code: string): SafeStyle {
    let result: string;
    switch (code.toLowerCase()) {
      case 'pending':
        result = 'expired';
        break;
      case 'rejected':
        result = 'expired';
        break;
      case 'approved':
        result = 'success';
        break;
      default:
        result = 'normal';
        break;
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  reject(Id: string) {
    this.MlStudentReject = new StudentRejectMl();
    const dialogRef = this._srvDialog.open({
      title: "Reject Student Enquiry",
      content: RejectComponent,
      width: 400,
    });

    const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

    rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
      this.MlStudentReject.StudentEnquiryID = Id;
      this.MlStudentReject.Reason = formData.Reason;

      this._srvReq.postStudentReject(this.MlStudentReject).subscribe({
        next: (response) => {
          new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
          this.getStudentEnquiry();
          dialogRef.close();
        },
        error: (error) => new CustomNotification(this._srvNotification).ShowError(error.Message),
      });
    });
  }


  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

  setPagenation() {
    this._srvReq.listPageSize = this.pageSize;
    this._srvReq.listPageSkip = this.skip;
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }
}
