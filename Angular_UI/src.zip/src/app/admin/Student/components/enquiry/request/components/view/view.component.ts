import { Component } from '@angular/core';
import { DateConversion, DropDownFilter, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { Occupation, Qualification, StudentAddressCreate } from 'src/app/shared/model/student-profile';
import { batchByIDDataType, Country, CourseDetailMl, CourseTypeListMl, District, gender_lst, PhoneCode, RelationShipListMl, State } from 'src/app/shared/model/common';
import { PaymentDetail, StudentCreate, StudentPaymentData } from 'src/app/admin/Student/components/student/model/student';
import { InputRegex } from 'src/app/shared/components/regex';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { StudentsService } from '../../../../student/service/student.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { StudentService } from 'src/app/admin/Student/services/student.service';
import { IWebError } from 'src/core/model';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';
import { CookieKey } from 'src/core/helper';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { RequestService } from '../../service/request.service';
import { StudentEnquirylistMl } from '../../model/request';
import { ImageUploadResult } from 'src/app/shared/model/payment';

@Component({
  selector: 'view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent {

  /* List */
  public addressData: StudentAddressCreate[] = [];
  public LstCountry: Country[] = [];
  public LstState: State[] = [];
  public LstDistrict: District[] = [];
  public LstPhoneCode: PhoneCode[] = [];
  public LstOccupation: Occupation[] = [];
  public LstQualification: Qualification[] = [];
  public LstCourseData: CourseDetailMl[] = [];
  public LstCourseData1: CourseDetailMl[] = [];
  public Lstbatch: batchByIDDataType[] = [];
  public batch: batchByIDDataType[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public LstGender: gender_lst[] = [];
  public LstGuardian: RelationShipListMl[] = [];
  public LstCourseType: CourseTypeListMl[] = [];

  /* Model */
  public MlAddress: StudentAddressCreate = new StudentAddressCreate();
  public MlCreateStudent: StudentCreate = new StudentCreate()
  public MlExistingStudent: StudentPaymentData = new StudentPaymentData();
  public MlPayment: PaymentDetail = new PaymentDetail();
  public MlCourse: CourseDetailMl = new CourseDetailMl();
  public MlBatch: batchByIDDataType = new batchByIDDataType();
  public com_address: StudentAddressCreate = new StudentAddressCreate();
  public per_address: StudentAddressCreate = new StudentAddressCreate();
  public MlProfileFile = new ImageUploadResult();

  /* Pattern */
  public Name = InputRegex.Name;
  public Email = InputRegex.Email;
  public Mobile = InputRegex.Mobile;
  public Pincode = /^(6)?[1-9][0-9]{5}$/;

  /* Input decimal point not allow */
  public existing: boolean = false;
  public existingDisabled: boolean = false;

  /* Payment Details */
  public paymentamount: number = 0;
  public ErrorNotification: string = 'Please enter valid Amount';
  public ErrorNotify: string = 'Fees amount must be equal with total amount';
  public Totalamount: number = 0;
  public Balanceamount: number = 0;
  public isDownPaymentDisabled: boolean = true;
  public downPaymentMinAmount: number = 0;
  public downPaymentMaxAmount: number = 0;
  public disbledDepositFrom = false;
  public currencySymbol: string = '';

  /* Address Selection */
  public isDisabledState: boolean = true;
  public isDisabledDistrict = true;
  public selectedCountry: any;
  public selectedState: any;
  public selectedDistrict: any;
  public CountryID: string = '';
  public ShippingState!: Array<{
    StateProvinceID: number;
    StateProvinceName: string;
  }>;

  public ShippingDistrict!: Array<{
    DistrictID: number;
    DistrictName: string;
  }>;

  public shipDisabledState: boolean = true;
  public shipDisabledDistrict: boolean = true;
  public shipselectedCountry: any;
  public shipselectedState: any;
  public shipselectedDistrict: any;

  public courseData: boolean = false;
  public batchInfo: boolean = false;

  /* Existing Student is True Disabled the Step 1 */
  public IsStep1: boolean = true;

  /* Date & Time Format */
  public timeFormat: string = '';
  public time: string = '';
  public dateFormat: string = '';

  /* Get Image File Extension */
  public FileExtension: string = "";

  public imageSrc1?: any;
  public studentID: string = '';
  public currentStep: number = 0;

  public guardians: string = 'Father';

  /* Telerik Report Viewer */
  public getScreenHeight: any;
  public getScreenWidth: any;
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public open: boolean = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";
  public IsDisable = false;

  public originalAmount = 0;
  public discountPercentage: any = null;
  public DiscountPercent: number = 0;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;
  public StartWithFilterSettings = DropDownFilter.StartWithfilterSettings;

  public checkProfilePic = false;
  public checkProfilePicFileSize = false;
  public checkProfilePicFileType = false;
  public checkProfilePicChange = false;

  FrmEntry = new FormGroup({
    personalDetails: this.fb.group({
      type: new FormControl("New", [Validators.required]),
      name: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      gender: new FormControl(null, [Validators.required]),
      dob: new FormControl(null, [Validators.required]),
      PhoneCode: new FormControl(null, [Validators.required]),
      mobile: new FormControl(null, [Validators.required]),
      AlternatePhoneCode: new FormControl(),
      altmobile: new FormControl(),
      email: new FormControl(),
      qualification: new FormControl(null, [Validators.required]),
      guardian: new FormControl(null, [Validators.required]),
      guardianName: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      occupation: new FormControl(null, [Validators.required]),
      ReasonNotes: new FormControl(null),
      HowToKnow: new FormControl(null),
      Purpose: new FormControl(null),
      image: new FormControl(null),
    }),
    address: this.fb.group({
      address1: new FormControl(null, [Validators.required]),
      address2: new FormControl(),
      area: new FormControl(null, [Validators.required]),
      country: new FormControl(null, [Validators.required]),
      state: new FormControl(null, [Validators.required]),
      district: new FormControl(null, [Validators.required]),
      Taluk: new FormControl(null, [Validators.required]),
      pincode: new FormControl(null, [Validators.required]),
      permenantaddress1: new FormControl(null, [Validators.required]),
      permenantaddress2: new FormControl(),
      permenantarea: new FormControl(null, [Validators.required]),
      permenantcountry: new FormControl(null, [Validators.required]),
      permenantstate: new FormControl(null, [Validators.required]),
      permenantdistrict: new FormControl(null, [Validators.required]),
      permenantTaluk: new FormControl(null, [Validators.required]),
      permenantpincode: new FormControl(null, [Validators.required]),
    }),
    courseDetails: this.fb.group({
      courseType: new FormControl(null, [Validators.required]),
      courseName: new FormControl(null, [Validators.required]),
      batch: new FormControl(null, [Validators.required]),
      discount: new FormControl(0, [Validators.min(0)]),
      discountPercent: new FormControl(null, [Validators.min(0), Validators.max(100)]),
      downPayment: new FormControl(null, [Validators.required])
    })
  });


  constructor(public fb: FormBuilder, public _srvCookie: CookieService,
    private _srvStudent: StudentsService,
    public layout: LayoutComponent, private _srvCommon: CommonService,
    private _srvNotification: NotificationService,
    public _srvStd: StudentService, private _srvReq: RequestService,
  ) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.imageSrc1 = "assets/logo/img_avatar.png";
    this.FrmDataBinding(this._srvReq.MlStudentEnquiryData);
  }

  FrmDataBinding(data: StudentEnquirylistMl) {
    const PersonalFrm = this.FrmEntry.controls.personalDetails.controls;
    const AddressFrm = this.FrmEntry.controls.address.controls;
    const CourseFrm = this.FrmEntry.controls.courseDetails.controls;

    PersonalFrm.altmobile.setValue(data.AlternatePhone);
    PersonalFrm.dob.setValue(DateConversion.ConvertStringToDate(data.DateOfBirth));
    PersonalFrm.guardianName.setValue(data.GuardianName);
    PersonalFrm.mobile.setValue(data.Phone);
    PersonalFrm.name.setValue(data.StudentName);
    PersonalFrm.ReasonNotes.setValue(data.ReasonToSelect);
    PersonalFrm.HowToKnow.setValue(data.ReferBy);
    PersonalFrm.Purpose.setValue(data.Purpose);
    PersonalFrm.type.setValue('New');
    if (data.DocumentID !== '00000000-0000-0000-0000-000000000000') this.imagePreview(data.DocumentID);

    this._srvCommon.getPhoneCode().subscribe({
      next: (e) => {
        this.LstPhoneCode = e.Data;
        data.AlternatePhoneCode ? PersonalFrm.AlternatePhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.AlternatePhoneCode)) : PersonalFrm.AlternatePhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == '+91'));
        PersonalFrm.PhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.PhoneCode));
      }
    });

    this._srvCommon.getLstGender().subscribe(e => {
      this.LstGender = e.Data;
      PersonalFrm.gender.setValue(this.LstGender.find(e => e.GenderName.toUpperCase() == data.Gender.toUpperCase()));
    })

    this._srvCommon.getStudentQualification().subscribe(e => {
      this.LstQualification = e.Data;
      PersonalFrm.qualification.setValue(data.Qualification);

    })

    this._srvCommon.getOccupationData().subscribe(e => {
      this.LstOccupation = e.Data;
      const Occupation = this.LstOccupation.find(val => val.Occupation.toUpperCase() == data.Occupation.toUpperCase());
      Occupation ? PersonalFrm.occupation.setValue(Occupation.Occupation) : PersonalFrm.occupation.setValue(data.Occupation);
    })

    this._srvCommon.getRelationShipLst().subscribe(e => {
      this.LstGuardian = e.Data;
      PersonalFrm.guardian.setValue(this.LstGuardian.find(val => val.MinValue.toUpperCase() == data.GuardianType.toUpperCase()));
    })


    data.Address.forEach(Add => {
      if (Add.AddressType.toLowerCase() == 'communication address' || Add.AddressType.toLowerCase() == 'communicationaddress') {
        AddressFrm.address1.setValue(Add.Address1);
        AddressFrm.address2.setValue(Add.Address2);
        AddressFrm.area.setValue(Add.Area);
        AddressFrm.pincode.setValue(Add.Pincode);
        AddressFrm.Taluk.setValue(Add.Taluk);
        this._srvCommon.getLstCountry().subscribe({
          next: (res: any) => {
            this.LstCountry = res.Data;
            const COUNTRY = this.LstCountry.find(e => e.CountryName.toUpperCase() == Add.Country.toUpperCase());
            if (COUNTRY) {
              AddressFrm.country.setValue(COUNTRY);
              this._srvCommon.getLstState(COUNTRY?.CountryID).subscribe(e => {
                this.LstState = e.Data;
                const STATE = this.LstState.find(e => e.StateProvinceName.toUpperCase() == Add.State.toUpperCase())
                AddressFrm.state.setValue(STATE);
                this.isDisabledState = false;
                if (STATE) {
                  this._srvCommon.getLstDistrict(STATE?.StateProvinceID).subscribe(val => {
                    this.LstDistrict = val.Data;
                    const DISTRICT = this.LstDistrict.find(e => e.DistrictName.toUpperCase() == Add.District.toUpperCase());
                    AddressFrm.district.setValue(DISTRICT);
                    this.isDisabledDistrict = false;
                  })
                }
              })
            }
          }
        })
      }

      if (Add.AddressType.toLowerCase() == 'permanent address' || Add.AddressType.toLowerCase() == 'permanentaddress') {

        AddressFrm.permenantaddress1.setValue(Add.Address1);
        AddressFrm.permenantaddress2.setValue(Add.Address2);
        AddressFrm.permenantarea.setValue(Add.Area);
        AddressFrm.permenantpincode.setValue(Add.Pincode);
        AddressFrm.permenantTaluk.setValue(Add.Taluk);

        this._srvCommon.getLstCountry().subscribe({
          next: (res: any) => {
            this.LstCountry = res.Data;
            const COUNTRY = this.LstCountry.find(e => e.CountryName.toUpperCase() == Add.Country.toUpperCase());
            if (COUNTRY) {
              AddressFrm.permenantcountry.setValue(COUNTRY);
              this._srvCommon.getLstState(COUNTRY?.CountryID).subscribe(e => {
                this.ShippingState = e.Data;
                const STATE = this.ShippingState.find(e => e.StateProvinceName.toUpperCase() == Add.State.toUpperCase())
                AddressFrm.permenantstate.setValue(STATE);
                this.shipDisabledState = false;
                if (STATE) {
                  this._srvCommon.getLstDistrict(STATE?.StateProvinceID).subscribe(val => {
                    this.ShippingDistrict = val.Data;
                    const DISTRICT = this.ShippingDistrict.find(e => e.DistrictName.toUpperCase() == Add.District.toUpperCase());
                    AddressFrm.permenantdistrict.setValue(DISTRICT);
                    this.shipDisabledDistrict = false;
                  })
                }
              })

            }
          }
        })
      }
    });
    this.compareAddress(data.Address[1], data.Address[0]);
    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
        CourseFrm.courseType.setValue(this.LstCourseType.find(e => e.CourseType.toUpperCase() == data.CourseTypeName.toUpperCase()))

        this._srvCommon.getCourseListInCourseType(this.FrmEntry.controls.courseDetails.value.courseType.CourseTypeID).subscribe({
          next: val => {
            this.LstCourseData = this.LstCourseData1 = val.Data || [];
            CourseFrm.courseName.setValue(this.LstCourseData.find(e => e.CourseID == data.CourseID));
            this.selectCourse(this.LstCourseData.find(e => e.CourseID == data.CourseID))
          }
        });
      }
    })

    this.FrmEntry.controls.personalDetails.controls.image.disable();
  }

  /* Compare two address (Communication & Permanent) */
  compareTwoAddress(comAddress: any, perAddress: any): boolean {
    this.com_address.Address1 = comAddress.Address1;
    this.com_address.Address2 = comAddress.Address2;
    this.com_address.Area = comAddress.Area;
    this.com_address.Country = comAddress.Country;
    this.com_address.State = comAddress.State;
    this.com_address.District = comAddress.District;
    this.com_address.Pincode = comAddress.Pincode;

    this.per_address.Address1 = perAddress.Address1;
    this.per_address.Address2 = perAddress.Address2;
    this.per_address.Area = perAddress.Area;
    this.per_address.Country = perAddress.Country;
    this.per_address.State = perAddress.State;
    this.per_address.District = perAddress.District;
    this.per_address.Pincode = perAddress.Pincode;
    const keys1 = Object.keys(this.com_address);
    const keys2 = Object.keys(this.per_address);
    if (keys1.length !== keys2.length) {
      return false;
    }
    for (const key of keys1) {
      if (key !== "AddressType") {
        if (comAddress[key] !== perAddress[key]) {
          return false;
        }
      }
    }
    return true;
  }

  /* Address Compare */
  compareAddress(comAddress: any, perAddress: any): void {
    if (comAddress.Address1 !== "" && perAddress.Address1 !== "") {
      if (comAddress.Address1 === perAddress.Address1 && comAddress.Address2 === perAddress.Address2 &&
        comAddress.Area === perAddress.Area && comAddress.Country === perAddress.Country &&
        comAddress.State === perAddress.State && comAddress.District === perAddress.District && comAddress.Pincode === perAddress.Pincode) {
        this.copyAddressChecked = this.perDisable = true;
      }
      else this.copyAddressChecked = false;
    }
    else {
      this.FrmEntry.controls['AddressDetails'].reset();
      this.copyAddressChecked = this.perDisable = false;
    }
  }

  imagePreview(data: string) {
    this._srvCommon.previewImage(data).subscribe({
      next: (res: any) => {
        if (res.Data.FileExtension !== '.pdf') {
          this.imageSrc1 = 'data:' + res.Data.MIMEType + ';base64,' + res.Data.ProfileBase64;
          const base64String = this.imageSrc1;
          const fileName = 'profile.jpg';
          const file = this.convertBase64ToFile(base64String, fileName);
          let fileArray = [];
          fileArray.push(file);
          this.MlCreateStudent.studentImage = fileArray[0];
          // this.FrmEntry.controls.personalDetails.controls.image.setValue(this.imageSrc1);
        }
      },
      error: (err: IWebError) => {
        this.errorMsg(err.Message)
        // this.FrmEntry.controls.personalDetails.controls.image.setValue(null);
      }
    });

  }


  /* Change Gurdian Type */
  guard(event: any) {
    this.guardians = event;
  }


  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourseData = [];
    this.Lstbatch = [];
    this.FrmEntry.controls.courseDetails.controls.courseName.setValue(null);
    this.FrmEntry.controls.courseDetails.controls['batch'].setValue(null);
    this.FrmEntry.controls.courseDetails.controls['discount'].setValue(null);
    this.FrmEntry.controls.courseDetails.controls['discountPercent'].setValue(null);

    this.batchInfo = false;
    this.courseData = false;

    if (event && event.CourseTypeID) {
      this._srvCommon.getCourseListInCourseType(event.CourseTypeID).subscribe({
        next: val => {
          this.LstCourseData = this.LstCourseData1 = val.Data || [];
        }
      });
    }
  }



  /*  Filter the batch */
  batchFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.BatchNumber.toLowerCase().includes(normalizedQuery) ||
      data.Timing.toLowerCase().includes(normalizedQuery) ||
      data.FacultyID.toLowerCase().includes(normalizedQuery) ||
      data.BatchType.toLowerCase().includes(normalizedQuery);
    this.Lstbatch = this.batch.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.ShortName.toLowerCase().includes(normalizedQuery) ||
      data.CourseName.toLowerCase().includes(normalizedQuery);
    // data.CourseType.toLowerCase().includes(normalizedQuery);

    this.LstCourseData = this.LstCourseData1.filter(filterExpression);
  }

  countryChange(value: any) {
    this.selectedCountry = value;
    this.selectedState = this.selectedDistrict = undefined;
    this.currentGroup.controls['state'].setValue(null);
    this.currentGroup.controls['district'].setValue(null);

    if (value === undefined) {
      this.isDisabledState = true;
      this.LstState = [];
    }
    else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.LstState = e.Data;
          this.isDisabledState = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }

    this.isDisabledDistrict = true;
    this.LstDistrict = [];
  }

  stateChange(value: any) {
    this.selectedState = value;
    this.selectedDistrict = undefined;
    this.currentGroup.controls['district'].setValue(null);
    if (value === undefined) {
      this.isDisabledDistrict = true;
      this.LstDistrict = [];
    }
    else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.LstDistrict = e.Data;
          this.isDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  districtChange(value: any) {
    this.selectedDistrict = value;
  }

  shipCountry(value: any) {
    this.shipselectedCountry = value;
    this.shipselectedState = undefined;
    this.shipselectedDistrict = undefined;
    this.currentGroup.controls['permenantstate'].setValue(null);
    this.currentGroup.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledState = true;
      this.ShippingState = [];
    } else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.ShippingState = e.Data;
          this.shipDisabledState = false;

        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
    this.shipDisabledDistrict = true;
    this.ShippingDistrict = [];
  }

  shipState(value: any) {
    this.shipselectedState = value;
    this.shipselectedDistrict = undefined;
    this.currentGroup.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledDistrict = true;
      this.ShippingDistrict = [];
    } else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.ShippingDistrict = e.Data;
          this.shipDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
  }

  shipDistrict(value: any) {
    this.shipselectedDistrict = value;
  }


  /* Remanining Balance */
  total(total: number): void {
    this.Totalamount = total;
  }


  public copyAddressChecked: boolean = false;
  public perDisable: boolean = false;
  copyAddress(event: any) {
    this.perDisable = this.copyAddressChecked = event.target.checked;

    if (event.target.checked) {
      this.currentGroup.controls['permenantaddress1'].setValue(this.currentGroup.controls['address1'].value);
      this.currentGroup.controls['permenantaddress2'].setValue(this.currentGroup.controls['address2'].value);
      this.currentGroup.controls['permenantarea'].setValue(this.currentGroup.controls['area'].value);
      this.currentGroup.controls['permenantcountry'].setValue(this.currentGroup.controls['country'].value);
      this.currentGroup.controls['permenantpincode'].setValue(this.currentGroup.controls['pincode'].value);
      this.currentGroup.controls['permenantTaluk'].setValue(this.currentGroup.controls['Taluk'].value);

      if (this.currentGroup.controls['country'].value) {
        this.shipDisabledState = false;
        this.shipDisabledDistrict = true;
        this.ShippingDistrict = [];
        this._srvCommon.getLstState(this.currentGroup.controls['permenantcountry'].value.CountryID).subscribe((e: any) => {
          this.ShippingState = e.Data;
        })
        if (this.currentGroup.controls['state'].value) {
          this.currentGroup.controls['permenantstate'].setValue(this.currentGroup.controls['state'].value);
          this.shipDisabledDistrict = false;
          this._srvCommon.getLstDistrict(this.currentGroup.controls['permenantstate'].value.StateProvinceID).subscribe((e: any) => {
            this.ShippingDistrict = e.Data
          })
          if (this.currentGroup.controls['district'].value) this.currentGroup.controls['permenantdistrict'].setValue(this.currentGroup.controls['district'].value);
          else this.currentGroup.controls['permenantdistrict'].setValue(null);
        }
        else {
          this.shipDisabledDistrict = true;
          this.ShippingDistrict = [];
          this.currentGroup.controls['permenantdistrict'].setValue(null);
          this.currentGroup.controls['permenantstate'].setValue(null);
        }
      }
      else {
        this.shipDisabledState = this.shipDisabledDistrict = true;
        this.ShippingState = this.ShippingDistrict = [];
        this.currentGroup.controls['permenantdistrict'].setValue(null);
        this.currentGroup.controls['permenantstate'].setValue(null);
      }
    }
    else {
      this.ShippingState = this.ShippingDistrict = [];
      this.FrmEntry.controls['address'].controls['permenantaddress1'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantaddress2'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantarea'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantcountry'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantstate'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantdistrict'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantpincode'].setValue(null);
      this.FrmEntry.controls.address.controls.permenantTaluk.setValue(null);
    }
  }

  /* Change the Course */
  selectCourse(event: CourseDetailMl) {
    this.FrmEntry.controls.courseDetails.controls['batch'].setValue(null);
    this.Lstbatch = [];
    this.batchInfo = false;

    this.FrmEntry.controls.courseDetails.controls.discount.setValue(0);
    this.FrmEntry.controls.courseDetails.controls.discountPercent.setValue('0 %')
    this.originalAmount = 0;

    if (event === undefined) {
      this.courseData = false;
      this.isDownPaymentDisabled = true;
    }
    else {
      this.courseData = true;
      this.MlCourse = event;
      this.MlCourse.DiscountAmount = 0;
      this.downPaymentMaxAmount = this.MlCourse.NetAmount = event.CourseFees;
      this.paymentamount = this.downPaymentMinAmount = event.AdmissionFees;
      this.isDownPaymentDisabled = false;
      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValue(this.downPaymentMinAmount);
      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(this.downPaymentMinAmount), Validators.max(this.downPaymentMaxAmount)])

      this.originalAmount = this.MlCourse.NetAmount - this.MlCourse.AdmissionFees;
      this.FrmEntry.controls.courseDetails.controls.discount.setValidators([Validators.max(this.originalAmount)])
      this.FrmEntry.controls.courseDetails.controls.discount.updateValueAndValidity();

      this._srvCommon.getActiveBatchCourseID(event.CourseID).subscribe({
        next: (e) => this.Lstbatch = this.batch = e.Data,
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Change the Batch */
  selectBatch(event: batchByIDDataType) {
    if (event == undefined) this.batchInfo = false;
    else {
      this.batchInfo = true;
      this._srvCommon.getCourseBatchIDList(event.CourseBatchID).subscribe({
        next: (e) => this.MlBatch = this.batch = e.Data,
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Discount the Course Fees */
  // discountchange(event: number) {
  //   this.MlCourse.DiscountAmount = this.MlCourse.CourseFees * event / 100;
  //   this.downPaymentMaxAmount = this.MlCourse.NetAmount = this.MlCourse.CourseFees - this.MlCourse.DiscountAmount;
  //   this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(this.downPaymentMinAmount), Validators.max(this.MlCourse.NetAmount)])
  // }

  /* Down Payment */
  downPayment(event: number) {
    this.paymentamount = event;
  }

  private isStepValid = (index: number) => {
    return this.getGroupAt(index).valid || this.currentGroup.untouched;
  };

  private shouldValidate = (index: number) => {
    return this.getGroupAt(index).touched && this.currentStep >= index;
  };

  public stepActivate(e: StepperActivateEvent) {
    if (!this.currentGroup.valid) {
      e.preventDefault();
      this.currentGroup.markAllAsTouched();
    }
  }

  step = [
    {
      label: 'Personal Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
    {
      label: 'Address',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
    {
      label: 'Course Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    }
  ];

  /* Get File Extension */
  getFileNameWithExt(event: any) {
    if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf(".");
    const ext = name.substring(lastDot + 1);
    this.FileExtension = ext;
  }

  fileChange1(event: any) {
    this.MlCreateStudent.studentImage = [];
    this.getFileNameWithExt(event);
    if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png") {
      const reader = new FileReader();
      this.checkProfilePicFileType = false;
      if (event.target.files && event.target.files.length) {
        if (event.target.files[0].size >= 2097152) {
          this.checkProfilePicFileSize = true;
          this.imageSrc1 = "assets/logo/img_avatar.png";
          this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
          this.MlProfileFile = new ImageUploadResult();
        }
        else {
          const [file1] = event.target.files;
          const file = event.target.files[0];
          this.FrmEntry.controls.personalDetails.controls.image.setValue(file);
          this.MlCreateStudent.studentImage = file;
          this.fileData(file, 'Profile')
          reader.readAsDataURL(file1);
          reader.onload = () => {
            this.imageSrc1 = reader.result as any;
            this.checkProfilePic = false;
            this.checkProfilePicFileSize = false;
          }
        }
      }
    }
    else {
      this.imageSrc1 = "assets/logo/img_avatar.png";
      this.checkProfilePicFileType = true;
      this.checkProfilePic = this.checkProfilePicFileSize = false;
      this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
      this.MlProfileFile = new ImageUploadResult();
    }

  }

  fileData(file: any, type: string) {
    this._srvCommon.postImageUpload(type, file).subscribe({
      next: val => {
        this.MlProfileFile = val.Data;
        this.checkProfilePicChange = true;
      },
      error: (err) => this.errorMsg(err.Message)
    })
  }

  prev() {
    if (this.step[this.currentStep - 1].disabled === true) this.currentStep = this.currentStep - 2;
    else this.currentStep = this.currentStep - 1;
  }


  next() {
    // if (this.currentGroup.valid) {
    //   if (this.currentStep == 0) {
    //     if (this.FrmEntry.controls.personalDetails.value.image) {
    //       // if (!this.checkProfilePicFileSize && !this.checkProfilePicFileType && !this.checkProfilePic)
    //       this.currentStep = this.currentStep + 1;
    //       return;
    //     } else {
    //       this.checkProfilePic = true;
    //     }
    //   } else {
    this.currentStep = this.currentStep + 1;
    //     return;
    //   }
    // }
    // this.currentGroup.markAllAsTouched();

    if (this.currentStep == 2) { }
  }

  goBack() {
    this._srvReq.action.next({ Mode: 'LIST' });
    this._srvReq.stdEnquiryDateRange = true;
  }

  /* FormGroup Value Binding the Model */
  formToModelBinding(data: any) {
    this.FrmEntry.controls.personalDetails.enable();
    this.FrmEntry.controls.address.enable();
    this.FrmEntry.controls.courseDetails.controls.courseName.enable();

    // if (data.personalDetails.type == "New") {
    this.MlCreateStudent.studentName = data.personalDetails.name;
    this.MlCreateStudent.gender = data.personalDetails.gender.GenderName;
    this.MlCreateStudent.dateOfBirth = DateConversion.ConvertToYearMonthDate(data.personalDetails.dob);
    this.MlCreateStudent.phoneCode = data.personalDetails.PhoneCode.PhoneCode
    this.MlCreateStudent.phone = data.personalDetails.mobile;
    this.MlCreateStudent.alternatePhoneCode = data.personalDetails.AlternatePhoneCode.PhoneCode;
    this.MlCreateStudent.alternatePhone = data.personalDetails.altmobile == null ? "" : data.personalDetails.altmobile;
    this.MlCreateStudent.email = data.personalDetails.email;
    // this.MlCreateStudent.qualification = data.personalDetails.qualification.Qualification;
    this.MlCreateStudent.qualification = data.personalDetails.qualification;
    this.MlCreateStudent.guardianType = data.personalDetails.guardian.MinValue;
    this.MlCreateStudent.fatherName = data.personalDetails.guardianName;
    this.MlCreateStudent.occupation = data.personalDetails.occupation;

    this.MlCreateStudent.ReasonToSelect = data.personalDetails.ReasonNotes ?? "";
    this.MlCreateStudent.ReferBy = data.personalDetails.HowToKnow ?? "";
    this.MlCreateStudent.Purpose = data.personalDetails.Purpose ?? "";

    this.MlCreateStudent.address = this.addressData = [];
    this.MlAddress.AddressType = "Communication Address"
    this.MlAddress.Address1 = data.address.address1;
    this.MlAddress.Address2 = data.address.address2 == null ? "" : data.address.address2;
    this.MlAddress.Country = data.address.country.CountryName;
    this.MlAddress.State = data.address.state.StateProvinceName;
    this.MlAddress.District = data.address.district.DistrictName;
    this.MlAddress.Area = data.address.area;
    this.MlAddress.Taluk = data.address.Taluk;
    this.MlAddress.Pincode = data.address.pincode;
    this.addressData.push(this.MlAddress);

    this.MlAddress = new StudentAddressCreate();
    this.MlAddress.AddressType = "Permanent Address"
    this.MlAddress.Address1 = data.address.permenantaddress1;
    this.MlAddress.Address2 = data.address.permenantaddress2 == null ? "" : data.address.permenantaddress2;
    this.MlAddress.Country = data.address.permenantcountry.CountryName;
    this.MlAddress.State = data.address.permenantstate.StateProvinceName;
    this.MlAddress.District = data.address.permenantdistrict.DistrictName
    this.MlAddress.Area = data.address.permenantarea;
    this.MlAddress.Pincode = data.address.permenantpincode;
    this.MlAddress.Taluk = data.address.permenantTaluk;
    this.addressData.push(this.MlAddress);
    this.MlCreateStudent.address = this.addressData;
    // }

    this.MlExistingStudent.paymentItems = [];

    this.PaymentDetails.filter((e: any) => {
      this.MlPayment = new PaymentDetail();
      this.MlPayment.PaymentModeID = e.PaymentModeID;
      this.MlPayment.PayModeType = e.PayModeType;
      this.MlPayment.PayModeValue = e.PayModeValue;
      this.MlPayment.Amount = e.Amount;
      this.MlPayment.LedgerID = e.FromLedger.LedgerID;
      this.MlPayment.LedgerName = e.FromLedger.LedgerName;
      this.MlPayment.TransactionNo = e.TransactionNo;
      this.MlPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
      this.MlPayment.RoundOff = 0;
      this.MlPayment.BankCommission = 0;
      e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID : delete this.MlPayment.DocumentID;

      this.MlExistingStudent.paymentItems.push(this.MlPayment);
    });

    this.MlExistingStudent.studentID = data.personalDetails.type == "New" ? this.studentID : data.personalDetails.record.StudentID;
    this.MlExistingStudent.courseBatchID = data.courseDetails.batch.CourseBatchID;
    // this.MlExistingStudent.discount = data.courseDetails.discount ?? 0;
    this.MlExistingStudent.discount = (this.MlCourse.DiscountAmount / this.MlCourse.CourseFees) * 100;
    this.MlExistingStudent.downPayment = data.courseDetails.downPayment;
    this.MlExistingStudent.StudentEnquiryID = this._srvReq.MlStudentEnquiryData.StudentEnquiryID;
  }

  save(data: any) {

    if (!this.currentGroup.valid) this.currentGroup.markAllAsTouched();
    else if (this.Totalamount == 0) this.errorMsg("Please Add Payment");
    else if (this.paymentamount !== this.Totalamount) this.errorMsg("Please enter full payment");
    else if (this.currentGroup.valid) {
      this.formToModelBinding(data);

      this._srvStudent.createStudent(this.MlCreateStudent).subscribe({
        next: (res: any) => {
          this.studentID = res.Data.StudentID;
          this.MlExistingStudent.studentID = this.studentID;
          this.MlExistingStudent.studentType = 'New';
          this._srvStudent.updateStudentDownPayment(this.MlExistingStudent).subscribe({
            next: (res: any) => {
              new CustomNotification(this._srvNotification).ShowSuccess(res.Message);

              this.FrmEntry.controls.personalDetails.disable();
              this.FrmEntry.controls.address.disable();
              this.FrmEntry.controls.courseDetails.controls.courseName.disable();

              this.title = 'Fees Receipt';
              this.ServerUrl = this.layout.ServerUrl;
              this.bearerToken = this._srvCookie.get(CookieKey.Api);
              this.Reportsource = {
                report: 'iCloud/FeesReceipt(PartPayment)',
              };
              this.open = true;
              this.goBack();
            },
            error: (err: IWebError) => this.errorMsg(err.Message)
          });
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  public get currentGroup(): FormGroup {
    return this.getGroupAt(this.currentStep);
  }

  public getGroupAt(index: number): FormGroup {
    var groups = Object.keys(this.FrmEntry.controls).map((groupName) =>
      this.FrmEntry.get(groupName)) as FormGroup[];
    return groups[index];
  }


  /* Discount the Course Fees */
  discountchange(event: number) {
    // this.MlCourse.DiscountAmount = this.MlCourse.CourseFees * event / 100;
    this.DiscountPercent = 0;
    var discountAmount: number = event

    if (discountAmount > this.originalAmount) discountAmount = this.originalAmount;

    this.MlCourse.DiscountAmount = discountAmount;
    this.downPaymentMaxAmount = this.MlCourse.NetAmount = this.MlCourse.CourseFees - this.MlCourse.DiscountAmount;
    this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(this.downPaymentMinAmount), Validators.max(this.MlCourse.NetAmount)])

    this.FrmEntry.controls.courseDetails.controls.discount.setValue(discountAmount);

    if (discountAmount >= 0 && this.originalAmount > 0) {
      this.DiscountPercent = +((discountAmount / this.MlCourse.CourseFees) * 100).toFixed(2);
      this.discountPercentage = ((discountAmount / this.MlCourse.CourseFees) * 100).toFixed(2) + '%';

    } else {
      this.discountPercentage = '0 %';
      this.DiscountPercent = 0;
    }
    this.FrmEntry.controls.courseDetails.controls.discountPercent.setValue(this.discountPercentage);
    if (discountAmount > (this.MlCourse.CourseFees - this.MlCourse.AdmissionFees)) {
      this.FrmEntry.controls.courseDetails.controls.downPayment.setValue(this.MlCourse.CourseFees - discountAmount);
      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(0), Validators.max(this.MlCourse.NetAmount)])
      this.paymentamount = this.MlCourse.CourseFees - discountAmount;
    } else {
      this.FrmEntry.controls.courseDetails.controls.downPayment.setValue(this.MlCourse.AdmissionFees);
      this.paymentamount = this.MlCourse.AdmissionFees;
    }
  }
  /* Close Telerik Report */
  close(): void {
    this.open = false;
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

  convertBase64ToFile(base64: string, fileName?: string): File | Blob {
    // Split the Base64 string to get data
    const [metadata, data] = base64.split(',');
    const mime = metadata.match(/:(.*?);/)?.[1] || '';
    const binaryString = atob(data);

    // Convert binary string to array buffer
    const arrayBuffer = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      arrayBuffer[i] = binaryString.charCodeAt(i);
    }

    // Create a Blob object
    const blob = new Blob([arrayBuffer], { type: mime });

    // If fileName is provided, create a File object
    if (fileName) {
      return new File([blob], fileName, { type: mime });
    }
    return blob;
  }


  public notesMaxlength = 150;
  public notesCounter: string = '0/150';

  notesValueChange(event: string) {
    var charachtersCount = event.length;
    this.notesCounter = `${charachtersCount}/${this.notesMaxlength}`;
  }
}
