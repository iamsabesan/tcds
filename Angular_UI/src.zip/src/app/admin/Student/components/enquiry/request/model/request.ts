
export interface PathRoute {
  Mode: 'LIST' | 'VIEW'
}


export class StudentEnquirylistMl {
  StudentEnquiryID: string = '';
  TenantBranchID: string = '';
  CourseID: string = '';
  Course: string = '';
  CourseTypeName: string = '';
  StudentName: string = '';
  Gender: string = '';
  DateOfBirth: string = '';
  PhoneCode: string = '';
  Phone: string = '';
  AlternatePhoneCode: string = '';
  AlternatePhone: string = '';
  Email: string = '';
  Qualification: string = '';
  GuardianType: string = '';
  GuardianName: string = '';
  Occupation: string = '';
  ReasonToSelect: string = '';
  Purpose: string = '';
  ReferBy: string = '';
  RequestedDate: string = '';
  ReqDate: Date;
  Status: string = '';
  DocumentID: string = '';
  Address: Address[] = [];
}

export class Address {
  StudentAddressID: string = '';
  StudentEnquiryID: string = '';
  AddressType: string = '';
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Pincode: string = '';
  Taluk: string = '';
}

export class StudentRejectMl {
  StudentEnquiryID: string = '';
  Reason: string = '';
}