import { Component } from "@angular/core";
import { RequestService } from "./service/request.service";

@Component({
    selector: 'request',
    templateUrl: 'request.component.html',
    providers: [RequestService]

})

export class RequestComponent {
    public actions: string = '';
    constructor(private _srvReq: RequestService) {
        this._srvReq.action.subscribe(e => this.actions = e.Mode);
    }
}