import { NgModule } from "@angular/core";

import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { LabelModule } from "@progress/kendo-angular-label";
import { RequestComponent } from "./request.component";
import { ListComponent } from "./components/list/list.component";
import { ViewComponent } from "./components/view/view.component";
import { RequestService } from "./service/request.service";
// import { PaymentGridModule } from "src/app/shared/components/payment-grid/payment-grid.module";
import { StudentCourseDetailModule } from "src/app/shared/components/student-course-detail/student-course-detail.module";
import { CourseDetailModule } from "src/app/shared/components/course-detail/course-detail.module";
import { DatePickerModule } from "@progress/kendo-angular-dateinputs";
import { PaymentGridModule } from "src/app/shared/components/payment-grid/payment-grid.module";
import { DialogModule } from "@progress/kendo-angular-dialog";
// import { StudentService } from "../../../services/student.service";

const routes = [
    {
        path: '',
        component: RequestComponent
    }
]

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        ReactiveFormsModule,
        GridModule,
        LabelModule,
        DatePickerModule,
        DialogModule,

        RejectModule,
        DateRangesModule,
        PaymentGridModule,
        StudentCourseDetailModule,
        CourseDetailModule,
    ],
    declarations: [
        RequestComponent,
        ListComponent,
        ViewComponent
    ],
    providers: [
        RequestService,
        // StudentService
    ]
})
export class RequestModuel { }