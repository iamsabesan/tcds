import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { HttpService } from "src/core/service";
import { IRequestType } from "src/core/model";
import { StudentEnquirylistMl, StudentRejectMl } from "../model/request";

@Injectable()

export class RequestService {

    public MllstFliterData = new DateRanges();
    public listPageSize: any = 15;
    public listPageSkip: any = 0;
    stdEnquiryDateRange = false;
    public MlStudentEnquiryData: StudentEnquirylistMl = new StudentEnquirylistMl();

    public action = new BehaviorSubject<{ Mode: 'LIST' | 'VIEW' }>({ Mode: 'LIST' });

    constructor(private _http: HttpService) { }

    getEnquiryList(fromDate: string, toDate: string, nameOrPhone: string) {
        return this._http.get(`/icloud-admission/v1/student/enquiry/list?fromDate=${fromDate}&toDate=${toDate}&nameOrPhone=${nameOrPhone}`, { RequestType: IRequestType.Protected })
    }

    postStudentReject(data: StudentRejectMl) {
        return this._http.post('/icloud-admission/v1/student/enquiry/reject', data, { RequestType: IRequestType.Protected })
    }
}