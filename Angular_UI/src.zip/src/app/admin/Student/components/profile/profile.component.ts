import { Component, HostListener, Input, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CustomNotification } from 'src/app/shared/model/shared';
import { Router } from '@angular/router';
import { DateConversion, DropDownFilter, LocalString, getUrl, gridFontStyle } from 'src/app/shared/app-global';
import { IntlService } from '@progress/kendo-angular-intl';
import { StudentService } from '../../services/student.service';
import { Country, District, MultiDropdownColumn, PhoneCode, RelationShipListMl, State, StudentBasicDetail, StudentColumn, gender_lst } from 'src/app/shared/model/common';
import { Address, Certificate, Course, CourseData, directStudentViewDataType, PaymentData, StudentCourseBasicDetail, StudentDiscontinueMl, StudentEditMl, StudentMaterialIssue, StudentPartPayment, StudentProfile } from '../../models/student-profile';
import { IWebError } from 'src/core/model';
import { CookieService } from 'ngx-cookie-service';
import { CookieKey } from 'src/core/helper';
import { CommonService } from 'src/app/shared/service/common.service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { AppService } from 'src/core/service';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { PaymentGridComponent } from 'src/app/shared/components/payment-grid/payment-grid.component';
// import { EditStudentComponent } from 'src/app/shared/components/edit-student/edit-student.component';
// import { DialogRef, DialogService } from '@progress/kendo-angular-dialog';
import { Occupation, Qualification, StudentAddressCreate } from 'src/app/shared/model/student-profile';
import { ImageUploadResult } from 'src/app/shared/model/payment';
import { InputRegex } from 'src/app/shared/components/regex';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})

export class ProfileComponent {

  /* View Child */
  @ViewChild(PaymentGridComponent, { static: false }) childRef!: PaymentGridComponent;

  /* List */
  public LstStudent: StudentBasicDetail[] = [];
  public LststudentBaseData: StudentBasicDetail[] = [];
  public Lstcourse: StudentCourseBasicDetail[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public LstCertificate: Certificate[] = [];

  /* MultiColumn Combobox */
  public LstStudentColumn: MultiDropdownColumn[] = StudentColumn;

  /* Model */
  private _studentCourseDataType: StudentCourseBasicDetail = new StudentCourseBasicDetail();
  public get studentCourseDataType(): StudentCourseBasicDetail {
    return this._studentCourseDataType;
  }
  public set studentCourseDataType(value: StudentCourseBasicDetail) {
    this._studentCourseDataType = value;
  }
  public MlOneStudent: StudentProfile = new StudentProfile();
  public MlCourseDetail: CourseData = new CourseData();
  public MlStudentPartPayment: StudentPartPayment = new StudentPartPayment();
  public MlStudentPayment: PaymentData = new PaymentData();
  public MlSingleStudent: StudentBasicDetail = new StudentBasicDetail();
  public MlStudentMaterialIssue: StudentMaterialIssue = new StudentMaterialIssue();
  public gridStyle: gridFontStyle = new gridFontStyle('medium');
  public MlStudentCourseFees: Course = new Course();
  public MlDiscontinueStudent: StudentDiscontinueMl = new StudentDiscontinueMl();


  /* Format */
  public currencySymbol = '';
  public dateFormat: string = "";

  /* Payment Transaction */
  public paymentamount = 0;
  public ErrorNotification = 'Please Enter Valid Fees Amount';
  public ErrorNotify = 'Fees Amount must be equal with Total Amount';
  public Totalamount: number = 0;

  /* Specific URL Path */
  public previousUrl: string = '';
  public currentUrl: string = '';

  /* Select the Tab Section */
  public feesTab: boolean;
  public courseTab: boolean;
  public materialTab: boolean;
  public IsShowStudentDetail: boolean;
  public showSelectCourse: boolean;
  public IsShowStudentCourseInfo: boolean;

  /* Go Back Button */
  public showFooter: boolean = false;

  /* Telerik Report */
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened: boolean = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken: string = "";

  public isPaymentDisabled: boolean = false;
  public disbledDepositFrom = false;
  /* Get Student BatchMapping ID */
  public StudentBatchMappingID: string = "";
  public StudentId: string = '';

  /* Concat Image binding Base64*/
  public Image: any;

  CountryCurrencyType: string = 'Rs. '
  CountryCurrencyEnd: string = '/-'

  /* Grid Pagination */
  public buttonCount = 5;
  skip = 0;
  pageSize = 5;
  public sizes: any[] = [5, 15, 20, 50, "All"];

  /* Student Marksheet List Option */
  public LstMarksheetOption = [
    {
      text: "Issue",
    },
    {
      text: "View"
    }
  ];

  public dialogDetailsWidth = 450;
  public ShowDiscontinueDialog = false;


  public notesMaxlength = 150;
  public notesCounter: string = '0/150';

  /* Set Timer */
  private _setTimer: number = 500;

  /* For Responsiveness */
  getScreenWidth: any;
  getScreenHeight: any;
  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight - 75;
    window.innerWidth > 1550 || window.innerWidth < 1100 ? this.dialogDetailsWidth = 480 : this.dialogDetailsWidth = 450;
  }

  /* Form Group */
  feesForm = this.fb.group({
    feeAmount: new FormControl(null, [Validators.required]),
  });

  DiscontinueFrmEntry = this.fb.group({
    reason: ['']
  });

  /* Student Edit After Use Varaible */
  private _studentBatchMappingID: string = '';
  private _IsEditStudent: boolean = false;

  // private ngZone: NgZone private _srvDialog: DialogService,
  constructor(public fb: FormBuilder,
    private _srvNotification: NotificationService, private _srvStudent: StudentService,
    private _router: Router, public CurrencyService: IntlService, private _srvCommon: CommonService,
    private _srvCookie: CookieService, private layout: LayoutComponent,
    private _srvApp: AppService,) { }

  ngOnInit() {
    this.getStdBasicData();
    if (this._srvApp.val.ContactID) this.getStudentData();
    this.reRouting();
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;

  }

  /* Get All Student List */
  getStdBasicData() {
    this._srvCommon.getStudentBasicDetail().subscribe({
      next: (e) => this.LstStudent = this.LststudentBaseData = e.Data,
      error: (err) => this.errorMsg(err.Message)
    })
  }

  /* IsAvailable the Service Value */
  getStudentData() {
    this.MlSingleStudent = this._srvApp.val;
    this.getStudentDetails(this._srvApp.val.ContactID);
  }

  public StudentID: string = '';
  /* Select the Student */
  studentDetail(event: any) {
    this.MlOneStudent = new StudentProfile();
    if (event) {
      this.getStudentDetail(event.ContactID);
      this.StudentID = event.StudentID;
    }
    else this.IsShowStudentDetail = this.IsShowStudentCourseInfo = this.showSelectCourse = false;
    this.feesForm.reset();
  }

  getStudentDetail(data: string) {
    this.getStudentDetails(data);
  }

  /* Get Stduent Detail With Using StudentID */
  getStudentDetails(data: string) {
    this.StudentId = data;
    this.MlOneStudent = new StudentProfile();
    this.Lstcourse = [];
    this.StudentBatchMappingID = '';
    this._srvStudent.getStudentProfileGetByIdData(data).subscribe({
      next: (res: any) => {
        this.IsShowStudentDetail = true;
        this.MlOneStudent = res.Data;
        this.MlOneStudent.Courses.map(e => e.FullName = e.ShortName + ' - ' + e.FullName);
        this.Lstcourse = this.MlOneStudent.Courses;

        if (this.MlOneStudent.StudentImages.length !== 0)
          this.Image = "data:" + this.MlOneStudent.StudentImages[0].MIMEType + ";base64," + this.MlOneStudent.StudentImages[0].ProfileBase64
        else this.Image = 'assets/logo/img_avatar.png'

        /* Binding the Address (Communication & Permanent) */
        this.bindingAddress();
        if (this.MlOneStudent.Courses.length && !this._srvApp.val.ContactID && !this._IsEditStudent) {
          this.studentCourseDataType = this.MlOneStudent.Courses[0];
          this.studentCourseDataType.BatchMappingID = this._studentBatchMappingID = this.MlOneStudent.Courses[0].BatchMappingID;
          setTimeout(() => this.getStudentCourseDetail(this.studentCourseDataType.BatchMappingID), this._setTimer);
          this.StudentBatchMappingID = this.studentCourseDataType.BatchMappingID;
        }

        else if (this._srvApp.val && !this._IsEditStudent) {
          this.StudentBatchMappingID = this.studentCourseDataType.BatchMappingID = this._studentBatchMappingID = this.MlSingleStudent.BatchMappingID;
          setTimeout(() => this.getStudentCourseDetail(this.MlSingleStudent.BatchMappingID), this._setTimer);
        }
        this._IsEditStudent = false;
      }

    });
  }

  /* Address Binding */
  bindingAddress() {
    this.MlOneStudent.Address.forEach((e) => {
      if (e.AddressType === 'Permanent Address') this.MlOneStudent.permentAddress = e;
      else this.MlOneStudent.currentAddress = e;
    });
    this.MlOneStudent.currentAddress.Address = (!this.MlOneStudent.currentAddress.Address2) ? this.MlOneStudent.currentAddress.Address1 : this.MlOneStudent.currentAddress.Address1 + ", " + this.MlOneStudent.currentAddress.Address2;
    this.MlOneStudent.permentAddress.Address = (!this.MlOneStudent.permentAddress.Address2) ? this.MlOneStudent.permentAddress.Address1 : this.MlOneStudent.permentAddress.Address1 + ", " + this.MlOneStudent.permentAddress.Address2;
  }

  /* Select Student Courses */
  selectCourse(event: StudentCourseBasicDetail) {
    this.IsShowStudentCourseInfo = false;
    this.StudentBatchMappingID = '';
    if (event) {
      this.getStudentCourseDetail(event.BatchMappingID);
      this.StudentBatchMappingID = this._studentBatchMappingID = event.BatchMappingID;
    }
  }

  isDisableDiscontinue: boolean = false;
  /* Get Student Course, Batch, Material, Fees Detail */
  getStudentCourseDetail(data: string) {
    this.MlCourseDetail = new CourseData()
    this._srvStudent.getStudentCourseGetBatchMappingId(data).subscribe({
      next: (e) => {
        this.MlCourseDetail = e.Data;

        let date1 = new Date();
        let date2 = DateConversion.ConvertStringToDate(this.MlCourseDetail.Batch.EndDate);

        this.isDisableDiscontinue = date1 > date2;
        this.MlStudentCourseFees = this.MlCourseDetail.Course;
        this.LstCertificate[0] = this.MlCourseDetail.Certificate;
        this.LstCertificate = this.LstCertificate.filter((e) => e.CertificateAndMarksheetID !== '00000000-0000-0000-0000-000000000000');
        this.IsShowStudentCourseInfo = true;
        if (this._srvApp.val.ContactID == "") {
          this.courseTab = true;
        }
        this.isPaymentDisabled = e.Data.Course.Balance == 0 ? true : false;
        this.feesForm.controls['feeAmount'].setValidators([Validators.required, Validators.max(this.MlStudentCourseFees.Balance)]);
        this.MlCourseDetail.Marksheet.forEach((E) => {
          E.EditOptions = [
            { text: "Issue", disabled: E.Status == 'Issued' },
            { text: "View", disabled: false }
          ];
        })
        this._srvApp.val = new directStudentViewDataType();
        this.MlCourseDetail.Course.TotalDiscountAmount = this.MlCourseDetail.Course.CourseFees - this.MlCourseDetail.Course.TotalFees;

      },
      error: (err) => {
        this.IsShowStudentCourseInfo = false;
        this.errorMsg(err.Message);
        this._srvApp.val = new directStudentViewDataType();

      }
    })

  }

  /* Filter the Student & Course Data */
  studentFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.RollNumber.toLowerCase().includes(normalizedQuery) ||
      data.StudentName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery)
    this.LstStudent = this.LststudentBaseData.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string) {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.FullName.toLowerCase().includes(normalizedQuery) ||
      data.ShortName.toLowerCase().includes(normalizedQuery)
    this.MlOneStudent.Courses = this.Lstcourse.filter(filterExpression);
  }

  //#region Material Issue
  /* Student Material Issue */
  btnMaterialIssue(event: any) {
    this.MlStudentMaterialIssue.ContactID = this.MlOneStudent.ContactID;
    this.MlStudentMaterialIssue.StudentID = this.MlSingleStudent.StudentID;
    this.MlStudentMaterialIssue.batchMappingID = this.StudentBatchMappingID;
    this.MlStudentMaterialIssue.materialID = event.MaterialID;
    this._srvStudent.postStudentMaterialIssue(this.MlStudentMaterialIssue).subscribe({
      next: (e) => {
        new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
        setTimeout(() => this.getStudentCourseDetail(this.StudentBatchMappingID), this._setTimer)
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }
  //#endregion

  //#region Fees
  /* Student Part Payment Fees */
  feesSubmit() {
    if (this.feesForm.valid === true) {
      if (this.Totalamount == 0) this.errorMsg("Please add payment");
      else if (this.Totalamount !== this.paymentamount) this.errorMsg("Fees amount is pending");
      else {
        this.MlStudentPartPayment.paymentItems = [];
        this.PaymentDetails.forEach((e: any) => {
          this.MlStudentPayment = new PaymentData();

          this.MlStudentPayment.Amount = e.Amount;
          this.MlStudentPayment.PaymentModeID = e.PaymentModeID;
          this.MlStudentPayment.PayModeType = e.PayModeType;
          this.MlStudentPayment.PayModeValue = e.PayModeValue;
          this.MlStudentPayment.LedgerID = e.FromLedger.LedgerID;
          this.MlStudentPayment.LedgerName = e.FromLedger.LedgerName;
          this.MlStudentPayment.TransactionNo = e.TransactionNo;
          this.MlStudentPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
          this.MlStudentPayment.RoundOff = 0;
          this.MlStudentPayment.BankCommission = 0;
          e.DocumentID ? this.MlStudentPayment.DocumentID = e.DocumentID : delete this.MlStudentPayment.DocumentID;

          this.MlStudentPartPayment.paymentItems.push(this.MlStudentPayment)
        })
        this.MlStudentPartPayment.batchMappingID = this.StudentBatchMappingID;
        this.MlStudentPartPayment.partPayment = this.Totalamount;

        this._srvStudent.postStudentPartPayment(this.MlStudentPartPayment).subscribe({
          next: (e) => {
            new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
            this.btnResetFees();
            this._srvApp.val.ContactID = this._srvApp.ContactID
            setTimeout(() => {
              this.getStudentCourseDetail(this.StudentBatchMappingID)
            }, this._setTimer);
          },
          error: (err) => this.errorMsg(err.Message)
        })
      }
    }
    else {
      this.errorMsg("Please add fees amount");
      this.feesForm.markAllAsTouched();
    };

  }

  total(total: number): void {
    this.Totalamount = total;
  }

  btnResetFees() {
    this.feesForm.reset();
    this.PaymentDetails = [];
    this.childRef.paymentmessage = true;
    this.childRef.Totalamount = this.paymentamount = 0;
  }

  /* Enter the Fees Amount */
  onChange(data: number) {
    this.paymentamount = this.MlStudentCourseFees.Balance < data ? 0 : data
  }
  //#endregion

  //#region Certificate Issue
  /* Student Marksheet Issue */
  btnChangeMarksheet(event: any, data: Certificate) {
    if (event.text == 'Issue') this.updateCertificateAndMarksheet(data.CertificateAndMarksheetID);
    else {
      /* Open the Telerik Report Marksheet */
      this.getWindowDimesion(window);
      this.title = 'Marksheet';
      this.opened = true;
      this.viewerContainerStyle = this.layout.viewerContainerStyle;
      this.bearerToken = this._srvCookie.get(CookieKey.Api);
      this.ServerUrl = this.layout.ServerUrl;
      this.Reportsource = {
        report: 'iCloud/Marksheet',
        parameters: {
          Authorization: this.bearerToken, Agent: window.navigator.userAgent, examIndentTransiD: data.ExamIndentTransID
        }
      };
    }
  }

  /* Report Dialog Close */
  close() {
    this.opened = false;
  }

  /* Student Certificate Issue */
  btnCertificateIssue(event: Certificate) {
    this.updateCertificateAndMarksheet(event.CertificateAndMarksheetID);
  }

  updateCertificateAndMarksheet(CertificateAndMarksheetID: string) {
    this._srvStudent.updateCertificateStatus(CertificateAndMarksheetID).subscribe({
      next: (res: any) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
        setTimeout(() => this.getStudentCourseDetail(this.StudentBatchMappingID), this._setTimer);
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    })
  }
  //#endregion

  /* Go to Previous Component */
  btnGoBack() {
    this._router.navigate([getUrl.invokingUrl]);
    this._srvStudent.checkGoBack = true;
    if (getUrl.invokingUrl === '/iCloud/fees/balance-list') {
      this._srvApp.FeesCheckGoBack = false
      this._srvApp.checkGoBack = true;
    }
  }

  reRouting() {
    if (this._srvApp.checkStudentView) {
      this.IsShowStudentDetail = this.IsShowStudentCourseInfo = false;
      if (getUrl.invokingUrl == '/iCloud/fees/balance-list') {
        this.showFooter = this.feesTab = true;
        this.courseTab = this.materialTab = false;
      }
      else if (getUrl.invokingUrl == '/iCloud/indent/pending-list') {
        this.showFooter = this.materialTab = true;
        this.feesTab = this.courseTab = false;
      }
      else if (getUrl.invokingUrl == '/iCloud/student/student-list') this.showFooter = this.courseTab = true;
      else if (getUrl.invokingUrl == '/iCloud/student/alumnus') this.showFooter = this.courseTab = true;
      else {
        this.courseTab = true;
        this.feesTab = this.materialTab = false;
      }
      this._srvApp.checkStudentView = false;
    }
  }

  Edit() {
    this.IsOpenStudentEditDialog = true;
    this.currentStep = 0;
    this.FrmDataBinding(this.MlOneStudent);
  }

  ClickDiscontinue() {
    this.ShowDiscontinueDialog = true;
    this.MlDiscontinueStudent.BatchMappingID = this.MlCourseDetail.Course.BatchMappingID;

  }

  DiscontinueStudent() {
    if (this.DiscontinueFrmEntry.valid) {
      this.MlDiscontinueStudent.Reason = this.DiscontinueFrmEntry.value.reason;
      this._srvStudent.postStudentDiscontinue(this.MlDiscontinueStudent).subscribe({
        next: val => {
          new CustomNotification(this._srvNotification).ShowSuccess(val.Message);
          this.DiscontinueDialogClose();
          setTimeout(() => this.getStudentCourseDetail(this.StudentBatchMappingID), this._setTimer);
        }, error: err => this.errorMsg(err.Message)
      })
    }
    this.DiscontinueFrmEntry.markAllAsTouched();
  }

  DiscontinueDialogClose() {
    this.ShowDiscontinueDialog = false;
    this.DiscontinueFrmEntry.reset();
    this.MlDiscontinueStudent = new StudentDiscontinueMl();
    this.notesCounter = '0/150';
  }

  notesValueChange(event: string) {
    var charachtersCount = event.length;
    this.notesCounter = `${charachtersCount}/${this.notesMaxlength}`;
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }

  /* Student Edit */
  @Input() MlStudentData: StudentProfile = new StudentProfile();

  /* List */
  public addressData: StudentAddressCreate[] = [];
  public LstCountry: Country[] = [];
  public LstState: State[] = [];
  public LstDistrict: District[] = [];
  public LstPhoneCode: PhoneCode[] = [];
  public LstOccupation: Occupation[] = [];
  public LstQualification: Qualification[] = [];
  public LstGender: gender_lst[] = [];
  public LstGuardian: RelationShipListMl[] = [];

  /* Model */
  public MlAddress: Address = new Address();
  public MlProfileFile = new ImageUploadResult();
  public com_address: StudentAddressCreate = new StudentAddressCreate();
  public per_address: StudentAddressCreate = new StudentAddressCreate();
  public MlStudentEdit: StudentEditMl = new StudentEditMl();


  /* Pattern */
  public Name = InputRegex.Name;
  public Email = InputRegex.Email;
  public Mobile = InputRegex.Mobile;
  public Pincode = /^(6)?[1-9][0-9]{5}$/;

  /* Input decimal point not allow */
  public existing: boolean = false;
  public existingDisabled: boolean = false;
  public IsOpenStudentEditDialog: boolean = false;

  /* Payment Details */
  // public paymentamount: number = 0;
  // public ErrorNotification: string = 'Please enter valid Amount';
  // public ErrorNotify: string = 'Fees amount must be equal with total amount';
  // public Totalamount: number = 0;
  // public Balanceamount: number = 0;
  // public isDownPaymentDisabled: boolean = true;
  // public downPaymentMinAmount: number = 0;
  // public downPaymentMaxAmount: number = 0;
  // public disbledDepositFrom = false;
  // public currencySymbol: string = '';

  /* Address Selection */
  public isDisabledState: boolean = true;
  public isDisabledDistrict = true;
  public selectedCountry: any;
  public selectedState: any;
  public selectedDistrict: any;
  public CountryID: string = '';
  public ShippingState!: Array<{
    StateProvinceID: number;
    StateProvinceName: string;
  }>;

  public ShippingDistrict!: Array<{
    DistrictID: number;
    DistrictName: string;
  }>;

  public shipDisabledState: boolean = true;
  public shipDisabledDistrict: boolean = true;
  public shipselectedCountry: any;
  public shipselectedState: any;
  public shipselectedDistrict: any;

  public courseData: boolean = false;
  public batchInfo: boolean = false;

  /* Existing Student is True Disabled the Step 1 */
  public IsStep1: boolean = true;

  /* Date & Time Format */
  public timeFormat: string = '';
  public time: string = '';
  // public dateFormat: string = '';

  /* Get Image File Extension */
  public FileExtension: string = "";

  public imageSrc1?: any;
  public studentID: string = '';
  public currentStep: number = 0;

  public guardians: string = 'Father';
  public open: boolean = false;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;
  public StartWithFilterSettings = DropDownFilter.StartWithfilterSettings;

  public checkProfilePic = false;
  public checkProfilePicFileSize = false;
  public checkProfilePicFileType = false;
  public checkProfilePicChange = false;

  FrmEntry = new FormGroup({
    personalDetails: this.fb.group({
      name: [],
      gender: [],
      dob: [],
      PhoneCode: [],
      mobile: [],
      AlternatePhoneCode: [],
      altmobile: [],
      email: [],
      qualification: [],
      guardian: [],
      guardianName: [],
      occupation: [],
      image: [null],
    }),
    address: this.fb.group({
      address1: [],
      address2: [],
      area: [],
      country: [],
      state: [],
      district: [],
      pincode: [],
      permenantaddress1: [],
      permenantaddress2: [],
      permenantarea: [],
      permenantcountry: [],
      permenantstate: [],
      permenantdistrict: [],
      permenantpincode: [],
      Taluk: [],
      permenantTaluk: []
    })
  });

  FrmDataBinding(data: StudentProfile) {
    var PersonalDetails = this.FrmEntry.controls.personalDetails.controls;
    var AddressDetails = this.FrmEntry.controls.address.controls;
    this.checkProfilePicChange = false;

    PersonalDetails.altmobile.setValue(data.AlternatePhone);
    PersonalDetails.dob.setValue(DateConversion.ConvertStringToDateYYMMDD(data.DateOfBirth));
    PersonalDetails.email.setValue(data.Email);
    PersonalDetails.guardianName.setValue(data.FatherName);
    if (data.StudentImages.length) PersonalDetails.image.setValue(data.StudentImages[0]);
    PersonalDetails.mobile.setValue(data.Phone);
    PersonalDetails.name.setValue(data.StudentName);
    PersonalDetails.qualification.setValue(data.Qualification);

    this._srvCommon.getPhoneCode().subscribe({
      next: (e) => {
        this.LstPhoneCode = e.Data;
        PersonalDetails.AlternatePhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.AlternatePhoneCode));
        PersonalDetails.PhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.PhoneCode));
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });


    this._srvCommon.getLstGender().subscribe(e => {
      this.LstGender = e.Data;
      PersonalDetails.gender.setValue(this.LstGender.find(e => e.GenderName.toUpperCase() == data.Gender.toUpperCase()));
    })

    this._srvCommon.getStudentQualification().subscribe(e => {
      this.LstQualification = e.Data;
    })

    this._srvCommon.getOccupationData().subscribe(e => {
      this.LstOccupation = e.Data;
      const Occupation = this.LstOccupation.find(val => val.Occupation.toUpperCase() == data.Occupation.toUpperCase());
      Occupation ? PersonalDetails.occupation.setValue(Occupation.Occupation) : PersonalDetails.occupation.setValue(data.Occupation);
    })

    this._srvCommon.getRelationShipLst().subscribe(e => {
      this.LstGuardian = e.Data;
      PersonalDetails.guardian.setValue(this.LstGuardian.find(val => val.MinValue.toUpperCase() == data.GuardianType.toUpperCase()));
    })


    AddressDetails.address1.setValue(data.currentAddress.Address1);
    AddressDetails.address2.setValue(data.currentAddress.Address2);
    AddressDetails.area.setValue(data.currentAddress.Area);
    AddressDetails.Taluk.setValue(data.currentAddress.Taluk);
    this._srvCommon.getLstCountry().subscribe(country => {
      this.LstCountry = country.Data;
      AddressDetails.country.setValue(this.LstCountry.find(e => e.CountryName.toUpperCase() == data.currentAddress.Country.toUpperCase()));
      this._srvCommon.getLstState(AddressDetails.country.value.CountryID).subscribe(e => {
        this.LstState = e.Data;
        AddressDetails.state.setValue(this.LstState.find(e => e.StateProvinceName.toUpperCase() == data.currentAddress.State.toUpperCase()));
        this.isDisabledState = false;

        this._srvCommon.getLstDistrict(AddressDetails.state.value.StateProvinceID).subscribe(val => {
          this.LstDistrict = val.Data;
          AddressDetails.district.setValue(this.LstDistrict.find(e => e.DistrictName.toUpperCase() == data.currentAddress.District.toUpperCase()));
          this.isDisabledDistrict = false;
        });
      });

      AddressDetails.permenantcountry.setValue(this.LstCountry.find(e => e.CountryName.toUpperCase() == data.permentAddress.Country.toUpperCase()));
      this._srvCommon.getLstState(AddressDetails.permenantcountry.value.CountryID).subscribe(e => {
        this.ShippingState = e.Data;
        AddressDetails.permenantstate.setValue(this.ShippingState.find(e => e.StateProvinceName.toUpperCase() == data.permentAddress.State.toUpperCase()));
        this.shipDisabledState = false;
        this._srvCommon.getLstDistrict(AddressDetails.permenantstate.value.StateProvinceID).subscribe(val => {
          this.ShippingDistrict = val.Data;
          AddressDetails.permenantdistrict.setValue(this.ShippingDistrict.find(e => e.DistrictName.toUpperCase() == data.permentAddress.District.toUpperCase()));
          this.shipDisabledDistrict = false;
        })
      })

    })
    AddressDetails.permenantaddress1.setValue(data.permentAddress.Address1);
    AddressDetails.permenantaddress2.setValue(data.permentAddress.Address2);
    AddressDetails.permenantarea.setValue(data.permentAddress.Area);
    AddressDetails.permenantpincode.setValue(data.permentAddress.Pincode);
    AddressDetails.pincode.setValue(data.currentAddress.Pincode);
    AddressDetails.permenantTaluk.setValue(data.permentAddress.Taluk)
    if (this.compareTwoAddress(data.currentAddress, data.permentAddress)) this.copyAddressChecked = this.perDisable = true;
    else this.copyAddressChecked = this.perDisable = false;

    if (data.StudentImages.length) this.imageSrc1 = "data:" + data.StudentImages[0].MIMEType + ";base64," + data.StudentImages[0].ProfileBase64
    else {
      this.imageSrc1 = "assets/logo/img_avatar.png";
      this.checkProfilePic = this.checkProfilePicFileSize = this.checkProfilePicFileType = false;
    }
  }

  /* Compare two address (Communication & Permanent) */
  compareTwoAddress(comAddress: any, perAddress: any): boolean {
    this.com_address.Address1 = comAddress.Address1;
    this.com_address.Address2 = comAddress.Address2;
    this.com_address.Area = comAddress.Area;
    this.com_address.Country = comAddress.Country;
    this.com_address.State = comAddress.State;
    this.com_address.District = comAddress.District;
    this.com_address.Pincode = comAddress.Pincode;

    this.per_address.Address1 = perAddress.Address1;
    this.per_address.Address2 = perAddress.Address2;
    this.per_address.Area = perAddress.Area;
    this.per_address.Country = perAddress.Country;
    this.per_address.State = perAddress.State;
    this.per_address.District = perAddress.District;
    this.per_address.Pincode = perAddress.Pincode;
    const keys1 = Object.keys(this.com_address);
    const keys2 = Object.keys(this.per_address);
    if (keys1.length !== keys2.length) {
      return false;
    }
    for (const key of keys1) {
      if (key !== "AddressType") {
        if (comAddress[key] !== perAddress[key]) {
          return false;
        }
      }
    }
    return true;
  }

  public get currentGroup(): FormGroup {
    return this.getGroupAt(this.currentStep);
  }

  public getGroupAt(index: number): FormGroup {
    var groups = Object.keys(this.FrmEntry.controls).map((groupName) =>
      this.FrmEntry.get(groupName)) as FormGroup[];
    return groups[index];
  }

  private isStepValid = (index: number) => {
    return this.getGroupAt(index).valid || this.currentGroup.untouched;
  };

  private shouldValidate = (index: number) => {
    return this.getGroupAt(index).touched && this.currentStep >= index;
  };

  public stepActivate(e: StepperActivateEvent) {
    if (!this.currentGroup.valid) {
      e.preventDefault();
      this.currentGroup.markAllAsTouched();
    }
  }

  step = [
    {
      label: 'Personal Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
    {
      label: 'Address',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
  ];


  /* Get File Extension */
  getFileNameWithExt(event: any) {
    if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf(".");
    const ext = name.substring(lastDot + 1);
    this.FileExtension = ext;
  }

  fileChange1(event: any) {
    this.getFileNameWithExt(event);
    if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png") {
      const reader = new FileReader();
      this.checkProfilePicFileType = false;
      if (event.target.files && event.target.files.length) {
        if (event.target.files[0].size >= 2097152) {
          this.checkProfilePicFileSize = true;
          this.imageSrc1 = "assets/logo/img_avatar.png";
          this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
          this.MlProfileFile = new ImageUploadResult();
        }
        else {
          const [file1] = event.target.files;
          const file = event.target.files[0];
          this.FrmEntry.controls.personalDetails.controls.image.setValue(file);
          this.fileData(file, 'Profile')
          reader.readAsDataURL(file1);
          reader.onload = () => {
            this.imageSrc1 = reader.result as any;
            this.checkProfilePic = false;
            this.checkProfilePicFileSize = false;
          }
        }
      }
    }
    else {
      this.imageSrc1 = "assets/logo/img_avatar.png";
      this.checkProfilePicFileType = true;
      this.checkProfilePic = this.checkProfilePicFileSize = false;
      this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
      this.MlProfileFile = new ImageUploadResult();
    }

  }

  fileData(file: any, type: string) {
    this._srvCommon.postImageUpload(type, file).subscribe({
      next: val => {
        this.MlProfileFile = val.Data;
        this.checkProfilePicChange = true;
      },
      error: (err) => this.errorMsg(err.Message)
    })
  }

  countryChange(value: any) {
    this.selectedCountry = value;
    this.selectedState = this.selectedDistrict = undefined;
    this.FrmEntry.controls.address.controls['state'].setValue(null);
    this.FrmEntry.controls.address.controls['district'].setValue(null);

    if (value === undefined) {
      this.isDisabledState = true;
      this.LstState = [];
    }
    else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.LstState = e.Data;
          this.isDisabledState = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }

    this.isDisabledDistrict = true;
    // this.dataResultDistrict = [];
    this.LstDistrict = [];
  }

  stateChange(value: any) {
    this.selectedState = value;
    this.selectedDistrict = undefined;
    this.FrmEntry.controls.address.controls['district'].setValue(null);
    if (value === undefined) {
      this.isDisabledDistrict = true;
      this.LstDistrict = [];
    }
    else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.LstDistrict = e.Data;
          this.isDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  districtChange(value: any) {
    this.selectedDistrict = value;
  }

  shipCountry(value: any) {
    this.shipselectedCountry = value;
    this.shipselectedState = undefined;
    this.shipselectedDistrict = undefined;
    this.FrmEntry.controls.address.controls['permenantstate'].setValue(null);
    this.FrmEntry.controls.address.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledState = true;
      this.ShippingState = [];
    } else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.ShippingState = e.Data;
          this.shipDisabledState = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
    this.shipDisabledDistrict = true;
    this.ShippingDistrict = [];
  }

  shipState(value: any) {
    this.shipselectedState = value;
    this.shipselectedDistrict = undefined;
    this.FrmEntry.controls.address.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledDistrict = true;
      this.ShippingDistrict = [];
    } else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.ShippingDistrict = e.Data;
          this.shipDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
  }

  shipDistrict(value: any) {
    this.shipselectedDistrict = value;
  }


  public copyAddressChecked: boolean = false;
  public perDisable: boolean = false;
  copyAddress(event: any) {
    this.perDisable = this.copyAddressChecked = event.target.checked;

    if (event.target.checked) {
      this.currentGroup.controls['permenantaddress1'].setValue(this.currentGroup.controls['address1'].value)
      this.currentGroup.controls['permenantaddress2'].setValue(this.currentGroup.controls['address2'].value)
      this.currentGroup.controls['permenantarea'].setValue(this.currentGroup.controls['area'].value)
      this.currentGroup.controls['permenantcountry'].setValue(this.currentGroup.controls['country'].value)
      this.currentGroup.controls['permenantpincode'].setValue(this.currentGroup.controls['pincode'].value)
      this.FrmEntry.controls.address.controls.permenantTaluk.setValue(this.FrmEntry.controls.address.controls.Taluk.value);
      if (this.currentGroup.controls['country'].value) {
        this.shipDisabledState = false;
        this.shipDisabledDistrict = true;
        this.ShippingDistrict = [];
        this._srvCommon.getLstState(this.currentGroup.controls['permenantcountry'].value.CountryID).subscribe((e: any) => {
          this.ShippingState = e.Data;
        })
        if (this.currentGroup.controls['state'].value) {
          this.currentGroup.controls['permenantstate'].setValue(this.currentGroup.controls['state'].value);
          this.shipDisabledDistrict = false;
          this._srvCommon.getLstDistrict(this.currentGroup.controls['permenantstate'].value.StateProvinceID).subscribe((e: any) => {
            this.ShippingDistrict = e.Data
          })
          if (this.currentGroup.controls['district'].value) this.currentGroup.controls['permenantdistrict'].setValue(this.currentGroup.controls['district'].value);
          else this.currentGroup.controls['permenantdistrict'].setValue(null);
        }
        else {
          this.shipDisabledDistrict = true;
          this.ShippingDistrict = [];
          this.currentGroup.controls['permenantdistrict'].setValue(null);
          this.currentGroup.controls['permenantstate'].setValue(null);
        }
      }
      else {
        this.shipDisabledState = this.shipDisabledDistrict = true;
        this.ShippingState = this.ShippingDistrict = [];
        this.currentGroup.controls['permenantdistrict'].setValue(null);
        this.currentGroup.controls['permenantstate'].setValue(null);
      }
    }
    else {
      this.ShippingState = this.ShippingDistrict = [];
      this.FrmEntry.controls['address'].controls['permenantaddress1'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantaddress2'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantarea'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantcountry'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantstate'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantdistrict'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantpincode'].setValue(null);
      this.FrmEntry.controls.address.controls.permenantTaluk.setValue(null);
    }
  }

  prev() {
    this.currentStep = this.currentStep - 1;
  }

  next() {
    if (this.currentGroup.valid) {
      if (!this.checkProfilePicFileSize && !this.checkProfilePicFileType && !this.checkProfilePic)
        this.currentStep = this.currentStep + 1;
      return;
    }
    this.currentGroup.markAllAsTouched();
  }

  goBack() {
    this.IsOpenStudentEditDialog = false;
    // this.formSubmitted.emit("Cancle");
  }

  save() {
    this.MlStudentEdit = new StudentEditMl();
    if (this.currentGroup.valid) {
      const PersonalData = this.FrmEntry.controls.personalDetails.value;
      const AddressData = this.FrmEntry.controls.address.value;
      this.MlStudentEdit.AlternatePhoneCode = PersonalData.AlternatePhoneCode.PhoneCode;
      this.MlStudentEdit.AlternatePhone = PersonalData.altmobile;
      this.MlStudentEdit.ContactID = this.MlOneStudent.ContactID;
      this.MlStudentEdit.ContactName = PersonalData.name;
      this.MlStudentEdit.DateOfBirth = DateConversion.ConvertToMonthDateYear(PersonalData.dob);
      this.checkProfilePicChange ? this.MlStudentEdit.DocumentID = this.MlProfileFile.DocumentID : delete this.MlStudentEdit.DocumentID;

      this.MlStudentEdit.Email = PersonalData.email;
      this.MlStudentEdit.Gender = PersonalData.gender.GenderName;
      this.MlStudentEdit.GuardianName = PersonalData.guardianName;
      this.MlStudentEdit.GuardianType = PersonalData.guardian.MinValue;
      this.MlStudentEdit.Occupation = PersonalData.occupation;
      this.MlStudentEdit.Phone = PersonalData.mobile;
      this.MlStudentEdit.PhoneCode = PersonalData.PhoneCode.PhoneCode;
      // this.MlStudentEdit.Qualification = PersonalData.qualification.Qualification;
      this.MlStudentEdit.Qualification = PersonalData.qualification;
      this.MlStudentEdit.StudentID = this.StudentID;

      this.MlAddress = new Address();

      this.MlAddress.Address1 = AddressData.address1;
      this.MlAddress.Address2 = AddressData.address2;
      this.MlAddress.AddressTypeID = this.MlOneStudent.currentAddress.AddressTypeID;
      this.MlAddress.Area = AddressData.area;
      this.MlAddress.ContactID = this.MlOneStudent.currentAddress.ContactID;
      this.MlAddress.Country = AddressData.country.CountryName;
      this.MlAddress.District = AddressData.district.DistrictName;
      this.MlAddress.Pincode = AddressData.pincode;
      this.MlAddress.State = AddressData.state.StateProvinceName;
      this.MlAddress.Taluk = AddressData.Taluk;
      this.MlStudentEdit.Address.push(this.MlAddress);

      this.MlAddress = new Address();
      this.MlAddress.Address1 = AddressData.permenantaddress1;
      this.MlAddress.Address2 = AddressData.permenantaddress2;
      this.MlAddress.AddressTypeID = this.MlOneStudent.permentAddress.AddressTypeID;
      this.MlAddress.Area = AddressData.permenantarea;
      this.MlAddress.ContactID = this.MlOneStudent.permentAddress.ContactID;
      this.MlAddress.Country = AddressData.permenantcountry.CountryName;
      this.MlAddress.District = AddressData.permenantdistrict.DistrictName;
      this.MlAddress.Pincode = AddressData.permenantpincode;
      this.MlAddress.State = AddressData.permenantstate.StateProvinceName;
      this.MlAddress.Taluk = AddressData.permenantTaluk;
      this.MlStudentEdit.Address.push(this.MlAddress);

      this._srvStudent.postStudentEdit(this.MlStudentEdit).subscribe({
        next: (val) => {
          this._IsEditStudent = true;
          this.goBack();
          this.getStudentDetail(this.StudentId);
          setTimeout(() => this.getStudentCourseDetail(this._studentBatchMappingID), this._setTimer + 500);
          new CustomNotification(this._srvNotification).ShowSuccess(val.Message);
        },
        error: err => this.errorMsg(err.Message)
      })
    }
    this.currentGroup.markAllAsTouched();
  }
}
