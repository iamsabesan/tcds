import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CookieService } from 'ngx-cookie-service';
import { DateConversion, DropDownFilter, Gender, Gurdian, LocalString } from 'src/app/shared/app-global';
import { Country, CourseDetailMl, District, MultiDropdownColumn, PhoneCode, Purpose, Reason, State, StudentColumn, batchByIDDataType, CourseTypeListMl } from 'src/app/shared/model/common';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { CookieKey } from 'src/core/helper';
import { IWebError } from 'src/core/model';
import { StudentsService } from '../../service/student.service';
import { InputRegex } from 'src/app/shared/components/regex';
import { StudentData, CourseBasicInfoData, StudentPaymentData, PaymentDetail, StudentCreate } from '../../model/student';
import { LayoutComponent } from 'src/app/layouts/layout.component';
import { StudentService } from 'src/app/admin/Student/services/student.service';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { Occupation, Qualification, StudentAddressCreate } from 'src/app/shared/model/student-profile';
import { Router } from '@angular/router';
import { WalletFranchiseeService } from 'src/app/admin/Wallet/wallet-franchisee/services/wallet-franchisee.service';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent {

  /* List */
  public addressData: StudentAddressCreate[] = [];
  public LstCountry: Country[] = [];
  public LstState: State[] = [];
  public LstDistrict: District[] = [];
  public LstPhoneCode: PhoneCode[] = [];
  public LstOccupation: Occupation[] = [];
  public LstQualification: Qualification[] = [];
  public LstStudentBasicInfo: StudentData[] = [];
  public LstCourseData: CourseBasicInfoData[] = [];
  public Lstbatch: batchByIDDataType[] = [];
  public batch: batchByIDDataType[] = [];
  public PaymentDetails: PaymentInfo[] = [];
  public LstGender = Gender.LstGender;
  public LstGuardian = Gurdian.LstGurdian;
  public LstReason: Reason[] = [];
  public LstTCDSCentre: Purpose[] = [];
  public LstPurpose: Purpose[] = [];
  public LstCourseType: CourseTypeListMl[] = [];

  /* MultiColumn Combobox */
  public LstStudentColumn: MultiDropdownColumn[] = StudentColumn;

  /* Model */
  public MlAddress: StudentAddressCreate = new StudentAddressCreate();
  public MlCreateStudent: StudentCreate = new StudentCreate()
  public MlExistingStudent: StudentPaymentData = new StudentPaymentData();
  public MlPayment: PaymentDetail = new PaymentDetail();
  public MlCourse: CourseDetailMl = new CourseDetailMl();
  public MlBatch: batchByIDDataType = new batchByIDDataType();

  /* Pattern */
  public Name = InputRegex.Name;
  public Email = InputRegex.Email;
  public Mobile = InputRegex.Mobile;
  public Pincode = /^(6)?[1-9][0-9]{5}$/;

  /* Input decimal point not allow */
  public existing: boolean = false;
  public existingDisabled: boolean = false;

  /* Payment Details */
  public paymentamount: number = 0;
  public ErrorNotification: string = 'Please enter valid Amount';
  public ErrorNotify: string = 'Fees amount must be equal with total amount';
  public Totalamount: number = 0;
  public Balanceamount: number = 0;
  public isDownPaymentDisabled: boolean = true;
  public downPaymentMinAmount: number = 0;
  public downPaymentMaxAmount: number = 0;
  public disbledDepositFrom = false;
  public currencySymbol: string = '';

  /* Address Selection */
  public isDisabledState: boolean = true;
  public isDisabledDistrict = true;
  public selectedCountry: any;
  public selectedState: any;
  public selectedDistrict: any;
  public CountryID: string = '';
  public ShippingState!: Array<{
    StateProvinceID: number;
    StateProvinceName: string;
  }>;

  public ShippingDistrict!: Array<{
    DistrictID: number;
    DistrictName: string;
  }>;

  public shipDisabledState: boolean = true;
  public shipDisabledDistrict: boolean = true;
  public shipselectedCountry: any;
  public shipselectedState: any;
  public shipselectedDistrict: any;

  public courseData: boolean = false;
  public batchInfo: boolean = false;

  /* Existing Student is True Disabled the Step 1 */
  public IsStep1: boolean = true;

  /* Date & Time Format */
  public timeFormat: string = '';
  public time: string = '';
  public dateFormat: string = '';

  /* Get Image File Extension */
  public FileExtension: string = "";

  public imageSrc1?: any;
  public studentID: string = '';
  public currentStep: number = 0;

  public guardians: string = 'Father';

  /* Telerik Report Viewer */
  public getScreenHeight: any;
  public getScreenWidth: any;
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public open: boolean = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";

  public originalAmount = 0;
  public discountPercentage: any = null;
  public DiscountPercent: number = 0;

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;
  public StartWithFilterSettings = DropDownFilter.StartWithfilterSettings;

  FrmEntry = new FormGroup({
    personalDetails: this.fb.group({
      type: new FormControl("New", [Validators.required]),
      record: new FormControl(),
      name: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      gender: new FormControl(null, [Validators.required]),
      dob: new FormControl(null, [Validators.required]),
      PhoneCode: new FormControl(null, [Validators.required]),
      mobile: new FormControl(null, [Validators.required]),
      AlternatePhoneCode: new FormControl(),
      altmobile: new FormControl(),
      email: new FormControl(null),
      qualification: new FormControl(null, [Validators.required]),
      guardian: new FormControl(null, [Validators.required]),
      guardianName: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      occupation: new FormControl(null, [Validators.required]),
      reason: new FormControl(null),
      centre: new FormControl(null),
      purpose: new FormControl(null),
      image: new FormControl(File, [Validators.required]),
    }),
    address: this.fb.group({
      address1: new FormControl(null, [Validators.required]),
      address2: new FormControl(),
      area: new FormControl(null, [Validators.required]),
      country: new FormControl(null, [Validators.required]),
      state: new FormControl(null, [Validators.required]),
      district: new FormControl(null, [Validators.required]),
      pincode: new FormControl(null, [Validators.required]),
      permenantaddress1: new FormControl(null, [Validators.required]),
      permenantaddress2: new FormControl(),
      permenantarea: new FormControl(null, [Validators.required]),
      permenantcountry: new FormControl(null, [Validators.required]),
      permenantstate: new FormControl(null, [Validators.required]),
      permenantdistrict: new FormControl(null, [Validators.required]),
      permenantpincode: new FormControl(null, [Validators.required]),
      Taluk: new FormControl(null, [Validators.required]),
      permenantTaluk: new FormControl(null, [Validators.required]),
    }),
    courseDetails: this.fb.group({
      courseType: new FormControl(null, [Validators.required]),
      courseName: new FormControl(null, [Validators.required]),
      batch: new FormControl(null, [Validators.required]),
      discount: new FormControl(0, [Validators.min(0)]),
      discountPercent: new FormControl(null, [Validators.min(0), Validators.max(100)]),
      downPayment: new FormControl(null, [Validators.required])
    })
  });

  constructor(public fb: FormBuilder, public _srvCookie: CookieService,
    public layout: LayoutComponent, private _srvCommon: CommonService,
    private _srvStudent: StudentsService, private _srvNotification: NotificationService,
    public _srvStd: StudentService, private _routes: Router,
    private _srvWalletFranchisee: WalletFranchiseeService,
    public currencyService: IntlService
  ) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.imageSrc1 = "assets/logo/img_avatar.png";
    this.loadData();
    this.news();
  }

  walletBalanace: number = 0;
  /* Default Load Data */
  loadData() {

    const fromDate = DateConversion.ConvertMonthDateYear(new Date());
    const toDate = DateConversion.ConvertMonthDateYear(new Date());

    this._srvWalletFranchisee.getFranchiseewalletHistory(fromDate, toDate).subscribe((res) => {
      this.walletBalanace = res.Data.WalletBalance.WalletBalance ?? 0;
    })

    /* Phone Code */
    this._srvCommon.getPhoneCode().subscribe({
      next: (e) => {
        this.LstPhoneCode = e.Data;
        const IndianPhoneCode = this.LstPhoneCode.find((e) => e.PhoneCode == '+91')?.PhoneCode;
        this.FrmEntry.controls['personalDetails'].controls['PhoneCode'].setValue({ PhoneCode: IndianPhoneCode });
        this.FrmEntry.controls['personalDetails'].controls['AlternatePhoneCode'].setValue({ PhoneCode: IndianPhoneCode });
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Get Occupation */
    this._srvCommon.getOccupationData().subscribe({
      next: (e: any) => this.LstOccupation = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Get Student Data */
    this._srvCommon.getStudentBasicDetail().subscribe({
      next: (e: any) => this.LstStudentBasicInfo = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Get Qualification */
    this._srvCommon.getStudentQualification().subscribe({
      next: (e: any) => this.LstQualification = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Get CourseBasic Data */
    // this._srvCommon.getCourseBasicData().subscribe({
    //   next: (e: any) => this.LstCourseData = e.Data,
    //   error: (err: IWebError) => this.errorMsg(err.Message)
    // });

    /* Get Country */
    this._srvCommon.getLstCountry().subscribe({
      next: (e: any) => this.LstCountry = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });


    /* Get Reason */
    this._srvCommon.getReason().subscribe({
      next: (e: any) => this.LstReason = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });


    /* Get TCDS Centre */
    this._srvCommon.getTCDSCentre().subscribe({
      next: (e: any) => this.LstTCDSCentre = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Get Purpose */
    this._srvCommon.getPurpose().subscribe({
      next: (e: any) => this.LstPurpose = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

  }

  /* Change Gurdian Type */
  guard(event: any) {
    this.guardians = event;
  }

  /*  Filter the batch */
  batchFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.BatchNumber.toLowerCase().includes(normalizedQuery) ||
      data.Timing.toLowerCase().includes(normalizedQuery) ||
      data.FacultyID.toLowerCase().includes(normalizedQuery) ||
      data.BatchType.toLowerCase().includes(normalizedQuery);
    this.Lstbatch = this.batch.filter(filterExpression);
  }

  /* Existing Student Filter */
  studentFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.RollNumber.toLowerCase().includes(normalizedQuery) ||
      data.StudentName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery) ||
      data.Course.toLowerCase().includes(normalizedQuery);

    this.LstStudentBasicInfo = this.LstStudentBasicInfo.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.ShortName.toLowerCase().includes(normalizedQuery) ||
      data.CourseName.toLowerCase().includes(normalizedQuery) ||
      data.CourseType.toLowerCase().includes(normalizedQuery);

    this.LstCourseData = this.LstCourseData.filter(filterExpression);
  }

  countryChange(value: any) {
    this.selectedCountry = value;
    this.selectedState = this.selectedDistrict = undefined;
    this.currentGroup.controls['state'].setValue(null);
    this.currentGroup.controls['district'].setValue(null);

    if (value === undefined) {
      this.isDisabledState = true;
      this.LstState = [];
    }
    else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.LstState = e.Data;
          this.isDisabledState = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }

    this.isDisabledDistrict = true;
    // this.dataResultDistrict = [];
    this.LstDistrict = [];
  }

  stateChange(value: any) {
    this.selectedState = value;
    this.selectedDistrict = undefined;
    this.currentGroup.controls['district'].setValue(null);
    if (value === undefined) {
      this.isDisabledDistrict = true;
      this.LstDistrict = [];
    }
    else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.LstDistrict = e.Data;
          this.isDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  districtChange(value: any) {
    this.selectedDistrict = value;
  }

  shipCountry(value: any) {
    this.shipselectedCountry = value;
    this.shipselectedState = undefined;
    this.shipselectedDistrict = undefined;
    this.currentGroup.controls['permenantstate'].setValue(null);
    this.currentGroup.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledState = true;
      this.ShippingState = [];
    } else {
      this._srvCommon.getLstState(value.CountryID).subscribe({
        next: (e) => {
          this.ShippingState = e.Data;
          this.shipDisabledState = false;

        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
    this.shipDisabledDistrict = true;
    this.ShippingDistrict = [];
  }

  shipState(value: any) {
    this.shipselectedState = value;
    this.shipselectedDistrict = undefined;
    this.currentGroup.controls['permenantdistrict'].setValue(null);
    if (value === undefined) {
      this.shipDisabledDistrict = true;
      this.ShippingDistrict = [];
    } else {
      this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
        next: (e) => {
          this.ShippingDistrict = e.Data;
          this.shipDisabledDistrict = false;
        },
        error: (err) => this.errorMsg(err.Message)
      })
    }
  }

  shipDistrict(value: any) {
    this.shipselectedDistrict = value;
  }


  /* Remanining Balance */
  total(total: number): void {
    this.Totalamount = total;
  }

  news() {
    this.step[1].disabled = this.existing = false;
    this.IsStep1 = true;

    this.FrmEntry.controls['personalDetails'].controls['record'].clearValidators();
    this.FrmEntry.controls['personalDetails'].controls['record'].updateValueAndValidity();

    this.currentGroup.controls['name'].setValidators([Validators.required])
    this.currentGroup.controls['name'].updateValueAndValidity();

    this.currentGroup.controls['gender'].setValidators([Validators.required])
    this.currentGroup.controls['gender'].updateValueAndValidity();

    this.currentGroup.controls['dob'].setValidators([Validators.required])
    this.currentGroup.controls['dob'].updateValueAndValidity();

    this.currentGroup.controls['mobile'].setValidators([Validators.required, Validators.pattern(this.Mobile)])
    this.currentGroup.controls['mobile'].updateValueAndValidity();

    // this.currentGroup.controls['email'].setValidators([Validators.required, Validators.pattern(this.Email)])
    // this.currentGroup.controls['email'].updateValueAndValidity();

    this.currentGroup.controls['qualification'].setValidators([Validators.required])
    this.currentGroup.controls['qualification'].updateValueAndValidity();

    this.currentGroup.controls['guardianName'].setValidators([Validators.required])
    this.currentGroup.controls['guardianName'].updateValueAndValidity();

    this.currentGroup.controls['occupation'].setValidators([Validators.required])
    this.currentGroup.controls['occupation'].updateValueAndValidity();

    this.currentGroup.controls['image'].setValidators([Validators.required])
    this.currentGroup.controls['image'].updateValueAndValidity();
  }

  exis() {
    this.step[1].disabled = this.existing = true;
    this.IsStep1 = false;

    this.currentGroup.controls['record'].setValidators([Validators.required]);
    this.currentGroup.controls['record'].updateValueAndValidity();

    this.currentGroup.controls['name'].clearValidators();
    this.currentGroup.controls['name'].updateValueAndValidity();

    this.currentGroup.controls['gender'].clearValidators();
    this.currentGroup.controls['gender'].updateValueAndValidity();

    this.currentGroup.controls['dob'].clearValidators();
    this.currentGroup.controls['dob'].updateValueAndValidity();

    this.currentGroup.controls['mobile'].clearValidators();
    this.currentGroup.controls['mobile'].updateValueAndValidity();

    this.currentGroup.controls['email'].clearValidators();
    this.currentGroup.controls['email'].updateValueAndValidity();

    this.currentGroup.controls['qualification'].clearValidators();
    this.currentGroup.controls['qualification'].updateValueAndValidity();

    this.currentGroup.controls['guardianName'].clearValidators();
    this.currentGroup.controls['guardianName'].updateValueAndValidity();

    this.currentGroup.controls['occupation'].clearValidators();
    this.currentGroup.controls['occupation'].updateValueAndValidity();

    this.currentGroup.controls['image'].clearValidators();
    this.currentGroup.controls['image'].updateValueAndValidity();
  }

  public copyAddressChecked: boolean = false;
  public perDisable: boolean = false;
  copyAddress(event: any) {
    this.perDisable = this.copyAddressChecked = event.target.checked;

    if (event.target.checked) {
      this.currentGroup.controls['permenantaddress1'].setValue(this.currentGroup.controls['address1'].value)
      this.currentGroup.controls['permenantaddress2'].setValue(this.currentGroup.controls['address2'].value)
      this.currentGroup.controls['permenantarea'].setValue(this.currentGroup.controls['area'].value)
      this.currentGroup.controls['permenantcountry'].setValue(this.currentGroup.controls['country'].value)
      this.currentGroup.controls['permenantpincode'].setValue(this.currentGroup.controls['pincode'].value)
      this.FrmEntry.controls.address.controls.permenantTaluk.setValue(this.FrmEntry.controls.address.controls.Taluk.value)

      if (this.currentGroup.controls['country'].value) {
        this.shipDisabledState = false;
        this.shipDisabledDistrict = true;
        this.ShippingDistrict = [];
        this._srvCommon.getLstState(this.currentGroup.controls['permenantcountry'].value.CountryID).subscribe((e: any) => {
          this.ShippingState = e.Data;
        })
        if (this.currentGroup.controls['state'].value) {
          this.currentGroup.controls['permenantstate'].setValue(this.currentGroup.controls['state'].value);
          this.shipDisabledDistrict = false;
          this._srvCommon.getLstDistrict(this.currentGroup.controls['permenantstate'].value.StateProvinceID).subscribe((e: any) => {
            this.ShippingDistrict = e.Data
          })
          if (this.currentGroup.controls['district'].value) this.currentGroup.controls['permenantdistrict'].setValue(this.currentGroup.controls['district'].value);
          else this.currentGroup.controls['permenantdistrict'].setValue(null);
        }
        else {
          this.shipDisabledDistrict = true;
          this.ShippingDistrict = [];
          this.currentGroup.controls['permenantdistrict'].setValue(null);
          this.currentGroup.controls['permenantstate'].setValue(null);
        }
      }
      else {
        this.shipDisabledState = this.shipDisabledDistrict = true;
        this.ShippingState = this.ShippingDistrict = [];
        this.currentGroup.controls['permenantdistrict'].setValue(null);
        this.currentGroup.controls['permenantstate'].setValue(null);
      }
    }
    else {
      this.ShippingState = this.ShippingDistrict = [];
      this.FrmEntry.controls['address'].controls['permenantaddress1'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantaddress2'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantarea'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantcountry'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantstate'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantdistrict'].setValue(null);
      this.FrmEntry.controls['address'].controls['permenantpincode'].setValue(null);
      this.FrmEntry.controls.address.controls.permenantTaluk.setValue(null)
    }
  }

  onCourseTypeChange(event: CourseTypeListMl | null): void {
    this.LstCourseData = [];
    this.Lstbatch = [];

    this.FrmEntry.controls.courseDetails.controls.courseName.setValue(null);
    this.FrmEntry.controls.courseDetails.controls['batch'].setValue(null);
    this.FrmEntry.controls.courseDetails.controls['discount'].setValue(null);
    this.FrmEntry.controls.courseDetails.controls['discountPercent'].setValue(null);

    this.batchInfo = false;
    this.courseData = false;

    if (event && event.CourseTypeID) {
      this._srvCommon.getCourseListInCourseType(event.CourseTypeID).subscribe({
        next: val => {
          this.LstCourseData = val.Data || [];
        }
      });
    }
  }

  /* Change the Course */
  selectCourse(event: CourseDetailMl) {
    this.FrmEntry.controls.courseDetails.controls.discount.setValue(0);
    this.FrmEntry.controls.courseDetails.controls.discountPercent.setValue('0 %')

    this.currentGroup.controls['batch'].setValue(null);
    this.Lstbatch = [];
    this.batchInfo = false;
    this.originalAmount = 0;
    if (event === undefined) {
      this.courseData = false;
      this.isDownPaymentDisabled = true;
    }
    else {
      this.courseData = true;
      this.MlCourse = event;
      this.MlCourse.DiscountAmount = 0;
      this.downPaymentMaxAmount = this.MlCourse.NetAmount = event.CourseFees;
      this.paymentamount = this.downPaymentMinAmount = event.AdmissionFees;
      this.isDownPaymentDisabled = false;
      // this.originalAmount = this.MlCourse.NetAmount - this.MlCourse.AdmissionFees;
      this.originalAmount = this.MlCourse.NetAmount;
      this.FrmEntry.controls.courseDetails.controls.discount.setValidators([Validators.max(this.originalAmount)])
      this.FrmEntry.controls.courseDetails.controls.discount.updateValueAndValidity();

      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValue(this.downPaymentMinAmount);
      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(this.downPaymentMinAmount), Validators.max(this.downPaymentMaxAmount)])
      this._srvCommon.getActiveBatchCourseID(event.CourseID).subscribe({
        next: (e) => this.Lstbatch = this.batch = e.Data,
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Change the Batch */
  selectBatch(event: batchByIDDataType) {


    if (event == undefined) this.batchInfo = false;
    else {
      this.batchInfo = true;
      this._srvCommon.getCourseBatchIDList(event.CourseBatchID).subscribe({
        next: (e) => this.MlBatch = this.batch = e.Data,
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }



  /* Down Payment */
  downPayment(event: number) {
    this.paymentamount = event;
  }

  private isStepValid = (index: number) => {
    return this.getGroupAt(index).valid || this.currentGroup.untouched;
  };

  private shouldValidate = (index: number) => {
    return this.getGroupAt(index).touched && this.currentStep >= index;
  };

  public stepActivate(e: StepperActivateEvent) {
    if (!this.currentGroup.valid) {
      e.preventDefault();
      this.currentGroup.markAllAsTouched();
    }
  }

  step = [
    {
      label: 'Personal Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
    {
      label: 'Address',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    },
    {
      label: 'Course Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
      disabled: false
    }
  ];

  /* Get File Extension */
  getFileNameWithExt(event: any) {
    if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf(".");
    const ext = name.substring(lastDot + 1);
    this.FileExtension = ext;
  }

  public IsValidProfile: boolean = false;
  public StudentProfile: any[] = [];
  fileChange1(event: any) {
    this.getFileNameWithExt(event);
    if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png") {
      const reader = new FileReader();
      if (event.target.files && event.target.files.length) {
        if (event.target.files[0].size >= 2097152) this.errorMsg("Profile picture size is larger than 2 MB");
        else {
          const [file1] = event.target.files;
          const file = event.target.files[0];
          this.MlCreateStudent.studentImage = file;

          this.IsValidProfile = false;
          reader.readAsDataURL(file1);
          reader.onload = () => {
            this.imageSrc1 = reader.result as any;
          }
        }
      }
    }
    else {
      this.imageSrc1 = 'assets/logo/img_avatar.png';
      this.MlCreateStudent.studentImage = [];
      this.StudentProfile = [];
      this.IsValidProfile = true;
      this.errorMsg("Please upload valid profile image");
    }
  }

  prev() {
    if (this.step[this.currentStep - 1].disabled === true) this.currentStep = this.currentStep - 2;
    else this.currentStep = this.currentStep - 1;
  }

  ImageNext(data: any) {
    if (this.currentGroup.valid && this.currentStep < this.step.length && (this.step[this.currentStep + 1].disabled === false)) {
      if (data.personalDetails.type === 'New') {
        if (this.MlCreateStudent.studentImage.length == 0) {
          this.errorMsg("Please upload profile image");
          this.IsValidProfile = true;
        }
        else {
          this.currentStep = this.currentStep + 1;
          this.IsValidProfile = false;
        }
      }
      return;
    }
    else if (this.currentGroup.valid && this.currentStep < this.step.length && (this.step[this.currentStep + 1].disabled === true)) {
      this.currentStep = this.currentStep + 2;
      return;
    }
    this.currentGroup.markAllAsTouched();
  }

  next() {
    if (this.currentGroup.valid && this.currentStep < this.step.length && (this.step[this.currentStep + 1].disabled === false)) {
      this.currentStep = this.currentStep + 1;
      return;
    }
    else if (this.currentGroup.valid && this.currentStep < this.step.length && (this.step[this.currentStep + 1].disabled === true)) {
      this.currentStep = this.currentStep + 2;
      return;
    }
    this.currentGroup.markAllAsTouched();
  }

  goBack() {

    if (!this._srvStd.checkStudentCreate) {
      this._routes.navigate(['/iCloud/student/enquiry/request']);
      this._srvStd.checkStudentCreate = true;
    } else {
      this._srvStudent.Modes.next({ Mode: 'LIST' });
      this._srvStd.checkGoBack = true;
    }

  }

  /* FormGroup Value Binding the Model */
  formToModelBinding(data: any) {

    if (data.personalDetails.type == "New") {
      // this.MlCreateStudent = new StudentCreate();
      this.MlCreateStudent.studentName = data.personalDetails.name;
      this.MlCreateStudent.gender = data.personalDetails.gender;
      this.MlCreateStudent.dateOfBirth = DateConversion.ConvertToYearMonthDate(data.personalDetails.dob);
      this.MlCreateStudent.phoneCode = data.personalDetails.PhoneCode.PhoneCode
      this.MlCreateStudent.phone = data.personalDetails.mobile;
      this.MlCreateStudent.alternatePhoneCode = data.personalDetails.AlternatePhoneCode.PhoneCode;
      this.MlCreateStudent.alternatePhone = data.personalDetails.altmobile == null ? "" : data.personalDetails.altmobile;
      this.MlCreateStudent.email = data.personalDetails.email;
      // this.MlCreateStudent.qualification = data.personalDetails.qualification.Qualification;
      this.MlCreateStudent.qualification = data.personalDetails.qualification;
      this.MlCreateStudent.guardianType = data.personalDetails.guardian;
      this.MlCreateStudent.fatherName = data.personalDetails.guardianName;
      this.MlCreateStudent.occupation = data.personalDetails.occupation;
      this.MlCreateStudent.ReasonToSelect = data.personalDetails.reason?.Reason ?? "";
      this.MlCreateStudent.ReferBy = data.personalDetails.centre?.Value ?? "";
      this.MlCreateStudent.Purpose = data.personalDetails.purpose?.Value ?? "";
      // this.MlCreateStudent.studentImage = this.StudentProfile;

      this.MlCreateStudent.address = this.addressData = [];
      this.MlAddress.AddressType = "Communication Address"
      this.MlAddress.Address1 = data.address.address1;
      this.MlAddress.Address2 = data.address.address2 == null ? "" : data.address.address2;
      this.MlAddress.Country = data.address.country.CountryName;
      this.MlAddress.State = data.address.state.StateProvinceName;
      this.MlAddress.District = data.address.district.DistrictName;
      this.MlAddress.Area = data.address.area;
      this.MlAddress.Pincode = data.address.pincode;
      this.MlAddress.Taluk = data.address.Taluk;
      this.addressData.push(this.MlAddress);

      this.MlAddress = new StudentAddressCreate();
      this.MlAddress.AddressType = "Permanent Address"
      this.MlAddress.Address1 = data.address.permenantaddress1;
      this.MlAddress.Address2 = data.address.permenantaddress2 == null ? "" : data.address.permenantaddress2;
      this.MlAddress.Country = data.address.permenantcountry.CountryName;
      this.MlAddress.State = data.address.permenantstate.StateProvinceName;
      this.MlAddress.District = data.address.permenantdistrict.DistrictName
      this.MlAddress.Area = data.address.permenantarea;
      this.MlAddress.Pincode = data.address.permenantpincode;
      this.MlAddress.Taluk = data.address.permenantTaluk;
      this.addressData.push(this.MlAddress);
      this.MlCreateStudent.address = this.addressData;
    }

    this.MlExistingStudent.paymentItems = [];

    this.PaymentDetails.filter((e: any) => {
      this.MlPayment = new PaymentDetail();
      this.MlPayment.PaymentModeID = e.PaymentModeID;
      this.MlPayment.PayModeType = e.PayModeType;
      this.MlPayment.PayModeValue = e.PayModeValue;
      this.MlPayment.Amount = e.Amount;
      this.MlPayment.LedgerID = e.FromLedger.LedgerID;
      this.MlPayment.LedgerName = e.FromLedger.LedgerName;
      this.MlPayment.TransactionNo = e.TransactionNo;
      this.MlPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
      this.MlPayment.RoundOff = 0;
      this.MlPayment.BankCommission = 0;
      e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID : delete this.MlPayment.DocumentID;

      this.MlExistingStudent.paymentItems.push(this.MlPayment);
    });

    this.MlExistingStudent.studentID = data.personalDetails.type == "New" ? this.studentID : data.personalDetails.record.StudentID;
    this.MlExistingStudent.courseBatchID = data.courseDetails.batch.CourseBatchID;
    // this.MlExistingStudent.discount = data.courseDetails.discountPercent ?? 0;
    // this.MlExistingStudent.discount = this.DiscountPercent;
    this.MlExistingStudent.discount = (this.MlCourse.DiscountAmount / this.MlCourse.CourseFees) * 100;
    this.MlExistingStudent.downPayment = data.courseDetails.downPayment;

  }

  save(data: any) {
    if (!this.currentGroup.valid) this.currentGroup.markAllAsTouched();
    else if (this.Totalamount == 0) this.errorMsg("Please Add Payment");
    else if (this.paymentamount !== this.Totalamount) this.errorMsg("Please enter full payment");

    else if (data.personalDetails.type === 'Existing') {
      this.formToModelBinding(data);
      this.MlExistingStudent.studentType = 'Existing';

      this._srvStudent.updateStudentDownPayment(this.MlExistingStudent).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.title = 'Fees Receipt'
          this.ServerUrl = this.layout.ServerUrl;
          this.bearerToken = this._srvCookie.get(CookieKey.Api);
          this.Reportsource = {
            report: 'iCloud/FeesReceipt(PartPayment)',
          };
          this.open = true;
          this.goBack();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      })
    }

    else if (data.personalDetails.type === 'New') {
      this.formToModelBinding(data);

      this._srvStudent.createStudent(this.MlCreateStudent).subscribe({
        next: (res: any) => {
          this.studentID = res.Data.StudentID;
          this.MlExistingStudent.studentID = this.studentID;
          this.MlExistingStudent.studentType = 'New';
          this._srvStudent.updateStudentDownPayment(this.MlExistingStudent).subscribe({
            next: (res: any) => {
              new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
              this.goBack();
            },
            error: (err: IWebError) => this.errorMsg(err.Message)
          });
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  public get currentGroup(): FormGroup {
    return this.getGroupAt(this.currentStep);
  }

  public getGroupAt(index: number): FormGroup {
    var groups = Object.keys(this.FrmEntry.controls).map((groupName) =>
      this.FrmEntry.get(groupName)) as FormGroup[];
    return groups[index];
  }

  /* Close Telerik Report */
  close(): void {
    this.open = false;
  }

  /* Discount the Course Fees */
  discountchange(event: number) {
    // this.MlCourse.DiscountAmount = this.MlCourse.CourseFees * event / 100;
    this.DiscountPercent = 0;
    var discountAmount: number = event

    if (discountAmount > this.originalAmount) discountAmount = this.originalAmount;

    this.MlCourse.DiscountAmount = discountAmount;
    this.downPaymentMaxAmount = this.MlCourse.NetAmount = this.MlCourse.CourseFees - this.MlCourse.DiscountAmount;
    this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(this.downPaymentMinAmount), Validators.max(this.MlCourse.NetAmount)])

    this.FrmEntry.controls.courseDetails.controls.discount.setValue(discountAmount);

    if (discountAmount >= 0 && this.originalAmount > 0) {
      this.DiscountPercent = +((discountAmount / this.MlCourse.CourseFees) * 100).toFixed(2);
      this.discountPercentage = ((discountAmount / this.MlCourse.CourseFees) * 100).toFixed(2) + '%';

    } else {
      this.discountPercentage = '0 %';
      this.DiscountPercent = 0;
    }
    this.FrmEntry.controls.courseDetails.controls.discountPercent.setValue(this.discountPercentage);
    if (discountAmount > (this.MlCourse.CourseFees - this.MlCourse.AdmissionFees)) {
      this.FrmEntry.controls.courseDetails.controls.downPayment.setValue(this.MlCourse.CourseFees - discountAmount);
      this.FrmEntry.controls['courseDetails'].controls['downPayment'].setValidators([Validators.required, Validators.min(0), Validators.max(this.MlCourse.NetAmount)])
      this.paymentamount = this.MlCourse.CourseFees - discountAmount;
    } else {
      this.FrmEntry.controls.courseDetails.controls.downPayment.setValue(this.MlCourse.AdmissionFees);
      this.paymentamount = this.MlCourse.AdmissionFees;
    }
  }



  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
