import { Component, HostListener, ViewChild } from '@angular/core';
import { batchByIDDataType, CourseTypeListMl, StudentFilterDataMl } from 'src/app/shared/model/common';
import { CourseBasicInfo, MlCurrectStdList, StudentList, studentListfilterData } from '../../model/student';
// import { studentListDataType } from 'src/app/admin/Student/models/Alumnus';
import { studentListFilter } from 'src/app/admin/Batch/models/batch';
import { directStudentViewDataType, StudentDiscontinueMl } from 'src/app/admin/Student/models/student-profile';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, DropDownFilter, LocalString, getUrl, gridFontStyle } from 'src/app/shared/app-global';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { Router } from '@angular/router';
import { StudentsService } from '../../service/student.service';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IWebError } from 'src/core/model';
import { FormBuilder, NgForm } from '@angular/forms';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
import { CommonService } from 'src/app/shared/service/common.service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { AppService } from 'src/core/service';
import { StudentService } from 'src/app/admin/Student/services/student.service';
import { CourseInfoListByFranchisee } from 'src/app/admin/Indent/models/exam-indent';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent {

  /* View Child */
  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;
  @ViewChild("form") public form?: NgForm; // daterange component value assign the form 

  /* List */
  public LstBatch: batchByIDDataType[] = [];
  public LstStoreBatch: batchByIDDataType[] = [];
  public LstStoreCourse: CourseBasicInfo[] = [];
  public LstCourse: CourseBasicInfo[] = [];
  public LstCurrentStudent: StudentList[] = [];
  public LstCurrentStudentData: StudentList[] = [];
  public edit: string[] = ['Edit', 'View', 'Discontinue'];
  public LstStatusDropDown: string[] = ['All', 'Studying', 'Discontinued']
  public LstCourseType: CourseTypeListMl[] = [];
  public LstCourseInfo: CourseInfoListByFranchisee[] = [];

  /* Model */
  public StudentFilterData: studentListfilterData = new studentListfilterData();
  public datefilter: studentListFilter = new studentListFilter();
  public studentBasicData: directStudentViewDataType = new directStudentViewDataType();
  public endDates: Date = new Date();
  public MlDateRange: DateRanges = new DateRanges();
  public FilterData: StudentFilterDataMl = new StudentFilterDataMl();
  public MlDiscontinueStudent: StudentDiscontinueMl = new StudentDiscontinueMl();
  public MlCurrentStudent: StudentList = new StudentList();

  public todayDate: Date = new Date();
  public filter!: CompositeFilterDescriptor;

  /* Date & Time Format */
  public dateWholePeriod!: boolean;
  public gridStyle = new gridFontStyle();
  public dateStyle = new DateSize('medium');

  public course = "";
  public batchId: string = "";
  public batchDisabled = true;

  public startDate: Date = new Date();
  public endDate: Date = new Date();
  public Course: string = '';
  public Batch: string = '';
  public CourseType: string = '';

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Grid Pagination */
  public buttonCount = 5;
  skip = 0;
  pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";
  WholePerStrDate: Date;

  public dialogDetailsWidth = 450;
  public ShowDiscontinueDialog = false;

  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    window.innerWidth > 1550 || window.innerWidth < 1100 ? this.dialogDetailsWidth = 480 : this.dialogDetailsWidth = 450;
  }


  public notesMaxlength = 150;
  public notesCounter: string = '0/150';

  DiscontinueFrmEntry = this.fb.group({
    reason: ['']
  })

  Status = 'All'


  constructor(
    private _srvStudent: StudentsService,
    private _srvCommon: CommonService,
    private _srvNotification: NotificationService,
    private routes: Router,
    public _srvValueShare: ValueShareService,
    public _srvApp: AppService,
    public _srvStd: StudentService,
    public fb: FormBuilder,
  ) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);

      }
    })
  }

  ngOnInit(): void {
    this.dateWholePeriod = true;

    this._srvCommon.getCourseTypeList().subscribe({
      next: val => {
        this.LstCourseType = val.Data;
      }
    })

    this.getCourseBasicInfo();


    var date: any = DateConversion.ConvertMonthDateYear(new Date());
    var todate: any = DateConversion.ConvertMonthDateYear(new Date());
    if (this._srvStd.checkGoBack) {
      date = this._srvStd.MllstFliterData.date.startDate;
      todate = this._srvStd.MllstFliterData.date.endDate;
      if (this._srvStd.MllstFliterData.courseType) {
        this.CourseType = this._srvStd.MllstFliterData.courseType.CourseTypeID;
        this.StudentFilterData.courseType = this._srvStd.MllstFliterData.courseType;
        this.getCourseList(this.CourseType);
        if (this._srvStd.MllstFliterData.course) {
          this.course = this._srvStd.MllstFliterData.course.CourseID;
          this.StudentFilterData.course = this._srvStd.MllstFliterData.course;

          if (this._srvStd.MllstFliterData.batch) this.batchId = this._srvStd.MllstFliterData.batch.CourseBatchID;
          if (this.StudentFilterData.course) this.getBatch(this.course);
        }
      }

      this.pageSize = this._srvStd.listPageSize;
      this.skip = this._srvStd.listPageSkip;
    } else {
      this._srvStd.MllstFliterData = new MlCurrectStdList();
    }
    this.getCurrentStudentList(date, todate, this.course, this.batchId, this.CourseType);
  }

  ngAfterViewInit() {
    if (this._srvStd.checkGoBack) {
      setTimeout(() => {

        this.MlDateRange = this._srvStd.MllstFliterData.date;

        if (this.MlDateRange.duration && this.dateRanges.dateData) {
          if (this.MlDateRange.duration != "Custom") {
            this.dateRanges.dateData.forEach(e => {
              if (e.value == this.MlDateRange.duration) {
                this.dateRanges.selectedValue = e;
                this.dateRanges.getDate(e);
              }
            })
          } else {
            const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
            this.dateRanges.selectedValue = customRange;
            this.dateRanges.IsdisabledDate = false;
            this.AssignDate(this.MlDateRange);
          }
        } else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
          if (this.MlDateRange.duration != "") {
            this.dateRanges.IsdisabledDate = false;
            // const customRange = this.dateRanges.dateData.find(obj => obj.value === "Today");
            this.dateRanges.selectedValue = undefined;
            // this.dateRanges.getDate(this.dateRanges.selectedValue);
          }
          this.AssignDate(this.MlDateRange)
        } else {
          this.AssignDate(this.MlDateRange)
          this.dateRanges.IsdisabledDate = false;
          this.dateRanges.selectedValue = undefined;
        }

      });
      this._srvStd.checkGoBack = false;
    }


  }

  /* Date Assign */
  AssignDate(MlDateRange: DateRanges) {
    this.dateRanges.dateRange.startDate = MlDateRange.startDate;
    this.dateRanges.dateRange.endDate = MlDateRange.endDate;

  }

  /* Get Course */
  getCourseBasicInfo() {
    this._srvCommon.getCourseBasicData().subscribe({
      next: (e) => this.LstStoreCourse = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  onCourseTypeChange(event: CourseTypeListMl | null): void {

    this.LstCourseInfo = [];
    this.LstBatch = [];
    this.StudentFilterData.batch = this.StudentFilterData.course = null;

    if (event && event.CourseTypeID) {
      this.getCourseList(event.CourseTypeID);
    }
  }

  getCourseList(Id: string) {
    this._srvCommon.getCourseListInCourseType(Id).subscribe({
      next: val => {
        this.LstCourseInfo = val.Data || [];
      }
    });
  }

  /* Choose the Course */
  CourseFun(event: any) {
    this.StudentFilterData.batch = undefined;
    this.LstBatch = this.LstStoreBatch = [];
    if (event) this.getBatch(event.CourseID);
  }
  /* Get Batch List With Using the CourseID */
  getBatch(courseID: string) {
    this._srvCommon.getActiveBatchCourseID(courseID).subscribe({
      next: (e) => {
        this.batchDisabled = false;
        this.LstBatch = this.LstStoreBatch = e.Data;
        this.StudentFilterData.batch = this.LstBatch.find(e => e.CourseBatchID == this.batchId);
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Batch Filter */
  batchFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.CourseBatchID.toLowerCase().includes(normalizedQuery) ||
      data.BatchNumber.toLowerCase().includes(normalizedQuery) ||
      data.CourseName.toLowerCase().includes(normalizedQuery) ||
      data.FacultyID.toLowerCase().includes(normalizedQuery) ||
      data.Timing.toLowerCase().includes(normalizedQuery) ||
      data.BatchType.toLowerCase().includes(normalizedQuery);

    this.LstBatch = this.LstStoreBatch.filter(filterExpression);
  }

  /* Course Filter */
  courseFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      // data.CourseID.toLowerCase().includes(normalizedQuery) ||
      data.CourseName.toLowerCase().includes(normalizedQuery) ||
      // data.CourseType.toLowerCase().includes(normalizedQuery) ||
      data.ShortName.toLowerCase().includes(normalizedQuery);
    this.LstStoreCourse = this.LstCourse.filter(filterExpression);
  }

  /* Move to Student Create Component */
  newStudent() {
    // this._srvStudent.MlDate = this.MlDateRange;
    this._srvStudent.Modes.next({ Mode: 'CREATE' });
    this._srvStd.listPageSize = this.pageSize;
    this._srvStd.listPageSkip = this.skip;

  }

  /* Go to Student Profile Component */
  view(data: any) {
    this._srvApp.val = data;
    this.routes.navigate(['/iCloud/student/student-profile']);
    this._srvApp.checkStudentView = true;
    this._srvStd.listPageSize = this.pageSize;
    this._srvStd.listPageSkip = this.skip;
    getUrl.invokingUrl = '/iCloud/student/student-list';
  }

  lstflitervalue() {
    this._srvStd.MllstFliterData.date.startDate = this.dateRanges.dateRange.startDate;
    this._srvStd.MllstFliterData.date.endDate = this.dateRanges.dateRange.endDate;
    this._srvStd.MllstFliterData.date.duration = this.MlDateRange.duration;
    this._srvStd.MllstFliterData.course = this.StudentFilterData.course;
    this._srvStd.MllstFliterData.batch = this.StudentFilterData.batch;
    this._srvStd.MllstFliterData.courseType = this.StudentFilterData.courseType;
  }

  /* Get Date */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  getCurrentStudentList(fromDate: Date, toDate: Date, courseID: string, batchID: string, courseType: string) {
    this.FilterData = new StudentFilterDataMl();
    const startDate = (fromDate == null || fromDate == undefined) ? "" : DateConversion.ConvertMonthDateYear(fromDate);
    const endDate = (toDate == null || toDate == undefined) ? "" : DateConversion.ConvertMonthDateYear(toDate);
    const Course = (courseID == null || courseID == undefined) ? "" : courseID;
    const Batch = (batchID == null || batchID == undefined) ? "" : batchID;
    const CourseType = (courseType == null || courseType == undefined) ? "" : courseType;

    startDate && endDate ? this.FilterData.StartDate = startDate : delete this.FilterData.StartDate;
    startDate && endDate ? this.FilterData.EndDate = endDate : delete this.FilterData.EndDate;
    Batch ? this.FilterData.CourseBatchID = Batch : delete this.FilterData.CourseBatchID;
    Course ? this.FilterData.CourseID = Course : delete this.FilterData.CourseID;
    CourseType ? this.FilterData.CourseTypeID = CourseType : delete this.FilterData.CourseTypeID;
    this.LstCurrentStudent = this.LstCurrentStudentData = []
    this._srvStudent.getCurrentStudent(this.FilterData).subscribe({
      next: (e) => {
        this.LstCurrentStudentData = e.Data;
        if (this.LstCurrentStudentData.length) {
          this.LstCurrentStudentData.forEach(val => {
            val.RegDate = DateConversion.ConvertStringToDateTime(val.RegisteredDate);
          })
          this.LstCurrentStudent = this.LstCurrentStudentData
          this.ListStatusChack();
        }



      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }


  btnSearchStudent() {
    // this._srvStudent.studentFilterData.StartDate = this.startDate = this.MlDateRange.startDate;
    // this._srvStudent.studentFilterData.EndDate = this.endDate = this.MlDateRange.endDate;
    this._srvStudent.studentFilterData.StartDate = this.startDate = this.dateRanges.dateRange.startDate;
    this._srvStudent.studentFilterData.EndDate = this.endDate = this.dateRanges.dateRange.endDate;
    this._srvStudent.studentFilterData.Course = this.Course = this.StudentFilterData.course ? this.StudentFilterData.course.CourseID : '';
    this.Batch = this._srvStudent.studentFilterData.Batch = this.StudentFilterData.batch == undefined ? "" : this.StudentFilterData.batch.CourseBatchID;
    this._srvStudent.studentFilterData.CourseTypeID = this.CourseType = this.StudentFilterData.courseType ? this.StudentFilterData.courseType.CourseTypeID : '';
    if (((!this.startDate || !this.endDate) && (!this.Course && !this.Batch && !this.CourseType))) this.errorMsg("Please fill the details");
    else if (((!this.startDate && this.endDate) || (this.startDate && !this.endDate)) && ((this.CourseType || !this.CourseType) && (this.Course || !this.Course) && (this.Batch || !this.Batch))) this.errorMsg("Please fill the date");
    else {
      this.lstflitervalue();
      this.getCurrentStudentList(this.startDate, this.endDate, this.Course, this.Batch, this.CourseType);
    }
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }

  DiscontinueStudent() {
    if (this.DiscontinueFrmEntry.valid) {
      this.MlDiscontinueStudent.Reason = this.DiscontinueFrmEntry.value.reason;
      this._srvStd.postStudentDiscontinue(this.MlDiscontinueStudent).subscribe({
        next: val => {
          new CustomNotification(this._srvNotification).ShowSuccess(val.Message);
          this.DiscontinueDialogClose();
          this.getCurrentStudentList(this.startDate, this.endDate, this.Course, this.Batch, this.CourseType);

        }, error: err => this.errorMsg(err.Message)
      })
    }
    // this.getCurrentStudentList(this.startDate, this.endDate, this.Course, this.Batch);
    this.DiscontinueFrmEntry.markAllAsTouched();
  }

  DiscontinueDialogClose() {
    this.ShowDiscontinueDialog = false;
    this.DiscontinueFrmEntry.reset();
    this.MlDiscontinueStudent = new StudentDiscontinueMl();
    this.notesCounter = '0/150';
  }
  notesValueChange(event: string) {
    var charachtersCount = event.length;
    this.notesCounter = `${charachtersCount}/${this.notesMaxlength}`;
  }

  StatusValueChange(data: any) {
    console.log(data);
    this.ListStatusChack();
  }

  ListStatusChack() {
    if (this.Status == 'Studying') {
      this.LstCurrentStudent = this.LstCurrentStudentData.filter(e => e.IsActive == true);
    } else if (this.Status == "Discontinued") {
      this.LstCurrentStudent = this.LstCurrentStudentData.filter(e => e.IsActive == false);
    } else {
      this.LstCurrentStudent = this.LstCurrentStudentData;
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
