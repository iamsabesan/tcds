import { batchByIDDataType } from "src/app/shared/model/common";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { dateRange } from "src/app/shared/model/info.model";
import { StudentAddressCreate } from "src/app/shared/model/student-profile";

/* Different Component Open Based on condition */
export interface IMode {
    Mode: 'LIST' | 'CREATE'
}

//#region Student List
export class CourseBasicInfo {
    CourseID: string = '';
    ShortName: string = '';
    Course: string = '';
    CourseType: string = '';
    Semester: number = 0;
    Duration: string = '';
    CourseFees: number = 0;
    AdmissionFees: number = 0;
    TotalFees: number = 0;
}

export class studentListfilterData {
    batch: any;
    course: any;
    courseType: any;
    dateRange: dateRange
}

export class StudentFilterData {
    StartDate: Date;
    EndDate: Date;
    Course: string = '';
    Batch: string = '';
    CourseTypeID: string = '';
}


export class StudentList {
    StudentID: string = '';
    BatchMappingID: string = '';
    RegisteredDate: string = '';
    RegDate: Date;
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    StartDate: string = '';
    EndDate: string = '';
    StartTime: string = '';
    EndTime: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    IsActive: boolean;
    Reason: string = '';
    CourseTypeName: string = '';
    ShortName: string = '';
}


//#endregion

//#region Student Create



/* Student Basic Info */
export class StudentData {
    BatchMappingID: string = '';
    StudentID: string = '';
    ContactID: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Course: string = '';
    BatchNumber: string = '';
    BatchTime: string = '';
}



/* Course Detail */
export class CourseBasicInfoData {
    CourseID: string = '';
    ShortName: string = '';
    Course: string = '';
    CourseType: string = '';
    Semester: number = 0;
    Duration: string = '';
    CourseFees: number = 0;
    AdmissionFees: number = 0;
    TotalFees: number = 0;
}

/* Student Paid Payment */
export class StudentPaymentData {
    studentID: string = '';
    courseBatchID: string = '';
    discount: number = 0;
    downPayment: number = 0;
    studentType: string = '';
    StudentEnquiryID: string = '';
    paymentItems: PaymentDetail[] = [];
}

/* Payment Detail */
export class PaymentDetail {
    PaymentModeID: string = '';
    PayModeType: string = '';
    PayModeValue: number = 0;
    Amount: number = 0;
    RoundOff = 0;
    TransactionNo: string = '';
    TransactionDate: string = "";
    BankCommission = 0;
    LedgerID = '';
    LedgerName = '';
    DocumentID: string = '';
}

/* Create a New Student */
export class StudentCreate {
    studentName: string = '';
    gender: string = '';
    dateOfBirth: string = '';
    phoneCode: string = '';
    phone: string = '';
    alternatePhoneCode: string = '';
    alternatePhone: string = '';
    email: string = '';
    qualification: string = '';
    guardianType: string = '';
    fatherName: string = '';
    occupation: string = '';
    ReasonToSelect: string = '';
    ReferBy: string = '';
    Purpose: string = '';
    studentImage: File[] = [];
    address: StudentAddressCreate[] = [];
}
//#endregion

// Current Student List Filter data

export class MlCurrectStdList {
    date = new DateRanges();
    course: any;
    batch: batchByIDDataType;
    courseType: any;
}