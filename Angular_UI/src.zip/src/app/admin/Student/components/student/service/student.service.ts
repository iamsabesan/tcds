import { Injectable } from '@angular/core';
import { IMode, StudentCreate, StudentFilterData } from '../model/student';
import { HttpService } from 'src/core/service';
import { IRequestType } from 'src/core/model';
import { BehaviorSubject } from 'rxjs';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { StudentFilterDataMl } from 'src/app/shared/model/common';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  constructor(private _srvHttp: HttpService) { }

  public Modes = new BehaviorSubject<IMode>({ Mode: 'LIST' });
  /* Student List Filter Data */
  public studentFilterData: StudentFilterData = new StudentFilterData();
  public MlDate: DateRanges = new DateRanges();
  public listPageSize: any = 15;
  public listPageSkip: any = 0;
  /* Get Current Student List */
  getCurrentStudent(data: StudentFilterDataMl) {
    // return this._srvHttp.get("/icloud-admission/v1/student/current/list", { params: { fromDate, toDate, courseID, courseBatchID }, RequestType: IRequestType.Protected });
    return this._srvHttp.post("/icloud-admission/v1/student/current/list", data, { RequestType: IRequestType.Protected });
  }

  /* Create a New Student */
  createStudent(data: StudentCreate) {
    const formData = new FormData();
    formData.append("studentName", data.studentName);
    formData.append("gender", data.gender);
    formData.append("dateOfBirth", data.dateOfBirth);
    formData.append("phoneCode", data.phoneCode);
    formData.append("phone", data.phone);
    formData.append("alternatePhoneCode", data.alternatePhoneCode);
    formData.append("alternatePhone", data.alternatePhone);
    if (data.email) formData.append("email", data.email);
    formData.append("qualification", data.qualification);
    formData.append("guardianType", data.guardianType);
    formData.append("fatherName", data.fatherName);
    formData.append("occupation", data.occupation);
    formData.append("ReasonToSelect", data.ReasonToSelect);
    formData.append("ReferBy", data.ReferBy);
    formData.append("Purpose", data.Purpose);
    formData.append("studentImage", data.studentImage as any);
    data.address.forEach((e: any, index) => {
      formData.append(`address[${index}][AddressType]`, e.AddressType);
      formData.append(`address[${index}][Address1]`, e.Address1);
      formData.append(`address[${index}][Address2]`, e.Address2);
      formData.append(`address[${index}][Country]`, e.Country);
      formData.append(`address[${index}][State]`, e.State);
      formData.append(`address[${index}][District]`, e.District);
      formData.append(`address[${index}][Area]`, e.Area);
      formData.append(`address[${index}][Pincode]`, e.Pincode);
      formData.append(`address[${index}][Taluk]`, e.Taluk);
    })
    return this._srvHttp.post("/icloud-admission/v1/student/register/phone", formData, { RequestType: IRequestType.Protected });
  }

  /* Student Paid the Down Payment */
  updateStudentDownPayment(data: any) {
    return this._srvHttp.post("/icloud-admission/v1/student/downpayment", data, { RequestType: IRequestType.Protected });
  }



}
