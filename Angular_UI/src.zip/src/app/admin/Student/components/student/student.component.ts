import { Component } from '@angular/core';
import { StudentsService } from './service/student.service';
import { StudentService } from '../../services/student.service';

@Component({
    selector: 'student',
    templateUrl: './student.component.html',
    providers: [StudentsService]
})
export class StudentComponent {
    public Actions: string = '';

    constructor(private _srvStudent: StudentsService, _srvStd: StudentService) {
        if (_srvStd.checkStudentEnquiry) {
            this.Actions = 'CREATE';
            _srvStd.checkStudentEnquiry = false;

            setTimeout(() => {
            }, 1000);
        } else {
            this._srvStudent.Modes.subscribe(E => {
                this.Actions = E.Mode;
            });
        }
    }
}
