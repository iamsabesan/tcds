import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputsModule, DateInputModule } from '@progress/kendo-angular-dateinputs';
import { CourseDetailModule } from 'src/app/shared/components/course-detail/course-detail.module';
import { TooltipModule } from "@progress/kendo-angular-tooltip";
import { StudentCourseDetailModule } from 'src/app/shared/components/student-course-detail/student-course-detail.module';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { StudentsService } from './service/student.service';
import { StudentComponent } from './student.component';
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { CommonService } from 'src/app/shared/service/common.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CookieService } from 'ngx-cookie-service';
import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';

const routes: Routes = [
    {
        path: '',
        component: StudentComponent,
    }
];

@NgModule({
    declarations: [
        StudentComponent,
        ListComponent,
        CreateComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        ReactiveFormsModule,
        PopupModule,
        GridModule,
        LabelModule,
        DialogsModule,
        DateInputsModule,
        CourseDetailModule,
        DateInputModule,
        TooltipModule,
        StudentCourseDetailModule,
        DateRangesModule,
        TelerikReportingModule,
        PaymentGridModule
    ],
    providers: [StudentsService, NotificationService, CommonService, CookieService]
})
export class StudentModule {}
