//#region  Student Profile

/* Student Profile */
export class StudentProfile {
    ContactID: string = '';
    RollNumber: string = '';
    Gender: string = '';
    StudentName: string = '';
    StudentImages: any;
    DateOfBirth: string = '';
    Phone: string = '';
    PhoneCode: string = '';
    AlternatePhone: string = '';
    AlternatePhoneCode: string = '';
    Email: string = '';
    Qualification: string = '';
    FatherName: string = '';
    GuardianType: string = '';
    Occupation: string = '';
    Address: AddressData[] = [];
    permentAddress: AddressData = new AddressData();
    currentAddress: AddressData = new AddressData();
    Courses: StudentCourseBasicDetail[] = [];
}

/* Address */
export class AddressData {
    ContactID: string = '';
    AddressTypeID: string = '';
    AddressType: string = '';
    Address?: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
    Taluk: string = '';
}

/* Student Course Detail */
export class StudentCourseBasicDetail {
    FullName: string = '';
    ShortName: string = '';
    StudentID: string = '';
    BatchMappingID: string = '';
}

/* Student Course, Batch, Material, fees, Certificate & Marksheet */
export class CourseData {
    Course: Course = new Course();
    Batch: Batch = new Batch();
    Materials: Materials[] = [];
    Payments: Payment[] = [];
    Marksheet: Certificate[] = [];
    Certificate: Certificate = new Certificate();
}

export class Course {
    BatchMappingID: string = '';
    CourseBatchID: string = '';
    CourseID: string = '';
    Course: string = '';
    CourseType: string = '';
    Duration: string = '';
    CourseFees: number = 0;
    Discount: number = 0;
    TotalFees: number = 0;
    PaidFees: number = 0;
    Balance: number = 0;
    IsActive: boolean;
    Reason: string = '';
    ShortName: string = '';
    TotalDiscountAmount: number = 0;
}

export class Batch {
    CourseBatchID: string = '';
    BatchNumber: string = '';
    BatchType: string = '';
    BatchTrack: string = '';
    FacultyID: string = '';
    FacultyName: string = '';
    StartDate: string = '';
    EndDate: string = '';
    StartTime: Date = new Date();
    EndTime: Date = new Date();
}

export class Materials {
    MaterialID: string = '';
    MaterialName: string = '';
    Semester: number = 0;
    IssuedDate: string = '';
    Status: string = '';
}

export class Payment {
    TenantBranchTransID: string = '';
    ReceiptDate: string = '';
    ReceiptNo: string = '';
    Amount: number = 0;
    PaymentType: string = '';
    KeyValue: string = '';
    Summary: string = '';
}

export class Certificate {
    ExamIndentTransID: string = '';
    CertificateAndMarksheetID: string = '';
    Course: string = '';
    Date: string = '';
    IssuedDate: string = '';
    Status: string = '';
    EditOptions: any[] = [];
}

/* Student Material Issue */
export class StudentMaterialIssue {
    batchMappingID: string = '';
    materialID: string = '';
    StudentID: string = '';
    ContactID: string = '';
}

/* Student Part Payment */
export class StudentPartPayment {
    batchMappingID: string = '';
    partPayment: number = 0;
    paymentItems: PaymentData[] = [];
}

/*Payment Transaction */
export class PaymentData {
    PaymentModeID: string = '';
    PayModeType: string = '';
    PayModeValue: number = 0;
    Amount: number = 0;
    RoundOff = 0;
    TransactionNo: string = '';
    TransactionDate: string = "";
    BankCommission = 0;
    LedgerID = '';
    LedgerName = '';
    DocumentID = '';
}
//#endregion

/* Student Info */
export class directStudentViewDataType {
    FullName: string = '';
    StudentID: string = '';
    Course: string = '';
    StudentName: string = '';
    BatchMappingID: string = '';
    ContactID: string = '';
    RollNumber: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    BatchNumber: string = '';
    BatchTime: string = '';
}

export class StudentDiscontinueMl {
    BatchMappingID: string = '';
    Reason: string = '';
}


/* Edit Student details */
export class StudentEditMl {
    ContactID: string = '';
    StudentID: string = '';
    ContactName: string = '';
    Gender: string = '';
    DateOfBirth: string = '';
    PhoneCode: string = '';
    Phone: string = '';
    AlternatePhoneCode: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    Qualification: string = '';
    GuardianType: string = '';
    GuardianName: string = '';
    Occupation: string = '';
    DocumentID: string = '';
    Address: Address[] = [];
}

export class Address {
    ContactID: string = '';
    AddressTypeID: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
    Taluk: string = '';
}


export class StudentEnquirylistMl {
    StudentEnquiryID: string = '';
    TenantBranchID: string = '';
    CourseID: string = '';
    Course: string = '';
    StudentName: string = '';
    Gender: string = '';
    DateOfBirth: string = '';
    PhoneCode: string = '';
    Phone: string = '';
    AlternatePhoneCode: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    Qualification: string = '';
    GuardianType: string = '';
    GuardianName: string = '';
    Occupation: string = '';
    ReasonToSelect: string = '';
    RequestedDate: string = '';
    Status: string = '';
    DocumentID: string = '';
    Address: Address2[] = [];
}

export class Address2 {
    StudentAddressID: string = '';
    StudentEnquiryID: string = '';
    AddressType: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    Country: string = '';
    State: string = '';
    District: string = '';
    Pincode: string = '';
}