import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { MlCurrectStdList } from '../components/student/model/student';
import { StudentFilterDataMl } from 'src/app/shared/model/common';
import { StudentDiscontinueMl, StudentEditMl, StudentEnquirylistMl } from '../models/student-profile';
// import { StudentEnquirylistMl } from '../components/enquiry/Request/model/request';
// import { Student, studentCreateDataType } from '../models/student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  public MllstFliterData = new MlCurrectStdList();
  public checkGoBack = false;
  public checkStudentView = false;
  public listPageSize: any = 15;
  public listPageSkip: any = 0;

  /* Student Enquiry */
  public checkStudentEnquiry = false;
  public checkStudentCreate = true;
  public MlStudentEnquiryData: StudentEnquirylistMl = new StudentEnquirylistMl();

  constructor(private _srvHttp: HttpService) { }

  /* Get Alumnus Student */
  getAlumnsStudent(data: StudentFilterDataMl) {
    return this._srvHttp.post("/icloud-admission/v1/student/alumni/list", data, { RequestType: IRequestType.Protected });
  }

  //#region Student Profile
  /* Get Student Profile (Franchisee) */
  getStudentProfileGetByIdData(contactID: string) {
    return this._srvHttp.get("/icloud-admission/v1/student/getbyid", { params: { contactID }, RequestType: IRequestType.Protected });
  }

  /* Get Student Course, Batch, Material, Certificate Data (Franchisee)(Student Profile) */
  getStudentCourseGetBatchMappingId(batchMappingID: string) {
    return this._srvHttp.get(`/icloud-admission/v1/student/course/detail?batchMappingID=${batchMappingID}`, { RequestType: IRequestType.Protected })
  }

  /* Student Material Issue (Franchisee) */
  postStudentMaterialIssue(data: any) {
    return this._srvHttp.post("/icloud-admission/v1/student/material/issue", data, { RequestType: IRequestType.Protected });
  }

  /* Student Part Payment Paid (Franchisee) (Student Profile) */
  postStudentPartPayment(data: any) {
    return this._srvHttp.post("/icloud-admission/v1/student/partpayment", data, { RequestType: IRequestType.Protected });
  }

  /* Student Certificate & Marksheet Issue */
  updateCertificateStatus(CertificateAndMarksheetID: string) {
    return this._srvHttp.get(`/icloud-admission/v1/student/marksheetandcertificate/issue?certificateAndMarksheetID=${CertificateAndMarksheetID}`, { RequestType: IRequestType.Protected });
  }

  /* Student Discontinue */
  postStudentDiscontinue(data: StudentDiscontinueMl) {
    return this._srvHttp.post("/icloud-admission/v1/student/discontinued", data, { RequestType: IRequestType.Protected });
  }

  /* Edit Student Details */
  postStudentEdit(data: StudentEditMl) {
    return this._srvHttp.post("/icloud-admission/v1/student/edit", data, { RequestType: IRequestType.Protected });
  }

  //#endregion


}
