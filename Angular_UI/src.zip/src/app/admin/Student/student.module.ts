import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { StudentComponent } from './student.component';
import { StudentService } from './services/student.service';
import { DateInputsModule, DateInputModule } from '@progress/kendo-angular-dateinputs';
import { CourseDetailModule } from 'src/app/shared/components/course-detail/course-detail.module';
import { TooltipModule } from "@progress/kendo-angular-tooltip";
import { StudentCourseDetailModule } from 'src/app/shared/components/student-course-detail/student-course-detail.module';
import { ProfileComponent } from './components/profile/profile.component';
import { AlumnusListComponent } from './components/alumnus-list/alumnus-list.component';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CommonService } from 'src/app/shared/service/common.service';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
import { AdminService } from 'src/core/service';
import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';
import { EditStudentModule } from 'src/app/shared/components/edit-student/edit-student.module';
// import { FeesModule } from '../Fees/fees.module';

const routes: Routes = [
  {
    path: '',
    component: StudentComponent,
    children: [
      {
        path: 'student-list',
        loadChildren: () => import('./components/student/student.module').then(m => m.StudentModule)
      },
      {
        path: 'student-profile',
        component: ProfileComponent,
      },
      {
        path: 'alumnus',
        component: AlumnusListComponent,
      },
      {
        path: 'enquiry/request',
        loadChildren: () => import('./components/enquiry/request/request.module').then(m => m.RequestModuel)
      },
      {
        path: 'enquiry',
        loadChildren: () => import('./components/enquiry/report/report.module').then(m => m.ReportModuel)
      },
      {
        path: 'student-profile/:component/:studentID',
        component: ProfileComponent,
      },
    ]
  }
];

@NgModule({
  declarations: [
    StudentComponent,
    ProfileComponent,
    AlumnusListComponent,

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    DropDownsModule,
    FormsModule,
    ReactiveFormsModule,
    PopupModule,
    GridModule,
    LabelModule,
    DialogsModule,
    DateInputsModule,
    CourseDetailModule,
    DateInputModule,
    TooltipModule,
    StudentCourseDetailModule,
    DateRangesModule,
    TelerikReportingModule,
    PaymentGridModule,
    EditStudentModule
  ],
  providers: [StudentService, NotificationService, CommonService, ValueShareService, AdminService],
  // exports: [ProfileComponent]
})
export class StudentModule { }
