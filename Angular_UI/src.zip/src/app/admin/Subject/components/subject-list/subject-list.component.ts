import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { EditSubject, Material, CreateSubject, SubjectData, MaterialList, } from '../../models/subject';
import { SubjectService } from '../../services/subject.service';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DropDownFilter, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { IWebError } from 'src/core/model';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { CommonService } from 'src/app/shared/service/common.service';
import { InputRegex } from 'src/app/shared/components/regex';

@Component({
  selector: 'subject-list',
  templateUrl: './subject-list.component.html',
  styleUrls: ['./subject-list.component.scss']
})
export class SubjectListComponent {

  /* List */
  public LstSubject: SubjectData[] = [];
  public Lstbooks: MaterialList[] = [];
  public bookName: any[] = [];
  public bookArray: any[] = [];
  public finalResult: any[] = [];

  /* Model */
  public MlSubjectCreate: CreateSubject = new CreateSubject();
  public MlEditSubjectData: EditSubject = new EditSubject();
  public MlSubjectMaterialID: Material = new Material();

  /* Pattern */
  // public Name = InputRegex.Name;

  /* Grid Filter and aggragate value */
  public filter!: CompositeFilterDescriptor;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('medium');

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  public subjectDialog: boolean = false;
  public editSubjecttDialog: boolean = false;
  public showButton = LocalString.showAddButton;

  public SubjectName: string = '';
  public SubjectID: string = '';
  public SubjectNamePattern = InputRegex.StrNumSpec;

  /* Form Group */
  subject = new FormGroup({
    subjectName: new FormControl(null, [Validators.required]),
    book: new FormControl(null, [Validators.required]),
  });

  editForm = new FormGroup({
    subjectName: new FormControl(null, [Validators.required]),
    newBook: new FormControl(null)
  });

  constructor(private _srvSubject: SubjectService,
    private _srvNotification: NotificationService,
    private _srvCommon: CommonService) { }

  ngOnInit(): void {
    /* Get Material */
    this._srvCommon.getAllMateraialList().subscribe({
      next: (e) => this.Lstbooks = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
    this.getSubject();
  }

  /* Get Subject List */
  getSubject() {
    this._srvSubject.getSubjectList().subscribe({
      next: (e) => this.LstSubject = e.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Open Create Subject Dialog */
  newSubject() {
    this.subjectDialog = true;
  }

  /* Close Create Subject Dialog*/
  btnCloseSubjectDialog() {
    this.subjectDialog = false;
    this.subject.reset();
    // this.editForm
  }

  /* Close Edit Subject Dialog*/
  btnEditSubjectDialog() {
    this.editSubjecttDialog = false;
    this.editForm.reset();
  }

  /* Reset Form Data */
  reset() {
    this.subject.reset();
    this.editForm.reset();
    this.editForm.controls.subjectName.setValue(this.SubjectName);
  }

  /* Create a New Subject */
  btnCreateSubject(data: any) {
    this.MlSubjectCreate.subjectMaterial = [];
    if (!this.subject.valid) this.subject.markAllAsTouched();
    else {
      this.MlSubjectCreate.subjectName = data.subjectName;

      data.book.forEach((e: any) => {
        this.MlSubjectMaterialID = new Material();
        this.MlSubjectMaterialID.materialID = e.MaterialID;
        this.MlSubjectCreate.subjectMaterial.push(this.MlSubjectMaterialID)
      });

      this._srvSubject.createSubject(this.MlSubjectCreate).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.btnCloseSubjectDialog();
          this.getSubject();
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Edit the Subject */
  Edit(data: any) {
    this.SubjectID = data.SubjectID;
    this.editSubjecttDialog = true;
    this.SubjectName = data.SubjectName;

    this.editForm.controls.subjectName.setValue(this.SubjectName);
    this.editForm.controls.newBook.clearValidators();
    this.editForm.controls.newBook.updateValueAndValidity();

    this.bookName = data.Materials;
    this.Lstbooks.filter((e: any) => this.bookArray = e.MaterialName);

    let array1 = data.Materials.map((e: any) => e.MaterialName);
    let array2 = this.Lstbooks;
    let resultArray = [];
    for (let i = 0; i < array2.length; i++) {
      let id = array2[i].MaterialName;
      if (!array1.includes(id)) resultArray.push(array2[i]);
    }
    this.finalResult = resultArray;
  }

  /* Already Created Subject Edit the Books */
  btnUpdateSubject(data: any) {
    this.MlEditSubjectData.subjectMaterial = [];
    if (!this.editForm.valid) this.editForm.markAllAsTouched();
    else {
      this.MlEditSubjectData.subjectID = this.SubjectID;
      this.MlEditSubjectData.SubjectName = this.editForm.value.subjectName;
      const mapMaterials = (list: any[]) => {
        list?.forEach(e => {
          const material = new Material();
          material.materialID = e.MaterialID;
          this.MlEditSubjectData.subjectMaterial.push(material);
        });
      };

      // If newBook is selected → map both
      if (this.editForm.value.newBook) {
        mapMaterials(this.bookName);
        mapMaterials(data.newBook ?? []);
      }
      else mapMaterials(this.bookName);


      this._srvSubject.editSubject(this.MlEditSubjectData).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.btnEditSubjectDialog();
          this.getSubject();
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
