
/* Subject List */
export class SubjectData {
  SubjectID: any;
  SubjectName: string = '';
  Materials: MaterialList[] = []
}

/* Material */
export class MaterialList {
  MaterialID: any;
  MaterialName: string = '';
}

/* Create Subject */
export class CreateSubject {
  subjectName: string = '';
  subjectMaterial: Material[] = [];
}

/* Edit Subject */
export class EditSubject {
  subjectID: any;
  SubjectName: string = '';
  subjectMaterial: Material[] = [];
}

export class Material {
  materialID: string = '';
}
