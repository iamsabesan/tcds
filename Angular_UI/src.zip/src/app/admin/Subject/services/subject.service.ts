import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { CreateSubject, EditSubject } from '../models/subject';
import { Master } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class SubjectService {

  constructor(private _srvHttp: HttpService) { }

  /* Get Subject List */
  getSubjectList() {
    return this._srvHttp.get(Master.getSubject, { RequestType: IRequestType.Protected });
  }

  /* Create a New Subject */
  createSubject(createSubject: CreateSubject) {
    return this._srvHttp.post(Master.createSubject, createSubject, { RequestType: IRequestType.Protected });
  }

  /* Already Created Subject Edit Books */
  editSubject(editSubject: EditSubject) {
    return this._srvHttp.post(Master.updateSubject, editSubject, { RequestType: IRequestType.Protected });
  }
}
