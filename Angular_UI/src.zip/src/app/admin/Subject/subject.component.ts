import { Component } from '@angular/core';
@Component({
  selector: 'subject',
  template: '<subject-list></subject-list>',
  styleUrls: ["./subject.component.scss"],
})
export class SubjectComponent {
  constructor() { }
}
