import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { TooltipModule } from "@progress/kendo-angular-tooltip";
import { SubjectService } from './services/subject.service';
import { SubjectComponent } from './subject.component';
import { SubjectListComponent } from './components/subject-list/subject-list.component';

const routes: Routes = [
  {
    path: '',
    component: SubjectComponent,
  }
];

@NgModule({
  declarations: [
    SubjectComponent,
    SubjectListComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    TooltipModule,
    DropDownsModule,  
    FormsModule,
    ReactiveFormsModule,
    PopupModule,
    GridModule,
    LabelModule,
    DialogsModule
  ],
  providers: [SubjectService]
})
export class SubjectModule { }
