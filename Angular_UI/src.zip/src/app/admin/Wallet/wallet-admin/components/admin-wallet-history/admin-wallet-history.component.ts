import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { PagerPosition } from '@progress/kendo-angular-grid';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, DropDownFilter, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { franchiseeInfoType, walletHistoryDataType } from '../../models/wallet-admin';
import { WalletServiceService } from '../../services/wallet-service.service';
import { IWebError } from 'src/core/model';
import { CommonService } from 'src/app/shared/service/common.service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';

@Component({
  selector: 'app-admin-wallet-history',
  templateUrl: './admin-wallet-history.component.html',
  styleUrls: ['./admin-wallet-history.component.scss']
})

export class AdminWalletHistoryComponent implements OnInit {

  /* View Child */
  @ViewChild("form") public form?: NgForm; // daterange component value assign the form 
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  /* List */
  public LstFranchisee: franchiseeInfoType[] = [];
  public LstFilterValue: franchiseeInfoType[] = [];

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  /* Model */
  public MlGetData: walletHistoryDataType = new walletHistoryDataType();
  public MlFranchiseeID: franchiseeInfoType = new franchiseeInfoType();

  public currencySymbol: string = '';
  public walletBalanace: number = 0;

  public gridStyle = new gridFontStyle();
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: number[] = [15, 25, 50, 100];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Form Group */
  public walletFilter = new FormGroup({
    franchiseeid: new FormControl(),
    startDate: new FormControl(),
    endDate: new FormControl()
  });

  /* Date Range Component */
  public dateWholePeriod: boolean;
  public WholePerStrDate: Date;

  // private _allFranchisee = {
  //   TenantBranchID: ZeroGUID.guid,
  //   FranchiseeCode: 'ALL',
  //   BranchName: 'ALL',
  //   ContactName: '',
  //   Phone: '',
  //   Address: ''
  // }

  constructor(private _srvNotification: NotificationService,
    public currencyService: IntlService, private _srvWallet: WalletServiceService,
    public _srvCommon: CommonService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.walletBalanace = 5000;
    this.getFranchiseeDetail();
  }

  /* Get Franchisee Detail */
  getFranchiseeDetail() {
    this._srvWallet.getfranchiceBasicInfo().subscribe({
      next: (e) => {
        this.LstFilterValue = e.Data;
        this.LstFilterValue.map((e: any) => {
          // e.Address = this._srvCommon.concatAddress(e);
          e.Address = e.District + " - " + e.Taluk
          // e.Address = e.Address1 + ", " + e.Address2 + ", " + e.Area + ", " + e.District + ", " + e.State;
        });
        this.LstFranchisee = this.LstFilterValue;
        if (this.LstFilterValue.length) {
          // this.LstFilterValue.unshift(this._allFranchisee as any);
          this.MlFranchiseeID = this.LstFranchisee[0];
          this.getWholePer(this.MlFranchiseeID.TenantBranchID);
          this.walletHistory(this.LstFilterValue[0].TenantBranchID, DateConversion.ConvertToYearMonthDate(new Date()), DateConversion.ConvertToYearMonthDate(new Date()))
        } else this.MlFranchiseeID = undefined;

      },
      error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
    });
  }

  /* Franchisee and Date Wise Filter the Wallet */
  btnSearchWallet() {
    if (this.MlDateRange.startDate == null || this.MlDateRange.endDate == null) this.errorMsg("Please fill the dates");
    else
      this.walletHistory(this.MlFranchiseeID.TenantBranchID, DateConversion.ConvertToYearMonthDate(this.MlDateRange.startDate), DateConversion.ConvertToYearMonthDate(this.MlDateRange.endDate))
  }

  walletHistory(baranchId: string, fromDate: string, endDate: string) {
    this._srvWallet.postwalletHistoryUrl(baranchId, fromDate, endDate).subscribe({
      next: (e) => this.MlGetData = e.Data,
      error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
    });
  }

  /* Date Range Component Whole Period Data Get */
  getWholePer(id: string) {
    // this._srvWallet.getWholePerDate(id).subscribe({
    //   next: (res) => {
    //     if (res.Data !== "") {
    //       this.dateWholePeriod = false;
    //     }
    //   },
    //   error: (err: IWebError) => this.errorMsg(err.Message)
    // });
    this._srvCommon.getWholePeriodDate(id).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
        if (this.MlDateRange.duration == "Whole Period") this.dateRangeFun()
      }
    })
  }

  /* Franchisee Dropdown Filter */
  public franchiseeFilter(searchTerm: string) {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.FranchiseeCode.toLowerCase().includes(normalizedQuery) ||
      data.BranchName.toLowerCase().includes(normalizedQuery) ||
      data.ContactName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery) ||
      data.Address.toLowerCase().includes(normalizedQuery);

    this.LstFranchisee = this.LstFilterValue.filter(filterExpression);
  }

  dateChange(event: any) {
    this.MlDateRange = event;
  }

  valuesChange(event: franchiseeInfoType) {
    if (event) {
      this.dateWholePeriod = false;
      this.getWholePer(event.TenantBranchID)
    }
    else {
      this.dateWholePeriod = true;
      this.dateRanges.selectedValue = this.dateRanges.dateRange.endDate = this.dateRanges.dateRange.startDate = null;
    }

    // this.dateWholePeriod = true;
    // if (event == undefined) {
    //   this.dateWholePeriod = true;
    //   this.WholePerStrDate = null
    // }
    // else {
    //   this.dateWholePeriod = false;
    //   this.getWholePer(event.TenantBranchID)
    // }
  }
  dateRangeFun() {
    // let data: any;

    this.dateRanges.dateData.forEach(e => {
      if (e.value == this.MlDateRange.duration) {
        this.dateRanges.selectedValue = e;
        this.dateRanges.getDate(e);
      }
      this.dateRanges.dateRange.startDate = this.WholePerStrDate;
    })

    // this.dateRanges.getDate(this.MlDateRange.duration)
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
