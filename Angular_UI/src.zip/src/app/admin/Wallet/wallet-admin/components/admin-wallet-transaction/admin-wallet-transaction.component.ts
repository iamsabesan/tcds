import { Component } from "@angular/core";
import { WalletServiceService } from "../../services/wallet-service.service";
import { IntlService } from "@progress/kendo-angular-intl";
import { CommonService } from "src/app/shared/service/common.service";
import { IWebError } from "src/core/model";
import { franchiseeInfoType, WalletTransaction, WalletTransactionDetails } from "../../models/wallet-admin";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { DateConversion, DateSize, gridFontStyle, LocalString } from "src/app/shared/app-global";
import { PageChangeEvent} from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor, GroupDescriptor } from '@progress/kendo-data-query';

@Component({
    selector:'wallet-transaction',
    templateUrl:'./admin-wallet-transaction.component.html',
    styleUrls:['./admin-wallet-transaction.component.scss']
})
export class WalletTransactionComponent {

    /* Variable */
    public currencySymbol: string = '';
    public isChecked = false;
    public value = [];
    
    /*List*/
    public LstFranchisee:franchiseeInfoType[] = []; 
    public LstWalletTransaction:WalletTransactionDetails[] = [];
    public LstWalletGridList = [];
    
    /* Model */ 
    public dateStyle = new DateSize('medium');
    public gridStyle = new gridFontStyle();
    public MlDateRange: DateRanges = new DateRanges();
    public MlWalletTransact:WalletTransaction = new WalletTransaction();
    public group: GroupDescriptor[] = [{ field: "FranchiseeCode" }];

    /* Grid Pagination */
    public buttonCount: number = 5;
    public pageSize: number = 15;
    public skip: number = 0;
    public sizes: number[] = [15, 25, 50, 100];
    
      /* Grid Filter */
      public filter!: CompositeFilterDescriptor;

      constructor(public currencyService: IntlService, private _srvWallet: WalletServiceService,
        public _srvCommon: CommonService) { }

 
    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this.getFranchiseeDetail();

    }

    public tagMapper(tags: any[]): any[] {
        return tags.length < 4 ? tags : [tags];
    }

    /* Get Franchisee Detail*/
    getFranchiseeDetail(){
        this._srvWallet.getfranchiceBasicInfo().subscribe({
            next:(res)=>{
                this.LstFranchisee = res.Data;
                 this.LstFranchisee.map((e: any) => {
                    e.District = e.District + " - " + e.Taluk
                });

            },
            error:(err:IWebError)=>this._srvCommon.errorMsg(err.Message)
        })
    } 

     /* Select Particular Franchisee */
    isItemSelected(item: any) {
        return this.value.some((x: any) => x.TenantBranchID === item.TenantBranchID);
    }

    /* Select All Particular Franchisee */
    allFranchisee() {
        this.isChecked = !this.isChecked;
        this.value = this.isChecked ? this.LstFranchisee.slice() : [];
    }

    onValueChange(){
        this.isChecked = this.value.length === this.LstFranchisee.length;
    }

    dateChange(event: any) {
        this.MlDateRange = event;
    }

    btnSearch(){
        this.pageSize = 15;
        this.skip = 0;
        this.LstWalletTransaction = this.LstWalletGridList = [];

        if(this.value.length === 0){
            this._srvCommon.errorMsg('Please select Franchisee');
            return;
        }

        if(!this.MlDateRange.startDate || !this.MlDateRange.endDate ){
            this._srvCommon.errorMsg('Please fill the dates');
            return;
        }

        if(this.value.length !== 0 && this.MlDateRange.startDate && this.MlDateRange.endDate){
            
            this.MlWalletTransact.TenantBranchID = this.value.map((item)=>item.TenantBranchID);
            this.MlWalletTransact.Fromdate =  DateConversion.ConvertToYearMonthDate(this.MlDateRange.startDate);
            this.MlWalletTransact.Todate =  DateConversion.ConvertToYearMonthDate(this.MlDateRange.endDate);

            this._srvWallet.postWalletTransaction(this.MlWalletTransact).subscribe({
                next:(res)=>{  
                    this.LstWalletGridList = res.Data.flatMap(branch =>
                        branch.WalletHistory.map(w => ({
                            FranchiseeCode: branch.BranchDetail.FranchiseeCode,
                            FranchiseeName: branch.BranchDetail.ContactName,
                            Address: `${branch.BranchDetail.District} - ${branch.BranchDetail.Taluk}`,
                            TransactionDate: w.TransactionDate,
                            Description: w.Description,
                            AmountIn: w.AmountIn,
                            AmountOut: w.AmountOut,
                            Status: w.Status,
                            Balance: w.Balance
                        }))
                    );
                },
                error:(err:IWebError)=>{this._srvCommon.errorMsg(err.Message)}
            })
        }
    }

    getFranchiseeName(group: any): string {
        return group?.items?.[0]?.FranchiseeName +' - '+  group?.items?.[0]?.Address || '';
    }

    pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
        this.pageSize = event.take;
    }
}