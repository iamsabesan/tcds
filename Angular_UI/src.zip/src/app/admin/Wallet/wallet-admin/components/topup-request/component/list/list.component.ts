import { Component } from "@angular/core";
import { walletRequestType } from "../../model/topup-request";
import { inactiveAddress } from "src/app/admin/Franchisee/Components/Franchisee-request-list/models/request-list";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { TopupRequestService } from "../../service/topup-request.service";
import { Router } from "@angular/router";
import { NotificationService } from "@progress/kendo-angular-notification";
import { IWebError } from "src/core/model";
import { CustomNotification } from "src/app/shared/model/shared";
import { PageChangeEvent } from "@progress/kendo-angular-grid";
import { CommonService } from "src/app/shared/service/common.service";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html'
})
export class ListComponent {

    /* List */
    public LstRequestWallet: walletRequestType[] = [];

    /* Model */
    public MlAddress: inactiveAddress = new inactiveAddress();

    /* Grid Filter */
    public filter!: CompositeFilterDescriptor;

    /* Date */
    public todaydate: Date = new Date();
    public startDate: Date = new Date(2022, 1, 10);
    public endDate: Date = new Date(2022, 3, 15);

    /* Currency Symbol */
    public currencySymbol = '';

    /* Grid Header Style */
    public gridStyle = new gridFontStyle();

    /* Grid Pagination */
    public buttonCount = 5;
    skip = 0;
    pageSize = 15;
    public sizes: any[] = [15, 25, 50, 100, "All"];

    constructor(private _srvTopup: TopupRequestService, public routes: Router, private _srvNotification: NotificationService,
        private _srvCommon: CommonService
    ) { }

    ngOnInit(): void {
        this.currencySymbol = LocalString.CurrencySymbol;

        if (this._srvTopup.isOldRecord) this.LstRequestWallet = this._srvTopup.lstWalletRequest;
        else {
            this._srvTopup.getwalletData().subscribe({
                next: (res) => {
                    this.LstRequestWallet = res.Data;
                    this.LstRequestWallet.map((e: any) => {
                        // e.Address = e.BranchDetail.Address = e.BranchDetail.Address1 + ", " + e.BranchDetail.Address2 + ", " + e.BranchDetail.Area + ", " + e.BranchDetail.District + ", " + e.BranchDetail.State;
                        // e.Address = e.BranchDetail.Address = e.BranchDetail.Address1 + ", " + e.BranchDetail.Address2 + ", " + e.BranchDetail.Area + ", " + e.BranchDetail.Taluk + ", " + e.BranchDetail.District + ", " + e.BranchDetail.State;
                        e.Address = this._srvCommon.concatAddress(e.BranchDetail);
                        e.BranchDetail.BranchName = e.BranchDetail.BranchName.toUpperCase();
                    })
                },
                error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
            });
        }
        if (this._srvTopup.adminWaletTopupRequest) {
            this.pageSize = this._srvTopup.listPageSize;
            this.skip = this._srvTopup.listPageSkip;
            this._srvTopup.adminWaletTopupRequest = false;
        }

        this._srvTopup.isOldRecord = false;
    }

    view(event: any) {
        this.MlAddress = event.BranchDetail;
        // this.MlAddress.Address1 = event.BranchDetail.Address1;
        // this.MlAddress.Address2 = event.BranchDetail.Address2;
        // this.MlAddress.Area = event.BranchDetail.Area;
        // this.MlAddress.Country = event.BranchDetail.Country;
        // this.MlAddress.District = event.BranchDetail.District;
        // this.MlAddress.Pincode = event.BranchDetail.Pincode;
        // this.MlAddress.State = event.BranchDetail.State;
        this._srvTopup.wallet.next({ Mode: 'view', data: event })
        this._srvTopup.listPageSize = this.pageSize;
        this._srvTopup.listPageSkip = this.skip;
        this._srvTopup.lstWalletRequest = this.LstRequestWallet;
    }

    public pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
        this.pageSize = event.take;
        // Add any additional logic if needed
    }

}