import { Component } from "@angular/core";
import { walletReject, walletRequestType } from "../../model/topup-request";
import { InputRegex } from "src/app/shared/components/regex";
import { TopupRequestService } from "../../service/topup-request.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { DialogService } from "@progress/kendo-angular-dialog";
import { IntlService } from "@progress/kendo-angular-intl";
import { LocalString } from "src/app/shared/app-global";
import { CustomNotification } from "src/app/shared/model/shared";
import { IWebError } from "src/core/model";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import { PaymentDetailViewListMl } from "src/app/shared/model/common";

@Component({
    selector: 'view',
    templateUrl: 'view.component.html'
})
export class ViewComponent {

    /* List */
    public LstPayment: PaymentDetailViewListMl[] = [];

    /* Model */
    public Mlfranchisee: walletRequestType = new walletRequestType();
    public MlAdminWalletReject: walletReject = new walletReject()

    /* Date */
    public total: number = 0;;
    public todayDate: Date = new Date();
    public dialog: boolean = false;

    /* Get Currency Symbol */
    public currencySymbol: string = '';

    /* Get Wallet Balance */
    public walletBalanace: number = 0;

    public rejectID: string = '';

    /* Show the franchisee details */
    public walletRequest: boolean = false;
    public franchiseeDetails: boolean = false;

    /* Pattern */
    public Name = InputRegex.Name;

    constructor(private _srvTopup: TopupRequestService, private _srvNotification: NotificationService,
        private dialogservice: DialogService, public currencyService: IntlService) {
        this.walletRequest = true;
        this.franchiseeDetails = false;
    }

    ngOnInit(): void {
        this.currencySymbol = LocalString.CurrencySymbol;

        this._srvTopup.wallet.subscribe({
            next: (e: any) => {
                if (e.data) {
                    this.Mlfranchisee = e.data;
                    this.walletBalanace = e.data.WalletBalance;
                    this.LstPayment = e.data.PaymentDetail;
                }
            },
            error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });

        this.total = this.LstPayment.reduce((sum: any, current: any) => sum + current.Amount, 0);
        this.rejectID = this.Mlfranchisee.WalletID;
    }

    /* Approve the Franchisee Wallet Request */
    approve() {
        this._srvTopup.postWalletApproval(this.Mlfranchisee).subscribe({
            next: (e) => {
                new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
                this.goBack();
            },
            error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
    }

    /* Reject the Franchisee Wallet Request */
    rejects() {
        const dialogRef = this.dialogservice.open({
            title: "Reject Wallet Topup Request",
            content: RejectComponent,
            width: 400
        });
        // const dialog = dialogRef.content.instance;
        // dialog.showSuccessMsg = 'Wallet Topup Request Rejected';

        const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

        rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
            this.MlAdminWalletReject.walletID = this.rejectID;
            this.MlAdminWalletReject.reason = formData.Reason;


            this._srvTopup.postWalletReject(this.MlAdminWalletReject).subscribe({
                next: (response) => {
                    new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
                    this.goBack();
                    dialogRef.close();
                },
                error: (error) => new CustomNotification(this._srvNotification).ShowError(error.Message),
            });
        });

        // dialog.walletRejectionID = this.rejectID;
        // dialogRef.result.subscribe((result: any) => {
        //     if (!(result instanceof DialogCloseResult)) this.goBack();
        // });
    }

    goBack() {
        this._srvTopup.wallet.next({ Mode: 'list' })
        this._srvTopup.isOldRecord = this._srvTopup.adminWaletTopupRequest = true;
    }

}