import { inactiveAddress } from "src/app/admin/Franchisee/Components/Franchisee-request-list/models/request-list";
import { PaymentDetailViewListMl } from "src/app/shared/model/common";

export class WalletAdmin {
    Mode = 'list' || 'view';
    data? = new walletRequestType();
}

// #region Topup request
export class walletRequestType {
    WalletID: any;
    Date: Date = new Date();
    BranchDetail: walletBranchDetail = new walletBranchDetail();
    WalletBalance: number = 0;
    BranchCode: string = '';
    PaymentDetail: PaymentDetailViewListMl[] = [];
    Address?: any;
}

export class walletBranchDetail {
    BranchName: string = '';
    ContactName: string = '';
    Gender: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: any;
    Address?: inactiveAddress[] = [];
}

// Reject the Franchisee Wallet Request
export class walletReject {
    walletID: string;
    reason: string;
}

export class walletApproveMl {
    walletID: string = '';
}