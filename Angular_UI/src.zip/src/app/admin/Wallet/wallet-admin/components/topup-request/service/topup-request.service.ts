import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { IRequestType } from "src/core/model";
import { HttpService } from "src/core/service";
import { WalletAdmin, walletApproveMl, walletReject, walletRequestType } from "../model/topup-request";

@Injectable({
    providedIn: 'root'
})
export class TopupRequestService {

    public wallet = new BehaviorSubject<WalletAdmin>({ Mode: 'list' });
    walletShareValue = new BehaviorSubject<walletRequestType[]>([])
    public listPageSize: any = 15;
    public listPageSkip: any = 0;
    adminWaletTopupRequest = false;

    public isOldRecord: boolean = false;
    public lstWalletRequest: any[] = [];
    constructor(public http: HttpService) { }

    /* Franchisee Wallet Request List */
    getwalletData() {
        return this.http.get('/icloud-payment/v1/wallet/list', { RequestType: IRequestType.Protected });
    }

    /* Franchisee Wallet Request Approval */
    postWalletApproval(data: walletRequestType) {
        const Id = new walletApproveMl();
        Id.walletID = data.WalletID;
        return this.http.post('/icloud-payment/v1/wallet/accept', Id, { RequestType: IRequestType.Protected })
    }

    /* Franchisee Wallet Request Reject */
    postWalletReject(data: walletReject) {
        return this.http.post('/icloud-payment/v1/wallet/reject', data, { RequestType: IRequestType.Protected })
    }

}