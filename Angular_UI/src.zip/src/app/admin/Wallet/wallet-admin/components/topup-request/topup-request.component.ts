import { Component } from "@angular/core";
import { TopupRequestService } from "./service/topup-request.service";

@Component({
    selector: 'topup-request',
    templateUrl: './topup-request.component.html',
    providers:[TopupRequestService]
})
export class TopupRequestComponent {
    mode: string;
    constructor(public _srvTopup: TopupRequestService) {
        _srvTopup.wallet.subscribe(e => this.mode = e.Mode);
    }
}