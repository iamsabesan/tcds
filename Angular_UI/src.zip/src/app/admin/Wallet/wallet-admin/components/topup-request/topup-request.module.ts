import { NgModule } from "@angular/core";
import { TopupRequestComponent } from "./topup-request.component";
import { ViewComponent } from "./component/view/view.component";
import { ListComponent } from "./component/list/list.component";
import { TopupRequestService } from "./service/topup-request.service";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { GridModule } from "@progress/kendo-angular-grid";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { IconsModule } from "@progress/kendo-angular-icons";
import { FranchiseeViewDetailsModule } from "src/app/shared/components/franchisee-view-details/franchisee-view-details.module";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { RouterModule, Routes } from "@angular/router";
import { CommonModule } from "@angular/common";
import { DialogsModule } from "@progress/kendo-angular-dialog";

const routes: Routes = [
    {
        path: '',
        component: TopupRequestComponent,

    }
];


@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        RejectModule,
        GridModule,
        NavigationModule,
        IconsModule,
        PaymentInfoModule,
        FranchiseeViewDetailsModule,
        ButtonsModule,
        DialogsModule,

    ],
    declarations: [
        TopupRequestComponent,
        ViewComponent,
        ListComponent
    ],
    providers: [TopupRequestService]
})
export class TopupRequestModule { }