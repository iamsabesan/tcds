/* Franchisee Wallet History Dropdown */
export class franchiseeInfoType {
    Address?: string = '';
    BranchCode: string = '';
    BranchName: string = '';
    Phone: string = '';
    ContactName: string = '';
    TenantBranchID: any;
    AddressTypeID: string = '';
    Address1: string = '';
    Address2: string = '';
    AddressType: string = '';
    Area: string = '';
    Country: string = '';
    District: string = '';
    Pincode: number = 0;
    State: string = '';
}

/* Franchisee Wallet History */
export class walletHistoryDataType {
    OpeningBalance: openingAmount = new openingAmount();
    WalletBalance: walletAmount = new walletAmount();
    WalletHistory: walletHistoryData[] = [];
}

export class openingAmount {
    OpeningBalance: number = 0;
}
export class walletAmount {
    WalletBalance: number = 0;
}
export class walletHistoryData {
    AmountIn: number = 0;
    AmountOut: number = 0;
    Balance: number = 0;
    Date: Date = new Date();
    Description: string = '';
    Status: string = '';
}

export class WalletTransaction {
  TenantBranchID: string[] = [];
  Fromdate: string = '';
  Todate: string = '';
}

export class WalletTransactionDetails {
  TenantBranchID: string = '';
  BranchDetail: BranchDetail = new BranchDetail();
  WalletHistory: WalletHistory[] = [];
}

export class BranchDetail {
  TenantBranchID: string = '';
  BranchName: string = '';
  ContactName: string = '';
  Gender: string = '';
  Phone: string = '';
  AlternatePhone: string = '';
  Email: string = '';
  AddressTypeID: string = '';
  AddressType: string = '';
  Address1: string = '';
  Address2: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Area: string = '';
  Pincode: string = '';
  Taluk: string = '';
  FranchiseeCode: string = '';
}

export class WalletHistory {
  TenantBranchID: string = '';
  TransactionDate: string = '';
  Description: string = '';
  AmountIn: number = 0;
  AmountOut: number = 0;
  Status: string = '';
  Balance: number = 0;
}


export const data = [
        {
            "TenantBranchID": "a71bef3a-1474-476d-98c5-0fcce2d9a769",
            "BranchDetail": {
                "TenantBranchID": "a71bef3a-1474-476d-98c5-0fcce2d9a769",
                "BranchName": "TCDS COMPUTER EDUCATION",
                "ContactName": "DINESH",
                "Gender": "MALE",
                "Phone": "+91 6379705149",
                "AlternatePhone": "+91 9874563211",
                "Email": "dinesh@gmail.com",
                "AddressTypeID": "00000000-0000-0000-0000-000000000000",
                "AddressType": "",
                "Address1": "124,1",
                "Address2": "INNER RING ROAD",
                "Country": "INDIA",
                "State": "TAMIL NADU",
                "District": "CHENNAI",
                "Area": "PONMAGAL NAGAR, GUINDY",
                "Pincode": "600032",
                "Taluk": "GUINDY",
                "FranchiseeCode": "TC000672"
            },
            "WalletHistory": [
                {
                    "TenantBranchID": "a71bef3a-1474-476d-98c5-0fcce2d9a769",
                    "TransactionDate": "26-12-2025 11:07:01 AM",
                    "Description": "Registration Fees : 1500.00 ( testtt, TC000672ST2976, MEAN ) (CASH)",
                    "AmountIn": 0.00,
                    "AmountOut": 1500.00,
                    "Status": "APPROVED",
                    "Balance": 4724.00
                },
                {
                    "TenantBranchID": "a71bef3a-1474-476d-98c5-0fcce2d9a769",
                    "TransactionDate": "25-12-2025 06:07:40 PM",
                    "Description": "Registration Fees : 2500.00 ( testtt, TC000672ST2976, FE ) (CASH)",
                    "AmountIn": 0.00,
                    "AmountOut": 2500.00,
                    "Status": "APPROVED",
                    "Balance": 6224.00
                }
			]	
		}
	]	

