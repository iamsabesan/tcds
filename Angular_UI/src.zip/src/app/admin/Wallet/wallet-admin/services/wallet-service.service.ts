import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { WalletTransaction } from '../models/wallet-admin';

@Injectable({
  providedIn: 'root'
})
export class WalletServiceService {

  constructor(private _srvHttp: HttpService) { }

  /* Franchisee Basic Info */
  getfranchiceBasicInfo() {
    return this._srvHttp.get('/icloud-franchisee/v1/franchisee/list/basicinfo', { RequestType: IRequestType.Protected });
  }

  /* Frachisee Wallet History */
  postwalletHistoryUrl(tenantBranchID: string, fromDate: string, toDate: string) {
    return this._srvHttp.get(`/icloud-payment/v1/wallet/history?tenantBranchID=${tenantBranchID}&fromDate=${fromDate}&toDate=${toDate}`, { RequestType: IRequestType.Protected })
  }

  /* Franchisee Start Date */
  getWholePerDate(tenantBranchID: string) {
    return this._srvHttp.get('/icloud-franchisee/v1/franchisee/wholeperiod', { params: { tenantBranchID }, RequestType: IRequestType.Protected })
  }
  
  postWalletTransaction(walletTransaction:WalletTransaction){
     return this._srvHttp.post('/icloud-payment/v1/wallet/history-v1',walletTransaction, { RequestType: IRequestType.Protected })
  }
}
