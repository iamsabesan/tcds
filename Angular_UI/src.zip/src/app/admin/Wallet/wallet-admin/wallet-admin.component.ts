import { Component } from '@angular/core';
@Component({
  selector: 'app-wallet-admin',
  templateUrl: './wallet-admin.component.html',
  styleUrls: ["./wallet-admin.component.scss"],
})
export class WalletAdminComponent {}
