import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { WalletAdminComponent } from './wallet-admin.component';
import { AdminWalletHistoryComponent } from './components/admin-wallet-history/admin-wallet-history.component';
import { WalletServiceService } from './services/wallet-service.service';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { WalletTransactionComponent } from './components/admin-wallet-transaction/admin-wallet-transaction.component';

const routes: Routes = [
  {
    path: '',
    component: WalletAdminComponent,
    children: [
      {
        path: 'wallet-request-list',
        // component: WalletTopupRequestComponent,
        loadChildren: () => import('./components/topup-request/topup-request.module').then(m => m.TopupRequestModule)

      },
      {
        path: 'wallet-history',
        component: AdminWalletHistoryComponent,
      },

      {
        path: 'wallet-transaction',
        component: WalletTransactionComponent,
      },

    ]
  }
];

@NgModule({
  declarations: [
    WalletAdminComponent,
    AdminWalletHistoryComponent,
    WalletTransactionComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    DropDownsModule,
    FormsModule,
    ReactiveFormsModule,
    DateInputModule,
    GridModule,
    LabelModule,
    DateInputsModule,
    DateRangesModule,
  ],
  providers: [WalletServiceService]
})
export class WalletAdminModule { }
