import { Component, OnInit, ViewChild } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { franchiseeWalletHistory, walletHistoryData } from '../../models/wallet-franchisee';
import { WalletFranchiseeService } from '../../services/wallet-franchisee.service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { CommonService } from 'src/app/shared/service/common.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'wallet-history',
  templateUrl: './wallet-history.component.html',
  styleUrls: ['./wallet-history.component.scss']
})
export class WalletHistoryComponent implements OnInit {

  /* View Child */
  @ViewChild(DateRangesComponent) dateRange: DateRangesComponent;

  /* List */
  public LstGetData: walletHistoryData[] = [];

  public filter: CompositeFilterDescriptor;
  public currencySymbol: string = '';

  /* Model */
  public MlFranchiseeWallet: franchiseeWalletHistory = new franchiseeWalletHistory();

  /* Pagination */
  public buttonCount: number = 5;
  public pageSize: number = 15;
  public skip: number = 0;
  public sizes: number[] = [15, 25, 50, 100];

  public dateWholePeriod: boolean;
  public walletBalanace: number = 0;
  public openingBalanace: number = 0;
  public WholePerStrDate!: Date;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();

  public dateStyle = new DateSize('medium');

  /* Date Range */
  public MlDateRange: DateRanges = new DateRanges();

  constructor(private _srvWalletFranchisee: WalletFranchiseeService,
    private _srvNotification: NotificationService, public currencyService: IntlService,
    private _srvCommon: CommonService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    if (this._srvWalletFranchisee.MlDate) this.MlDateRange = this._srvWalletFranchisee.MlDate;

    if (this._srvWalletFranchisee.IsPagination) {
      this.pageSize = this._srvWalletFranchisee.PageSize;
      this.skip = this._srvWalletFranchisee.Skip;
    }

    this.walletData();
    this.getWholePeriodDate();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      if (this.MlDateRange.duration && this.dateRange.dateData) {
        this.dateRange.dateData.forEach(e => {
          if (e.value == this._srvWalletFranchisee.MlDate.duration) {
            this.dateRange.selectedValue = e;
            this.dateRange.getDate(e);
          }
        })
      }
    });
  }

  /* Get Whole Period Data */
  getWholePeriodDate() {
    this._srvCommon.getWholePeriodDate(LocalString.TenantBranchID).subscribe({
      next: (res: any) => this.WholePerStrDate = DateConversion.ConvertStringToDate(res.Data),
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Go to Wallet Topup Component */
  walletTopup() {
    this._srvWalletFranchisee.WalletBalance = this.walletBalanace;
    this._srvWalletFranchisee.IsPagination = true;
    this._srvWalletFranchisee.PageSize = this.pageSize;
    this._srvWalletFranchisee.Skip = this.skip;
    this._srvWalletFranchisee.Mode.next({ Mode: 'CREATE' })
  }

  /* Date Range */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Page Change Event */
  pageEvent(event: PageChangeEvent) {
    this.pageSize = event.take
    this.skip = event.skip;
  }

  /* Search Wallet History */
  btnSearchWalletHistory() {
    this._srvWalletFranchisee.MlDate = this.MlDateRange;
    if (!this.MlDateRange.startDate || !this.MlDateRange.endDate) this.errorMsg("Please fill the dates");
    else this.walletData();
  }

  /* Get Wallet Transaction List */
  walletData() {
    const fromDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
    const toDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);

    this._srvWalletFranchisee.getFranchiseewalletHistory(fromDate, toDate).subscribe({
      next: (e) => {
        this.MlFranchiseeWallet = e.Data;
        this.LstGetData = e.Data.WalletHistory;
        this.walletBalanace = this.MlFranchiseeWallet.WalletBalance.WalletBalance;
        this.openingBalanace = this.MlFranchiseeWallet.OpeningBalance.OpeningBalance;
        if (this.LstGetData.length) {
          this.LstGetData.forEach(val => {
            val.Date = DateConversion.ConvertStringToDateTime(val.TransactionDate);
          });
        }
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
