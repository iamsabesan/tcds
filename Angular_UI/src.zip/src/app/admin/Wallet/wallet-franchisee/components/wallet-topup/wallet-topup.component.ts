import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { WalletTopup } from '../../models/wallet-franchisee';
import { WalletFranchiseeService } from '../../services/wallet-franchisee.service';
import { PaymentInfo } from 'src/app/shared/model/payment-grid.model';
import { PaymentGridComponent } from 'src/app/shared/components/payment-grid/payment-grid.component';
import { PaymentPayVal } from 'src/app/shared/model/payment';


@Component({
  selector: 'wallet-topup',
  templateUrl: './wallet-topup.component.html',
  styleUrls: ['./wallet-topup.component.scss']
})
export class WalletTopupComponent implements OnInit {

  /* Payment View Child */
  @ViewChild(PaymentGridComponent, { static: false }) childRef!: PaymentGridComponent;

  /* List */
  public PaymentDetails: PaymentInfo[] = [];
  public LstPayment: PaymentPayVal[] = [];

  /* Model */
  public MlPayment: PaymentPayVal = new PaymentPayVal();
  public MlWalletTopup: WalletTopup = new WalletTopup()

  /* Payment Grid Detail */
  public paymentamount: number = 0;
  public ErrorNotification: string = 'Please Enter Valid Amount';
  public ErrorNotify: string = 'Fees amount must be equal with total amount';
  public Totalamount: number = 0;

  /* Get Currency Symbol */
  public currencySymbol: string = '';

  /* Show Available Wallet Balance */
  public walletBalance: number = 0;

  /* Set Minimum & Maximum Amount */
  public setMinAmt: number = 0;
  public setMaxAmt: number = 0;

  /* Form Group */
  walletTopupForm = new FormGroup({
    walletAmount: new FormControl(null, [Validators.min(1)]),
  });

  constructor(private _srvWalletFranchisee: WalletFranchiseeService, private _srvNotification: NotificationService,
    public CurrencyService: IntlService) { }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.walletBalance = this._srvWalletFranchisee.WalletBalance;
  }

  /* Wallet Amount Event */
  walletAmountChange(event: number) {
    this.setMinAmt = this.setMaxAmt = this.paymentamount = event;
  }

  /* Get Balance Amount */
  total(total: number): void {
    this.Totalamount = total;
  }

  /* Reset Data */
  reset() {
    this.walletTopupForm.reset();
    this.PaymentDetails = [];
    this.childRef.paymentmessage = true;
    this.childRef.Totalamount = this.paymentamount = 0;
  }

  /* Wallet Topup Request */
  requestWalletTopup() {
    if (!this.walletTopupForm.valid) this.errorMsg("Enter valid amount");
    else if (this.Totalamount == 0) this.errorMsg("Please Add Payment");
    else if (this.paymentamount !== this.Totalamount) this.errorMsg('Please enter full payment');

    else {
      this.LstPayment = [];
      this.PaymentDetails.filter((e: PaymentInfo) => {
        this.MlPayment = new PaymentPayVal();
        this.MlPayment.PaymentModeID = e.PaymentModeID;
        this.MlPayment.PayModeType = e.PayModeType;
        this.MlPayment.PayModeValue = e.PayModeValue;
        this.MlPayment.Amount = e.Amount;
        this.MlPayment.FromLedgerID = e.FromLedger.LedgerID;
        this.MlPayment.FromLedgerName = e.FromLedger.LedgerName;
        this.MlPayment.ToLedgerID = e.ToLedger.LedgerID;
        this.MlPayment.ToLedgerName = e.ToLedger.LedgerName;
        this.MlPayment.TransactionNo = e.TransactionNo.toString();
        e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID  : delete this.MlPayment.DocumentID;
        this.MlPayment.TransactionDate = DateConversion.ConvertToMonthDateYear(e.TransactionDate);
        this.MlPayment.RoundOff = 0;
        this.MlPayment.BankCommission = 0;
        this.LstPayment.push(this.MlPayment);
      });

      this.MlWalletTopup.walletAmount = this.paymentamount;
      this.MlWalletTopup.paymentItems = this.LstPayment;

      this._srvWalletFranchisee.walletTopup(this.MlWalletTopup).subscribe({
        next: (e) => {
          this._srvWalletFranchisee.Mode.next({ Mode: 'LIST' });
          new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
        },
        error: (err) => this.errorMsg(err.Message)
      });
    }
  }

  /* Go to List Component */
  goBack() {
    this._srvWalletFranchisee.Mode.next({ Mode: 'LIST' })
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
