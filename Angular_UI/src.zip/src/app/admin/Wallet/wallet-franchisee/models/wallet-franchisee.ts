import { PaymentPayVal } from "src/app/shared/model/payment";

export interface WalletFranchisee {
    Mode: 'CREATE' | 'LIST';
}


export class franchiseeWalletHistory {
    OpeningBalance: openingAmount = new openingAmount();
    WalletBalance: walletAmount = new walletAmount();
    WalletHistory: walletHistoryData[] = [];
}

export class openingAmount {
    OpeningBalance: number = 0;
}
export class walletAmount {
    WalletBalance: number = 0;
}
export class walletHistoryData {
    AmountIn: number = 0;
    AmountOut: number = 0;
    Balance: number = 0;
    Date: string | Date;
    Description: string = '';
    Status: string = '';
    TransactionDate: string = '';
}

export class WalletTopup {
    walletAmount: number = 0;
    paymentItems: PaymentPayVal[] = [];
}
