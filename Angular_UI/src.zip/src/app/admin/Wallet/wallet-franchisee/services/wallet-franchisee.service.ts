import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { WalletFranchisee, WalletTopup } from '../models/wallet-franchisee';
import { DateRanges } from 'src/app/shared/model/date-ranges';

@Injectable({
  providedIn: 'root'
})
export class WalletFranchiseeService {

  /* Dynamic Switch LIST & CREATE Component */
  public Mode = new BehaviorSubject<WalletFranchisee>({ Mode: 'LIST' });

  public MlDate: DateRanges = new DateRanges();

  /* Store Wallet Balance Amount */
  public WalletBalance: number = 0;

  /* Pagination */
  public IsPagination: boolean = false;
  public PageSize: number = 15;
  public Skip: number = 0;

  constructor(private _srvHttp: HttpService) { }

  /* Get Franchisee Wallet Transaction History */
  getFranchiseewalletHistory(fromDate: string, toDate: string) {
    return this._srvHttp.get(`/icloud-payment/v1/wallet/history?fromDate=${fromDate}&toDate=${toDate}`, { RequestType: IRequestType.Protected })
  }

  /* Franchisee Wallet Topup */
  walletTopup(walletTopup: WalletTopup) {
    return this._srvHttp.post("/icloud-payment/v1/wallet/topup", walletTopup, { RequestType: IRequestType.Protected });
  }

  /* Get Whole Period Date */
  getWholePeriodDate() {
    return this._srvHttp.get("/icloud-franchisee/v1/franchisee/wholeperiod", { RequestType: IRequestType.Protected })
  }
}
