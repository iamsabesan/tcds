import { Component } from '@angular/core';
import { WalletFranchiseeService } from './services/wallet-franchisee.service';
@Component({
  selector: 'app-wallet-franchisee',
  templateUrl: './wallet-franchisee.component.html',
  styleUrls: ["./wallet-franchisee.component.scss"],
  providers: [WalletFranchiseeService]
})

export class WalletFranchiseeComponent {

  public actions: string = '';

  constructor(private _srvWalletFranchisee: WalletFranchiseeService) {
    this._srvWalletFranchisee.Mode.subscribe((res: any) => this.actions = res.Mode)
  }
}
