import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { WalletTopupComponent } from './components/wallet-topup/wallet-topup.component';
import { WalletHistoryComponent } from './components/wallet-history/wallet-history.component';
import { WalletFranchiseeService } from './services/wallet-franchisee.service';
import { WalletFranchiseeComponent } from './wallet-franchisee.component';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PaymentGridModule } from 'src/app/shared/components/payment-grid/payment-grid.module';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { CommonService } from 'src/app/shared/service/common.service';

const routes: Routes = [
  {
    path: '',
    component: WalletFranchiseeComponent,
    children: [
      {
        path: 'wallet-list',
        component: WalletHistoryComponent,
      },
      {
        path: 'wallet-topup',
        component: WalletTopupComponent,
      },
    ]
  }
];

@NgModule({
  declarations: [
    WalletFranchiseeComponent,
    WalletHistoryComponent,
    WalletTopupComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,

    /* Kendo Component */
    ButtonsModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    GridModule,
    LabelModule,
    DropDownsModule,

    /* Shared Component */
    DateRangesModule,
    PaymentGridModule,

  ],
  providers: [WalletFranchiseeService, NotificationService, CommonService]
})
export class WalletFranchiseeModule { }
