import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
// import { DrawerComponent } from '@progress/kendo-angular-layout/drawer/drawer.component';
import { filter, Observable } from 'rxjs';
import { getUrl, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { AppService } from 'src/core/service/app.service';
import { AdminDashboard } from './model/admin-dashboard';
import { DashboardService } from './service/dashboard.service';
import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';
import { SeriesLabelsContentArgs } from '@progress/kendo-angular-charts';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  // @ViewChild(DrawerComponent, { static: true })
  // drawer!: DrawerComponent;
  public currencySymbol: string = '';
  public LanguageCulture: string = '';
  public NumberFormat: string = '';
  public walletBalances = 125000;
  public menuList: CustomMenu[] = [];
  public previousUrl: string = '';
  public currentUrl: string = '';
  public dashboardData: AdminDashboard = new AdminDashboard();
  public checkingData: any;

  public LstFranchisee = [];
  public TotalFranchisee: number = 0;
  public MlFranchisee: AdminDashboard = new AdminDashboard();

  public ActiveFranchisee: string = '#00B886';
  public ExpiredFranchisee: string = '#0380B5';
  public LockedFranchisee: string = '#9242D2';
  public PendingFranchisee: string = '#DB8122';

  constructor(public srvIntl: IntlService, public routes: Router,
    public _srvNotification: NotificationService, private _appService: AppService,
    public service: DashboardService) { }

  ngOnInit() {
    this.menuList = this._appService.menus;
    this.currencySymbol = LocalString.CurrencySymbol;
    this.LanguageCulture = LocalString.CurrencyFormat;
    this.NumberFormat = LocalString.NumberFormat;
    this.getDashboard()
    this.routes.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: any) => {
      this.previousUrl = this.currentUrl;
      getUrl.currentUrl = event.url;
      getUrl.invokingUrl = this.previousUrl;
    });
  }
  getDashboard() {
    this.service.getAdminDashboard().subscribe({
      next: (e) => {
        this.dashboardData = this.MlFranchisee = e.Data;
        this.getChart(this.MlFranchisee);
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  data$: Observable<{ LstFranchisee: any[], TotalFranchisee: number }>;

  getChart(data: AdminDashboard) {
    const a = [];
    a.push({ Count: data.FranchiseeActive, Color: this.ActiveFranchisee })
    a.push({ Count: data.FranchiseeExpired, Color: this.ExpiredFranchisee })
    a.push({ Count: data.FranchiseeLocked, Color: this.LockedFranchisee })
    a.push({ Count: data.FranchiseePending, Color: this.PendingFranchisee });

    this.LstFranchisee = a;
    this.TotalFranchisee = data.FranchiseeActive + data.FranchiseeExpired + data.FranchiseeLocked;
    // this.LstFranchisee.filter((e) => {
    //   if(!e.FranchiseePending) this.TotalFranchisee = e
    // })
    // this.TotalFranchisee = this.LstFranchisee.reduce((sum, item) => sum + item.Count, 0);
  }

  public labelContent(e: SeriesLabelsContentArgs): string {
    return e.category;
  }


  franchiseePending() {
    this.routes.navigate(['/iCloud/franchisee/franchisee-request-list']);
  }
  franchiseeActive() {
    this.routes.navigate(['/iCloud/franchisee/franchisee-list']);
  }
  walletPending() {
    this.routes.navigate(['/iCloud/wallet/wallet-request-list']);
  }
  walletBalance() {
    this.routes.navigate(['/iCloud/wallet/wallet-history']);
  }
  mail(componentName: any) {
    this.routes.navigate(['/iCloud/mail/admin-mail']);
    this.menuList.forEach(item => {
      item.selected = item.label === componentName;
    });
  }
  materialIndent() {
    this.routes.navigate(['/iCloud/indent/material-indent-list']);
  }
  materiaExamIndent() {
    this.routes.navigate(['/iCloud/indent/exam-indent-list']);
  }
  despatchMaterial() {
    this.routes.navigate(['/iCloud/despatch/material-despatch-list']);
  }
  despatchCertificate() {
    this.routes.navigate(['/iCloud/despatch/certificate-marksheet-despatch-list']);
  }
  printingCertificate() {
    this.routes.navigate(['/iCloud/Print/certificate-print-list']);
  }
  printingMarksheet() {
    this.routes.navigate(['/iCloud/Print/marksheet-print-list']);
  }
  renewalRequest() {
    this.routes.navigate(['/iCloud/franchisee/renewal-request-list']);
    // this.drawerComponent.selectItem(component);
  }
  course() {
    this.routes.navigate(['/iCloud/course/course-list']);
  }


  chartTitle = '9 Franchisee';

  // Chart data
  chartData = [
    { category: 'Active', value: 5, color: '#00b300' },
    { category: 'Expired', value: 1, color: '#007bff' },
    { category: 'Locked', value: 3, color: '#8000ff' },
    { category: 'Pending', value: 2, color: '#ff8000' },
  ];

  // labelContent = (e: any) => `${e.value}`;
} 
