import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { IconsModule } from "@progress/kendo-angular-icons";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { ChartsModule } from "@progress/kendo-angular-charts";
import { BotWidgetCardModule } from 'bot-widget-card';
import { BotWidgetSimpleModule } from 'bot-widget-simple';
// import { IndentModule } from '../Indent/indent.module';


const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  }
]

@NgModule({
  declarations: [
    DashboardComponent,
  ],
  imports: [
    CommonModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    ChartsModule,
    BotWidgetCardModule,
    BotWidgetSimpleModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: []
})
export class dashboardModule { }
