import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  public adminDashboardUrl = "/icloud-franchisee/v1/franchisee/admin/dashboard";
  constructor(public http_service:HttpService) { }
  getAdminDashboard(){
    return this.http_service.get(this.adminDashboardUrl, {RequestType:IRequestType.Protected});
  }
}
 