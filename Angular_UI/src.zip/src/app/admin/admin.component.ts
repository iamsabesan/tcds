// import { AnimationPlayer } from '@angular/animations';
// import { DOCUMENT } from '@angular/common';
import { Component, OnInit,  ViewEncapsulation } from '@angular/core';
// import { Router } from '@angular/router';
// import { CldrIntlService, IntlService } from '@progress/kendo-angular-intl';
// import { DrawerItemExpandedFn, DrawerSelectEvent, TabAlignment } from '@progress/kendo-angular-layout';
// import { Align, PopupRef } from '@progress/kendo-angular-popup';
// import { CookieKey, CrazyKey } from 'src/core/helper';
// import { ILoginResponse, IRequestType, IUser, MappedMenuTree, Theme, UpdateTheme } from 'src/core/model';
// import { AppService, HttpService, KeyService } from 'src/core/service';
// import * as _ from 'lodash';
// import { environment } from '../../environments/environment';
// import { License, LocalString, themeList } from '../shared/app-global';
// import { AppConfigService } from 'src/core/service/appconfig.service';
// import { drawerMenu } from './drawer-menu';

@Component({
  selector: 'sys-admin',
  templateUrl: './admin.component.html',
  styleUrls: ["./admin.component.scss"],
  encapsulation: ViewEncapsulation.None
})
export class AdminComponent implements OnInit {
  // @ViewChild("settingsAnchor") settingsAnchor!: ElementRef;
  // @ViewChild("MenuAnchor") MenuAnchor!: ElementRef;
  // @ViewChild("settingsPopup", { read: ElementRef }) settingsPopup!: ElementRef;
  // @ViewChild("MenuPopup", { read: ElementRef }) MenuPopup!: ElementRef;
  // _privateKey: string = environment._privateKey;
  // Themes = themeList;
  // activeThemeType = Theme.ActiveThemeType;
  // activeThemeName = Theme.ActiveThemeName;
  // lightThemes: any[] = [];
  // darkThemes: any[] = [];
  // themeSidebar = false;
  // LoginUserTheme = "";
  // updateTheme: UpdateTheme = new UpdateTheme();
  // licenseObj: License = new License();
  // ShowLicenseInfo = environment.ShowLicenseInfo;
  // AppLogo = environment.AppLogo;
  // AppLogoSmall = environment.AppLogoSmall;

  // userClaims: IUser | undefined;
  // activeThemeKey = "";
  // userName: string = '';

  // splashScreenEl: any;
  // player!: AnimationPlayer;

  // menuList: MappedMenuTree[] = [];
  // Bearer: ILoginResponse[] = [];
  // items: any[] = [];
  // expandedIndices: number[] = [];
  // menuExpandedStateIcon = '';
  // selectedItem = "";

  // fullScreenIcon = true;
  // exitFullScreenIcon = false;

  // showSettingsOp = false;
  // showMenuSettingsOp = false;
  // alignment: TabAlignment = "start";
  // drawerExpanded = true;
  // item: any = {};
  // anchorAlign: Align = { horizontal: 'right', vertical: 'bottom' };
  // popupAlign: Align = { horizontal: 'right', vertical: 'top' };
  // popup!: PopupRef | null;

  // // Drawer Class
  // @Input() drawerClass = '';
  // public drawerClasses = '';

  // SysSettings = [
  //   { title: "Themes", iconClass: "lock" },
  // ]

  // SysMenuSettings = [
  //   { title: "Change Password", iconClass: "lock" },
  //   { title: "Profile", iconClass: "lock" },
  //   { title: "Sign out", iconClass: "user" }
  // ]

  // public getScreenWidth: any;
  // public getScreenHeight: any;

  // @HostListener('window:resize', ['$event'])
  // onWindowResize() {
  //   this.getScreenWidth = window.innerWidth;
  //   this.getScreenHeight = window.innerHeight;
  //   return [this.getScreenWidth, this.getScreenHeight];
  // }

  // viewerContainerStyle = {
  //   position: 'relative',
  //   height: '100%',
  //   left: '0px',
  //   right: '0px',
  // };
  // // ServerUrl = {
  // //   url: "http://server.office:83",
  // //   username: 'reportuser',
  // //   password: '123456'
  // // };
  // serUrl = {
  //   url: "http://server.office:83",
  //   username: 'reportuser',
  //   password: '123456'
  // };
  // ServerUrl: any;

  // constructor(@Inject(DOCUMENT) private document: Document,
  //   private _appService: AppService,
  //   private _httpService: HttpService, private _srvKey: KeyService,
  //   private router: Router, private appConfigService: AppConfigService,
  //   @Inject(LOCALE_ID) public localeId: string, public intlService: IntlService) {
  //   this.splashScreenEl = this.document.body.querySelector('#splash-screen-guru');
  //   this.lightThemes = this.Themes.filter((e) => e.themeType === 'light');
  //   this.darkThemes = this.Themes.filter((e) => e.themeType === 'dark');

  //   // this.ServerUrl = {
  //   //   url: this.appConfigService.appConfigDetails.ServerUrl,
  //   //   username: this.appConfigService.appConfigDetails.Username,
  //   //   password: this.appConfigService.appConfigDetails.Password
  //   // };

  //   this.ServerUrl = {
  //     url: this.appConfigService.appConfigDetails.ServerUrl,
  //     username: CrazyKey.decrypt(this.appConfigService.appConfigDetails.Username, environment._privateKey),
  //     password: CrazyKey.decrypt(this.appConfigService.appConfigDetails.Password, environment._privateKey),
  //   };
  //   this.drawerClasses = this.drawerClass;

  // }

  // getTenantBranchUrl = '/tenant-branch-service/tenantbranch/list';
  // getBranchList() {
  //   return this._httpService.get(this.getTenantBranchUrl, { RequestType: IRequestType.Protected });
  // };

  ngOnInit(): void {
  //   this.getScreenWidth = window.innerWidth;
  //   this.getScreenHeight = window.innerHeight;
  //   LocalString.Agent = "Agent";

  //   this.menuList = this._appService.menus;
  //   // this.menuList = drawerMenu;
  //   this.menuList.forEach((menu) => {
  //     if (this.router.url === "/iCloud") {
  //       if (menu.isDefault == true) {
  //         const i = this.menuList.findIndex((e) => e.isDefault == true);
  //         menu.selected = true;
  //         this.router.navigate([this.menuList[i].path]);
  //       };
  //     }
  //     else {
  //       if (!this.menuList.some((e) => e.path === this.router.url)) {
  //         this.router.navigate(['/iCloud/error']);
  //       }
  //     }

  //     if (menu.parentId === 0) {
  //       if (menu.type.toLocaleLowerCase() === 'item') {
  //         this.items.push(_.pick(menu, ['id', 'text', 'icon', 'expanded', 'selected', 'path']))
  //       } else {
  //         this.items.push(_.pick(menu, ['id', 'text', 'icon', 'expanded', 'selected']))
  //       }
  //       return;
  //     } else {
  //       this.items.push(menu);
  //     }
  //   });

  //   this.items.forEach((e) => {
  //     if (e.path === this.router.url) {
  //       e.selected = true;
  //       this.expandedIndices.push(e.parentId);
  //     }
  //   });

  //   this.userClaims = this._appService.user;
  //   if (this.userClaims) {
  //     this.localeId = CrazyKey.decrypt(this.userClaims.LanguageCulture, this._privateKey);
  //     LocalString.CurrencySymbol = this.userClaims.CurrencySymbol;
  //     // LocalString.dateTimeFormat = CrazyKey.decrypt(this.userClaims.DateTimeFormat, this._privateKey);
  //     LocalString.dateFormat = CrazyKey.decrypt(this.userClaims.DateFormat, this._privateKey);
  //     LocalString.timeFormat = CrazyKey.decrypt(this.userClaims.TimeFormat, this._privateKey);
  //     LocalString.TenantID = CrazyKey.decrypt(this.userClaims.TenantID, this._privateKey);
  //     LocalString.TenantBranchID = CrazyKey.decrypt(this.userClaims.TenantBranchID, this._privateKey);
  //     if (this.localeId === 'hi-IN') {
  //       this.localeId = 'en-IN';
  //     }
  //     if (LocalString.LanguageCulture !== this.localeId) {
  //       (<CldrIntlService>this.intlService).localeId = this.localeId;
  //       LocalString.LanguageCulture = this.localeId;
  //     }

  //     this.userName = CrazyKey.decrypt(this.userClaims.UserName, this._privateKey);
  //     this.licenseObj.LicenseInfo = 'Licensed to ' + CrazyKey.decrypt(this.userClaims.TenantName, this._privateKey);

  //     const authRole = CrazyKey.decrypt(this.userClaims.AuthRole, this._privateKey);
  //     LocalString.showAddButton = (authRole === '["TenantAdmin"]') ? true : false;
  //   }

  //   this.activeThemeKey = this._srvKey.HashedCookieKey(CookieKey.ActiveTheme);
  //   const currentTheme = JSON.parse(localStorage.getItem(this.activeThemeKey) || '') as string;
  //   this.LoginUserTheme = CrazyKey.decrypt(currentTheme, this._privateKey);
  //   const isThemeExists = this.Themes.some((e) => e.themeName === this.LoginUserTheme);
  //   if (isThemeExists) {
  //     this.setTheme(this.LoginUserTheme);
  //   }
  //   else {
  //     this.setTheme('astronautBlue');
  //   }
  // }

  // isItemExpanded: DrawerItemExpandedFn = (item): boolean => {
  //   return this.expandedIndices.indexOf(item.id) >= 0;
  };

  // onSelect(ev: DrawerSelectEvent): void {
  //   this.selectedItem = ev.item.text;
  //   const current = ev.item.id;
  //   const parentID = ev.item.parentId;
  //   if (this.expandedIndices.indexOf(current) >= 0) {
  //     this.expandedIndices = this.expandedIndices.filter((id) => id !== current);
  //   }
  //   else {
  //     this.expandedIndices = [];
  //     if (parentID) {
  //       this.expandedIndices.push(parentID);
  //     }
  //     this.expandedIndices.push(current);
  //     if (ev.item.path) {
  //       this.router.navigate([ev.item.path]);
  //     }
  //   }
  // }

  // selectThemeType(selectedThemeType: any) {
  //   this.activeThemeType = selectedThemeType;
  // }

  // loadTheme(selectedThemeName: string) {
  //   this.updateTheme.ActiveTheme = selectedThemeName;
  //   this._httpService.post('/menu/updatetheme', this.updateTheme, { RequestType: IRequestType.Protected }).subscribe({
  //     next: () => {
  //       localStorage.setItem(this.activeThemeKey, JSON.stringify(CrazyKey.encrypt(selectedThemeName, this._privateKey)));
  //       this.setTheme(selectedThemeName);
  //     }
  //   });
  // }

  // setTheme(selectedThemeName: string) {
  //   Theme.ActiveThemeType = this.activeThemeType;
  //   Theme.ActiveThemeName = this.LoginUserTheme = this.activeThemeName = selectedThemeName;
  //   let cssFile = selectedThemeName.concat('-', this.activeThemeType).concat('.css');
  //   let headEl = this.document.getElementsByTagName('head')[0];
  //   const newLinkEl = this.document.createElement('link');
  //   newLinkEl.id = 'theme';
  //   newLinkEl.rel = 'stylesheet';
  //   newLinkEl.href = cssFile;
  //   let link = this.document.getElementById('theme');
  //   headEl.appendChild(newLinkEl);
  //   if (link) {
  //     link.parentNode?.removeChild(link);
  //   }
  // }

  // togglePopup(popup: string, show?: boolean,): void {
  //   switch (popup) {
  //     case 'settingsPopup': {
  //       this.showSettingsOp = show !== undefined ? show : !this.showSettingsOp;
  //       this.showMenuSettingsOp = false;
  //       break;
  //     }
  //     default: {
  //       this.showSettingsOp = false;
  //       break;
  //     }
  //   }
  // }

  // MenuToggle(popup: string, show?: boolean,): void {
  //   switch (popup) {
  //     case 'MenuPopup': {

  //       this.showMenuSettingsOp = show !== undefined ? show : !this.showMenuSettingsOp;
  //       this.showSettingsOp = false;
  //       break;
  //     }
  //     default: {
  //       this.showMenuSettingsOp = false;
  //       break;
  //     }
  //   }
  // }

  // ChangeTheme() {
  //   this.onSelectedItem('Themes');
  // }
  // fullScreen(data: string) {
  //   if (data == 'fullscreen') {
  //     document.documentElement.requestFullscreen();
  //     this.fullScreenIcon = false;
  //     this.exitFullScreenIcon = true;
  //   }
  //   else if (data == 'fullscreen-exit') {
  //     document.exitFullscreen();
  //     this.fullScreenIcon = true;
  //     this.exitFullScreenIcon = false;
  //   }
  // }
  // SignOut() {
  //   this._srvKey.SignOut();
  //   if (document.fullscreenElement) {
  //     document.exitFullscreen();
  //   }
  // }

  // onSelectedItem(item: string) {
  //   if (item == 'Themes') {
  //     this.themeSidebar = true;
  //     this.activeThemeName = Theme.ActiveThemeName;
  //     this.activeThemeType = Theme.ActiveThemeType;
  //   }
  //   else if (item == "Change Password") {
  //   }
  //   else if (item == "Sign out") {
  //     this.SignOut();
  //   }
  // }
  // onMenuSelectedItem(item: string) {
  //   if (item == 'Themes') {
  //     this.themeSidebar = true;
  //     this.activeThemeName = Theme.ActiveThemeName;
  //     this.activeThemeType = Theme.ActiveThemeType;
  //   }
  //   else if (item == "Change Password") {
  //   }
  //   else if (item == "Sign out") {
  //     this.SignOut();
  //   }
  // }

  // closeThemeSidebar() {
  //   this.themeSidebar = false;
  // }

  // addChildren(arr: Array<any>, index: number, children: Array<any>) {
  //   arr.splice(index + 1, 0, ...children);
  // }

  // resetItems(): Array<any> {
  //   let arr: Array<any> = [];
  //   this.items.forEach((item) => {
  //     arr.push(Object.assign({}, item));
  //   });
  //   return arr;
  // }

  // @HostListener('keydown', ['$event'])
  // keydown(event: any): void {
  //   if (event.keyCode === 27) {
  //     this.togglePopup('default', false);
  //     this.MenuToggle('default', false);
  //   }
  // }

  // @HostListener('document:click', ['$event'])
  // documentClick(event: any): void {
  //   this.contains(event.target)
  // }

  // contains(target: any) {
  //   let isExist: boolean;
  //   let eleRef = target.closest("button") === null ? 'default' : target.closest("button").getAttribute('name');
  //   switch (eleRef) {
  //     case ('settingsPopup'): {
  //       isExist = this.settingsAnchor.nativeElement.contains(target) ||
  //         (this.settingsPopup ? this.settingsPopup.nativeElement.contains(target) : false);
  //       break;
  //     }
  //     case ('MenuPopup'): {
  //       isExist = this.MenuAnchor.nativeElement.contains(target) ||
  //         (this.MenuPopup ? this.MenuPopup.nativeElement.contains(target) : false);
  //       break;
  //     }
  //     default: {
  //       isExist = false;
  //     }
  //   }
  //   if (!isExist) {
  //     this.togglePopup(eleRef, false);
  //     this.MenuToggle(eleRef, false);
  //   }
  // }
  // mouseOverTheme = '';
  // MouseOver(data: string) {
  //   if (this.mouseOverTheme !== data) {
  //     this.mouseOverTheme = data;
  //     this.showTheme(this.mouseOverTheme);
  //   }
  // }

  // MouseLeave() {
  //   this.showTheme(this.LoginUserTheme);
  // }
  // showTheme(theme: string) {
  //   let cssFile = theme.concat('-', this.activeThemeType).concat('.css');
  //   let headEl = this.document.getElementsByTagName('head')[0];
  //   const newLinkEl = this.document.createElement('link');
  //   newLinkEl.id = 'theme';
  //   newLinkEl.rel = 'stylesheet';
  //   newLinkEl.href = cssFile;
  //   let link = this.document.getElementById('theme');
  //   headEl.appendChild(newLinkEl);
  //   if (link) {
  //     link.parentNode?.removeChild(link);
  //   }
  // }
}
