import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { AdminComponent } from './admin.component';
const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: 'franchisee',
        loadChildren: () => import('./Franchisee/franchisee.module').then(m => m.FrachiseeModule)
      },
      // {
      //   path: 'franchisee/franchisee-request-list',
      //   loadChildren: () => import('./Franchisee/Components/Franchisee-request-list/Franchisee-request-list.module').then(m => m.FrachiseeRequestListModule)
      // },
      {
        path: 'vendor/vendor-list',
        loadChildren: () => import('./Vendor/vendor.module').then(m => m.VendorModule)
      },
      {
        path: 'course/course-list',
        loadChildren: () => import('./Course/course.module').then(m => m.CourseModule)
      },
      {
        path: 'subject',
        loadChildren: () => import('./Subject/subject.module').then(m => m.SubjectModule)
      },
      {
        path: 'indent',
        loadChildren: () => import('./Indent/indent.module').then(m => m.IndentModule)
      },
      {
        path: 'despatch',
        loadChildren: () => import('./Despatch/despatch.module').then(m => m.DespatchModule)
      },
      {
        path: 'batch/batch-list',
        loadChildren: () => import('./Batch/batch.module').then(m => m.BatchModule)
      },
      // {
      //   path: 'student/student-list',
      //   loadChildren: () => import('./Student/components/student/student.module').then(m => m.StudentModule)
      // },
      {
        path: 'student',
        loadChildren: () => import('./Student/student.module').then(m => m.StudentModule)
      },
      {
        path: 'wallet',
        loadChildren: () => import('./Wallet/wallet-admin/wallet-admin.module').then(m => m.WalletAdminModule)
      },
      {
        path: 'wallet/wallet-list',
        // loadChildren: () => import('./Wallet/components/wallet-franchisee/wallet-franchisee.module').then(m => m.WalletFranchiseeModule)
        loadChildren: () => import('./Wallet/wallet-franchisee/wallet-franchisee.module').then(m => m.WalletFranchiseeModule)
      },
      {
        path: 'stock',
        loadChildren: () => import('./Stock/stock.module').then(m => m.StockModule)
      },
      {
        path: 'fees',
        loadChildren: () => import('./Fees/fees.module').then(m => m.FeesModule)
      },
      {
        path: 'Print',
        loadChildren: () => import('./Print/print.module').then(m => m.CertificatePrintListModule)
      },
      {
        path: 'Despatch',
        loadChildren: () => import('./Despatch/despatch.module').then(m => m.DespatchModule)
      },
      {
        path: 'franchisee-dashboard',
        loadChildren: () => import('./dashboard/dashboard.moule').then(m => m.dashboardModule)
      },
      {
        path: 'admin-dashboard',
        loadChildren: () => import('./admin-dashboard/dashboard.moule').then(m => m.dashboardModule)
      },
      {
        path: 'reports',
        loadChildren: () => import('./report/report.module').then(m => m.ReportModule)
      },
      {
        path: 'mail',
        loadChildren: () => import('./Mail/mail.module').then(m => m.MailModule)
      },
      {
        path: 'news',
        loadChildren: () => import('./news/news.module').then(m => m.NewsModule)
      },
      {
        path: 'admin-employee',
        loadChildren: () => import('./user/components/admin/admin.module').then(m => m.AdminModule)
      },
      {
        path: 'franchisee-employee',
        loadChildren: () => import('./user/components/franchisee/franchisee.module').then(m => m.FranchiseeModule)
      },
      // {
      //   path: 'user',
      //   loadChildren: () => import('./user/user.module').then(m => m.UserModule)
      // },
      {
        path: 'user-job-title',
        loadChildren: () => import('./user-job-title/user-job-title.module').then(m => m.UserJobTitleModule)
      }, {
        path: "bank",
        loadChildren: () => import('./Banking/banking.module').then(m => m.BankingModule)
      },
      {
        path: "accounting",
        loadChildren: () => import('./Accounting/accounting.module').then(m => m.AccountingModule)
      },
      {
        path: "videos",
        loadChildren: () => import('./videos/videos.module').then(m => m.VideosModule)
      }
    ]
  }
];

@NgModule({
  declarations: [
    AdminComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    PopupModule,
    DialogsModule,
    ToolBarModule,
    HttpClientModule
  ]
})
export class AdminModule { }
