import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from '@progress/kendo-angular-notification';
import { LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { Dashboard } from './model/dashboard';
import { DashboardService } from './service/dashboard.service';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent {
  public startDate = new Date();
  public dashboard: Dashboard = new Dashboard();
  public currency: string = '';
  public ApprovalPercentage: number = 0;
  public SubscriptionPercentage: number = 0;
  public LanguageCulture: string = '';
  public NumberFormat: string = '';
  constructor(private _srvDashboard: DashboardService, private _router: Router,
    private _srvNotification: NotificationService, public srvIntl: IntlService) { }

  ngOnInit() {
    this.currency = LocalString.CurrencySymbol;
    this.LanguageCulture = LocalString.CurrencyFormat;
    this.NumberFormat = LocalString.NumberFormat;
    this.getDashboard()
  }

  getDashboard() {
    this._srvDashboard.getFranchiseeDashboard().subscribe({
      next: (e) => {
        this.dashboard = e.Data;
        this.ApprovalPercentage = (this.dashboard.ApprovalCompletedDays / this.dashboard.ApprovalTotalDays) * 100;
        this.SubscriptionPercentage = (this.dashboard.SubscriptionCompletedDays / this.dashboard.SubscriptionTotalDays) * 100;
        this.ApprovalPercentage = + this.ApprovalPercentage.toFixed(0);
        this.SubscriptionPercentage = + this.SubscriptionPercentage.toFixed(0);
      },
      error: (err) => {
        new CustomNotification(this._srvNotification).ShowError(err.Message);
      }
    });
  }

  getWallet() {
    this._router.navigate(['/iCloud/wallet/wallet-list']);
  }

  getCourseList() {
    this._router.navigate(["/iCloud/course/course-list"]);
  }

  getMail() {
    this._router.navigate(["/iCloud/mail/franchisee-mail"]);
  }

  getMaterial() {
    this._router.navigate(['/iCloud/indent/indent-list']);
  }

  getBatch() {
    this._router.navigate(['/iCloud/batch/batch-list']);
  }

  getCurrentStudent() {
    this._router.navigate(['/iCloud/student/student-list']);
  }

  getAlumunsList() {
    this._router.navigate(["/iCloud/student/alumnus"]);
  }

  getFeesBalance() {
    this._router.navigate(["/iCloud/fees/balance-list"]);
  }

  getExamIndent() {
    this._router.navigate(["/iCloud/indent/exam-indent"]);
  }

  getMarksheet() {
    this._router.navigate(["/iCloud/indent/ceritificate-mis"]);
  }
  
  getCertificate() {
    this._router.navigate(["/iCloud/indent/ceritificate-mis"]);
  }
}
