import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  public franchiseeDashboardUrl = "/icloud-franchisee/v1/franchisee/dashboard";
  constructor(public http_service: HttpService) { }
  getFranchiseeDashboard() {
    return this.http_service.get(this.franchiseeDashboardUrl, { RequestType: IRequestType.Protected });
  }
}
