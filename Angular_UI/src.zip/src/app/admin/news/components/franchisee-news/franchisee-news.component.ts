import { Component } from '@angular/core';
import { FranchiseeNews } from '../../model/news';
import { NewsService } from '../../service/news.service';
import { IWebError } from 'src/core/model';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CustomNotification } from 'src/app/shared/model/shared';

@Component({
  selector: 'franchisee-news',
  templateUrl: './franchisee-news.component.html',
  styleUrls: ['./franchisee-news.component.scss']
})

export class FranchiseeNewsComponent {

  /* Model */
  public MlFranchiseeNews: FranchiseeNews = new FranchiseeNews();

  constructor(private _srvNews: NewsService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this._srvNews.getFranchiseeNews().subscribe({
      next: (res: any) => {
        if (res.Data) this.MlFranchiseeNews = res.Data
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }
}
