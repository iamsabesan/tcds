import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { EditNews, CreateNews, NewsList } from '../../model/news';
import { NewsService } from '../../service/news.service';
import { IWebError } from 'src/core/model';
import { PageChangeEvent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.scss']
})

export class NewsListComponent {

  /* List */
  public LstNews: NewsList[] = [];

  /* Model */
  public MlCreateNews: CreateNews = new CreateNews();
  public MlEditNews: EditNews = new EditNews();

  /* Grid Filter */
  public filter: CompositeFilterDescriptor;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('medium');

  /* Dialog */
  public createNews: boolean = false;

  /* Check 'CREATE' OR 'EDIT' Status */
  public IsCheckStatus: string = "";

  /* Check Show On Startup */
  public IsShowOnStartUp: boolean = false;

  /* Pagination */
  public buttonCount = 5;
  public pageSize: number = 15;
  public skip: number = 0;
  public sizes: any[] = [15, 25, 50, 100, "All"];

  /* Form Group */
  FrmEntry = new FormGroup({
    titles: new FormControl(null, [Validators.required]),
    content: new FormControl(null, [Validators.required]),
    showStartup: new FormControl(null),
  });

  constructor(private _srvNotification: NotificationService, private _srvNews: NewsService) { }

  ngOnInit() {
    this.MlCreateNews.showOnStartUp = false;
    this.getNewsList();
  }

  /* Get News List */
  getNewsList() {
    this._srvNews.getNewsList().subscribe({
      next: (e) => this.LstNews = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Show On StartUp  */
  modeSwitcher(event: boolean) {
    this.IsShowOnStartUp = event;
  }

  /* Page Change Event */
  pageEvent(event: PageChangeEvent) {
    this.pageSize = event.take
    this.skip = event.skip;
  }

  /* Post New News */
  newNews() {
    this.createNews = true;
    this.IsCheckStatus = 'createNews';
  }

  /* Close Dialog */
  btnCancel() {
    this.createNews = false;
    this.FrmEntry.reset();
  }

  /* Reset the Form Data */
  btnReset() {
    if (this.IsCheckStatus == 'createNews') this.FrmEntry.reset();
    else this.editNews(this.MlEditNews);
  }

  /* Edit Event */
  editNews(event: NewsList) {
    this.MlEditNews = event;
    this.IsCheckStatus = 'editNews';
    this.MlEditNews.NewsListID = event.NewsListID;
    this.FrmEntry.controls['titles'].setValue(event.Title);
    this.FrmEntry.controls['content'].setValue(null);
    this.FrmEntry.controls['content'].setValue(event.NewsContent);
    this.IsShowOnStartUp = event.ShowOnStartUp;
    this.createNews = true;
  }

  /* Post the News */
  postNews(data: any) {
    if (!this.FrmEntry.valid) this.FrmEntry.markAllAsTouched();
    else {
      if (this.IsCheckStatus === 'createNews') {
        this.MlCreateNews.newsContent = data.content;
        this.MlCreateNews.title = data.titles;
        this.MlCreateNews.showOnStartUp = this.IsShowOnStartUp;

        this._srvNews.postNewNews(this.MlCreateNews).subscribe({
          next: (e: any) => {
            new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
            this.btnCancel();
            this.getNewsList();
          },
          error: (err: IWebError) => this.errorMsg(err.Message)
        });
      }

      else if (this.IsCheckStatus === 'editNews') {
        this.MlEditNews.NewsContent = data.content;
        this.MlEditNews.Title = data.titles;
        this.MlEditNews.ShowOnStartUp = this.IsShowOnStartUp;

        this._srvNews.postEditNews(this.MlEditNews).subscribe({
          next: (e: any) => {
            new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
            this.btnCancel();
            this.getNewsList();
          },
          error: (err: IWebError) => this.errorMsg(err.Message)
        });
      }
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
