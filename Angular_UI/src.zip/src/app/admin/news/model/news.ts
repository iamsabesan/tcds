
/* Post a New News */
export class CreateNews {
    title: string = '';
    newsContent: string = '';
    showOnStartUp: boolean;
}

/* Already Post a News Edit */
export class EditNews {
    NewsListID: string = "";
    Title: string = "";
    NewsContent: string = "";
    ShowOnStartUp: boolean;
}

/* News List */
export class NewsList {
    NewsListID: string = '';
    Date?: string = '';
    Title: string = '';
    NewsContent: string = '';
    ShowOnStartUp: boolean = false;
}

/* Franchisee News */
export class FranchiseeNews {
    NewsListID: string = '';
    Title: string = '';
    NewsContent: string = '';
}