import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { NewsService } from './service/news.service';
import { NewsComponent } from './news.component';
import { NewsListComponent } from './components/news-list/news-list.component';
import { EditorModule } from '@progress/kendo-angular-editor';
import { FranchiseeNewsComponent } from './components/franchisee-news/franchisee-news.component';
const routes: Routes = [
    {
        path: '',
        component: NewsComponent,
        children: [
            {
                path: 'news-list',
                component: NewsListComponent,
            },
            {
                path: 'franchisee-news',
                component: FranchiseeNewsComponent,
            },
        ]
    }
];

@NgModule({
    declarations: [
        NewsComponent,
        NewsListComponent,
        FranchiseeNewsComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        FormsModule,
        ReactiveFormsModule,
        GridModule,
        LabelModule,
        DialogsModule,
        EditorModule
    ],
    providers: [NewsService]
})
export class NewsModule { }
