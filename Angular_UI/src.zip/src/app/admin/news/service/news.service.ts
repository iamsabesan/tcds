import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { CreateNews, EditNews } from '../model/news';

@Injectable({
  providedIn: 'root'
})
export class NewsService {

  constructor(private _srvHttp: HttpService) { }

  /* Get Admin News List */
  getNewsList() {
    return this._srvHttp.get("/news/v1/news/list", { RequestType: IRequestType.Protected })
  }

  /* Post the New News */
  postNewNews(postNews: CreateNews) {
    return this._srvHttp.post("/news/v1/news/create", postNews, { RequestType: IRequestType.Protected })
  }

  /* Already Post a News Edit */
  postEditNews(editNews: EditNews) {
    return this._srvHttp.post("/news/v1/news/edit", editNews, { RequestType: IRequestType.Protected })
  }

  /* Get Franchisee News */
  getFranchiseeNews() {
    return this._srvHttp.get("/news/v1/news/byfranchisee", { RequestType: IRequestType.Protected })
  }
} 
