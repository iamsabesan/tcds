import { Component } from '@angular/core';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { aggregateBy, AggregateDescriptor, AggregateResult, CompositeFilterDescriptor, State, process, GroupDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, DropDownFilter, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { AllMaterialListDataType } from 'src/app/shared/model/common';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { materialData, materialFlowReportDataType, materialFlowSearchDataType } from '../../model/purchase';
import { PurchaseService } from '../../services/purchase.service';
import { materialFlowModel } from '../purchase-invoice/model/purchase-invoice';
import { IntlService } from '@progress/kendo-angular-intl';

@Component({
  selector: 'material-flow-report',
  templateUrl: './material-flow-report.component.html',
  styleUrls: ['./material-flow-report.component.scss']
})
export class MaterialFlowReportComponent {

  /* List */
  public MlMaterialFlowSearchValue: materialFlowSearchDataType = new materialFlowSearchDataType();
  public LstMaterialFlowreport: materialFlowReportDataType[] = [];
  public LstMaterial: AllMaterialListDataType[] = [];

  /* Model */
  public materialFlowModel: materialFlowModel = new materialFlowModel()
  public MlMaterial: materialData = new materialData()
  public gridStyle = new gridFontStyle();
  public dateStyle = new DateSize('medium');
  public MlDateRange: DateRanges = new DateRanges();

  /* Grid Data Filter */
  public filter!: CompositeFilterDescriptor;
  public aggregates!: AggregateDescriptor[];
  public group: GroupDescriptor[] = [];
  public gridData!: GridDataResult;
  public total!: AggregateResult;
  public state: State;
  // public state: State = {
  //   skip: 0,
  //   filter: { logic: "and", filters: [], },
  // };


  public dateSelected: any;

  /* Is Show Footer */
  public IsShowFooterTotalAmount: boolean;

  /* Date */
  public dateWholePeriod!: boolean;
  public quantity: number = 0;
  public WholePerStrDate: Date;

  /* All Checkbox */
  public isChecked = false;
  public value: any[] = [];

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Currency Symbol */
  public currencySymbol: string = '';

  /* Grid Pagination */
  public buttonCount: number = 5;
  public skip: number = 0;
  public pageSize: number = 15;
  public sizes: number[] = [15, 25, 50, 100];

  constructor(private _srvNotification: NotificationService, public intlService: IntlService,
    private _srvPurchase: PurchaseService, private _srvCommon: CommonService) {
    _srvCommon.getWholePeriodDate(LocalString.TenantBranchID).subscribe({
      next: (val) => {
        this.dateWholePeriod = false;
        if (val.Data !== "") {
          this.dateWholePeriod = true;
          this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
        }
      }
    });
  }
  ngOnInit() {
    this.dateWholePeriod = true;
    this.currencySymbol = LocalString.CurrencySymbol;
    this.getMaterialList();
  }

  /* Get Material List */
  getMaterialList() {
    this._srvCommon.getAllMateraialList().subscribe({
      next: (e) => this.LstMaterial = e.Data,
      error: (err) => this.errorMsg(err.Message)
    });
  }

  /* Grid Filter Record Dynamic Change Total Amount */
  dataStateChange(state: DataStateChangeEvent) {
    this.state = state;
    this.gridData = process(this.LstMaterialFlowreport, this.state);
    this.IsShowFooterTotalAmount = false;
    if (this.gridData.data.length !== 0) {
      this.total = aggregateBy(this.gridData.data, this.aggregates);
      this.IsShowFooterTotalAmount = true;
    }
  }

  /* Group Filter */
  onGroupChange(group: GroupDescriptor[]) {
    group.map((group) => (group.aggregates = this.aggregates));
    this.group = group;
    // if (group.length !== 0) this.IsShowFooterTotalAmount = true;
    this.IsShowFooterTotalAmount = (group.length == 0 && this.gridData.data.length !== 0) ? true : false;
    // this.gridData.data = groupBy(this.LstMaterialFlowreport, this.group);
    // this.quantity = this.LstMaterialFlowreport.reduce((sum: any, current: any) => sum + current.PurchaseQuantity, 0);
  }

  /* Date Selected */
  dateChange(event: any) {
    this.MlDateRange = event;
  }

  /* Intermediate Checkbox */
  public get isIndet() {
    return this.value.length !== 0 && this.value.length !== this.LstMaterial.length;
  }

  /* One by one multiselect */
  isItemSelected(item: any) {
    return this.value.some((e: any) => e.MaterialID === item.MaterialID);
  }

  /* All Select */
  onClick() {
    this.isChecked = !this.isChecked;
    this.value = this.isChecked ? this.LstMaterial.slice() : [];
    if (!this.isChecked) this.MlMaterialFlowSearchValue.materials = [];
    else {
      this.MlMaterialFlowSearchValue.materials = [];
      this.LstMaterial.forEach((e: any) => {
        this.MlMaterial = new materialData();
        this.MlMaterial.materialID = e.MaterialID;
        this.MlMaterialFlowSearchValue.materials.push(this.MlMaterial)
      });
    }
  }

  /* Checkbox Change Event */
  onValueChange() {
    this.isChecked = this.value.length === this.LstMaterial.length;
  }

  /* Checkbox Event Change */
  MaterialValue(data: any) {
    if (data.length > 0) {
      this.MlMaterialFlowSearchValue.materials = [];
      data.forEach((e: any) => {
        this.MlMaterial = new materialData();
        this.MlMaterial.materialID = e.MaterialID;
        this.MlMaterialFlowSearchValue.materials.push(this.MlMaterial)
      });
    }
    else if (data.length === 0) this.MlMaterialFlowSearchValue.materials = [];
  }

  /* Get Material Flow Report */
  getMaterialFlowReport(data: materialFlowSearchDataType) {
    this._srvPurchase.getMaterialFlowReport(data).subscribe({
      next: (e) => {
        this.LstMaterialFlowreport = e.Data;
        this.IsShowFooterTotalAmount = false;
        if (this.LstMaterialFlowreport.length !== 0) {
          this.IsShowFooterTotalAmount = true;
          this.aggregates = [{ field: "PurchaseQuantity", aggregate: "sum" }, { field: "PurchaseAmount", aggregate: "sum" }, { field: "SalesQuantity", aggregate: "sum" }, { field: "SalesAmount", aggregate: "sum" }];
          this.total = aggregateBy(this.LstMaterialFlowreport, this.aggregates)
        }
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  search() {
    if (this.MlDateRange.startDate == null || this.MlDateRange.endDate == null) this.errorMsg("Please fill the dates");
    else if (this.MlMaterialFlowSearchValue.materials.length == 0) this.errorMsg("Please select atleast one material");
    else {
      this.MlMaterialFlowSearchValue.fromDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.startDate);
      this.MlMaterialFlowSearchValue.toDate = DateConversion.ConvertMonthDateYear(this.MlDateRange.endDate);
      this.getMaterialFlowReport(this.MlMaterialFlowSearchValue);
    }
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}

