import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DateConversion, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { materialInwardsDataType, materialType, purchaseCreate, PurchaseInvoiceCreate, purchaseInvoiveCreate, purchaseSummary, vendorBasicInfoDataType } from '../../model/purchase-invoice';
import { PurchaseInvoiceService } from '../../services/purchase-invoice.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-purchase-invoice-create',
  templateUrl: './purchase-invoice-create.component.html',
  styleUrls: ['./purchase-invoice-create.component.scss']
})
export class PurchaseInvoiceCreateComponent {

  /* List */
  public materialType: materialType[] = [];
  public vendorInfo: vendorBasicInfoDataType[] = [];
  public vendor: vendorBasicInfoDataType[] = [];
  public materials: materialInwardsDataType[] = [];

  /* Model */
  public purchaseDatas: purchaseCreate = new purchaseCreate();
  public purchaseCreates: PurchaseInvoiceCreate = new PurchaseInvoiceCreate();
  public purchaseInvoiceCreateData: purchaseInvoiveCreate = new purchaseInvoiveCreate();
  public purchaseMaterial: materialInwardsDataType = new materialInwardsDataType();

  public currencySymbol: string = '';
  public totals: number = 0;

  /* Sum Calculation */
  public decimals: number = 0;
  public value: number = 0;
  public dateFormat: string = '';
  public discountValue = 0;
  public totalGST = 0;
  public roundOFF = 0;
  public NameNumericPattern = /^(?=.*[a-zA-Z])[a-zA-Z0-9 .,()\s-]+$/;

  public min: Date = new Date();
  vendorPurchase = new FormGroup({
    vendor: new FormControl(null, [Validators.required]),
    invoiceNo: new FormControl(null, [Validators.required]),
    invoiceDate: new FormControl(null, [Validators.required])
  })
  constructor(public service: PurchaseInvoiceService, public intlService: IntlService, private _srvNotification: NotificationService) { }
  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.min = new Date(new Date().getFullYear() - 1, new Date().getMonth(), new Date().getDate());
    this.getMaterialata()
    this.vendorBasicList()
  }

  vendorBasicList() {
    this.service.getVendorBasicInfo().subscribe({
      next: (e) => {
        this.vendorInfo = this.vendor = e.Data;
      },
      error: (err) => {
        new CustomNotification(this._srvNotification).ShowError(err.Message);
      }
    })
  }

  getMaterialata() {
    this.service.getMaterialTypeListandMaterial().subscribe({
      next: (e) => {
        this.materialType = e.Data;
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    })
  }

  public vendorFilter(searchTerm: string): void {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.TenantBranch.toLowerCase().includes(normalizedQuery) ||
      data.ContactName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery) ||
      data.SourceSupply.toLowerCase().includes(normalizedQuery);

    this.vendorInfo = this.vendor.filter(filterExpression);
  }


  addNew() {
    this.purchaseDatas.purchaseData.push(this.purchaseCreates);
    this.purchaseCreates = new PurchaseInvoiceCreate();
  }

  materialTypes(event: any, index: number) {
    if (!event) {
      this.purchaseDatas.purchaseData[index].materialName = "";
      this.purchaseDatas.purchaseData[index] = new PurchaseInvoiceCreate();
      // this.purchaseCreates.materialItem = [];
    }
    else this.purchaseDatas.purchaseData[index].material = event.Materials;
  }

  materialName(event: any, index: number) {
    if (!event) {
      this.purchaseDatas.purchaseData[index].price = 0;
      this.purchaseDatas.purchaseData[index].gstPercent = 0;
      this.purchaseDatas.purchaseData[index].quantity = 0;
    }
    else {
    }
  }

  /* Price Change Event */
  priceEvent(price: number, index: number) {
    if (price) {
      this.purchaseDatas.purchaseData[index].price = price;
    }
  }


  deletes(i: number) {
    this.purchaseDatas.purchaseData.splice(i, 1);
  }
  goBack() {
    this.service.purchase.next({ Mode: 'list' })
  }
  reset() {
    this.vendorPurchase.reset();
    this.purchaseDatas = new purchaseCreate();
    this.purchaseDatas.purchaseData.length = 0;
  }
  save(data: any) {
    var purchaseEntryValue: any = this.vendorPurchase.value
    this.materials = []
    const validation = this.purchaseDatas.purchaseData.every(item => item.materialType && item.materialName && item.quantity && item.price);
    if (!this.vendorPurchase.valid) {
      this.vendorPurchase.markAllAsTouched();
    }
    else if (this.purchaseDatas.purchaseData.length > 0) {
      if (validation) {
        this.purchaseInvoiceCreateData.vendorID = purchaseEntryValue.vendor.ContactID;
        this.purchaseInvoiceCreateData.invoiceNo = String(purchaseEntryValue.invoiceNo);
        this.purchaseInvoiceCreateData.invoiceDate = DateConversion.ConvertMonthDateYear(purchaseEntryValue.invoiceDate);
        this.purchaseInvoiceCreateData.materialInwards = [];
        data.purchaseData.filter((e: any) => {
          this.purchaseMaterial = new materialInwardsDataType();
          this.purchaseMaterial.materialID = e.materialName.MaterialID;
          this.purchaseMaterial.quantity = e.quantity;
          this.purchaseMaterial.price = e.price;
          this.purchaseMaterial.gst = e.gstPercent;
          this.purchaseInvoiceCreateData.materialInwards.push(this.purchaseMaterial)
        });
        this.purchaseInvoiceCreateData.notes = data.notes;

        if (this.discountValue >= 0 && this.totalGST >= 0) {
          this.service.postPurchaseCreate(this.purchaseInvoiceCreateData).subscribe({
            next: (e) => {
              new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
              this.service.purchase.next({ Mode: 'list' })
            },
            error: (err) => this.errorMsg(err.Message)
          })
        }
        else this.errorMsg('Please fill the correct details');
      }
      else this.errorMsg('Please fill material details')
    }
    else if (this.purchaseDatas.purchaseData.length == 0) this.errorMsg('Minimum One purchase must be added');
  }
  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

  get _summary(): purchaseSummary {
    const summary = new purchaseSummary();

    this.purchaseDatas.purchaseData.forEach((po) => {
      const GstAmt = parseFloat((((po.price * po.gstPercent) / 100) * po.quantity).toFixed(2));
      po.totalDiscountAmount = GstAmt;
      summary.gst = summary.gst + GstAmt
      po.beforeDiscount = parseFloat((po.price * po.quantity).toFixed(2));
      po.total = parseFloat((GstAmt + (po.price * po.quantity)).toFixed(2));
      summary.subTotal = summary.subTotal + parseFloat((po.price * po.quantity).toFixed(2));
    })

    if (summary.subTotal == 0) this.discountValue = this.roundOFF = 0;

    summary.afterDiscount = summary.subTotal - this.discountValue;
    summary.total = summary.afterDiscount + this.roundOFF + this.totalGST;
    // summary.total = summary.afterDiscount + this.roundOFF + summary.subTotal + this.totalGST;

    this.purchaseInvoiceCreateData.amount = summary.subTotal;
    this.purchaseInvoiceCreateData.discount = this.discountValue;
    this.purchaseInvoiceCreateData.gst = this.totalGST;
    this.purchaseInvoiceCreateData.roundOff = this.roundOFF;

    return summary;
  }
}
