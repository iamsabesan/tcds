import { Component, ViewChild } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { DateConversion, DateSize, gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { DateRanges } from 'src/app/shared/model/date-ranges';
import { CustomNotification } from 'src/app/shared/model/shared';
import { purchaseInvoiceDataType } from '../../model/purchase-invoice';
import { PurchaseInvoiceService } from '../../services/purchase-invoice.service';
import { DateRangesComponent } from 'src/app/shared/components/date-ranges/date-ranges.component';
import { PageChangeEvent } from '@progress/kendo-angular-grid';
import { CommonService } from 'src/app/shared/service/common.service';

@Component({
  selector: 'app-purchase-invoice-list',
  templateUrl: './purchase-invoice-list.component.html',
  styleUrls: ['./purchase-invoice-list.component.scss'],
})
export class PurchaseInvoiceListComponent {
  /* View Child */
  @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

  filter!: CompositeFilterDescriptor;
  public gridStyle = new gridFontStyle('medium');
  public dateStyle = new DateSize('medium');
  public gridView: purchaseInvoiceDataType[] = [];
  public currencySymbol: string = '';

  /* DateRange */
  public MlDateValue: DateRanges = new DateRanges();
  public dateWholePeriod!: boolean;
  public buttonCount = 5;
  skip = 0;
  pageSize = 15;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  WholePerStrDate: Date;
  constructor(private _srvPurchaseInvoice: PurchaseInvoiceService, private _srvNotification: NotificationService, public _srvCommon: CommonService) {
    const tenentBranchid = LocalString.TenantBranchID;
    _srvCommon.getWholePeriodDate(tenentBranchid).subscribe({
      next: (val) => {
        this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
      }
    })
  }

  ngOnInit() {
    this.dateWholePeriod = true;
    this.currencySymbol = LocalString.CurrencySymbol;
    this.MlDateValue = this._srvPurchaseInvoice.MlDateRange;

    this.getPurchaseList()

    // if (this._srvPurchaseInvoice.listPageSize && this._srvPurchaseInvoice.listPageSkip) {
    this.pageSize = this._srvPurchaseInvoice.listPageSize;
    this.skip = this._srvPurchaseInvoice.listPageSkip;
    // }
  }
  ngAfterViewInit() {
    setTimeout(() => {
      if (this.MlDateValue.duration && this.dateRanges.dateData) {
        this.dateRanges.dateData.forEach(e => {
          if (e.value == this._srvPurchaseInvoice.MlDateRange.duration) {
            this.dateRanges.selectedValue = e;
            this.dateRanges.getDate(e);
          }
        })
      }
    });
  }

  getPurchaseList() {
    var fromDate = DateConversion.ConvertMonthDateYear(this.MlDateValue.startDate)
    var toDate = DateConversion.ConvertMonthDateYear(this.MlDateValue.endDate)

    this._srvPurchaseInvoice.getPurchaseInvoice(fromDate, toDate).subscribe({
      next: (e) => {
        // e.Data.forEach((e: any) => e.MaterialPurchase.InvoiceDate = new Date(e.MaterialPurchase.InvoiceDate.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3")))
        this.gridView = e.Data;
      }, error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    })
  }

  newPurchase() {
    this._srvPurchaseInvoice.listPageSize = this.pageSize;
    this._srvPurchaseInvoice.listPageSkip = this.skip;
    this._srvPurchaseInvoice.MlDateRange = this.MlDateValue;
    this._srvPurchaseInvoice.purchase.next({ Mode: 'create' });
  }

  view(data: any) {
    this._srvPurchaseInvoice.listPageSize = this.pageSize;
    this._srvPurchaseInvoice.listPageSkip = this.skip;
    this._srvPurchaseInvoice.MlDateRange = this.MlDateValue;
    this._srvPurchaseInvoice.purchase.next({ Mode: 'view', data: data });
  }

  dateChange(event: any) {
    this.MlDateValue = event;
  }

  filters() {
    if (!this.MlDateValue.startDate && !this.MlDateValue.endDate) new CustomNotification(this._srvNotification).ShowError("Please fill the details");
    else this.getPurchaseList()
  }

  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.pageSize = event.take;
    // Add any additional logic if needed
  }

}


