import { Component } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { CookieService } from 'ngx-cookie-service';
import { LocalString } from 'src/app/shared/app-global';
import { CookieKey } from 'src/core/helper/CookieKey.model';
import { PurchaseDetailView, PurchaseHeaderDetail, purchaseInvoiceDataType } from '../../model/purchase-invoice';
import { PurchaseInvoiceService } from '../../services/purchase-invoice.service';
import { LayoutComponent } from 'src/app/layouts/layout.component';

@Component({
  selector: 'app-purchase-invoice-view',
  templateUrl: './purchase-invoice-view.component.html',
  styleUrls: ['./purchase-invoice-view.component.scss']
})
export class PurchaseInvoiceViewComponent {
  public currencySymbol: string = '';
  // gridView: PurchaseDetailView[] = purchaseView;
  gridView: PurchaseDetailView[] = [];
  public purchaseHeader: PurchaseHeaderDetail = new PurchaseHeaderDetail();
  public purchaseInvoiceDetails: purchaseInvoiceDataType = new purchaseInvoiceDataType();
  public matPurID = '';
  // public purchaseInfo : PurchaseInfo = new PurchaseInfo();
  public totalAmount = 0;
  public totalGST = 0;
  public aftergstCalculation = 0;
  public discount = 100;
  public dateFormate: string = "";
  public getScreenHeight: any;
  public getScreenWidth: any;
  public viewerContainerStyle: any;
  public ServerUrl: any;
  public opened = false;
  public Reportsource: any;
  public title: string = '';
  public bearerToken = "";
  constructor(public service: PurchaseInvoiceService, public intlService: IntlService, private _srvCookie: CookieService, private layout: LayoutComponent) {

  }
  ngOnInit() {
    // this.purchaseHeader = purchaseViewDetail;
    this.purchaseHeader = new PurchaseHeaderDetail();
    this.currencySymbol = LocalString.CurrencySymbol;
    this.totalAmount = this.gridView.reduce((sum: any, current: any) => sum + current.amount, 0);
    // this.discount =  this.totalAmount - 100;
    this.service.purchase.subscribe((res: any) => {
      
      this.purchaseInvoiceDetails = res.data;
      this.matPurID = res.data.MaterialPurchase.MaterialPurchaseID
    })
    this.gridView.forEach((res: any) => {
      res.gstAmount = res.amount * res.gst / 100;
    })
    this.totalGST = this.gridView.reduce((sum: any, current: any) => sum + current.gstAmount, 0);
    this.aftergstCalculation = this.totalAmount - this.discount;

    this.viewerContainerStyle = this.layout.viewerContainerStyle;
    this.bearerToken = this._srvCookie.get(CookieKey.Api);
    this.ServerUrl = this.layout.ServerUrl;
    this.getScreenHeight = window.innerHeight;
  }
  back() {
    this.service.purchase.next({ Mode: 'list' })
  }
  public close(): void {
    this.opened = false;
  }
  PurPrint() {
    this.title = 'Purchase Invoice'
    this.Reportsource = {
      report: 'iCloud/PurchaseInvoice',
      parameters: {
        Authorization: this.bearerToken, Agent: window.navigator.userAgent, materialPurchaseID: this.matPurID
      }
    };
    this.opened = true;
  }
}
