import { dateRange } from "src/app/shared/model/info.model";

export class PurchaseInvoice {
    Mode = 'list' || 'create' || 'view';
    data?: purchaseInvoiceDataType;
}

export class PurchaseInfo {
    id!: number;
    invoiceDate: any;
    invoiceNo!: number;
    vendor: string = '';
    gst!: number;
    amount!: number;
    purchaseData: PurchaseInvoiceCreate[] = []
}
export class PurchaseInvoiceList {
    id!: number;
    invoiceDate: any;
    invoiceNo!: number;
    vendor: string = '';
    gst!: number;
    amount!: number;
}


export class PurchaseDetailView {
    materialName: string = '';
    quantity: number = 0;
    unitPrice: number = 0;
    gst: number = 0;
    amount: number = 0;
    gstAmount: number = 0;
    discount: number = 0;
}

export class PurchaseHeaderDetail {
    vendorName: string = '';
    invoiceNo: string = '';
    date: any;
    doorNo: number = 0;
    street: string = '';
    area: string = '';
    city: string = '';
    state: string = '';
    country: string = '';
    pincode: number = 0;
    phoneNo: string = '';
    email: string = '';
}

export class materialFlowModel {
    material: any;
    text: string = "";
    value: number = 0;
    dateRange?: dateRange
}

//#region  Purchase List 
export class purchaseInvoiceDataType {
    BranchDetail: purchaseInvoiceBranchDetail = new purchaseInvoiceBranchDetail();
    MaterialPurchase: purchaseInvoiceMaterialPurchase = new purchaseInvoiceMaterialPurchase()
    MaterialPurchaseTrans: purchaseInvoiceMaterialPurchasetrans[] = [];
}

export class purchaseInvoiceBranchDetail {
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
}

export class purchaseInvoiceMaterialPurchase {
    MaterialPurchaseID: string = '';
    InvoiceNo: string = '';
    InvoiceDate: string = '';
    GST: number = 0;
    Amount: number = 0;
    SubTotal: number = 0;
    Discount: number = 0;
    AfterDiscount: number = 0;
    RoundOff: number = 0;
    Notes: string = '';
    VendorName: string = "";
    TotalAmount: number = 0;
}

export class purchaseInvoiceMaterialPurchasetrans {
    MaterialPurchaseID: string = '';
    MaterialName: string = '';
    Quantity: number = 0;
    UnitPrice: number = 0;
    GST: number = 0;
    GSTAmount = 0;
    Amount: number = 0;
    TotalAmount = 0;
}
//#endregion

//#region  Create a New Purchase 
export class purchaseCreate {
    notes: string = '';
    purchaseData: PurchaseInvoiceCreate[] = []
}

export class PurchaseInvoiceCreate {
    id!: number;
    materialType: string = '';
    materialName: string = '';
    quantity: number = 0;
    price: number = 0;
    gstPercent: number = 0;
    gstAmount = 0;
    total: number = 0;
    beforeTotal = 0;
    beforeDiscount: number = 0;
    afterDiscount: number = 0;
    roundOffAmount: number = 0;
    totalAmount: number = 0;
    totalGST: number = 0;
    materialItem: any[] = [];
    material: materialDataType[] = [];
    totalDiscountAmount = 0;
}
//#endregion


export class materialType {
    MaterialTypeID: string = '';
    MaterialType: string = '';
    Materials: materialDataType[] = [];
}

export class materialDataType {
    MaterialTypeID: string = '';
    MaterialID: string = '';
    MaterialName: string = '';
    Price: number = 0;
    GST: number = 0;
}

/* Vendor Detail */
export class vendorBasicInfoDataType {
    ContactID: string = "";
    ContactName: string = "";
    TenantBranch: string = "";
    PhoneCode: string = "";
    Phone: string = "";
    Email: string = "";
    VendorType: string = "";
    CompanyName: string = "";
    PanNumber: string = "";
    TDS: number = 0;
    SourceSupply: string = "";
    GSTTreatmentName: string = "";
    GSTTreatmentID: string = "";
}

export class purchaseInvoiveCreate {
    vendorID: string = '';
    invoiceNo: string = '';
    invoiceDate: string = '';
    materialInwards: materialInwardsDataType[] = [];
    amount: number = 0;
    discount: number = 0;
    gst: number = 0;
    roundOff: number = 0;
    notes: string = '';
}
export class materialInwardsDataType {
    materialID: string = '';
    quantity: number = 0;
    price: number = 0;
    gst: number = 0;
}

export class purchaseSummary {
    subTotal = 0;
    discount = 0;
    afterDiscount = 0;
    gst = 0;
    roundoff = 0;
    total = 0;
}

