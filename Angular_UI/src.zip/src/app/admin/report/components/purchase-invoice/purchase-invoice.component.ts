import { Component } from '@angular/core';
import { PurchaseInvoiceService } from './services/purchase-invoice.service';
@Component({
  selector: 'app-purchase-invoice',
  templateUrl: './purchase-invoice.component.html',
  styleUrls: ["./purchase-invoice.component.scss"],
  providers: [PurchaseInvoiceService]
})
export class PurchaseInvoiceComponent{
  actions = '';
  constructor(public service :PurchaseInvoiceService)
  {
    service.purchase.subscribe((res :any)=>{
      this.actions = res.Mode;
    })
  }
}
