import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogModule, DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { PurchaseInvoiceService } from './services/purchase-invoice.service';
import { PurchaseInvoiceComponent } from './purchase-invoice.component';
import { PurchaseInvoiceListComponent } from './components/purchase-invoice-list/purchase-invoice-list.component';
import { PurchaseInvoiceCreateComponent } from './components/purchase-invoice-create/purchase-invoice-create.component';
import { PurchaseInvoiceViewComponent } from './components/purchase-invoice-view/purchase-invoice-view.component';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { PipeModule } from "../../../../pipes/pipe.module";
const routes: Routes = [
    {
        path: '',
        component: PurchaseInvoiceComponent,
        children: [
            {
                path: 'purchase-invoice-list',
                component: PurchaseInvoiceListComponent,
            },
            {
                path: 'purchase-invoice-create',
                component: PurchaseInvoiceCreateComponent,
            },
            {
                path: 'purchase-invoice-view',
                component: PurchaseInvoiceViewComponent
            },
        ]
    }
];

@NgModule({
    declarations: [
        PurchaseInvoiceComponent,
        PurchaseInvoiceListComponent,
        PurchaseInvoiceCreateComponent,
        PurchaseInvoiceViewComponent
    ],
    providers: [PurchaseInvoiceService],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        ReactiveFormsModule,
        DateInputModule,
        PopupModule,
        GridModule,
        LabelModule,
        DialogsModule,
        DateInputsModule,
        DateRangesModule,
        DialogModule,
        TelerikReportingModule,
        PipeModule
    ]
})
export class PurchaseInvoiceModule { }
