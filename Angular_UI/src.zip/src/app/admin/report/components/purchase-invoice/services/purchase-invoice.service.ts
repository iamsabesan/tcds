import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { PurchaseInvoice, purchaseInvoiveCreate } from '../model/purchase-invoice';
import { DateRanges } from 'src/app/shared/model/date-ranges';

@Injectable({
  providedIn: 'root'
})

export class PurchaseInvoiceService {
  public purchase = new BehaviorSubject<PurchaseInvoice>({ Mode: 'list' });

  public MlDateRange: DateRanges = new DateRanges();
  public listPageSize: any = 15;
  public listPageSkip: any = 0;
  constructor(private _srvHttp: HttpService) { }

  /* Get Date Wise Purchase Order List */
  getPurchaseInvoice(fromDate: string, toDate: string) {
    return this._srvHttp.get('/icloud-inventory/v1/indent/purchase/invoice/list', { params: { fromDate, toDate }, RequestType: IRequestType.Protected });
  }

  getMaterialTypeListandMaterial() {
    return this._srvHttp.get('/icloud-inventory/v1/material/types/materials', { RequestType: IRequestType.Protected })
  }

  /* Get Vendor List */
  getVendorBasicInfo() {
    return this._srvHttp.get('/user-service/user/vendor-list', { RequestType: IRequestType.Protected });
  }

  /* Create a New Purchase */
  postPurchaseCreate(data: purchaseInvoiveCreate) {
    return this._srvHttp.post('/icloud-inventory/v1/indent/material/purchase/invoice', data, { RequestType: IRequestType.Protected })
  }
}
