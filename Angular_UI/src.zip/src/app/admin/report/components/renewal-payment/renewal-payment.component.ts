import { Component } from '@angular/core';
import { DetailExpandEvent } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle, LocalString } from 'src/app/shared/app-global';
import { CustomNotification } from 'src/app/shared/model/shared';
import { franchiseeRenewalPaymentListDataType, ExpandedRow } from '../../model/purchase';
import { PurchaseService } from '../../services/purchase.service';
import { IWebError } from 'src/core/model';


@Component({
  selector: 'app-renewal-payment',
  templateUrl: './renewal-payment.component.html',
  styleUrls: ['./renewal-payment.component.scss']
})
export class RenewalPaymentComponent {

  /* List */
  public LstFranchiseeRenewalPayment: franchiseeRenewalPaymentListDataType[] = [];

  /* Currency Symbol */
  public currencySymbol = '';

  /* Grid Filter & Expand */
  public filter!: CompositeFilterDescriptor;
  public totalValue: any[] = [];
  public expandedDetailKeys = ExpandedRow.SubjectExpanded;
  public gridStyle: gridFontStyle = new gridFontStyle('medium');
  public totalAmount: number;

  public buttonCount = 5;
  public pageSize: number = 15;
  public skip: number = 0;
  public sizes: any[] = [15, 25, 50, 100, "All"];

  constructor(private _srvPurchase: PurchaseService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.currencySymbol = LocalString.CurrencySymbol;
    this._srvPurchase.getfranchiseeRenewalPaymentList().subscribe({
      next: (e) => {
        this.LstFranchiseeRenewalPayment = e.Data;
        this.LstFranchiseeRenewalPayment.filter((e: any) => {
          if (e.Address2 !== "" || null) {
            e.Address = e.Address1 + ", " + e.Address2 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
          } else {
            e.Address = e.Address1 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
          }
          e.total = e.PaymentDetails.reduce((sum: any, current: any) => sum + current.Amount, 0);
        });
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  detailExpand(data: DetailExpandEvent) {
    this.totalValue = data.dataItem.PaymentDetails;
  }

  expandDetailsBy = (dataItem: franchiseeRenewalPaymentListDataType): string => {
    return dataItem.PackageLogID;
  }
}