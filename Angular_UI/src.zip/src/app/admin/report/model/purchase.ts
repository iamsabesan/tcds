import { PaymentDetailViewListMl } from "src/app/shared/model/common";

export class ExpandedRow {
    static SubjectExpanded: string[] = [];
}

//#region  Material Flow Report 
export class materialFlowReportDataType {
    InvoiceDate: string = '';
    InvoiceNo: string = '';
    VendorOrFranchisee: string = '';
    MaterialName: string = '';
    PurchaseQuantity: number = 0
    PurchaseAmount: number = 0
    SalesQuantity: number = 0
    SalesAmount: number = 0
}

export class materialFlowSearchDataType {
    fromDate: string = '';
    toDate: string = '';
    materials: materialData[] = [];
}

export class materialData {
    materialID: string = '';
}
//#endregion

//#region Franchisee Renewal Payment List
export class franchiseeRenewalPaymentListDataType {
    TenantBranchID: string = '';
    FranchiseeCode: string = '';
    FranchiseeName: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Address: string = '';
    Address1: string = '';
    Address2: string = '';
    Country: string = '';
    State: string = '';
    District: string = '';
    Area: string = '';
    Pincode: string = '';
    PackageType: string = '';
    PackageLogID: string = '';
    Amount: number = 0;
    total?: number = 0;
    PaymentDetails: PaymentDetailViewListMl[] = []
}
//#endregion