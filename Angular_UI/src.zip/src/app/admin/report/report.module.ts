import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateInputModule, DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { PurchaseService } from './services/purchase.service';
import { MaterialFlowReportComponent } from './components/material-flow-report/material-flow-report.component';
import { ReportComponent } from './report.component';
import { DateRangesModule } from 'src/app/shared/components/date-ranges/date-ranges.module';
import { PurchaseInvoiceModule } from './components/purchase-invoice/purchase-invoice.module';
import { HttpClientModule } from '@angular/common/http';
import { NotificationService } from '@progress/kendo-angular-notification';
import { RenewalPaymentComponent } from './components/renewal-payment/renewal-payment.component';
import { PaymentInfoModule } from 'src/app/shared/components/payment-info/payment-info.module';
const routes: Routes = [
    {
        path: '',
        component: ReportComponent,
        children: [
            {
                path: 'material-flow-report',
                component: MaterialFlowReportComponent,
            },
            {
                path: 'renewal-payment-list',
                component: RenewalPaymentComponent,
            },
            {
                path: 'purchase-invoice-list',
                loadChildren: () => import('./components/purchase-invoice/purchase-invoice.module').then(m => m.PurchaseInvoiceModule)
            }
        ]
    }
];

@NgModule({
    declarations: [
        ReportComponent,
        MaterialFlowReportComponent,
        RenewalPaymentComponent,
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        ButtonsModule,
        LayoutModule,
        NavigationModule,
        IconsModule,
        InputsModule,
        ToolBarModule,
        DropDownsModule,
        FormsModule,
        ReactiveFormsModule,
        DateInputModule,
        PopupModule,
        GridModule,
        LabelModule,
        DialogsModule,
        DateInputsModule,
        DateRangesModule,
        PurchaseInvoiceModule,
        HttpClientModule,
        PaymentInfoModule
    ],
    providers: [PurchaseService, NotificationService]
})
export class ReportModule { }
