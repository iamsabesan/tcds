import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { materialFlowSearchDataType } from '../model/purchase';

@Injectable({
  providedIn: 'root'
})
export class PurchaseService {

  public materialFlowReportUrl = "/icloud-inventory/v1/indent/material/flow/report";
  public franchiseRenewalPaymentListUrl = "/icloud-franchisee/v1/franchisee/renewal/payment/list";
  constructor(public http_service: HttpService) { }
  // getMaterialFlowReport(materialFlowSearchValue: materialFlowSearchDataType) {
  //   return this.http_service.post(this.materialFlowReportUrl, { Body: { materialFlowSearchValue }, RequestType: IRequestType.Protected });
  // }
  getfranchiseeRenewalPaymentList(){
    return this.http_service.get(this.franchiseRenewalPaymentListUrl, {RequestType:IRequestType.Protected});
  }
  getMaterialFlowReport(materialFlowSearchValue: materialFlowSearchDataType) {
    return this.http_service.post("/icloud-inventory/v1/indent/material/flow/report", materialFlowSearchValue,{ RequestType: IRequestType.Protected });
  }
}
