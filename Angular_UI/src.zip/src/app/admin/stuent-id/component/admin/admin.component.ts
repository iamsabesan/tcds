import { Component } from "@angular/core";
import { AdminService } from "./service/admin.service";

@Component({
    selector: 'admin-StudentIDCard',
    templateUrl: './admin.component.html',
    providers: [AdminService]
})
export class AdminStudentIDCardComponent {
    
    public Actions: string = '';

    constructor(private _srvAdminStudentID: AdminService) {
        this._srvAdminStudentID.Mode.subscribe(res => this.Actions = res.Mode)
    }

}