import { NgModule } from "@angular/core";
import { CreateComponent } from "./component/create/create.component";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { AdminService } from "./service/admin.service";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { AdminStudentIDCardComponent } from "./admin.component";
import { GridModule } from "@progress/kendo-angular-grid";
import { ButtonModule } from "@progress/kendo-angular-buttons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IconsModule } from "@progress/kendo-angular-icons";
import { FormsModule } from "@angular/forms";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { InfoModule } from "src/app/shared/components/info/info.module";
import { DialogModule, DialogsModule } from "@progress/kendo-angular-dialog";
import { RejectModule } from "src/app/shared/components/reject/reject.module";
import { TelerikReportingModule } from "@progress/telerik-angular-report-viewer";

const routes: Routes = [
    {
        path: '',
        component: AdminStudentIDCardComponent
    }
]
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,

        GridModule,
        ButtonModule,
        InputsModule,
        LabelModule,
        NavigationModule,
        LayoutModule,
        IconsModule,
        DialogsModule,
        DialogModule,

        PaymentInfoModule,
        InfoModule,
        RejectModule,
        TelerikReportingModule
    ],
    declarations: [
        AdminStudentIDCardComponent,
        CreateComponent,
        ListComponent,
        ViewComponent
    ],
    providers: [
        AdminService
    ]
})

export class AdminStudentIDModule { }