import { Component } from "@angular/core";
import { LocalString, gridFontStyle } from "src/app/shared/app-global";
import { AdminService } from "../../service/admin.service";
import { IWebError } from "src/core/model";
import { CommonService } from "src/app/shared/service/common.service";
import { StudentIDCardIndent } from "../../model/admin";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html',
    styleUrls: ['list.component.scss']
})

export class ListComponent {

    /* List */
    public LstIDCardIndent: StudentIDCardIndent[] = [];

    /* Model */
    public gridStyle = new gridFontStyle();

    /* Grid Pagination */
    public buttonCount: number = 5;
    public sizes: any[] = [25, 50, 100, "All"];
    public info: boolean = true;
    public previousNext: boolean = true;

    public currencySymbol = '';

    constructor(private _srvAdminIDCard: AdminService,
        private _srvCommon: CommonService) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvAdminIDCard.getAdminStudentIDCardList().subscribe({
            next: (res: any) => {
                this.LstIDCardIndent = res.Data;
                res.Data.forEach((E) => {
                    E.franchiseeDetails.FranchiseeName = E.franchiseeDetails.FranchiseeName.toUpperCase();
                    E.franchiseeDetails.Address = this._srvCommon.concatAddress(E.franchiseeDetails)
                    // E.franchiseeDetails.Address = E.franchiseeDetails.Area + ", " + E.franchiseeDetails.District + ", " + E.franchiseeDetails.State + " - " + E.franchiseeDetails.Pincode + '.';
                });
            },
            error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
        })
    }

    /* View the Detail */
    btnViewDetail(data: StudentIDCardIndent) {
        this._srvAdminIDCard.MlStudentIDCardDetail = new StudentIDCardIndent();
        this._srvAdminIDCard.MlStudentIDCardDetail = data;
        this._srvAdminIDCard.Mode.next({ Mode: 'VIEW' });
    }
}