import { PaymentDetail } from "../../franchisee/model/franchisee";

export class StudentIDCardIndent {
    IDCardIndentID: string = '';
    TenantBranchID: string = '';
    IndentNumber: string = '';
    TotalIndent: number = 0;
    Amount: number = 0;
    IndentDate: string = '';
    Pending: number = 0;
    Printed: number = 0;
    Despatched: number = 0;
    Rejected: number = 0;
    Status: string = '';
    franchiseeDetails: FranchiseeDetails = new FranchiseeDetails();
}

export class FranchiseeDetails {
    TenantBranchID: string = '';
    FranchiseeCode: string = '';
    FranchiseeName: string = '';
    ContactName: string = '';
    Phone: string = '';
    Address: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    Taluk: string = '';
    State: string = '';
    District: string = '';
    Pincode: string = '';
}

/* Student ID Card Indent Detail */
export class StudentDetail {
    CourierAmount: number = 0;
    IDCardIndentID: string = '';
    TenantBranchID: string = '';
    IndentNumber: string = '';
    IndentDate: string = '';
    StudentInfo: StudentInfo[] = [];
    PaymentDetails: PaymentDetail[] = [];
    franchiseeDetails: FranchiseeDetail = new FranchiseeDetail();
}
export class StudentInfo {
    IsChecked: boolean = false;
    IDCardFees: number = 0;
    IDCardIndentTransID: string = '';
    BatchMappingID: string = '';
    ContactID: string = '';
    StudentID: string = '';
    RollNumber: string = '';
    Course: string = '';
    BatchNumber: string = '';
    BatchTime: string = '';
    ShortName: string = '';
    CourseTypeName: string = '';
    StudentName: string = '';
    Phone: string = '';
    Status: string = '';
}

export class FranchiseeDetail {
    TenantBranchID: string = '';
    BranchName: string = '';
    ContactName: string = '';
    Gender: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    AddressTypeID: string = '';
    AddressType: string = '';
    Address1: string = '';
    Address2: string = '';
    Country: string = '';
    State: string = '';
    District: string = '';
    Area: string = '';
    Pincode: string = '';
    Taluk: string = '';
    FranchiseeCode: string = '';
}

/* Update the Printed Status */
export class UpdatePrintedStatus {
    IDCardIndentID: string = '';
    TransIDs: TransId[] = [];
}

export class TransId {
    IDCardIndentTransID: string = '';
}
