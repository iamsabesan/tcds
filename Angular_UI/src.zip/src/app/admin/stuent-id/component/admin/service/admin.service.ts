import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { StudentIDCard } from "src/app/shared/ServiceUrl";
import { IRequestType } from "src/core/model";
import { HttpService } from "src/core/service";
import { StudentIDCardIndent, UpdatePrintedStatus } from "../model/admin";

@Injectable({
    providedIn: 'root'
})

export class AdminService {

    /* Behavior Subject for storing the request type */
    public Mode = new BehaviorSubject({ Mode: 'LIST' });

    /* Store the Franchisee Detail */
    public MlStudentIDCardDetail: StudentIDCardIndent = new StudentIDCardIndent();

    constructor(private _srvHttp: HttpService) { }

    /* Get Student ID Card Indent List */
    getAdminStudentIDCardList() {
        return this._srvHttp.get(StudentIDCard.getAdminStudentIDCardIndent, { RequestType: IRequestType.Protected });
    }

    /* Get Student ID Card Indent List */
    getStudentIDCardPrintList() {
        return this._srvHttp.get(StudentIDCard.getStudentIDCardPrintLst, { RequestType: IRequestType.Protected });
    }

    /* Get Student ID Card Indent Detail */
    getAdminStudentIDCardDetail(idCardIndent: string) {
        return this._srvHttp.get(`${StudentIDCard.getAdminStudentIDCardDetail}${idCardIndent}`, { RequestType: IRequestType.Protected });
    }

    approveIndent(approveIndent: any) {
        return this._srvHttp.post(StudentIDCard.getAdminStudentIDCardApprove, approveIndent, { RequestType: IRequestType.Protected });
    }

    /* Reject Indent */
    rejectIndent(idCardIndent: string, reason: string) {
        return this._srvHttp.post(StudentIDCard.getAdminStudentIDCardReject + '?iDCardIndentID=' + idCardIndent + '&reason=' + reason, { RequestType: IRequestType.Protected })
    }

    /* Update the 'Print' Status */
    updatePrintedStatus(printedIDCard: UpdatePrintedStatus) {
        return this._srvHttp.post(StudentIDCard.updatePrintedStatus, printedIDCard, { RequestType: IRequestType.Protected });
    }

    // /* Preview & Print the Student ID Card */
    // previewIDCard(preivewIDCard: any) {
    //     return this._srvHttp.post(StudentIDCard.previewStudentIDCard, preivewIDCard, { RequestType: IRequestType.Protected });
    // }

}