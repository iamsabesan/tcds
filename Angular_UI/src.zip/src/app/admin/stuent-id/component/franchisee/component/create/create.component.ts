import { Component } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { IntlService } from "@progress/kendo-angular-intl";
import { StepperActivateEvent } from "@progress/kendo-angular-layout";
import { DateConversion, DropDownFilter, gridFontStyle, LocalString } from "src/app/shared/app-global";
import { batchByIDDataType, CourseInfoListByFranchiseeMl, CourseTypeListMl, MultiDropdownColumn, StudentFilterDataMl } from "src/app/shared/model/common";
import { PaymentPayVal } from "src/app/shared/model/payment";
import { PaymentInfo } from "src/app/shared/model/payment-grid.model";
import { CommonService } from "src/app/shared/service/common.service";
import { BatchColumn, CourseColumn, CreateStudentIdMl, Idcard, StudentListMl } from "../../model/franchisee";
import { FranchiseeService } from "../../service/franchisee.service";

@Component({
    selector: 'create',
    templateUrl: 'create.component.html',
    styleUrls: ['create.component.scss']
})

export class CreateComponent {

    public currentStep: number = 0;


    public LstCourseType: CourseTypeListMl[] = [];
    public LstCourseInfo: CourseInfoListByFranchiseeMl[] = [];
    public LstBatchDetail: batchByIDDataType[] = [];
    public LstStudentDetail: StudentListMl[] = [];
    public LstStoreStudentDetail: StudentListMl[] = [];
    public LstStudentIDIndent: StudentListMl[] = [];
    /* Multicolumn Dropdown */
    public LstCourseColumn: MultiDropdownColumn[] = CourseColumn;
    public LstBatchColumn: MultiDropdownColumn[] = BatchColumn;
    public PaymentDetails: PaymentInfo[] = [];


    /* Model */
    public MlPayment: PaymentPayVal = new PaymentPayVal();
    public gridStyle = new gridFontStyle('medium');
    public MlCreateStudentIDCard: CreateStudentIdMl = new CreateStudentIdMl()

    /* Dropdown Filter */
    public filterSettings = DropDownFilter.StartWithfilterSettings;


    public currencySymbol: string = '';

    public CourierChargeAmount: number = 0;
    public IDCardCharge: number = 0;
    public TotalAmount: number = 0;

    public batchComboValue: any;
    public studentValue: any;

    /* Payment Transaction */
    public paymentamount: number = 0;
    public totalFees: number = 0;
    public Totalamount: number = 0;
    public ErrorNotification: string = 'Please Enter Valid Total Amount';
    public ErrorNotify: string = 'Exam Fees amount must be equal with Total Amount';


    public FrmEntry = this.fb.group({
        courseType: [],
        course: [],
        batch: [],
        studentName: [],
    });

    constructor(public currencyService: IntlService, private _srvCom: CommonService, private _srvFrStudentID: FranchiseeService,
        public fb: FormBuilder) { }


    ngOnInit(): void {
        this.currencySymbol = LocalString.CurrencySymbol;

        this._srvCom.getCourseTypeList().subscribe({
            next: val => {
                this.LstCourseType = val.Data;
            }
        })

        this._srvCom.getCourierChargeAmount().subscribe({ next: res => this.CourierChargeAmount = res.Data });

        this._srvCom.getIDCardChargeAmount().subscribe({ next: e => this.IDCardCharge = e.Data })
    }


    public steps = [
        {
            label: "Select Student",
        },
        {
            label: "Make Payment",
        },
    ];

    public onStepActivate(ev: StepperActivateEvent): void {
        if (this.currentStep == 0) {
            if (!this.LstStudentIDIndent.length) {
                ev.preventDefault();
                this._srvCom.errorMsg('Please add at least one student ID card indent.')
            }
        }
    }

    onCourseTypeChange(event: CourseTypeListMl | null): void {
        this.LstCourseInfo = [];
        this.LstBatchDetail = this.LstStudentDetail = [];

        this.FrmEntry.controls.course.setValue(null);
        this.FrmEntry.controls['batch'].setValue(null);
        this.FrmEntry.controls['studentName'].setValue(null);

        if (event && event.CourseTypeID) {
            this._srvCom.getCourseListInCourseType(event.CourseTypeID).subscribe({
                next: val => {
                    this.LstCourseInfo = val.Data || [];
                }
            });
        }
    }


    /* Get Batch Detail With Using CourseID */
    getBatch(event: CourseInfoListByFranchiseeMl) {
        this.LstBatchDetail = this.LstStudentDetail = [];
        this.batchComboValue = this.studentValue = undefined;
        this.FrmEntry.controls['batch'].setValue(null);
        this.FrmEntry.controls['studentName'].setValue(null);
        if (event) {
            var CourseID = event.CourseID;

            this._srvCom.getActiveBatchCourseID(CourseID).subscribe({
                next: (e) => this.LstBatchDetail = e.Data,
                error: (err) => this._srvCom.errorMsg(err.Message)
            });
        }
    }

    /* Get Student Detail With Using BatchID */
    getStudentDetail(event: any) {
        this.LstStudentDetail = [];
        this.batchComboValue = this.studentValue = undefined;
        this.FrmEntry.controls['studentName'].setValue(null);

        if (event) {
            this.batchComboValue = event.CourseBatchID;
            var student = new StudentFilterDataMl();

            delete student.StartDate;
            delete student.EndDate;

            student.CourseID = this.FrmEntry.controls.course.value.CourseID;
            student.CourseBatchID = this.batchComboValue;
            student.CourseTypeID = this.FrmEntry.controls.courseType.value.CourseTypeID;

            this._srvFrStudentID.getCurrentStudent(student).subscribe({
                next: (e) => {
                    this.LstStudentDetail = this.LstStoreStudentDetail = e.Data;
                    if (this.LstStudentDetail.length !== 0) this.LstStudentDetail = this.compareTwoArray(this.LstStudentDetail, this.LstStudentIDIndent);
                }
            })

            // this._srvCom.getStudentListCourseBatchId(this.batchComboValue).subscribe({
            //     next: (e) => {
            //         this.LstStudentDetail = this.LstStoreStudentDetail = e.Data;
            //         if (this.LstStudentDetail.length !== 0) this.LstStudentDetail = this.compareTwoArray(this.LstStudentDetail, this.LstStudentExamIndent);
            //     },
            //     error: (err) => this._srvCom.errorMsg(err.Message)
            // })
        }
    }

    StudentValue(event: any) {
        if (event) this.studentValue = event;
        else this.studentValue = undefined;
    }

    /* Compare Two Array Value (Student Detail & LstExamIndent) */
    compareTwoArray(array1: any, array2: any) {
        return array1.filter((object1: any) => {
            return !array2.some((object2: any) => {
                return object1.RollNumber === object2.StudentID && object1.BatchMappingID == object2.BatchMappingID;
            });
        });
    }


    /* Add Exam Indent in List */
    addStudent() {
        if (!this.FrmEntry.valid) this.FrmEntry.markAllAsTouched();
        else {
            this.FrmEntry.controls.studentName.value.filter((e: any) => {

                const studentGrid: StudentListMl = new StudentListMl();
                studentGrid.BatchMappingID = e.BatchMappingID;
                studentGrid.StudentID = e.RollNumber;
                studentGrid.StudentName = e.StudentName;
                studentGrid.Course = e.Course;
                studentGrid.Batch = e.StartTime + ' - ' + e.EndTime;
                studentGrid.ShortName = e.ShortName;
                studentGrid.CourseTypeName = e.CourseTypeName;

                this.LstStudentIDIndent.push(studentGrid);
                this.FrmEntry.reset();
                this.LstBatchDetail = this.LstStudentDetail = [];
            });
        }
    }


    /* Delete the Record in Exam Indent List */
    deleteRow(row: number) {
        this.LstStudentIDIndent.splice(row, 1);
        this.LstStudentDetail = this.compareTwoArray(this.LstStoreStudentDetail, this.LstStudentIDIndent);
    }

    next() {
        if (!this.FrmEntry.valid && !this.LstStudentIDIndent.length) this.FrmEntry.markAllAsTouched();
        else if (!this.LstStudentIDIndent.length) this._srvCom.errorMsg("Please add at least one student ID card indent.");

        else if (this.LstStudentIDIndent.length && this.currentStep !== this.steps.length) {
            this.totalFees = this.LstStudentIDIndent.length * this.IDCardCharge
            this.TotalAmount = this.totalFees + this.CourierChargeAmount;
            this.paymentamount = this.TotalAmount;
            this.currentStep += 1;
            return;
        }
    }

    submit() {
        const LstPayment = [];
        this.MlCreateStudentIDCard = new CreateStudentIdMl();
        // this.MlCreateExamIndent.batchMapping = this.MlCreateExamIndent.paymentItems = [];
        if (!this.LstStudentIDIndent.length) this._srvCom.errorMsg("Please add detail");
        else if (this.PaymentDetails.length == 0) this._srvCom.errorMsg("Please add payment");
        else if (this.Totalamount < this.paymentamount) this._srvCom.errorMsg("Please pay full amount");
        else if (this.Totalamount > this.paymentamount) this._srvCom.errorMsg("Please pay currect amount");

        else if (this.Totalamount == this.paymentamount) {


            this.PaymentDetails.filter((e: any) => {

                this.MlPayment = new PaymentPayVal();
                this.MlPayment.PaymentModeID = e.PaymentModeID;
                this.MlPayment.PayModeType = e.PayModeType;
                this.MlPayment.PayModeValue = e.PayModeValue;
                this.MlPayment.Amount = e.Amount;
                this.MlPayment.FromLedgerID = e.FromLedger.LedgerID;
                this.MlPayment.FromLedgerName = e.FromLedger.LedgerName;
                this.MlPayment.ToLedgerID = e.ToLedger.LedgerID;
                this.MlPayment.ToLedgerName = e.ToLedger.LedgerName;
                this.MlPayment.TransactionNo = e.TransactionNo;
                this.MlPayment.TransactionDate = DateConversion.ConvertMonthDateYear(e.TransactionDate);
                this.MlPayment.RoundOff = 0;
                this.MlPayment.BankCommission = 0;
                e.DocumentID ? this.MlPayment.DocumentID = e.DocumentID : delete this.MlPayment.DocumentID;

                LstPayment.push(this.MlPayment)
            });

            this.MlCreateStudentIDCard.CourierAmount = this.CourierChargeAmount;
            this.MlCreateStudentIDCard.TotalAmount = this.TotalAmount;
            this.MlCreateStudentIDCard.paymentItems = LstPayment;

            this.MlCreateStudentIDCard.IDCard = this.LstStudentIDIndent.map(student => {
                const idCard = new Idcard();
                idCard.BatchMappingID = student.BatchMappingID;
                return idCard;
            });

            this._srvFrStudentID.postCreateStudentID(this.MlCreateStudentIDCard).subscribe({
                next: res => {
                    this._srvCom.successMsg(res.Message);
                    this._srvFrStudentID.Mode.next({ Mode: 'LIST' });
                }, error: err => this._srvCom.errorMsg(err.Message)
            });
        }
    }


    /* Delete the Record in Exam Indent List */
    rowDelete(row: number) {
        this.LstStudentIDIndent.splice(row, 1);
        this.LstStudentDetail = this.compareTwoArray(this.LstStoreStudentDetail, this.LstStudentIDIndent);
        this.totalFees = this.LstStudentIDIndent.length * this.IDCardCharge
        this.TotalAmount = this.totalFees + this.CourierChargeAmount;
        this.paymentamount = this.TotalAmount;
        if (!this.LstStudentIDIndent.length) this.PaymentDetails = [];
    }


    prev(): void {
        this.currentStep -= 1;
    }

    /* Go back on the Exam Indent List Component */
    goBack() {
        this._srvFrStudentID.Mode.next({ Mode: 'LIST' });
        this._srvFrStudentID.IndentDateRange = true;
    }

    /* Exam total payment value */
    totalAmount(total: number): void {
        this.Totalamount = total;
    }

}