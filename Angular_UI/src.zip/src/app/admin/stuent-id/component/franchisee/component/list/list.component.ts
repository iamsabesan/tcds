import { Component, ViewChild } from "@angular/core";
import { PageChangeEvent } from "@progress/kendo-angular-grid";
import { DateConversion, DateSize, gridFontStyle, LocalString } from "src/app/shared/app-global";
import { DateRangesComponent } from "src/app/shared/components/date-ranges/date-ranges.component";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { CommonService } from "src/app/shared/service/common.service";
import { StudentIDCardListMl } from "../../model/franchisee";
import { FranchiseeService } from "../../service/franchisee.service";

@Component({
    selector: 'list',
    templateUrl: 'list.component.html',
    styleUrls: ['list.component.scss']
})

export class ListComponent {

    /* View Child */
    @ViewChild(DateRangesComponent) dateRanges: DateRangesComponent;

    /* List */
    public LstStatus: string[] = [];
    public LstStudentIDCard: StudentIDCardListMl[] = [];

    /* Model */
    public gridStyle: gridFontStyle = new gridFontStyle('medium');
    public dateStyle: DateSize = new DateSize('medium');
    public MlDateRange: DateRanges = new DateRanges();
    public MlStatus: any;

    /* Store Currency Symbol */
    public currencySymbol: string = '';

    /* Date Format */
    public dateWholePeriod: boolean;
    WholePerStrDate: Date;

    /* Grid Pagination */
    public pageSize: number = 15;
    public skip: number = 0;
    public buttonCount: number = 5;
    public sizes: any[] = [25, 50, 100, "All"];

    constructor(private _srvFrStudentID: FranchiseeService, public _srvCom: CommonService) {

        const tenentBranchid = LocalString.TenantBranchID;
        _srvCom.getWholePeriodDate(tenentBranchid).subscribe({
            next: (val) => {
                this.WholePerStrDate = DateConversion.ConvertStringToDate(val.Data);
            }
        })
    }

    ngOnInit(): void {
        this.dateWholePeriod = false;
        this.currencySymbol = LocalString.CurrencySymbol;
        this._srvFrStudentID.getStudentIDStatusLst().subscribe(e => {
            this.LstStatus = e.Data;
            if (!this.MlStatus) this.MlStatus = this.LstStatus.find(e => e.toUpperCase() == 'ALL');
        });


        if (this._srvFrStudentID.IndentDateRange) {
            this.MlStatus = this._srvFrStudentID.MlLstFilterStatus;
            this.MlDateRange = this._srvFrStudentID.MllstFliterData;
            this.pageSize = this._srvFrStudentID.listPageSize;
            this.skip = this._srvFrStudentID.listPageSkip;
        }

        setTimeout(() => {
            this.searchDate()
        }, 100);

    }

    ngAfterViewInit() {

        if (this._srvFrStudentID.IndentDateRange) {
            this.MlStatus = null;
            this.MlStatus = this._srvFrStudentID.MlLstFilterStatus;
            setTimeout(() => {
                this.MlDateRange = this._srvFrStudentID.MllstFliterData;
                if (this.MlDateRange.duration && this.dateRanges.dateData) {
                    if (this.MlDateRange.duration != "Custom") {
                        this.dateRanges.dateData.forEach(e => {
                            if (e.value == this.MlDateRange.duration) {
                                this.dateRanges.selectedValue = e;
                                this.dateRanges.getDate(e);
                            }
                        })
                    }
                    else {
                        const customRange = this.dateRanges.dateData.find(obj => obj.value === "Custom");
                        this.dateRanges.selectedValue = customRange;
                        this.dateRanges.IsdisabledDate = false;
                        this.AssignDate(this.MlDateRange);
                    }
                }
                else if (!this.MlDateRange.duration && (this.MlDateRange.startDate && this.MlDateRange.endDate)) {
                    if (this.MlDateRange.duration != "") {
                        this.dateRanges.IsdisabledDate = false;
                        this.dateRanges.selectedValue = undefined;
                    }
                    this.AssignDate(this.MlDateRange)
                }
                else {
                    this.AssignDate(this.MlDateRange)
                    this.dateRanges.IsdisabledDate = false;
                    this.dateRanges.selectedValue = undefined;
                }
                this._srvFrStudentID.IndentDateRange = false;
                this._srvFrStudentID.listPageSize = 15;
                this._srvFrStudentID.listPageSkip = 0;
            });
        }
    }

    /* Date Assign */
    AssignDate(MlDateRange: DateRanges) {
        this.dateRanges.dateRange.startDate = MlDateRange.startDate;
        this.dateRanges.dateRange.endDate = MlDateRange.endDate;
    }



    /* Go to Create Exam Indent Component */
    addNew() {
        this.setPagenation();
        this._srvFrStudentID.Mode.next({ Mode: 'CREATE' });
    }

    setPagenation() {
        this._srvFrStudentID.listPageSize = this.pageSize;
        this._srvFrStudentID.listPageSkip = this.skip;
    }


    searchDate() {
        this.LstStudentIDCard = [];
        if (this.dateRanges && ((!this.dateRanges.dateRange.startDate && this.dateRanges.dateRange.endDate) || (this.dateRanges.dateRange.startDate && !this.dateRanges.dateRange.endDate))) this._srvCom.errorMsg('Please enter the correct date')
        else {
            const fromDate = this.dateRanges.dateRange.startDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.startDate) : '';
            const endDate = this.dateRanges.dateRange.endDate ? DateConversion.ConvertToYearMonthDate(this.dateRanges.dateRange.endDate) : '';
            const status = this.MlStatus ?? 'ALL';
            this._srvFrStudentID.getStudentIdCardLst(fromDate, endDate, status).subscribe({
                next: val => {
                    this.LstStudentIDCard = val.Data;
                    this.MlDateRange = this.dateRanges.dateRange;
                    this.lstflitervalue();
                }, error: err => this._srvCom.errorMsg(err.Message)
            })
        }
    }

    view(data: StudentIDCardListMl) {
        this._srvFrStudentID.StudentIDViewIndentID = '';
        this._srvFrStudentID.StudentIDViewIndentID = data.IDCardIndentID;
        this._srvFrStudentID.Mode.next({ Mode: 'VIEW' });
        this.lstflitervalue();
    }

    lstflitervalue() {
        setTimeout(() => {
            this._srvFrStudentID.MllstFliterData.duration = this.MlDateRange.duration;
            this._srvFrStudentID.MllstFliterData.startDate = this.dateRanges.dateRange.startDate;
            this._srvFrStudentID.MllstFliterData.endDate = this.dateRanges.dateRange.endDate;
            this._srvFrStudentID.MlLstFilterStatus = this.MlStatus;
        }, 100)
    }



    public pageChange(event: PageChangeEvent): void {
        this.skip = event.skip;
        this.pageSize = event.take;
    }
}