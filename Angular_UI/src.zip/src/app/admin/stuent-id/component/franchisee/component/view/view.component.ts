import { ChangeDetectorRef, Component } from "@angular/core";
import { IntlService } from "@progress/kendo-angular-intl";
import { gridFontStyle, LocalString } from "src/app/shared/app-global";
import { PaymentDetailViewListMl } from "src/app/shared/model/common";
import { CommonService } from "src/app/shared/service/common.service";
import { ReceiveStudentIDCardMl, ViewStudentIDIndentDetailsMl } from "../../model/franchisee";
import { FranchiseeService } from "../../service/franchisee.service";

@Component({
    selector: 'view',
    templateUrl: 'view.component.html',
    styleUrls: ['view.component.scss']
})

export class ViewComponent {

    /* List */
    public PaymentInfo: PaymentDetailViewListMl[] = [];
    public LstReceiveStudentIDCard: ReceiveStudentIDCardMl[] = [];


    /* Model */
    public MlStudentIDViewDetails: ViewStudentIDIndentDetailsMl = new ViewStudentIDIndentDetailsMl();
    public gridStyle: gridFontStyle = new gridFontStyle();

    /* Store Currency Symbol */
    public currencySymbol: string = '';

    total: number = 0;

    /* Grid Pagination */
    public pageSize: number = 5;
    public skip: number = 0;
    public buttonCount: number = 5;
    public sizes: any[] = [5, 10, 20, 50, 100, "All"];

    public IsDespatch: boolean = false;
    public SelectAll: boolean = false;

    constructor(private _srvFrStudentID: FranchiseeService, public _srvCom: CommonService, public intlService: IntlService, private cd: ChangeDetectorRef,) { }

    ngOnInit() {

        this.currencySymbol = LocalString.CurrencySymbol;

        this._srvFrStudentID.getStudentViewDetails(this._srvFrStudentID.StudentIDViewIndentID).subscribe({
            next: val => {
                this.MlStudentIDViewDetails = val.Data;
                this.PaymentInfo = [];
                this.PaymentInfo = this.MlStudentIDViewDetails.PaymentDetails.map(e => ({
                    TransactionDate: e.TransactionDate,
                    Summary: e.Summary,
                    Amount: e.Amount,
                    PayMode: e.PayMode,
                    DocumentID: e.DocumentID,
                    WalletID: e.TransID
                }));
                this.cd.markForCheck()

                this.total = this.MlStudentIDViewDetails.IndentAmount + this.MlStudentIDViewDetails.CourierAmount;

                if (this.MlStudentIDViewDetails.StudentInfo.length) {
                    this.IsDespatch = this.MlStudentIDViewDetails.StudentInfo.some(e => e.Status.toLowerCase() == 'despatched')

                    this.MlStudentIDViewDetails.StudentInfo.forEach(e => { e.IsDespatched = false })
                }

            }, error: err => this._srvCom.errorMsg(err.Message)
        })

    }

    ReceiveStudentIDCard() {
        var checkDespatch = this.MlStudentIDViewDetails.StudentInfo.some(e => (e.Status.toLowerCase() == 'despatched') && (e.IsDespatched == true));
        if (checkDespatch) {
            this.LstReceiveStudentIDCard = this.MlStudentIDViewDetails.StudentInfo.filter(e => (e.Status.toLowerCase() == 'despatched') && (e.IsDespatched)).map(data => ({ IDCardIndentTransID: data.IDCardIndentTransID }))
            this._srvFrStudentID.postStudentIdCardReceive(this.LstReceiveStudentIDCard).subscribe({
                next: val => {
                    this._srvCom.successMsg(val.Message);
                    setTimeout(() => {
                    this.goBack() 
                    }, 500);
                }, error: err => this._srvCom.errorMsg(err.Message)
            })

        } else this._srvCom.errorMsg('Please select atleast one student ID card')
    }

    clickSelectAll(selectAll: boolean) {
        this.MlStudentIDViewDetails.StudentInfo.forEach(val => {
            if (val.Status.toLowerCase() === 'despatched') {
                if (selectAll) val.IsDespatched = true;
                else val.IsDespatched = false;
            }
        });
    }

    clickCheckbox() {
        if (this.MlStudentIDViewDetails.StudentInfo.every(e => (e.Status.toLowerCase() == 'despatched') && (e.IsDespatched == true))) {
            this.SelectAll = true;
        } else this.SelectAll = false;
    }

    goBack() {
        this._srvFrStudentID.Mode.next({ Mode: 'LIST' });
        this._srvFrStudentID.IndentDateRange = true;
    }
}