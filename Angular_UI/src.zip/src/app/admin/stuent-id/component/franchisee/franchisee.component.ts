import { Component } from "@angular/core";
import { FranchiseeService } from "./service/franchisee.service";

@Component({
    selector: 'franchisee-student-id',
    templateUrl: 'franchisee.component.html',
    providers: [FranchiseeService]
})

export class FranchiseeComponent {

    public Actions: string = '';

    constructor(private _srvFrStudentID: FranchiseeService) {
        this._srvFrStudentID.Mode.subscribe(res => this.Actions = res.Mode)
    }
}