import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { ButtonModule } from "@progress/kendo-angular-buttons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { GridModule } from "@progress/kendo-angular-grid";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { DateRangesModule } from "src/app/shared/components/date-ranges/date-ranges.module";
import { PaymentGridModule } from "src/app/shared/components/payment-grid/payment-grid.module";
import { PaymentInfoModule } from "src/app/shared/components/payment-info/payment-info.module";
import { CreateComponent } from "./component/create/create.component";
import { ListComponent } from "./component/list/list.component";
import { ViewComponent } from "./component/view/view.component";
import { FranchiseeComponent } from "./franchisee.component";
import { FranchiseeService } from "./service/franchisee.service";

const routes: Routes = [
    {
        path: '',
        component: FranchiseeComponent
    }
]

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,
        ReactiveFormsModule,

        GridModule,
        ButtonModule,
        InputsModule,
        LabelModule,
        NavigationModule,
        LayoutModule,
        IconsModule,
        ToolBarModule,
        DropDownsModule,

        PaymentInfoModule,
        DateRangesModule,
        PaymentGridModule


    ],
    declarations: [
        CreateComponent,
        ListComponent,
        ViewComponent,
        FranchiseeComponent
    ],
    providers: [
        FranchiseeService
    ]
})

export class FranchiseeStudentIDModule {

}