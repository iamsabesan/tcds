import { MultiDropdownColumn } from "src/app/shared/model/common";
import { PaymentPayVal } from "src/app/shared/model/payment";

export interface Pages {
    Mode: 'LIST' | 'CREATE' | 'VIEW'
}


/* Add Exam Indent */
export const CourseColumn: MultiDropdownColumn[] = [
    {
        Field: "ShortName",
        Title: "Short Name",
        Width: 150,
    },
    {
        Field: "Course",
        Title: "Full Name",
        Width: 250,
    },
    // {
    //     Field: "CourseType",
    //     Title: "Course Type",
    //     Width: 200
    // }
];

export const BatchColumn: MultiDropdownColumn[] = [
    {
        Field: "BatchNumber",
        Title: "ID",
        Width: 150
    },
    {
        Field: "Timing",
        Title: "Time",
        Width: 150,
    },
    {
        Field: "FacultyName",
        Title: "Faculty",
        Width: 200
    }
];
//#endregion

export class StudentListMl {
    StudentID: string = '';
    BatchMappingID: string = '';
    ContactID: string = '';
    RegisteredDate: string = '';
    RollNumber: string = '';
    StudentName: string = '';
    Course: string = '';
    StartDate: string = '';
    EndDate: string = '';
    StartTime: string = '';
    EndTime: string = '';
    Phone: string = '';
    AlternatePhone: string = '';
    Email: string = '';
    IsActive: boolean;
    Reason: string = '';
    ShortName: string = '';
    CourseTypeName: string = '';
    Batch: string = '';
}


export class CreateStudentIdMl {
    IDCard: Idcard[] = [];
    TotalAmount: number = 0;
    CourierAmount: number = 0;
    paymentItems: PaymentPayVal[] = [];
}

export class Idcard {
    BatchMappingID: string = '';
}

export class StudentIDCardListMl {
    Slno: number = 0;
    IDCardIndentID: string = '';
    IndentNumber: string = '';
    TotalIndent: number = 0;
    Amount: number = 0;
    Status: string = '';
    Pending: number = 0;
    Printed: number = 0;
    Despatched: number = 0;
    Rejected: number = 0;
    IndentDate: string = '';
}


export class ViewStudentIDIndentDetailsMl {
    IDCardIndentID: string = '';
    IndentNumber: string = '';
    TotalIndent: number = 0;
    IndentAmount: number = 0;
    CourierAmount: number = 0;
    Status: string = '';
    IndentDate: string = '';
    StudentInfo: StudentInfo[] = [];
    PaymentDetails: PaymentDetail[] = [];
}

export class StudentInfo {
    IDCardIndentTransID: string = '';
    BatchMappingID: string = '';
    ContactID: string = '';
    StudentID: string = '';
    RollNumber: string = '';
    Course: string = '';
    BatchNumber: string = '';
    BatchTime: string = '';
    ShortName: string = '';
    CourseTypeName: string = '';
    StudentName: string = '';
    Phone: string = '';
    Status: string = '';
    IsDespatched: boolean = false;
}

export class PaymentDetail {
    TransactionDate: string = '';
    Summary: string = '';
    Amount: number = 0;
    PayMode: string = '';
    DocumentID: string = '';
    TransID: string = '';
}


export class ViewStudentIDDetailsDetailsByID {
    IDCardIndentID: string = '';
}

export class ReceiveStudentIDCardMl {
    IDCardIndentTransID: string = '';
}
