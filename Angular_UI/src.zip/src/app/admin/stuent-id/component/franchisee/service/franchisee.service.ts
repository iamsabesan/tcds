import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { StudentFilterDataMl } from "src/app/shared/model/common";
import { DateRanges } from "src/app/shared/model/date-ranges";
import { StudentIDCard } from "src/app/shared/ServiceUrl";
import { IRequestType } from "src/core/model";
import { HttpService } from "src/core/service";
import { CreateStudentIdMl, ReceiveStudentIDCardMl, ViewStudentIDDetailsDetailsByID } from "../model/franchisee";

@Injectable()

export class FranchiseeService {

    public Mode = new BehaviorSubject({ Mode: 'LIST' });
    public listPageSize: any = 15;
    public listPageSkip: any = 0;

    public MllstFliterData = new DateRanges();
    public MlLstFilterStatus: any;
    public IndentDateRange = false;
    public StudentIDViewIndentID: string = '';


    constructor(private _http: HttpService) { }

    getCurrentStudent(data: StudentFilterDataMl) {
        // return this._srvHttp.get("/icloud-admission/v1/student/current/list", { params: { fromDate, toDate, courseID, courseBatchID }, RequestType: IRequestType.Protected });
        return this._http.post("/icloud-admission/v1/student/current/list", data, { RequestType: IRequestType.Protected });
    }

    postCreateStudentID(data: CreateStudentIdMl) {
        return this._http.post(StudentIDCard.postCreateStudentId, data, { RequestType: IRequestType.Protected })
    }

    getStudentIdCardLst(fromDate: string, toDate: string, status: string) {
        return this._http.get(StudentIDCard.getFrStudentIdCardList + 'fromDate=' + fromDate + '&toDate=' + toDate + '&status=' + status)
    }

    getStudentIDStatusLst() {
        return this._http.get(StudentIDCard.getStudentIDStatusList, { RequestType: IRequestType.Protected })
    }

    getStudentViewDetails(ID: string) {
        const Filter: ViewStudentIDDetailsDetailsByID = new ViewStudentIDDetailsDetailsByID();
        Filter.IDCardIndentID = ID
        return this._http.post(StudentIDCard.getStudentIDCardViewDetailsFr, Filter, { RequestType: IRequestType.Protected })
    }

    postStudentIdCardReceive(data: ReceiveStudentIDCardMl[]) {
        return this._http.post(StudentIDCard.postStudentIDCardReceive, data, { RequestType: IRequestType.Protected });
    }

}