
/* Video Type */
export const VideoType = [
    {
        id: 1,
        Type: "Theory"
    },
    {
        id: 2,
        Type: "Practical"
    },
]

/* Subject Video List  & Edit the Subject Video */
export class SubjectVideo {
    SubVideoMappingID: string = '';
    SubjectID: string = '';
    Title: string = '';
    VideoType: string = '';
    ContentUrl: string = '';
    SortOrder: string = '';
}

/* Add New Subject Video */
export class CreateSubjectVideo {
    SubjectID: string = '';
    SubVideoMappingID: string = '';
    Title: string = '';
    VideoType: string = '';
    ContentUrl: string = '';
    SortOrder: string = '';
}

/* Edit Subject Video */
export class DeleteSubjectVideo {
    SubVideoMappingID: string = ''
}