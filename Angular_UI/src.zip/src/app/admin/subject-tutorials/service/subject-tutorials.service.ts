import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { CreateSubjectVideo, DeleteSubjectVideo, SubjectVideo } from '../model/subject-tutorials';
import { Master } from 'src/app/shared/ServiceUrl';

@Injectable({
  providedIn: 'root'
})
export class SubjectTutorialsService {

  constructor(private _srvHttp: HttpService) { }

  /* Get Subject Mapped Video List */
  getSubjectVideos(SubjectID: string) {
    return this._srvHttp.get(`${Master.getSubjectVideo}${SubjectID}`, { RequestType: IRequestType.Protected });
  }

  /* Subject Mapped Video */
  mappedVideo(data: CreateSubjectVideo) {
    return this._srvHttp.post(Master.mappedVideo, data, { RequestType: IRequestType.Protected });
  }

  /* Already Mapped Video Edit */
  editSubjectVideo(editVideo: SubjectVideo) {
    return this._srvHttp.post(Master.editVideo, editVideo, { RequestType: IRequestType.Protected });
  }

  /* Delete Subject Video */
  deleteSubjectVideo(deleteVideo: DeleteSubjectVideo) {
    return this._srvHttp.post(Master.deleteVideo, deleteVideo, { RequestType: IRequestType.Protected });
  }
}
