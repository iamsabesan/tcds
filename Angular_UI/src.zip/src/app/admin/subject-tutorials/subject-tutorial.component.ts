import { Component } from "@angular/core";
import { SubjectService } from "../Subject/services/subject.service";
import { IWebError } from "src/core/model";
import { NotificationService } from "@progress/kendo-angular-notification";
import { CustomNotification } from "src/app/shared/model/shared";
import { SubjectData } from "../Subject/models/subject";
import { DropDownFilter, gridFontStyle } from "src/app/shared/app-global";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { AddEvent, CancelEvent, EditEvent, GridComponent, PagerPosition, RemoveEvent, } from "@progress/kendo-angular-grid";
import { SubjectTutorialsService } from "./service/subject-tutorials.service";
import { CreateSubjectVideo, DeleteSubjectVideo, SubjectVideo, VideoType } from "./model/subject-tutorials";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { DialogRef, DialogService } from "@progress/kendo-angular-dialog";
// import { Observable } from "rxjs";

@Component({
    selector: 'subject-tutorials',
    templateUrl: './subject-tutorial.component.html',
    styleUrls: ['./subject-tutorial.component.scss']
})

export class SubjectTutorialComponent {

    /* List */
    public LstSubject: SubjectData[] = [];
    public LstSubjectVideos: SubjectVideo[] = [];
    public LstVideoType = VideoType;
    // public LstSubjectVideos: Observable<GridDataResult> | undefined;

    /* Model */
    public MlSubjectVideo = new SubjectVideo();
    public MlCreateSubjectVideo: CreateSubjectVideo = new CreateSubjectVideo();

    /* Grid Header Style */
    public gridStyle = new gridFontStyle('medium');

    /* Grid Filter */
    public filter: CompositeFilterDescriptor;

    /* Dropdown Filter */
    public filterSettings = DropDownFilter.filterSettings;

    /* Grid Selection */
    public SubjectSelection: number[] = [0];

    /* Get SubjectID using for Create, Edit the Subject Mapped Video */
    public SubjectID: string;

    /* Grid Pagination */
    public subjectButtonCount = 5;
    public subjectSkip = 0;
    public subjectPageSize = 20;
    public subjectSizes: any[] = [20, 30, 50, 100, "All"]
    public buttonCount = 5;
    public skip = 0;
    public pageSize = 15;
    public sizes: any[] = [15, 25, 50, 100, "All"];
    public info: boolean = true;
    public previousNext: boolean = true;
    public position: PagerPosition = "bottom";
    public result: any;

    public formGroup: FormGroup;
    public editedRowIndex: number;
    constructor(private _srvSubject: SubjectService, private _srvNotification: NotificationService,
        private _srvSubjectTutorial: SubjectTutorialsService, private dialogService: DialogService) { }

    ngOnInit() {
        this.getSubject();
    }
    /* List of Subject */
    getSubject() {
        this._srvSubject.getSubjectList().subscribe({
            next: (res: any) => {
                this.LstSubject = res.Data;
                if (this.LstSubject.length !== 0) {
                    this.SubjectID = this.LstSubject[0].SubjectID;
                    this.getSubjectVideo(this.SubjectID);
                }
                // else this.LstSubjectVideos.forEach((e) => e.data = []);
            },
            error: (err: IWebError) => this.errorMsg(err.Message)
        });
    }

    /* Get Subject Mapped Videos List */
    getSubjectVideo(subjectID: string) {
        this._srvSubjectTutorial.getSubjectVideos(subjectID).subscribe({
            next: (res: any) => this.LstSubjectVideos = res.Data,
            error: (err: IWebError) => this.errorMsg(err.Message)
        });
    }

    /* Subject Selction */
    subjectSelection(event: any) {
        this.SubjectID = event.selectedRows[0].dataItem.SubjectID;
        this.getSubjectVideo(this.SubjectID);
    }

    /* New add Video */
    public addHandler({ sender }: AddEvent): void {
        this.closeEditor(sender);
        this.formGroup = createFormGroup({
            SortOrder: "",
            VideoType: "",
            Title: "",
            ContentUrl: "",
            SubjectID: this.SubjectID,
        });
        sender.addRow(this.formGroup);
    }

    /* Edit video details */
    public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
        this.closeEditor(sender);
        this.formGroup = createFormGroup(dataItem);
        this.editedRowIndex = rowIndex;
        sender.editRow(rowIndex, this.formGroup);
    }

    /* Cancle the Create and Edit video details */
    public cancelHandler({ sender, rowIndex }: CancelEvent): void {
        this.getSubjectVideo(this.SubjectID);
        this.closeEditor(sender, rowIndex);
    }

    // public saveHandler({ sender, rowIndex, dataItem }: AddEvent): void {
    //     // const product = formGroup.value;
    //     // // this.service.save(product, isNew);
    //     this.formGroup = createFormGroup(dataItem);

    //     this.MlCreateSubjectVideo.SubjectID = this.SubjectID;
    //     this.MlCreateSubjectVideo.SubVideoMappingID = dataItem.SubVideoMappingID;
    //     this.MlCreateSubjectVideo.SortOrder = dataItem.SortOrder;
    //     this.MlCreateSubjectVideo.VideoType = (typeof dataItem.VideoType == 'string') ? dataItem.VideoType : dataItem.VideoType.Type;
    //     this.MlCreateSubjectVideo.Title = dataItem.Title;
    //     this.MlCreateSubjectVideo.ContentUrl = dataItem.ContentUrl;
    //     if (!dataItem.SubVideoMappingID) {
    //         this._srvSubjectTutorial.mappedVideo(this.MlCreateSubjectVideo).subscribe({
    //             next: (res: any) => {
    //                 new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
    //                 this.getSubjectVideo(this.SubjectID);
    //                 sender.closeRow(rowIndex);
    //             },
    //             error: (err: IWebError) => this.errorMsg(err.Message)
    //         })
    //     }
    //     else {
    //         this._srvSubjectTutorial.editSubjectVideo(this.MlCreateSubjectVideo).subscribe({
    //             next: (res: any) => {
    //                 new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
    //                 this.getSubjectVideo(this.SubjectID);
    //                 sender.closeRow(rowIndex);
    //             },
    //             error: (err: IWebError) => this.errorMsg(err.Message)
    //         })
    //     }
    // }


    /* Save the Create and Edit video details */
    public saveHandler({ sender, rowIndex, dataItem }: AddEvent): void {
        // Initialize form group with the data item
        this.formGroup = createFormGroup(dataItem);

        // Validate the form
        if (this.formGroup.invalid) {
            this.formGroup.markAllAsTouched();
            this.errorMsg('Fill the details')
            return;
        }

        // Map form data to MlCreateSubjectVideo object
        this.MlCreateSubjectVideo = {
            SubjectID: this.SubjectID,
            SubVideoMappingID: dataItem.SubVideoMappingID,
            SortOrder: dataItem.SortOrder,
            VideoType: dataItem.VideoType && (typeof dataItem.VideoType === 'string') ? dataItem.VideoType : dataItem.VideoType.Type ? dataItem.VideoType.Type : '',
            Title: dataItem.Title,
            ContentUrl: dataItem.ContentUrl
        };

        // Determine the appropriate service method to call
        const serviceCall = dataItem.SubVideoMappingID
            ? this._srvSubjectTutorial.editSubjectVideo(this.MlCreateSubjectVideo)
            : this._srvSubjectTutorial.mappedVideo(this.MlCreateSubjectVideo);

        // Execute the service call and handle response
        serviceCall.subscribe({
            next: (res: any) => {
                new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                this.getSubjectVideo(this.SubjectID);
                sender.closeRow(rowIndex);
            },
            error: (err: IWebError) => {
                this.errorMsg(err.Message);
            }
        });
    }

    /* Delete video detail */
    public removeHandler({ dataItem }: RemoveEvent): void {
        const subjectVideoID = new DeleteSubjectVideo();
        subjectVideoID.SubVideoMappingID = dataItem.SubVideoMappingID;
        const dialog: DialogRef = this.dialogService.open({
            title: 'Delete Video',
            content: `Do you delete the video for the ${dataItem.Title}?`,
            actions: [
                { text: 'No' },
                { text: 'Yes', themeColor: 'primary' }
            ],
            width: 300,
            height: 150,
        });
        dialog.result.subscribe((result) => {
            this.result = result;
            if (this.result.text == "Yes") {
                this._srvSubjectTutorial.deleteSubjectVideo(subjectVideoID).subscribe({
                    next: (res) => {
                        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                        this.getSubjectVideo(this.SubjectID);
                    }, error: (err) => this.errorMsg(err.Message)
                })

            }
        })
    }

    private closeEditor(grid: GridComponent, rowIndex = this.editedRowIndex): void {
        grid.closeRow(rowIndex);
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
    }


    /* Show Error Msg */
    errorMsg(err: string) {
        new CustomNotification(this._srvNotification).ShowError(err);
    }

    public checkType(val: any): boolean {
        return typeof val == 'string'
    }

    // public category(id: number) {
    //     return this.LstVideoType.find((x) => x.id === id);
    // }
}

/* FormGroup*/
const createFormGroup = (dataItem) =>
    new FormGroup({
        SortOrder: new FormControl(dataItem.SortOrder, Validators.required),
        VideoType: new FormControl(dataItem.VideoType, Validators.required),
        Title: new FormControl(dataItem.Title, Validators.required),
        ContentUrl: new FormControl(dataItem.ContentUrl, Validators.required),
    });