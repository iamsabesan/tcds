import { NgModule } from "@angular/core";
import { SubjectTutorialComponent } from "./subject-tutorial.component";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { GridModule } from "@progress/kendo-angular-grid";
import { ButtonModule } from "@progress/kendo-angular-buttons";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { FormsModule } from "@angular/forms";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DialogsModule } from "@progress/kendo-angular-dialog";

const routes: Routes = [
    {
        path: '',
        component: SubjectTutorialComponent
    }
]

@NgModule({
    declarations: [SubjectTutorialComponent],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        LayoutModule,
        NavigationModule,
        ToolBarModule,
        GridModule,
        ButtonModule,
        FormsModule,
        IconsModule,
        DropDownsModule,
        InputsModule,
        DialogsModule,

    ],
    providers: []
})
export class SubjectTutorialsModule { }