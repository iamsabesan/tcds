export class UserDepartment{
    DepartmentID: string = "";
    DepartmentName: string = "";
    IsActive: boolean = true;
}
export class UserJobTitle{
    SlNo: number = 0;
    DesignationID: string = "";
    Designation: string = "";
    AuthRoleID: number = 0;
    Levels: any = 0;
    IsActive: boolean = true;
    ParentID: any;
    Users: UserList[] = [];
}
export class UserList{
    DesignationID: string = "";
    ContactID: string = "";
    ContactName: string = "";
    PhoneCode: string = "";
    Phone: string = "";
    Email: string = "";
    IsActive: boolean = true;
}

export class UserJTDetails{
    DepartmentID: string = "";
    DepartmentName: string = "";
    IsActive: boolean = true;
    DesignationList: UserJobTitle[] = [];
}


//** Create */
export class DepartmentCreate{
    Designation: string = "";
}

export class DesignationCreate{
    Designation: string = "";
    ParentDesignation: string = "";
}
