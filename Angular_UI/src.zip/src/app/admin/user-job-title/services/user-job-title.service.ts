import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';

import { DepartmentCreate, DesignationCreate, UserJobTitle } from '../models/user-job-title.model';

@Injectable()
export class UserJobTitleService {

  getUserJobTitleDetailsURL = "/user-service/user/get-user-job-title";
  createDeptURL = "/user-service/user/create-user-designation";

  constructor(public http: HttpService) { }

  getUserJobTitleDetails(){
    return this.http.get<UserJobTitle>(this.getUserJobTitleDetailsURL, { RequestType: IRequestType.Protected });
  }

  CreateUserDepartment(data: DepartmentCreate){
    return this.http.post(this.createDeptURL, data, { RequestType: IRequestType.Protected });
  }

  CreateUserDesignation(data: DesignationCreate){
    return this.http.post(this.createDeptURL, data, { RequestType: IRequestType.Protected });
  }

}
