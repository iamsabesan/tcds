import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { SelectionChangeEvent } from '@progress/kendo-angular-treelist';
import { UserService } from '../user/services/user.service';
import { DepartmentCreate, DesignationCreate, UserJobTitle, UserJTDetails, UserList, } from './models/user-job-title.model';
import { UserJobTitleService } from './services/user-job-title.service';
import { PagerPosition, SelectableSettings } from '@progress/kendo-angular-grid';
import { CustomNotification } from 'src/app/shared/model/shared';
import { DropDownFilter, ShowInactive } from 'src/app/shared/app-global';
import { BranchColumn, MultiDropdownColumn, ReportingToColumn, UpdateStatus } from 'src/app/shared/model/common';
import { CompositeFilterDescriptor, SortDescriptor } from '@progress/kendo-data-query';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'user-job-title',
  templateUrl: './user-job-title.component.html',
  styleUrls: ['./user-job-title.component.scss'],
})

export class UserJobTitleComponent implements OnInit {

  /* View Child */
  @ViewChild('DeptForm') DeptForm!: NgForm;
  @ViewChild('DesignationForm') DesignationForm!: NgForm;

  /* List */
  public UserJobTitleList: UserJTDetails[] = [];
  public userDesignation: UserJobTitle[] = [];
  public userList: UserList[] = [];
  public LstStoreUser: UserList[] = [];
  public ActiveDeptList: UserJTDetails[] = [];

  /* Model */
  public deptCreate: DepartmentCreate = new DepartmentCreate();
  public designationCreate: DesignationCreate = new DesignationCreate();
  public MlUpdateEmployeeStatus: UpdateStatus = new UpdateStatus();

  /* Multi-column combobox */
  public BranchColumns: MultiDropdownColumn[] = BranchColumn;
  public ReportingToColumns: MultiDropdownColumn[] = ReportingToColumn

  /* Resuse Value */
  public IsDeptDialogOpen: boolean = false;
  public IsDesignationDialogOpen: boolean = false;

  public DesignationData: UserJobTitle[] = [];
  public designationDept: string = '';
  public selectedDept: any;

  public selectableSettings!: SelectableSettings;

  setSelectableSettings(): void {
    this.selectableSettings = {
      checkboxOnly: false,
      mode: 'single',
      drag: false,
    };
  }

  /* Department & JobTitle Selection */
  public deptSelect: number[] = [0];
  public selectedJT: any[] = [{ itemKey: 1 }];

  /* Dropdown Filter */
  public filterSettings = DropDownFilter.StartWithfilterSettings;

  /* Show Active & Inactive Employee */
  public IsShowEmployee: boolean = ShowInactive.ShowInactiveEmployee;

  /* Department & JobTitle Selection ID */
  public DepartmentSelectionID: string = '';
  public JobTitleSelectionID: string = '';

  public filter!: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes: any[] = [25, 50, 100, "All"];
  public info: boolean = true;
  public previousNext: boolean = true;
  public position: PagerPosition = "bottom";

  constructor(
    private _srvJobTitle: UserJobTitleService,
    private _srvNotification: NotificationService,
    private _srvUser: UserService,
  ) {
    this.setSelectableSettings();
  }

  ngOnInit() {
    this.LoadJobTitleDetails();
  }

  /* Department */
  AddDepartment() {
    this.IsDeptDialogOpen = true;
  }

  isDeptDialogClose() {
    this.IsDeptDialogOpen = false;
    this.DeptForm.resetForm();
  }

  deptSave() {
    this._srvJobTitle.CreateUserDepartment(this.deptCreate).subscribe({
      next: (res) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
        this.LoadJobTitleDetails();
        this.isDeptDialogClose();
        this.deptCreate.Designation = '';
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Get Index */
  findIndex(DeptForm: NgForm) {
    const i = this.UserJobTitleList.map(e => e.DepartmentName === DeptForm.value.deptName).indexOf(true);
    this.deptSelect = [i];
  }

  /* Job Title */
  AddJobTitle() {
    this.IsDesignationDialogOpen = true;
  }

  LoadIndexAgentJobTitle(dep: string) {
    this._srvJobTitle.getUserJobTitleDetails().subscribe((res) => {
      this.UserJobTitleList = res.Data;
      this.ActiveDeptList = this.UserJobTitleList.filter((e) => e.IsActive === true);
      for (var i = 0; i < this.UserJobTitleList.length; i++) {
        this.UserJobTitleList[i].DesignationList.forEach((e) => e.ParentID = this.UserJobTitleList[i].DesignationList.find((f) => f.DesignationID === e.ParentID)?.SlNo);
      }
      let index = this.UserJobTitleList.findIndex((e: UserJTDetails) => e.DepartmentID === dep);
      if (this.UserJobTitleList.length !== 0 && this.UserJobTitleList[index] !== undefined) {
        this.UserJobTitleList[index].DesignationList !== undefined ? this.userDesignation = this.DesignationData = this.UserJobTitleList[index].DesignationList : '';
        this.userDesignation.length !== 0 ? this.userList = this.userDesignation[0].Users : '';
      }
    })
  }

  /* Job Title Close */
  isDesignationDialogClose() {
    this.IsDesignationDialogOpen = false;
    this.designationCreate.Designation = '';
  }

  /* Create a new job title */
  designationSave(DesignationForm: NgForm) {
    this.designationCreate.Designation = DesignationForm.value.jobtitleName;
    if (DesignationForm.value.parentDesignation === '' || DesignationForm.value.parentDesignation === undefined || DesignationForm.value.parentDesignation === null)
      this.designationCreate.ParentDesignation = DesignationForm.value.department;
    else
      this.designationCreate.ParentDesignation = DesignationForm.value.parentDesignation;

    this.LoadIndexAgentJobTitle(DesignationForm.value.department);

    this._srvJobTitle.CreateUserDesignation(this.designationCreate).subscribe({
      next: (res) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
        this.LoadIndexAgentJobTitle(DesignationForm.value.department);
        this.isDesignationDialogClose();
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  depChangeEvent(event: any) {
    this.designationCreate.ParentDesignation = '';
    if (event) {
      this.selectedDept = event;
      this._srvUser.getUserDesignation(event).subscribe((res) => this.userDesignation = res.Data.filter((e: any) => e.IsActive === true));
    }
    else this.userDesignation = [];
  }


  LoadJobTitleDetails() {
    this._srvJobTitle.getUserJobTitleDetails().subscribe({
      next: (res: any) => {
        this.UserJobTitleList = res.Data;
        if (this.UserJobTitleList.length !== 0) {
          this.DepartmentSelectionID = this.UserJobTitleList[0].DepartmentID;
          this.ActiveDeptList = this.UserJobTitleList.filter((e) => e.IsActive === true);
          for (var i = 0; i < this.UserJobTitleList.length; i++) {
            this.UserJobTitleList[i].DesignationList.forEach((e) => {
              e.ParentID = this.UserJobTitleList[i].DesignationList.find((f) => f.DesignationID === e.ParentID)?.SlNo;
            });
          }
          this.userDesignation = this.DesignationData = this.UserJobTitleList[0].DesignationList;
          if (this.userDesignation.length !== 0) {
            this.designationCreate.ParentDesignation = this.JobTitleSelectionID = this.userDesignation[0].DesignationID;

            this.userList = this.LstStoreUser = this.userDesignation[0].Users;
            this.userList = this.LstStoreUser.filter((e: UserList) => e.IsActive == true);
            this.designationDept = this.UserJobTitleList[0].DepartmentID;
          }
        }
        else this.DesignationData = this.userList = [];
      },
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  deptSelection(event: any) {
    this.DesignationData = this.userDesignation = event.selectedRows[0].dataItem.DesignationList;
    this.designationDept = this.DepartmentSelectionID = event.selectedRows[0].dataItem.DepartmentID;
    event.selectedRows[0].dataItem.DesignationList.length !== 0 ? this.designationCreate.ParentDesignation = event.selectedRows[0].dataItem.DesignationList[0].DesignationID : this.DesignationData = this.userList = [];
    if (this.DesignationData.length !== 0) {
      this.userList = this.LstStoreUser = this.DesignationData[0].Users.length !== 0 ? event.selectedRows[0].dataItem.DesignationList[0].Users : [];
      if (this.IsShowEmployee) this.userList = this.LstStoreUser;
      else this.userList = this.LstStoreUser.filter((e: UserList) => e.IsActive == true)
    }
    this.selectedJT = [{ itemKey: 1 }];
    this.userDesignation.length !== 0 ? this.designationCreate.ParentDesignation = event.selectedRows[0].dataItem.DesignationList[0].DesignationID : this.designationCreate.ParentDesignation = '';
  }

  DesignationSelection(e: SelectionChangeEvent): void {
    this.JobTitleSelectionID = e.items[0].dataItem.DesignationID;
    this.userList = this.LstStoreUser = e.items[0].dataItem.Users;
    this.designationCreate.ParentDesignation = e.items[0].dataItem.DesignationID;
    if (this.IsShowEmployee) this.userList = this.LstStoreUser;
    else this.userList = this.LstStoreUser.filter((e: UserList) => e.IsActive == true)
  }

  /**
   * Employee Component Grid (20-03-2024)
   */

  /* Active or Inactive record color */
  rowCallback(dataItem: any): string {
    if (dataItem.dataItem.IsActive == false) return 'expired';
    else return 'normal';
  }


  modeSwitcher(event: boolean) {
    this.IsShowEmployee = ShowInactive.ShowInactiveEmployee = event;
    if (!event) this.userList = this.LstStoreUser.filter((e: UserList) => e.IsActive == true);
    else this.userList = this.LstStoreUser;
  }

  btnEmployeeToggle(event: boolean, dataItem: UserList) {
    this.MlUpdateEmployeeStatus.ContactID = dataItem.ContactID;
    this.MlUpdateEmployeeStatus.Status = event;

    this._srvUser.updateEmployeeStatus(this.MlUpdateEmployeeStatus).subscribe({
      next: (res: any) => new CustomNotification(this._srvNotification).ShowSuccess(res.Data),
      error: (err: IWebError) => this.errorMsg(err.Message)
    })
  }

  /* Employee Status Update On Load Again Update Employee Status*/
  againLoadJobitle() {
    this._srvJobTitle.getUserJobTitleDetails().subscribe((res) => {
      this.UserJobTitleList = res.Data;
      if (this.UserJobTitleList.length !== 0) {
        this.ActiveDeptList = this.UserJobTitleList.filter((e) => e.IsActive === true);
        for (var i = 0; i < this.UserJobTitleList.length; i++) {
          this.UserJobTitleList[i].DesignationList.forEach((e) => {
            e.ParentID = this.UserJobTitleList[i].DesignationList.find((f) => f.DesignationID === e.ParentID)?.SlNo;
          });
        }
        this.DesignationData = this.UserJobTitleList.find((e: UserJTDetails) => e.DepartmentID == this.DepartmentSelectionID)?.DesignationList;
        this.userDesignation = this.DesignationData;
        this.userList = this.LstStoreUser = this.DesignationData.find((res: UserJobTitle) => res.DesignationID == this.JobTitleSelectionID)?.Users;
        this.designationCreate.ParentDesignation = this.userDesignation[0].DesignationID;
        if (this.IsShowEmployee) this.userList = this.LstStoreUser;
        else this.userList = this.LstStoreUser.filter((e: UserList) => e.IsActive == true)
      }
      else this.DesignationData = this.userList = [];
    })
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
