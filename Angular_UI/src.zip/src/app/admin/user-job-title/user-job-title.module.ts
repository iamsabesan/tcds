import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { IconsModule } from '@progress/kendo-angular-icons';
import { UserJobTitleService } from './services/user-job-title.service';
import { DialogService, DialogsModule } from '@progress/kendo-angular-dialog';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { UserService } from '../user/services/user.service';
import { TreeListModule } from '@progress/kendo-angular-treelist';
import { GridModule } from '@progress/kendo-angular-grid';
import { UserJobTitleComponent } from './user-job-title.component';


const routes: Routes = [
  {
    path: 'user-department',
    component: UserJobTitleComponent
  }
];

@NgModule({
  declarations: [
    UserJobTitleComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    TreeListModule,
    GridModule,
    NavigationModule,
    ToolBarModule,
    IconsModule,
    DialogsModule,
    LabelModule,
    InputsModule,
    ButtonsModule,
    DropDownsModule,
  ],
  providers: [UserJobTitleService, NotificationService, DialogService, UserService,]
})
export class UserJobTitleModule { }
// BranchService