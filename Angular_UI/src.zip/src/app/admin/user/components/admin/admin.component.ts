import { Component } from "@angular/core";
import { UserService } from "../../services/user.service";

@Component({
    selector: 'admin',
    templateUrl: './admin.component.html',
    providers: [UserService]
})
export class AdminComponent {
    public actions: string = '';

    constructor(private _srvUser: UserService) {
        this._srvUser.stfAction.subscribe(e => this.actions = e.Mode);
    }
}