import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { UserService } from '../../services/user.service';
import { UserModule } from '../../user.module';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';

const routes: Routes = [
    {
        path: '',
        component: AdminComponent,
    },
];
@NgModule({
    declarations: [
        AdminComponent,
        ListComponent,
        CreateComponent
    ],
    imports: [
        RouterModule.forChild(routes),
        UserModule,
        DatePickerModule
    ],
    providers: [UserService],
})
export class AdminModule { }