import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { StepperActivateEvent } from '@progress/kendo-angular-layout';
import { BreadCrumbItem } from '@progress/kendo-angular-navigation';
import { NotificationService } from '@progress/kendo-angular-notification';
import { addDays } from '@progress/kendo-date-math';
import { Branch } from 'src/app/admin/Accounting/models/daybook.model';
import { EmployeeCreate, EmployeeDetail, ReportingTo, UserDesignation } from 'src/app/admin/user/models/user.model';
import { UserService } from 'src/app/admin/user/services/user.service';
import { DateConversion, DropDownFilter, LocalString } from 'src/app/shared/app-global';
import { InputRegex } from 'src/app/shared/components/regex';
import { BranchColumn, Country, District, MultiDropdownColumn, PhoneCode, ReportingToColumn, State } from 'src/app/shared/model/common';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { CrazyKey } from 'src/core/helper';
import { IWebError } from 'src/core/model';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreateComponent {

  /* ViewChild */
  @ViewChild('EmployeeID') EmployeeID!: ElementRef;
  @ViewChild('EmployeeName') EmployeeName!: ElementRef;

  /* List */
  public BranchData: Branch[] = [];
  public LstStoreBranch: Branch[] = [];
  public DesignationData: UserDesignation[] = [];
  public ReportingToData: ReportingTo[] = [];
  public TempReportingTo: ReportingTo[] = [];

  /* Address */
  public LstCountry: Country[] = [];
  public LstState: State[] = [];
  public LstDistrict: District[] = [];
  public LstPermanentCountry: Country[] = [];
  public LstPermanentState: State[] = [];
  public LstPermanentDistrict: District[] = [];

  /* Model */
  public MlEmployee: EmployeeCreate = new EmployeeCreate();

  /* DropDown Column */
  public ReportingToColumns: MultiDropdownColumn[] = ReportingToColumn;
  public BranchColumns: MultiDropdownColumn[] = BranchColumn;

  /* Copy Address Checked */
  public copyAddressChecked: boolean = false;
  public isReadOnly: boolean = false;
  public showImgError: boolean = true;
  public imageSrc1: any;
  public imgclose: boolean = false;
  public FileExtension: string = "";
  public GenderValue: string = "";

  /* Title */
  public setTitle: string = 'New';
  public isLinear: boolean = true;
  public CurrentStep: number = 0;
  public oldImgSrc: any;

  /* Gender */
  public LstGender: string[] = ['Male', 'Female', 'Non-Binary'];

  /* Phone Code */
  public LstPhoneCode: PhoneCode[] = [];
  public setPhoneMaxLen: number = 10;
  public setAlternatePhoneMaxLen: number = 10;

  /* Image BaseURL */
  public baseURL: string = '';

  /* Employee Profile */
  public showError: boolean = false;

  public trueSection: boolean = false;

  public TenantID: string = '';
  public DepartmentID: string = '';
  public perDisable: boolean = false;

  /* Maximum Date */
  public maximumDate: Date = addDays(new Date(), 1);
  public DateFormat = LocalString.DateFormat;

  /* Change Button Name */
  public btnSave: string = 'Save';

  /* Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Password */
  public MainPassword: boolean =true;
  public ConfirmPassword: boolean=true;
  public ShowError: boolean = false;
  public showMsg: boolean = false;

  /* Pattern */
  public Email = InputRegex.Email;
  public Mobile = InputRegex.Mobile;
  public Pincode = /^(6)?[1-9][0-9]{5}$/;
  public PasswordRegex = InputRegex.Password;

  /* Is Show or Not Password Component */
  public IsHidePassword: boolean = true;

  /* Address Select Value */
  public selectedCountry: any;
  public selectedState: any;
  public selectedDistrict: any;

  public permenantselectedCountry: any;
  public permenantselectedState: any;
  public permenantselectedDistrict: any;

  /* FormGroup */
  FrmEntry = new FormGroup({
    EmployeeDetails: this.fb.group({
      EmployeeID: new FormControl('', [Validators.minLength(3), Validators.maxLength(15)]),
      EmployeeName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      Gender: new FormControl('', [Validators.required]),
      Email: new FormControl('', [Validators.required, Validators.pattern(this.Email)]),
      DateOfBirth: new FormControl(new Date(), [Validators.required]),
      DateOfJoining: new FormControl(new Date(), [Validators.required,]),
      PhoneCode: new FormControl({ PhoneCode: '+91' }, [Validators.required]),
      Phone: new FormControl('', [Validators.required]),
      AlternatePhoneCode: new FormControl({ PhoneCode: '+91' }),
      AlternatePhone: new FormControl(''),
      JobTitle: new FormControl('', [Validators.required]),
      ReportTo: new FormControl(''),
      Password: new FormControl('', [Validators.required]),
      ConfirmPassword: new FormControl('', [Validators.required]),
    }),
    AddressDetails: this.fb.group({
      Address1: new FormControl('',),
      Address2: new FormControl(''),
      Area: new FormControl(''),
      Country: new FormControl(null),
      State: new FormControl(new State()),
      District: new FormControl(new District()),
      Pincode: new FormControl(''),

      PermanentAddress1: new FormControl('',),
      PermanentAddress2: new FormControl(''),
      PermanentArea: new FormControl(''),
      PermanentCountry: new FormControl(null,),
      PermanentState: new FormControl(new State()),
      PermanentDistrict: new FormControl(new District()),
      PermanentPincode: new FormControl(''),
    })
  })

  constructor(private _srvUser: UserService,
    public fb: FormBuilder, private _srvNotification: NotificationService,
    private _srvCommon: CommonService,
    private _appConfigService: AppConfigService,
  ) { }

  public title: BreadCrumbItem[] = [
    { text: "Employees" },
    { text: "Create" }
  ]

  onItemClick(item: BreadCrumbItem) {
    if (item.text == "Employees") this.btnGoBack();
  }

  ngOnInit() {
    setTimeout(() => {
      this.EmployeeID.nativeElement.focus();
    }, 100);

    this.loadInitialData();
    this.maximumDate = new Date();

    this.imageSrc1 = '/assets/logo/img_avatar.png';
    this.baseURL = CrazyKey.decrypt(this._appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
    this.IsHidePassword = true;
    this.FrmEntry.reset();
    this.FrmEntry.controls['EmployeeDetails'].controls['DateOfBirth'].setValue(null);
    this.FrmEntry.controls['EmployeeDetails'].controls['DateOfJoining'].setValue(new Date());

    if (this._srvUser.IsCreate == 'Update') {
      setTimeout(() => {
        this.EmployeeName.nativeElement.focus();
      }, 100);
      this.isReadOnly = true;
      this.setTitle = 'Edit';
      this.btnSave = 'Update';
      this._srvUser.getEmployeeByID(this._srvUser.ContactID).subscribe({
        next: (res: any) => this.formGroupValueBinding(res.Data),
        error: (err: IWebError) => this.errorMsg(err.Message)
      })
    }
    this.maximumDate =  addDays(new Date(), 2)
  }

  loadInitialData() {

    /* Branch */
    this._srvCommon.getBranchList().subscribe({
      next: (res: any) => this.BranchData = this.LstStoreBranch = res.Data.filter((e: any) => e.IsActive == true),
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Phone Code */
    this._srvCommon.getPhoneCode().subscribe({
      next: (res: any) => {
        this.LstPhoneCode = res.Data;
        const IndianPhoneCode = this.LstPhoneCode.find((e) => e.PhoneCode == '+91')?.PhoneCode;
        this.FrmEntry.controls['EmployeeDetails'].controls['PhoneCode'].setValue({ PhoneCode: IndianPhoneCode });
        this.FrmEntry.controls['EmployeeDetails'].controls['AlternatePhoneCode'].setValue({ PhoneCode: IndianPhoneCode });
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Country */
    this._srvCommon.getLstCountry().subscribe({
      next: (res: any) => this.LstCountry = this.LstPermanentCountry = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });

    /* Designation */
    this.getDesignationList();


    /* Reporting To */
    this._srvUser.getReportingToList().subscribe({
      next: (response) => {
        this.TempReportingTo = response.Data;
        this.ReportingToData = this.TempReportingTo.filter((e) => e.TenantBranchID == LocalString.TenantBranchID)
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Designation */
  getDesignationList() {
    this._srvUser.getDesignation().subscribe({
      next: (res: any) => this.DesignationData = res.Data,
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  formGroupValueBinding(data: EmployeeDetail) {
    this.MlEmployee.ContactID = data.ContactID;
    this.FrmEntry.controls['EmployeeDetails'].controls['EmployeeID'].setValue(data.ContactCode);
    this.FrmEntry.controls['EmployeeDetails'].controls['EmployeeName'].setValue(data.ContactName);
    this.FrmEntry.controls['EmployeeDetails'].controls['Email'].setValue(data.Email);
    this.FrmEntry.controls['EmployeeDetails'].controls['Gender'].setValue(data.Gender);

    data.DateOfBirthI18 == null ? new Date() : this.FrmEntry.controls['EmployeeDetails'].controls['DateOfBirth'].setValue(DateConversion.ConvertStringToDate(data.DateOfBirthI18));
    data.DateOfJoiningI18 == null ? new Date() : this.FrmEntry.controls['EmployeeDetails'].controls['DateOfJoining'].setValue(DateConversion.ConvertStringToDate(data.DateOfJoiningI18));

    this.FrmEntry.controls['EmployeeDetails'].controls['PhoneCode'].setValue({ PhoneCode: data.PhoneCode });
    this.FrmEntry.controls['EmployeeDetails'].controls['Phone'].setValue(data.Phone);
    this.FrmEntry.controls['EmployeeDetails'].controls['AlternatePhoneCode'].setValue({ PhoneCode: data.AlternatePhoneCode });
    this.FrmEntry.controls['EmployeeDetails'].controls['AlternatePhone'].setValue(data.AlternatePhone);

    this.imageSrc1 = this.oldImgSrc = `${this.baseURL}${data.PictureUrl}${LocalString.TenantID}/${data.ContactID}`;
    data.PictureUrl !== '' ? this.MlEmployee.ProfilePicture.length = 1 : (this.MlEmployee.ProfilePicture = []) && (this.imageSrc1 = "/assets/logo/img_avatar.png");


    setTimeout(() => {
      this.FrmEntry.controls['EmployeeDetails'].controls['JobTitle'].setValue(data.JobTitleID);
      this.getDesignationList();

      if (data.ReportingToParentID == null || data.ReportingToParentID == "" || data.ReportingToParentID == "00000000-0000-0000-0000-000000000000") this.FrmEntry.controls['EmployeeDetails'].controls['ReportTo'].setValue(null);
      else this.FrmEntry.controls['EmployeeDetails'].controls['ReportTo'].setValue(data.ReportingToParentID);
    }, 200);

    this.hidePassword();
    this.communicationAddress(data);
    this.permanentAddress(data);
    this.compareAddress(data);
  }

  /* Communuication address set value for formgroup */
  communicationAddress(data: EmployeeDetail) {
    if (data.CommCountry == "" || data.CommCountry == null) { }
    else {
      this._srvCommon.getLstCountry().subscribe((res) => {
        this.LstCountry = res.Data;
        this.selectedCountry = this.LstCountry.find((e) => e.CountryName == data.CommCountry) ?? new Country();
        this.FrmEntry.controls['AddressDetails'].controls['Country'].setValue(this.selectedCountry);

        this._srvCommon.getLstState(this.selectedCountry.CountryID).subscribe((res) => {
          this.LstState = res.Data;
          this.selectedState = this.LstState.find((e) => e.StateProvinceName == data.CommState) ?? new State();
          this.FrmEntry.controls['AddressDetails'].controls['State'].setValue(this.selectedState);

          this._srvCommon.getLstDistrict(this.selectedState.StateProvinceID).subscribe((res) => {
            this.LstDistrict = res.Data;
            this.selectedDistrict = this.LstDistrict.find((e) => e.DistrictName == data.CommDistrict) ?? new District();
            this.FrmEntry.controls['AddressDetails'].controls['District'].setValue(this.selectedDistrict);
          });
        });
      });
      setTimeout(() => {
        this.FrmEntry.controls['AddressDetails'].controls['Address1'].setValue(data.CommAddress1);
        this.FrmEntry.controls['AddressDetails'].controls['Address2'].setValue(data.CommAddress2);
        this.FrmEntry.controls['AddressDetails'].controls['Area'].setValue(data.CommArea);
        this.FrmEntry.controls['AddressDetails'].controls['Pincode'].setValue(data.CommPinCode);
      }, 300);

    }
  }

  /* Permanent address set value for formgroup */
  permanentAddress(data: EmployeeDetail) {
    if (data.PermCountry == "" || data.PermCountry == null) { }
    else {
      this._srvCommon.getLstCountry().subscribe((res) => {
        this.LstPermanentCountry = res.Data;
        this.permenantselectedCountry = this.LstCountry.find((e) => e.CountryName == data.PermCountry) ?? new Country();
        this.FrmEntry.controls['AddressDetails'].controls['PermanentCountry'].setValue(this.permenantselectedCountry);

        this._srvCommon.getLstState(this.permenantselectedCountry.CountryID).subscribe((res) => {
          this.LstPermanentState = res.Data;
          this.permenantselectedState = this.LstPermanentState.find((e) => e.StateProvinceName == data.PermState) ?? new State();
          this.FrmEntry.controls['AddressDetails'].controls['PermanentState'].setValue(this.permenantselectedState);

          this._srvCommon.getLstDistrict(this.permenantselectedState.StateProvinceID).subscribe((res) => {
            this.LstPermanentDistrict = res.Data;
            this.permenantselectedDistrict = this.LstPermanentDistrict.find((e) => e.DistrictName == data.PermDistrict) ?? new District();
            this.FrmEntry.controls['AddressDetails'].controls['PermanentDistrict'].setValue(this.permenantselectedDistrict);
          });
        });
      });

      setTimeout(() => {
        this.FrmEntry.controls['AddressDetails'].controls['PermanentAddress1'].setValue(data.PermAddress1);
        this.FrmEntry.controls['AddressDetails'].controls['PermanentAddress2'].setValue(data.PermAddress2);
        this.FrmEntry.controls['AddressDetails'].controls['PermanentArea'].setValue(data.PermArea);
        this.FrmEntry.controls['AddressDetails'].controls['PermanentPincode'].setValue(data.PermPinCode);
      }, 300)
    }
  }

  /* Address Compare */
  compareAddress(data: EmployeeDetail) {
    if (data.CommAddress1 !== "" && data.PermAddress1 !== "") {
      if (data.CommAddress1 === data.PermAddress1 && data.CommAddress2 === data.PermAddress2 &&
        data.CommArea === data.PermArea && data.CommCountry === data.PermCountry &&
        data.CommState === data.PermState && data.CommDistrict === data.PermDistrict && data.CommPinCode === data.PermPinCode) {
        this.copyAddressChecked = this.perDisable = true;
      }
      else this.copyAddressChecked = false;
    }
    else {
      this.FrmEntry.controls['AddressDetails'].reset();
      this.copyAddressChecked = this.perDisable = false;
    }
  }

  /* PassWord Component Hide */
  hidePassword() {
    this.IsHidePassword = false;
    this.FrmEntry.controls['EmployeeDetails'].controls['Password'].clearValidators();
    this.FrmEntry.controls['EmployeeDetails'].controls['Password'].updateValueAndValidity();
    this.FrmEntry.controls['EmployeeDetails'].controls['ConfirmPassword'].clearValidators();
    this.FrmEntry.controls['EmployeeDetails'].controls['ConfirmPassword'].updateValueAndValidity();
  }

  /* Step validation */
  private getGroupAt(index: number): FormGroup {
    const groups = Object.keys(this.FrmEntry.controls).map((groupName) =>
      this.FrmEntry.get(groupName)
    ) as FormGroup[];
    return groups[index];
  }

  public get currentGroup(): FormGroup {
    return this.getGroupAt(this.CurrentStep);
  }

  private isStepValid = (index: number): boolean => {
    return this.getGroupAt(index).valid || this.currentGroup.untouched;
  };

  private shouldValidate = (index: number): boolean => {
    return this.getGroupAt(index).touched && this.CurrentStep >= index;
  };

  public stepActivate(e: StepperActivateEvent) {
    if (!this.currentGroup.valid) {
      e.preventDefault();
      this.currentGroup.markAllAsTouched();
    }
  }

  /* steps */
  public steps = [
    {
      label: 'Employee Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
    },
    {
      label: 'Address Details',
      isValid: this.isStepValid,
      validate: this.shouldValidate,
    }
  ];

  public UserHierarchyLevel: number = 0;
  public reportingToDisable = false

  GetuserDesignation(data: any) {
    this.DesignationData = this.ReportingToData = [];
    this.FrmEntry.controls['EmployeeDetails'].controls['JobTitle'].setValue(null);
    this.FrmEntry.controls['EmployeeDetails'].controls['ReportTo'].setValue(null);
    if (data) {
      this._srvUser.getUserDesignation(data).subscribe((res) => {
        this.DesignationData = res.Data.filter((e: any) => e.IsActive === true);
      });
    }
  }

  GetReportingTo(data: any) {
    this.FrmEntry.controls['EmployeeDetails'].controls['ReportTo'].setValue(null);
    if (data) {
      const JobTitle = this.DesignationData.find((e) => e.DesignationID == data);
      this.MlEmployee.AuthRoleID = JobTitle.AuthRoleID;
      this.MlEmployee.ContactType = JobTitle.Designation;
      this.UserHierarchyLevel = this.DesignationData.filter((e) => e.DesignationID === data)[0].Levels;
    }
  }

  /* Reporting To Filter */
  reportFilter(searchTerm: string) {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.ContactName.toLowerCase().includes(normalizedQuery) ||
      data.Phone.toLowerCase().includes(normalizedQuery) ||
      data.JobTitle.toLowerCase().includes(normalizedQuery) ||
      data.Department.toLowerCase().includes(normalizedQuery);
    this.ReportingToData = this.TempReportingTo.filter(filterExpression);
  }

  /* Branch Filter */
  public branchNameFilter(searchTerm: string) {
    const normalizedQuery = searchTerm.toLowerCase();
    const filterExpression = (data: any) =>
      data.TenantBranchName.toLowerCase().includes(normalizedQuery) ||
      data.District.toLowerCase().includes(normalizedQuery) ||
      data.State.toLowerCase().includes(normalizedQuery);
    this.BranchData = this.LstStoreBranch.filter(filterExpression);
  }

  onNumberOnlyInput(event: Event) {
    const input = event.target as HTMLInputElement;
    const transformedValue = input.value.replace(/[^0-9]/g, ''); // Only allow digits
    input.value = transformedValue;
    return transformedValue
  }

  mobileNumberOnChange(event: Event) {
    this.FrmEntry.controls.EmployeeDetails.controls.Phone.setValue(this.onNumberOnlyInput(event), { emitEvent: false })
  }

  alternateMobileNumberOnChange(event: Event) {
    this.FrmEntry.controls.EmployeeDetails.controls.AlternatePhone.setValue(this.onNumberOnlyInput(event), { emitEvent: false })
  }

  /* Password */
  Password() {
    this.MainPassword = !this.MainPassword;
  }

  cpassword() {
    this.ConfirmPassword = !this.ConfirmPassword;
  }

  public isMatchPassword: boolean = true;
  conPass() {
    const Password = this.FrmEntry.controls['EmployeeDetails'].controls['Password'].value;
    const ConfirmPassword = this.FrmEntry.controls['EmployeeDetails'].controls['ConfirmPassword'].value;
    this.isMatchPassword = Password === ConfirmPassword;
    this.showMsg = this.isMatchPassword == true ? false : true;

    // this.FrmEntry.controls['EmployeeDetails'].controls['Password'].value !== data ? this.showMsg = true : this.showMsg = false;
  }

  /* Get File Extension */
  getFileNameWithExt(event: any) {
    if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf(".");
    const ext = name.substring(lastDot + 1);
    this.FileExtension = ext;
  }

  /* Upload Employee Profile Image */
  uploadEmployeeProfile(event: any) {
    this.getFileNameWithExt(event);
    if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png") {
      const reader = new FileReader();
      if (event.target.files && event.target.files.length) {
        if (event.target.files[0].size >= 2097152) this.errorMsg("Profile picture size is larger than 2 MB");
        else {
          const [file] = event.target.files;
          this.MlEmployee.ProfilePicture.pop();
          this.MlEmployee.ProfilePicture.push(file);
          this.MlEmployee.ProfilePicture.length !== 0 ? this.showError = false : this.showError = true;
          reader.readAsDataURL(file);
          reader.onload = () => {
            this.imageSrc1 = this.oldImgSrc = reader.result;
          };
          this.imgclose = true;
        }
      }
    }
    else {
      this.showError = true;
      this.imgclose = this.showImgError = false;
      this.MlEmployee.ProfilePicture = [];
      this.imageSrc1 = '/assets/logo/img_avatar.png'
    }
  }

  /* Communication Address Country Event  */
  countryChangeEvent(data: Country) {
    this.LstState = this.LstDistrict = [];
    this.FrmEntry.controls['AddressDetails'].controls['State'].setValue(null);
    this.FrmEntry.controls['AddressDetails'].controls['District'].setValue(null);

    if (data) {
      this._srvCommon.getLstState(data.CountryID).subscribe({
        next: (res: any) => this.LstState = res.Data,
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Communication Address State Event */
  stateChangeEvent(data: State) {
    this.LstDistrict = [];
    this.FrmEntry.controls['AddressDetails'].controls['District'].setValue(null);
    if (data) {
      this._srvCommon.getLstDistrict(data.StateProvinceID).subscribe({
        next: (res: any) => this.LstDistrict = res.Data,
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Copy Communication Address --> Permanent Address */
  copyAddress(event: any) {
    if (event.target.checked === true) {
      this.LstPermanentCountry = this.LstCountry;
      this.LstPermanentState = this.LstState;
      this.LstPermanentDistrict = this.LstDistrict;

      this.currentGroup.controls['PermanentAddress1'].setValue(this.currentGroup.controls['Address1'].value);
      this.currentGroup.controls['PermanentAddress2'].setValue(this.currentGroup.controls['Address2'].value);
      this.currentGroup.controls['PermanentArea'].setValue(this.currentGroup.controls['Area'].value);
      this.currentGroup.controls['PermanentCountry'].setValue(this.currentGroup.controls['Country'].value);
      this.currentGroup.controls['PermanentState'].setValue(this.currentGroup.controls['State'].value);
      this.currentGroup.controls['PermanentDistrict'].setValue(this.currentGroup.controls['District'].value);
      this.currentGroup.controls['PermanentPincode'].setValue(this.currentGroup.controls['Pincode'].value);
      this.perDisable = this.copyAddressChecked = true;
    }
    else {
      this.LstPermanentState = this.LstPermanentDistrict = [];
      this.perDisable = this.copyAddressChecked = false;
      this.FrmEntry.controls['AddressDetails'].controls['PermanentAddress1'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentAddress2'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentArea'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentCountry'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentDistrict'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentState'].setValue(null);
      this.FrmEntry.controls['AddressDetails'].controls['PermanentPincode'].setValue(null);
    }
  }

  /* Permenant Address Country Event */
  permenantCountryEvent(data: Country) {
    this.FrmEntry.controls['AddressDetails'].controls['PermanentState'].setValue(null);
    this.FrmEntry.controls['AddressDetails'].controls['PermanentDistrict'].setValue(null);

    this.LstPermanentState = this.LstPermanentDistrict = [];
    if (data) {
      this._srvCommon.getLstState(data.CountryID).subscribe({
        next: (res: any) => this.LstPermanentState = res.Data,
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Permenant Address State Event */
  permenantStateEvent(data: State) {
    this.LstPermanentDistrict = [];
    this.FrmEntry.controls['AddressDetails'].controls['PermanentDistrict'].setValue(null);

    if (data) {
      this._srvCommon.getLstDistrict(data.StateProvinceID).subscribe({
        next: (res: any) => this.LstPermanentDistrict = res.Data,
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Go Back to List */
  btnGoBack() {
    this._srvUser.Mode.next({ Mode: 'LIST' });
    this.FrmEntry.reset();
  }

  /* Go to Previous Step */
  btnPrevious() {
    this.CurrentStep -= 1;
  }

  /* Go to Next Step */
  btnNext() {
    if (!this.isMatchPassword) this.errorMsg("Password & confirm password are mismatching");

    else if ((this.currentGroup.valid && this.CurrentStep !== this.steps.length && this.MlEmployee.ProfilePicture.length !== 0 && this.btnSave === 'Save')) {
      this.CurrentStep += 1;
      this.showError = false;
      return;
    }
    else if ((this.currentGroup.valid && this.CurrentStep !== this.steps.length && this.btnSave === 'Update' && this.showError === false)) {
      this.CurrentStep += 1;
      this.showError = false;
      return;
    }
    else if ((this.currentGroup.valid && this.CurrentStep !== this.steps.length && this.btnSave === 'Save' && this.MlEmployee.ProfilePicture.length == 0)) {
      this.showError = true;
    }

    this.currentGroup.markAllAsTouched();
  }

  /* Copy of FrmValue to Model */
  cpyFrmValue(FrmValue: any) {
    const EmployeeDetails = FrmValue.EmployeeDetails;
    const AddressDetails = FrmValue.AddressDetails;

    /* Employee Details */
    this.MlEmployee.EmployeeID = EmployeeDetails.EmployeeID;
    this.MlEmployee.EmployeeName = EmployeeDetails.EmployeeName;
    this.MlEmployee.Gender = EmployeeDetails.Gender;
    this.MlEmployee.Email = EmployeeDetails.Email;
    this.MlEmployee.DateOfBirth = DateConversion.ConvertToYearMonthDate(EmployeeDetails.DateOfBirth);
    this.MlEmployee.DateOfJoining = DateConversion.ConvertToYearMonthDate(EmployeeDetails.DateOfJoining)
    this.MlEmployee.PhoneCode = EmployeeDetails.PhoneCode.PhoneCode;
    this.MlEmployee.Phone = EmployeeDetails.Phone;
    this.MlEmployee.AlternatePhoneCode = EmployeeDetails.AlternatePhoneCode.PhoneCode;
    this.MlEmployee.AlternatePhone = EmployeeDetails.AlternatePhone;
    this.MlEmployee.PassWord = EmployeeDetails.Password;
    this.MlEmployee.ConfirmPassWord = EmployeeDetails.ConfirmPassword;

    // if (typeof EmployeeDetails.Branch === 'string') this.MlEmployee.BranchID = EmployeeDetails.Branch;
    // else this.MlEmployee.BranchID = EmployeeDetails.Branch.TenantBranchID;
    this.MlEmployee.BranchID = LocalString.TenantBranchID;

    this.MlEmployee.DepartmentID = "5fefecda-f010-40d4-870a-096df35d6466";
    // if (typeof EmployeeDetails.Department === 'string') this.MlEmployee.DepartmentID = EmployeeDetails.Department;
    // else this.MlEmployee.DepartmentID = EmployeeDetails.Department.DepartmentID;

    if (typeof EmployeeDetails.JobTitle === 'string') this.MlEmployee.JobTitleID = EmployeeDetails.JobTitle;
    else {
      this.MlEmployee.JobTitleID = EmployeeDetails.JobTitle.JobTitleID;
      this.MlEmployee.AuthRoleID = EmployeeDetails.JobTitle.AuthRoleID;
    }

    if (typeof EmployeeDetails.ReportTo === 'string') this.MlEmployee.ReportToParentID = EmployeeDetails.ReportTo;
    else if (EmployeeDetails.ReportTo === null || EmployeeDetails.ReportTo === undefined) this.MlEmployee.ReportToParentID = '00000000-0000-0000-0000-000000000000';
    else this.MlEmployee.ReportToParentID = EmployeeDetails.ReportTo.ContactID;

    if (this.IsAddressNull) {
      /* Address */
      this.MlEmployee.CommunicationAddress.Address1 = AddressDetails.Address1;
      this.MlEmployee.CommunicationAddress.Address2 = AddressDetails.Address2 !== null ? AddressDetails.Address2 : "";
      this.MlEmployee.CommunicationAddress.Area = AddressDetails.Area;

      if (typeof AddressDetails.Country === "string") this.MlEmployee.CommunicationAddress.Country = AddressDetails.Country;
      else this.MlEmployee.CommunicationAddress.Country = AddressDetails.Country.CountryName;

      if (typeof AddressDetails.State === "string") this.MlEmployee.CommunicationAddress.State = AddressDetails.State;
      else this.MlEmployee.CommunicationAddress.State = AddressDetails.State.StateProvinceName;

      if (typeof AddressDetails.District === "string") this.MlEmployee.CommunicationAddress.District = AddressDetails.District;
      else this.MlEmployee.CommunicationAddress.District = AddressDetails.District.DistrictName;

      this.MlEmployee.CommunicationAddress.PinCode = AddressDetails.Pincode;

      this.MlEmployee.PermanentAddress.Address1 = AddressDetails.PermanentAddress1;
      this.MlEmployee.PermanentAddress.Address2 = AddressDetails.PermanentAddress2 !== null ? AddressDetails.PermanentAddress2 : "";
      this.MlEmployee.PermanentAddress.Area = AddressDetails.PermanentArea;

      if (typeof AddressDetails.PermanentCountry === "string") this.MlEmployee.PermanentAddress.Country = AddressDetails.PermanentCountry;
      else this.MlEmployee.PermanentAddress.Country = AddressDetails.PermanentCountry.CountryName;

      if (typeof AddressDetails.PermanentState === "string") this.MlEmployee.PermanentAddress.State = AddressDetails.PermanentState;
      else this.MlEmployee.PermanentAddress.State = AddressDetails.PermanentState.StateProvinceName;

      if (typeof AddressDetails.PermanentDistrict === "string") this.MlEmployee.PermanentAddress.District = AddressDetails.PermanentDistrict;
      else this.MlEmployee.PermanentAddress.District = AddressDetails.PermanentDistrict.DistrictName;

      this.MlEmployee.PermanentAddress.PinCode = AddressDetails.PermanentPincode;
    }
  }

  /* Address Section Validation */
  validatorAddress() {
    this.FrmEntry.controls.AddressDetails.controls.Address1.setValidators([Validators.required, Validators.minLength(2)]);
    this.FrmEntry.controls.AddressDetails.controls.Address1.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.Area.setValidators([Validators.required, Validators.minLength(2)]);
    this.FrmEntry.controls.AddressDetails.controls.Area.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.Country.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.Country.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.State.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.State.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.District.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.District.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.Pincode.setValidators([Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(this.Pincode),]);
    this.FrmEntry.controls.AddressDetails.controls.Pincode.updateValueAndValidity();

    this.FrmEntry.controls.AddressDetails.controls.PermanentAddress1.setValidators([Validators.required, Validators.minLength(2)]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentAddress1.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.PermanentArea.setValidators([Validators.required, Validators.minLength(2)]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentArea.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.PermanentCountry.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentCountry.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.PermanentState.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentState.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.PermanentDistrict.setValidators([Validators.required]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentDistrict.updateValueAndValidity();
    this.FrmEntry.controls.AddressDetails.controls.PermanentPincode.setValidators([Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(this.Pincode),]);
    this.FrmEntry.controls.AddressDetails.controls.PermanentPincode.updateValueAndValidity();

    this.FrmEntry.controls.AddressDetails.markAllAsTouched();
  }

  /* Address Section Clear Validation */
  FrmClearValidator(data: string) {
    this.FrmEntry.controls['AddressDetails'].controls[data].clearValidators();
    this.FrmEntry.controls['AddressDetails'].controls[data].updateValueAndValidity();
  }

  clearValidators() {
    this.FrmClearValidator('Address1');
    this.FrmClearValidator('Area');
    this.FrmClearValidator('Country');
    this.FrmClearValidator('State');
    this.FrmClearValidator('District');
    this.FrmClearValidator('Pincode');

    this.FrmClearValidator('PermanentAddress1');
    this.FrmClearValidator('PermanentArea');
    this.FrmClearValidator('PermanentCountry');
    this.FrmClearValidator('PermanentState');
    this.FrmClearValidator('PermanentDistrict');
    this.FrmClearValidator('PermanentPincode');
  }

  ngDoCheck() {
    if (this.CurrentStep == 1) {
      const FrmValue = this.FrmEntry.controls.AddressDetails.value;
      if (FrmValue.Address1 || FrmValue.Area || FrmValue.Country || FrmValue.State || FrmValue.District || FrmValue.Pincode || FrmValue.PermanentAddress1 || FrmValue.PermanentArea || FrmValue.PermanentArea || FrmValue.PermanentCountry || FrmValue.PermanentState || FrmValue.PermanentDistrict || FrmValue.PermanentPincode) { }
      else this.clearValidators();
    }
  }
  /* Create & Edit a Employee */
  public IsAddressNull: boolean = false;
  btnFrmSubmit(FrmEntry: FormGroup) {
    const FrmValue = this.FrmEntry.controls.AddressDetails.value;
    if (FrmValue.Address1 || FrmValue.Area || FrmValue.Country || FrmValue.State || FrmValue.District || FrmValue.Pincode || FrmValue.PermanentAddress1 || FrmValue.PermanentArea || FrmValue.PermanentArea || FrmValue.PermanentCountry || FrmValue.PermanentState || FrmValue.PermanentDistrict || FrmValue.PermanentPincode) {
      this.validatorAddress();
      this.IsAddressNull = true;
      if (this.FrmEntry.status == "VALID") {
        this.cpyFrmValue(FrmEntry.value);
        this.FrmSubmit();
      }
    }

    else {
      this.IsAddressNull = false;
      this.cpyFrmValue(FrmEntry.value);
      this.FrmSubmit();
    }
  }

  /* Employee Submit */
  FrmSubmit() {
    if (this.btnSave === 'Save') {
      this._srvUser.franchiseeCreateEmployee(this.MlEmployee, "Create", this.IsAddressNull).subscribe({
        next: (res: any) => {
          this.successMsg(res.Message);
          this.btnGoBack();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      })
    }
    else if (this.btnSave === 'Update' && this.showError === false) {
      this._srvUser.franchiseeCreateEmployee(this.MlEmployee, "Update", this.IsAddressNull).subscribe({
        next: (res: any) => {
          this.successMsg(res.Message);
          this.btnGoBack();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      })
    }
  }

  /* Skip the address section */
  // btnSkip() {
  //   this.cpyFrmValue(this.FrmEntry.value, "Skip");
  //   if (this.btnSave === 'Save') {
  //     this._srvUser.createEmployee(this.MlEmployee, "Create", true).subscribe({
  //       next: (res: any) => {
  //         this.successMsg(res.Message);
  //         this.btnGoBack();
  //       },
  //       error: (err: IWebError) => this.errorMsg(err.Message)
  //     })
  //   }
  //   else if (this.btnSave === 'Update') {
  //     this._srvUser.createEmployee(this.MlEmployee, "Update", true).subscribe({
  //       next: (res: any) => {
  //         this.successMsg(res.Message);
  //         this.btnGoBack();
  //       },
  //       error: (err: IWebError) => this.errorMsg(err.Message)
  //     })
  //   }
  // }


  /* Show Success Msg */
  successMsg(res: string) {
    new CustomNotification(this._srvNotification).ShowSuccess(res);
  }
  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
