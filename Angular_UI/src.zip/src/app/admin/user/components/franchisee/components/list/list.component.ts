import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PageChangeEvent, PagerPosition } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { Align } from '@progress/kendo-angular-popup';
import { CompositeFilterDescriptor, SortDescriptor } from '@progress/kendo-data-query';
import { ResetPassword, UserList } from 'src/app/admin/user/models/user.model';
import { UserService } from 'src/app/admin/user/services/user.service';
import { ShowInactive, UserListType } from 'src/app/shared/app-global';
import { InputRegex } from 'src/app/shared/components/regex';
import { UpdateStatus } from 'src/app/shared/model/common';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})

export class ListComponent {

  /* List */
  public LstStoreEmployee: UserList[] = [];
  public LstActiveEmployee: UserList[] = [];
  public LstEmployee: UserList[] = [];

  /* Model */
  public MlResetPassword: ResetPassword = new ResetPassword();
  public MlUpdateEmployeeStatus: UpdateStatus = new UpdateStatus();

  public ContactName: string = '';
  public checked = ShowInactive.ShowInactiveUser;

  /* Dialog Open */
  public IsResetPasswordDialogOpen: boolean = false;

  // /* Pattern */
  public PasswordRegex = InputRegex.Password;

  /* Grid */
  public filter: CompositeFilterDescriptor;
  public sort: SortDescriptor[] = [];

  /* Grid Pagination */
  public buttonCount = 5;
  public sizes: any[] = [15, 25, 50, 100, "All"];
  public info = true;
  public previousNext = true;
  public position: PagerPosition = "bottom";
  public pageSize: number = 15;
  public skip: number = 0;

  /* Menu Option */
  public anchorAlign: Align = { horizontal: 'right', vertical: 'bottom' };
  public popupAlign: Align = { horizontal: 'right', vertical: 'top' };

  public showMsg: boolean = false;

  /* Grid and Card View */
  public TableSelected: boolean = false;
  public ListSelected: boolean = false;
  public selectedList: string = '';
  public selectedTable: string = '';
  public listType = UserListType.ActiveListType;

  public PasswordHint = ' password (Eg :Test@123)'

  constructor(private _srvUser: UserService, private _srvCommon: CommonService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.ContactName = this._srvUser.ContactName;

    if (this._srvUser.IsPagination) {
      this.pageSize = this._srvUser.employee_list_pageSize;
      this.skip = this._srvUser.employee_list_skip;
    }

    this.getUserList();
    this.ListType(UserListType.ActiveListType);
  }

  /** Filter the contact name in the card view, then navigate to the create component and 
   * return to the list component to display the same data
   */
  getContactName(event: string) {
    this._srvUser.ContactName = event;
  }

  /* Get Employees List */
  getUserList() {
    this._srvCommon.getEmployees().subscribe({
      next: (response) => {
        this.LstStoreEmployee = response.Data;
        this.LstActiveEmployee = this.LstStoreEmployee.filter((e) => e.IsActive == true);
        if (ShowInactive.ShowInactiveUser == true) this.LstEmployee = this.LstStoreEmployee;
        else this.LstEmployee = this.LstActiveEmployee;
      },
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  /* Grid or Card View */
  ListType(data: string) {
    if (data == 'Grid') {
      UserListType.ActiveListType = this.listType = 'Grid';
      this.TableSelected = true;
      this.ListSelected = false;
      this.selectedTable = 'selected-icon';
      this.selectedList = '';
    } else {
      UserListType.ActiveListType = this.listType = 'List';
      this.TableSelected = false;
      this.ListSelected = true;
      this.selectedTable = '';
      this.selectedList = 'selected-icon';
    }
  }

  /* Active or Inactive toggle */
  modeSwitcher(value: string): void {
    if (!value) {
      this.LstEmployee = this.LstStoreEmployee.filter((e) => e.IsActive == true);
      ShowInactive.ShowInactiveUser = this.checked = false;
    }
    else {
      this.LstEmployee = this.LstStoreEmployee;
      ShowInactive.ShowInactiveUser = this.checked = true;
    }
  }

  btnNew() {
    this._srvUser.Mode.next({ Mode: "CREATE" });
    this._srvUser.IsCreate = 'Create';

    this._srvUser.IsPagination = true;
    this._srvUser.employee_list_pageSize = this.pageSize;
    this._srvUser.employee_list_skip = this.skip;
  }


  /* Tab Click Edit Button */
  onSelect(row: any, event: any) {
    if (event.item.text === 'Reset Password') this.reset_Password(row);
    else if (event.item.text == 'Edit') this.btnEditEmployee(row);
  }

  reset_Password(data: any) {
    this.MlResetPassword.ContactID = data.ContactID;
    this.IsResetPasswordDialogOpen = true;
  }

  /* Employee Status Update */
  StatusToggle(event: boolean, data: UserList) {
    this.MlUpdateEmployeeStatus.ContactID = data.ContactID;
    this.MlUpdateEmployeeStatus.Status = event;
    data.IsActive = event;

    this._srvUser.updateEmployeeStatus(this.MlUpdateEmployeeStatus).subscribe({
      next: (res: any) => new CustomNotification(this._srvNotification).ShowSuccess(res.Data),
      error: (err: IWebError) => this.errorMsg(err.Message)
    });
  }

  btnEditEmployee(data: any) {
    this._srvUser.IsCreate = 'Update';
    this._srvUser.ContactID = data.ContactID;
    this._srvUser.Mode.next({ Mode: 'CREATE' });

    this._srvUser.IsPagination = true;
    this._srvUser.employee_list_pageSize = this.pageSize;
    this._srvUser.employee_list_skip = this.skip;
  }

  /* Grid Page Change Event */
  pageChange(event: PageChangeEvent) {
    this.pageSize = event.take;
    this.skip = event.skip;
  }

  /* Password Section */
  FrmReset = new FormGroup({
    Password: new FormControl('', [Validators.required, Validators.pattern(this.PasswordRegex), Validators.minLength(8), Validators.maxLength(20)])
  })

  /* Generate Password */
  /* Generate Random Password */
  generateRandomPass(passwordLength: number) {
    var numberChars = "0123456789";
    var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var lowerChars = "abcdefghijklmnopqrstuvwxyz";
    var spe = "@$!%*?&_#"
    var allChars = numberChars + upperChars + lowerChars + spe;
    var randPasswordArray = Array(passwordLength);
    randPasswordArray[0] = numberChars;
    randPasswordArray[1] = upperChars;
    randPasswordArray[2] = lowerChars;
    randPasswordArray[3] = spe;
    randPasswordArray = randPasswordArray.fill(allChars, 4);
    return this.shuffleArray(randPasswordArray.map(function (x) { return x[Math.floor(Math.random() * x.length)] })).join('');
  }

  shuffleArray(array: any) {
    for (var i = array.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
    return array;
  }

  removePasswordValidator() {
    this.FrmReset.controls['Password'].clearValidators();
    this.FrmReset.controls['Password'].updateValueAndValidity();
  }

  generatePassword() {
    this.removePasswordValidator();
    this.FrmReset.controls['Password'].setValue(this.generateRandomPass(8));
  }

  isFocusOut() {
    this.removePasswordValidator();
  }

  setPasswordValidator() {
    this.FrmReset.controls['Password'].setValidators([Validators.required, Validators.pattern(this.PasswordRegex), Validators.minLength(8), Validators.maxLength(20)]);
    this.FrmReset.controls['Password'].updateValueAndValidity()
  }

  /* Reset Password Dialog Close */
  IsResetPasswordDialogClose() {
    this.IsResetPasswordDialogOpen = false;
    this.FrmReset.reset();
  }

  /* User Reset Password Submit */
  resetPassword(FrmReset: FormGroup) {
    this.setPasswordValidator();
    if (FrmReset.status === 'VALID') {
      this.MlResetPassword.NewPassword = FrmReset.value.Password;
      this._srvUser.resetPassword(this.MlResetPassword).subscribe({
        next: (response) => {
          this.IsResetPasswordDialogClose();
          new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
        },
        error: (error: IWebError) => this.errorMsg(error.Message),
      });
    }
    else FrmReset.markAllAsTouched();
  }

  /* Show Error Msg */
  errorMsg(error: string) {
    new CustomNotification(this._srvNotification).ShowError(error);
  }
}
