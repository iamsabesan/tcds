import { Component } from "@angular/core";
import { UserService } from "../../services/user.service";

@Component({
    selector: 'franchisee',
    templateUrl: './franchisee.component.html',
    providers: [UserService]
})
export class FranchiseeComponent {
    public actions: string = '';

    constructor(private _srvUser: UserService) {
        this._srvUser.Mode.subscribe(e => this.actions = e.Mode);
    }
}