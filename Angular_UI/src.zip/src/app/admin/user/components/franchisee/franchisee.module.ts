import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FranchiseeComponent } from './franchisee.component';
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { UserModule } from '../../user.module';

const routes: Routes = [
    {
        path: '',
        component: FranchiseeComponent,
    },
];
@NgModule({
    declarations: [
        FranchiseeComponent,
        ListComponent,
        CreateComponent
    ],
    imports: [
        UserModule,
        RouterModule.forChild(routes),
    ],
    providers: [UserService],
})
export class FranchiseeModule { }