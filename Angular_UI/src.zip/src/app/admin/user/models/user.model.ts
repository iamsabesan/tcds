import { Address } from "src/app/shared/model/common";

/* Admin Mode */
export class IUserRegistration {
  Mode = 'LIST' || 'CREATE';
}

/* Franchisee Mode */
export class FranchiseeEmployee {
  Mode = 'LIST' || 'CREATE';
}


export class UserDepartment {
  DepartmentID: string = '';
  DepartmentName: string = '';
}

export class UserDesignation {
  DesignationID = '';
  Designation = '';
  JobTitle = '';
  AuthRoleID: number = 0;
  Levels: number = 0;
}

export class ReportingTo {
  ContactID: string = '';
  ContactName: string = '';
  PhoneCode: string = '';
  Phone: string = '';
  Designation: string = '';
  Department: string = '';
  UserID: string = '';
  DepartmentID: string = '';
  JobTitle: string = '';
  TenantBranchID: string = '';
  TenantBranch: string = '';
  Email: string = '';
  IsActive: boolean = false;
  Employment: string = '';
}

export class UserList {
  ContactID = '';
  ContactName = '';
  Department = '';
  AuthRole = [];
  JobTitle: string = '';
  TenantBranch = '';
  TenantBranchID = '';
  PhoneCode = '';
  Phone = '';
  Email = '';
  IsActive: boolean;
}

export class ResetPassword {
  ContactID: string = '';
  NewPassword: string = '';
}

/* Employee Create */
export class EmployeeCreate {
  ContactID: string = '';
  BranchID: string = '';
  ContactType: string = '';
  DepartmentID?: string = '';
  JobTitleID: string = '';
  AuthRoleID: any;
  ReportToParentID: string = '';
  EmployeeID: string = '';
  EmployeeName: string = '';
  Gender: string = '';
  Email: string = '';
  DateOfBirth: string = '';
  DateOfJoining: string = '';
  PhoneCode: string = '';
  Phone: string = '';
  AlternatePhoneCode: string = '';
  AlternatePhone: string = '';
  CommunicationAddress = new Address();
  PermanentAddress = new Address();
  ProfilePicture: File[] = [];
  IsActive?: boolean = false;
  PassWord: string = '';
  ConfirmPassWord: string = '';
  EmployeeStatus: string = '';
}

/* Get Employee Detail With Using the ContactID */
export class EmployeeDetail {
  UserID: string = '';
  ContactID: string = '';
  ContactCode: string = '';
  ContactName: string = '';
  Gender: string = '';
  Email: string = '';
  DateOfBirthI18: string = '';
  DateOfJoiningI18: string = '';
  PhoneCode: string = '';
  Phone: string = '';
  AlternatePhoneCode: string = '';
  AlternatePhone: string = '';
  BranchID: string = '';
  BranchName: string = '';
  DepartmentID: string = '';
  DepartmentName: string = '';
  JobTitleID: string = '';
  JobTitle: string = '';
  ReportingToParentID: string = '';
  CommAddress1: string = '';
  CommAddress2: string = '';
  CommArea: string = '';
  CommCountry: string = '';
  CommState: string = '';
  CommDistrict: string = '';
  CommPinCode: string = '';
  PermAddress1: string = '';
  PermAddress2: string = '';
  PermArea: string = '';
  PermCountry: string = '';
  PermState: string = '';
  PermDistrict: string = '';
  PermPinCode: string = '';
  DownloadUrl: string = '';
  PictureUrl: string = '';
  ThumbnailUrl: string = '';
  IsActive: boolean;
  Employment: string = '';
}