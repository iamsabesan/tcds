import { Injectable } from '@angular/core';

import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { EmployeeCreate, FranchiseeEmployee, IUserRegistration, ResetPassword, } from '../models/user.model';
import { UpdateStatus } from 'src/app/shared/model/common';

@Injectable()
export class UserService {

  /* List Filter Employee Name */
  public ContactName: string = '';

  /* Grid Pagination */
  public IsPagination: boolean = false;
  public employee_list_skip: number = 0;
  public employee_list_pageSize: number = 0;

  /* Is Create or Edit Employee */
  public IsCreate: string = '';

  /* Get Employee ContactID */
  public ContactID: string = '';

  /* Using Behaviour Subject for List, Create Components */
  public stfAction = new BehaviorSubject<IUserRegistration>({ Mode: 'LIST' });
  public Mode = new BehaviorSubject<FranchiseeEmployee>({ Mode: 'LIST' });


  constructor(public http: HttpService) { }

  /* Get Employee List */
  // getUserList() {
  //   return this.http.get('/user-service/user/tenant-user-list', { RequestType: IRequestType.Protected, });
  // }

  /* Get Department List Admin Login */
  getDepartment() {
    return this.http.get("/user-service/user/get-user-department", { RequestType: IRequestType.Protected, });
  }

  /* Get Designation List Admin Login With Using DepartmentID*/
  getUserDesignation(DepartmentID: string) {
    return this.http.get("/user-service/user/get-user-designation", { params: { DepartmentID }, RequestType: IRequestType.Protected, });
  }

  /* Get Designation List Franchisee Login */
  getDesignation() {
    return this.http.get("/user-service/user/get-franchisee-designation", { RequestType: IRequestType.Protected, });
  }

  /* Get Reporting To */
  getReportingToList() {
    return this.http.get("/user-service/user/user-reporting-to", { RequestType: IRequestType.Protected, });
  }

  getRole() {
    return this.http.get("/compass/v1/Agent/getDesignationList", { RequestType: IRequestType.Protected, });
  }

  getReportingTo() {
    const Designation = 'TenantUser';
    return this.http.get("/compass/v1/Agent/agentbydesignation", { params: { Designation }, RequestType: IRequestType.Protected, });
  }

  /* Get Branch List */
  getTenantBranch() {
    return this.http.get("/tenant-branch-service/tenantbranch/list", { RequestType: IRequestType.Protected, });
  }

  /* Employee Password Reset */
  resetPassword(data: ResetPassword) {
    return this.http.post<ResetPassword>("/user-service/user/reset-password", data, { RequestType: IRequestType.Protected, });
  }

  /* Create Employee */
  createEmployee(MlEmployee: EmployeeCreate, EmployeeStatus: string, IsSkip: boolean) {
    const formData = new FormData();

    formData.append('ContactName', MlEmployee.EmployeeName);
    formData.append('Gender', MlEmployee.Gender);
    formData.append('Email', MlEmployee.Email);
    formData.append('DateOfBirth', MlEmployee.DateOfBirth);
    formData.append('PhoneCode', MlEmployee.PhoneCode)
    formData.append('Phone', MlEmployee.Phone);
    formData.append('AlternatePhoneCode', MlEmployee.AlternatePhoneCode);
    formData.append('DateofJoining', MlEmployee.DateOfJoining)
    MlEmployee.AlternatePhone == null ? formData.append('AlternatePhone', "") : formData.append('AlternatePhone', MlEmployee.AlternatePhone);

    if (EmployeeStatus == 'Create') {
      formData.append('ContactCode', MlEmployee.EmployeeID);
      formData.append('TenantBranchID', MlEmployee.BranchID);
      formData.append('DeptGroupID', MlEmployee.DepartmentID);
      formData.append('AuthRoleID', MlEmployee.AuthRoleID);
      formData.append('ContactType', MlEmployee.ContactType);
    }
    else {
      formData.append('ContactID', MlEmployee.ContactID);
      formData.append('DepartmentID', MlEmployee.DepartmentID);
      formData.append('JobTitleID', MlEmployee.JobTitleID);
    }

    formData.append('ReportToParentID', MlEmployee.ReportToParentID);

    if (MlEmployee.PassWord == null || MlEmployee.PassWord == "") { }
    else formData.append('Password', MlEmployee.PassWord);

    if (IsSkip) {
      formData.append('CommAddr.Address1', MlEmployee.CommunicationAddress.Address1);
      formData.append('CommAddr.Address2', MlEmployee.CommunicationAddress.Address2)
      formData.append('CommAddr.Area', MlEmployee.CommunicationAddress.Area);
      formData.append('CommAddr.Country', MlEmployee.CommunicationAddress.Country);
      formData.append('CommAddr.State', MlEmployee.CommunicationAddress.State);
      formData.append('CommAddr.District', MlEmployee.CommunicationAddress.District);
      formData.append('CommAddr.PinCode', MlEmployee.CommunicationAddress.PinCode);

      formData.append('PermAddr.Address1', MlEmployee.PermanentAddress.Address1);
      formData.append('PermAddr.Address2', MlEmployee.PermanentAddress.Address2)
      formData.append('PermAddr.Area', MlEmployee.PermanentAddress.Area);
      formData.append('PermAddr.Country', MlEmployee.PermanentAddress.Country);
      formData.append('PermAddr.State', MlEmployee.PermanentAddress.State);
      formData.append('PermAddr.District', MlEmployee.PermanentAddress.District);
      formData.append('PermAddr.PinCode', MlEmployee.PermanentAddress.PinCode);
    }

    MlEmployee.ProfilePicture.forEach((e: any) => {
      formData.append('ProfilePicture', e);
    });

    if (EmployeeStatus == "Create")
      return this.http.post('/user-service/v1/audit/user/employee/create', formData, { RequestType: IRequestType.Protected })
    // return this.http.post('/user-service/user/employee/create', formData, { RequestType: IRequestType.Protected })
    else
      return this.http.post('/user-service/v1/audit/user/employee/edit', formData, { RequestType: IRequestType.Protected })
  }

  /* Franchisee Create Employee */
  franchiseeCreateEmployee(MlEmployee: EmployeeCreate, EmployeeStatus: string, IsSkip: boolean) {
    const formData = new FormData();

    formData.append('ContactName', MlEmployee.EmployeeName);
    formData.append('Gender', MlEmployee.Gender);
    formData.append('Email', MlEmployee.Email);
    formData.append('DateOfBirth', MlEmployee.DateOfBirth);
    formData.append('PhoneCode', MlEmployee.PhoneCode)
    formData.append('Phone', MlEmployee.Phone);
    formData.append('AlternatePhoneCode', MlEmployee.AlternatePhoneCode);
    formData.append('DateofJoining', MlEmployee.DateOfJoining)
    MlEmployee.AlternatePhone == null ? formData.append('AlternatePhone', "") : formData.append('AlternatePhone', MlEmployee.AlternatePhone);

    if (EmployeeStatus == 'Create') {
      formData.append('ContactCode', MlEmployee.EmployeeID);
      formData.append('TenantBranchID', MlEmployee.BranchID);
      formData.append('AuthRoleID', MlEmployee.AuthRoleID);
      formData.append('ContactType', MlEmployee.ContactType);
      formData.append('DeptGroupID', MlEmployee.DepartmentID);
    }
    else {
      formData.append('DepartmentID', MlEmployee.DepartmentID);
      formData.append('ContactID', MlEmployee.ContactID);
      formData.append('JobTitleID', MlEmployee.JobTitleID);
    }

    formData.append('ReportToParentID', MlEmployee.ReportToParentID);

    if (MlEmployee.PassWord == null || MlEmployee.PassWord == "") { }
    else formData.append('Password', MlEmployee.PassWord);

    if (IsSkip) {
      formData.append('CommAddr.Address1', MlEmployee.CommunicationAddress.Address1);
      formData.append('CommAddr.Address2', MlEmployee.CommunicationAddress.Address2)
      formData.append('CommAddr.Area', MlEmployee.CommunicationAddress.Area);
      formData.append('CommAddr.Country', MlEmployee.CommunicationAddress.Country);
      formData.append('CommAddr.State', MlEmployee.CommunicationAddress.State);
      formData.append('CommAddr.District', MlEmployee.CommunicationAddress.District);
      formData.append('CommAddr.PinCode', MlEmployee.CommunicationAddress.PinCode);

      formData.append('PermAddr.Address1', MlEmployee.PermanentAddress.Address1);
      formData.append('PermAddr.Address2', MlEmployee.PermanentAddress.Address2)
      formData.append('PermAddr.Area', MlEmployee.PermanentAddress.Area);
      formData.append('PermAddr.Country', MlEmployee.PermanentAddress.Country);
      formData.append('PermAddr.State', MlEmployee.PermanentAddress.State);
      formData.append('PermAddr.District', MlEmployee.PermanentAddress.District);
      formData.append('PermAddr.PinCode', MlEmployee.PermanentAddress.PinCode);
    }

    MlEmployee.ProfilePicture.forEach((e: any) => {
      formData.append('ProfilePicture', e);
    });

    if (EmployeeStatus == "Create")
      return this.http.post('/user-service/v1/audit/user/employee/create', formData, { RequestType: IRequestType.Protected })
    else
      return this.http.post('/user-service/v1/audit/user/employee/edit', formData, { RequestType: IRequestType.Protected })
  }

  /* Get Particular Employee Detail With Using the ContactID */
  getEmployeeByID(ContactID: string) {
    return this.http.get(`/user-service/user/employee/details?contactID=${ContactID}`, { RequestType: IRequestType.Protected, });
  }

  /* Update Employee Status Active & Inactive */
  updateEmployeeStatus(MlUpdateStatus: UpdateStatus) {
    return this.http.post('/user-service/user/employee/status/update', MlUpdateStatus, { RequestType: IRequestType.Protected })
  }

  getPhoneCode() {
    return this.http.get('/common/phonecode', { RequestType: IRequestType.Anonymus, });
  }

}
