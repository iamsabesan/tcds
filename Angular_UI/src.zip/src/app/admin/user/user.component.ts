import { Component, OnInit } from '@angular/core';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',

})
export class UserComponent implements OnInit {

  action = '';
  constructor(
    private _srvUser: UserService,
  ) { }

  ngOnInit(): void {
    this._srvUser.stfAction.subscribe(res => {
      this.action = res.Mode;
    });
  }
}
