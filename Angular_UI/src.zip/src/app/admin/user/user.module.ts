import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { IconsModule } from '@progress/kendo-angular-icons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { DatePickerModule } from '@progress/kendo-angular-dateinputs';
import { GridModule } from '@progress/kendo-angular-grid';

const Module = [
  CommonModule,
  NavigationModule,
  IconsModule,
  FormsModule,
  ReactiveFormsModule,
  LayoutModule,
  LabelModule,
  InputsModule,
  ButtonsModule,
  DropDownsModule,
  FormsModule,
  ReactiveFormsModule,
  GridModule,
  DialogModule,
  NotificationModule,
  Ng2SearchPipeModule,
  ToolBarModule,
  TooltipModule,
  DatePickerModule,
]
@NgModule({
  declarations: [],
  imports: [...Module],
  exports: [...Module]
})

export class UserModule { }