import { ChangeDetectorRef, Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { AddEvent, CancelEvent, EditEvent, GridComponent, RemoveEvent } from "@progress/kendo-angular-grid";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { gridFontStyle } from "src/app/shared/app-global";
import { mobileAndShowIn, mobileApp } from "../../model/videos.model";
import { CustomNotification } from "src/app/shared/model/shared";
import { NotificationService } from "@progress/kendo-angular-notification";
import { VideosService } from "../../service/videos.service";
import { IWebError } from "src/core/model";
import { DialogRef, DialogService } from "@progress/kendo-angular-dialog";

@Component({
    selector: 'mobile-apps',
    templateUrl: 'mobile-apps.component.html',
    styleUrls: ['mobile-apps.component.scss']
})
export class MobileAppsComponent {

    /* List */
    LstMobileApps: mobileApp[] = [];
    LstMobile: mobileAndShowIn[] = [];
    LstShowIn: mobileAndShowIn[] = [];
    LstCopyShowIn: mobileAndShowIn[] = [];
    LstLinkType = [
        'YouTube',
        'HyperLink'
    ]
    /* Model */
    MlMobileApps = new mobileApp();
    /* Grid Header Style */
    public gridStyle = new gridFontStyle();

    /* Grid Filter */
    public filter: CompositeFilterDescriptor;

    /* Grid Pagination */
    public buttonCount = 5;
    public skip = 0;
    public pageSize = 15;
    public sizes: any[] = [15, 25, 50, 100, "All"];

    public formGroup: FormGroup;
    public editedRowIndex: number;
    public result: any;
    constructor(private _srvVideos: VideosService, private _srvNotification: NotificationService, private cd: ChangeDetectorRef, public dialogService: DialogService) { }

    ngOnInit() {
        this.getVideosList();
        this.getMobile();
        this.getShowIn();
    }

    /* get Videos List */
    getVideosList() {
        this._srvVideos.getMobileAppList().subscribe({
            next: (val) => {
                this.LstMobileApps = val.Data;
            }, error: (err) => this.errorMsg(err.Message)
        })
    }

    /* get Mobile Dropdown */
    getMobile() {
        this._srvVideos.getMobile().subscribe((val) => this.LstMobile = val.Data)
    }
    /* get Show In Dropdown */
    getShowIn() {
        this._srvVideos.getShowIn().subscribe((val) => this.LstShowIn = this.LstCopyShowIn = val.Data)
    }

    /* New add Video */
    public addHandler({ sender }: AddEvent): void {
        this.closeEditor(sender);
        this.formGroup = createFormGroup({
            SortOrder: "",
            VideoType: "",
            Title: "",
            ContentUrl: "",
            SubjectID: '',
        });
        sender.addRow(this.formGroup);
    }

    public saveHandler({ sender, rowIndex, dataItem }: AddEvent): void {
        this.formGroup = createFormGroup(dataItem);

        if (this.formGroup.invalid) {
            this.formGroup.markAllAsTouched();
            this.errorMsg('Fill the details')
            return;
        }
        dataItem.MobileApp = typeof dataItem.MobileApp == 'string' ? dataItem.MobileApp : dataItem.MobileApp.MinValue;
        dataItem.ShowIn = typeof dataItem.ShowIn == 'string' ? dataItem.ShowIn : dataItem.ShowIn.MinValue;

        const serviceCall = dataItem.GuideVideoID
            ? this._srvVideos.postEditMobileApp(dataItem)
            : this._srvVideos.postAddMobileApp(dataItem);

        serviceCall.subscribe({
            next: (res: any) => {
                new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                this.getVideosList();
                sender.closeRow(rowIndex);
            },
            error: (err: IWebError) => {
                this.errorMsg(err.Message);
            }
        });
    }

    /* Edit video details */
    public editHandler({ sender, rowIndex, dataItem }: EditEvent): void {
        this.closeEditor(sender);
        this.formGroup = createFormGroup(dataItem);
        this.editedRowIndex = rowIndex;
        sender.editRow(rowIndex, this.formGroup);
    }

    public cancelHandler({ sender, rowIndex }: CancelEvent): void {
        this.closeEditor(sender, rowIndex);
        this.getVideosList();
    }

    /* Delete video detail */
    public removeHandler({ dataItem }: RemoveEvent): void {

        const dialog: DialogRef = this.dialogService.open({
            title: 'Delete Video',
            content: `Do you want to delete the mobile app video the ${dataItem.Title}?`,
            actions: [
                { text: 'No' },
                { text: 'Yes', themeColor: 'primary' }
            ],
            width: 300,
            height: 150,
        });
        dialog.result.subscribe((result) => {
            this.result = result;
            if (this.result.text == "Yes") {
                this._srvVideos.getDeleteMobileAppVideo(dataItem.GuideVideoID).subscribe({
                    next: (res) => {
                        new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                        this.getVideosList();
                    }, error: (err) => this.errorMsg(err.Message)
                })

            }
        })
    }
    private closeEditor(grid: GridComponent, rowIndex = this.editedRowIndex): void {
        grid.closeRow(rowIndex);
        this.getVideosList();
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
    }

    /* Dropdown Mobile App */
    mobileAppValueChange(event: mobileAndShowIn, data: mobileApp) {
        data.ShowIn = '';
        if (!event) this.LstShowIn = this.LstCopyShowIn;
        else {
            if (event.MinValue == "Student") this.LstShowIn = this.LstCopyShowIn.filter(e => e.MinValue !== "Feedback")
            else this.LstShowIn = this.LstCopyShowIn;
            this.cd.markForCheck();
        }
    }

    /* Show Error Msg */
    errorMsg(err: string) {
        new CustomNotification(this._srvNotification).ShowError(err);
    }

}

/* FormGroup*/
const createFormGroup = (dataItem) =>
    new FormGroup({
        Title: new FormControl(dataItem.Title, Validators.required),
        MobileApp: new FormControl(dataItem.MobileApp, Validators.required),
        ShowIn: new FormControl(dataItem.ShowIn, Validators.required),
        SortOrder: new FormControl(dataItem.SortOrder, Validators.required),
        LinkType: new FormControl(dataItem.LinkType, Validators.required),
        ContentUrl: new FormControl(dataItem.ContentUrl, Validators.required),
    })