import { Component } from "@angular/core";
import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { gridFontStyle } from "src/app/shared/app-global";
import { VideosService } from "../../service/videos.service";
import { IWebError } from "src/core/model";
import { CustomNotification } from "src/app/shared/model/shared";
import { ApproveStudentFeedback, RejectStudentFeedback, StudentFeedback } from "../../model/videos.model";
import { NotificationService } from "@progress/kendo-angular-notification";
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { DialogService } from "@progress/kendo-angular-dialog";
import { RejectComponent } from "src/app/shared/components/reject/reject.component";
import * as saveAs from "file-saver";

@Component({
    selector: 'student-testimonials',
    templateUrl: 'student-testimonials.component.html',
    styleUrls: ['student-testimonials.component.scss']
})
export class StudentTestimonialsComponent {

    /* List */
    public LstStudentFeedbackRequest: StudentFeedback[] = [];

    /* Model */
    public MlApproveStudentFeedback: ApproveStudentFeedback = new ApproveStudentFeedback();
    public MlRejectStudentFeedback: RejectStudentFeedback = new RejectStudentFeedback();

    /* Dialog */
    public openApproveDialog: boolean = false;

    /* Grid Filter */
    public gridStyle = new gridFontStyle('medium');
    public filter: CompositeFilterDescriptor;

    /* Grid Pagination */
    public buttonCount: number = 5;
    public pageSize: number = 15;
    public sizes: number[] = [15, 25, 50, 100];
    public skip: number = 0;

    /* Download Image */
    public downloadImage: string = ''

    /* Form Group */
    FrmEntry = new FormGroup({
        ContentURL: new FormControl('', [Validators.required])
    })
    constructor(private _srvVideo: VideosService, private _srvNotification: NotificationService,
        private _dialogservice: DialogService) { }

    ngOnInit() {
        this.getStudentFeedback();
        this.downloadImage = 'assets/logo/video_download_icon.png';
    }

    /* Get Student Feedback List */
    getStudentFeedback() {
        this._srvVideo.getStudentFeedback().subscribe({
            next: (res: any) => this.LstStudentFeedbackRequest = res.Data,
            error: (err: IWebError) => this.errorMsg(err.Message)
        });
    }

    /* Download Video */
    btnDownload(data: StudentFeedback) {
        this._srvVideo.downloadVideo(data.FileName).subscribe({
            next: (res: Blob) => saveAs(res),
            error: (err: IWebError) => this.errorMsg(err.Message)
        });
    }

    /* Approved Dialog Open */
    btnApproveFeedback(data: StudentFeedback) {
        this.MlApproveStudentFeedback.FeedbackID = data.FeedbackID;
        this.MlApproveStudentFeedback.FileName = data.FileName;
        this.MlApproveStudentFeedback.Title = data.Title;
        this.MlApproveStudentFeedback.TenantBranchID = data.TenantBranchID;
        this.openApproveDialog = true;
    }

    /* Approve Dialog Close */
    btnCloseDialog() {
        this.openApproveDialog = false;
        this.FrmEntry.reset();
    }

    /* Approve Student Feedback */
    btnFrmSubmit() {
        if (this.FrmEntry.invalid) this.FrmEntry.markAllAsTouched();
        else {
            this.MlApproveStudentFeedback.ContentUrl = this.FrmEntry.value.ContentURL;
            this._srvVideo.approveFeedback(this.MlApproveStudentFeedback).subscribe({
                next: (res: any) => {
                    new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                    this.openApproveDialog = false;
                    this.getStudentFeedback();
                },
                error: (err: IWebError) => this.errorMsg(err.Message)
            })
        }
    }

    /* Reject Student Feedback */
    btnRejectFeedback(data: StudentFeedback) {
        this.MlRejectStudentFeedback.FeedbackID = data.FeedbackID;
        this.MlRejectStudentFeedback.FileName = data.FileName;

        const dialogRef = this._dialogservice.open({
            title: "Reject Student Feedback",
            content: RejectComponent,
            width: 400,
        });
        const rejectComponentInstance = dialogRef.content.instance as RejectComponent;

        rejectComponentInstance.formSubmitted.subscribe((formData: any) => {
            this.MlRejectStudentFeedback.Reason = formData.Reason;

            this._srvVideo.rejectFeedback(this.MlRejectStudentFeedback).subscribe({
                next: (res: any) => {
                    new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
                    this.getStudentFeedback();
                    dialogRef.close();
                },
                error: (err: IWebError) => this.errorMsg(err.Message)
            });
        });
    }

    /* Show Error Msg */
    errorMsg(err: string) {
        new CustomNotification(this._srvNotification).ShowError(err)
    }
}