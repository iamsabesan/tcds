export class StudentFeedback {
    FeedbackID: string = '';
    TenantBranchID: string = '';
    Franchisee: string = '';
    Title: string = '';
    FileName: string = '';
    Status: string = '';
    Reason: string = '';
    RequestDate: string = '';
}

/* Reject Student FeedBack */
export class RejectStudentFeedback {
    FeedbackID: string = '';
    Reason: string = '';
    FileName: string = '';
}

/* Approve Student FeedBack */
export class ApproveStudentFeedback {
    FeedbackID: string = '';
    TenantBranchID: string = '';
    Title: string = '';
    ContentUrl: string = '';
    FileName: string = '';
}

/* Mobile App List */
export class mobileApp {
    GuideVideoID = '';
    TenantBranchID = '';
    Franchisee = '';
    Title = '';
    MobileApp = '';
    ShowIn = '';
    SortOrder = '';
    LinkType = '';
    ContentUrl = '';
}

export class mobileAndShowIn {
    MinValue = '';
}