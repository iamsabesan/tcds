import { Injectable } from "@angular/core";
import { IRequestType } from "src/core/model";
import { HttpService } from "src/core/service";
import { ApproveStudentFeedback, RejectStudentFeedback, mobileApp } from "../model/videos.model";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { AppConfigService } from 'src/core/service/appconfig.service';
import { environment } from "src/environments/environment";
import { CrazyKey } from "src/core/helper";

@Injectable()
export class VideosService {
    constructor(private _srvHttp: HttpService, private _http: HttpClient, private _appConfigService: AppConfigService,) { }

    /* Get Student FeedBack List */
    getStudentFeedback() {
        return this._srvHttp.get("/icloud-franchisee/v1/franchisee/student-feedback/list", { RequestType: IRequestType.Protected })
    }

    /* Approv Student FeedBack */
    approveFeedback(approveFeedback: ApproveStudentFeedback) {
        return this._srvHttp.post("/icloud-franchisee/v1/franchisee/feedback/approve", approveFeedback, { RequestType: IRequestType.Protected })
    }

    /* Reject Student FeedBack */
    rejectFeedback(rejectFeedback: RejectStudentFeedback) {
        return this._srvHttp.post("/icloud-franchisee/v1/franchisee/feedback/reject", rejectFeedback, { RequestType: IRequestType.Protected })
    }

    /* Download Video */
    downloadVideo(fileName: string) {
        const token = 'Bearer ' + this._srvHttp._getRolloutApiKey();
        const headers = new HttpHeaders().set('Authorization', token);
        const baseUrl = CrazyKey.decrypt(this._appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
        return this._http.get(baseUrl + `/icloud-franchisee/v1/franchisee/download/${fileName}`, { headers, responseType: "blob" });
    }

    /* Get Mobile App List */
    getMobileAppList() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/guide-video-list', { RequestType: IRequestType.Protected })
    }

    /* Get Mobile Dropdown List */
    getMobile() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/mobile/apps', { RequestType: IRequestType.Protected });
    }

    /* Get Show In Dropdown */
    getShowIn() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/mobile/show-in', { RequestType: IRequestType.Protected })
    }

    /* Post Add Mobile App Videos */
    postAddMobileApp(data: mobileApp) {
        return this._srvHttp.post('/icloud-franchisee/v1/franchisee/add-videos', data, { RequestType: IRequestType.Protected })
    }

    /* Post Add Mobile App Videos */
    postEditMobileApp(data: mobileApp) {
        return this._srvHttp.post('/icloud-franchisee/v1/franchisee/edit-video', data, { RequestType: IRequestType.Protected })
    }

    /* Get Show In Dropdown */
    getDeleteMobileAppVideo(guidevideoID: string) {
        return this._srvHttp.get(`/icloud-franchisee/v1/franchisee/guide-video/delete/${guidevideoID}`, { RequestType: IRequestType.Protected })
    }
}