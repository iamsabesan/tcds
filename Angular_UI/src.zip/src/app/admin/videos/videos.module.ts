import { NgModule } from "@angular/core";
import { MobileAppsComponent } from "./component/mobile-apps/mobile-apps.component";
import { StudentTestimonialsComponent } from "./component/student-testimonials/student-testimonials.component";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { GridModule } from "@progress/kendo-angular-grid";
import { ButtonModule } from "@progress/kendo-angular-buttons";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { IconsModule } from "@progress/kendo-angular-icons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { VideosService } from "./service/videos.service";
import { TooltipModule } from "@progress/kendo-angular-tooltip";

const routes: Routes = [
    {
        path: 'mobile-apps',
        component: MobileAppsComponent
    },
    {
        path: 'student-testimonials',
        component: StudentTestimonialsComponent
    }
]


@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        LayoutModule,
        NavigationModule,
        ToolBarModule,
        GridModule,
        ButtonModule,
        FormsModule,
        ReactiveFormsModule,
        IconsModule,
        DropDownsModule,
        InputsModule,
        DialogsModule,
        TooltipModule
    ],
    declarations: [
        MobileAppsComponent,
        StudentTestimonialsComponent
    ],
    providers: [
        VideosService
    ]
})
export class VideosModule { }