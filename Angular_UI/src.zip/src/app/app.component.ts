import { AfterViewInit, Component, Inject, LOCALE_ID, ViewEncapsulation } from '@angular/core';
import { LoaderService } from 'src/core/service';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements AfterViewInit {
  title = 'TCDS';

  constructor(private _loading: LoaderService, @Inject(LOCALE_ID) public localeId: string, private _srvAppCon: AppConfigService) {
    if (environment.production) {
      console.log = function () { };
    }
  }

  ngOnInit() {
    document.title = this._srvAppCon.appConfigDetails.ProjectName;
  }

  ngAfterViewInit(): void {
    const interval = setInterval(() => {
      const config = this._srvAppCon.appConfigDetails;
      if (config && config.ProjectName) {
        document.title = config.ProjectName;
        clearInterval(interval);
      }
    }, 300);
    this._loading.hide();
  }
}
