import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { APP_INITIALIZER, LOCALE_ID, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { RouterModule, Routes } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { IconsModule } from '@progress/kendo-angular-icons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import '@progress/kendo-angular-intl/locales/en-IN/all';
import '@progress/kendo-angular-intl/locales/en-GB/all';
import '@progress/kendo-angular-intl/locales/hi/all';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { ListViewModule } from '@progress/kendo-angular-listview';
import { MapModule } from '@progress/kendo-angular-map';
import { MenuModule } from '@progress/kendo-angular-menu';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { NotificationModule } from '@progress/kendo-angular-notification';
import { ProgressBarModule } from '@progress/kendo-angular-progressbar';
import { ScrollViewModule } from '@progress/kendo-angular-scrollview';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { TooltipsModule } from '@progress/kendo-angular-tooltip';
import { TelerikReportingModule } from '@progress/telerik-angular-report-viewer';
import { RouteGuard } from 'src/core/guard/auth.guard';
import { AdminService, AppService, HttpService, KeyService, LoaderService } from 'src/core/service';
import { AuthInterceptor } from 'src/core/service/auth.service';
import { UserService } from 'src/core/service/user.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LocalString } from './shared/app-global';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { EditorModule } from '@progress/kendo-angular-editor';
import { PDFExportModule } from "@progress/kendo-angular-pdf-export";
import { UploadsModule } from '@progress/kendo-angular-upload';
import { ValueShareService } from 'src/app/shared/service/value-share.service';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { LayoutComponent } from './layouts/layout.component';


const appRoutes: Routes = [
  {
    path: 'auth',
    loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule)
  },
  {
    path: 'iCloud',
    component: LayoutComponent,
    loadChildren: () => import('src/app/layouts/layouts.module').then(m => m.LayoutsModule),
    canLoad: [RouteGuard],
    canActivate: [RouteGuard]
  },
  {
    path: '',
    redirectTo: 'auth',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'auth',
    pathMatch: 'full'
  }
]

export function createTranslateLoader(http: HttpClient): any {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),

    AppRoutingModule,
    EditorModule,
    BrowserAnimationsModule,
    IconsModule,
    RouterModule,
    NotificationModule,
    ButtonsModule,
    DropDownsModule,
    GridModule,
    InputsModule,
    LabelModule,
    LayoutModule,
    ListViewModule,
    NavigationModule,
    ProgressBarModule,
    ScrollViewModule,
    ToolBarModule,
    TooltipsModule,
    DateInputsModule,
    MenuModule,
    MapModule,
    TelerikReportingModule,
    PDFExportModule,
    UploadsModule,

    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: createTranslateLoader,
        deps: [HttpClient]
      }
    }),
  ],
  providers: [
    HttpService,
    LoaderService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderService, multi: true },
    AuthInterceptor,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
    KeyService,
    RouteGuard,
    AppService,
    ValueShareService,
    UserService,
    AdminService,
    { provide: LOCALE_ID, useValue: LocalString.LanguageCulture },
    {
      provide: APP_INITIALIZER, multi: true, deps: [AppConfigService],
      useFactory: (appConfigService: AppConfigService) => {
        return () => {
          return appConfigService.loadAppConfig();
        };
      }
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
