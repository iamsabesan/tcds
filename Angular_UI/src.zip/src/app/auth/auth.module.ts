import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthComponent } from './auth.component';
import { RouterModule, Routes } from '@angular/router';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { HttpService } from 'src/core/service';
import { ButtonModule } from '@progress/kendo-angular-buttons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { ReactiveFormsModule } from '@angular/forms';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { AuthService } from './components/service/auth.service';
import { LayoutComponent } from '../layouts/layout.component';

const routes: Routes = [
  {
    path: '',
    component: AuthComponent,
    children: [
      {
        path: 'sign-in',
        component: SignInComponent
      },
      {
        path: 'forgot-password',
        component: ForgotPasswordComponent
      },
      {
        path: '**',
        redirectTo: '/auth/sign-in',
        pathMatch: 'full'
      },
      {
        path: '',
        redirectTo: '/auth/sign-in',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  declarations: [
    AuthComponent,
    SignInComponent,
    ForgotPasswordComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    ButtonModule,
    InputsModule,
    LabelModule,
    LayoutModule
  ],
  providers: [HttpService, AuthService,LayoutComponent],
  exports: [SignInComponent]
})
export class AuthModule { }
