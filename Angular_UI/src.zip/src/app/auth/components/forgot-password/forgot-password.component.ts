import { ChangeDetectorRef, Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { InputRegex } from 'src/app/shared/components/regex';
import { CustomNotification } from 'src/app/shared/model/shared';
import { ILoginResponse, IRequestType, LoginModel } from 'src/core/model';
import { ForgetEmailMl, ForgetEmailResultMl, ForgetOTPMl, ForgetPasswordMl } from '../model/auth';
import { HttpService, KeyService } from 'src/core/service';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { Router } from '@angular/router';
import { CrazyKey } from 'src/core/helper';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'auth-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  /* Model */
  loginCredentials: LoginModel = new LoginModel();
  MlForgetEmail: ForgetEmailMl = new ForgetEmailMl();
  MlForgetEmailResult: ForgetEmailResultMl = new ForgetEmailResultMl();
  MlForgetOTP: ForgetOTPMl = new ForgetOTPMl();
  MlForgetPassword: ForgetPasswordMl = new ForgetPasswordMl();


  fgForgotPassword!: FormGroup;
  emailRegex = InputRegex.Email;
  RegisterEmail = '';
  @ViewChild("RegisterEmail") EmailValue!: ElementRef;
  @ViewChild('OTPInput', { read: ElementRef, static: false }) OTPValue!: ElementRef;
  @ViewChild('template', { read: TemplateRef })
  public notificationTemplate!: TemplateRef<unknown>;
  IsVerify: string = 'Email';

  public IsEmailVerified!: boolean;
  public viewEmilOtpResend = true;
  public secondsEmailOtp: number = 0; // Set to 2 minutes
  public EmailOTPPattern = /^[0-9]{6}$/;
  public PasswordRegex = InputRegex.Password;

  public OTPErrorCheck = false;
  public EmailValidityTime: number = 0;
  private intervalIdEmail = 0;

  /* Password */
  public ConfirmPassword = true;
  public MainPassword = true;
  public isMatchPassword: boolean = true;
  public showMsg = false;

  public PassWordHint = "Password Format: UserName@_123";

  private OTPID: string = '';

  OTPFrmEntry = this.fb.group({
    EmailOtp: ['']
  })

  PasswordFrmEntry = this.fb.group({
    password: [''],
    confirmPassword: ['']
  })


  constructor(private fb: FormBuilder, private notificationService: NotificationService, private _keyService: KeyService,
    private _httpService: HttpService, private _appConfig: AppConfigService, private _router: Router, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.fgForgotPassword = this.fb.group({
      Email: ['', [Validators.required]]
    });
    this.loginCredentials.LoginName = CrazyKey.decrypt(this._appConfig.appConfigDetails.GuestUser, environment._privateKey);
    this.loginCredentials.Password = CrazyKey.decrypt(this._appConfig.appConfigDetails.GuestPassword, environment._privateKey);
    this.loginCredentials.TenantID = this._appConfig.appConfigDetails.TenantID;
    this._httpService.post<ILoginResponse>(CrazyKey.encrypt(this._appConfig.appConfigDetails.LoginURL, environment._privateKey), this.loginCredentials, { RequestType: IRequestType.Anonymus }).subscribe({
      next: (res: any) => {
        this._keyService.SyncApiKey(res.Data);
      },
    })

  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.EmailValue.nativeElement.focus();
    }, 100);
  }

  private focusOTPInput(retries: number = 5) {
    const inputElement = this.OTPValue?.nativeElement?.querySelector('input');
    if (inputElement) {
      inputElement.focus();
    } else if (retries > 0) {
      setTimeout(() => this.focusOTPInput(retries - 1), 100);
    }
  }


  frmForgotPassword_Submit() {
    this.MlForgetEmailResult = new ForgetEmailResultMl();
    this.MlForgetEmail = new ForgetEmailMl();
    if (this.fgForgotPassword.valid) {
      this.MlForgetEmail.Email = this.fgForgotPassword.value.Email;
      this.PostForgetEmail(this.MlForgetEmail).subscribe({
        next: val => {
          this.MlForgetEmailResult = val.Data;
          this.OTPFrmEntry.controls.EmailOtp.reset();
          this.EmailValidityTime = +this.MlForgetEmailResult.ValidityTime;
          this.startTimerEmail(this.EmailValidityTime);
          this.IsVerify = "OTP";
          this.OTPErrorCheck = false;
          this.cdr.detectChanges();
          this.focusOTPInput();

        }, error: err => this._errorMsg(err.Message)
      })
    }
  }

  backtoMail() {
    this.IsVerify = "Email";
    this.cdr.detectChanges();
    this.ngAfterViewInit();
  }


  otpVerify() {
    this.MlForgetOTP = new ForgetOTPMl();
    if (this.OTPFrmEntry.valid) {
      this.MlForgetOTP.OTPCode = this.OTPFrmEntry.value.EmailOtp;
      this.MlForgetOTP.OTPTransID = this.MlForgetEmailResult.OTPTransID;
      this.MlForgetOTP.OTPType = 'ForgotPassword';
      this.OTPErrorCheck = true;
      this.PostForgetOTP(this.MlForgetOTP).subscribe({
        next: val => {
          this.secondsEmailOtp = 0;
          this.OTPID = val.Data;
          this.IsEmailVerified = true;
          setTimeout(() => {
            this.IsVerify = 'Password';

          }, 1500);
        },
        error: err => {
          if (err.Message == "Exceed the number otp verification attempt !!!") {
            this._errorMsg(err.Message)
            this.secondsEmailOtp = 0;
            this.viewEmilOtpResend = true;
            this.IsEmailVerified = false;

          }
          else {
            this._errorMsg(err.Message);
            this.IsEmailVerified = false;
          }
        }

      })
    }
    this.OTPFrmEntry.markAllAsTouched();
  }

  /* Email Timer */
  startTimerEmail(emailTime: number): void {
    this.clearTimerEmail();
    this.secondsEmailOtp = emailTime;
    this.viewEmilOtpResend = false;
    this.intervalIdEmail = window.setInterval(() => {

      if (this.secondsEmailOtp > 0) {
        this.secondsEmailOtp -= 1;
      } else {
        this.clearTimerEmail();
        this.viewEmilOtpResend = true;
      }

    }, 1000);
  }

  clearTimerEmail() { clearInterval(this.intervalIdEmail); }


  emailOTPOnChange(event: Event) {
    this.OTPFrmEntry.controls.EmailOtp.setValue(this.onOTPInput(event), { emitEvent: false })
  }

  onOTPInput(event: Event) {
    const input = event.target as HTMLInputElement;
    const transformedValue = input.value.replace(/[^0-9]/g, ''); // Only allow digits
    input.value = transformedValue;
    return transformedValue
  }

  /* Secondes */
  transform(value: number): string {
    const minutes: number = Math.floor(value / 60);
    return (
      ('00' + minutes).slice(-2) +
      ':' +
      ('00' + Math.floor(value - minutes * 60)).slice(-2)
    );
  }


  /* Resend Email OTP */
  resendOTPEmail(): void {
    this.frmForgotPassword_Submit();
  }


  /* Show Email * Include */
  transformEmailID(email: string): string {
    if (!email || !email.includes('@')) {
      return email;
    }

    const [username, domain] = email.split('@');
    const visibleSection = username.slice(0, 4); // Take first 4 characters
    const maskedSection = username.slice(4).replace(/./g, '*'); // Mask remaining characters
    return `${visibleSection}${maskedSection}@${domain}`;
  }


  disableCopyPaste(event: ClipboardEvent): void {
    event.preventDefault();  // This will prevent copy, paste, and cut actions
  }

  /* Password */
  Password() {
    this.MainPassword = !this.MainPassword;
  }

  cpassword() {
    this.ConfirmPassword = !this.ConfirmPassword;
  }

  conPass() {
    const Password = this.PasswordFrmEntry.value.password;
    const ConfirmPassword = this.PasswordFrmEntry.value.confirmPassword;
    this.isMatchPassword = Password === ConfirmPassword;
    this.showMsg = this.isMatchPassword == true ? true : false;
  }


  submit() {
    this.MlForgetPassword = new ForgetPasswordMl();
    if (this.PasswordFrmEntry.valid) {
      if (this.PasswordFrmEntry.value.password == this.PasswordFrmEntry.value.confirmPassword) {
        // new CustomNotification(this.notificationService).ShowSuccess('Submited')

        this.MlForgetPassword.Email = this.MlForgetEmail.Email;
        if (this.PasswordFrmEntry.value.confirmPassword) this.MlForgetPassword.NewPassword = this.PasswordFrmEntry.value.confirmPassword;
        this.MlForgetPassword.OTPTransID = this.OTPID;
        this.PostForgetPassword(this.MlForgetPassword).subscribe({
          next: val => {
            new CustomNotification(this.notificationService).ShowSuccess(val.Message);

            setTimeout(() => {
              this._router.navigate(['/auth/sign-in']);
            }, 500);

          }, error: err => this._errorMsg(err.Message)
        })


      } else this._errorMsg("Password & confirm password are mismatching")
    }
    this.PasswordFrmEntry.markAllAsTouched();
  }

  PostForgetEmail(data: ForgetEmailMl) {
    return this._httpService.post('/user-service/v1/audit/user/forgot-password', data, { RequestType: IRequestType.Protected })
  }
  PostForgetOTP(data: ForgetOTPMl) {
    return this._httpService.post('/sms-service/sms/VerifyOTP', data, { RequestType: IRequestType.Protected })
  }

  PostForgetPassword(data: ForgetPasswordMl) {
    return this._httpService.post('/user-service/v1/audit/user/new-password', data, { RequestType: IRequestType.Protected })
  }

  /* Show Error Msg */
  private _errorMsg = (err: string) => new CustomNotification(this.notificationService).ShowError(err)
}
