// ============================================
// Author						: GURU
// Description					:
// Date							:
// ============================================
export { ForgotPasswordComponent } from  './forgot-password.component';
