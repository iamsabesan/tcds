export class ForgetEmailMl {
    Email: string = '';
}

export class ForgetEmailResultMl {
    OTPTransID: string = '';
    ValidityTime: string = '';
}

export class ForgetOTPMl {
    OTPTransID: string = '';
    OTPCode: any;
    OTPType: string = '';
}

export class ForgetPasswordMl {
    OTPTransID: string = '';
    NewPassword: string = '';
    Email: string = '';
}