import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private _srvHttp: HttpService) { }

  /* Franchisee Subscription Info */
  getSubscriptionInfo() {
    return this._srvHttp.get('/icloud-franchisee/v1/subscription/basicinfo', { RequestType: IRequestType.Protected, LoadingScreen: false });
  }
}
