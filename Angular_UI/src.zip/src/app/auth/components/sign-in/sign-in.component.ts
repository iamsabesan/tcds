import { Component, ElementRef, Inject, LOCALE_ID, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IntlService } from '@progress/kendo-angular-intl';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CrazyKey } from 'src/core/helper';
import { ILoginResponse, IRequestType, IUser, IWebError, LoginModel, SubscriptionInfo } from 'src/core/model';
import { AppService, HttpService, KeyService } from 'src/core/service';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { environment } from 'src/environments/environment';
// import { AuthService } from '../service/auth.service';
import { LayoutComponent } from 'src/app/layouts/layout.component';
// import { CommonService } from 'src/app/shared/service/common.service';


@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.scss']
})
export class SignInComponent implements OnInit {
  @ViewChild(LayoutComponent) layOut: LayoutComponent;
  isfrmSubmitted = false;
  passwordVisible = false;
  encrypted = false;
  fgLogin!: FormGroup;
  MainPassword!: boolean;
  loginCredentials: LoginModel = new LoginModel();
  @ViewChild('txtUsername') txtUsername!: ElementRef;
  constructor(private _httpService: HttpService,
    private _keyService: KeyService,
    public _activatedRoute: ActivatedRoute,
    public _router: Router,
    private _formBuilder: FormBuilder,
    private _srvNotification: NotificationService,
    @Inject(LOCALE_ID) public localeId: string,
    public intlService: IntlService,
    public _appConfig: AppConfigService,

    private _appService: AppService,) { }
    
  ngOnInit(): void {
    setTimeout(() => {
      this.txtUsername.nativeElement.select();
    }, 0)
    this.fgLogin = this._formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }


  userClaims: IUser | undefined;
  currentPlatforms: string = "";
  _privateKey = environment._privateKey;

  public AuthRole: string[] = [];
  public ApprovalEndDate: string = "";
  public SubscriptionEndDate: string = "";
  public MlSubscriptionInfo: SubscriptionInfo = new SubscriptionInfo();

  Launch() {
    if (this.fgLogin.status == 'INVALID') {
      this.fgLogin.markAllAsTouched();
    }
    else {
      this.loginCredentials.LoginName = this.fgLogin.controls['username'].value;
      this.loginCredentials.Password = this.fgLogin.controls['password'].value;
      this.loginCredentials.TenantID = this._appConfig.appConfigDetails.TenantID;

      this._httpService.post<ILoginResponse>(this._appConfig.appConfigDetails.LoginURL, this.loginCredentials, { RequestType: IRequestType.Anonymus }).subscribe({
        next: (response: any) => {
          this._keyService.SyncApiKey(response.Data);
          this.userClaims = this._appService.user;

          /* (userName) this get the user name */
          const user = this._keyService.HashedCookieKey("userName");
          localStorage.setItem(user, JSON.stringify(this.userClaims.UserName));
          this.currentPlatforms = CrazyKey.decrypt(this.userClaims.PlatformID, this._privateKey);
          this.AuthRole = JSON.parse(CrazyKey.decrypt(this.userClaims.AuthRole, this._privateKey));
          this.getMenu();
        },
        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
  }

  /* Get the Menu Based on Role */
  getMenu() {
    if (this.currentPlatforms.toUpperCase() == this._appConfig.appConfigDetails.PlatformID.toUpperCase()) {
      this._httpService.get('/menu/getMappedMenu', { RequestType: IRequestType.Protected }).subscribe({
        next: (response: any) => {
          this._keyService.SyncRoleMenu(response.Data);
          this._activatedRoute.queryParams.subscribe((params: any) => {
            const returnUrl = params['return'];
            this._router.navigateByUrl(returnUrl ? returnUrl : 'iCloud');
          });
        },
        error: (error: IWebError) => this.errorMsg(error.Message)
      });
    }
    else {
      this._activatedRoute.queryParams.subscribe((params: any) => {
        const returnUrl = params['return'];
        this._router.navigateByUrl(returnUrl ? returnUrl : 'auth');
      });
      this.errorMsg("Access Denied");
    }
  }

  Password() {
    this.MainPassword = !this.MainPassword;
  }

  /* Show Error Msg */
  errorMsg(error: string) {
    new CustomNotification(this._srvNotification).ShowError(error);
  }
}

