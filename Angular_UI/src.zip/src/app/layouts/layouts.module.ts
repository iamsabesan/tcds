import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SimplebarAngularModule } from 'simplebar-angular';
import { LayoutComponent } from './layout.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TopbarComponent } from './topbar/topbar.component';
import { FooterComponent } from './footer/footer.component';
import { RightsidebarComponent } from './rightsidebar/rightsidebar.component';
import { HorizontalComponent } from './horizontal/horizontal.component';
import { VerticalComponent } from './vertical/vertical.component';
import { HorizontaltopbarComponent } from './horizontaltopbar/horizontaltopbar.component';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { PopupModule } from '@progress/kendo-angular-popup';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { DialogService, DialogsModule } from '@progress/kendo-angular-dialog';
import { ChnagePasswordModule } from '../shared/components/change-password/change-password.module';
const routes: Routes = [
  {
    path: 'franchisee-dashboard',
    loadChildren: () => import('src/app/admin/dashboard/dashboard.moule').then(m => m.dashboardModule)
  },
  {
    path: 'admin-dashboard',
    loadChildren: () => import('src/app/admin/admin-dashboard/dashboard.moule').then(m => m.dashboardModule)
  },
  {
    path: 'franchisee',
    loadChildren: () => import('src/app/admin/Franchisee/franchisee.module').then(m => m.FrachiseeModule)
  },
  {
    path: 'user-job-title',
    loadChildren: () => import('src/app/admin/user-job-title/user-job-title.module').then(m => m.UserJobTitleModule)
  },
  {
    path: 'admin-employee',
    loadChildren: () => import('src/app/admin/user/components/admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: 'franchisee-employee',
    loadChildren: () => import('src/app/admin/user/components/franchisee/franchisee.module').then(m => m.FranchiseeModule)
  },
  {
    path: 'course/course-list',
    loadChildren: () => import('src/app/admin/Course/course.module').then(m => m.CourseModule)
  },
  {
    path: 'batch/batch-list',
    loadChildren: () => import('src/app/admin/Batch/batch.module').then(m => m.BatchModule)
  },
  {
    path: 'subject',
    loadChildren: () => import('src/app/admin/Subject/subject.module').then(m => m.SubjectModule)
  },
  {
    path: 'subject-tutorials',
    loadChildren: () => import('src/app/admin/subject-tutorials/subject-tutorial.module').then(m => m.SubjectTutorialsModule)
  },
  {
    path: "videos",
    loadChildren: () => import('src/app/admin/videos/videos.module').then(m => m.VideosModule)
  },
  {
    path: 'student',
    loadChildren: () => import('src/app/admin/Student/student.module').then(m => m.StudentModule)
  },
  {
    path: 'fees',
    loadChildren: () => import('src/app/admin/Fees/fees.module').then(m => m.FeesModule)
  },
  {
    path: 'wallet',
    loadChildren: () => import('src/app/admin/Wallet/wallet-admin/wallet-admin.module').then(m => m.WalletAdminModule)
  },
  {
    path: 'wallet/wallet-list',
    loadChildren: () => import('src/app/admin/Wallet/wallet-franchisee/wallet-franchisee.module').then(m => m.WalletFranchiseeModule)
  },
  {
    path: 'mail',
    loadChildren: () => import('src/app/admin/Mail/mail.module').then(m => m.MailModule)
  },
  {
    path: 'news',
    loadChildren: () => import('src/app/admin/news/news.module').then(m => m.NewsModule)
  },
  {
    path: 'vendor/vendor-list',
    loadChildren: () => import('src/app/admin/Vendor/vendor.module').then(m => m.VendorModule)
  },
  {
    path: 'indent',
    loadChildren: () => import('src/app/admin/Indent/indent.module').then(m => m.IndentModule)
  },
  {
    path: 'despatch',
    loadChildren: () => import('src/app/admin/Despatch/despatch.module').then(m => m.DespatchModule)
  },
  {
    path: 'Print',
    loadChildren: () => import('src/app/admin/Print/print.module').then(m => m.CertificatePrintListModule)
  },
  {
    path: 'reports',
    loadChildren: () => import('src/app/admin/report/report.module').then(m => m.ReportModule)
  },
  {
    path: 'stock',
    loadChildren: () => import('src/app/admin/Stock/stock.module').then(m => m.StockModule)
  },
  {
    path: "accounting",
    loadChildren: () => import('src/app/admin/Accounting/accounting.module').then(m => m.AccountingModule)
  },
  {
    path: "bank",
    loadChildren: () => import('src/app/admin/Banking/banking.module').then(m => m.BankingModule)
  },

  {
    path: "re-printing-request",
    loadChildren: () => import('src/app/admin/Re-Printing/Re-Printing.module').then(m => m.ReprintingModule)
  },

  {
    path: "indent/student-ID-card",
    loadChildren: () => import('src/app/admin/stuent-id/component/admin/admin.module').then(m => m.AdminStudentIDModule)
  },
  {
    path: "student-id-card-indent",
    loadChildren: () => import('src/app/admin/stuent-id/component/franchisee/franchisee.module').then(m => m.FranchiseeStudentIDModule)
  },

  {
    path: "role",
    loadChildren: () => import('src/app/admin/Role/roles.module').then(m => m.RolesModule)
  },
];

@NgModule({
  declarations: [LayoutComponent, SidebarComponent, TopbarComponent, FooterComponent, RightsidebarComponent, HorizontalComponent, VerticalComponent, HorizontaltopbarComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    TranslateModule,
    RouterModule,
    SimplebarAngularModule,
    ButtonsModule,
    IconsModule,
    PopupModule,
    LayoutModule,
    DialogsModule,
    ChnagePasswordModule,
  ],
  providers: [
    DialogService
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class LayoutsModule { }
