import { CustomMenu } from './menu.model';

export const MENU: CustomMenu[] = [
    {
        "subItems": [],
        "id": 1,
        "label": "Admin Dashboard",
        "link": "/admin/dashboard",
        "icon": "/assets/MenuIcons/dashboard/admin-dashboard.png",
        "parentId": 0,
        "isDefault": true
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 29,
                "label": "Branches",
                "link": "/admin/branch",
                "icon": "/assets/MenuIcons/admin/branches.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 30,
                "label": "Roles",
                "link": "/admin/role",
                "icon": "/assets/MenuIcons/admin/roles.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 63,
                "label": "Job Title",
                "link": "/admin/user-job-title/user-department",
                "icon": "/assets/MenuIcons/admin/job-titles.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1064,
                "label": "Plans",
                "link": "/admin/plans",
                "icon": "/assets/MenuIcons/admin/plans.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 31,
                "label": "Employees",
                "link": "/admin/employee",
                "icon": "/assets/MenuIcons/admin/employees.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 53,
                "label": "Agents",
                "link": "/admin/agent",
                "icon": "/assets/MenuIcons/admin/agents.png",
                "parentId": 28,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 54,
                "label": "Customers",
                "link": "/admin/customer",
                "icon": "/assets/MenuIcons/admin/customers.png",
                "parentId": 28,
                "isDefault": false
            }
        ],
        "id": 28,
        "label": "Admin",
        "link": "",
        "icon": "/assets/MenuIcons/admin/admin.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 4,
                "label": "Projects",
                "link": "/admin/project/project-list",
                "icon": "/assets/MenuIcons/master/projects.png",
                "parentId": 3,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 5,
                "label": "Blocks & Plots",
                "link": "/admin/plot/plot-list",
                "icon": "/assets/MenuIcons/master/blocksandplots.png",
                "parentId": 3,
                "isDefault": false
            }
        ],
        "id": 3,
        "label": "Master",
        "link": "",
        "icon": "/assets/MenuIcons/master/master.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 18,
                "label": "New Blocking",
                "link": "/admin/block/block-entry",
                "icon": "/assets/MenuIcons/blocking/new-blocking.png",
                "parentId": 17,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 19,
                "label": "Renewal",
                "link": "/admin/block-renewal/block-renewal-entry",
                "icon": "/assets/MenuIcons/blocking/renewal.png",
                "parentId": 17,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 20,
                "label": "Extension",
                "link": "/admin/block-extension/block-extension-entry",
                "icon": "/assets/MenuIcons/blocking/extension.png",
                "parentId": 17,
                "isDefault": false
            }
        ],
        "id": 17,
        "label": "Blocking",
        "link": "",
        "icon": "/assets/MenuIcons/blocking/blocking.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 23,
                "label": "Direct Booking",
                "link": "/admin/direct-booking/direct-booking-entry",
                "icon": "/assets/MenuIcons/booking/direct-booking.png",
                "parentId": 21,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 22,
                "label": "Booking Payment",
                "link": "/admin/booking-blocked/booking-blocked-create",
                "icon": "/assets/MenuIcons/booking/booking-blocked.png",
                "parentId": 21,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 24,
                "label": "Part Payment",
                "link": "/admin/booking/booking-part-payment-entry",
                "icon": "/assets/MenuIcons/booking/part-payment.png",
                "parentId": 21,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1063,
                "label": "Extension",
                "link": "/admin/booking-extension/booking-extension-entry",
                "icon": "/assets/MenuIcons/booking/booking-extension.png",
                "parentId": 21,
                "isDefault": false
            }
        ],
        "id": 21,
        "label": "Booking",
        "link": "",
        "icon": "/assets/MenuIcons/booking/booking.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 26,
                "label": "Blocking",
                "link": "/admin/Cancelation/blocking-cancelation",
                "icon": "/assets/MenuIcons/cancellation/blocking-cancellation.png",
                "parentId": 25,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 27,
                "label": "Booking",
                "link": "/admin/Cancelation/booking-cancelation",
                "icon": "/assets/MenuIcons/cancellation/booking-cancellation.png",
                "parentId": 25,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 57,
                "label": "Approval",
                "link": "/admin/Cancelation/approval",
                "icon": "/assets/MenuIcons/cancellation/cancellation.png",
                "parentId": 25,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 58,
                "label": "Refund",
                "link": "/admin/Cancelation/refund",
                "icon": "/assets/MenuIcons/cancellation/refund.png",
                "parentId": 25,
                "isDefault": false
            }
        ],
        "id": 25,
        "label": "Cancellation",
        "link": "",
        "icon": "/assets/MenuIcons/cancellation/cancellation.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 52,
                "label": "Receipts",
                "link": "/admin/reports/receipt-list",
                "icon": "/assets/MenuIcons/reports/receipts.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 55,
                "label": "Cancelled Plots",
                "link": "/admin/reports/cancellation-list",
                "icon": "/assets/MenuIcons/reports/projects/cancelled-plots.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 59,
                "label": "Refund Issued",
                "link": "/admin/reports/refund-issued",
                "icon": "/assets/MenuIcons/reports/agent/refund-issued.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1065,
                "label": "Fully Paid",
                "link": "/admin/reports/fully-paid-list",
                "icon": "/assets/MenuIcons/reports/projects/fully-paid.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13143,
                "label": "Vacant List",
                "link": "/admin/reports/vacant-plot",
                "icon": "/assets/MenuIcons/reports/projects/vacant-list.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13144,
                "label": "Plot History",
                "link": "/admin/reports/plot-history",
                "icon": "/assets/MenuIcons/reports/projects/plot-history.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13145,
                "label": "Upline & Downline",
                "link": "/admin/reports/agent-upline-downline",
                "icon": "/assets/MenuIcons/reports/agent/upline-and-downline.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13146,
                "label": "Eligible Incentive",
                "link": "/admin/reports/agent-eligible-incentive",
                "icon": "/assets/MenuIcons/reports/agent/eligible-incentive.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13147,
                "label": "Plan Wise Sales List",
                "link": "/admin/reports/plan-wise-sales-list",
                "icon": "/assets/MenuIcons/reports/agent/plan-wise-sales-list.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13148,
                "label": "Day Book Report",
                "link": "/admin/reports/day-book-report",
                "icon": "/assets/MenuIcons/reports/day-book-report.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 13149,
                "label": "Project Wise Collection",
                "link": "/admin/reports/project-wise-collection-report",
                "icon": "/assets/MenuIcons/reports/projects/project-wise-collection.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 14151,
                "label": "Customer History",
                "link": "/admin/reports/customer-history",
                "icon": "/assets/MenuIcons/reports/customer-history.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 14152,
                "label": "Project History",
                "link": "/admin/reports/project-history",
                "icon": "/assets/MenuIcons/reports/projects/project-history.png",
                "parentId": 51,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 14153,
                "label": "Bank Book",
                "link": "/admin/reports/bank-book",
                "icon": "/assets/MenuIcons/reports/reports.png",
                "parentId": 51,
                "isDefault": false
            }
        ],
        "id": 51,
        "label": "Reports",
        "link": "NULL",
        "icon": "/assets/MenuIcons/reports/reports.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 61,
                "label": "Plot Transfer",
                "link": "/admin/transfer/plot-transfer",
                "icon": "/assets/MenuIcons/plot-transfer/plot-transfer.png",
                "parentId": 60,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 62,
                "label": "Transfer List",
                "link": "/admin/transfer/transfer-list",
                "icon": "/assets/MenuIcons/plot-transfer/transfer-list.png",
                "parentId": 60,
                "isDefault": false
            }
        ],
        "id": 60,
        "label": "Transfer",
        "link": "",
        "icon": "/assets/MenuIcons/plot-transfer/transfer.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 1067,
                "label": "Ledger",
                "link": "/admin/accounting/ledger-list",
                "icon": "/assets/MenuIcons/accounting/ledger.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1068,
                "label": "Contra",
                "link": "/admin/accounting/contra-list",
                "icon": "/assets/MenuIcons/accounting/contra.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1069,
                "label": "Expense",
                "link": "/admin/accounting/expense-posting",
                "icon": "/assets/MenuIcons/accounting/expense.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1070,
                "label": "DayBook",
                "link": "/admin/accounting/daybook-date",
                "icon": "/assets/MenuIcons/accounting/day-book.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1071,
                "label": "Journal Report",
                "link": "/admin/accounting/journal-report",
                "icon": "/assets/MenuIcons/accounting/journal-report.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1072,
                "label": "Bank",
                "link": "/admin/banking",
                "icon": "/assets/MenuIcons/accounting/banks.png",
                "parentId": 1066,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 1073,
                "label": "Vendor",
                "link": "/admin/vendor/vendor-list",
                "icon": "/assets/MenuIcons/accounting/vendor.png",
                "parentId": 1066,
                "isDefault": false
            }
        ],
        "id": 1066,
        "label": "Accounting",
        "link": "",
        "icon": "/assets/MenuIcons/accounting/accounting.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 6141,
                "label": "Unpresented cheques",
                "link": "/admin/reports/unpresented-list",
                "icon": "/assets/MenuIcons/receipt-cheques/unpresented-cheque.png",
                "parentId": 8141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 6142,
                "label": "Presented cheques",
                "link": "/admin/reports/cheque-tracking-list",
                "icon": "/assets/MenuIcons/receipt-cheques/presented-cheque.png",
                "parentId": 8141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 9141,
                "label": "Cheque Tracking",
                "link": "/admin/reports/receipt-honour-list",
                "icon": "/assets/MenuIcons/receipt-cheques/cheque-tracking.png",
                "parentId": 8141,
                "isDefault": false
            }
        ],
        "id": 8141,
        "label": "Receipt Cheques",
        "link": "",
        "icon": "/assets/MenuIcons/receipt-cheques/receipt-cheque.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 7141,
                "label": "Issued Cheques",
                "link": "/admin/accounting/payment-cheque-list",
                "icon": "/assets/MenuIcons/payment-cheques/cheque-issued.png",
                "parentId": 8142,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 9142,
                "label": "Cheque Tracking",
                "link": "/admin/accounting/payment-honour-list",
                "icon": "/assets/MenuIcons/payment-cheques/cheque-tracking.png",
                "parentId": 8142,
                "isDefault": false
            }
        ],
        "id": 8142,
        "label": "Payment Cheques",
        "link": "",
        "icon": "/assets/MenuIcons/payment-cheques/payment-cheque.png",
        "parentId": 0,
        "isDefault": false
    },
    {
        "subItems": [
            {
                "subItems": [],
                "id": 10142,
                "label": "Configuration",
                "link": "/admin/incentive/configure",
                "icon": "/assets/MenuIcons/admin/configuration.png",
                "parentId": 10141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 10143,
                "label": "Approval",
                "link": "/admin/incentive/approval",
                "icon": "/assets/MenuIcons/incentive/approval.png",
                "parentId": 10141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 10144,
                "label": "Cash Payment",
                "link": "/admin/incentive/cash",
                "icon": "/assets/MenuIcons/incentive/cash-issue.png",
                "parentId": 10141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 10145,
                "label": "Bank Payment",
                "link": "/admin/incentive/bank",
                "icon": "/assets/MenuIcons/incentive/bank-issue.png",
                "parentId": 10141,
                "isDefault": false
            },
            {
                "subItems": [],
                "id": 10146,
                "label": "Issued",
                "link": "/admin/incentive/issued",
                "icon": "/assets/MenuIcons/incentive/issued.png",
                "parentId": 10141,
                "isDefault": false
            }
        ],
        "id": 10141,
        "label": "Incentive",
        "link": "",
        "icon": "/assets/MenuIcons/incentive/incentive.png",
        "parentId": 0,
        "isDefault": false
    }
];


export const StudentRequestData = {
    "subItems": [],
    "id": 28233,
    "label": "Request",
    "link": "/iCloud/student/enquiry/request",
    "icon": "/assets/MenuIcons/icons/request.png",
    "parentId": 0,
    "isDefault": false
}


export const StudentReportData = {
    "subItems": [],
    "id": 28233,
    "label": "Report",
    "link": "/iCloud/student/enquiry/report",
    "icon": "/assets/MenuIcons/icons/reports.png",
    "parentId": 0,
    "isDefault": false
}

export const AdminIDCard = {
    "subItems": [],
    "id": 28233,
    "label": "ID Card",
    "link": "/iCloud/Print/student-ID-card",
    "icon": "/assets/MenuIcons/franchisee/Stock.png",
    "parentId": 0,
    "isDefault": false
}
export const DespatchIDCard = {
    "subItems": [],
    "id": 28233,
    "label": "Student ID Card",
    "link": "/iCloud/despatch/student-ID-card",
    "icon": "/assets/MenuIcons/franchisee/Stock.png",
    "parentId": 0,
    "isDefault": false
}

export const FranchiseeIDCard = {
    "subItems": [],
    "id": 28233,
    "label": "Student ID Card Indent",
    "link": "/iCloud/indent/student-id-card",
    "icon": "/assets/MenuIcons/franchisee/Stock.png",
    "parentId": 0,
    "isDefault": false
}


export const WalletTransaction = {
    "id": 1084,
    "parentId": 1081,
    "label": "Transaction",
    "icon": "/assets/MenuIcons/admin/wallet_transactions.png",
    "expanded": false,
    "selected": false,
    "link": "/iCloud/wallet/wallet-transaction",
    "type": "item",
    "SortOrder": 3.3,
    "isDefault": false
}
