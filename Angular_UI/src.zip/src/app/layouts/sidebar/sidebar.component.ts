import { Component, OnInit, AfterViewInit, ElementRef, ViewChild, Input, OnChanges, Inject, EventEmitter, Output } from '@angular/core';
import MetisMenu from 'metismenujs';
import { Router, NavigationEnd } from '@angular/router';
import {  MENU, } from './menu';
import { CustomMenu, MenuItem } from './menu.model';
import { TranslateService } from '@ngx-translate/core';
// import { IUser, License } from '@src/core/model';
// import { AppService, KeyService } from '@src/core/service';
import { DOCUMENT } from '@angular/common';
import { IUser, IWebError, License } from 'src/core/model';
import { environment } from 'src/environments/environment';
import { AppService, KeyService } from 'src/core/service';
import { CrazyKey } from 'src/core/helper';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CommonService } from 'src/app/shared/service/common.service';
import { CustomNotification } from 'src/app/shared/model/shared';
// import { environment } from '@src/environments/environment';
// import { CrazyKey } from '@src/core/helper';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})

/**
 * Sidebar component
 */
export class SidebarComponent implements OnInit, AfterViewInit, OnChanges {
  @ViewChild('componentRef') scrollRef;
  @Input() isCondensed = false;
  @Output() settingsButtonClicked = new EventEmitter();
  menu: any;
  data: any;
  menuItems: MenuItem[] = [];
  @ViewChild('sideMenu') sideMenu: ElementRef;
  element: any;
  licenseObj: License = new License();
  ShowLicenseInfo = environment.ShowLicenseInfo;
  userClaims: IUser | undefined;
  signoutShowDialog = false;

  constructor(private _appService: AppService, private router: Router,
    public translate: TranslateService, @Inject(DOCUMENT) private document: any, private _srvKey: KeyService,
    private _srvCommon: CommonService, private _srvNotification: NotificationService) {
    router.events.forEach((event) => {
      if (event instanceof NavigationEnd) {
        this._activateMenuDropdown();
        this._scrollElement();
      }
    });
  }

  customeList: CustomMenu[] = [];
  ngOnInit() {
    this.element = document.documentElement;
    this.initialize();
    this._scrollElement();
    this.customeList = this._appService.menus;
    this.customeList.forEach((menu) => {
      if (this.router.url === '/iCloud') {
        if (menu.isDefault == true) {
          const i = this.customeList.findIndex((e) => e.isDefault == true);
          this.router.navigate([this.customeList[i].link]);
        }
      } else {
        if (
          !(menu.link === this.router.url) &&
          !(menu.subItems.some((x) => x.link === this.router.url)) &&
          !(menu.subItems.every((r) => !r.subItems.some((e) => e.link === this.router.url)))
        ) {
        }
      }
    });


    this.userClaims = this._appService.user;
    if (this.userClaims) this.licenseObj.LicenseInfo = 'Licensed to ' + CrazyKey.decrypt(this.userClaims.TenantName, environment._privateKey);
  }


  ngAfterViewInit() {
    this.menu = new MetisMenu(this.sideMenu.nativeElement);
    this._activateMenuDropdown();
  }

  toggleMenu(event) {
    event.currentTarget.nextElementSibling.classList.toggle('mm-show');
  }

  ngOnChanges() {
    if (!this.isCondensed && this.sideMenu || this.isCondensed) {
      setTimeout(() => {
        this.menu = new MetisMenu(this.sideMenu.nativeElement);
      });
    } else if (this.menu) {
      this.menu.dispose();
    }
  }
  _scrollElement() {
    setTimeout(() => {
      if (document.getElementsByClassName("mm-active").length > 0) {
        const currentPosition = document.getElementsByClassName("mm-active")[0]['offsetTop'];
        if (currentPosition > 500)
          if (this.scrollRef.SimpleBar !== null)
            this.scrollRef.SimpleBar.getScrollElement().scrollTop =
              currentPosition + 300;
      }
    }, 300);
  }

  /**
   * remove active and mm-active class
   */
  _removeAllClass(className) {
    const els = document.getElementsByClassName(className);
    while (els[0]) {
      els[0].classList.remove(className);
    }
  }

  /**
   * Activate the parent dropdown
   */
  _activateMenuDropdown() {
    this._removeAllClass('mm-active');
    this._removeAllClass('mm-show');
    const links = document.getElementsByClassName('side-nav-link-ref');
    let menuItemEl = null;
    // tslint:disable-next-line: prefer-for-of
    const paths = [];
    for (let i = 0; i < links.length; i++) {
      paths.push(links[i]['pathname']);
    }
    var itemIndex = paths.indexOf(window.location.pathname);
    if (itemIndex === -1) {
      const strIndex = window.location.pathname.lastIndexOf('/');
      const item = window.location.pathname.substr(0, strIndex).toString();
      menuItemEl = links[paths.indexOf(item)];
    } else {
      menuItemEl = links[itemIndex];
    }
    if (menuItemEl) {
      menuItemEl.classList.add('active');
      const parentEl = menuItemEl.parentElement;
      if (parentEl) {
        parentEl.classList.add('mm-active');
        const parent2El = parentEl.parentElement.closest('ul');
        if (parent2El && parent2El.id !== 'side-menu') {
          parent2El.classList.add('mm-show');
          const parent3El = parent2El.parentElement;
          if (parent3El && parent3El.id !== 'side-menu') {
            parent3El.classList.add('mm-active');
            const childAnchor = parent3El.querySelector('.has-arrow');
            const childDropdown = parent3El.querySelector('.has-dropdown');
            if (childAnchor) { childAnchor.classList.add('mm-active'); }
            if (childDropdown) { childDropdown.classList.add('mm-active'); }
            const parent4El = parent3El.parentElement;
            if (parent4El && parent4El.id !== 'side-menu') {
              parent4El.classList.add('mm-show');
              const parent5El = parent4El.parentElement;
              if (parent5El && parent5El.id !== 'side-menu') {
                parent5El.classList.add('mm-active');
                const childanchor = parent5El.querySelector('.is-parent');
                if (childanchor && parent5El.id !== 'side-menu') { childanchor.classList.add('mm-active'); }
              }
            }
          }
        }
      }
    }

  }

  /**
   * Initialize
   */
  initialize(): void {
    this.menuItems = MENU;
  }

  /**
   * Returns true or false if given menu item has child or not
   * @param item menuItem
   */
  hasItems(item: MenuItem) {
    return item.subItems !== undefined ? item.subItems.length > 0 : false;
  }

  SignOut() {
    this.signoutShowDialog = true;
  }

  signoutDialogClose() {
    this.signoutShowDialog = false;
  }
  signoutMember() {
    this._srvCommon.logout().subscribe({
      next: (res: any) => new CustomNotification(this._srvNotification).ShowSuccess(res.Message),
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
    this._srvKey.SignOut();
    if (document.fullscreenElement) {
      document.exitFullscreen();
    }
  }

  ChangeTheme() {
    this.settingsButtonClicked.emit();
  }
  /**
   * Fullscreen method
   */
  fullscreen() {
    document.body.classList.toggle('fullscreen-enable');
    if (
      !document.fullscreenElement && !this.element.mozFullScreenElement &&
      !this.element.webkitFullscreenElement) {
      if (this.element.requestFullscreen) {
        this.element.requestFullscreen();
      } else if (this.element.mozRequestFullScreen) {
        /* Firefox */
        this.element.mozRequestFullScreen();
      } else if (this.element.webkitRequestFullscreen) {
        /* Chrome, Safari and Opera */
        this.element.webkitRequestFullscreen();
      } else if (this.element.msRequestFullscreen) {
        /* IE/Edge */
        this.element.msRequestFullscreen();
      }
    } else {
      if (this.document.exitFullscreen) {
        this.document.exitFullscreen();
      } else if (this.document.mozCancelFullScreen) {
        /* Firefox */
        this.document.mozCancelFullScreen();
      } else if (this.document.webkitExitFullscreen) {
        /* Chrome, Safari and Opera */
        this.document.webkitExitFullscreen();
      } else if (this.document.msExitFullscreen) {
        /* IE/Edge */
        this.document.msExitFullscreen();
      }
    }
  }
}
