import { NgModule } from '@angular/core';
import { nl2brPipe } from './address.pipe';
import { CurrencyGuruPipe } from './currency.pipe';
import { DateGuruPipe } from './date.pipe';


@NgModule({
  imports: [],
  exports: [CurrencyGuruPipe, DateGuruPipe, nl2brPipe],
  declarations: [CurrencyGuruPipe, DateGuruPipe, nl2brPipe],
})
export class PipeModule { }
