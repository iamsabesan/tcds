export class DawnURL {
    static baseUrl = '/icloud-';
    static apiVersion = 'v1/';
    static dashboard = 'dashboard/';
    static admission = 'admission/';
    static academic = 'academic/';
    static inventory = 'inventory/';
    static user = '/user-service/user/';
    static batch = 'batch/';
    static course = 'course/';
    static material = 'material/';
    static subject = 'subject/';
    static payment = 'payment/';
    static accounting = 'accounting/';
    static receipt = 'receipt/';
    static customer = 'customer/';
    static auditUser = '/user-service/v1/audit/user/';
    static tenantBranch = '/tenant-branch-service/tenantbranch/';
    static email = 'email/';
}

/* Admin */
export class Admin {
    //#region Branch
    static getBranches = `${DawnURL.tenantBranch}list`;
    static getHomeBranchDetailsUrl = `${DawnURL.tenantBranch}home-branch-detail`;
    static createBranche = `${DawnURL.tenantBranch}create`;
    //#endregion

    //#region Employee
    static getEmployee = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}${DawnURL.batch}faculty/list`;
    static createEmployee = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}${DawnURL.batch}faculty/list`;
    //#endregion

    //#region Roles
    // static getDepartment = `${DawnURL.user}get-all-departments`;
    static getDepartment = `${DawnURL.user}get-all-departments`;
    static getRoleMenu = `${DawnURL.user}get-role-menu?AuthRoleID=`;
    static updateRoleMenu = `${DawnURL.user}update-role-menu`;
    //#endregion
}

export class Franchisee {
    static updateFranchiseeDetail = `${DawnURL.baseUrl}franchisee/v1/franchisee/edit/contact`;
    static updateFranchiseeAddressDetail = `${DawnURL.baseUrl}franchisee/v1/franchisee/edit`;
}

export class Master {
    //#region Course
    static getAdmninCourse = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.course}list`;
    static getFranchiseeCourse = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.course}list/byfranchisee`;
    static getCourseType = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.course}type/list`;
    static createCourse = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.course}create`;
    static updateCourse = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.course}edit`;
    //#endregion

    //#region Material
    static getMaterialType = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}type/list`;
    static getMaterial = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}list?MaterialTypeID=`;
    static createMaterialType = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}createtype`;
    static createMaterial = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}create`;
    static updateMaterial = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}edit`;
    //#endregion

    //#region Subject
    static getSubject = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}list`;
    static createSubject = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}create`;
    static updateSubject = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}edit`;
    //#endregion

    //#region Subject Video
    static getSubjectVideo = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}video/list?subjectID=`;
    static mappedVideo = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}video-mapping`;
    static editVideo = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}video/edit`;
    static deleteVideo = `${DawnURL.baseUrl}${DawnURL.academic}${DawnURL.apiVersion}${DawnURL.subject}video/delete`;
    //#endregion
}

export class Mail {
    //#region Inbox
    static getInboxMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}inbox/list`;
    static unreadMailRead = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}read?mailOutBoxID=`;
    static deleteMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}delete?mailOutBoxID=`;
    //#endregion

    //#region Sent
    static getSentMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}send/list`;
    //#endregion

    //#region Trash
    static getTrashMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}delete/list`;
    static restoreMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}rollback?mailOutBoxID=`;
    //#endregion

    //#region Compose
    static getComposeToMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}branch/wise/contact`;
    static createNewMail = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}create`;
    static getEmailAttachment = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}`;
    static downloadAttachment = `/${DawnURL.email}${DawnURL.apiVersion}${DawnURL.email}download/`;
    //#endregion
}

export class Student {
    static getReason = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}student/reason/dropdown`;
    static getTCDSCentre = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}student/referby/dropdown`;
    static getPurpose = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}student/purpose/dropdown`;
}

/* Re-Print Request */
export class RePrintRequest {
    //icloud-admission/v1/student/reprint/student/list
    //student/reprint/student/mark?batchMappingID=f81f0c57-311c-403a-b3d0-d6822e2500d1&semester=2
    static getStudentDetail = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}student/reprint/student/list`;
    static getStudentCertificateMarksheet = `${DawnURL.baseUrl}${DawnURL.admission}${DawnURL.apiVersion}student/reprint/student/mark?batchMappingID=`;
    static getMarksheetPreview = ``;
    static getCertificatePreview = ``;
    static reprintRequest = ``;
}

export class Despatch {
    static getAdminIDCardDespatch = `/icloud-inventory/v1/indent/id-card/despatch/list`;
    static postStudentIDCardDespatch = `/icloud-inventory/v1/indent/id-card/despatch`;
}

export class Common {
    //#region Communication
    static getCountry = '/common/country';
    static getState = `/common/state/`;
    static getDistrict = `/common/district/`;
    //#endregion

    //#region Basic
    static getPhoneCode = `/common/phonecode`;
    static getGender = `/common/gender`;
    static getBank = `/common/Bank`;
    //#endregion

    //#region Document URL
    static documentUrl = '/document-service/image/profile/';
    //#endregion

    //#region Change Password
    static changePassword = `${DawnURL.auditUser}change-password`
    //#endregion


    //#region Logout
    static logout = `${DawnURL.auditUser}logout`;
    //#endregion

    static getAllMaterial = `${DawnURL.baseUrl}${DawnURL.inventory}${DawnURL.apiVersion}${DawnURL.material}alllist`;
}


export class Fees {
    static getStudentFeesStatus = `/icloud-admission/v1/student/status/dropdown/web`;

    static getIDCardCharges = `/icloud-franchisee/v1/franchisee/id-card/charges`;
    static getCourierCharge = `/icloud-franchisee/v1/franchisee/courier/charges`;

    /* Admin Charger Update */
    static postIndentFeesUpdate = `/icloud-franchisee/v1/franchisee/idcard-courier/charge/update`;
    // static postCourierChargeUpdate = `/icloud-franchisee/v1/franchisee/courier/charge/update?amount=`;
    // static postIDCardCharegeUpdate = `/icloud-franchisee/v1/franchisee/id-card/charge/update?amount=`;
}

export class StudentIDCard {
    static postCreateStudentId = `/icloud-inventory/v1/indent/id-card`;
    static getFrStudentIdCardList = `/icloud-inventory/v1/indent/id-card/list?`;
    static getStudentIDStatusList = `/icloud-inventory/v1/indent/id-card/status/dropdown`;
    static getStudentIDCardViewDetailsFr = `/icloud-inventory/v1/indent/id-card/details`;
    static postStudentIDCardReceive = `/icloud-inventory/v1/indent/id-card/receive`

    /* Admin */
    static getAdminStudentIDCardIndent = `/icloud-inventory/v1/indent/id-card/list-by/admin`;
    static getAdminStudentIDCardDetail = `/icloud-inventory/v1/indent/id-card/view-by/admin?iDCardIndentID=`;
    static getAdminStudentIDCardReject = `/icloud-inventory/v1/indent/id-card/reject`;
    static getAdminStudentIDCardApprove = `/icloud-inventory/v1/indent/id-card/approve`;
    static updatePrintedStatus = `/icloud-inventory/v1/indent/id-card/print/status`;
    // static previewStudentIDCard = `/icloud-admission/v1/student/id-cards/print`;
    static getStudentIDCardPrintLst = `/icloud-inventory/v1/indent/id-card/print/list`;
}
export class TelerikReportViewer {
    private static _getBaseURL = 'iCloud/';
    static getStudentIDCard = `${this._getBaseURL}StudentID_Card`;
}