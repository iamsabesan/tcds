import { DropDownFilterSettings, VirtualizationSettings } from "@progress/kendo-angular-dropdowns";

export class ZeroGUID {
  static guid = '00000000-0000-0000-0000-000000000000';
}

export class Theme {
  static ActiveThemeType = "light";
  static ActiveThemeName = "";
}

export class License {
  LicensedTo = '';
  LicenseInfo = '';
}
// Project List screen
export class ListType {
  static ActiveListType = "Grid";
}

// User List screen
export class UserListType {
  static ActiveListType = "Grid";
}

// Project List screen
export class ShowInactive {
  static ShowInactiveProject = false;
  static ShowInactiveBranch = false;
  static ShowInactiveUser = false;
  static ShowInactiveAgent = false;
  static ShowInactiveCustomer = false;
  static ShowActiveFranchisee = true;
  static ShowInactiveEmployee = false;
  static ShowInactiveBatch = false;
  static ShowInactiveBank = false;
}

export class ThemesList {
  themeType = "";
  themeName = "";
  displayName = "";
  displayColor = "";
}

export const themeList: ThemesList[] = [
  { themeType: 'light', themeName: 'kashmirBlue', displayName: 'Kashmir Blue', displayColor: 'background-color: #58639b;' },
  { themeType: 'light', themeName: 'pacificBlue', displayName: 'Pacific Blue', displayColor: 'background-color: #12a1a3' },
  { themeType: 'light', themeName: 'astronautBlue', displayName: 'Astronaut Blue', displayColor: 'background-color: #0f446c' },
  { themeType: 'light', themeName: 'persianBlue', displayName: 'Persian Blue', displayColor: 'background-color: #222fb9' },
  { themeType: 'light', themeName: 'elfGreen', displayName: 'Elf Green', displayColor: 'background-color: #008d70' },
  { themeType: 'light', themeName: 'aquaDeep', displayName: 'Aqua Deep', displayColor: 'background-color: #0a4450' },
  { themeType: 'light', themeName: 'mustardBrown', displayName: 'Mustard Brown', displayColor: 'background-color: #a57c11' },
  { themeType: 'light', themeName: 'pastelBrown', displayName: 'Pastel Brown', displayColor: 'background-color: #876154' },
  { themeType: 'light', themeName: 'magnesioGrey', displayName: 'Magnesio Grey', displayColor: 'background-color: #424242' },
  { themeType: 'light', themeName: 'minimalGrey', displayName: 'Minimal Grey', displayColor: 'background-color: #f3f3f3' },
  { themeType: 'dark', themeName: 'gunmetalGrey', displayName: 'Gunmetal Grey', displayColor: 'background-color: #2e3446' },
  { themeType: 'dark', themeName: 'darkJungle', displayName: 'Dark Jungle', displayColor: 'background-color: #1f1f1f' }
]

export class LocalString {
  static Agent: string = "Agent";
  static AgentCaps: string = LocalString.Agent.toUpperCase();
  static CurrencySymbol: string = "";
  static LanguageCulture: string = "en-IN"
  static UserName: string = "";
  static LicenseInfo: string = "";
  static TenantID: string = '';
  static TenantBranchID: string = '';
  static DateTimeFormat: string = "";
  static DateFormat: string = "";
  static TimeFormat: string = "";
  static showAddButton: boolean = true;
  static Currency: string = '';
  static CurrencyCode: string = '';
  static LocaleID: string = '';
  static IsAdmin: boolean = true;
  static CurrencyFormat = 'c2';
  static NumberFormat = 'n0';
}

export const perVal: string = "";

export class GlobalMapValues {
  static zoomSize: number = 0;
  static center: number[] = [];
}

/* Get URL */
export class getUrl {
  static invokingUrl: string = '';
  static currentUrl: string = '';
  static params = [];
}

/* Subscription Info */
export class SubscriptionInfo {
  static ApprovalStartDate: string = "";
  static ApprovalEndDate: string = "";
  static ApprovalStatus: string = "";
  static SubscriptionStartDate: string = "";
  static SubscriptionEndDate: string = "";
  static SubscriptionStatus: string = "";
  static PollingInterval: number = 0;
}

/* Grid Header & Data Size */
export class gridFontStyle {
  gridClass: string;
  gridColumn: string;
  gridColumnGroup: string;

  constructor(public FontSize: string = 'small') {
    this.gridClass = 'grid-' + FontSize + '-class';
    this.gridColumn = 'grid-' + FontSize + '-column';
    this.gridColumnGroup = 'grid-' + FontSize + '-column-group';

  }
}

/* Date Range Width */
export class DateSize {
  small: string;
  medium: string;
  large: string;

  constructor(public width: string = 'small') {
    // this.groupHeaderClass = 'info-grid-' + this.width + '-group-header';
    // this.columnHeaderClass = 'info-grid-' + this.width + '-header';
    // this.gridDataRowClass = 'info-grid-' + this.width + '-datarow';
    // this.gridOptionColClass = 'info-grid-' + this.width + '-header-center';

    this.small = 'date-' + width;
    this.medium = 'date-' + width;
    this.large = 'date-' + width;

  }
}

/* Dropdown Filter */
export class DropDownFilter {
  public static filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains'
  }

  public static StartWithfilterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'startsWith'
  }
}

export class Gender {
  static LstGender: string[] = ['Male', 'Female', 'Non Binary'];
}

export class Gurdian {
  static LstGurdian: string[] = ['Father', 'Mother', 'Guardian']
}



export class FileExtension {
  static FileTypeExtension = ".jpg, .png, .jpeg, .zip, .docx, .xlsx, .pdf, .rar, .svg, .txt, .mp4";
}

/* Date Conversion */
export class DateConversion {
  static userClaims: any;
  static response: Date = new Date();
  static ConvertToDateMonthYear(str: any) {
    var date = new Date(str),
      mnth = ('0' + (date.getMonth() + 1)).slice(-2),
      day = ('0' + date.getDate()).slice(-2);
    const res = [day, mnth, date.getFullYear()].join('-');
    return res;
  }

  static ConvertToYearMonthDate(str: any) {
    var date = new Date(str),
      mnth = ('0' + (date.getMonth() + 1)).slice(-2),
      day = ('0' + date.getDate()).slice(-2);
    const res = [date.getFullYear(), mnth, day].join('-');
    return res;
  }

  static ConvertMonthDateYear(str: any) {
    var date = new Date(str),
      mnth = ('0' + (date.getMonth() + 1)).slice(-2),
      day = ('0' + date.getDate()).slice(-2);
    const res = [mnth, day, date.getFullYear()].join('-');
    return res;
  }

  static ConvertToYearDateMonth(str: any) {
    var date = new Date(str),
      mnth = ('0' + (date.getMonth() + 1)).slice(-2),
      day = ('0' + date.getDate()).slice(-2);
    const res = [date.getFullYear(), day, mnth].join('-');
    return res;
  }

  static ConvertToMonthDateYear(str: any) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2)
    const res = [mnth, day, date.getFullYear()].join("/");
    return res;
  }

  static ConvertStringToDate(str: string) {
    const date = parseInt(str.split('-')[0]);
    const month = parseInt(str.split('-')[1]) - 1;
    const year = parseInt(str.split('-')[2]);
    this.response = new Date(year, month, date);
    return this.response;
  }

  static ConvertStringToDateYYMMDD(str: string) {
    const date = parseInt(str.split('-')[2]);
    const month = parseInt(str.split('-')[1]) - 1;
    const year = parseInt(str.split('-')[0]);
    this.response = new Date(year, month, date);
    return this.response;
  }


  static ConvertDateToString(str: Date) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    const res = [mnth, day, date.getFullYear()].join("-");
    return res;
  }

  static ConvertStringToDateTime(str: string): Date {
    if (!str) return null;

    const [datePart, timePart, period] = str.trim().split(' ');
    const [day, month, year] = datePart.split('-').map(Number);
    let [hours, minutes, seconds] = timePart.split(':').map(Number);

    // Convert 12-hour to 24-hour format
    if (period === 'PM' && hours < 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;

    return new Date(year, month - 1, day, hours, minutes, seconds);
  }

}



export class FileIcons {
  static getIcons(fileType: any) {
    switch (fileType) {
      case ('png'):
      case ('jpeg'):
      case ('jpg'):
      case ('svg'): {
        return "k-icon k-i-image";
      }
      case ('xlsx'):
      case ('xls'): {
        return "k-icon k-i-excel";
      }
      case ('csv'): {
        return "k-icon k-i-file-csv";
      }
      case ('pdf'): {
        return "k-icon k-i-file-pdf";
      }
      case ('pptx'): {
        return "k-icon k-i-file-ppt";
      }
      case ('docx'): {
        return "k-icon k-i-file-word";
      }
      case ('txt'): {
        return "k-icon k-i-file-txt";
      }
      case ('zip'): {
        return "k-icon k-i-file-zip";
      }
      default: {
        return "k-icon k-i-attachments"
      }
    }
  }
}


export class CountryCurrency {
  static CountryCurrencyType: string = 'Rs. '
  static CountryCurrencyEnd: string = '/-'
}

export class Virtual {
  static virtual: VirtualizationSettings = {
    itemHeight: 36, // @progress/kendo-theme-default default item height
  };
}