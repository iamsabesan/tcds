import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DialogRef } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
import { FileRestrictions, RemoveEvent, SelectEvent } from '@progress/kendo-angular-upload';
import { FileExtension, gridFontStyle } from 'src/app/shared/app-global';
import { composeMailToDataType, createMailDataType, ToContactID } from 'src/app/shared/model/mailbox';
import { CustomNotification } from 'src/app/shared/model/shared';
import { CommonService } from 'src/app/shared/service/common.service';
import { MailboxService } from 'src/app/shared/service/mailbox.service';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-compose',
  templateUrl: './compose.component.html',
  styleUrls: ['./compose.component.scss']
})

export class ComposeComponent {

  /* List */
  LstToMail: composeMailToDataType[] = [];

  /* Grid Header Style */
  public gridStyle = new gridFontStyle();
  public MlCreateNewMail: createMailDataType = new createMailDataType();

  public value: any = [];
  public Attachment = [];
  public isChecked: boolean = false;

  composeForm = this.fb.group({
    to: [],
    subject: [],
    editor: [],
    files: [],
  });

  /* File Restrictions  */
  myRestrictions: FileRestrictions = {
    allowedExtensions: [".jpg", ".png", ".jpeg", ".zip", ".docx", ".xlsx", ".pdf", ".rar", ".svg", ".txt", ".mp4"],
  };

  public FileExtension = FileExtension.FileTypeExtension;

  /* Disabled the To Dropdown for Franchisee Mail */
  public IsDisabledToCombobox: boolean = false;

  constructor(public fb: FormBuilder, public dialog: DialogRef, private _srvMail: MailboxService,
    private _srvNotification: NotificationService, private _srvCommon: CommonService) { }

  ngOnInit(): void {
    this.getFranchiseeBasicData();
  }

  getFranchiseeBasicData(): void {
    this._srvMail.getComposeMailToData().subscribe({
      next: (e: any) => {
        this.LstToMail = e.Data;
        this.IsDisabledToCombobox = false;
        this.LstToMail.filter((e: any) => {
          e.Address = this._srvCommon.concatAddress(e)
          if (e.ContactName == 'TCDS-HO') {
            this.value = this.LstToMail;
            this.isItemSelected(this.LstToMail[0]);
            this.isChecked = this.IsDisabledToCombobox = true;
            this.onValueChange();
          }
          else {
            this.isChecked = this.IsDisabledToCombobox = false;
          }
        });
        
      },
      error: (err: IWebError) => this._errorMsg(err.Message)
    });
  }

  /* Close Dialog */
  btnCloseDialog() {
    this.composeForm.reset();
    this.dialog.close();
  }

  /* Post a New Mail */
  btnSubmitNewMail(data: any) {
    this.MlCreateNewMail.toContactID = [];
    if (this.composeForm.invalid) this.composeForm.markAllAsTouched();
    else {
      if (this.MlCreateNewMail.attachment?.length > 10) this._errorMsg("A Maximum of 10 files are permitted.");
      else {
        const CheckFileSize = this.MlCreateNewMail.attachment?.some((e) => e.size > 5242880);
        const CheckFileName = this.MlCreateNewMail.attachment?.find(e => e.size > 5242880)?.name;

        if (CheckFileSize) this._errorMsg(`${CheckFileName} file size greater than 5 MB`);
        else {
          this.MlCreateNewMail.subject = data.subject;
          this.MlCreateNewMail.mailContent = data.editor == null ? "" : data.editor;

          data.to.forEach((e: any) => {
            const FranchiseeID = new ToContactID();
            FranchiseeID.ToContactID = e.ContactID;
            this.MlCreateNewMail.toContactID.push(FranchiseeID);
          });
          this._srvMail.postComposeMail(this.MlCreateNewMail).subscribe({
            next: (e) => {
              new CustomNotification(this._srvNotification).ShowSuccess(e.Message);
              this.btnCloseDialog();
            },
            error: (err) => this._errorMsg(err.Message)
          });
        }
      }
    }
  }

  /* Select Particular Franchisee */
  isItemSelected(item: any) {
    return this.value.some((x: any) => x.ContactID === item.ContactID);
  }

  /* Select All Particular Franchisee */
  allFranchisee() {
    this.isChecked = !this.isChecked;
    this.value = this.isChecked ? this.LstToMail.slice() : [];
  }

  onValueChange() {
    this.isChecked = this.value.length === this.LstToMail.length;
  }

  /* Upload Document */
  selectDocument(e: SelectEvent): void {
    e.files.forEach((e) => {
      if (e.size > 5242880) this._errorMsg("File size is too large");
    });
  }

  /* Mail Document Upload */
  valueChange(event: any) {
    const allowedExtensions = this.myRestrictions.allowedExtensions;
    const validFiles = [];
    if (event) {
      event.forEach((file: any) => {
        const fileExtension = file.name.split('.').pop().toLowerCase();
        if (allowedExtensions.includes(`.${fileExtension}`)) {
          if (file.size > 5242880) this._errorMsg("File size is too large");
          else validFiles.push(file);
        }
        else this._errorMsg("The file type is not accepted.")
      });
      this.MlCreateNewMail.attachment = this.Attachment = validFiles;
    }
    else this.MlCreateNewMail.attachment = this.Attachment = [];
  }


  remove(e: RemoveEvent): void {
    console.log(e);
  }

  /* Show Error Msg */
  private _errorMsg = (err: string) => new CustomNotification(this._srvNotification).ShowError(err)
}
