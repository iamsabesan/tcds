import { Component, HostListener, NgZone, ViewChild } from '@angular/core';
import { DialogService } from '@progress/kendo-angular-dialog';
import { DrawerItem, DrawerSelectEvent } from '@progress/kendo-angular-layout';
import { ComposeComponent } from '../compose/compose.component';
import { SentComponent } from '../sent/sent.component';

@Component({
  selector: 'app-drawer-manu',
  templateUrl: './drawer-manu.component.html',
  styleUrls: ['./drawer-manu.component.scss']
})
export class DrawerManuComponent {

  @ViewChild(SentComponent) sendComponent: SentComponent;
  public drawerExpanded = true;
  public selected = "Inbox";

  /* Expand Drawer */
  public expanded = true;

  dialogHeight = 628;
  dialogWidth = 900;

  public items: Array<DrawerItem> = [
    { text: "Inbox", icon: "k-i-inbox", selected: true },
    { text: "Sent", icon: "k-i-envelop" },
    { text: "Trash", icon: "k-i-trash" },
  ];




  constructor(private _dialogService: DialogService, private ngZone: NgZone) {
    this.setDialogHeight();
  }

  @HostListener('window:resize', [])
  onResize(): void {
    this.ngZone.run(() => {
      this.setDialogHeight();
    });
  }

  private setDialogHeight(): void {
    const windowHeight = window.innerWidth;

    if (windowHeight >= 1000 && windowHeight <= 1402) {
      this.dialogHeight = 550;
      this.dialogWidth = 800;
    } else {
      this.dialogHeight = 628;
      this.dialogWidth = 900;
    }
  }

  /* Drawer Item Select */
  public onSelect(ev: DrawerSelectEvent): void {
    this.selected = ev.item.text;
  }

  /* Dialog Open */
  public openComposeMail(): void {
    this.setDialogHeight();
    const dialogRef = this._dialogService.open({
      title: 'New Mail',
      content: ComposeComponent,
      width: this.dialogWidth,
      height: this.dialogHeight,
      maxHeight: '85%'
    });

    dialogRef.result.subscribe(() => {
      if (this.selected == "Sent") this.sendComponent.getSentMail();
    });
  }
}
