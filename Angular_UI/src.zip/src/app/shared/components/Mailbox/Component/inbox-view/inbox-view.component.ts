import { Component } from '@angular/core';
import { DialogRef } from '@progress/kendo-angular-dialog';
import { attachmentDataType, sentMailDataType } from 'src/app/shared/model/mailbox';
import { MailboxService } from 'src/app/shared/service/mailbox.service';

@Component({
  selector: 'app-inbox-view',
  templateUrl: './inbox-view.component.html',
  styleUrls: ['./inbox-view.component.scss']
})

export class InboxViewComponent {
  public mailDataView: sentMailDataType = new sentMailDataType()
  public maildata = [];
  public tovalue!: boolean;
  public fromValue: any;
  public time: Date = new Date();
  public Attachment: attachmentDataType[] = [];

  constructor(private _srvMail: MailboxService, public dialog: DialogRef) {
  }

  ngOnInit() {
    this._srvMail.mailData.subscribe((e: any) => {
      this.Attachment = e.mailboxType.Attachments;
      this.mailDataView = e.mailboxType;
      this.time = this.mailDataView.Date;
      this.tovalue = this.mailDataView.To == undefined ? false : true;
      if (e.mailboxType.Content == "null") e.mailboxType.Content = "";
    });
  }

  close() {
    this.dialog.close()
  }
  pdfDownload(item: attachmentDataType) {
    this._srvMail.downloadAttachment(item, item.ContentUrl.split("/")[1]);
  }
}
