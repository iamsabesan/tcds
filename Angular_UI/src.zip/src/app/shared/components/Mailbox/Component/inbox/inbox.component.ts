import { Component } from '@angular/core';
import { DialogService } from '@progress/kendo-angular-dialog';
import { PagerPosition, RowClassArgs } from '@progress/kendo-angular-grid';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PagerType } from '@progress/kendo-angular-pager';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { ToDataType } from 'src/app/shared/model/mailbox';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MailboxService } from 'src/app/shared/service/mailbox.service';
import { InboxViewComponent } from '../inbox-view/inbox-view.component';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent {

  /* List */
  public inboxData: ToDataType[] = [];

  /* Filter */
  filter!: CompositeFilterDescriptor;

  /* Date Format */
  public dateFormat: string = '';

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('small');

  /* Grid Pagination */
  public buttonCount = 5;
  public pageSize = 15;
  public sizes = [25, 50, 100];
  public skip = 0;
  public type: PagerType = "numeric";
  public info = true;
  public previousNext = true;
  public position: PagerPosition = "bottom";

  public IsDialogOpen = false;
  public DeleteOneMail: ToDataType = new ToDataType();

  constructor(private dialogService: DialogService, private _srvMail: MailboxService, private _srvNotification: NotificationService) { }

  ngOnInit() {
    this.getInboxMail();
  }

  /* Get Inbox Mail */
  getInboxMail() {
    this._srvMail.getFranchiseeInboxMail().subscribe({
      next: (e) => {
        this.inboxData = e.Data;
        if (this.inboxData.length) {
          this.inboxData.filter((e: ToDataType) => {
            e.Add1 = e.District + ", " + e.State + ".";
            if (!e.Address2) e.Address = e.Address1 + ", " + e.Address2 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;
            else e.Address = e.Address1 + ", " + e.Area + ", " + e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode;

            if (e.FranchiseeID !== "") {
              e.Franchisee = e.FranchiseeID + " - " + e.BranchName + " - " + e.Add1;
              e.sentFranchisee = e.FranchiseeID + " - " + e.BranchName + " - " + e.Add1;
            }
            else {
              e.Franchisee = e.BranchName + " - " + e.Add1;
              e.sentFranchisee = e.BranchName + " - " + e.Add1;
            }
          });
        }
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  /* UnRead Mail Highlight Colors */
  public rowCallback = (context: RowClassArgs): any => {
    if (this.inboxData.length) return context.dataItem.Status.toLowerCase() == 'new' ? 'unread' : 'read';
  }

  /* View the Mail */
  viewInboxData(data: ToDataType) {
    this._srvMail.mailData.subscribe((e: any) => {
      e.mailboxType = data;
    });

    this.dialogService.open({
      title: "Inbox",
      content: InboxViewComponent,
      width: 600,
      height: 600,
    });

    this._srvMail.postInboxMailRead(data.MailOutBoxID).subscribe({
      next: () => this.getInboxMail(),
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  deleteMail(data: ToDataType) {
    this.DeleteOneMail = new ToDataType();
    this.DeleteOneMail = data;
    this.IsDialogOpen = true;
  }

  DialogClose() {
    this.IsDialogOpen = false;
  }

  DeleteMail() {
    this._srvMail.postInboxMailDelete(this.DeleteOneMail.MailOutBoxID).subscribe({
      next: (response: any) => {
        new CustomNotification(this._srvNotification).ShowSuccess(response.Message);
        this.getInboxMail();
        this.DialogClose();
      },
      error: (error: any) => new CustomNotification(this._srvNotification).ShowError(error.Message)
    });
  }
}
