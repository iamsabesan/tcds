import { Component } from '@angular/core';
import { DialogService } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { sentMailDataType } from 'src/app/shared/model/mailbox';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MailboxService } from 'src/app/shared/service/mailbox.service';
import { InboxViewComponent } from '../inbox-view/inbox-view.component';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.scss']
})

export class SentComponent {

  /* List */
  public LstSentMail: sentMailDataType[] = []

  /* Grid Filter */
  public filter!: CompositeFilterDescriptor;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('small');

  /* Grid Pagination */
  public buttonCount = 5;
  public sizes = [25, 50, 100];
  public skip = 0;

  constructor(private dialogService: DialogService, public service: MailboxService, public notificationService: NotificationService) { }

  ngOnInit() {
    this.getSentMail();
  }

  /* Get Sent Mail List */
  getSentMail() {
    this.service.getAdminSentMail().subscribe({
      next: (e) => {
        this.LstSentMail = e.Data;

        this.LstSentMail.filter((val: sentMailDataType) => {
          // e.Add1 = e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode + ".";
          val.To.Add1 = val.To.District + ", " + val.To.State;

          if (!val.To.Address2) val.To.Address = val.To.Address1 + ", " + val.To.Address2 + ", " + val.To.Area + ", " + val.To.District + ", " + val.To.State + ", " + val.To.Country + " - " + val.To.Pincode;
          else val.To.Address = val.To.Address1 + ", " + val.To.Area + ", " + val.To.District + ", " + val.To.State + ", " + val.To.Country + " - " + val.To.Pincode;

          if (val.To.FranchiseeID !== "") val.To.Add1 = val.To.FranchiseeID + ", " + val.To.BranchName + ", " + val.To.Add1 + ".";
          else val.To.Add1 = val.To.BranchName + ", " + val.To.Add1 + ".";
        });
      },
      error: (err) => new CustomNotification(this.notificationService).ShowError(err.Message)
    })
  }

  /* View Mail */
  view(data: any) {
    this.service.mailData.subscribe((e: any) => {
      e.mailboxType = data;
    });

    this.dialogService.open({
      title: "Sent",
      content: InboxViewComponent,
      width: 600,
      height: 600,
    });
  }
}
