import { Component } from '@angular/core';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { gridFontStyle } from 'src/app/shared/app-global';
import { trashMailDataType } from 'src/app/shared/model/mailbox';
import { CustomNotification } from 'src/app/shared/model/shared';
import { MailboxService } from 'src/app/shared/service/mailbox.service';

@Component({
  selector: 'app-trash',
  templateUrl: './trash.component.html',
  styleUrls: ['./trash.component.scss']
})

export class TrashComponent {

  /* List */
  public LstTrashMail: trashMailDataType[] = [];

  /* Grid Filter */
  public filter: CompositeFilterDescriptor;

  /* Grid Header Style */
  public gridStyle = new gridFontStyle('small');

  /* Grid Pagination */
  public buttonCount: number = 5;
  public sizes = [25, 50, 100];
  public skip: number = 0;


  public IsDialogOpen = false;
  public RestoreOneMail: trashMailDataType = new trashMailDataType();

  constructor(private _srvNotification: NotificationService, private _srvMail: MailboxService) { }

  ngOnInit() {
    this.getTrashMail();
  }

  getTrashMail() {
    this._srvMail.getAdminDeleteMail().subscribe({
      next: (e) => {
        this.LstTrashMail = e.Data;
        this.LstTrashMail.filter((e: any) => {
          e.Add1 = e.District + ", " + e.State + ".";
          e.Address = e.District + ", " + e.State + ", " + e.Country + " - " + e.Pincode + ".";
          if (e.FranchiseeID !== "") e.Franchisee = e.FranchiseeID + " - " + e.BranchName + " - " + e.Add1;
          else e.Franchisee = e.BranchName + " - " + e.Add1;
        });
      },
      error: (err) => this.errorMsg(err.Message)
    })
  }

  restore(data: trashMailDataType) {

    this.RestoreOneMail = new trashMailDataType()
    this.RestoreOneMail = data;
    this.IsDialogOpen = true;
    // this._srvMail.postAdminRollBack(data.MailOutBoxID).subscribe({
    //   next: (res) => {
    //     new CustomNotification(this._srvNotification).ShowSuccess(res.Data)
    //     this.getTrashMail();
    //   },
    //   error: (err) => this.errorMsg(err.Message)
    // });
  }

  DialogClose() {
    this.IsDialogOpen = false;
  }

  DeleteMail() {
    this._srvMail.postAdminRollBack(this.RestoreOneMail.MailOutBoxID).subscribe({
      next: (res) => {
        new CustomNotification(this._srvNotification).ShowSuccess(res.Message)
        this.getTrashMail();
        this.DialogClose()
      },
      error: (err) => this.errorMsg(err.Message)
    });
  }

  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err)
  }
}
