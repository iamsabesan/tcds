import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { IconsModule } from '@progress/kendo-angular-icons';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { MailboxComponent } from './mailbox.component';
import { TrashComponent } from './Component/trash/trash.component';
import { SentComponent } from './Component/sent/sent.component';
import { InboxViewComponent } from './Component/inbox-view/inbox-view.component';
import { InboxComponent } from './Component/inbox/inbox.component';
import { DrawerManuComponent } from './Component/drawer-manu/drawer-manu.component';
import { ComposeComponent } from './Component/compose/compose.component';
import { EditorModule } from '@progress/kendo-angular-editor';
import { UploadsModule } from '@progress/kendo-angular-upload';


@NgModule({
  declarations: [
    MailboxComponent,
    TrashComponent,
    SentComponent,
    InboxViewComponent,
    InboxComponent,
    DrawerManuComponent,
    ComposeComponent
  ],

  imports: [
    CommonModule,
    ButtonsModule,
    LayoutModule,
    IconsModule,
    DialogsModule,
    LabelModule,
    InputsModule,
    GridModule, 
    DropDownsModule,
    EditorModule,
    UploadsModule
  ],
  exports: [MailboxComponent,DrawerManuComponent],
  providers: [],
})
export class MailboxModule { }