import { Component, Input, OnInit } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { batchByIDDataType, CourseDetailMl } from '../../model/common';

@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.scss']
})
export class CourseDetailComponent implements OnInit {

  @Input() courseInfo: boolean;
  @Input() batchInfo: boolean;
  @Input() chooseCourseData: CourseDetailMl;
  @Input() chooseBatchData!: batchByIDDataType;


  constructor(public currencyService: IntlService) { }

  ngOnInit(): void {

  }

}
