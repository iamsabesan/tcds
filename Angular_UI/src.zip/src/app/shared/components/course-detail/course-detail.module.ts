import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PopupModule } from '@progress/kendo-angular-popup';
import { GridModule } from "@progress/kendo-angular-grid";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { ToolBarModule } from "@progress/kendo-angular-toolbar";
import { CourseDetailComponent } from './course-detail.component';

@NgModule({
  declarations: [
    CourseDetailComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    InputsModule,
    ToolBarModule,
    DropDownsModule,
    FormsModule,
    ReactiveFormsModule,
    PopupModule,
    GridModule,
    LabelModule,
    DialogsModule
  ],
  exports : [CourseDetailComponent],
  providers: []
})
export class CourseDetailModule { }
