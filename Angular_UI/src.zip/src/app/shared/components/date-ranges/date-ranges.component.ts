import { Component, EventEmitter, Input, Output } from '@angular/core';
import {
  Day,
  prevDayOfWeek,
  firstMonthOfYear,
  lastDayOfMonth,
  lastMonthOfYear,
} from '@progress/kendo-date-math';
import { addMonths, addYears } from '@progress/kendo-date-math';
import { firstDayOfMonth, addDays } from '@progress/kendo-date-math';
import { DropDownFilter, LocalString } from '../../app-global';
import { DateRange, DateRanges } from '../../model/date-ranges';
import { MisReportService } from 'src/app/admin/Indent/components/mis-report/service/mis-report.service';

@Component({
  selector: 'app-date-ranges',
  templateUrl: './date-ranges.component.html',
  styleUrls: ['./date-ranges.component.scss'],
})
export class DateRangesComponent {
  /* this component values assign the other componet using on eveEmiter */
  @Output() dateSelected = new EventEmitter<DateRanges>();

  @Input() dateWholePeriod: boolean = false;
  @Input() WholePerStrDate?: Date;


  // (set wholeperiod defauld value)
  @Input() IsOpenDateRanges: boolean = false;
  public IsCloseDateRanges: boolean = false;

  /* List */
  public datefilterData: DateRange[] = [];
  public dateData: DateRange[] = [];

  /* Model */
  public dateRange: DateRanges = {
    duration: '',
    startDate: new Date(),
    endDate: new Date(),
  };
  public dateSelecteds: DateRanges = new DateRanges();

  /* Disabled date */
  public IsdisabledDate: boolean = true;

  public selectedValue: DateRange = new DateRange();

  /* Date Format */
  public dateFormat: string = '';

  /* Dropdown Filter */
  public Filter = DropDownFilter.filterSettings;

  constructor(public _srvMiisRepor:MisReportService) {
    // this.dateData.filter((e: DateRange) => {
    //   if (e.disabled === false) {
    //     this.datefilterData.push(e);
    //   }
    // });

    // this.selectedValue = this.datefilterData[0]; //defalut select the daterange value
  }
  ngOnInit() {

    this.dateData = [
      { value: 'Today', id: 1, disabled: false },
      { value: 'This Week', id: 2, disabled: false },
      { value: 'This Month', id: 3, disabled: false },
      { value: 'Last 3 Months', id: 4, disabled: false },
      { value: 'Last 6 Months', id: 5, disabled: false },
      { value: 'Last 12 Months', id: 6, disabled: false },
      { value: 'This Year', id: 7, disabled: false },
      { value: 'Last Year', id: 8, disabled: false },
      { value: 'Whole Period', id: 9, disabled: this.dateWholePeriod },
      { value: 'Custom', id: 10, disabled: false },
    ];

    this.datefilterData = this.dateData.filter((e) => !e.disabled);
  
    if (this.IsOpenDateRanges&&this._srvMiisRepor.IsCloseDateRanges) {
      setTimeout(()=>{
        // selected defauld value "Whole Period"
        this.selectedValue = this.datefilterData[8];
        this.dateFormat = LocalString.DateFormat;

        /* Component value assign */
        this.dateRange.duration = 'Whole Period';
        this.dateRange.startDate = this.WholePerStrDate;

        this.dateRange.endDate = new Date();
        this.IsdisabledDate = true;
        this.dateSelecteds = this.dateRange;
        this.dateSelected.emit(this.dateRange);

      },120)
     
    } else {
        this.selectedValue = this.datefilterData[0];
        this.dateFormat = LocalString.DateFormat;
  
        /* Component value assign */
        this.dateRange.duration = 'Today';
        this.dateRange.startDate = this.dateRange.endDate = new Date();
        this.IsdisabledDate = true;
        this.dateSelecteds = this.dateRange;
        this.dateSelected.emit(this.dateRange);
    }
  }
  // i did
  // ngOnInit() {
  //   this.dateFormat = LocalString.DateFormat;

  //   /* Component value assign */
  //   this.dateRange.duration = 'Today';
  //   this.dateRange.startDate = this.dateRange.endDate = new Date();
  //   this.IsdisabledDate = true;
  //   this.dateSelecteds = this.dateRange;
  //   this.dateSelected.emit(this.dateRange);
  // }

  /* Daterange dropdown validation */
  getDate(event: DateRange) {
    if (event) {
      this.dateRange.duration = event.value;
      this.IsdisabledDate = true;
    }
    if (event == undefined) {
      this.dateRange.duration = undefined;
      this.dateRange.startDate = this.dateRange.endDate = null;
      this.IsdisabledDate = false;
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Today') {
      this.dateRange.startDate = this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'This Week') {
      this.dateRange.startDate = prevDayOfWeek(new Date(), Day.Monday);
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'This Month') {
      this.dateRange.startDate = firstDayOfMonth(new Date());
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'This Year') {
      this.dateRange.startDate = firstMonthOfYear(firstDayOfMonth(new Date()));
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Last 3 Months') {
      this.dateRange.startDate = addDays(addMonths(new Date(), -3), 1);
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Last 6 Months') {
      this.dateRange.startDate = addDays(addMonths(new Date(), -6), 1);
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Last 12 Months') {
      this.dateRange.startDate = addDays(addMonths(new Date(), -12), 1);
      this.dateRange.endDate = new Date();
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Last Year') {
      this.dateRange.startDate = firstMonthOfYear(firstDayOfMonth(addYears(new Date(), -1)));
      this.dateRange.endDate = lastMonthOfYear(lastDayOfMonth(this.dateRange.startDate));
      this.dateSelected.emit(this.dateRange);
    } 
    
    else if (event.value === 'Whole Period') {
      setTimeout(()=>{
        this.dateRange.startDate = this.WholePerStrDate;
        this.dateRange.endDate = new Date();
        this.dateSelected.emit(this.dateRange);
      },100)
   
    } 
    
    else {
      this.IsdisabledDate = false;
      this.dateSelected.emit(this.dateRange);
    }
  }
}
