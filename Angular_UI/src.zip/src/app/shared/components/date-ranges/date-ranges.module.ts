import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { DateRangesComponent } from "./date-ranges.component";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";

@NgModule({ 
  declarations: [
    DateRangesComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    LayoutModule,
    DateInputsModule,
    LabelModule,
    ButtonsModule,
    DropDownsModule,
  ],
  exports: [DateRangesComponent]
})
export class DateRangesModule {

}
