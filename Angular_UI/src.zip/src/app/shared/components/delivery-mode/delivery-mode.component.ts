import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { NotificationService } from '@progress/kendo-angular-notification';
import { DeliveryModeList, CreateDeliveryMode, DeliveryModeType } from '../../model/common';
import { CustomNotification } from '../../model/shared';
import { CommonService } from '../../service/common.service';
import { DropDownFilter } from '../../app-global';
import { InputRegex } from '../regex';
import { IWebError } from 'src/core/model';

@Component({
  selector: 'app-delivery-mode',
  templateUrl: './delivery-mode.component.html',
  styleUrls: ['./delivery-mode.component.scss']
})
export class DeliveryModeComponent implements OnInit {

  /* View Child */
  @ViewChild('deliveryForm') deliveryForm!: NgForm;
  @ViewChild('delivery', { static: false }) delivery!: ElementRef;

  /* Output Emitter */
  @Output() comboSelected = new EventEmitter<number>();

  /* List */
  public LstDeliveryMode: DeliveryModeList[] = [];

  /* Model */
  public MlDeliveryName: CreateDeliveryMode = new CreateDeliveryMode();
  public MlDeliveryMode: DeliveryModeType = new DeliveryModeType();

  /* Selected the Delivery Mode */
  public selectedValue: number = 0;

  /* Open Create Delivery Mode Dialog */
  public showDeliveryMode: boolean = false;

  /* Regex */
  public NamePattern = InputRegex.alphaNumericOnly;

  /* DropDown Filter */
  public filterSettings = DropDownFilter.filterSettings;

  /* Form Group */
  FrmEntry = new FormGroup({
    DeliveryName: new FormControl(null, [Validators.required])
  })

  constructor(public _srvNotification: NotificationService, private _srvCommon: CommonService) { }

  ngOnInit() {
    this.getDeliveryMood();
  }

  getDeliveryMood() {
    this._srvCommon.getdeliveryMood().subscribe({
      next: (res: any) => this.LstDeliveryMode = res.Data,
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  /* Open Dialog */
  addNew() {
    this.showDeliveryMode = true;
  }

  /* Close Dialog */
  btnCloseDialog() {
    this.showDeliveryMode = false;
    this.FrmEntry.reset();
  }

  /* Emit the Delivert Mode */
  onChange(data: any) {
    this.comboSelected.emit(data);
  }

  clearCombo() {
    this.selectedValue = this.MlDeliveryMode.value = 0;
  }

  /* Create a New Delivery Mode */
  submit() {
    if (this.FrmEntry.invalid) this.FrmEntry.markAllAsTouched();
    else {
      this.MlDeliveryName.deliveryModeName = this.FrmEntry.value.DeliveryName;
      this._srvCommon.createDeliveryMode(this.MlDeliveryName).subscribe({
        next: (res) => {
          new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
          this.btnCloseDialog();
          this.getDeliveryMood();
        },
        error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
      });
    }
  }
}
