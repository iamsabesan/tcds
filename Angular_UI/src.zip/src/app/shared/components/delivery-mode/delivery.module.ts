import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { IconsModule } from "@progress/kendo-angular-icons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DeliveryModeComponent } from "./delivery-mode.component";

@NgModule({
  declarations: [
    DeliveryModeComponent
  ],
  imports: [
    CommonModule,
    DialogModule,
    InputsModule,
    ButtonsModule,
    LabelModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    IconsModule
  ],
  exports: [DeliveryModeComponent],
  providers: [],
})
export class DeliveryModule {

}
