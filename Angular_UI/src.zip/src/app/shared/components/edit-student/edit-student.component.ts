import { Component, EventEmitter, Input, Output } from "@angular/core";
import { CustomNotification } from "../../model/shared";
import { FormBuilder, FormGroup } from "@angular/forms";
import { DateConversion, DropDownFilter, LocalString } from "../../app-global";
import { InputRegex } from "../regex";
import { Occupation, Qualification, StudentAddressCreate } from "../../model/student-profile";
import { Country, District, gender_lst, PhoneCode, RelationShipListMl, State } from "../../model/common";
import { CookieService } from "ngx-cookie-service";
import { CommonService } from "../../service/common.service";
import { NotificationService } from "@progress/kendo-angular-notification";
import { IWebError } from "src/core/model";
import { StepperActivateEvent } from "@progress/kendo-angular-layout";
import { Address, StudentEditMl, StudentProfile } from "src/app/admin/Student/models/student-profile";
import { ImageUploadResult } from "../../model/payment";

@Component({
    selector: 'edit-student',
    templateUrl: 'edit-student.component.html',
    styleUrls: ['edit-student.component.scss']
})
export class EditStudentComponent {
    @Output() formSubmitted = new EventEmitter<any>();
    @Input() MlStudentData: StudentProfile = new StudentProfile();
    @Input() StudentID: string = '';


    /* List */
    public addressData: StudentAddressCreate[] = [];
    public LstCountry: Country[] = [];
    public LstState: State[] = [];
    public LstDistrict: District[] = [];
    public LstPhoneCode: PhoneCode[] = [];
    public LstOccupation: Occupation[] = [];
    public LstQualification: Qualification[] = [];
    public LstGender: gender_lst[] = [];
    public LstGuardian: RelationShipListMl[] = [];

    /* Model */
    public MlAddress: Address = new Address();
    public MlProfileFile = new ImageUploadResult();
    public com_address: StudentAddressCreate = new StudentAddressCreate();
    public per_address: StudentAddressCreate = new StudentAddressCreate();
    public MlStudentEdit: StudentEditMl = new StudentEditMl();


    /* Pattern */
    public Name = InputRegex.Name;
    public Email = InputRegex.Email;
    public Mobile = InputRegex.Mobile;
    public Pincode = /^(6)?[1-9][0-9]{5}$/;

    /* Input decimal point not allow */
    public existing: boolean = false;
    public existingDisabled: boolean = false;

    /* Payment Details */
    public paymentamount: number = 0;
    public ErrorNotification: string = 'Please enter valid Amount';
    public ErrorNotify: string = 'Fees amount must be equal with total amount';
    public Totalamount: number = 0;
    public Balanceamount: number = 0;
    public isDownPaymentDisabled: boolean = true;
    public downPaymentMinAmount: number = 0;
    public downPaymentMaxAmount: number = 0;
    public disbledDepositFrom = false;
    public currencySymbol: string = '';

    /* Address Selection */
    public isDisabledState: boolean = true;
    public isDisabledDistrict = true;
    public selectedCountry: any;
    public selectedState: any;
    public selectedDistrict: any;
    public CountryID: string = '';
    public ShippingState!: Array<{
        StateProvinceID: number;
        StateProvinceName: string;
    }>;

    public ShippingDistrict!: Array<{
        DistrictID: number;
        DistrictName: string;
    }>;

    public shipDisabledState: boolean = true;
    public shipDisabledDistrict: boolean = true;
    public shipselectedCountry: any;
    public shipselectedState: any;
    public shipselectedDistrict: any;

    public courseData: boolean = false;
    public batchInfo: boolean = false;

    /* Existing Student is True Disabled the Step 1 */
    public IsStep1: boolean = true;

    /* Date & Time Format */
    public timeFormat: string = '';
    public time: string = '';
    public dateFormat: string = '';

    /* Get Image File Extension */
    public FileExtension: string = "";

    public imageSrc1?: any;
    public studentID: string = '';
    public currentStep: number = 0;

    public guardians: string = 'Father';

    /* Telerik Report Viewer */
    public getScreenHeight: any;
    public getScreenWidth: any;
    public viewerContainerStyle: any;
    public ServerUrl: any;
    public open: boolean = false;
    public Reportsource: any;
    public title: string = '';
    public bearerToken = "";

    /* Dropdown Filter */
    public filterSettings = DropDownFilter.filterSettings;
    public StartWithFilterSettings = DropDownFilter.StartWithfilterSettings;

    public checkProfilePic = false;
    public checkProfilePicFileSize = false;
    public checkProfilePicFileType = false;
    public checkProfilePicChange = false;

    FrmEntry = new FormGroup({
        personalDetails: this.fb.group({
            name: [],
            gender: [],
            dob: [],
            PhoneCode: [],
            mobile: [],
            AlternatePhoneCode: [],
            altmobile: [],
            email: [],
            qualification: [],
            guardian: [],
            guardianName: [],
            occupation: [],
            image: [null],
        }),
        address: this.fb.group({
            address1: [],
            address2: [],
            area: [],
            country: [],
            state: [],
            district: [],
            pincode: [],
            permenantaddress1: [],
            permenantaddress2: [],
            permenantarea: [],
            permenantcountry: [],
            permenantstate: [],
            permenantdistrict: [],
            permenantpincode: [],
        })
    });

    constructor(public fb: FormBuilder, public _srvCookie: CookieService,
        private _srvCommon: CommonService,
        private _srvNotification: NotificationService,

    ) { }

    ngOnInit() {
        this.currencySymbol = LocalString.CurrencySymbol;
        this.dateFormat = LocalString.DateFormat;
        this.imageSrc1 = "assets/logo/img_avatar.png";
        this.FrmDataBinding(this.MlStudentData)
    }

    FrmDataBinding(data: StudentProfile) {
        var PersonalDetails = this.FrmEntry.controls.personalDetails.controls;
        var AddressDetails = this.FrmEntry.controls.address.controls;
        this.checkProfilePicChange = false;

        PersonalDetails.altmobile.setValue(data.AlternatePhone);
        PersonalDetails.dob.setValue(DateConversion.ConvertStringToDateYYMMDD(data.DateOfBirth));
        PersonalDetails.email.setValue(data.Email);
        PersonalDetails.guardianName.setValue(data.FatherName);
        if (data.StudentImages.length) PersonalDetails.image.setValue(data.StudentImages[0]);
        PersonalDetails.mobile.setValue(data.Phone);
        PersonalDetails.name.setValue(data.StudentName);

        this._srvCommon.getPhoneCode().subscribe({
            next: (e) => {
                this.LstPhoneCode = e.Data;
                PersonalDetails.AlternatePhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.AlternatePhoneCode));
                PersonalDetails.PhoneCode.setValue(this.LstPhoneCode.find(e => e.PhoneCode == data.PhoneCode));
            },
            error: (err: IWebError) => this.errorMsg(err.Message)
        });


        this._srvCommon.getLstGender().subscribe(e => {
            this.LstGender = e.Data;
            PersonalDetails.gender.setValue(this.LstGender.find(e => e.GenderName.toUpperCase() == data.Gender.toUpperCase()));
        })

        this._srvCommon.getStudentQualification().subscribe(e => {
            this.LstQualification = e.Data;
            PersonalDetails.qualification.setValue(this.LstQualification.find(e => e.Qualification.toUpperCase() == data.Qualification.toUpperCase()));
        })

        this._srvCommon.getOccupationData().subscribe(e => {
            this.LstOccupation = e.Data;
            const Occupation = this.LstOccupation.find(val => val.Occupation.toUpperCase() == data.Occupation.toUpperCase());
            Occupation ? PersonalDetails.occupation.setValue(Occupation.Occupation) : PersonalDetails.occupation.setValue(data.Occupation);
        })

        this._srvCommon.getRelationShipLst().subscribe(e => {
            this.LstGuardian = e.Data;
            PersonalDetails.guardian.setValue(this.LstGuardian.find(val => val.MinValue.toUpperCase() == data.GuardianType.toUpperCase()));
        })


        AddressDetails.address1.setValue(data.currentAddress.Address1);
        AddressDetails.address2.setValue(data.currentAddress.Address2);
        AddressDetails.area.setValue(data.currentAddress.Area);

        this._srvCommon.getLstCountry().subscribe(country => {
            this.LstCountry = country.Data;
            AddressDetails.country.setValue(this.LstCountry.find(e => e.CountryName.toUpperCase() == data.currentAddress.Country.toUpperCase()));
            this._srvCommon.getLstState(AddressDetails.country.value.CountryID).subscribe(e => {
                this.LstState = e.Data;
                AddressDetails.state.setValue(this.LstState.find(e => e.StateProvinceName.toUpperCase() == data.currentAddress.State.toUpperCase()));
                this.isDisabledState = false;

                this._srvCommon.getLstDistrict(AddressDetails.state.value.StateProvinceID).subscribe(val => {
                    this.LstDistrict = val.Data;
                    AddressDetails.district.setValue(this.LstDistrict.find(e => e.DistrictName.toUpperCase() == data.currentAddress.District.toUpperCase()));
                    this.isDisabledDistrict = false;

                })
            })


            AddressDetails.permenantcountry.setValue(this.LstCountry.find(e => e.CountryName.toUpperCase() == data.permentAddress.Country.toUpperCase()));
            // this.shipCountry(AddressDetails.permenantcountry.value)

            this._srvCommon.getLstState(AddressDetails.permenantcountry.value.CountryID).subscribe(e => {
                this.ShippingState = e.Data;
                AddressDetails.permenantstate.setValue(this.ShippingState.find(e => e.StateProvinceName.toUpperCase() == data.permentAddress.State.toUpperCase()));
                this.shipDisabledState = false;
                this._srvCommon.getLstDistrict(AddressDetails.permenantstate.value.StateProvinceID).subscribe(val => {
                    this.ShippingDistrict = val.Data;
                    AddressDetails.permenantdistrict.setValue(this.ShippingDistrict.find(e => e.DistrictName.toUpperCase() == data.permentAddress.District.toUpperCase()));
                    this.shipDisabledDistrict = false;
                })
            })

        })
        AddressDetails.permenantaddress1.setValue(data.permentAddress.Address1);
        AddressDetails.permenantaddress2.setValue(data.permentAddress.Address2);
        AddressDetails.permenantarea.setValue(data.permentAddress.Area);
        AddressDetails.permenantpincode.setValue(data.permentAddress.Pincode);
        AddressDetails.pincode.setValue(data.currentAddress.Pincode);

        if (this.compareTwoAddress(data.currentAddress, data.permentAddress)) this.copyAddressChecked = this.perDisable = true;
        else this.copyAddressChecked = this.perDisable = false;

        if (this.MlStudentData.StudentImages.length) this.imageSrc1 = "data:" + this.MlStudentData.StudentImages[0].MIMEType + ";base64," + this.MlStudentData.StudentImages[0].ProfileBase64
        else {
            this.imageSrc1 = "assets/logo/img_avatar.png";
            this.checkProfilePic = this.checkProfilePicFileSize = this.checkProfilePicFileType = false;
        }
    }



    countryChange(value: any) {
        this.selectedCountry = value;
        this.selectedState = this.selectedDistrict = undefined;
        this.FrmEntry.controls.address.controls['state'].setValue(null);
        this.FrmEntry.controls.address.controls['district'].setValue(null);

        if (value === undefined) {
            this.isDisabledState = true;
            this.LstState = [];
        }
        else {
            this._srvCommon.getLstState(value.CountryID).subscribe({
                next: (e) => {
                    this.LstState = e.Data;
                    this.isDisabledState = false;
                },
                error: (err) => this.errorMsg(err.Message)
            })
        }

        this.isDisabledDistrict = true;
        // this.dataResultDistrict = [];
        this.LstDistrict = [];
    }

    stateChange(value: any) {
        this.selectedState = value;
        this.selectedDistrict = undefined;
        this.FrmEntry.controls.address.controls['district'].setValue(null);
        if (value === undefined) {
            this.isDisabledDistrict = true;
            this.LstDistrict = [];
        }
        else {
            this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
                next: (e) => {
                    this.LstDistrict = e.Data;
                    this.isDisabledDistrict = false;
                },
                error: (err) => this.errorMsg(err.Message)
            });
        }
    }

    districtChange(value: any) {
        this.selectedDistrict = value;
    }

    shipCountry(value: any) {
        this.shipselectedCountry = value;
        this.shipselectedState = undefined;
        this.shipselectedDistrict = undefined;
        this.FrmEntry.controls.address.controls['permenantstate'].setValue(null);
        this.FrmEntry.controls.address.controls['permenantdistrict'].setValue(null);
        if (value === undefined) {
            this.shipDisabledState = true;
            this.ShippingState = [];
        } else {
            this._srvCommon.getLstState(value.CountryID).subscribe({
                next: (e) => {
                    this.ShippingState = e.Data;
                    this.shipDisabledState = false;
                },
                error: (err) => this.errorMsg(err.Message)
            })
        }
        this.shipDisabledDistrict = true;
        this.ShippingDistrict = [];
    }

    shipState(value: any) {
        this.shipselectedState = value;
        this.shipselectedDistrict = undefined;
        this.FrmEntry.controls.address.controls['permenantdistrict'].setValue(null);
        if (value === undefined) {
            this.shipDisabledDistrict = true;
            this.ShippingDistrict = [];
        } else {
            this._srvCommon.getLstDistrict(value.StateProvinceID).subscribe({
                next: (e) => {
                    this.ShippingDistrict = e.Data;
                    this.shipDisabledDistrict = false;
                },
                error: (err) => this.errorMsg(err.Message)
            })
        }
    }

    shipDistrict(value: any) {
        this.shipselectedDistrict = value;
    }


    public copyAddressChecked: boolean = false;
    public perDisable: boolean = false;
    copyAddress(event: any) {
        this.perDisable = this.copyAddressChecked = event.target.checked;

        if (event.target.checked) {
            this.currentGroup.controls['permenantaddress1'].setValue(this.currentGroup.controls['address1'].value)
            this.currentGroup.controls['permenantaddress2'].setValue(this.currentGroup.controls['address2'].value)
            this.currentGroup.controls['permenantarea'].setValue(this.currentGroup.controls['area'].value)
            this.currentGroup.controls['permenantcountry'].setValue(this.currentGroup.controls['country'].value)
            this.currentGroup.controls['permenantpincode'].setValue(this.currentGroup.controls['pincode'].value)

            if (this.currentGroup.controls['country'].value) {
                this.shipDisabledState = false;
                this.shipDisabledDistrict = true;
                this.ShippingDistrict = [];
                this._srvCommon.getLstState(this.currentGroup.controls['permenantcountry'].value.CountryID).subscribe((e: any) => {
                    this.ShippingState = e.Data;
                })
                if (this.currentGroup.controls['state'].value) {
                    this.currentGroup.controls['permenantstate'].setValue(this.currentGroup.controls['state'].value);
                    this.shipDisabledDistrict = false;
                    this._srvCommon.getLstDistrict(this.currentGroup.controls['permenantstate'].value.StateProvinceID).subscribe((e: any) => {
                        this.ShippingDistrict = e.Data
                    })
                    if (this.currentGroup.controls['district'].value) this.currentGroup.controls['permenantdistrict'].setValue(this.currentGroup.controls['district'].value);
                    else this.currentGroup.controls['permenantdistrict'].setValue(null);
                }
                else {
                    this.shipDisabledDistrict = true;
                    this.ShippingDistrict = [];
                    this.currentGroup.controls['permenantdistrict'].setValue(null);
                    this.currentGroup.controls['permenantstate'].setValue(null);
                }
            }
            else {
                this.shipDisabledState = this.shipDisabledDistrict = true;
                this.ShippingState = this.ShippingDistrict = [];
                this.currentGroup.controls['permenantdistrict'].setValue(null);
                this.currentGroup.controls['permenantstate'].setValue(null);
            }
        }
        else {
            this.ShippingState = this.ShippingDistrict = [];
            this.FrmEntry.controls['address'].controls['permenantaddress1'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantaddress2'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantarea'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantcountry'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantstate'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantdistrict'].setValue(null);
            this.FrmEntry.controls['address'].controls['permenantpincode'].setValue(null);
        }
    }


    private isStepValid = (index: number) => {
        return this.getGroupAt(index).valid || this.currentGroup.untouched;
    };

    private shouldValidate = (index: number) => {
        return this.getGroupAt(index).touched && this.currentStep >= index;
    };

    public stepActivate(e: StepperActivateEvent) {
        if (!this.currentGroup.valid) {
            e.preventDefault();
            this.currentGroup.markAllAsTouched();
        }
    }

    step = [
        {
            label: 'Personal Details',
            isValid: this.isStepValid,
            validate: this.shouldValidate,
            disabled: false
        },
        {
            label: 'Address',
            isValid: this.isStepValid,
            validate: this.shouldValidate,
            disabled: false
        },
    ];

    /* Get File Extension */
    getFileNameWithExt(event: any) {
        if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
        const name = event.target.files[0].name;
        const lastDot = name.lastIndexOf(".");
        const ext = name.substring(lastDot + 1);
        this.FileExtension = ext;
    }

    fileChange1(event: any) {
        this.getFileNameWithExt(event);
        if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png") {
            const reader = new FileReader();
            this.checkProfilePicFileType = false;
            if (event.target.files && event.target.files.length) {
                if (event.target.files[0].size >= 2097152) {
                    this.checkProfilePicFileSize = true;
                    this.imageSrc1 = "assets/logo/img_avatar.png";
                    this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
                    this.MlProfileFile = new ImageUploadResult();
                }
                else {
                    const [file1] = event.target.files;
                    const file = event.target.files[0];
                    this.FrmEntry.controls.personalDetails.controls.image.setValue(file);
                    this.fileData(file, 'Profile')
                    reader.readAsDataURL(file1);
                    reader.onload = () => {
                        this.imageSrc1 = reader.result as any;
                        this.checkProfilePic = false;
                        this.checkProfilePicFileSize = false;
                    }
                }
            }
        }
        else {
            this.imageSrc1 = "assets/logo/img_avatar.png";
            this.checkProfilePicFileType = true;
            this.checkProfilePic = this.checkProfilePicFileSize = false;
            this.FrmEntry.controls.personalDetails.controls.image.setValue(null)
            this.MlProfileFile = new ImageUploadResult();
        }

    }

    fileData(file: any, type: string) {
        this._srvCommon.postImageUpload(type, file).subscribe({
            next: val => {
                this.MlProfileFile = val.Data;
                this.checkProfilePicChange = true;
            },
            error: (err) => this.errorMsg(err.Message)
        })
    }

    prev() {
        this.currentStep = this.currentStep - 1;
    }

    next() {
        if (this.currentGroup.valid) {
            if (!this.checkProfilePicFileSize && !this.checkProfilePicFileType && !this.checkProfilePic)
                this.currentStep = this.currentStep + 1;
            return;
        }
        this.currentGroup.markAllAsTouched();
    }

    goBack() {
        this.formSubmitted.emit("Cancle");
    }


    save() {
        this.MlStudentEdit = new StudentEditMl();
        if (this.currentGroup.valid) {
            const PersonalData = this.FrmEntry.controls.personalDetails.value;
            const AddressData = this.FrmEntry.controls.address.value;
            this.MlStudentEdit.AlternatePhoneCode = PersonalData.AlternatePhoneCode.PhoneCode;
            this.MlStudentEdit.AlternatePhone = PersonalData.altmobile;
            this.MlStudentEdit.ContactID = this.MlStudentData.ContactID;
            this.MlStudentEdit.ContactName = PersonalData.name;
            this.MlStudentEdit.DateOfBirth = DateConversion.ConvertToMonthDateYear(PersonalData.dob);
            this.checkProfilePicChange ? this.MlStudentEdit.DocumentID = this.MlProfileFile.DocumentID : delete this.MlStudentEdit.DocumentID;

            this.MlStudentEdit.Email = PersonalData.email;
            this.MlStudentEdit.Gender = PersonalData.gender.GenderName;
            this.MlStudentEdit.GuardianName = PersonalData.guardianName;
            this.MlStudentEdit.GuardianType = PersonalData.guardian.MinValue;
            this.MlStudentEdit.Occupation = PersonalData.occupation;
            this.MlStudentEdit.Phone = PersonalData.mobile;
            this.MlStudentEdit.PhoneCode = PersonalData.PhoneCode.PhoneCode;
            this.MlStudentEdit.Qualification = PersonalData.qualification.Qualification;
            this.MlStudentEdit.StudentID = this.StudentID;

            this.MlAddress = new Address();

            this.MlAddress.Address1 = AddressData.address1
            this.MlAddress.Address2 = AddressData.address2
            this.MlAddress.AddressTypeID = this.MlStudentData.currentAddress.AddressTypeID
            this.MlAddress.Area = AddressData.area
            this.MlAddress.ContactID = this.MlStudentData.currentAddress.ContactID
            this.MlAddress.Country = AddressData.country.CountryName
            this.MlAddress.District = AddressData.district.DistrictName
            this.MlAddress.Pincode = AddressData.pincode
            this.MlAddress.State = AddressData.state.StateProvinceName
            this.MlStudentEdit.Address.push(this.MlAddress);

            this.MlAddress = new Address();
            this.MlAddress.Address1 = AddressData.permenantaddress1
            this.MlAddress.Address2 = AddressData.permenantaddress2
            this.MlAddress.AddressTypeID = this.MlStudentData.permentAddress.AddressTypeID
            this.MlAddress.Area = AddressData.permenantarea
            this.MlAddress.ContactID = this.MlStudentData.permentAddress.ContactID
            this.MlAddress.Country = AddressData.permenantcountry.CountryName
            this.MlAddress.District = AddressData.permenantdistrict.DistrictName
            this.MlAddress.Pincode = AddressData.permenantpincode
            this.MlAddress.State = AddressData.permenantstate.StateProvinceName
            this.MlStudentEdit.Address.push(this.MlAddress);

            this.formSubmitted.emit(this.MlStudentEdit);
        }

        this.currentGroup.markAllAsTouched();

    }

    public get currentGroup(): FormGroup {
        return this.getGroupAt(this.currentStep);
    }

    public getGroupAt(index: number): FormGroup {
        var groups = Object.keys(this.FrmEntry.controls).map((groupName) =>
            this.FrmEntry.get(groupName)) as FormGroup[];
        return groups[index];
    }

    /* Compare two address (Communication & Permanent) */
    compareTwoAddress(comAddress: any, perAddress: any): boolean {
        this.com_address.Address1 = comAddress.Address1;
        this.com_address.Address2 = comAddress.Address2;
        this.com_address.Area = comAddress.Area;
        // this.com_address.WardNo = comAddress.WardNo;
        this.com_address.Country = comAddress.Country;
        this.com_address.State = comAddress.State;
        this.com_address.District = comAddress.District;
        this.com_address.Pincode = comAddress.Pincode;

        this.per_address.Address1 = perAddress.Address1;
        this.per_address.Address2 = perAddress.Address2;
        this.per_address.Area = perAddress.Area;
        // this.per_address.WardNo = perAddress.WardNo;
        this.per_address.Country = perAddress.Country;
        this.per_address.State = perAddress.State;
        this.per_address.District = perAddress.District;
        this.per_address.Pincode = perAddress.Pincode;
        const keys1 = Object.keys(this.com_address);
        const keys2 = Object.keys(this.per_address);
        if (keys1.length !== keys2.length) {
            return false;
        }
        for (const key of keys1) {
            if (key !== "AddressType") {
                if (comAddress[key] !== perAddress[key]) {
                    return false;
                }
            }
        }
        return true;
    }

    /* Close Telerik Report */
    close(): void {
        this.open = false;
    }

    /* Show Error Msg */
    errorMsg(err: string) {
        new CustomNotification(this._srvNotification).ShowError(err);
    }

}