import { NgModule } from "@angular/core";
import { EditStudentComponent } from "./edit-student.component";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { DatePickerModule } from "@progress/kendo-angular-dateinputs";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogsModule } from "@progress/kendo-angular-dialog";

@NgModule({
    declarations: [
        EditStudentComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        InputsModule,
        LabelModule,
        DropDownsModule,
        DatePickerModule,
        LayoutModule,
        ButtonsModule,
        DialogsModule
    ],
    exports: [
        EditStudentComponent
    ]
})

export class EditStudentModule { }