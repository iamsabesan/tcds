import { Component, Input, OnInit } from '@angular/core';
import { TileUrlTemplateArgs } from '@progress/kendo-angular-map';
import { NotificationService } from '@progress/kendo-angular-notification';
import { inactiveAddress } from 'src/app/admin/Franchisee/Components/Franchisee-request-list/models/request-list';
import { HttpService } from 'src/core/service';
// import { franchiseeRequests } from 'src/app/admin/Franchisee/Components/Franchisee-request-list/models/request-list';
import { FranchiseeImgList, imageType } from '../../model/franchisee-request-view';
import { CustomNotification } from '../../model/shared';
// import { CustomNotification } from '../../model/shared';
import { CommonService } from '../../service/common.service';
import { DropDownFilter, GlobalMapValues } from '../../app-global';
import { EditFranchiseeCode } from '../../model/common';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRegex } from '../regex';
import { IWebError } from 'src/core/model';

export class MlEditPersonalDetailModel {
  FranchiseeEnquiryID!: string;
  ContactName!: string;
  Gender!: string;
  PhoneCode!: string;
  Phone!: string;
}

export class MlEditAddressDetailModel {
  FranchiseeEnquiryID: string
  FranchiseeCode: string
  Taluk: string
  Address1: string
  Address2: string
  Area: string
  District: string
  State: string
  Country: string
  Pincode: string
}

@Component({
  selector: 'app-franchisee-request-details',
  templateUrl: './franchisee-request-details.component.html',
  styleUrls: ['./franchisee-request-details.component.scss']
})
export class FranchiseeRequestDetailsComponent implements OnInit {

  @Input() CustomerAgentRatio: any;
  @Input() ModuleName = '';
  @Input() walletRequest: boolean = true;
  @Input() franchiseeDetails: boolean = true;
  @Input() franchiseeDatas: any;
  @Input() ViewComponent: string = '';
  @Input() isShowEditOption?: boolean = false;

  public address: inactiveAddress = new inactiveAddress();
  // item = listData;
  public item: any;
  public altMobile: string = '';
  public imageData: imageType[] = [];
  public filterImage: imageType[] = [];
  public allImage: imageType[] = [];
  public lstFranchiseeViewImg: FranchiseeImgList[] = [];
  public opened = false;

  /* List */
  public LstGender: any[] = [];
  public LstPhoneCode: any[] = [];
  public LstCountry: any[] = [];
  public LstState: any[] = [];
  public LstDistrict: any[] = [];

  public filterSettings = DropDownFilter.filterSettings;
  public Mobile = InputRegex.Mobile;
  public Pincode = /^(6)?[1-9][0-9]{5}$/;

  /* Map */
  public center = GlobalMapValues.center;
  public centers = GlobalMapValues.center;
  public tempMarkers: any[] = [];
  public zoomSize = GlobalMapValues.zoomSize;
  tileUrl = (e: TileUrlTemplateArgs): string =>
    `https://${e.subdomain}.tile.openstreetmap.org/${e.zoom}/${e.x}/${e.y}.png`;
  public viewMapCenter: number[] = [];
  public viewMapMarker: any[] = [];

  constructor(private _srvCommon: CommonService,
    private _srvNotification: NotificationService, public srvHttp: HttpService) { }

  ngOnInit(): void {
    this.franchiseeDatas.Address.filter((e: any) => {
      this.address = e;
    });
    this.item = this.franchiseeDatas;
    this.filterImage = this.franchiseeDatas.FranchiseeImgs
    this.imageData = this.franchiseeDatas.FranchiseeImgs;
    this.MlEditFranchiseeCode.FranchiseeEnquiryID = this.franchiseeDatas.FranchiseeEnquiryID;
    if (this.ViewComponent == 'Active') {
      this.imageData.forEach((e: imageType) => {
        e.ThumbnailImage = this._srvCommon.getBase64ImageUrl(e.ThumbnailData);
        // e.image = this._srvCommon.getBase64ImageUrl(e.AttachmentContent);
      })
    } else {
      // this.imageData.forEach((e: any) => {
      //   this._srvCommon.getImage(e.ContentUrl).subscribe({
      //     next: (val) => {
      //       e.image = e.ThumbnailImage = val.Data
      //     },
      //     error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
      //   });
      // });
      this.getImage();
    }


    this.center = GlobalMapValues.center = [this.address.Latitude, this.address.Longitude];
    this.viewMapMarker.pop();
    this.viewMapMarker.push({ latlng: [this.address.Latitude, this.address.Longitude], name: this.address.ShortName });
  }

  getImage(){
      this.imageData.forEach((e: any) => {
        this._srvCommon.getImage(e.ContentUrl).subscribe({
          next: (val) => {
            e.image = e.ThumbnailImage = val.Data
          },
          error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
      });
  }


  MapzoomChange(ZoomSize: number) {
    GlobalMapValues.zoomSize = this.zoomSize = ZoomSize;
  }


  public close(): void {
    this.opened = false;
  }

  open(data: any) {
    this.opened = true;
    this.filterImage = this.imageData;
    this.filterImage = this.filterImage.filter((e: any) => e.ContentUrl !== data.ContentUrl);
    this.filterImage.unshift(data);

    if (this.ViewComponent == 'Active') {
      this._srvCommon.getFranchiseeImageList(this.franchiseeDatas.FranchiseeRequestID).subscribe(e => {
        this.lstFranchiseeViewImg = e.Data;
        if (this.lstFranchiseeViewImg.length) {
          this.lstFranchiseeViewImg.forEach(e => {
            e.image = this._srvCommon.getBase64ImageUrl(e.Content);
            e.DocumentName = e.MIMEType;
          })
        }
      })
    }
  }

  //#region 
  FrmEntry = new FormGroup({
    FranchiseeCode: new FormControl('', [Validators.required])
  });

  public MlEditFranchiseeCode: EditFranchiseeCode = new EditFranchiseeCode();
  public IsOpenEditFranchiseeDialog: boolean = false;
  btnEditFranchiseeID(data: any) {
    this.IsOpenEditFranchiseeDialog = true;
    this.FrmEntry.controls['FranchiseeCode'].setValue(data.FranchiseeCode);
  }

  btnCloseEditDialog(event: string) {
    if (event == 'Cancel') this.IsOpenEditFranchiseeDialog = false;
    else {
      if (this.FrmEntry.valid) {
        this.MlEditFranchiseeCode.FranchiseeCode = this.FrmEntry.controls.FranchiseeCode.value;
        this._srvCommon.EditFranchiseeID(this.MlEditFranchiseeCode).subscribe({
          next: (res: any) => {
            new CustomNotification(this._srvNotification).ShowSuccess(res.Message);
            this.btnCloseEditDialog('Cancel');
            this._srvCommon.getInactiveList().subscribe({
              next: (res: any) => {
                const FranchiseeDetail = res.Data.find((e: any) => e.FranchiseeEnquiryID == this.MlEditFranchiseeCode.FranchiseeEnquiryID);
                this.franchiseeDatas = FranchiseeDetail;
                this.item = this.franchiseeDatas;
                this.franchiseeDatas.Address.filter((e: any) => this.address = e);
              },
              error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
            });
          },
          error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
        });
      }
      else this.FrmEntry.markAllAsTouched();
    }
  }

  btnEditFranchisee() {
    this.MlEditFranchiseeCode.FranchiseeCode = this.FrmEntry.controls.FranchiseeCode.value;
    this._srvCommon.EditFranchiseeID(this.MlEditFranchiseeCode).subscribe({
      next: () => {
        this.getDetail();
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }

  /* Update the Latest Detail */
  getDetail(): void {
    this._srvCommon.getInactiveList().subscribe({
      next: (res: any) => {
       this.franchiseeDatas  = res.Data.find((e) => e.FranchiseeRequestID == this.MlEditFranchiseeCode.FranchiseeRequestID);
        this.franchiseeDatas?.Address?.filter((e: any) => {
          this.address = e;
        });
        this.item = this.franchiseeDatas;
        this.filterImage = this.franchiseeDatas.FranchiseeImgs
        this.imageData = this.franchiseeDatas.FranchiseeImgs;
        this.getImage();
      },
      error: (err) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });
  }
  //#endregion

  //#region Personal Detail Edit- RK - 22-01-2026
  frmPersonalDetail = new FormGroup({
    ContactName: new FormControl(null, [Validators.required]),
    Gender: new FormControl(null, [Validators.required]),
    PhoneCode: new FormControl(null, [Validators.required]),
    Phone: new FormControl(null, [Validators.required]),
    Email: new FormControl(null, [Validators.required]),
  });

  frmAddressDetail = new FormGroup({
    FranchiseeCode: new FormControl(null, [Validators.required]),
    Address1: new FormControl(null, [Validators.required]),
    Address2: new FormControl(null),
    Area: new FormControl(null, [Validators.required]),
    Taluk: new FormControl(null, [Validators.required]),
    Country: new FormControl(null, [Validators.required]),
    State: new FormControl(null, [Validators.required]),
    District: new FormControl(null, [Validators.required]),
    Pincode: new FormControl(null, [Validators.required]),
  });

  public isOpenPersonalDetailDialog: boolean = false;
  public isOpenAddressDetailDialog: boolean = false;
  public MlEditPersonalDetail: MlEditPersonalDetailModel = new MlEditPersonalDetailModel();

  btnEditPersonalDetail(data: any) {
    this.MlEditPersonalDetail.FranchiseeEnquiryID = data.FranchiseeEnquiryID;
    this.MlEditFranchiseeCode = data;
    this.isOpenPersonalDetailDialog = true;
    this.frmPersonalDetail.controls.ContactName.setValue(data.ContactName);
    this.frmPersonalDetail.controls.Email.setValue(data.Email);
    this._srvCommon.getLstGender().subscribe({
      next: (res: any) => {
        this.LstGender = res.Data;
        if (this.LstGender.length) this.frmPersonalDetail.controls.Gender.setValue(this.LstGender.find((e) => e.GenderName.toLowerCase() == data.Gender.toLowerCase()).GenderName);
      }
    });

    const PHONE = data.Phone.split(' ');
    this.frmPersonalDetail.controls.Phone.setValue(PHONE[1]);
    this._srvCommon.getPhoneCode().subscribe({
      next: (res: any) => {
        this.LstPhoneCode = res.Data;
        if (this.LstPhoneCode.length) this.frmPersonalDetail.controls.PhoneCode.setValue(this.LstPhoneCode.find((e) => e.PhoneCode == PHONE[0]));
      }
    });
  }

  updatePersonalDetail() {
    if (!this.frmPersonalDetail.valid) this.frmPersonalDetail.markAllAsTouched();
    else {
      const FRMVALUE = this.frmPersonalDetail.value;
      this.MlEditPersonalDetail.ContactName = FRMVALUE.ContactName;
      this.MlEditPersonalDetail.Gender = FRMVALUE.Gender;
      this.MlEditPersonalDetail.PhoneCode = FRMVALUE.PhoneCode.PhoneCode;
      this.MlEditPersonalDetail.Phone = FRMVALUE.Phone;

      this._srvCommon.updateFranchiseeDetail(this.MlEditPersonalDetail).subscribe({
        next: (res: any) => {
          this._srvCommon.successMsg(res.Message);
          this.isOpenPersonalDetailDialog = false;
          this.getDetail();
        },
        error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
      })
    }
  }
  //#endregion

  //#region Address Edit - RK - 22-01-2026
  public MlEditAddressDetail: MlEditAddressDetailModel = new MlEditAddressDetailModel();
  btnEditAddressDetail(data: any) {
    this.isOpenAddressDetailDialog = true;
    this.frmAddressDetail.controls.FranchiseeCode.clearValidators();
    if (data.Status.toUpperCase() !== 'APPROVED') this.frmAddressDetail.controls.FranchiseeCode.setValidators([Validators.required])

    const ADDRESS = data.Address[0];
    this.MlEditAddressDetail.FranchiseeEnquiryID = data.FranchiseeEnquiryID;
    this.MlEditFranchiseeCode = data;
    this.frmAddressDetail.controls.FranchiseeCode.setValue(data.FranchiseeCode);
    this.frmAddressDetail.controls.Address1.setValue(ADDRESS.Address1);
    this.frmAddressDetail.controls.Address2.setValue(ADDRESS.Address2);
    this.frmAddressDetail.controls.Area.setValue(ADDRESS.Area);
    this.frmAddressDetail.controls.Taluk.setValue(ADDRESS.Taluk);
    this.frmAddressDetail.controls.Pincode.setValue(ADDRESS.Pincode);

    this._srvCommon.getLstCountry().subscribe({
      next: (res: any) => {
        this.LstCountry = res.Data;
        const COUNTRY = this.LstCountry.find((e) => e.CountryName.toLowerCase() == ADDRESS.Country.toLowerCase());
        this.frmAddressDetail.controls['Country'].setValue(COUNTRY);
        if (COUNTRY) {
          this._srvCommon.getLstState(COUNTRY.CountryID).subscribe({
            next: (res: any) => {
              this.LstState = res.Data;
              const STATE = this.LstState.find((e) => e.StateProvinceName.toLowerCase() == ADDRESS.State.toLowerCase());
              this.frmAddressDetail.controls['State'].setValue(STATE);
              if (STATE) {
                this._srvCommon.getLstDistrict(STATE.StateProvinceID).subscribe({
                  next: (res: any) => {
                    this.LstDistrict = res.Data
                    const DISTRICT = this.LstDistrict.find((e) => e.DistrictName.toLowerCase() == ADDRESS.District.toLowerCase())
                    this.frmAddressDetail.controls['District'].setValue(DISTRICT)
                  }
                });
              }
            }
          })
        }
      },
      error: (err: IWebError) => this._srvCommon.errorMsg(err.Message),
    });
  }

  countryChange(data: any) {
    this.LstState = this.LstDistrict = [];
    this.frmAddressDetail.controls['State'].setValue(null);
    this.frmAddressDetail.controls['District'].setValue(null);
    if (data) {
      this._srvCommon.getLstState(data.CountryID).subscribe({
        next: (res: any) => this.LstState = res.Data,
        error: (err: IWebError) => this._srvCommon.errorMsg(err.Message),
      });
    }
  }

  stateChange(data: any) {
    this.LstDistrict = [];
    this.frmAddressDetail.controls['District'].setValue(null);
    if (data) {
      this._srvCommon.getLstDistrict(data.StateProvinceID).subscribe({
        next: (res: any) => (this.LstDistrict = res.Data),
        error: (err: IWebError) => this._srvCommon.errorMsg(err.Message),
      });
    }
  }

  updateAddressDetail() {
    if (!this.frmAddressDetail.valid) this.frmAddressDetail.markAllAsTouched();
    else {
      const FRMADDRESS = this.frmAddressDetail.value;
      this.MlEditAddressDetail.FranchiseeCode = FRMADDRESS.FranchiseeCode;
      this.MlEditAddressDetail.Address1 = FRMADDRESS.Address1;
      this.MlEditAddressDetail.Address2 = FRMADDRESS.Address2 ?? "";
      this.MlEditAddressDetail.Area = FRMADDRESS.Area;
      this.MlEditAddressDetail.Taluk = FRMADDRESS.Taluk;
      this.MlEditAddressDetail.Pincode = FRMADDRESS.Pincode;
      this.MlEditAddressDetail.Country = FRMADDRESS.Country.CountryName;
      this.MlEditAddressDetail.State = FRMADDRESS.State.StateProvinceName;
      this.MlEditAddressDetail.District = FRMADDRESS.District.DistrictName;

      this._srvCommon.updateFranchiseeAddressDetail(this.MlEditAddressDetail).subscribe({
        next: (res: any) => {
          this._srvCommon.successMsg(res.Message);
          this.isOpenAddressDetailDialog = false;
          this.getDetail();
        },
        error: (err: IWebError) => this._srvCommon.errorMsg(err.Message)
      })
    }
  }
  //#endregion
}
