import { NgModule } from '@angular/core';
import { LayoutModule } from "@progress/kendo-angular-layout";
import { DialogModule, DialogsModule } from '@progress/kendo-angular-dialog';
import { MapModule } from '@progress/kendo-angular-map';
import { ScrollViewModule } from '@progress/kendo-angular-scrollview';
import { FranchiseeRequestDetailsComponent } from './franchisee-request-details.component';
import { CommonModule } from '@angular/common';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LabelModule } from '@progress/kendo-angular-label';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { AppBarModule, NavigationModule } from '@progress/kendo-angular-navigation';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';

@NgModule({
  declarations: [
    FranchiseeRequestDetailsComponent,
  ],
  imports: [
    CommonModule,
    LayoutModule,
    DialogsModule,
    AppBarModule,
    ScrollViewModule,
    MapModule,
    DialogModule,
    IconsModule,
    LabelModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonsModule,
    NavigationModule,
    InputsModule,
    ToolBarModule,
    DropDownsModule
  ],
  providers: [],
  exports: [FranchiseeRequestDetailsComponent],
})
export class FranchiseeRequestDetailsModule { }