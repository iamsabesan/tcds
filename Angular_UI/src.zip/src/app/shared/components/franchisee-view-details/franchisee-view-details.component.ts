import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-franchisee-view-details',
  templateUrl: './franchisee-view-details.component.html',
  styleUrls: ['./franchisee-view-details.component.scss']
})
export class FranchiseeViewDetailsComponent {
  @Input() franchiseeDatas: any;
  item: any;

  constructor() { }
  
  ngOnInit(): void {
    this.item = this.franchiseeDatas;
  }

}
