import { NgModule } from '@angular/core';
import { LayoutModule } from "@progress/kendo-angular-layout";
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { FranchiseeViewDetailsComponent } from './franchisee-view-details.component';

@NgModule({
    declarations: [
        FranchiseeViewDetailsComponent,
    ],
    imports: [
        ButtonsModule,
        LayoutModule,
    ],
    providers: [

    ],
    exports: [FranchiseeViewDetailsComponent],


})
export class FranchiseeViewDetailsModule { }