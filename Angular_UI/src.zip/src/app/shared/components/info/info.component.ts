import { Component, Input, OnInit } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { LocalString } from '../../app-global';


@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {

  @Input() DisplayType = "";
  @Input() ShowFranchisee: boolean = true;
  @Input() franchiseeInfo: any;
  @Input() MlFranchiseeDetail: any;
  @Input() renewalInfo: any;
  @Input() renewalPaymentInfo: boolean = false;
  public currencySymbol: string = '';
  Blocking = false;

  constructor(public CurrencyService: IntlService) {
  }

  ngOnInit(): void {
    this.currencySymbol = LocalString.CurrencySymbol;
  }

  ngDoCheck() {
    this.DisplayType = this.DisplayType.replace(/\s/g, '').toLocaleLowerCase();


  }
}
