import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { InfoComponent } from "./info.component";


@NgModule({
  declarations: [
    InfoComponent
  ],
  imports: [
    CommonModule,
    LayoutModule
  ],
  exports: [InfoComponent]
})
export class InfoModule {

}
