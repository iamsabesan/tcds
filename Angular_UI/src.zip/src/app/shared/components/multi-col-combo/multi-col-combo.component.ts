import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { DropDownFilterSettings } from "@progress/kendo-angular-dropdowns";
import { orderBy } from "@progress/kendo-data-query";
import { Columns } from "../../model/multi-col-combo.model";


@Component({
  selector: 'app-multi-col-combo',
  templateUrl: './multi-col-combo.component.html'
})
export class MultiColComboComponent implements OnInit {

  @Input() Data: any[] = [];
  @Input() textField: string = "";
  @Input() valueField: string = "";
  @Input() value: any;
  @Input() Columns: Columns[] = [];
  @Input() Label: string = "";
  @Input() ComboboxDisabled: boolean = false;

  @Input() ErrorReason!: boolean;
  @Input() ErrorMsg: string = "";

  @Output() newItemEvent = new EventEmitter<any>();

  filterFields: string[] = [];
  constructor() { }

  ngOnInit() {
    this.Columns.forEach((e, i) => {
      this.filterFields[i] = e.Field
    });
  }

  ngAfterViewInit() {
    this.Data = orderBy(this.Data, [{ field: this.textField, dir: "asc" }]);
  }
  selectedValue(event: any) {
    this.newItemEvent.emit(event);
  }

  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'contains',
    fields: this.filterFields
  };


}
