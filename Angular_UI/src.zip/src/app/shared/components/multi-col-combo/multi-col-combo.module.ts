import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { MultiColComboComponent } from "./multi-col-combo.component";

@NgModule({
  declarations: [
    MultiColComboComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    LayoutModule,
    LabelModule,
    DropDownsModule,
    InputsModule
  ],
  exports: [MultiColComboComponent],
  providers: [],
})
export class MultiColComboComponentModule {

}
