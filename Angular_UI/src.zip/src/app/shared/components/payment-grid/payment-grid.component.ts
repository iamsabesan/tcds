import { Component, EventEmitter, Input, Output } from '@angular/core';
import { PaymentInfo } from '../../model/payment-grid.model';
import { LedgerList, PayModeList } from '../../model/payment.model';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PaymentService } from '../../service/payment.service';
import { CustomNotification } from '../../model/shared';
import { DialogCloseResult, DialogService } from '@progress/kendo-angular-dialog';
import { DateConversion } from '../../app-global';
import { PaymentComponent } from '../payment/payment.component';
import { IntlService } from '@progress/kendo-angular-intl';
// import { IWebError } from 'src/core/model';
// import { CustomNotification } from '../../model/shared';

@Component({
  selector: 'app-payment-grid',
  templateUrl: './payment-grid.component.html',
  styleUrls: ['./payment-grid.component.scss']
})
export class PaymentGridComponent {

  Paymentinfo: PaymentInfo = new PaymentInfo();

  @Input() PaymentType = "";
  @Input() PaymentDetails: PaymentInfo[] = [];
  @Input() gridDisable = false;
  @Output() NetTotal = new EventEmitter<number>();
  @Input() public paymentamount: number;
  @Input() public ErrorNotification = '';
  @Input() public ErrorNotify = '';
  @Input() paymentmessage = true;
  @Input() ModuleName = '';
  @Input() SelectedMode = "";
  @Input() allowMultiplePaymode: boolean;
  @Input() disbledDepositFrom = true;
  @Input() IsWalletTransfer: boolean;
  PayModeList: PayModeList[] = [];
  PayModeMl: PayModeList = new PayModeList();
  public BalanceAmount: number = 0;
  public Totalamount: number = 0;
  public Balance: number = 0;
  public paymentCombo: any;

  /* Get Minimum & Maximum Amount */
  @Input() MinAmt: number = 0;
  @Input() MaxAmt: number = 0;
  public setMin: number;
  public setMax: number;

  constructor(public _srvNotification: NotificationService, public _srvPayment: PaymentService,
    private _srvDialog: DialogService, public CurrencyService: IntlService,) { }

  ngOnInit() {
  }

  /* Checking the Remaining Balance */
  ngDoCheck() {
    if (this.paymentamount < this.Totalamount) {
      this.Totalamount = this.BalanceAmount = 0;
      this.PaymentDetails = [];
      this.NetTotal.emit(this.Totalamount)
    }
    else if (this.paymentamount !== 0) {
      this.BalanceAmount = this.paymentamount - this.Totalamount;
      this.NetTotal.emit(this.Totalamount)
    }
    else if (this.paymentamount == 0) {
      this.Totalamount = this.BalanceAmount = 0;
      this.NetTotal.emit(this.Totalamount)
    }
  }

  /* Component initializing Minimum & Maximum Value Set */
  ngOnChanges() {
    this.setMin = this.MinAmt;
    this.setMax = this.MaxAmt;
  }


  openAddPayment() {

    if (((this.paymentamount == this.Totalamount) && (this.paymentamount > 0 && this.Totalamount > 0)) && ((this.paymentamount === this.setMin) || (this.paymentamount <= this.setMax))) {
      this.errorMsg("Could not add more payment");
    }
    else if ((this.paymentamount != 0 && this.paymentamount != null) && ((this.paymentamount === this.setMin) || (this.paymentamount <= this.setMax))) {
      const dialogRef = this._srvDialog.open({
        title: 'Payment Details',
        content: PaymentComponent,
        width: 520,
      });

      this.paymentCombo = dialogRef.content.instance as PaymentComponent;

      this.paymentCombo.ModuleName = this.ModuleName;
      this.paymentCombo.allowMultiplePaymode = this.allowMultiplePaymode;
      this.paymentCombo.paymentamount = this.paymentamount;
      // this.paymentCombo.paymentamount = this.BalanceAmount;
      dialogRef.result.subscribe((result: any) => {
        if (!(result instanceof DialogCloseResult)) {
          this.AddPaymentValidation(this.paymentCombo.PaymentInfo);
        }
      });
    }
    else this.errorMsg(this.ErrorNotification);
  }


  AddPaymentValidation(data: any) {
    this.Paymentinfo = new PaymentInfo();
    this.Paymentinfo = data;

    this.Paymentinfo.PaymentModeID = data.PaymentModeID;

    switch (data.PayModeType) {
      case ('CASH'):
        this.Paymentinfo.Amount = this.paymentCombo.paymode.controls['Amount'].value;
        this.Paymentinfo.FromLedger = this.Paymentinfo.ToLedger = this.paymentCombo.paymode.controls['LedgerName'].value;
        this.paymentCombo.ledgerList.filter((e: LedgerList) => {
          if (e.LedgerName === 'UNDEPOSITED CASH') {
            this.paymentCombo.paymode.controls['BankName'].setValue(e);
            this.Paymentinfo.FromLedger = this.Paymentinfo.ToLedger = this.paymentCombo.paymode.controls['BankName'].value;
          }
        })
        // this.Paymentinfo.LedgerID = this.paymentCombo.paymode.controls['BankName'].value;
        // this.Paymentinfo.LedgerName = this.Paymentinfo.BankName = this.paymentCombo.paymode.controls['LedgerName'].value;
        this.Paymentinfo.PayModeValue = this.paymentamount;
        this.Paymentinfo.TransactionDate = '';
        this.Paymentinfo.TransactionNo = 0;
        break;

      case ('WALLET'):
        this.Paymentinfo.Amount = this.paymentCombo.paymode.controls['Amount'].value;
        this.Paymentinfo.FromLedger = this.Paymentinfo.ToLedger = this.paymentCombo.paymode.controls['LedgerName'].value;
        // this.Paymentinfo.ToLedger = this.paymentCombo.paymode.controls['BankName'].value;
        this.paymentCombo.LstToBankTemp.filter((e: LedgerList) => {
          if (e.LedgerName.toLocaleLowerCase() == 'wallet bank') {
            const LedgerVal: any = e;
            this.Paymentinfo.ToLedger = LedgerVal;
          }
        })
        this.paymentCombo.LstFromBankTemp.filter((e: LedgerList) => {
          if (e.LedgerName.toLocaleLowerCase() == 'wallet bank') {
            this.paymentCombo.paymode.controls['BankName'].setValue(e);
            this.Paymentinfo.FromLedger = this.paymentCombo.paymode.controls['BankName'].value;
          }
        })
        this.Paymentinfo.PayModeValue = this.paymentamount;
        this.Paymentinfo.TransactionDate = new Date();
        this.Paymentinfo.TransactionNo = 0;
        break;

      case ('CHEQUE'):
      case ('DEMAND DRAFT'):
      case ('BANK REMITTANCE'):
      case ('NEFT'):
      case ('DEBIT CARD'):
      case ('CREDIT CARD'):
      case ('BANK TRANSFER'):
      case ('UPI'):
        this.Paymentinfo.Amount = this.paymentCombo.paymode.controls['Amount'].value;
        this.Paymentinfo.TransactionNo = this.paymentCombo.paymode.controls['TransactionNo'].value;
        this.Paymentinfo.TransactionDate = DateConversion.ConvertToMonthDateYear(this.paymentCombo.paymode.controls['TransactionDate'].value);
        this.Paymentinfo.FromLedger = this.paymentCombo.paymode.controls['FromBankName'].value;
        this.Paymentinfo.ToLedger = this.paymentCombo.paymode.controls['BankName'].value;
        this.Paymentinfo.PayModeValue = this.paymentCombo.paymode.controls['PayModeValue'].value;
        this.Paymentinfo.DocumentID = this.paymentCombo.MlScreenshotFile.DocumentID;
        break;
    }


    if (data.PayModeType.toUpperCase() != 'CASH') {
      if (this.BalanceAmount >= this.Paymentinfo.Amount) {
        (this.Paymentinfo.Amount !== null && this.Paymentinfo.Amount !== 0) ? this.PaymentDetails.push(this.Paymentinfo) : '';
        this.setTotalAmt(this.PaymentDetails);
        this.paymentCombo.paymode.controls['Amount'].reset();
        this.paymentCombo.paymode.controls['TransactionNo'].reset();
        this.paymentCombo.paymode.controls['TransactionDate'].setValue(new Date());
        this.paymentCombo.paymode.controls['BankName'].reset();
        this.paymentCombo.paymode.controls['FromBankName'].reset();
        this.paymentCombo.paymode.controls['LedgerName'].reset();
        this.paymentCombo.paymode.controls['PayModeValue'].reset();
      }
      else this.errorMsg(this.ErrorNotify);
    }
    else {
      let isProcessed: Boolean = false;
      this.Paymentinfo.TransactionDate = DateConversion.ConvertToMonthDateYear(new Date());


      this.PaymentDetails.forEach(element => {

        if (element.PayModeType.toLowerCase() == this.paymentCombo.SelectedMode && isProcessed === false && element.FromLedger.LedgerName === this.paymentCombo.BankLedgerName?.LedgerName) {
          if (this.BalanceAmount >= this.Paymentinfo.Amount) {
            element.Amount = element.Amount + this.Paymentinfo.Amount;
            this.setTotalAmt(this.PaymentDetails);
            this.paymentCombo.paymode.controls['Amount'].reset();
            this.paymentCombo.paymode.controls['BankName'].reset();
            this.paymentCombo.paymode.controls['FromBankName'].reset();
            this.paymentCombo.paymode.controls['LedgerName'].reset();
            isProcessed = true;
          }
          else this.errorMsg(this.ErrorNotify);
        }
      });

      if (!isProcessed) {
        if (this.BalanceAmount >= this.Paymentinfo.Amount) {
          (this.Paymentinfo.Amount !== null && this.Paymentinfo.Amount !== 0) ? this.PaymentDetails.push(this.Paymentinfo) : '';
          this.setTotalAmt(this.PaymentDetails);
          this.paymentCombo.paymode.controls['Amount'].reset();
          this.paymentCombo.paymode.controls['BankName'].reset();
          this.paymentCombo.paymode.controls['FromBankName'].reset();
          this.paymentCombo.paymode.controls['LedgerName'].reset();
        }
        else this.errorMsg(this.ErrorNotify);
      }
    }
    this.paymentmessage = false;
  }

  setTotalAmt(detail: PaymentInfo[]) {
    this.Totalamount = detail.reduce((n, { Amount }) => n + Amount, 0);
    this.BalanceAmount = this.paymentamount - this.Totalamount;

  }

  deleteRow(i: number, row: PaymentInfo) {
    this.PaymentDetails.splice(i, 1);
    this.Totalamount = this.Totalamount - row.Amount;
    this.BalanceAmount = this.paymentamount - this.Totalamount;
    if (this.PaymentDetails.length === 0) {
      this.Totalamount = this.BalanceAmount = 0;
      this.paymentmessage = true;
    }
  }

  /* Show Error Msg*/
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
