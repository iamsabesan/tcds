import { NgModule } from "@angular/core";
import { PaymentGridComponent } from "./payment-grid.component";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { InputsModule } from "@progress/kendo-angular-inputs";
// import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
// import { BrowserModule } from "@angular/platform-browser";
// import { PopupModule } from "@progress/kendo-angular-popup";
import { LabelModule } from "@progress/kendo-angular-label";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { PaymentModule } from "../payment/payment.module";
import { CommonModule } from "@angular/common";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
// import { IconsModule } from "@progress/kendo-angular-icons";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
// import { PopupModule } from "@progress/kendo-angular-popup";
// import { NotificationModule } from "@progress/kendo-angular-notification";

@NgModule({
    declarations: [PaymentGridComponent],
    exports: [PaymentGridComponent],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,

        /* Kendo Component */
        LayoutModule,
        InputsModule,
        LabelModule,
        NavigationModule,
        ButtonsModule,
        DialogsModule,
        DateInputsModule,
        DropDownsModule,

        /* Shared Component */
        PaymentModule,
    ],
    providers: []
})
export class PaymentGridModule { }