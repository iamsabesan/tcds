import { ChangeDetectionStrategy, Component, HostListener, Input, OnInit } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { LocalString } from '../../app-global';
import { PaymentDetailViewListMl } from '../../model/common';
import { CommonService } from '../../service/common.service';
import { IWebError } from 'src/core/model';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CustomNotification } from '../../model/shared';

@Component({
  selector: 'app-payment-info',
  templateUrl: './payment-info.component.html',
  styleUrls: ['./payment-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentInfoComponent implements OnInit {

  @Input() GridData: PaymentDetailViewListMl[] = [];
  @Input() totalAmount: number = 0;
  @Input() isShowFooter: boolean = true;
  @Input() isShowNotes: boolean = false;
  currencySymbol: string = '';
  public Data: any[] = [];
  public dateFormat: string = '';
  public CheckUPIDocumentID: boolean = false;

  public dialogDetailsWidth = 450;
  public ShowDocumentDialog = false;

  public DocumentScreenshotFile = '/assets/Image/reg-proof.png';
  public DocumentScreenshotFileType = '';
  public DocumentScreenshotFileName = '';
  public DocumentScreenshotFileId = '';
  public PaymentPaymodeName = '';


  @HostListener('window:resize', [])
  onWindowResize() {
    this.getWindowDimesion(window);
  }

  getWindowDimesion(window: Window) {
    window.innerWidth > 1550 || window.innerWidth < 1100 ? this.dialogDetailsWidth = 480 : this.dialogDetailsWidth = 450;
  }


  constructor(public CurrencyService: IntlService, public notificationService: NotificationService, private _srvCom: CommonService) { }

  ngOnInit(): void {
    if (this.GridData.length !== 0) this.totalAmount = this.GridData.reduce((sum: any, current: any) => sum + current.Amount, 0);
    this.currencySymbol = LocalString.CurrencySymbol;
    this.dateFormat = LocalString.DateFormat;
    this.Data = this.GridData;

    setTimeout(() => {
      this.CheckUPIDocumentID = this.Data.find(e => e.DocumentID != "00000000-0000-0000-0000-000000000000");
    },);
  }

  view(data: PaymentDetailViewListMl) {
    this.imagePreview(data);
  }

  imagePreview(data: PaymentDetailViewListMl) {
    this.DocumentScreenshotFileId = '';
    this.PaymentPaymodeName = '';
    if (data.DocumentID !== '00000000-0000-0000-0000-000000000000') {
      this._srvCom.previewImage(data.DocumentID).subscribe({
        next: (res: any) => {
          if (res.Data.FileExtension !== '.pdf') {
            this.DocumentScreenshotFile = 'data:' + res.Data.MIMEType + ';base64,' + res.Data.ProfileBase64;
            this.DocumentScreenshotFileType = 'Image';
            this.DocumentScreenshotFileName = res.Data.FileName;
          }
          else {
            this.DocumentScreenshotFileName = res.Data.FileName;
            this.DocumentScreenshotFileType = 'PDF';
            this.DocumentScreenshotFile = '/assets/Image/PDF_Image.png';
          }
          this.DocumentScreenshotFileId = data.DocumentID;
          this.PaymentPaymodeName = data.PayMode;
          this.ShowDocumentDialog = true;

        },

        error: (err: IWebError) => this.errorMsg(err.Message)
      });
    }
    else {
      this.DocumentScreenshotFile = '/assets/Image/reg-proof.png';
      this.DocumentScreenshotFileType = '';
    }
  }

  btnDownloadScreenshotProof(Paymode: string) {
    this._srvCom.downloadAttachment(this.DocumentScreenshotFileId, Paymode);
  }


  documentDialogClose() {
    this.ShowDocumentDialog = false;
    this.DocumentScreenshotFile = '/assets/Image/reg-proof.png';

  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this.notificationService).ShowError(err);
  }
}
