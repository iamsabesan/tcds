import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { GridModule } from "@progress/kendo-angular-grid";
import { PaymentInfoComponent } from "./payment-info.component";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { IconsModule } from "@progress/kendo-angular-icons";
// import { PDFViewerModule } from '@progress/kendo-angular-pdfviewer';



@NgModule({
  declarations: [
    PaymentInfoComponent
  ],
  imports: [
    CommonModule,
    GridModule,
    DialogsModule,
    IconsModule,
    // PDFViewerModule
  ],
  exports: [PaymentInfoComponent],
  providers: [],
})
export class PaymentInfoModule {

}
