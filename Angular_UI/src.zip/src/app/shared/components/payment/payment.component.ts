import { ChangeDetectorRef, Component, Input } from '@angular/core';
import { PaymentService } from '../../service/payment.service';
import { BankLager, CashLager, ImageUploadResult, PayModeList } from '../../model/payment';
import { IWebError } from 'src/core/model';
import { CustomNotification } from '../../model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { PaymentInfo } from '../../model/payment-grid.model';
import { DropDownFilter, LocalString } from '../../app-global';
import { BankList, LedgerList } from '../../model/payment.model';
import { alphaNumericOnly, onlyNumbers } from '../regex';
import { DialogRef } from '@progress/kendo-angular-dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PaymentGridComponent } from '../payment-grid/payment-grid.component';
import { CommonService } from '../../service/common.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent {

  /* List */
  public LstPaymode: PayModeList[] = [];
  public BankList: BankList[] = [];
  public ledgerList: LedgerList[] = [];
  public LstFromBank: BankLager[] = [];
  public LstToBank: BankLager[] = [];
  public LstFromBankTemp: BankLager[] = [];
  public LstToBankTemp: BankLager[] = [];
  public LstLeger: CashLager[] = [];

  /* Input Decorator */
  @Input() public Paymentinfo: PaymentInfo[] = [];
  @Input() public paymentamount = 0;
  @Input() public PaymentModeID = '';
  @Input() public Amount?: number;
  @Input() public PayModeValue!: number;
  @Input() public BankName = new LedgerList();
  @Input() public LedgerName = new CashLager();
  @Input() public TransactionNo!: number;
  @Input() public TransactionDate = new Date();
  @Input() public BankNameForDD = '';
  @Input() public DDNumber!: number;
  @Input() public DDDate = new Date();
  @Input() public BankNameForRTGS = '';
  @Input() public RTGSTransNo!: number;
  @Input() public RTGSTransDate = new Date();
  @Input() public NEFTTransNo!: number;
  @Input() public NEFTTransDate = new Date();
  @Input() public BankNameForNEFT = '';
  @Input() public CreditCardTransNo!: number;
  @Input() public CreditCardTransDate = new Date();
  @Input() public BankNameForCreditCard = '';
  @Input() public UpiTransNo!: number;
  @Input() public BankNameForUpi = '';
  @Input() public UpiTransDate = new Date();
  @Input() public Totalamount = 0;
  @Input() public PaymentType = '';

  @Input() ModuleName = '';
  @Input() Subscription: boolean = false;
  @Input() allowMultiplePaymode: boolean;

  @Input() public FromBankName = new LedgerList();

  /* Model */
  public MlScreenshotFile: ImageUploadResult = new ImageUploadResult();

  /* PayMode List */
  public PayModeList: PayModeList[] = [];

  public ddvalue: number = 0;
  public RTGAValue: number = 0;
  public NEFTValue: number = 0;
  public CreditCardValue: number = 0;
  public UPIValue: number = 0;
  public ShowPaymode: boolean = true;
  public PaymentDetail: PaymentInfo[] = [];

  public PaymentInfo: PaymentInfo = new PaymentInfo();
  public SelectedMode = "";
  public showContinue!: boolean;
  public readOnly!: boolean;
  public showAmtError: boolean = false;
  public showErrMsg: string = '';
  public setMaxValue: number = 0;
  public setMinValue: number = 0;

  public MinimumAmount: number = 0;
  public MaximumAmount: number = 0;

  //Payment Integration
  public PayModeMl: PayModeList = new PayModeList();
  public filterSettings = DropDownFilter.filterSettings;

  disbledDepositFrom: boolean;

  public LedgerColumn = [
    {
      Field: 'LedgerName',
      Title: 'Bank',
      Width: 220,
    },
    {
      Field: 'AccountType',
      Title: 'A/C Type',
      Width: 140,
    },
  ]

  public onlyNumbers = onlyNumbers;
  public alphaNumeric = alphaNumericOnly;

  public transactionType: string = 'receipt';

  /* Change Transcation & Cheque Name */
  public TransactionName: string = '';
  public TransactionMinLength: number = 0;
  public TransactionMaxLength: number = 0;

  // Screenshot File
  public screenshotProofFile: any;
  public screenshotProofName = '';
  public FileExtension: string = "";

  public checkScreenshotProofFile = false;
  public checkScreenshotProofFileSize = false;
  public checkScreenshotProofFileType = false;

  checkScreenShotInput = true;

  constructor(private _srvPayment: PaymentService, private _srvNotification: NotificationService,
    public dialog: DialogRef, public _cd: ChangeDetectorRef, private fb: FormBuilder,
    private PaymentGrid: PaymentGridComponent, private _srvCom: CommonService) { }

  public paymode: FormGroup = this.fb.group({
    PaymentModeID: [this.PaymentModeID, Validators.required],
    Amount: [this.PaymentGrid.BalanceAmount, [Validators.required, Validators.min(1)]],
    PayModeValue: [0],
    FromBankName: [this.FromBankName],
    BankName: [this.BankName],
    LedgerName: [this.LedgerName],
    TransactionNo: [this.TransactionNo],
    TransactionDate: [this.TransactionDate],
    screenshot: [null]

  });


  public DateFormat: string = "";
  ngOnInit(): void {
    this.screenshotProofFile = '/assets/Image/reg-proof.png';

    this.disbledDepositFrom = this.PaymentGrid.disbledDepositFrom;

    this.DateFormat = LocalString.DateFormat;

    this._srvPayment.getPaymentType().subscribe({
      next: (response) => this.LstPaymode = response.Data.filter(e => this.PaymentGrid.IsWalletTransfer ? e : e.Paymode !== 'WALLET'),
      error: (err: IWebError) => new CustomNotification(this._srvNotification).ShowError(err.Message)
    });

    this.setMaxValue = this.MaximumAmount = this.paymentamount;

    if (this.allowMultiplePaymode == false && this.ModuleName == 'Blocking') {
      this.showContinue = false;
      this.formSetValue('Amount', this.paymentamount)
      this.formSetValue('PayModeValue', this.paymentamount)
      this.readOnly = true;
    }
    else {
      this.showContinue = true;
      this.readOnly = false;
    }
    this.getDepositBank();
  }

  public BankLedgerName: string = '';
  paymodeProperties(event: any) {
    if (event) {
      this.PayModeMl.Paymode = this.PaymentInfo.PayModeType = this.LstPaymode.filter((e) => e.PaymodeID === event)[0].Paymode;

      this.PayModeMl.PaymodeID = this.PaymentInfo.PaymentModeID = event;

      if (this.ModuleName === 'Blocking') {
        this.formSetValue('Amount', this.PaymentGrid.BalanceAmount)
        this.formSetValue('PayModeValue', this.PaymentGrid.BalanceAmount);
      }
      else {
        if (this.PayModeMl.Paymode === 'CASH') {
          this.formSetValue('Amount', this.PaymentGrid.BalanceAmount)
          this.formSetValue('PayModeValue', this.PaymentGrid.BalanceAmount)
        }
        else {
          this.readOnly = false;
        }
      }


      this.SelectedMode = this.PaymentInfo.PayModeType !== 'CASH' ? "bank" : "cash";

      this._srvPayment.GetLedgers().subscribe({
        next: (res: any) => {
          this.ledgerList = res.Data.filter((e: LedgerList) => e.LedgerName !== 'PETTY CASH');
          if (this.SelectedMode === 'cash') this.ledgerList = res.Data.filter((e: LedgerList) => e.LedgerName === 'UNDEPOSITED CASH');
          else this.ledgerList = res.Data;

          this.formReset('TransactionNo')
          // this.formReset('TransactionDate')
          this.formReset('BankName')
          this.formReset('FromBankName')
          this.formSetValue('TransactionDate', new Date());
          this.screenshotProofFile = '/assets/Image/reg-proof.png';
          this.MlScreenshotFile = new ImageUploadResult();
          this.paymode.controls['screenshot'].clearValidators()
          this.paymode.controls['screenshot'].updateValueAndValidity()

          this.screenshotProofName = '';
          this.checkScreenshotProofFile = this.checkScreenshotProofFileSize = this.checkScreenshotProofFileType = false;

          if ((this.PaymentInfo.PayModeType.toUpperCase() == 'UPI') || (this.PaymentInfo.PayModeType.toUpperCase() === 'BANK REMITTANCE')) {
            this.paymode.controls['screenshot'].setValidators([Validators.required]);
            this.paymode.controls['screenshot'].updateValueAndValidity();
          }


          switch (this.PaymentInfo.PayModeType) {
            case ('CASH'):
              this.formEnable('Amount')
              this.formEnable('LedgerName')
              this.paymode.controls['TransactionNo'].clearValidators();
              this.paymode.controls['TransactionNo'].updateValueAndValidity;

              this.ledgerList.filter((e: LedgerList) => {
                if (e.LedgerName === 'UNDEPOSITED CASH') {
                  this.formSetValue('BankName', e);
                  this.formSetValue('LedgerName', e);
                }
              })
              break;

            case ('WALLET'):
              this.formEnable('Amount')
              this.formEnable('LedgerName')
              this.paymode.controls['TransactionNo'].clearValidators();
              this.paymode.controls['TransactionNo'].updateValueAndValidity;

              this.LstToBankTemp.filter((e: LedgerList) => {
                if (e.LedgerName.toLowerCase() === 'wallet bank') {

                  this.formSetValue('BankName', e);
                  this.formSetValue('LedgerName', e);
                }
              })
              break;

            case ('CHEQUE'):
              this.MinimumAmount = 0;
              this.MaximumAmount = 9999999999;

              this.TransactionName = 'Cheque';

              this.TransactionMinLength = this.TransactionMaxLength = 6;
              this.paymode.controls['TransactionNo'].setValidators([Validators.required, Validators.minLength(this.TransactionMaxLength), Validators.maxLength(this.TransactionMaxLength)]);
              this.paymode.controls['TransactionNo'].updateValueAndValidity;

              this.paymode.controls['PayModeValue'].setValidators([Validators.required, Validators.min(this.MinimumAmount), Validators.max(this.MaximumAmount)]);
              this.paymode.controls['PayModeValue'].updateValueAndValidity;

              this.formEnable('PayModeValue');
              this.formEnable('TransactionNo');
              this.formEnable('Amount');
              this.formEnable('TransactionDate');
              this.formEnable('BankName');
              this.formEnable('FromBankName');

              this.formSetValue('BankName', '')
              this.formSetValue('FromBankName', '')
              break;

            case ('DEMAND DRAFT'):
            case ('BANK REMITTANCE'):
            case ('NEFT'):
            case ('DEBIT CARD'):
            case ('CREDIT CARD'):
            case ('BANK TRANSFER'):
            case ('UPI'):
              this.MinimumAmount = this.PaymentGrid.BalanceAmount;
              this.MaximumAmount = this.PaymentGrid.BalanceAmount;

              this.TransactionName = 'Transaction';
              this.TransactionMinLength = 6;
              this.TransactionMaxLength = 16;
              this.paymode.controls['TransactionNo'].setValidators([Validators.required, Validators.minLength(this.TransactionMinLength), Validators.maxLength(this.TransactionMaxLength)]);
              this.paymode.controls['TransactionNo'].updateValueAndValidity;

              this.paymode.controls['PayModeValue'].setValidators([Validators.required, Validators.min(this.MinimumAmount), Validators.max(this.MaximumAmount)]);
              this.paymode.controls['PayModeValue'].updateValueAndValidity;
              this.formSetValue('PayModeValue', this.PaymentGrid.BalanceAmount)

              this.formEnable('PayModeValue');
              this.formEnable('TransactionNo');
              this.formEnable('Amount');
              this.formEnable('TransactionDate');
              this.formEnable('BankName');
              this.formEnable('FromBankName');

              this.formSetValue('BankName', '')
              this.formSetValue('FromBankName', '')
              this.formReset('BankName')
              this.formReset('TransactionNo')
              this.formDisbled('LedgerName')

              break;
            default:
              this.formReset('Amount')
              this.formReset('TransactionNo')
              this.formReset('BankName')
              this.formReset('FromBankName')
              this.formReset('PayModeValue')
          }
        }


      })
      this.formDisbled('Amount');
      this.formDisbled('TransactionNo');
      this.formDisbled('BankName');
      this.formDisbled('FromBankName');
      this.formDisbled('TransactionDate');


    }

    else {
      this.PayModeMl.Paymode = "";
      this.formReset('Amount')
      this.formReset('TransactionNo')
      this.formReset('BankName')
      this.formReset('FromBankName')
      this.formReset('PayModeValue')
    }
  }

  changeAmount(data: number) {
    // const amount = data;
    this.MinimumAmount = this.MaximumAmount = data;
    this.paymode.controls['PayModeValue'].setValidators([Validators.required, Validators.min(data), Validators.max(data)]);
  }

  getDepositBank() {
    this._srvPayment.getAdminBankLst().subscribe(e => {
      this.LstToBankTemp = e.Data;
      this.LstToBank = e.Data.filter((val: any) => val.LedgerName.toLocaleLowerCase() !== 'wallet bank')
    });
    this._srvPayment.getBankLst().subscribe(e => {
      this.LstFromBankTemp = e.Data
      this.LstFromBank = e.Data.filter((val: any) => val.LedgerName.toLocaleLowerCase() !== 'wallet bank')
    }
    );
    this._srvPayment.GetLedgers().subscribe(e => this.LstLeger = e.Data.filter((val: any) => val.LedgerName.toUpperCase() !== 'PETTY CASH'));
  }

  public onConfirmAction(): void {
    this.BankLedgerName = this.paymode.controls['LedgerName'].value;

    if (this.paymode.status == 'INVALID') {
      this.paymode.markAllAsTouched();
      if (!this.paymode.controls['screenshot'].valid) this.checkScreenshotProofFile = true
    }
    else if (this.paymentamount >= this.paymode.controls['Amount'].value && this.paymode.controls['Amount'].value <= this.PaymentGrid.BalanceAmount && this.paymode.controls['Amount'].value !== 0) {
      this.dialog.close({ text: "Submit" });
      this.showAmtError = false;
    }
    else {
      this.showAmtError = true;
      new CustomNotification(this._srvNotification).ShowErrorMsg(`Amount should not greater than balance Amount`);
    }
    this._cd.markForCheck();
  }



  public ContinueAction() {
    if (!this.paymode.controls['LedgerName'].value) this.formSetValue('LedgerName', '')
    if (!this.paymode.valid) {
      this.paymode.markAllAsTouched();
      if (!this.paymode.controls['screenshot'].valid) this.checkScreenshotProofFile = true;

    }
    else if ((this.paymentamount >= this.paymode.controls['Amount'].value) && (this.paymode.controls['Amount'].value <= this.PaymentGrid.BalanceAmount) && this.paymode.controls['Amount'].value != 0) {
      var PaymentData = new PaymentInfo();
      PaymentData = this.paymode.value;
      PaymentData.PayModeType = this.PayModeMl.Paymode;
      PaymentData.DocumentID = this.MlScreenshotFile.DocumentID;
      this.BankLedgerName = this.paymode.controls['LedgerName'].value;
      this.PaymentGrid.AddPaymentValidation(PaymentData);
      this.MinimumAmount = this.MaximumAmount = this.PaymentGrid.BalanceAmount;
      this.formSetValue('Amount', this.PaymentGrid.BalanceAmount);
      this.formSetValue('PayModeValue', this.PaymentGrid.BalanceAmount);
      this.paymode.controls['PayModeValue'].setValidators([Validators.required, Validators.min(this.MinimumAmount), Validators.max(this.MaximumAmount)]);
      this.paymode.controls['PayModeValue'].updateValueAndValidity();
      this.showAmtError = false;
      this.checkScreenshotProofFile = this.checkScreenshotProofFileSize = this.checkScreenshotProofFileType = false;
      this.screenshotProofFile = "/assets/Image/reg-proof.png";
      this.paymode.controls['screenshot'].reset();

      if (this.PayModeMl.Paymode.toUpperCase() === 'WALLET') {
        this.LstToBankTemp.filter((e: LedgerList) => {
          if (e.LedgerName.toLowerCase() === 'wallet bank') {
            this.formSetValue('BankName', e);
            this.formSetValue('LedgerName', e);
          }
        })
      }
    }
    else {
      this.showAmtError = true;
      const toPascalCase = (text: any, trimSpace = false) => text.split(' ').map((t: any) => t[0].toUpperCase() + t.slice(1).toLowerCase()).join(trimSpace ? '' : ' ')
      new CustomNotification(this._srvNotification).ShowErrorMsg(`Amount should not greater than  ${toPascalCase(this.ModuleName)} Amount`);
    }

    this.PaymentGrid.BalanceAmount === 0 ? this.dialog.close({ text: "Submit" }) : '';

  }

  getFileNameWithExt(event: any) {
    if (!event || !event.target || !event.target.files || event.target.files.length === 0) return;
    const name = event.target.files[0].name;
    const lastDot = name.lastIndexOf(".");
    const ext = name.substring(lastDot + 1);
    this.FileExtension = ext;
  }

  screenshotProofChange(event: any, fileInput: HTMLInputElement, fileName: string) {
    this.MlScreenshotFile = new ImageUploadResult();
    this.paymode.controls['screenshot'].setValue(null);
    this.screenshotProofName = '';
    this.checkScreenshotProofFile = this.checkScreenshotProofFileSize = this.checkScreenshotProofFileType = false;
    this.screenshotProofFile = "/assets/Image/reg-proof.png";

    this.getFileNameWithExt(event);
    if (this.FileExtension.toLocaleLowerCase() === "jpg" || this.FileExtension.toLocaleLowerCase() === "jpeg" || this.FileExtension.toLocaleLowerCase() === "png" || this.FileExtension.toLocaleLowerCase() === "pdf") {
      const reader = new FileReader();
      if (event.target.files && event.target.files.length) {
        if (event.target.files[0].size >= 2097152) {
          this.checkScreenshotProofFileSize = true;
        } else {
          const [file1] = event.target.files;
          const file = event.target.files[0];
          this.paymode.controls['screenshot'].setValue(file)

          this.fileData(file, fileName)
          reader.readAsDataURL(file1);
          reader.onload = () => {
            if (this.FileExtension.toLocaleLowerCase() === "pdf") {
              this.screenshotProofFile = '/assets/Image/PDF_Image.png';
              this.screenshotProofName = file.name;
            } else {
              this.screenshotProofFile = reader.result as any;
            }
          }
        }
      }
    }
    else {
      this.checkScreenshotProofFileType = true;
    }
    fileInput.value = '';
  }

  fileData(file: any, type: string) {
    this._srvCom.postImageUpload(type, file).subscribe({
      next: val => {
        this.MlScreenshotFile = val.Data;
      },
      error: (err) => this.errorMsg(err.Message)
    })
  }

  formSetValue(data: string, value: any) {
    this.paymode.controls[data].setValue(value);
  }
  formEnable(data: string) {
    this.paymode.controls[data].enable();
  }
  formDisbled(data: string) {
    this.paymode.controls[data].disable();

  }
  formReset(data: string) {
    this.paymode.controls[data].reset();
  }

  /* Show Error Msg */
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }

}
