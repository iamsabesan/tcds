import { NgModule } from "@angular/core";
import { PaymentComponent } from "./payment.component";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LabelModule } from "@progress/kendo-angular-label";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogsModule } from "@progress/kendo-angular-dialog";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IconsModule } from "@progress/kendo-angular-icons";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { CommonModule } from "@angular/common";
import { TooltipModule } from "@progress/kendo-angular-tooltip";
// import { PopupModule } from "@progress/kendo-angular-popup";

@NgModule({
    declarations: [PaymentComponent],
    exports: [PaymentComponent],
    imports: [
        CommonModule,
        ButtonsModule,
        LayoutModule,
        IconsModule,
        LabelModule,
        InputsModule,
        FormsModule,
        ReactiveFormsModule,
        NavigationModule,
        DialogsModule,
        DateInputsModule,
        DropDownsModule,
        TooltipModule
    ],
    providers: []
})
export class PaymentModule { }