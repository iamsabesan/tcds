import { Component, OnInit,  EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { DialogRef } from '@progress/kendo-angular-dialog';
import { NotificationService } from '@progress/kendo-angular-notification';
// import { Input } from 'postcss';
import { MlReason } from '../../model/info.model';
import { CustomNotification } from '../../model/shared';
import { SharedService } from '../../service/shared.service';

@Component({
  selector: 'app-reject',
  templateUrl: './reject.component.html',
  styleUrls: ['./reject.component.scss']
})
export class RejectComponent implements OnInit {
  @Output() formSubmitted = new EventEmitter<any>();


  public RejectForm!: NgForm;
  public MlReason: MlReason = new MlReason();
  public formStatus: string = '';
  public previousUrl: string = '';
  public currentUrl: string = '';
  public payment!: boolean;
  constructor(public dialog: DialogRef, private _srvNotification: NotificationService, public router: Router, public service: SharedService) {
  }

  ngOnInit() {
    this.payment = false;
  }


  save(form: NgForm) {
    
    if (form.valid) {
      this.formSubmitted.emit(this.MlReason);
    }
  }

  /* Show Msg */
  successMsg(res: string) {
    new CustomNotification(this._srvNotification).ShowSuccess(res);
  }
  errorMsg(err: string) {
    new CustomNotification(this._srvNotification).ShowError(err);
  }
}
