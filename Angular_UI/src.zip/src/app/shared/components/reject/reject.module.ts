import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { RejectComponent } from "./reject.component";




@NgModule({
  declarations: [
    RejectComponent
  ],
  imports: [
    CommonModule,
    DialogModule,
    InputsModule,
    ButtonsModule,
    LabelModule,
    FormsModule,
  ],
  exports: [RejectComponent],
  providers: [],
})
export class RejectModule {

}
