import { Component, Input, OnInit } from '@angular/core';
import { IntlService } from '@progress/kendo-angular-intl';
import { CountryCurrency } from '../../app-global';

@Component({
  selector: 'app-student-course-detail',
  templateUrl: './student-course-detail.component.html',
  styleUrls: ['./student-course-detail.component.scss']
})
export class StudentCourseDetailComponent implements OnInit {
  @Input() studentCourseFeesData: any
  constructor(public CurrencyService: IntlService) { }

  CountryCurrencyType: string = CountryCurrency.CountryCurrencyType;
  CountryCurrencyEnd: string = CountryCurrency.CountryCurrencyEnd;

  ngOnInit(): void { }

}
