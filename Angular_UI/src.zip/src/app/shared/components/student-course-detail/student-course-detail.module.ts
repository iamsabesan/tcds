import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { StudentCourseDetailComponent } from './student-course-detail.component';

@NgModule({
  declarations: [
    StudentCourseDetailComponent
  ],
  imports: [
    CommonModule,
    LayoutModule
  ],
  providers: [],
  exports: [StudentCourseDetailComponent]
})
export class StudentCourseDetailModule { }
