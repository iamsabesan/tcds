export class CourseBasicData {
  CourseID: string = '';
  CourseName: string = '';
  ShortName: string = '';
  CourseType: string = '';
  Semester: number = 0;
  Duration: string = '';
}

/* Get Course Detail */
export class CourseDetailMl {
  CourseID: string = '';
  ShortName: string = '';
  Course: string = '';
  CourseType: string = '';
  Semester: number = 0;
  Duration: string = '';
  DurationType: string = '';
  CertificatePrintName: string = '';
  CourseFees: number = 0;
  ExamFees: number = 0;
  AdmissionFees: number = 0;
  TotalFees: number = 0;
  NetAmount: number = 0;
  DiscountAmount: number = 0;
  Eligibility: string = '';
}

/* Batch Detail */
export class batchBasicData {
  CourseBatchID: string = '';
  BatchNumber: string = '';
  CourseName: string = '';
  FacultyID: string = '';
  Timing: string = '';
  BatchType: string = '';
  FacultyName = '';
  CourseTypeName: string = '';
}

export class batchByIDDataType {
  BatchNumber: string = '';
  CourseBatchID: string = '';
  Timing: string = '';
  FacultyID: string = '';
  FacultyName: string = '';
  BatchType?: string = '';
  Date?: string = '';
  StartDate?: string = '';
  EndDate?: string = '';
  startTime: Date = new Date();
  endTime: Date = new Date();
}

/* Student Detail */
export class StudentBasicDetail {
  BatchMappingID: string = '';
  StudentID: string = '';
  ContactID: string = '';
  RollNumber: string = '';
  StudentName: string = '';
  Phone: string = '';
  AlternatePhone: string = '';
  Course: string = '';
  BatchNumber: string = '';
  BatchTime: string = '';
}

export class DateType {
  fromDate: string = '';
  toDate: string = '';
}

/* Create a new Material List */
export class materialListDataType {
  MaterialID: string = '';
  MaterialName: string = '';
  Price: number = 0;
  MinimumStock: number = 0;
  OpeningStock: number = 0;
}

/* Material List */
export class AllMaterialListDataType {
  MaterialName: string = '';
  MaterialID: string = '';
}

/* Material Type */
export class materialTypeListDataType {
  MaterialTypeID: string = '';
  MaterialType: string = '';
}

//#region Delivery
/* Delivery Mode Type */
export class DeliveryModeList {
  DeliveryModeID: string = '';
  DeliveryModeName: string = '';
}

export class CreateDeliveryMode {
  deliveryModeName: string = '';
}

export class DeliveryModeType {
  modeName: string = '';
  value: number = 0;
}
//#endregion

export class basicAddressDataType {
  Address?: string = '';
  Phone: string = '';
  AlternatePhone: string = '';
  Email: string = '';
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  District: string = '';
  State: string = '';
  Country: string = '';
  Pincode: string = '';
}
export class franchiseeBasicInfoDataType {
  TenantBranchID: string = '';
  BranchCode: string = '';
  BranchName: string = '';
  ContactName: string = '';
  Phone: string = '';
  AddressTypeID: string = '';
  AddressType: string = '';
  Address?: string = '';
  Address1: string = '';
  Address2: string = '';
  Country: string = '';
  State: string = '';
  District: string = '';
  Area: string = '';
  Pincode: string = '';
}

/* Student Mapped Batch */
export class StudentListCourseBatchID {
  StudentID: string = '';
  ContactName: string = '';
  RollNumber: string = '';
  Semester: number = 0;
}

/* Address */
export class Address {
  Address1: string = '';
  Address2: string = '';
  Area: string = '';
  Country: any;
  State: string = '';
  District: string = '';
  PinCode: string = '';
}

/* Update the Employee & Agent Status */
export class UpdateStatus {
  ContactID: string = '';
  Status: boolean = false
}

/* Country */
export class Country {
  CountryID: number = 0;
  CountryName: string = '';
}

/* State */
export class State {
  StateProvinceID: number = 0;
  StateProvinceName: string = '';
}

/* District */
export class District {
  DistrictID: number = 0;
  DistrictName: string = '';
}

/* Phone Code */
export class PhoneCode {
  PhoneCode: string = '';
  PhoneNumberLength: number = 0;
}

/* Phone Code */
export class IPhoneCode {
  PhoneCode: string = '';
}

/* Multi-Column Dropdown Column */
export class MultiDropdownColumn {
  Field: string = '';
  Title: string = '';
  Width: number = 0;
}

/* Reason */
export class Reason {
  ReasonID: string = '';
  Reason: string = '';
}

/* Centre / Purpose */
export class Purpose {
  ID: string = '';
  Value: string = '';
}


/* MultiColumn Dropdown  */
/* Fee Balance (Franchisee) */
export const BatchColumn: MultiDropdownColumn[] = [
  {
    Field: 'ShortName',
    Title: 'Course Code',
    Width: 100
  },
  {
    Field: 'CourseName',
    Title: 'Course',
    Width: 200
  },
  {
    Field: 'FacultyName',
    Title: 'Faculty Name',
    Width: 200
  },
  {
    Field: 'Timing',
    Title: 'Timing',
    Width: 150
  },
  {
    Field: 'BatchType',
    Title: 'Type',
    Width: 100
  }
]

/* Branch Column */
export const BranchColumn: MultiDropdownColumn[] = [
  {
    Field: 'TenantBranchName',
    Title: 'Name',
    Width: 150
  },
  {
    Field: 'District',
    Title: 'District',
    Width: 110
  },
  {
    Field: 'State',
    Title: 'State',
    Width: 180
  }
]

export const ReportingToColumn: MultiDropdownColumn[] = [
  {
    Field: 'Department',
    Title: 'Department',
    Width: 120,
  },
  {
    Field: 'JobTitle',
    Title: 'Designation',
    Width: 170,
  },
  {
    Field: 'ContactName',
    Title: 'Name',
    Width: 150,
  },
  {
    Field: 'Phone',
    Title: 'Phone',
    Width: 140,
  },
];

export const StudentColumn: MultiDropdownColumn[] = [
  {
    Title: 'Student ID',
    Field: 'RollNumber',
    Width: 180
  },
  {
    Title: 'Name',
    Field: 'StudentName',
    Width: 200
  },
  {
    Title: 'Mobile',
    Field: 'Phone',
    Width: 140
  },
]

export const CourseCodeNameColumn: MultiDropdownColumn[] = [
  {
    Title: 'Course Code',
    Field: 'ShortName',
    Width: 120
  },
  {
    Title: 'Course Name',
    Field: 'Course',
    Width: 230
  },
]

export const CourseColumn: MultiDropdownColumn[] = [
  {
    Title: 'Code',
    Field: 'ShortName',
    Width: 120
  },
  {
    Title: 'Course',
    Field: 'CourseName',
    Width: 230
  },
  {
    Title: 'Type',
    Field: 'CourseType',
    Width: 150
  },
  {
    Title: 'Semester',
    Field: 'Semester',
    Width: 100
  },
]



export class PaymentDetailViewListMl {
  TransactionDate: Date | string = new Date();
  Summary: string = '';
  Amount: number = 0;
  WalletID: string = '';
  DocumentID: string = '';
  PayMode: string = '';
}

// Student Filter Model

export class StudentFilterDataMl {
  StartDate: string = '';
  EndDate: string = '';
  CourseID: string = '';
  CourseBatchID: string = '';
  CourseTypeID: string = '';
}

export class gender_lst {
  GenderID = 0;
  GenderName = '';
}

export class RelationShipListMl {
  MinValue: string = '';
}

export class EditFranchiseeCode {
  FranchiseeEnquiryID: string = '';
  FranchiseeRequestID:string = '';
  FranchiseeCode: string = '';
}

export class CourseTypeListMl {
  CourseType: string = '';
  CourseTypeID: string = '';
}

export class CourseListByCourseTypeMl {
  CourseID: string = '';
  ShortName: string = '';
  Course: string = '';
  CourseType: string = '';
  Semester: number = 0;
  Duration: string = '';
  DurationType: string = '';
  CertificatePrintName: string = '';
  CourseFees: number = 0;
  ExamFees: number = 0;
  AdmissionFees: number = 0;
  TotalFees: number = 0;
  Eligibility: string = '';
}

/* Course Info */
export class CourseInfoListByFranchiseeMl {
  CourseID: string = '';
  ShortName: string = '';
  Course: string = '';
  CourseType: string = '';
  Duration: string = '';
  CourseFees: number = 0;
  ExamFees: number = 0;
  AdmissionFees: number = 0;
  TotalFees: number = 0;
}


export class FranchiseeDashboardMl {
  ApprovalStartDate: string = '';
  ApprovalEndDate: string = '';
  SubscriptionStartDate: string = '';
  SubscriptionEndDate: string = '';
  ApprovalTotalDays: number = 0;
  ApprovalCompletedDays: number = 0;
  ApprovalRemainingDays: number = 0;
  SubscriptionTotalDays: number = 0;
  SubscriptionCompletedDays: number = 0;
  SubscriptionRemainingDays: number = 0;
  Courses: number = 0;
  Inbox: number = 0;
  WalletBalance: number = 0;
  ActiveBatch: number = 0;
  CompletedBatch: number = 0;
  AlumniStudent: number = 0;
  CurrentStudent: number = 0;
  DiscontinuedStudent: number = 0;
  FeesBalance: number = 0;
  MaterialPending: number = 0;
  ExamPending: number = 0;
  MarksheetPending: number = 0;
  CertificatePending: number = 0;
  ContactTitle: string = '';
  ContactName: string = '';
  FranchiseeName: string = '';
  Area: string = '';
  Taluk: string = '';
  District: string = '';
  Date: string = '';
  Day: string = '';
  OwnerImage: OwnerImage = new OwnerImage();
}


export class OwnerImage {
  ContactID: string = '';
  ContactName: string = '';
  DocumentName: string = '';
  FileName: string = '';
  DocumentType: string = '';
  ContentUrl: string = '';
}


