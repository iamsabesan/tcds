export class DateRanges {
    duration: string = '';
    startDate: Date = new Date();
    endDate: Date = new Date();
}

export class DateRange {
    disabled?: boolean;
    id: number = 0;
    value: string = "";
}