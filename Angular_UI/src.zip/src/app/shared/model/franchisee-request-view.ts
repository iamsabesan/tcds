export class imageType {
    ContentUrl: any;
    DocumentName: any;
    DocumentType: any;
    FileName: any;
    TenantBranchID: any;
    TransactionDate: Date = new Date();
    image!: any;
    ThumbnailImage!: any;
    AttachmentContent: string = '';
    ThumbnailData: string = '';
}

export class FranchiseeImgList {
    Content: string = '';
    FileName: string = '';
    MIMEType: string = '';
    DocumentName: string = '';
    image: string = '';
}
