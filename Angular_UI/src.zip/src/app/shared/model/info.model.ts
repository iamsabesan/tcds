export class franchiseeInfo {
  franchiseeID: number = 0;
  franchiseeName: string = '';
  location: string = '';
  mobile: string = '';
  email: string = '';
}
export class renewalInfo {
  renewalType: string = '';
  renewalPlan: string = '';
  renewalDuration: string = '';
  renewalFees: number = 0;
  renewalSubscription: any;
}

export class PaymentInfo {
  indentDate: Date = new Date();
  invoiceNo: number = 0;
  Amount: number = 0;
  summary: string = '';
}

export class MlReason {
  Reason: string = '';
  Payment:string="No";
}

export class dateRange {
  text: string = '';
  value: number = 0;
}


export const paymentInfo = [
  {
    "indentDate": new Date(2023, 2, 25),
    "invoiceNo": 1001,
    "summary": "By Cash",
    "Amount": 900
  },
  {
    "indentDate": new Date(2023, 2, 25),
    "invoiceNo": 1002,
    "summary": "By Cheque #454544 Central Bank Dt. 19/03/2023",
    "Amount": 1000
  }
];
