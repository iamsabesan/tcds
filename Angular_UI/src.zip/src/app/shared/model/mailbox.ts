
/* Post a New */
export class createMailDataType {
    subject: string = ''
    mailContent: string = ''
    toContactID: ToContactID[] = [];
    attachment: any[] = [];
}

export class ToContactID {
    ToContactID: string = ''
}

export class inboxMailDataType {
    FranchiseeID: string = '';
    MailOutBoxID: string = '';
    BranchName: string = '';
    Franchisee?: string = '';
    Address?: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
    Date: string = '';
    Subject: string = '';
    Attachments: AttachmentsDataType[] = [];
    file!: any[];
}
export class sentMailDataType {
    To: ToDataType = new ToDataType();
    sentFranchisee?: string = '';
    MailBoxID: string = '';
    Date: Date = new Date();
    Subject: string = '';
    Content: string = '';
    Attachments: AttachmentsDataType[] = [];
    file!: any[];
}
export class ToDataType {
    MailOutBoxID?: string = '';
    To?: string = '';
    FranchiseeID: string = '';
    BranchName: string = '';
    sentFranchisee?: string = '';
    Franchisee?: string = '';
    Address?: string = '';
    Add1?: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
    Subject?: string = '';
    Date?: Date = new Date();
    Attachments?: AttachmentsDataType[] = [];
    file!: any;
    Status: string = '';
}
export class trashMailDataType {
    MailBoxID: string = '';
    FranchiseeID: string = '';
    MailOutBoxID: string = '';
    BranchName: string = '';
    Franchisee?: string = '';
    Address?: string = '';
    Address1: string = '';
    Address2: string = '';
    Area: string = '';
    District: string = '';
    State: string = '';
    Country: string = '';
    Pincode: string = '';
    Date: string = '';
    Subject: string = '';
}

export class AttachmentsDataType {
    MailBoxID?: string = '';
    FileName: string = '';
    ContentType: string = '';
    ContentUrl: string = '';
}
export class composeMailToDataType {
    FranchiseeID: string = '';
    TenantBranchID: string = '';
    TenantBranchName: string = '';
    ContactID: string = '';
    ContactName: string = '';
    AddressTypeID: string = '';
    AddressType: string = '';
    Address1: string = '';
    Address2: string = '';
    Country: string = '';
    State: string = '';
    District: string = '';
    Area: string = '';
    Pincode: number = 0
}
export class attachmentDataType {
    ContentType: any;
    ContentUrl: any;
    FileName: any;
}
