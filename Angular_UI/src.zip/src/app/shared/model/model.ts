
export class rejectReasonType {
    franchiseeRequestID: any;
    reason: any;
}

export class walletReject {
    walletID: any;
    reason: any;
}

export class examIndentReject {
    examIndentID: string = '';
    reason: string = '';
}
export class fransPaymentRej {
    franchiseeRequestID: string = '';
    packageLogID: string = '';
    reason: string = '';
}
export class fransRenewalReject {
    packageLogID = '';
    reason = '';
}