export class Columns {
  Field = "";
  Title = "";
  Width!: number;
}



export class dateType{

  choose:any;
  start:any;
  end:any;

}
