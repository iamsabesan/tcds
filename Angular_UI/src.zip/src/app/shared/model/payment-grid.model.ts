import { BankLager } from "./payment";

export class PaymentInfo {
  PaymentModeID: string = "";
  PayModeType: string = "";
  PayModeValue: number = 0;
  Amount: number = 0;
  RoundOff = 0;
  // LedgerID: string = "";
  // LedgerName: string = "";
  // BankName?: string = "";
  // BankID?: string = "";
  TransactionNo: number = 0;
  //TransactionDate = new Date();
  TransactionDate: any;
  BankCommission = 0;
  FromLedger = new BankLager();
  ToLedger = new BankLager();
  DocumentID: string = '';
  // FromLedgerName =new BankLager()
  // FromLedgerID
  // ToLedgerID
  // ToLedgerName
}


export class PaymentData {
  paymenttype: string = '';
  Amount: number = 0;
}
