export class PayModeList{
    SlNo:number=0;
    PaymentModeID:string="";
    PaymentModeName:string="";
}

export const List: PayModeList[] = [
  {
    SlNo: 1,
    PaymentModeID: '1212',
    PaymentModeName: 'Cash'
  },
  {
    SlNo: 2,
    PaymentModeID: '1212',
    PaymentModeName: 'Bank Transfer'
  },
]

export class IPayMode {
  PayMode: string = '';
  PayModeID: string = '';
}

export class BankList {
  SlNo: number = 0;
  BankID: string = '';
  BankName: string = '';
}


export class LedgerList {
  CategoryID: string = "";
  LedgerID: string = "";
  LedgerName: string = "";
}
