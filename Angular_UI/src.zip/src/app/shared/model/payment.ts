export class payDrop {
    paymentType: any;
    paymentMode: any;
}
export class PaymentType {
    paymentMode: any;
    paymentType: any;
    amount: number = 0;
    bankName: string = "";
    transId: any;
    transDate: any;
    bankCommission: any;
}
export class PaymentInfo {
    PaymentModeID: string = "";
    PayModeType: string = "";
    PayModeValue: number = 0;
    Amount: number = 0;
    BankName: BankList = new BankList();
    TransactionNo: number = 0;
    TransactionDate = new Date();
    bankCommission: number = 0;
}
export class PaymentData {
    paymenttype: string = '';
    Amount: number = 0;
}
export class PayModeList {
    SlNo: number = 0;
    PaymodeID: string = '';
    Paymode: string = '';
}
export class BankList {
    SlNo: number = 0;
    BankID: string = '';
    BankName: string = '';
}

export class paymentInsertType {
    PaymodeID: any;
    Paymode: string = '';
}

export class BankLager {
    SlNo: number;
    LedgerID: string;
    LedgerName: string;
    ParentLedgerID: string;
    CategoryID: string;
    IsLedgerGroup: boolean;
    AllowCustomSubLedger: boolean;
}
export class CashLager {
    LedgerID = '';
    LedgerName = '';
    CategoryID = '';
    ParentLedgerID = '';
    AccountType = '';
    AccountNumber = '';
    AccountName = '';
}

export class PaymentPayVal {
    PaymentModeID: string = "";
    PayModeType: string = '';
    PayModeValue: number = 0;
    Amount: number = 0;
    RoundOff
    // ledgerID: string = "";
    // ledgerName: string = "";
    TransactionNo: string = "";
    TransactionDate: string = "";
    BankCommission = 0;
    FromLedgerName = '';
    FromLedgerID = '';
    ToLedgerID = '';
    ToLedgerName = '';
    DocumentID: string = '';
    // voucherID: string = "";
    // roundOff: number = 0;
    // bankCommision: number = 0;
}

export class ImageUploadResult {
    DocumentID = '';
    DocumentType = '';
    FileName = '';
    MIMEType = '';
    FileExtension = '';
    IsActivated: boolean;
}