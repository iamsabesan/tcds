

/* Student Address */
export class StudentAddressCreate {
    AddressType: string = "";
    Address1: string = "";
    Address2: string = "";
    Country: string = "";
    State: string = "";
    District: string = "";
    Area: string = "";
    Pincode: string = '';
    Taluk: string = '';
}


/* Occupation */
export class Occupation {
    Occupation: string = '';
    OccupationID: string = '';
}


/* Qualification */
export class Qualification {
    Qualification: string = '';
    QualificationID: string = '';
}