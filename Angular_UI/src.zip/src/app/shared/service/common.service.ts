import { Injectable } from '@angular/core';
import { IRequestType, SubscriptionInfo } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { Country, District, State, CreateDeliveryMode, EditFranchiseeCode } from '../model/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as saveAs from 'file-saver';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { Admin, Common, Fees, Franchisee, Master, Student } from '../ServiceUrl';
import { CustomNotification } from '../model/shared';
import { NotificationService } from '@progress/kendo-angular-notification';
import { CrazyKey } from 'src/core/helper';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class CommonService {

    public MlSubscriptionInfo: SubscriptionInfo = new SubscriptionInfo();

    constructor(private _srvHttp: HttpService,
        private _srvHttpDef: HttpClient,
        private _appConfig: AppConfigService, private _srvNotification: NotificationService) { }

    /* Get Country List */
    getLstCountry() {
        return this._srvHttp.get<Country>(Common.getCountry, { RequestType: IRequestType.Protected, });
    }

    /* Get State List */
    getLstState(CountryID: number) {
        return this._srvHttp.get<State>(`${Common.getState}${CountryID}`, { RequestType: IRequestType.Protected });
    }

    /* Get District List */
    getLstDistrict(StateID: number) {
        return this._srvHttp.get<District>(`${Common.getDistrict}${StateID}`, { RequestType: IRequestType.Protected });
    }

    /* Get Phone Code */
    getPhoneCode() {
        return this._srvHttp.get(Common.getPhoneCode, { RequestType: IRequestType.Anonymus, });
    }

    /* Get Employees */
    getEmployees() {
        return this._srvHttp.get(Admin.getEmployee, { RequestType: IRequestType.Protected })
    }

    /* Get All Branch */
    getBranchList() {
        return this._srvHttp.get(Admin.getBranches, { RequestType: IRequestType.Protected });
    }

    /* Get Course List */
    getCourseBasicInfo() {
        return this._srvHttp.get("/icloud-academic/v1/course/list/basicinfo", { RequestType: IRequestType.Protected });
    }

    /* Get Batch List */
    getBatchBasicInfo() {
        return this._srvHttp.get("/icloud-admission/v1/batch/basicinfo", { RequestType: IRequestType.Protected });
    }

    /* Get All Material List */
    getAllMateraialList() {
        return this._srvHttp.get(Common.getAllMaterial, { RequestType: IRequestType.Protected });
    }

    /* Get Material Type */
    getMaterialTypeList() {
        return this._srvHttp.get(Master.getMaterialType, { RequestType: IRequestType.Protected });
    }

    /* Create a Material List */
    postMaterialList(materialTypeID: string) {
        return this._srvHttp.get(`${Master.getMaterial}${materialTypeID}`, { RequestType: IRequestType.Protected })
    }

    //#region Delievery
    /* Get All Delievery Mode */
    getdeliveryMood() {
        return this._srvHttp.get("/icloud-inventory/v1/indent/deliverymode/list", { RequestType: IRequestType.Protected });
    }

    /* Create a New Delivery Mode */
    createDeliveryMode(data: CreateDeliveryMode) {
        return this._srvHttp.post("/icloud-inventory/v1/indent/create/deliverymode", data, { RequestType: IRequestType.Protected });
    }
    //#endregion

    /* Get All Student List */
    getStudentBasicDetail() {
        return this._srvHttp.get('/icloud-admission/v1/student/basicinfo/list/bybranch', { RequestType: IRequestType.Protected });
    }

    getStudentBasicData() {
        return this._srvHttp.get("/icloud-admission/v1/student/basicinfo/list", { RequestType: IRequestType.Protected });
    }

    getFranchiseeBasicInfo() {
        return this._srvHttp.get("/icloud-franchisee/v1/franchisee/list/basicinfo", { RequestType: IRequestType.Protected });
    }

    getBatchCourseIDList(courseID: any) {
        return this._srvHttp.get(`/icloud-admission/v1/batch/bycourseid?courseID=${courseID}`, { RequestType: IRequestType.Protected })
    }

    getCourseByIdList(courseID: any) {
        return this._srvHttp.get(`/icloud-academic/v1/course/getbyid?courseID=${courseID}`, { RequestType: IRequestType.Protected })
    }

    /* Get All Course List */
    getCourseBasicData() {
        return this._srvHttp.get("/icloud-academic/v1/course/info/list/byfranchisee", { RequestType: IRequestType.Protected })
    }

    /* Get Active, Inactive Batch List With Using the CourseID */
    getBatchByCourseById(CourseID: any) {
        return this._srvHttp.get("/icloud-admission/v1/batch/bycourseid", { params: { CourseID }, RequestType: IRequestType.Protected });
    }

    /* Get Active Batch With Using CourseID */
    getActiveBatchCourseID(CourseID: string) {
        return this._srvHttp.get(`/icloud-admission/v1/batch/active/list?courseID=${CourseID}`, { RequestType: IRequestType.Protected });
    }

    /* Get Batch Info With Using the BatchID */
    getCourseBatchIDList(courseBatchID: string) {
        return this._srvHttp.get("/icloud-admission/v1/batch/getbyid", { params: { courseBatchID }, RequestType: IRequestType.Protected })
    }

    getStudentListCourseBatchId(courseBatchID: any) {
        return this._srvHttp.get(`/icloud-admission/v1/student/batch/wise/list/${courseBatchID}`, { RequestType: IRequestType.Protected });
    }

    /* Get Image */
    getImage(ContentUrl: any) {
        return this._srvHttp.get(`/icloud-franchisee/v1/franchisee/${ContentUrl}`, { RequestType: IRequestType.Protected });
    }

    /* Get Whole Period Date */
    getWholePeriodDate(tenantBranchID: string) {
        return this._srvHttp.get(`/icloud-franchisee/v1/franchisee/wholeperiod?tenantBranchID=${tenantBranchID}`, { RequestType: IRequestType.Protected })
    }


    /* Image  */
    postImageUpload(EntityName: string, DocumentFile: any) {
        const formData = new FormData();
        formData.append(`EntityName`, EntityName);
        formData.append(`DocumentFile`, DocumentFile);
        return this._srvHttp.post('/insurance-contact-service/v1/contact/image/upload', formData, { RequestType: IRequestType.Protected })

    }

    /* Preview Image */
    previewImage(DocumentID: string) {
        if (DocumentID) {
            return this._srvHttp.get(`/document-service/document/base64/${DocumentID}`, { RequestType: IRequestType.Protected });
        }
        return null;
    }

    downloadAttachment(documentID: string, documentName: string) {
        const token = 'Bearer ' + this._srvHttp._getRolloutApiKey();
        const headers = new HttpHeaders().set('Authorization', token);
        const baseUrl = CrazyKey.decrypt(this._appConfig.appConfigDetails.apiBaseUrl, environment._privateKey);
        return this._srvHttpDef.get(baseUrl + `/document-service/document/download/${documentID}`, { headers, responseType: "blob" }).subscribe({
            next: (res: Blob) => {
                saveAs(res, documentName);
            }
        });
    }

    /* Get Occupation List */
    getOccupationData() {
        return this._srvHttp.get("/icloud-admission/v1/student/occupation/list", { RequestType: IRequestType.Protected });
    }

    /* Get Qualification List */
    getStudentQualification() {
        return this._srvHttp.get("/icloud-admission/v1/student/qualification/list", { RequestType: IRequestType.Protected });
    }

    getLstGender() {
        return this._srvHttp.get(Common.getGender, { RequestType: IRequestType.Anonymus });
    }

    getRelationShipLst() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/relationship/list', { RequestType: IRequestType.Protected });
    }

    /* Edit the Franchisee Code */
    EditFranchiseeID(data: EditFranchiseeCode) {
        return this._srvHttp.post('/icloud-franchisee/v1/franchisee/edit/franchisee/code', data, { RequestType: IRequestType.Protected });
    }

    /* Get the Inactive Franchisee List */
    getInactiveList() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/list/inactive', { RequestType: IRequestType.Protected })
    }

    getStudentStatus() {
        return this._srvHttp.get('/icloud-admission/v1/student/status/dropdown', { RequestType: IRequestType.Protected });
    }

    getAdminCurrentStock() {
        return this._srvHttp.get("/icloud-inventory/v1/indent/currentstock/list", { RequestType: IRequestType.Protected });
    }

    getCourierChargeAmount() {
        return this._srvHttp.get(Fees.getCourierCharge, { RequestType: IRequestType.Protected });
    }

    getIDCardChargeAmount() {
        return this._srvHttp.get(Fees.getIDCardCharges, { RequestType: IRequestType.Protected });
    }

    getCourseTypeList() {
        return this._srvHttp.get("/icloud-academic/v1/course/type/list", { RequestType: IRequestType.Protected });
    }

    getCourseListInCourseType(courseTypeID: string) {
        return this._srvHttp.get(`/icloud-academic/v1/course/info/list/byfranchisee?courseTypeID=${courseTypeID}`, { RequestType: IRequestType.Protected })
    }

    getFranchiseeDashboardDetail() {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/dashboard', { RequestType: IRequestType.Protected })
    }

    getReason() {
        return this._srvHttp.get(Student.getReason, { RequestType: IRequestType.Protected });
    }

    getTCDSCentre() {
        return this._srvHttp.get(Student.getTCDSCentre, { RequestType: IRequestType.Protected });
    }

    getPurpose() {
        return this._srvHttp.get(Student.getPurpose, { RequestType: IRequestType.Protected });
    }

    /* Log Out */
    logout() {
        return this._srvHttp.get(Common.logout, { RequestType: IRequestType.Protected });
    }

    /* Show Error Msg */
    errorMsg = (err: string) => new CustomNotification(this._srvNotification).ShowError(err);

    /* Later Hide the Error Msg */
    latererrorMsg = (err: string) => new CustomNotification(this._srvNotification).ShowErrorMsg(err);

    /* Show Error Msg */
    successMsg = (res: string) => new CustomNotification(this._srvNotification).ShowSuccess(res);


    getBase64ImageUrl(base64: string): string {
        if (!base64) return '';
        if (base64.startsWith('data:image')) {
            return base64;
        }
        const mimeType = this.getImageMimeType(base64);
        return `data:${mimeType};base64,${base64}`;
    }

    getImageMimeType(base64: string): string {
        const signatures: Record<string, string> = {
            iVBOR: 'image/png',
            '/9j/4': 'image/jpeg',
            R0lGO: 'image/gif',
            UklGR: 'image/webp',
            PHN2Z: 'image/svg+xml'
        };

        for (const prefix in signatures) {
            if (base64.startsWith(prefix)) {
                return signatures[prefix];
            }
        }

        return 'image/png';
    }

    getFranchiseeImageList(Id: string) {
        return this._srvHttp.get('/icloud-franchisee/v1/franchisee/baseurllist?franchiseeRequestID=' + Id, { RequestType: IRequestType.Protected })
    }

    updateFranchiseeDetail(data: any) {
        return this._srvHttp.post(Franchisee.updateFranchiseeDetail, data, { RequestType: IRequestType.Protected });
    }

    updateFranchiseeAddressDetail(data: any) {
        return this._srvHttp.post(Franchisee.updateFranchiseeAddressDetail, data, { RequestType: IRequestType.Protected });
    }

    concatAddress(data: any): string {
        return data.Area + ", " + data.Taluk + ", " + data.District + " - " + data.Pincode + ", " + data.State + ".";
    }
}