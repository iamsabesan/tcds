import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { saveAs } from '@progress/kendo-drawing/dist/npm/pdf';
import { BehaviorSubject } from 'rxjs';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { AppConfigService } from 'src/core/service/appconfig.service';
import { ToContactID, attachmentDataType, createMailDataType, sentMailDataType } from '../model/mailbox';
// import { valueShare } from '../model/mailbox';
import { saveAs } from 'file-saver';
import { Mail } from '../ServiceUrl';
import { CrazyKey } from 'src/core/helper';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MailboxService {

  public mailData = new BehaviorSubject<sentMailDataType[]>([])
  public AdminSentMailUrl = "/email/v1/email/send/list";
  public AdminDeleteMailUrl = "/email/v1/email/delete/list";
  public AdminMailSentListUrl = "/email/v1/email/send/list";
  public AdminMailRollBackUrl = "/email/v1/email/rollback";
  public franchiseeInboxMailListUrl = "/email/v1/email/inbox/list";
  public inboxMailDeleteUrl = "/email/v1/email/delete";
  public composeMailToDataUrl = "/email/v1/email/branch/wise/contact";
  public composeMailUrl = "/email/v1/email/create";
  public mailAttachmentUrl = "/email/v1/email/";

  constructor(private _srvHttp: HttpService,
    private appConfigService: AppConfigService,
    public httpDef: HttpClient) { }

  //#region Inbox
  getFranchiseeInboxMail() {
    return this._srvHttp.get(Mail.getInboxMail, { RequestType: IRequestType.Protected });
  }

  /* Get Compose Data */
  getComposeMailToData() {
    return this._srvHttp.get(Mail.getComposeToMail, { RequestType: IRequestType.Protected });
  }

  /* Update the "READ" Status */
  postInboxMailRead(mailOutBoxID: string) {
    return this._srvHttp.get(`${Mail.unreadMailRead}${mailOutBoxID}`, { RequestType: IRequestType.Protected })
  }

  /* Delete Mail */
  postInboxMailDelete(mailOutBoxID: string) {
    return this._srvHttp.get(`${Mail.deleteMail}${mailOutBoxID}`, { RequestType: IRequestType.Protected });
  }

  /* Create a New Mail */
  postComposeMail(data: createMailDataType) {
    const formData = new FormData();
    formData.append("subject", data.subject);
    formData.append("mailContent", data.mailContent);

    data.toContactID.forEach((e: ToContactID, index) => {
      formData.append(`toContactID[${index}][ToContactID]`, e.ToContactID);
    })
    if (data.attachment !== null) data.attachment.forEach((e: any) => formData.append("attachment", e))
    return this._srvHttp.post(Mail.createNewMail, formData, { RequestType: IRequestType.Protected });
  }
  //#endregion

  //#region Sent
  getAdminSentMail() {
    return this._srvHttp.get(Mail.getSentMail, { RequestType: IRequestType.Protected });
  }
  //#endregion

  //#region Trash
  getAdminDeleteMail() {
    return this._srvHttp.get(Mail.getTrashMail, { RequestType: IRequestType.Protected });
  }

  /* Restore Mail */
  postAdminRollBack(mailOutBoxID: string) {
    return this._srvHttp.get(`${Mail.restoreMail}${mailOutBoxID}`, { RequestType: IRequestType.Protected });
  }
  //#endregion



  // getAdminentMailList() {
  //   return this._srvHttp.get(this.AdminMailSentListUrl, { RequestType: IRequestType.Protected });
  // }



  getEmailAttachment(data: any) {
    return this._srvHttp.get(`${Mail.getEmailAttachment}${data}`, { RequestType: IRequestType.Protected })
  }

  downloadAttachment(data: attachmentDataType, documentID: string) {
    const token = 'Bearer ' + this._srvHttp._getRolloutApiKey();
    const headers = new HttpHeaders().set('Authorization', token);
    const baseUrl = CrazyKey.decrypt(this.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
    return this.httpDef.get(baseUrl + `${Mail.downloadAttachment}${documentID}`, { headers, responseType: "blob" }).subscribe({
      next: (res: Blob) => {
        saveAs(res, data.FileName);
      }
    });
  }
}
