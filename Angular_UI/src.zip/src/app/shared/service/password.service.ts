import { Injectable } from '@angular/core';
import { ChangePassword } from '../model/password-settings.model';
import { HttpService } from 'src/core/service';
import { IRequestType } from 'src/core/model';

@Injectable({
  providedIn: 'root'
})
export class PasswordService {

  ChangePasswordURL = "/user-service/v1/audit/user/change-password";
  constructor(public http: HttpService) { }

  ChangePassword(data: ChangePassword) {
    return this.http.post<ChangePassword>(this.ChangePasswordURL, data, { RequestType: IRequestType.Protected });
  }

}
