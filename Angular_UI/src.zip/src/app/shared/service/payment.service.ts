import { Injectable } from '@angular/core';

import { PayModeList } from '../model/payment.model';
import { HttpService } from 'src/core/service';
import { IRequestType } from 'src/core/model';

@Injectable({
  providedIn: 'root',
})
export class PaymentService {

  public SubscriptionPaymode: boolean = false;

  constructor(public http: HttpService) { }

  getAvailablePaymode(moduleName: string) {
    return this.http.get<PayModeList[]>('/compass/v1/Payment/GetPaymodeType', { params: { moduleName }, RequestType: IRequestType.Protected, });
  }

  GetLedgers() {
    return this.http.get(`/accounting-service/ledger/admin/cash`, { RequestType: IRequestType.Protected });
  }

  /* Old TCDS Payment */
  getPaymentType() {
    return this.http.get("/icloud-payment/v1/payment/list/paymode", { RequestType: IRequestType.Protected })
  }

  getBankDetail() {
    return this.http.get("/common/bank", { RequestType: IRequestType.Protected })
  }
  getBankLst() {
    return this.http.get("/accounting-service/branch/bank/ledger", { RequestType: IRequestType.Protected });
  }
  getAdminBankLst() {
    return this.http.get("/accounting-service/admin/bank/ledger", { RequestType: IRequestType.Protected });
  }

}
