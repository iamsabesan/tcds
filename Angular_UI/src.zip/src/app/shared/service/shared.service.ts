import { Injectable } from '@angular/core';
import { IRequestType } from 'src/core/model';
import { HttpService } from 'src/core/service';
import { examIndentReject, fransPaymentRej, fransRenewalReject, rejectReasonType, walletReject } from '../model/model';


@Injectable({
    providedIn: 'root'
})
export class SharedService {

    public rejectReasonURL = "/icloud-franchisee/v1/franchisee/reject";
    public walletRejectURL = "/icloud-payment/v1/wallet/reject";
    public paymentTypeURL = "/icloud-payment/v1/payment/list/paymode";
    public adminExamIndentReportReject = "/icloud-inventory/v1/indent/exam/reject";
    public bankDetailUrl = "/common/bank";
    public frnsRenewalReject = "/icloud-franchisee/v1/franchisee/renewal/reject";
    public fransPaymentReject = "/icloud-franchisee/v1/franchisee/reject/paid/request";
    constructor(public http_service: HttpService) { }
    getPaymentType() {
        return this.http_service.get(this.paymentTypeURL, { RequestType: IRequestType.Protected })
    }

    getBankDetail() {
        return this.http_service.get(this.bankDetailUrl, { RequestType: IRequestType.Protected })
    }

    postRejectReason(data: rejectReasonType) {
        return this.http_service.post(this.rejectReasonURL, data, { RequestType: IRequestType.Protected })
    }

    postWalletReject(data: walletReject) {
        return this.http_service.post('/icloud-payment/v1/wallet/reject', data, { RequestType: IRequestType.Protected })
    }

    postExamIndentReportReject(data: examIndentReject) {
        return this.http_service.post('/icloud-inventory/v1/indent/exam/reject', data, { RequestType: IRequestType.Protected })
    }

    postFranRewalReject(data: fransRenewalReject) {
        return this.http_service.post(this.frnsRenewalReject, data, { RequestType: IRequestType.Protected });
    }
    postFransPaymentReject(data: fransPaymentRej) {
        return this.http_service.post(this.fransPaymentReject, data, { RequestType: IRequestType.Protected });
    }

}