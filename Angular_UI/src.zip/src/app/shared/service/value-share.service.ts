import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';
// import { directStudentViewDataType, shareStudentValue } from 'src/app/admin/Student/models/student-profile';
import { directStudentViewDataType } from 'src/app/admin/Student/models/student-profile';

@Injectable({
    providedIn: 'root'
})
export class ValueShareService {
    public val: directStudentViewDataType = new directStudentViewDataType();
    // public directStudentData = new BehaviorSubject<shareStudentValue>({});

    constructor() {}
    ngOnInit() { }
}
