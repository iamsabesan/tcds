import { Component } from "@angular/core";

@Component({
  selector: 'share',
  templateUrl: './shared.component.html'

})
export class ShareComponent {
 
}
