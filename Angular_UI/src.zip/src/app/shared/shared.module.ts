
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Developer Import Kendo
import { LayoutModule } from "@progress/kendo-angular-layout";
import { IconsModule } from "@progress/kendo-angular-icons";
import { NavigationModule } from "@progress/kendo-angular-navigation";
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { PopupModule } from '@progress/kendo-angular-popup';
import { ShareComponent } from './shared.component';

const routes: Routes = [
  {
    path: '',
    component: ShareComponent,
  },

];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    ButtonsModule,
    LayoutModule,
    NavigationModule,
    IconsModule,
    PopupModule,
  ],
  declarations: [
    ShareComponent,
  ],
  providers: [],
})
export class ShareModule { }

