import { Injectable } from '@angular/core';
import { CanLoad, Route, Router, UrlSegment } from '@angular/router';
import { Observable } from 'rxjs';
import { CrazyKey, Guru } from '../helper';
import { KeyService } from '../service';
@Injectable()
export class AdminGuard implements CanLoad {

  private _privateKey  = '_privateKey';
  constructor(
    private _keyService: KeyService,
    private _router: Router
  ) { }
  canLoad(_route: Route, _segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    return new Promise((resolve) => {
      // Check Apikey is ready for use
      let isApiKeyReady = this._keyService.isApiKeyReady();

      // If Apikey is not ready redirect to auth route
      if (!isApiKeyReady) {
        this._router.navigate(
          ['/auth/sign-in'],
          {
            queryParams: { return: CrazyKey.encrypt(Guru.WindowUrl, this._privateKey) }
          }
        );
      }
      resolve(isApiKeyReady);
    });
  }
}
