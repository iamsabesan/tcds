export class AppConfig {
  PlatformID: string = '';
  apiBaseUrl: string = "";
  ServerUrl: string = "";
  Username: string = "";
  Password: string = "";
  GuestUser: string = "";
  GuestPassword: string = '';
  _p: string = ''; //RunTime Show or Hide in Inspect Tools
  ProjectName: string = "";
  TenantID: string = "";
  LoginURL: string = "";
}
