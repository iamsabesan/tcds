export interface ILoginResponse {
  BearerToken: string;
  ValidFrom: string;
  ValidTo: string;
  RefreshToken: string;
  RefreshTokenValidTo: string;
}

export interface IUser {
  PlatformID: string;
  UserID: string;
  UserName: string;
  AuthRole: string;
  TimeZone: string;
  DateFormat: string;
  TimeFormat: string;
  DateTimeFormat: string;
  TenantName: string;
  LanguageCulture: string;
  Currency: string;
  CurrencySymbol: string;
  CurrencyCode: string;
  TenantID: string;
  TenantBranchID: string;
  TenantBranchName: string;
  ActiveTheme: string;
}
export interface IHostuser {
  AuthRole: string;
  DateTimeFormat: string;
  LanguageCulture: string;
  TimeZone: string;
  UserID: string;
  UserName: string;
}
export interface IForgotPassword {
  UserName: string;
  MobileNumber: string;
  OrganizationSysid: string;
}
export interface IUpdatePassword {
  OldPassword: string;
  NewPassword: string;
  ContactRoleGuid: string;
}

