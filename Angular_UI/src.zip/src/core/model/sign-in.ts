export class BearerToken {
  BearerToken: string = '';
  ValidFrom: string = '';
  ValidTo: string = '';
  RefreshToken: string = '';
  RefreshTokenValidTo: string = ''
}

export class MappedMenuTree {
  id: number | undefined = 0;
  text: string = '';
  icon: string = '';
  path: string | null = '';
  parentId: number = 0;
  expanded: boolean = false;
  selected: boolean = false;
  type: string = '';
  isDefault: boolean = false;
  SortOrder: number = 0;
}

export class LoginModel {
  LoginName: string = '';
  Password: string = '';
  // PlatformID: string = '';
  TenantID: string = '';

}

/* Franchisee Subscription Information */
export class SubscriptionInfo {
  ApprovalStartDate: string = "";
  ApprovalEndDate: string = "";
  ApprovalStatus: string = "";
  SubscriptionStartDate: string = "";
  SubscriptionEndDate: string = "";
  SubscriptionStatus: string = "";
  PollingInterval: number = 1;
}

export class RenewBearerToken {
  RefreshToken: string = '';
}
