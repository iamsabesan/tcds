import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class AdminService {
    public checkGoBack = false;

}