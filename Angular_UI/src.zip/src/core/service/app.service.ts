import { Injectable } from '@angular/core';
import { CookieKey, CrazyKey, Guru } from 'src/core/helper';
import { ILoginResponse, IRequestType, IUser, IWebError, IWebResponse, MappedMenuTree, RenewBearerToken } from 'src/core/model';
import { environment } from 'src/environments/environment';
import jwt_decode from "jwt-decode";
import { CookieService } from 'ngx-cookie-service';
import { Observable, of, Subject } from 'rxjs';
import { HttpService } from './http.service';
import { KeyService } from './key.service';
import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';
import { directStudentViewDataType } from 'src/app/admin/Student/models/student-profile';
// import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';
export interface AppNotify {
  user: string;
  /** App data specifies the stored key,  default: `app` */
  menu: string;
}
@Injectable()
export class AppService {
  private _user!: IUser | undefined;
  private _mappedMenus!: MappedMenuTree[] | undefined;
  private notify$ = new Subject<AppNotify>();
  /* Student Details View */
  public val: directStudentViewDataType = new directStudentViewDataType();
  // Student Details ContactID
  public ContactID:string = '';
  public checkStudentView = false;
  public stdViewrouterURL = '';
  public checkGoBack = false;
  public FeesCheckGoBack = true;


  constructor(
    private _http: HttpService,
    private _srvCookie: CookieService,
    private _srvKey: KeyService,
  ) { }

  // get menus(): MappedMenuTree[] {
  get menus(): CustomMenu[] {
    try {
      const _menuCookieKey = this._srvKey.HashedCookieKey(CookieKey.Mappedmenu);
      const _menuCookieStr = localStorage.getItem(_menuCookieKey) || '';
      const temp = CrazyKey.decrypt(_menuCookieStr, environment._privateKey);
      if (!Guru.isValidString(_menuCookieStr)) {
        return [];
      }
      this._mappedMenus = JSON.parse(temp) as MappedMenuTree[];
      return this._mappedMenus;
    } catch (error) {
      return [];
    }
  }
  get user(): IUser | undefined {
    try {
      let bearerToken = this._srvCookie.get(CookieKey.Api);
      this._user = jwt_decode<IUser>(bearerToken);
      return this._user;
    } catch (error) {
      return undefined;
    }
  }
  get notify(): Observable<AppNotify> {
    return this.notify$.asObservable();
  }

  SignIn(Username: string, Passoword: string, RememberMe: boolean): Observable<IWebResponse<ILoginResponse> | IWebError> {
    return this._http.get<ILoginResponse>(`auth/login/${Username}/${Passoword}/${RememberMe}`, {
      RequestType: IRequestType.Guest
    });
  }
  GetRefreshToken(refToken: RenewBearerToken) {
    return this._http.post('/authorize/token/renew-for-tenant', refToken, { RequestType: IRequestType.Anonymus });
  }
  refreshAccessToken(): Observable<string> {
    // this is just simulating a delay to make it more realistic
    return of('foo').pipe();
  }
  SignOut(): void {
    this._srvKey.SignOut();
  }
}

