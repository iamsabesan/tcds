import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConfig } from '../model/appconfig.model';

@Injectable({
  providedIn: 'root'
})
export class AppConfigService {

  private appConfig: AppConfig = new AppConfig();
  constructor(private http: HttpClient) { }

  loadAppConfig() {
    return this.http.get<AppConfig>('../../assets/AppConfig.json').subscribe((res: AppConfig) => {
      this.appConfig = res;
    });
  }

  get appConfigDetails(): AppConfig {
    return this.appConfig;
  }

}
