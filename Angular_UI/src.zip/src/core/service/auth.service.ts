import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { CookieService } from "ngx-cookie-service";
import { Observable, Subscriber, Subscription } from "rxjs";
import { CookieKey, CrazyKey } from "../helper";
import { IUser, RenewBearerToken } from "../model";
import { AppService } from "./app.service";
import { KeyService } from "./key.service";
import { LoaderService } from "./loader.service";
import { HttpService } from "./http.service";
import { LocalString } from "src/app/shared/app-global";
import { environment } from "src/environments/environment";
type CallerRequest = {
  subscriber: Subscriber<any>;
  failedRequest: HttpRequest<any>;
};
@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  public _userClaims: IUser | undefined;

  private refreshInProgress = false;
  private requests: CallerRequest[] = [];
  private refreshJWTRequest: Subscription;
  private refreshTknAPIURL = '/authorize/token/renew-for-tenant'
  constructor(private _srvCookie: CookieService, private http: HttpClient, private _appService: AppService, private _keyService: KeyService,
    private _loaderService: LoaderService, private _httpService: HttpService) {
    this.refreshJWTRequest = Subscription.EMPTY;
    this.refreshInProgress = false;
  }


  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const observable = new Observable<HttpEvent<any>>((subscriber) => {
      const originalRequestSubscription = next.handle(request).subscribe((response) => {
        subscriber.next(response);

        /* Is Show or not in Loading Icon */
        if (!this._httpService.IsShowLoader) this._loaderService.hide();

      },
        (error) => {
          if (error.status === 401) {
            if (request.url.includes(this.refreshTknAPIURL)) {
              this.refreshJWTRequest.unsubscribe();
              this.requests = [];
              this._keyService.SignOut();
              this._loaderService.hide();
            }
            else {
              this.handleUnauthorizedError(subscriber, request);
            }
          } else {
            // notification!!!
            subscriber.error(error);
          }
        },
        () => {
          subscriber.complete();
        });
      return () => {
        originalRequestSubscription.unsubscribe();
      };
    });
    return observable;
  }
  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({ setHeaders: { 'Authorization': `Bearer ${token}` } });
  }
  private handleUnauthorizedError(subscriber: Subscriber<any>, request: HttpRequest<any>) {
    if (!this.refreshInProgress) {
      this.refreshInProgress = true;
      const temp: RenewBearerToken = {
        RefreshToken: this._srvCookie.get(CookieKey.Ref)
      }
      this.refreshJWTRequest = this._appService.GetRefreshToken(temp).subscribe({
        next: (response) => {
          this.refreshInProgress = false;
          this.repeatFailedRequests(response.Data.BearerToken);
          this._keyService.SyncApiKey(response.Data);
          this._appService.user;
          this._userClaims = this._appService.user;

          LocalString.DateTimeFormat = CrazyKey.decrypt(this._userClaims.DateTimeFormat, environment._privateKey);
          LocalString.DateFormat = CrazyKey.decrypt(this._userClaims.DateFormat, environment._privateKey);
          LocalString.TimeFormat = CrazyKey.decrypt(this._userClaims.TimeFormat, environment._privateKey);
          LocalString.CurrencySymbol = this._userClaims.CurrencySymbol;
          LocalString.Currency = CrazyKey.decrypt(this._userClaims.Currency, environment._privateKey);
          LocalString.CurrencyCode = CrazyKey.decrypt(this._userClaims.CurrencyCode, environment._privateKey);

        },
        error: () => {
          this.refreshInProgress = false;
          this._keyService.SignOut();
          this._loaderService.hide();
        }
      }
      )
    }
    if (!request.url.includes(this.refreshTknAPIURL)) {
      // avoid refresh requests while refreshInProgress
      // this solves a small bug after logout()
      this.requests.push({ subscriber, failedRequest: request });
    }
  }
  private repeatFailedRequests(authHeader: string) {
    this.requests.forEach((c) => {
      const requestWithNewToken = this.addToken(c.failedRequest, authHeader);
      this.repeatRequest(requestWithNewToken, c.subscriber);
    });
    this.refreshJWTRequest.unsubscribe();
    this.requests = [];
  }
  private repeatRequest(requestWithNewToken: HttpRequest<any>, subscriber: Subscriber<any>) {
    this.http.request(requestWithNewToken).subscribe((res) => {
      subscriber.next(res);
    },
      (err) => {
        if (err.status === 401) {
          this._keyService.SignOut();
        }
        subscriber.error(err);
      },
      () => {
        subscriber.complete();
      });
  }
}
