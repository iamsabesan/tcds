import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError, mergeMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { CrazyKey } from '../helper';
import { IHttpOption, IRequestServer, IRequestType, IWebError, IWebResponse } from '../model/http.model';
import { AppConfigService } from './appconfig.service';
import { KeyService } from './key.service';

@Injectable()
export class HttpService {
  // private _baseAddress = environment.apiGatewayUrl;
  private defOption: IHttpOption = {
    RequestType: IRequestType.Protected,
    RequestServer: IRequestServer.Api,
    DefaultLogout: true,
    LoadingScreen: true
  };

  public IsShowLoader: boolean = true;
  constructor(
    private _http: HttpClient,
    private _keyService: KeyService,
    private appConfigService: AppConfigService
  ) { }

  get<T>(
    url: string,
    usrOption?: IHttpOption
  ): Observable<IWebResponse<T> | IWebError> {

    // url = this.appConfigService.appConfigDetails.apiBaseUrl + url;

    const apiURL = CrazyKey.decrypt(this.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
    url = apiURL + url;

    // ! Merge Default & User Options
    usrOption = { ...this.defOption, ...usrOption };

    /* Is Show or not in Loading Icon */
    this.IsShowLoader = usrOption.LoadingScreen;

    // ! Init Http Request
    return this._http.get<IWebResponse<T>>(
      url,
      { headers: this._handleHeaders(usrOption), params: usrOption.params }
    ).pipe(
      // ! Success Respose
      mergeMap((value: IWebResponse<T>) => this._handleData<T>(value, usrOption?.RequestServer)),
      // ! Error Respose
      catchError((err: HttpErrorResponse) => this._handleData<T>(err, usrOption?.RequestServer))
    );
  }

  post<T>(
    url: string,
    body: any,
    usrOption?: IHttpOption
  ): Observable<IWebResponse<T> | IWebError> {
    // url = this.appConfigService.appConfigDetails.apiBaseUrl + url;

    const apiURL = CrazyKey.decrypt(this.appConfigService.appConfigDetails.apiBaseUrl, environment._privateKey);
    url = apiURL + url;

    // ! Merge Default & User Options
    usrOption = { ...this.defOption, ...usrOption };

    /* Is Show or not in Loading Icon */
    this.IsShowLoader = usrOption.LoadingScreen;

    // ! Init Http Request
    return this._http.post<IWebResponse<T>>(
      //this._handleUrl(url, usrOption),
      url,
      body,
      { headers: this._handleHeaders(usrOption), params: usrOption.params }
    ).pipe(
      // ! Success Respose
      mergeMap((value: IWebResponse<T>) => this._handleData<T>(value, usrOption?.RequestServer)),
      // ! Error Respose
      catchError((err: HttpErrorResponse) => this._handleData<T>(err, usrOption?.RequestServer))
    );
  }
  private _handleData<T>(event: IWebResponse<T> | HttpErrorResponse | any, options: IRequestServer | undefined)
    : Observable<IWebResponse<T> | IWebError> {
    return new Observable((subscribe) => {
      const webError = new IWebError(undefined);
      if (options === IRequestServer.Data) {
        subscribe.next({
          Code: event.code,
          Message: event.message,
          Data: event.data
        });
      } else if (event instanceof HttpErrorResponse) {
        if (!navigator.onLine) {
          webError.Code = 520;
          webError.Message = `You're offline! 😢, please check your internet connection`;
        } else if (event.status === 0) {
          webError.Code = 0;
          webError.Message = 'server is not reachable! 😢, please check your internet connection';
        } else {
          if (event.status === 401 || event.status === 403) {
            webError.Code = event.status;
            webError.Message = event.statusText;
          } else {
            webError.Code = event.error.Code;
            webError.Message = event.error.Message;
            webError.Data = event.error.Data;
          }
        }
        subscribe.error(webError);
      } else if (event instanceof IWebError) {
        // ? DEVELOPER EXCEPTION
        if (event && (event.Code >= 2000.02 && event.Code <= 2000.99)) {
          // ! DO YOUR STUFF (Ex: Show error message)
        }
        // ? API-DB-ERROR
        else if (event && (event.Code >= 3000.01 && event.Code <= 3000.99)) {
          // ! DO YOUR STUFF (Ex: Redirect to error page)
        }
        // ? API-AUTHORIZATION-ERROR
        else if (event && (event.Code >= 4000.01 && event.Code <= 6000.99)) {
          // ! DO YOUR STUFF (Ex: Logout current session immediatly)
          //this._srvKey.SignOut();
        }
        subscribe.error(event);
      }
      else {
        if (event.Code === 200.0 || event.Code === 201.0) {
          subscribe.next(event);
        }
        else {
          webError.Code = event.Code;
          webError.Message = event.Message;
          webError.Data = event.Data;
          if (webError.Message.toLocaleLowerCase() == "model validation error") {
            if (event.RefData.length !== 0) {
              event.RefData.filter((res: any) => {
                res.Description.filter((e: any) => {
                  if (e !== "") webError.Message = e
                });
              });
            }
          }
          subscribe.error(webError);
        }
      }
    });
  }

  private _handleHeaders(options: IHttpOption, AllowContentType = false): { [header: string]: string | string[] } {
    const defaultHeader: { [header: string]: string } = {};
    if (AllowContentType) {
      defaultHeader['Content-Type'] = 'application/json; charset=utf-8';
    }
    switch (options.RequestType) {
      /*   case IRequestType.Guest:
          defaultHeader[CookieKey.Auth] = this._getRolloutAuthKey();
          break; */
      case IRequestType.Protected:
        defaultHeader['Authorization'] = `Bearer ${this._getRolloutApiKey()}`;
        // defaultHeader['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJQbGF0Zm9ybUlEIjoiakRnZzhVX194UkFObVRzNDdXWE9oX19ISWtqNFBuYkFxUGhsMUh2c0VMenhGVlcwWEtfX0pTUHN2M3Y3cldxczBSMiIsIlVzZXJOYW1lIjoiS3VZYkFkQEBjSGt2bGI3YjlGTUlHX19nPT0iLCJMb2dpbk5hbWUiOiJudmMyOVRubzBocUlJMm5LMVdmR3ZlQkhjVnZ1RjZKaUFSRFJMOWt0RHVRPSIsIlVzZXJJRCI6Im5AQDlpV01MdjFMb2JLUGNPTUdjTlU3Z1NDT1AwTjRoVVRtaHhuWXFZSmpSZTd2X195QEB5SHNHYzl0SlcwY3M4engiLCJDb250YWN0SUQiOiJqcFZBazhITk9uUDZodk5GU2o0Vl9fWkIwR0hlcnJJcU1BU1pzZzlCbmEwRTYzMHdKeE4yOXNlNEU4UTRoZGQ4ZSIsIkNvbnRhY3ROYW1lIjoiS3VZYkFkQEBjSGt2bGI3YjlGTUlHX19nPT0iLCJBdXRoUm9sZSI6IkRqR1lCWVpOcm90ejlTWlh6WmlMSHc9PSIsIlRpbWVab25lIjoiTVhSNkxBMHBhNEJtNkZxbmdjOVdDRXU3UVFjazBXMlpONDRiekd3ZnZMdz0iLCJMYW5ndWFnZUN1bHR1cmUiOiJfX2JQaXk3TFE5QmdCNWVTQjFsNExlQT09IiwiRGF0ZVRpbWVGb3JtYXQiOiJLbk4yVWN2Sk5UM1JqVTFUelduNWplVVh6eVBWYkxIMHpldzg2TlhJamNrPSIsIkRhdGVGb3JtYXQiOiJvQkZIaFhlVjJwdTlENmp3QEBFbHdvZz09IiwiVGltZUZvcm1hdCI6IkhAQEFNekxPY213c3lLMWg4YXZLVlV3PT0iLCJDdXJyZW5jeSI6IjlkalpPbEhLTndnRlNISjlydUY4bWc9PSIsIkN1cnJlbmN5U3ltYm9sIjoi4oK5IiwiQ3VycmVuY3lDb2RlIjoib0FFV1dYcnVQSmlpdTY3Z3lJbzgwQT09IiwiVGVuYW50SUQiOiI3YjJ0WFRYTEw1ZzJCS3c0OUJKMEdkQWROek9VU1YwQk5INnE5dTRFOVgycDFJNUZ5eDFFdHg2a2tJVmg5SUliIiwiTG9nb1VSTCI6IklFNXBlbzZScnNsZzg4dWdNeTE4N1BPc01KQWNidWxrX19BQVlwb2JqS2hVPSIsIlRlbmFudE5hbWUiOiJ1SkRAQEJqdGdWX19EWXY4ckZUX19kNWhnPT0iLCJUZW5hbnRCcmFuY2hJRCI6Ilp1YjNoSkpkdks0OWpOQnZGTF9fVmgwVlVka1E5blhPU1Fha3hadlRhcFBMMzFTbFdzUDNYZUhla0hXdXhMam1ZIiwiVGVuYW50QnJhbmNoTmFtZSI6ImswNXlCMEdkeGY1aEJYWFFLa0ZsMUE9PSIsIkFjdGl2ZVRoZW1lIjoiY3VkU3FWQkJveFVpR3VDbFNOeG8xUT09IiwibmJmIjoxNzE5OTAyNjExLCJleHAiOjE3MTk5MDYyMTEsImlzcyI6IkJveCBvZiBUZWNoIFByaXZhdGUgTGltaXRlZCIsImF1ZCI6IkJveCBvZiBURUNIIn0.H_YOUeQn4elKrBI0LvvhJ_QAb_jA-rwk_aSzT3XFzr4';
        break;
    }
    return Object.assign(options.headers || {}, defaultHeader);
  }
  public _getRolloutApiKey(): string {
    const apiKey = this._keyService.ApiKey;
    return apiKey;
  }
}

