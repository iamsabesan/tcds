import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CookieKey, CrazyKey, Guru } from 'src/core/helper';
import { environment } from 'src/environments/environment';
import * as _ from 'lodash';
import { CookieService } from 'ngx-cookie-service';
import { BearerToken, MappedMenuTree } from '../model/sign-in';
import jwt_decode from "jwt-decode";
import { IUser} from '../model';
import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';
// import { CommonService } from 'src/app/shared/service/common.service';
// import { CustomNotification } from 'src/app/shared/model/shared';
// import { NotificationService } from '@progress/kendo-angular-notification';
// import { AuthService } from 'src/app/auth/components/service/auth.service';
// import { NotificationService } from '@progress/kendo-angular-notification';
// import { CustomNotification } from 'src/app/shared/model/shared';
// import { CustomMenu } from 'src/app/layouts/sidebar/menu.model';

@Injectable()
export class KeyService {

  constructor(private _srvCookie: CookieService, private router: Router, ) { }
  public isApiKeyReady(): boolean {
    let bearerToken = this._srvCookie.get(CookieKey.Api);
    return bearerToken ? true : false;
  }
  public isApiKeyRefTokenReady(): boolean {
    let refToken = this._srvCookie.get(CookieKey.Ref);
    return refToken ? true : false;
  }

  public get ApiKey(): string {
    try {
      const apiCookieArr = this._srvCookie.get(CookieKey.Api);
      if (!Guru.isValidObj(apiCookieArr)) {
        return '';
      }
      return apiCookieArr;
    } catch (error) {
      return '';
    }
  }

  public SyncApiKey(authData: BearerToken): void {
    const tokenExpiryDiffInMinutes = this.diff_minutes(new Date(authData.ValidFrom), new Date(authData.ValidTo));
    const refTokenExpiryDiffInMinutes = this.diff_minutes(new Date(), new Date(authData.RefreshTokenValidTo));
    const tokenExpiryDate = tokenExpiryDiffInMinutes / 1440;
    const refTokenExpiryDate = refTokenExpiryDiffInMinutes / 1440;

    this._srvCookie.set(CookieKey.Api, authData.BearerToken, tokenExpiryDate, '/', undefined, undefined, 'Lax');
    this._srvCookie.set(CookieKey.Ref, authData.RefreshToken, refTokenExpiryDate, '/', undefined, undefined, 'Lax');
    localStorage.setItem(this.HashedCookieKey(CookieKey.ActiveTheme), JSON.stringify(jwt_decode<IUser>(authData.BearerToken).ActiveTheme));
  }

  custom: CustomMenu = new CustomMenu();
  customList: CustomMenu[] = [];
  public SyncRoleMenu(roleMenu: MappedMenuTree[]) {
    this.customList = [];
    roleMenu.forEach((e) => {
      this.custom = new CustomMenu(); // Create a new instance for each iteration
      this.custom.id = e.id;
      this.custom.label = e.text;
      this.custom.link = e.path;
      this.custom.icon = e.icon;
      // this.custom.icon = "/assets/MenuIcons/accounting/banks.png";
      this.custom.parentId = e.parentId;
      this.custom.isDefault = e.isDefault;
      if (e.parentId == 0) {
        this.customList.push(this.custom);
      } else {
        const parentItem = this.findItemById(this.customList, e.parentId);
        if (parentItem) {
          if (!parentItem.subItems) {
            parentItem.subItems = [];
          }
          parentItem.subItems.push(this.custom);
        }
      }
    });
    // const Encoded = CrazyKey.encrypt(JSON.stringify(roleMenu), environment._privateKey);
    const Encoded = CrazyKey.encrypt(JSON.stringify(this.customList), environment._privateKey);
    const hashMenuKey = this.HashedCookieKey(CookieKey.Mappedmenu);
    localStorage.setItem(hashMenuKey, Encoded);
  }

  // Helper function to find an item by ID in a list or its subitems
  findItemById(list: CustomMenu[], id: number): CustomMenu | undefined {
    for (const item of list) {
      if (item.id === id) {
        return item;
      }
      if (item.subItems) {
        const foundItem = this.findItemById(item.subItems, id);
        if (foundItem) {
          return foundItem;
        }
      }
    }
    return undefined;
  }

  diff_minutes(dt2: Date, dt1: Date) {
    var diff = (dt2.getTime() - dt1.getTime()) / 1000;
    diff /= 60;
    return Math.abs(Math.round(diff));
  }

  public HashedCookieKey(str: string): string {
    return CrazyKey.hash(str, environment._privateKey);
  }

  public SignOut(): void {
    this._srvCookie.delete(CookieKey.Api, '/', undefined, undefined, 'Lax');
    this._srvCookie.delete(CookieKey.Ref, '/', undefined, undefined, 'Lax');
    localStorage.clear();
    this.router.navigate(['auth/sign-in']);
  }
}


