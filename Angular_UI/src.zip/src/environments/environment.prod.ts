export const environment = {
  production: true,
  _privateKey: '_privateKey',
  ShowLicenseInfo: true,
  AppTitle: 'Spider',
  AppLogo: '/assets/logo/app-logo.png',
  AppLogoSmall: '/assets/logo/app-logo-small.png'
};
