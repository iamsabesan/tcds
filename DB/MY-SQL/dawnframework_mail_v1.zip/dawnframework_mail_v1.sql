-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.11.19-MariaDB - MariaDB Server
-- Server OS:                    Win64
-- HeidiSQL Version:             12.20.0.7320
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for dawnframework_mail_v1
CREATE DATABASE IF NOT EXISTS `dawnframework_mail_v1` /*!40100 DEFAULT CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci */;
USE `dawnframework_mail_v1`;

-- Dumping structure for table dawnframework_mail_v1.client_configs
CREATE TABLE IF NOT EXISTS `client_configs` (
  `client_sysid` int(11) NOT NULL AUTO_INCREMENT,
  `mail_id` char(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `refresh_token` varchar(400) DEFAULT NULL,
  `provider_id` varchar(36) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`client_sysid`),
  UNIQUE KEY `client_guid` (`mail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.client_configs: ~4 rows (approximately)
INSERT INTO `client_configs` (`client_sysid`, `mail_id`, `user_id`, `username`, `password`, `client_id`, `client_secret`, `refresh_token`, `provider_id`, `created_at`, `updated_at`) VALUES
	(15, '3f93c1a1-5411-4d7d-b017-96283a3ab6cb', '884b914f-b4eb-40d0-97ce-b1ce4edcdd00', 'no-reply@mallnetindia.com', 'vhyg eikp glkz aule', NULL, NULL, NULL, 'f537d452-420b-4d52-8618-604b250660f6', '2024-08-28 10:29:14', '2024-08-28 04:59:14'),
	(16, 'a60037c8-441c-4deb-8092-f9fab9e75385', '468274dd-76f9-4ffd-8900-e9e1165a194e', 'info@mallnetindia.com', NULL, '715508943675-euuots73l91jc394b6637fil1ak53913.apps.googleusercontent.com', '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', '1//044bAz194rLC1CgYIARAAGAQSNwF-L9IrE19n9Ec_Zlcr5nei-k0hTxm5MlzwOGuLzlTpX_Tj-hmF0pQB98v63CoeSb0qhqb3SpY', 'b0123617-6548-4277-ae9e-96f5c4d4e891', '2024-10-03 13:05:21', '2024-10-03 07:35:21'),
	(17, 'be88c5dd-47ce-40a5-9ccb-21848d7d8e7c', '4b716df9-5c99-45c6-9635-821043bf69fa', 'fmd@mallnetindia.com', 'kpim qino kdqk jsfu', NULL, NULL, NULL, 'f537d452-420b-4d52-8618-604b250660f6', '2024-11-14 06:36:13', '2024-11-14 01:06:13'),
	(18, 'abd02590-6cb8-4d81-9ba5-8261567ebb7e', '87376a52-2394-4217-9de9-5af82e58799a', 'gm.ops@mniib.com', 'ulpi usjp obea zwyy', NULL, NULL, NULL, 'f537d452-420b-4d52-8618-604b250660f6', '2025-05-16 13:46:14', '2025-05-16 08:16:14');

-- Dumping structure for table dawnframework_mail_v1.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table dawnframework_mail_v1.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.migrations: ~6 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2022_11_12_063845_create_provider_config_table', 1),
	(6, '2022_11_12_071234_create_client_config_table', 2);

-- Dumping structure for table dawnframework_mail_v1.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.password_resets: ~0 rows (approximately)

-- Dumping structure for table dawnframework_mail_v1.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table dawnframework_mail_v1.provider_configs
CREATE TABLE IF NOT EXISTS `provider_configs` (
  `provider_guid` char(36) NOT NULL,
  `provider` varchar(11) NOT NULL,
  `host_name` varchar(21) NOT NULL,
  `port` int(11) NOT NULL,
  `smtp_secure` varchar(11) DEFAULT NULL,
  `smtp_auth` varchar(10) NOT NULL DEFAULT 'false',
  `auth_type` varchar(10) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`provider_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.provider_configs: ~2 rows (approximately)
INSERT INTO `provider_configs` (`provider_guid`, `provider`, `host_name`, `port`, `smtp_secure`, `smtp_auth`, `auth_type`, `created_at`, `updated_at`) VALUES
	('b0123617-6548-4277-ae9e-96f5c4d4e891', 'Google', 'smtp.gmail.com', 587, 'tls', 'true', 'XOAUTH2', '2022-11-12 11:35:30', '2022-11-12 06:05:30'),
	('f537d452-420b-4d52-8618-604b250660f6', 'Google', 'smtp.gmail.com', 587, 'tls', 'true', 'PASSWORD', '2022-11-12 11:36:28', '2022-11-12 06:06:28');

-- Dumping structure for table dawnframework_mail_v1.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` char(36) NOT NULL,
  `role` char(6) NOT NULL DEFAULT 'client',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table dawnframework_mail_v1.users: ~5 rows (approximately)
INSERT INTO `users` (`id`, `userid`, `role`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, '2751b31c-9d52-4237-9ecf-5b25bb88ac00', 'admin', 'bot', 'info@boxoftech.in', NULL, '$2a$04$pIvtrH3grVOX5TA8tCN48eQQfYIj5DqBh8vanxX1PtxlganuhxkAm', NULL, '2023-07-25 00:18:19', '2023-07-25 00:18:19'),
	(15, '884b914f-b4eb-40d0-97ce-b1ce4edcdd00', 'client', 'MallnetIndia', 'no-reply@mallnetindia.com', NULL, '$2y$10$xrmwaU.q2VIDE/t4X4pEleGlAy59eEjwA44YcYBG6TkfOG0zzdZe6', NULL, '2024-08-28 04:45:25', '2024-08-28 04:45:25'),
	(16, '468274dd-76f9-4ffd-8900-e9e1165a194e', 'client', 'MallnetIndia', 'info@mallnetindia.com', NULL, '$2y$10$S2yUzjn6psrxO5uapx81rOXgNmkQbacenED88zPX8i9Ih9ItZVilu', NULL, '2024-10-03 06:52:44', '2024-10-03 06:52:44'),
	(18, '4b716df9-5c99-45c6-9635-821043bf69fa', 'client', 'Mallnet', 'fmd@mallnetindia.com', NULL, '$2y$10$TvBDkuFhD8B2AtPA7Fttk.mn0E6qtWNRer2jtkivbj3tEhV1PJo2G', NULL, '2024-11-13 23:31:52', '2024-11-13 23:31:52'),
	(19, '87376a52-2394-4217-9de9-5af82e58799a', 'client', 'Mallnet', 'gm.ops@mniib.com', NULL, '$2y$10$cHM.8xsn3WadZuMfFA6XnuASM69CufujkOYgAkvLi1PP9/Sr0OVae', NULL, '2025-05-16 08:14:57', '2025-05-16 08:14:57');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
