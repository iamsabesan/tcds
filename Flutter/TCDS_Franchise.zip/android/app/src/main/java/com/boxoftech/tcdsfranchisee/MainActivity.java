package com.boxoftech.tcdsfranchisee;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;  // Import added here
import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

import java.io.OutputStream;
import java.io.IOException;

public class MainActivity extends FlutterActivity {
    private static final String CHANNEL = "download_helper";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("saveFileToDownloads")) {
                    String fileName = call.argument("fileName");
                    String mimeType = call.argument("mimeType");
                    byte[] bytes = call.argument("bytes");

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        saveFileToDownloads(fileName, mimeType, bytes, result);
                    } else {
                        result.error("UNSUPPORTED", "MediaStore API requires Android 10 or higher", null);
                    }
                } else if (call.method.equals("getSdkVersion")) {
                    int sdkVersion = getSdkVersion();
                    result.success(sdkVersion);
                } else {
                    result.notImplemented();
                }
            });
    }

    private int getSdkVersion() {
        return Build.VERSION.SDK_INT;
    }

    private void saveFileToDownloads(String fileName, String mimeType, byte[] bytes, MethodChannel.Result result) {
        ContentResolver resolver = getContentResolver();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        contentValues.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        contentValues.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        OutputStream outputStream = null;
        try {
            outputStream = resolver.openOutputStream(
                    resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            );

            if (outputStream != null) {
                outputStream.write(bytes);
                result.success(true);
            } else {
                result.success(false);
            }
        } catch (IOException e) {
            Log.e("MainActivity", "IOException during file save: " + e.getMessage());
            result.success(false);
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    Log.e("MainActivity", "Error closing stream: " + e.getMessage());
                }
            }
        }
    }
}
