

import 'package:get/get.dart';

import '../user_interface/registration_status/controller/registration_status_controller.dart';

class RegistrationStatusBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RegistrationStatusController>(() => RegistrationStatusController());
  }
}