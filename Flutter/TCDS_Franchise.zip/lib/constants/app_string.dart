class AppStrings {
  /*App Basic Information Start*/
  static const String appName = "TCDS Computer Education Center";
//   static const String baseUrl = "http://gateway.dawn.dt/"; // debug URL
//   static const String baseUrl = "http://192.168.1.10:8084/"; // debug URL
  static String baseUrl = "https://gateway.boxoftech.int.in/"; // release URL
  static const String gatewayUrl = "";
  // static const String databaseName = "ValueMount";
  static const String contentType = "content-type";
  static const String contentTypeValue = "application/json";
  static const String guestToken = "GuestToken";
  static const String guestRefreshToken = "GuestRefreshToken";
  static const String refreshTokenValue = "RefreshTokenValue";
  static const String success = 'success';
  static const String failure = 'failure';
  static const String accessToken = 'accessToken';
  static const String refreshToken = "refreshToken";
  static const String otpTransactionId = "otpTransactionId";
  static const String otpValidTime = "otpValidTime";
  static const String tenantName = 'tenantName';
  static const String profileName = 'profileName';
  static const String position = 'position';
  static const String contactID = 'contactID';
  static const String tenantBranchID = 'tenantBranchID';
  static const String bankAccountInfoID = 'BankAccountInfoID';
  static const String contactAddressId = 'contactAddressId';
  static const String contactCode = 'contactCode';
  static const String contactName = 'contactName';
  static const String nomineeID = 'NomineeID';
  static const String sharableLink = 'sharableLink';
  static const String franchiseeRequestID = 'franchiseeRequestID';
  static const String regPaymentStatus = 'regPaymentStatus';
  static const String userProfilePicture = 'userProfilePicture';
  static const String userName = 'userName';
  static const String userNumber = 'userNumber';
  static const String tenantLiveID = '98392E8C-A6FC-48D6-873D-5A6C7C514B94';
  static const String tenantLocalID = 'F4CBB9FC-7804-4046-98D1-2346C1676100';

  /*App Basic Information End*/

/*Other Variables Start*/
  static const String isLoggedIn = "isLoggedIn";
  static const String expire = "expire";
  static const String firstLogin = "firstLogIn";

  /*Other Variables End*/

  /* App API URLs Start */
  static const String refreshTokenUrl = "authorize/token/renew-for-tenant";
  static const String accountDeletion = "user-service/user/delete/account";
  static const String logInUrl = "identity-service/v1/login-by-tenant";
  static const String phoneCodeUrl = "common/phoneCode";
  static const String countryListUrl = "common/country";
  static const String getGenderTypes = "common/gender";
  static const String stateListUrl = "common/state/";
  static const String getBankName = "common/bank";
  static const String districtListUrl = "common/district/";
  static const String getDashboardData =
      "icloud-academic/v1/course/mobile/dashboard";
  static const String requestOtp =
      "icloud-franchisee/v1/franchisee/registration/otp/request";
  static const String verifyOTP = "icloud-franchisee/v1/franchisee/otp/verify";
  static const String getAccountType =
      "icloud-franchisee/v1/franchisee/account/type";
  static const String franchiseBank = "accounting-service/branch/bank/ledger";
  static const String adminBank = "accounting-service/admin/bank/ledger";
  static const String getStudentList =
      "icloud-admission/v1/student/mobile/list";
  static const String getDistrictLevelAwardsList =
      "icloud-franchisee/v1/franchisee/district-level/achievers";
  static const String getDistrictLevelFranchiseeList =
      "icloud-franchisee/v1/franchisee/district-level/rank";
  static const String getStateLevelFranchiseeList =
      "icloud-franchisee/v1/franchisee/state-level/rank";

  static const String getStateLevelAwardsList =
      "icloud-franchisee/v1/franchisee/state-level/achievers";
  static const String courseTypeUrl = "icloud-academic/v1/course/type/list";
  static const String studentListByBranch =
      "icloud-admission/v1/student/all/basicinfo/list/bybranch";
  static const String batchListByCourseId =
      "icloud-admission/v1/batch/bycourseid?courseID=";
  static const String courseBasicInfo =
      "icloud-academic/v1/course/info/list/byfranchisee";
  static const String levelUrl = "icloud-franchisee/v1/franchisee/level/status";
  static const String stockListUrl =
      "icloud-inventory/v1/indent/localstock/list";
  static const String hqStockListUrl =
      "icloud-inventory/v1/indent/currentstock/list";
  static const String materialIndentStatus =
      "icloud-admission/v1/student/status/dropdown";
  static const String getMaterialIndentTrackingUrl =
      "icloud-inventory/v1/indent/material/listbyfranchisee";
  static const String getCertificateIndentTrackingUrl =
      "icloud-admission/v1/student/certificate/marksheet/tracking?status=";
  static const String certificateReceive =
      "icloud-admission/v1/student/certificate/receive";
  static const String walletHistoryUrl = "icloud-payment/v1/wallet/history?";
  static const String courseDetailUrl =
      "icloud-academic/v1/course/list/byfranchisee?courseTypeID=";
  static const String feesBalanceList =
      "icloud-admission/v1/student/mbl/fees/balance?batchMappingID=";
  static const String studentPaymentHistory =
      "icloud-admission/v1/student/payment/history?batchMappingID=";
  static const String getProfileImage =
      "icloud-admission/v1/student/image?contactID=";
  static const String courseListByFranchisee =
      "icloud-academic/v1/course/info/list/byfranchisee";
  static const String getImageDetails = "icloud-franchisee/v1/franchisee/";
  static const String getTypeStatus =
      "icloud-franchisee/v1/franchisee/type/status";
  static const String registerFranchise =
      "icloud-franchisee/v1/franchisee/register";
  static const String otpResend =
      "icloud-franchisee/v1/franchisee/email/otp/resend";
  static const String getFranchiseeProfileImage =
      "icloud-franchisee/v1/franchisee/profile/info";
  static const String documentDownloadBase64 =
      "document-service/document/base64/";
  static const String paymodeUrl = "icloud-payment/v1/payment/list/paymode";
  static const String submitWalletTopup = "icloud-payment/v1/wallet/topup";
  static const String getReceivedMaterial =
      "icloud-inventory/v1/indent/material/received";
  static const String userData =
      "icloud-franchisee/v1/franchisee/requeststatus?franchiseeRequestID=";
  static const String cashLedgerUrl = "accounting-service/ledger/admin/cash";
  static const String studentPartPayment =
      "icloud-admission/v1/student/partpayment";

  static const String imageUpload =
      "insurance-contact-service/v1/contact/image/upload";
  static const String franchiseBanks =
      "icloud-franchisee/v1/franchisee/bank/list?franchiseeRequestID=";
  static const String franchiseRegistrationPayment =
      "icloud-franchisee/v1/franchisee/payment";
  static const String invoiceDownload =
      "icloud-inventory/v1/indent/invoice/download/new?branchMaterialIndentID=";
  static const String materialTypeList =
      "icloud-inventory/v1/material/type/list";
  static const String materialListByMaterialTypeId =
      "icloud-inventory/v1/material/list?materialTypeID=";
  static const String materialIndentSave =
      "icloud-inventory/v1/indent/material/new";
  static const String approvalRenewalUrl =
      "icloud-franchisee/v1/subscription/renewal/plan/detaillist";
  static const String renewalSubscriptionPaymentUrl =
      "icloud-franchisee/v1/franchisee/approval/renewal/payment";
  static const String dashboardTotalDetailUrl =
      "icloud-franchisee/v1/franchisee/dashboard";
  static const String franchiseCourseListUrl =
      "icloud-academic/v1/course/info/list/byfranchisee";
  static const String getFranchiseCourseBatchListUrl =
      "icloud-admission/v1/batch/active/list?courseID=";
  static const String getFranchiseStudentListByBatchUrl =
      "icloud-admission/v1/student/batch/wise/list/";
  static const String examIndentSave = "icloud-inventory/v1/indent/exam/create";
  static const String batchDataUrl =
      "icloud-admission/v1/batch/basicinfo/intented";
  static const String batchStudentListUrl =
      "icloud-admission/v1/student/mark/info?CourseBatchID=";
  static const String updateMarkUrl = "icloud-admission/v1/student/mark/update";
  static const String courierCharge =
      "icloud-franchisee/v1/franchisee/courier/charges";
  /*App Basic Information End*/
}
