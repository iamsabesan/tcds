class AssetPath {
  static const String phoneIcon = "assets/phone.png";
  static const String loginBackGround = "assets/logo_with_background.png";
  static const String profilePic = "assets/profile_picture.jpg";
  static const String userIcon = "assets/user.png";
  static const String userImage = "assets/user_image.png";
  static const String franchisee = "assets/Franchise.png";
  static const String addressLocation = "assets/Address_location.png";
  static const String mailLogin = "assets/mail_login.png";
  static const String gender = "assets/gender.png";
  static const String cameraIcon = "assets/camera_icon.png";
  static const String mobile = "assets/Mobile.png";
  static const String bank = "assets/Bank.png";
  static const String notes = "assets/Notes.png";
  static const String padLock = "assets/padlock.png";
  static const String inVisibleEyeIcon = "assets/invisible.png";
  static const String visibleEyeIcon = "assets/visible.png";
  static const String backArrow = "assets/back.png";
  static const String logo1 = "assets/tcds_logo1.png";
  static const String logo2 = "assets/tcds_logo2.png";
  static const String cloudDownload = "assets/cloud_download.png";
  static const String history = "assets/history.png";
  static const String rightArrow = "assets/right_arrow.png";
  static const String fileImage = "assets/file_image.png";
  static const String mailBlue = "assets/mail_blue.png";
  static const String yellowPhone = "assets/yellow_phone.png";
  static const String filterIcon = "assets/filter_icon.png";
  static const String uploadIcon = "assets/uploadIcon.png";
  static const String deleteIconWithBG =
      "assets/delete_icon_with_background.png";
  static const String pending = "assets/Pending.png";
  static const String rejected = "assets/Rejected.png";
  static const String approved = "assets/Approved.png";
  static const String addPhotoIcon = "assets/add-photo.png";
  static const String trackingIcon = "assets/tracking.png";
  static const String fileSearch = "assets/image-search 2.png";
  static const String indentIcon = "assets/indent_icon.png";
  static const String addIcon = "assets/add_frame.png";
  static const String plusIcon = "assets/plus_frame.png";

  // PopUp Icons
  static const String successfulIcon = "assets/check_icon.png";
  static const String informationIcon = "assets/information_icon.png";
  static const String questionMarkIcon = "assets/question_icon.png";

  //drawer icons
  static const String dashboard = "assets/Dashboard.png";
  static const String course = "assets/Course.png";
  static const String fees = "assets/Fees.png";
  static const String material = "assets/Material.png";
  static const String exam = "assets/Exam.png";
  static const String stock = "assets/Stocks.png";
  static const String student = "assets/Student.png";
  static const String award = "assets/Award.png";
  static const String rank = "assets/Rank.png";
  static const String renewal = "assets/renewal.png";
  static const String deleteAccount = "assets/DeleteAccount.png";
  static const String logout = "assets/Logout.png";

  //dashboard icons
  static const String courseDashboard = "assets/Course_dashboard.png";
  static const String feesDashboard = "assets/Fees_dashboard.png";
  static const String materialDashboard = "assets/Material_dashboard.png";
  static const String examDashboard = "assets/Exam_dashboard.png";
  static const String stocksDashboard = "assets/Stocks_dashboard.png";
  static const String studentsDashboard = "assets/Student_dashboard.png";
  static const String awardDashboard = "assets/Award_dashboard.png";
  static const String rankDashboard = "assets/Rank_dashboard.png";
  static const String enquiry = "assets/Enquiry.png";
  static const String wallet = "assets/wallet.png";
  static const String directRegistration = "assets/DirectRegistration.png";

  //global
  static const String registerNoLogo = "assets/logo_1.png";
  static const String eyeInvisible = "assets/invisible.png";
  static const String eveVisible = "assets/visible.png";
  static const String locationOrange = "assets/address_location.png";
  static const String defaultProfile = "assets/default_profile.png";
  static const String uploadProfile = "assets/upload_profile_pic.png";
  static const String cameraFrame = "assets/camera_frame.png";
  static const String calender = "assets/calender.png";
  static const String location = "assets/location.png";
  static const String mail = "assets/mail.png";
  static const String occupation = "assets/occupation.png";
  static const String owner = "assets/owner_logo.png";
  static const String person = "assets/person.png";
  static const String qualification = "assets/qualification.png";
  static const String qualificationHeading = "assets/qualification_heading.png";
  static const String centreDetails = "assets/centre_detail.png";
  static const String courses = "assets/courses.png";
  static const String backgroundLogo = "assets/logo_with_background.png";
  static const String delete = "assets/delete.png";
  static const String question = "assets/question_icon.png";
  static const String navigate = "assets/navigate.png";
  static const String leftArrow = "assets/left-arrow.png";
  static const String deleteBin = "assets/delete_bin.png";
  static const String company = "assets/company.png";
  static const String downloadInvoice = "assets/Download_invoice.png";
  static const String closeIcon = "assets/close_icon.png";
  static const String renewalWait = "assets/renewal_image.png";
  static const String approvalWallet = "assets/approval_wallet.png";

  // stocks
  static const String centreStock = "assets/centre_stock.png";
  static const String hqStock = "assets/hq_stock.png";
}
