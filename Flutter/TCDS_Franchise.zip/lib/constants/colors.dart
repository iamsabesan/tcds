import 'package:flutter/material.dart';

class AppColor {
  static const Color primaryColor = Color.fromRGBO(40, 110, 152, 1);
  static const Color secondaryColor = Color.fromRGBO(255, 113, 1, 1);
  static const Color primary2Color = Color.fromRGBO(40, 110, 152, 1);
  static const Color drawerSelectedColor = Color.fromRGBO(220, 242, 255, 1);
  static const Color skyBlue = Color.fromRGBO(141, 215, 252, 1);
  static const Color progressBarBlue = Color.fromRGBO(141, 215, 252, 1);
  static const Color progressBarPeach = Color.fromRGBO(255, 154, 154, 1);
  static const Color lightPeach = Color.fromRGBO(255, 154, 154, 1);
  static const Color lightBlue = Color.fromRGBO(247, 248, 252, 1);
  static const Color lightOrange = Color.fromRGBO(254, 224, 200, 1);
  static const Color lightOrange1 = Color.fromRGBO(255, 203, 172, 1);
  static const Color whiteColor = Color.fromRGBO(255, 255, 255, 1);
  static const Color yellowPhoneColor = Color.fromRGBO(232, 170, 38, 1);
  static const Color white2Color = Color.fromRGBO(245, 245, 245, 1);
  static const Color black2Color = Color.fromRGBO(104, 104, 104, 1);
  static const Color accordionColor = Color.fromRGBO(247, 248, 250, 1);
  static const Color darkGrey = Color.fromRGBO(119, 119, 119, 1);
  static const Color blackColor = Color.fromRGBO(70, 70, 70, 1);
  static const Color redColor = Colors.red;
  static const Color lightGrey = Color.fromRGBO(247, 248, 250, 1);
  static const Color violetColor = Color.fromRGBO(113, 108, 243, 1);
  static const Color greyColor = Color.fromRGBO(197, 197, 197, 1);
  static const Color lightWhite = Color.fromRGBO(218, 218, 218, 1);
  static const Color darkGreyColor = Color.fromRGBO(115, 115, 115, 1);
  static const Color blueColor = Color.fromRGBO(31, 160, 201, 1);
  static const Color grey2 = Color.fromARGB(255, 236, 236, 236);
  static const Color navigationIconColor = Color.fromRGBO(157, 178, 206, 1);
  static const Color cardColor = Color.fromARGB(1, 247, 248, 250);
  // static Color navigationIconColor = const Color(0x009db2ce);

  // static Color? orange = const Color.fromARGB(255, 138, 46, 1);
  static const Color orange = Colors.orange;
  static const Color orange1 = Color.fromRGBO(208, 121, 53, 1);
  static const Color green = Colors.green;
  static const Color green2 = Color.fromRGBO(232, 255, 239, 1);
  static const Color lightGreen = Color.fromRGBO(188, 216, 0, 1);
  static const Color red2 = Color.fromRGBO(255, 130, 128, 1);
  static const Color blue2 = Color.fromRGBO(239, 245, 255, 1);
  static const Color textHeaderClr = Color.fromRGBO(128, 128, 128, 1);

  static const Color shadowBorder = Color.fromRGBO(217, 217, 217, 1);
  static const Color grey3 = Color.fromRGBO(245, 245, 245, 1);
  static const Color grey = Color.fromRGBO(204, 204, 204, 1);
  static const Color black3Color = Color.fromRGBO(78, 78, 78, 1);
  static const Color titleColor = Color.fromRGBO(45, 54, 75, 1);
  static const Color subTitleColor = Color.fromRGBO(82, 90, 108, 1);
  static const Color deleteRed = Color.fromRGBO(243, 84, 84, 1);
  static const Color containerGrey = Color.fromRGBO(247, 248, 250, 1);
  static const Color pendingColor = Color.fromRGBO(249, 163, 63, 1);
  static const Color textBlackColor = Color.fromRGBO(74, 74, 74, 1);
  static const Color containerBorderGreyColor =
      Color.fromRGBO(227, 225, 225, 1);
  static const Color orangeShade = Color.fromRGBO(251, 226, 194, 1);

  static const Color pinkLight = Color.fromRGBO(255, 234, 245, 1);
  static const Color yellowLight = Color.fromRGBO(236, 243, 139, 1);
  static const Color sandalDark = Color.fromRGBO(221, 168, 83, 1);
  static const Color blueDark = Color.fromRGBO(24, 59, 78, 1);
  static const Color greenLight1 = Color.fromRGBO(228, 239, 231, 1);
  static const Color redShade100 = Color.fromRGBO(255, 205, 210, 1);
  static const Color redShade200 = Color.fromRGBO(239, 154, 154, 1);
  static const Color tealLight = Color.fromARGB(255, 232, 245, 244);
  static const Color pinkLight1 = Color.fromRGBO(252, 230, 230, 1);
  static const Color pinkDark = Color.fromRGBO(255, 198, 198, 1);
}
