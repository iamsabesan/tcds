import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/colors.dart';
import 'app_string.dart';

Future dialogueBox(
    {bool? isDismissible = true,
    bool? isWillPop = true,
    String? msg,
    bool? isClose}) {
  return Get.defaultDialog(
      titlePadding: EdgeInsets.zero,
      radius: 25.0,
      barrierDismissible: isDismissible!,
      title: "",
      onWillPop: () => Future.value(isWillPop!),
      content: errorBox(close: isClose ?? false, content: msg));
}

Widget bottomBtn({String? btnName, Color? btnColor}) {
  return Container(
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.r),
        color: btnColor ?? AppColor.primaryColor),
    padding: EdgeInsets.symmetric(vertical: 10.w, horizontal: 20.w),
    child: Text(
      btnName ?? "",
      style: const TextStyle(color: AppColor.whiteColor),
      textAlign: TextAlign.center,
    ),
  );
}

Widget errorBox({bool? close, String? content}) {
  return Padding(
    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 5.w),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                  margin: EdgeInsets.only(
                    left: 10.w,
                    right: 10.w,
                  ),
                  child: const Divider(
                    color: Colors.black,
                    thickness: 1.00,
                  )),
            ),
            const Text(
              AppStrings.appName,
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: AppColor.blackColor),
            ),
            Expanded(
              child: Container(
                margin: EdgeInsets.only(
                  left: 10.w,
                  right: 10.w,
                ),
                child: const Divider(
                  color: Colors.black,
                  thickness: 1.00,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: 20.w,
        ),
        Text(
          content ?? "",
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 20.w,
        ),
        GestureDetector(
            onTap: () {
              close! ? exit(0) : Get.back();
            },
            child: bottomBtn(btnName: "OK"))
      ],
    ),
  );
}
