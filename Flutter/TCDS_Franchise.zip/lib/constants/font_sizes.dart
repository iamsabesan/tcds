class AppFontSize {
  static double size1 = 20;
  static double size2 = 18;
  static double size3 = 16;
  static double size4 = 14;
  static double size5 = 12;
  static double size6 = 10;
}
