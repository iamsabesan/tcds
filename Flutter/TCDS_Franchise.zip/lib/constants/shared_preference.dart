import 'package:shared_preferences/shared_preferences.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:get/get.dart';
import 'package:tcds/routes/routes.dart';

class SharedPreference {
  static SharedPreferences? _prefs;

  static init() async {
    await SharedPreferences.getInstance().then((value) {
      _prefs = value;
    });
  }

  static putString(String key, String value) {
    if (_prefs != null) _prefs!.setString(key, value);
  }

  static String getString(String key) {
    return _prefs == null ? "" : _prefs!.getString(key) ?? "";
  }

  static putBool(String key, bool value) {
    if (_prefs != null) _prefs!.setBool(key, value);
  }

  static bool getBool(String key) {
    return _prefs == null ? false : _prefs!.getBool(key) ?? false;
  }

  static clearAll() async {
    await _prefs!.clear();
    SharedPreference.putBool(AppStrings.isLoggedIn, false);
    Get.offAllNamed(Routes.logInScreen);
  }
}
