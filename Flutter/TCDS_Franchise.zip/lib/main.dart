import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/routes/routes.dart';
import 'constants/shared_preference.dart';
import 'utils/helper_functions/in_app_update.dart';

import 'package:get/get.dart';

Future<void> main() async {
  // Ensure that Flutter is initialized.
  WidgetsFlutterBinding.ensureInitialized();

  // Force Hybrid Composition for Maps
  if (Platform.isAndroid) {
    // ignore: deprecated_member_use
    AndroidGoogleMapsFlutter.useAndroidViewSurface = true;
  }

  // Wait for Local Storage
  await initLocalStorage();
  runApp(const MyApp());
}

// Init Local Storage
initLocalStorage() async {
  await SharedPreference.init();
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    Get.config(defaultTransition: Transition.noTransition);

    return ScreenUtilInit(
      designSize: const Size(412, 892),
      child: GetMaterialApp(
        title: 'TCDS',
        debugShowCheckedModeBanner: false,
        initialRoute: ((SharedPreference.getBool(AppStrings.isLoggedIn)) &&
                (SharedPreference.getBool(AppStrings.expire)))
            ? Routes.renewal
            : SharedPreference.getBool(AppStrings.isLoggedIn)
                ? Routes.dashboardScreen
                : ((SharedPreference.getString(AppStrings.regPaymentStatus) ==
                            "regPaymentStatus") &&
                        (SharedPreference.getString(
                                AppStrings.franchiseeRequestID) !=
                            ""))
                    ? Routes.registrationPaymentStatus
                    : SharedPreference.getString(
                                AppStrings.franchiseeRequestID) ==
                            ""
                        ? Routes.logInScreen
                        : Routes.registrationStatus,
        // SharedPreference.getBool(AppStrings.isLoggedIn)
        //     ? Routes.logInScreen
        //     : Routes.logInScreen,
        theme: ThemeData(
          textSelectionTheme: const TextSelectionThemeData(
            selectionHandleColor: Colors.transparent,
          ),
          colorScheme: ColorScheme.fromSeed(
            seedColor: AppColor.primaryColor,
          ),
          dialogTheme:
              const DialogThemeData(backgroundColor: AppColor.whiteColor),
          // cardTheme: const CardTheme(
          //   color: AppColor.primaryColor,
          // )
        ),
        getPages: Routes.routesList,
        onInit: () {
          // Check for app updates after GetX is initialized
          WidgetsBinding.instance.addPostFrameCallback((_) {
            InAppUpdateHandler.checkForUpdate();
          });
        },
      ),
    );
  }
}
