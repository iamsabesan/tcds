import 'package:get/get.dart';
import 'package:tcds/user_interface/achievers_award/view/achievers_award_screen.dart';
import 'package:tcds/user_interface/course_details/view/course_details.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/dashboard/view/wallet_topup_screen.dart';
import 'package:tcds/user_interface/exam/view/exam_indent_main_screen.dart';
import 'package:tcds/user_interface/fees_collection/view/fees_collection_list_screen.dart';
import 'package:tcds/user_interface/franchise_ranking/view/franchise_ranking_screen.dart';
import 'package:tcds/user_interface/login/view/home_screen.dart';
import 'package:tcds/user_interface/login/view/login_screen.dart';
import 'package:tcds/user_interface/material/view/material_indent_main_screen.dart';
import 'package:tcds/user_interface/registration/view/franchisee_payment_screen.dart';
import 'package:tcds/user_interface/registration/view/get_details_page.dart';
import 'package:tcds/user_interface/students_list/view/students_list_screen.dart';

import '../bindings/registration_status_binding.dart';
import '../user_interface/material/view/stock.dart';
import '../user_interface/registration/view/registration_payment_status_page.dart';
import '../user_interface/registration_status/ui/registration_status_page.dart';
import '../user_interface/renewal/ui/approval_renewal_page.dart';
import '../user_interface/renewal/ui/renewal_detail_page.dart';
import '../user_interface/renewal/ui/subscription_renewal_page.dart';

class Routes {
  static const String logInScreen = '/login_screen';
  static const String homeScreen = '/home_screen';
  // static const String registrationScreen = '/registration_screen';
  static const String dashboardScreen = '/dashboard_screen';
  static const String studentsListScreen = '/student_list_screen';
  static const String franchiseePaymentScreen = '/franchisee_payment_screen';
  static const String franchiseeRankingScreen = '/franchisee_ranking_screen';
  // static const String walletHistoryScreen = '/wallet_history_screen';
  static const String walletTopUpScreen = '/wallet_topUp_screen';
  static const String stockListScreen = '/stock_list_screen';
  static const String courseDetailsScreen = '/course_details_screen';
  static const String materialIndent = '/material_indent';
  static const String examIndent = '/exam_indent';
  static const String feesCollectionList = '/fees_collection_list';
  static const String achieversAward = '/achieversAward';
  static const String getDetails = '/getDetail';
  static const String registrationStatus = '/registration_status';
  static const String registrationPaymentStatus =
      '/registration_payment_status';
  static const String approvalRenewal = '/approval_renewal';
  static const String subscriptionRenewal = '/subscription_renewal';
  static const String renewal = '/renewal';

  // profile screen routes
  static final routesList = [
    GetPage(
      name: logInScreen,
      page: () => const LoginScreen(),
    ),
    GetPage(
      name: homeScreen,
      page: () => const HomeScreen(),
    ),
    // GetPage(
    //   name: registrationScreen,
    //   page: () => const FranchiseeRegistrationScreen(),
    // ),
    GetPage(
      name: dashboardScreen,
      page: () => const DashboardScreen(),
    ),
    GetPage(
      name: studentsListScreen,
      page: () => const StudentListScreen(),
    ),
    GetPage(
      name: franchiseePaymentScreen,
      page: () => const FranchiseePaymentScreen(),
    ),
    GetPage(
      name: franchiseeRankingScreen,
      page: () => const FranchiseeRankingScreen(),
    ),
    /*  GetPage(
      name: walletHistoryScreen,
      page: () => const WalletHistoryScreen(),
    ), */
    GetPage(
      name: walletTopUpScreen,
      page: () => const WalletTopupScreen(),
    ),
    GetPage(
      name: stockListScreen,
      page: () => const AllStocks(),
    ),
    GetPage(
      name: courseDetailsScreen,
      page: () => const CourseDetailsScreen(),
    ),
    GetPage(
      name: materialIndent,
      page: () => const MaterialIndentMainScreen(),
    ),
    GetPage(
      name: examIndent,
      page: () => const ExamIndentMainScreen(),
    ),
    GetPage(
      name: achieversAward,
      page: () => const AchieversAwardScreen(),
    ),
    GetPage(
      name: getDetails,
      page: () => const GetDetailsPage(),
    ),
    GetPage(
      name: registrationStatus,
      page: () => const RegistrationStatusPage(),
      binding: RegistrationStatusBinding(),
    ),
    GetPage(
      name: feesCollectionList,
      page: () => const FeesCollectionListScreen(),
    ),
    GetPage(
      name: registrationPaymentStatus,
      page: () => const RegistrationPaymentStatusPage(),
    ),
    GetPage(
      name: approvalRenewal,
      page: () => const ApprovalRenewalPage(),
    ),
    GetPage(
      name: subscriptionRenewal,
      page: () => const SubscriptionRenewalPage(),
    ),
    GetPage(
      name: renewal,
      page: () => const RenewalDetailPage(),
    ),
  ];
}
