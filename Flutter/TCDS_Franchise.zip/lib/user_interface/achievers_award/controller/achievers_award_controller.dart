import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/achievers_award/model/level_achievers_award.dart';
import 'package:tcds/user_interface/achievers_award/model/image_response_model.dart';
import 'package:tcds/user_interface/achievers_award/model/level_response_model.dart';
import 'package:tcds/user_interface/registration/model/country_model.dart';
import 'package:tcds/user_interface/registration/model/district_model.dart';
import 'package:tcds/user_interface/registration/model/state_model.dart';

class AchieversAwardController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxBool achieversAwardScreenLoader = false.obs;
  RxList<AchieversAwardList> awardsList = <AchieversAwardList>[].obs;
  RxList<Map<String, List<AchieversAwardList>>> groupedAwardsList =
      <Map<String, List<AchieversAwardList>>>[].obs;
  RxList<String> levelList = <String>[].obs;
  RxList<CountryList> countryList = <CountryList>[].obs;
  RxList<DistrictList> districtList = <DistrictList>[].obs;
  RxList<StateList> stateList = <StateList>[].obs;
  RxList<ImageResponseModel> imageResponse = <ImageResponseModel>[].obs;

  Future<bool> getDistrictAwardsList({required dynamic body}) async {
    bool resultValue = false;
    achieversAwardScreenLoader.value = true;
    try {
      await engine
          .post(
              AppStrings.baseUrl + AppStrings.getDistrictLevelAwardsList, body)
          .then((value) async {
        // log(value.data.toString());
        AwardResponseModel model = AwardResponseModel.fromJson(value.data);
        awardsList.value = model.data;

        // after fetched awards let's loop through it for to get and store owner image as base64
        for (var i = 0; i < awardsList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: awardsList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            awardsList[i].base64Image = splitRawBase64;
          } else {
            awardsList[i].base64Image = null;
          }
        }

        // after fetched awards data completely let's filter it based on state or district
        groupedAwardsList.value = groupBy(awardsList,
                (award) => award.district.toLowerCase().removeAllWhitespace)
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedAwardsList.toString());

        achieversAwardScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> getStateAwardsList({required dynamic body}) async {
    bool resultValue = false;
    achieversAwardScreenLoader.value = true;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getStateLevelAwardsList, body)
          .then((value) async {
        // log(value.data.toString());
        AwardResponseModel model = AwardResponseModel.fromJson(value.data);
        awardsList.value = model.data;
        // after fetched centres let's loop through it for to get and store owner image as base64
        for (var i = 0; i < awardsList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: awardsList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            awardsList[i].base64Image = splitRawBase64;
          } else {
            awardsList[i].base64Image = null;
          }
        }

        // after fetched awards data completely let's filter it based on state or district
        groupedAwardsList.value = groupBy(awardsList,
                (award) => award.state.toLowerCase().removeAllWhitespace)
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedAwardsList.toString());

        achieversAwardScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Get image details
  Future<bool> getImageDetails({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageResponseModel model = ImageResponseModel.fromJson(value.data);
          imageResponse.clear();
          imageResponse.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }

  Future<bool> getLevel() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.levelUrl, protected: true)
          .then((value) {
        LevelResponseModel model = LevelResponseModel.fromJson(value.data);
        levelList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get country list
  Future<bool> getCountryList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.countryListUrl, protected: true)
          .then((value) {
        CountryResponseModel model = CountryResponseModel.fromJson(value.data);
        countryList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get state list
  Future<bool> getStateList({required String countryId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.stateListUrl + countryId,
              protected: true)
          .then((value) {
        StateResponseModel model = StateResponseModel.fromJson(value.data);
        stateList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get district list
  Future<bool> getDistrictList({required String stateId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.districtListUrl + stateId,
              protected: true)
          .then((value) {
        DistrictResponseModel model =
            DistrictResponseModel.fromJson(value.data);
        districtList.clear();
        districtList.value = model.data;
        // Add an extra custom option - ALL
        districtList.insert(
            0, DistrictList(districtId: -1, districtName: 'ALL'));
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
