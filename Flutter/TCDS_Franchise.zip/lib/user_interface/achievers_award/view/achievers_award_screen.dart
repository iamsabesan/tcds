import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/achievers_award/controller/achievers_award_controller.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/registration/model/country_model.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/pop_scope_handler.dart';
import 'package:tcds/utils/helper_widgets/searchable_dropdown.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import '../../registration/model/state_model.dart';
import '../model/level_achievers_award.dart';

class AchieversAwardScreen extends StatefulWidget {
  const AchieversAwardScreen({super.key});

  @override
  State<AchieversAwardScreen> createState() => _AchieversAwardScreenState();
}

class _AchieversAwardScreenState extends State<AchieversAwardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int _selectedIndex = 0;

  AchieversAwardController achieversAwardController =
      Get.put(AchieversAwardController());

  late String selectedYear;
  late List<String> years;

  TextEditingController stateCtrl = TextEditingController();
  TextEditingController stateTextCtrl = TextEditingController();
  TextEditingController districtTextCtrl = TextEditingController();
  TextEditingController districtCtrl = TextEditingController();
  TextEditingController levelCtrl = TextEditingController();
  TextEditingController levelTextCtrl = TextEditingController();
  TextEditingController typeCtrl = TextEditingController();
  TextEditingController typeTextCtrl = TextEditingController();

  RxBool showDistrict = false.obs;

  bool scrLoader = true;

  bool withBackArrow = false;

  @override
  void initState() {
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
    getApiCall();

    final currentYear = DateTime.now().year;
    years =
        List.generate(currentYear - 2023, (index) => (2024 + index).toString());
    selectedYear = currentYear.toString(); // Default to current year

    super.initState();
  }

  bool canPop = false;

  Future<void> getApiCall() async {
    await achieversAwardController.getCountryList();
    await achieversAwardController.getLevel();
    // get country id of india
    final CountryList india = achieversAwardController.countryList.firstWhere(
      (element) {
        return element.countryName.toLowerCase() == "india";
      },
      orElse: () => achieversAwardController.countryList.first,
    );
    // get state list based on country india
    await achieversAwardController.getStateList(
        countryId: india.countryId.toString());

    if (achieversAwardController.stateList.isNotEmpty) {
      // fetch state 'Tamil Nadu' to set as Default state
      final StateList defaultState =
          achieversAwardController.stateList.firstWhere(
        (element) {
          return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
              "tamilnadu";
        },
        orElse: () => achieversAwardController.stateList.first,
      );
      // Assign default value as TamilNadu to State
      stateTextCtrl.text = defaultState.stateProvinceName;
      stateCtrl.text = defaultState.stateProvinceId.toString();

      await achieversAwardController.getDistrictList(
          stateId: defaultState.stateProvinceId.toString());
      // Get awards list based on level
      if (achieversAwardController.levelList.isNotEmpty &&
          achieversAwardController.levelList.first.removeAllWhitespace
                  .toLowerCase() ==
              "districtlevel") {
        if (achieversAwardController.districtList.isNotEmpty) {
          achieversAwardController.getDistrictAwardsList(body: {
            "Year": selectedYear,
            "State": defaultState.stateProvinceName,
            "District": achieversAwardController.districtList[0].districtName,
          });
        }
      } else {
        achieversAwardController.getStateAwardsList(body: {
          "Year": selectedYear,
          "State": defaultState.stateProvinceName,
        });
      }
    }
    setState(() {
      scrLoader = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 7,
        ),
      ),
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        toolbarHeight: 70,
        titleSpacing: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Award',
          fontSize: AppFontSize.size2,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
        actions: [
          DropdownButton<String>(
            value: selectedYear,
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.black,
            ),
            dropdownColor: Colors.white,
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 18,
            ),
            underline: Container(),
            onChanged: (String? newValue) {
              setState(() {
                selectedYear = newValue!;
              });
            },
            items: years.map<DropdownMenuItem<String>>((String year) {
              return DropdownMenuItem<String>(
                value: year,
                child: Text(
                  year,
                  style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 18,
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 15.w),
        ],
      ),
      body: PopScopeHandler(
        child: scrLoader
            ? const Center(
                child: CircularProgressIndicator.adaptive(
                valueColor: AlwaysStoppedAnimation(AppColor.primaryColor),
              ))
            : Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 30.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              valueController: levelCtrl,
                              valueTextController: levelTextCtrl,
                              items: List.generate(
                                  achieversAwardController.levelList.length,
                                  (index) => SingleSelectDropDownModel(
                                      achieversAwardController.levelList[index],
                                      achieversAwardController.levelList[index]
                                          .toLowerCase())),
                              labelText: 'Select Level',
                              parentOnChangeCall: () async {
                                if (levelCtrl.text.removeAllWhitespace ==
                                    "districtlevel") {
                                  showDistrict.value = true;

                                  districtCtrl.clear();
                                  districtTextCtrl.clear();
                                  await achieversAwardController
                                      .getDistrictList(
                                    stateId: stateCtrl.text,
                                  );
                                  if (achieversAwardController
                                      .districtList.isNotEmpty) {
                                    await achieversAwardController
                                        .getDistrictAwardsList(body: {
                                      "Year": selectedYear,
                                      "State": stateTextCtrl
                                          .text.removeAllWhitespace,
                                      "District": achieversAwardController
                                          .districtList[0].districtName,
                                    });
                                  }
                                } else {
                                  showDistrict.value = false;

                                  achieversAwardController
                                      .getStateAwardsList(body: {
                                    "Year": selectedYear,
                                    "State":
                                        stateTextCtrl.text.removeAllWhitespace,
                                  });
                                }
                              },
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Expanded(
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              valueController: stateCtrl,
                              valueTextController: stateTextCtrl,
                              items: List.generate(
                                achieversAwardController.stateList.length,
                                (index) => SingleSelectDropDownModel(
                                  achieversAwardController
                                      .stateList[index].stateProvinceName,
                                  achieversAwardController
                                      .stateList[index].stateProvinceId
                                      .toString(),
                                ),
                              ),
                              labelText: 'Select State',
                              parentOnChangeCall: () async {
                                districtCtrl.clear();
                                districtTextCtrl.clear();
                                await achieversAwardController.getDistrictList(
                                  stateId: stateCtrl.text,
                                );

                                debugPrint("levelCtrl.text ${levelCtrl.text}");

                                if (levelCtrl.text.isNotEmpty &&
                                    levelCtrl.text.removeAllWhitespace ==
                                        "statelevel") {
                                  await achieversAwardController
                                      .getStateAwardsList(body: {
                                    "Year": selectedYear,
                                    "State":
                                        stateTextCtrl.text.removeAllWhitespace,
                                  });
                                } else {
                                  if (achieversAwardController
                                      .districtList.isNotEmpty) {
                                    await achieversAwardController
                                        .getDistrictAwardsList(body: {
                                      "Year": selectedYear,
                                      "State": stateTextCtrl
                                          .text.removeAllWhitespace,
                                      "District": achieversAwardController
                                          .districtList[0].districtName,
                                    });
                                  }
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20.w,
                    ),
                    Obx(() {
                      final districtList =
                          achieversAwardController.districtList;
                      return showDistrict.value
                          ? SearchableDropdown(
                              parentOnChangeCall: () async {
                                await achieversAwardController
                                    .getDistrictAwardsList(body: {
                                  "Year": selectedYear,
                                  "State":
                                      stateTextCtrl.text.removeAllWhitespace,
                                  "District":
                                      districtTextCtrl.text.removeAllWhitespace,
                                });
                              },
                              labelText: 'Select District',
                              valueController: districtCtrl,
                              valueTextController: districtTextCtrl,
                              items: List.generate(
                                districtList.length,
                                (index) => SingleSelectDropDownModel(
                                  districtList[index].districtName,
                                  districtList[index].districtId.toString(),
                                ),
                              ),
                            )
                          : const SizedBox.shrink();
                    }),
                    SizedBox(height: 20.w),
                    Obx(
                      () {
                        if (achieversAwardController
                            .achieversAwardScreenLoader.value) {
                          return const Center(
                            child: CircularProgressIndicator(
                              color: AppColor.primaryColor,
                            ),
                          );
                        } else if (achieversAwardController
                            .groupedAwardsList.isEmpty) {
                          return Center(
                            child: CustomText(
                              text: "No Data available",
                              color: AppColor.primaryColor,
                              fontSize: AppFontSize.size3,
                              fontWeight: FontWeight.w500,
                            ),
                          );
                        } else {
                          return Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                // heading
                                CustomText(
                                  text:
                                      "${showDistrict.value ? "DISTRICT" : "STATE"} LEVEL",
                                  color: AppColor.redColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: AppFontSize.size2.sp,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                CustomText(
                                  text:
                                      "[ TOP ${showDistrict.value ? "2" : "10"} ACHIEVERS ]",
                                  color: AppColor.green,
                                  fontWeight: FontWeight.bold,
                                  fontSize: AppFontSize.size3.sp,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                // total centres count
                                CustomText(
                                  text:
                                      "${stateTextCtrl.text.toUpperCase().removeAllWhitespace} (${showDistrict.value ? achieversAwardController.awardsList.first.stateCount : achieversAwardController.awardsList.first.totalCount})",
                                  fontSize: AppFontSize.size3.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.primaryColor,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Expanded(
                                  child: ListView.builder(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    scrollDirection: Axis.vertical,
                                    itemCount: achieversAwardController
                                        .groupedAwardsList
                                        .length, // Show the selected state or district only
                                    itemBuilder: (context, index) {
                                      // store current data map
                                      Map<String, List<AchieversAwardList>>
                                          temp = achieversAwardController
                                              .groupedAwardsList[index];
                                      String currentKey = temp.keys.first;
                                      List<AchieversAwardList> achieversList =
                                          temp[currentKey] ?? [];

                                      debugPrint("Current Key $currentKey");
                                      return Card(
                                        color: AppColor.lightBlue,
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 8.w,
                                          ),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: AppColor.greyColor,
                                              strokeAlign: 0.1,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(15.0),
                                          ),
                                          child: ExpansionTile(
                                            initiallyExpanded: true,
                                            dense: !showDistrict.value,
                                            trailing: showDistrict.value
                                                ? null
                                                : const SizedBox(),
                                            // disable expand button while in state mode / (Since we show only one for state)
                                            enabled: showDistrict.value,
                                            tilePadding: EdgeInsets.zero,
                                            childrenPadding: EdgeInsets.zero,
                                            minTileHeight:
                                                showDistrict.value ? null : 0,
                                            backgroundColor: AppColor.lightBlue,
                                            iconColor: showDistrict.value
                                                ? AppColor.primaryColor
                                                : AppColor.lightBlue,
                                            collapsedIconColor:
                                                AppColor.blackColor,
                                            /* leading: showDistrict.value
                                                ? CircleAvatar(
                                                    backgroundColor:
                                                        AppColor.lightOrange,
                                                    child: CustomText(
                                                      text:
                                                          "${achieversList.first.totalCount}",
                                                      color: AppColor.orange,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  )
                                                : null, */
                                            title: showDistrict.value
                                                ? Row(
                                                    children: [
                                                      Flexible(
                                                        child: CustomText(
                                                          text:
                                                              // levelCtrl.text
                                                              //             .removeAllWhitespace ==
                                                              //         "districtlevel"
                                                              //     ?
                                                              "${index + 1}. ${achieversList.first.district.toUpperCase()}"

                                                          // : achieversList
                                                          //     .first.state
                                                          ,
                                                          color: AppColor
                                                              .blackColor,
                                                          fontSize:
                                                              AppFontSize.size4,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                      CustomText(
                                                        text:
                                                            " (${achieversList.first.totalCount})",
                                                        color: AppColor
                                                            .primaryColor,
                                                        fontSize:
                                                            AppFontSize.size4,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ],
                                                  )
                                                : const SizedBox(),
                                            children: List.generate(
                                                achieversList.length,
                                                (rankIndex) {
                                              return Container(
                                                margin:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 5),
                                                child: Column(
                                                  children: [
                                                    ListTile(
                                                      minVerticalPadding: 0,
                                                      contentPadding:
                                                          const EdgeInsets.all(
                                                              5),

                                                      // tileColor: AppColor.whiteColor,
                                                      leading: Container(
                                                        height: 60.w,
                                                        width: 60.w,

                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        decoration:
                                                            const BoxDecoration(
                                                                shape: BoxShape
                                                                    .circle),
                                                        // show base64 image only when it's not empty
                                                        // else show default image
                                                        child: achieversList[
                                                                        rankIndex]
                                                                    .base64Image !=
                                                                null
                                                            ? Image.memory(
                                                                base64Decode(
                                                                    achieversList[
                                                                            rankIndex]
                                                                        .base64Image!),
                                                                fit: BoxFit
                                                                    .cover,
                                                                errorBuilder: (context,
                                                                        error,
                                                                        stackTrace) =>
                                                                    Image.asset(
                                                                  AssetPath
                                                                      .userIcon,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              )
                                                            : Image.asset(
                                                                AssetPath
                                                                    .userIcon,
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                      ),
                                                      title: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .contactName,
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .centreName,
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                          CustomText(
                                                            text: achieversList[
                                                                        rankIndex]
                                                                    .franchiseeCode
                                                                    .isEmpty
                                                                ? '-'
                                                                : achieversList[
                                                                        rankIndex]
                                                                    .franchiseeCode,
                                                            color: AppColor
                                                                .primary2Color,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                        ],
                                                      ),
                                                      subtitle: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .area,
                                                            color: AppColor
                                                                .blackColor,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                          const SizedBox(
                                                            height: 5,
                                                          ),
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .taluk,
                                                            color: AppColor
                                                                .blackColor,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                          if (!showDistrict
                                                              .value)
                                                            const SizedBox(
                                                              height: 5,
                                                            ),
                                                          if (!showDistrict
                                                              .value)
                                                            CustomText(
                                                              text: achieversList[
                                                                      rankIndex]
                                                                  .district,
                                                              color: AppColor
                                                                  .blackColor,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              maxLines: 2,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize:
                                                                  AppFontSize
                                                                      .size4.sp,
                                                            ),
                                                        ],
                                                      ),
                                                      trailing: Column(
                                                        children: [
                                                          CustomText(
                                                            text: (showDistrict
                                                                        .value &&
                                                                    districtTextCtrl
                                                                            .text
                                                                            .toLowerCase() ==
                                                                        'all')
                                                                ? achieversList[
                                                                        rankIndex]
                                                                    .districtRank
                                                                    .padLeft(
                                                                        2, "0")
                                                                : achieversList[
                                                                        rankIndex]
                                                                    .rank
                                                                    .toString()
                                                                    .padLeft(
                                                                        2, "0"),
                                                            color: Colors
                                                                .deepOrangeAccent,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size3.sp,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    if ((achieversList.length -
                                                            1) !=
                                                        rankIndex)
                                                      const Divider(
                                                        // Divider after the subtitle
                                                        color:
                                                            AppColor.greyColor,
                                                        thickness: 0.5,
                                                      ),
                                                  ],
                                                ),
                                              );
                                            }),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
// Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
// Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
