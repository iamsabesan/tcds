import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/course_details/model/course_detail_response_model.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';

class CourseDetailController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxList<CourseDetailList> courseDetailList = <CourseDetailList>[].obs;

  final RxString selectedCourseType = "".obs;
  final RxList<CourseDetailList> filteredCourseDetails =
      <CourseDetailList>[].obs;
  final RxList<CourseDetailList> courseDetailsList = <CourseDetailList>[].obs;

  Future<bool> getCourseDetailList({required String courseTypeId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseDetailUrl + courseTypeId)
          .then((value) {
        // log(jsonEncode(value.data));
        CourseDetailResponseModel model =
            CourseDetailResponseModel.fromJson(value.data);
        courseDetailList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
