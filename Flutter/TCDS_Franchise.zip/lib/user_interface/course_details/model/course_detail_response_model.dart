// To parse this JSON data, do
//
//     final courseDetailResponseModel = courseDetailResponseModelFromJson(jsonString);

import 'dart:convert';

CourseDetailResponseModel courseDetailResponseModelFromJson(String str) =>
    CourseDetailResponseModel.fromJson(json.decode(str));

String courseDetailResponseModelToJson(CourseDetailResponseModel data) =>
    json.encode(data.toJson());

class CourseDetailResponseModel {
  int code;
  String message;
  List<CourseDetailList> data;

  CourseDetailResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourseDetailResponseModel.fromJson(Map<String, dynamic> json) =>
      CourseDetailResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<CourseDetailList>.from(
            json["Data"].map((x) => CourseDetailList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CourseDetailList {
  String courseId;
  String shortName;
  String course;
  String courseType;
  String durationType;
  String certificatePrintName;
  String duration;
  double courseFees;
  double examFees;
  double admissionFees;
  double totalFees;
  int semester;
  String eligibility;
  List<SubjectMapping> subjectMapping;

  CourseDetailList({
    required this.courseId,
    required this.shortName,
    required this.course,
    required this.courseType,
    required this.duration,
    required this.courseFees,
    required this.durationType,
    required this.certificatePrintName,
    required this.examFees,
    required this.admissionFees,
    required this.totalFees,
    required this.eligibility,
    required this.subjectMapping,
    required this.semester,
  });

  factory CourseDetailList.fromJson(Map<String, dynamic> json) =>
      CourseDetailList(
        courseId: json["CourseID"],
        shortName: json["ShortName"],
        course: json["Course"],
        courseType: json["CourseType"],
        duration: json["Duration"],
        courseFees: json["CourseFees"],
        examFees: json["ExamFees"],
        admissionFees: json["AdmissionFees"],
        totalFees: json["TotalFees"],
        durationType: json["DurationType"],
        certificatePrintName: json["CertificatePrintName"],
        semester: json["Semester"],
        eligibility: json["Eligibility"],
        subjectMapping: List<SubjectMapping>.from(
            json["SubjectMapping"].map((x) => SubjectMapping.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CourseID": courseId,
        "ShortName": shortName,
        "Course": course,
        "CourseType": courseType,
        "Duration": duration,
        "CourseFees": courseFees,
        "ExamFees": examFees,
        "AdmissionFees": admissionFees,
        "TotalFees": totalFees,
        "Eligibility": eligibility,
        "SubjectMapping":
            List<dynamic>.from(subjectMapping.map((x) => x.toJson())),
      };
}

class SubjectMapping {
  String courseId;
  String subjectId;
  String subjectName;
  int semester;
  int theoryMarks;
  int practicalMarks;
  int totalMarks;

  SubjectMapping({
    required this.courseId,
    required this.subjectId,
    required this.subjectName,
    required this.semester,
    required this.theoryMarks,
    required this.practicalMarks,
    required this.totalMarks,
  });

  factory SubjectMapping.fromJson(Map<String, dynamic> json) => SubjectMapping(
        courseId: json["CourseID"],
        subjectId: json["SubjectID"],
        subjectName: json["SubjectName"],
        semester: json["Semester"],
        theoryMarks: json["TheoryMarks"],
        practicalMarks: json["PracticalMarks"],
        totalMarks: json["TotalMarks"],
      );

  Map<String, dynamic> toJson() => {
        "CourseID": courseId,
        "SubjectID": subjectId,
        "SubjectName": subjectName,
        "Semester": semester,
        "TheoryMarks": theoryMarks,
        "PracticalMarks": practicalMarks,
        "TotalMarks": totalMarks,
      };
}
