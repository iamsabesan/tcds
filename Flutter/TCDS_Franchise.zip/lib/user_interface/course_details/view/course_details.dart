import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/course_details/controller/course_detail_controller.dart';
import 'package:tcds/user_interface/course_details/view/respective_course_detail_screen.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/students_list/controller/student_list_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import '../../../utils/helper_widgets/custom_widget_three.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';

class CourseDetailsScreen extends StatefulWidget {
  const CourseDetailsScreen({super.key});

  @override
  State<CourseDetailsScreen> createState() => _CourseDetailsScreenState();
}

class _CourseDetailsScreenState extends State<CourseDetailsScreen> {
  final TextEditingController courseTypeCtrl = TextEditingController();
  final TextEditingController courseTypeTextCtrl = TextEditingController();
  final TextEditingController searchCtrl = TextEditingController();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final StudentListController studentListController =
      Get.put(StudentListController());
  final CourseDetailController courseDetailController =
      Get.put(CourseDetailController());

  int _selectedIndex = 8;

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 0);

  bool withBackArrow = false;

  @override
  void initState() {
    super.initState();
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
    studentListController.getCourseTypeList();
    searchCtrl.addListener(() {
      filterCourseDetails(searchCtrl.text);
    });
  }

/*  void filterCourseDetails(String query) {
    courseDetailController.courseDetailsList.value =
        studentListController.courseTypeList.where((course) => course.courseType.toLowerCase().contains(query.toLowerCase())).toList();
  }*/

  void filterCourseDetails(String query) {
    final matchingCourseTypes = studentListController.courseTypeList
        .where(
          (courseType) =>
              courseType.courseType.toLowerCase().contains(query.toLowerCase()),
        )
        .map((courseType) => courseType.courseTypeId)
        .toList();

    debugPrint("Matching Course Types: $matchingCourseTypes");

    courseDetailController.courseDetailsList.value =
        courseDetailController.courseDetailList
            .where(
              (course) => matchingCourseTypes
                  .contains(course.courseType), // Ensure you are matching IDs
            )
            .toList();

    debugPrint(
        "Filtered Course Details: ${courseDetailController.courseDetailsList}");
  }

  void filterCourses(String selectedCourseTypeId) {
    // Make sure the selectedCourseType is being passed correctly and matches the courseTypeId
    debugPrint("Selected Course Type: $selectedCourseTypeId");

    courseDetailController
        .getCourseDetailList(courseTypeId: selectedCourseTypeId)
        .then((value) {
      courseDetailController.courseDetailsList.value =
          courseDetailController.courseDetailList;
    });
  }

  @override
  void dispose() {
    super.dispose();
    courseDetailController.courseDetailsList.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(currentIndex: 1),
      ),
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        backgroundColor: AppColor.whiteColor,
        titleSpacing: 0.1,
        title: CustomText(
          text: "Course Details",
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
      ),
      body: PopScopeHandler(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.symmetric(vertical: 1.w, horizontal: 4.w),
              decoration: const BoxDecoration(
                shape: BoxShape.rectangle,
                color: AppColor.greyColor,
              ),
            ),
            SizedBox(height: 30.w),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.w),
              child: Obx(
                () => SingleSelectDropDown(
                  labelText: "Course Type",
                  valueController: courseTypeCtrl,
                  data: studentListController.courseTypeList
                      .map((course) => SingleSelectDropDownModel(
                            course.courseType,
                            course.courseTypeId.toString(),
                          ))
                      .toList(),
                  valueTextController: courseTypeTextCtrl,
                  parentOnChangeCall: (value) {
                    final selectedCourseTypeId = courseTypeCtrl.text;
                    filterCourses(selectedCourseTypeId);
                  },
                ),
              ),
            ),
            SizedBox(height: 20.w),
            Expanded(
              child: Obx(
                () {
                  if (courseDetailController.courseDetailsList.isEmpty) {
                    return Center(
                      child: CustomText(
                        text: 'No data available',
                        fontWeight: FontWeight.w500,
                        color: AppColor.primaryColor,
                        fontSize: AppFontSize.size3.sp,
                      ),
                    );
                  }
                  return ListView.builder(
                    itemCount: courseDetailController.courseDetailsList.length,
                    itemBuilder: (BuildContext context, int index) {
                      final data =
                          courseDetailController.courseDetailsList[index];
                      return Padding(
                        padding: EdgeInsets.symmetric(horizontal: 15.w),
                        child: CustomWidgetThree(
                          currencyFormat: currencyFormat,
                          withForwardArrow: true,
                          data: data,
                          onTap: () {
                            Get.to(
                                () => RespectiveCourseDetailScreen(
                                      currencyFormat: currencyFormat,
                                      data: data,
                                      // course: data.course,
                                      // duration: data.duration,
                                      // semester: data.semester.toString(),
                                      // courseType: data.courseType,
                                    ),
                                transition: Transition.rightToLeft,
                                duration: const Duration(milliseconds: 600));
                          },
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2;
          });
          Get.offAll(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF),
                shape: BoxShape.circle,
              ),
            ),
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
