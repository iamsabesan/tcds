import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/course_details/controller/course_detail_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/footer_accordian_widget.dart';
import '../model/course_detail_response_model.dart';

class RespectiveCourseDetailScreen extends StatefulWidget {
  final CourseDetailList data;
  final NumberFormat currencyFormat;

  const RespectiveCourseDetailScreen({
    super.key,
    required this.data,
    required this.currencyFormat,
  });

  @override
  State<RespectiveCourseDetailScreen> createState() =>
      _RespectiveCourseDetailScreenState();
}

class _RespectiveCourseDetailScreenState
    extends State<RespectiveCourseDetailScreen> {
  final CourseDetailController courseDetailController =
      Get.find<CourseDetailController>();

  // Subjects list holder
  Map<String, dynamic> semesterData = {};

  @override
  void initState() {
    // courseDetailController.getCourseDetailList(
    //     courseTypeId: widget.courseTypeId);
    super.initState();
    // filter data based on semester
    semestersList();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int _selectedIndex = 11;

  String getOrdinalSuffix(int number) {
    if (number % 10 == 1 && number % 100 != 11) {
      return '${number}st';
    } else if (number % 10 == 2 && number % 100 != 12) {
      return '${number}nd';
    } else if (number % 10 == 3 && number % 100 != 13) {
      return '${number}rd';
    } else {
      return '${number}th';
    }
  }

  // Filter subjects based on semester
  void semestersList() {
    semesterData = groupBy(
      widget.data.subjectMapping,
      (item) => item.semester.toString(),
    );
    debugPrint(semesterData.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        // toolbarHeight: 70,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        backgroundColor: AppColor.whiteColor,
        titleSpacing: 0.1,
        title: Padding(
          padding: EdgeInsets.only(right: 10.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: widget.data.course,
                      fontSize: AppFontSize.size3.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w500,
                    ),
                    SizedBox(
                      height: 2.w,
                    ),
                    CustomText(
                      text: widget.data.duration,
                      fontSize: AppFontSize.size4.sp,
                      color: AppColor.blackColor,
                    )
                  ],
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  SizedBox(
                    height: 10.w,
                  ),
                  CustomText(
                    text: '${widget.data.semester} semester',
                    fontSize: AppFontSize.size4.sp,
                    color: AppColor.blackColor,
                  )
                ],
              )
            ],
          ),
        ),
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_outlined,
          ),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: widget.data.subjectMapping.isEmpty
          ? const Center(
              child: CustomText(text: "No Data"),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: semesterData.length,
                    itemBuilder: (context, index) {
                      final String key = (index + 1).toString();
                      final List<SubjectMapping> value = semesterData[key];
                      return _buildSemesterList(
                        semester: '${getOrdinalSuffix((index + 1))} Semester',
                        subjects: value,
                        // subjects: value.map((subject) {
                        //   return {
                        //     "name": subject.subjectName,
                        //     "theory": subject.theoryMarks,
                        //     "practical": subject.practicalMarks,
                        //   };
                        // }).toList(),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15.w),
                  child: AccordionFooter(
                    totalAmount:
                        widget.currencyFormat.format(widget.data.totalFees),
                    // Replace with the actual total amount
                    expandedContent: Container(
                      // Adjust height of expanded content as needed
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 15),
                      decoration: const BoxDecoration(
                          color: AppColor.accordionColor,
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(16)),
                          boxShadow: []),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildFeeRow(
                              'Admission Fees', widget.data.admissionFees),
                          _buildFeeRow('Course Fees', widget.data.courseFees),
                          _buildFeeRow('Exam Fees', widget.data.examFees),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildSemesterList({
    required String semester,
    required List<SubjectMapping> subjects,
  }) {
    int totalTheory = subjects.fold(0, (sum, item) => sum + (item.theoryMarks));
    int totalPractical =
        subjects.fold(0, (sum, item) => sum + (item.practicalMarks));
    int totalMarks = totalTheory + totalPractical;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          text: "${widget.data.shortName} ($semester)",
          fontSize: AppFontSize.size4.sp,
          fontWeight: FontWeight.w600,
          color: AppColor.primaryColor,
        ),
        const SizedBox(
          height: 10,
        ),
        ...subjects.mapIndexed((index, subject) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: CustomText(
                        text: "${index + 1}. ${subject.subjectName}",
                        fontSize: AppFontSize.size5.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Flexible(
                      child: CustomText(
                        text:
                            '${subject.theoryMarks} (T)  ${subject.practicalMarks} (P) ',
                        fontSize: AppFontSize.size5.sp,
                        color: AppColor.black2Color,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    // CustomText(
                    //   text:
                    //       '${subject.theoryMarks + subject.practicalMarks} Marks',
                    //   fontSize: AppFontSize.size5.sp,
                    //   color: AppColor.orange,
                    //   fontWeight: FontWeight.w600,
                    // ),
                  ],
                ),
                // SizedBox(height: 5.w),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.end,
                //   children: [
                //     Flexible(
                //       child: CustomText(
                //         text:
                //             '${subject.theoryMarks} Theory • ${subject.practicalMarks} Practical',
                //         fontSize: AppFontSize.size5.sp,
                //         color: AppColor.black2Color,
                //         fontWeight: FontWeight.w500,
                //       ),
                //     ),
                //   ],
                // ),
                const Divider(
                  thickness: 0.5,
                ),
              ],
            ),
          );
        }),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const CustomText(
              text: 'Total Marks:',
              fontWeight: FontWeight.w500,
              color: AppColor.primaryColor,
            ),
            CustomText(
              text: '$totalMarks Marks',
              fontWeight: FontWeight.w600,
              color: AppColor.blackColor,
            ),
          ],
        ),
        SizedBox(height: 5.w),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CustomText(
              text: '$totalTheory Theory • $totalPractical Practical',
              fontSize: AppFontSize.size5.sp,
              color: AppColor.black2Color,
              fontWeight: FontWeight.w500,
            ),
          ],
        ),
        SizedBox(
          height: 40.w,
        )
      ],
    );
  }

  Widget _buildFeeRow(String label, double amount) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CustomText(
            text: label,
            fontSize: AppFontSize.size4.sp,
            color: AppColor.black2Color,
            fontWeight: FontWeight.w400,
          ),
          CustomText(
            text: widget.currencyFormat.format(amount),
            fontSize: AppFontSize.size4.sp,
            fontWeight: FontWeight.w500,
            color: AppColor.black2Color,
          ),
        ],
      ),
    );
  }
}
