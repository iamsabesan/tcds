// import 'dart:convert';
// import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/shared_preference.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/dashboard/model/admin_bank_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/cash_ledger_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/dashboard_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/franchisee_bank_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/franchisee_profile_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/image_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/paymode_list_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/profile_image_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/wallet_history_response_model.dart';
import '../../fees_collection/model/document_download.dart';
import '../../material/model/courier_rate_model.dart';
import '../../registration/model/bank_name_model.dart';
import '../../registration/model/document_upload.dart';
import '../../registration/model/franchise_bank_list_model.dart';
import '../model/dashboard_detail_model.dart';

class DashboardController extends GetxController {
  // engine instance
  HttpEngine engine = HttpEngine();

  RxBool dashboardLoader = false.obs;

  RxList<DashboardData> dashboardData = <DashboardData>[].obs;
  RxList<WalletHistoryData> walletHistoryData = <WalletHistoryData>[].obs;
  RxList<ProfileImageData> profileImageDataList = <ProfileImageData>[].obs;
  RxList<FranchiseeImg> franchiseeImageDataList = <FranchiseeImg>[].obs;
  RxList<FranchiseeBankList> franchiseeBankList = <FranchiseeBankList>[].obs;
  RxList<AdminBankList> adminBankList = <AdminBankList>[].obs;
  RxList<CashLedgerList> cashLedgerList = <CashLedgerList>[].obs;
  RxList<PaymodeList> payModeList = <PaymodeList>[].obs;
  RxList<FranchiseeProfileData> franchiseeProfileData =
      <FranchiseeProfileData>[].obs;
  RxList<ImageResponseModel> imageResponse = <ImageResponseModel>[].obs;
  RxList<String> profileImg = <String>[].obs;
  RxBool regStatusLoader = false.obs;
  RxList<DocumentDownload> latestDownloadedDocument = <DocumentDownload>[].obs;
  RxList<DocumentUploadData> latestUploadedDocument =
      <DocumentUploadData>[].obs;
  RxList<BankNameList> bankNameList = <BankNameList>[].obs;
  RxList<FranchiseBank> franchiseBankList = <FranchiseBank>[].obs;
  RxList<DashboardDetailData> dashboardTotalData = <DashboardDetailData>[].obs;

  // get ledger names & id
  String cashLedgerName = '';
  String cashLedgerId = '';
  String? walletToLegerID;
  String? walletToLegerName;
  String? walletFromLegerName;
  String? walletFromLegerID;

  // Courirer Amount
  RxInt courierAmt = 0.obs;

  // Get dashboard data
  Future<bool> getDashboardData() async {
    bool resultValue = false;
    // dashboardLoader.value = true;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getDashboardData,
              protected: true)
          .then((value) {
        DashboardResponseModel model =
            DashboardResponseModel.fromJson(value.data);
        // dashboardData.value = model.data;
        dashboardData.clear();
        dashboardData.add(model.data);
        resultValue = true;
        // dashboardLoader.value = false;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get Franchise BankName
  Future<bool> getFranchiseeBankName() async {
    bool resultValue = false;
    List<FranchiseeBankList> franchiseBankBackendList = [];
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.franchiseBank, protected: true)
          .then((value) {
        debugPrint(value.toString());
        FranchiseeBankResponseModel model =
            FranchiseeBankResponseModel.fromJson(value.data);
        for (int i = 0; i < model.data.length; i++) {
          if (model.data[i].ledgerName.toLowerCase().removeAllWhitespace !=
              "walletbank") {
            franchiseBankBackendList.add(model.data[i]);
          } else {
            walletFromLegerName = model.data[i].ledgerName;
            walletFromLegerID = model.data[i].ledgerId;
          }
        }
        franchiseeBankList.value = franchiseBankBackendList;
        resultValue = true;
      });
    } catch (e) {
      walletFromLegerName = null;
      walletFromLegerID = null;
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // get Admin BankName
  Future<bool> getAdminBankName() async {
    bool resultValue = false;
    List<AdminBankList> adminBankBankEndList = [];
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.adminBank, protected: true)
          .then((value) {
        debugPrint(value.toString());
        AdminBankResponseModel model =
            AdminBankResponseModel.fromJson(value.data);
        for (int i = 0; i < model.data.length; i++) {
          if (model.data[i].ledgerName.toLowerCase().removeAllWhitespace !=
              "walletbank") {
            adminBankBankEndList.add(model.data[i]);
          } else {
            walletToLegerID = model.data[i].ledgerId;
            walletToLegerName = model.data[i].ledgerName;
          }
        }
        adminBankList.value = adminBankBankEndList;

        resultValue = true;
      });
    } catch (e) {
      walletToLegerID = null;
      walletToLegerName = null;
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // get wallet history details
  Future<bool> getWalletHistory(
      {required String tenantBranchId,
      required String fromDate,
      required String toDate}) async {
    bool resultValue = false;
    try {
      await engine
          .get(
              '${AppStrings.baseUrl}${AppStrings.walletHistoryUrl}tenantBranchID=$tenantBranchId&fromDate=$fromDate&toDate=$toDate')
          .then((value) {
        debugPrint(value.toString());
        WalletHistoryResponseModel model =
            WalletHistoryResponseModel.fromJson(value.data);
        walletHistoryData.clear();
        walletHistoryData.add(model.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Get Profile picture
  Future<bool> getProfilePictureWithContactId(
      {required String contactID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getProfileImage + contactID,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        ProfileImageResponseModel model =
            ProfileImageResponseModel.fromJson(value.data);
        profileImageDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // Get image details
  Future<bool> getOwnerImage({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageResponseModel model = ImageResponseModel.fromJson(value.data);
          imageResponse.clear();
          imageResponse.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }

  // Get Franchisee profile picture
  Future<bool> getFranchiseeProfilePicture() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getFranchiseeProfileImage,
              protected: true)
          .then((value) async {
        // log(jsonEncode(value.data));
        FranchiseeProfileResponseModel model =
            FranchiseeProfileResponseModel.fromJson(value.data);
        franchiseeProfileData.clear();
        franchiseeProfileData.add(model.data);
        if (model.data.franchiseeImgs.isNotEmpty) {
          for (var i in model.data.franchiseeImgs) {
            if (i.documentName.toLowerCase().removeAllWhitespace ==
                "ownerimage") {
              bool fetchedOwnerImg = await getOwnerImage(imgID: i.contentUrl);
              if (fetchedOwnerImg && imageResponse.isNotEmpty) {
                String splitRawBase64 = imageResponse[0].data.split(",")[1];
                profileImg.clear();
                profileImg.add(splitRawBase64);
                SharedPreference.putString(
                    AppStrings.userProfilePicture, splitRawBase64);
                SharedPreference.putString(
                    AppStrings.userName, franchiseeProfileData[0].contactName);
                SharedPreference.putString(
                    AppStrings.userNumber, franchiseeProfileData[0].phone);
              } else {
                profileImg.clear();
              }
            }
          }
        }

        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get paymode
  Future<bool> getPayMode() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.paymodeUrl, protected: true)
          .then((value) {
        debugPrint(value.toString());
        PaymodeListResponseModel model =
            PaymodeListResponseModel.fromJson(value.data);
        payModeList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> submitWalletTop({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.submitWalletTopup, body,
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }

  Future<bool> saveMaterialIndent({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.materialIndentSave, body,
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }

  Future<bool> saveExamIndentIndent({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.examIndentSave, body,
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }

  Future<bool> fetchCourierCharge() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courierCharge, protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        CourierRateModel model = CourierRateModel.fromJson(value.data);
        courierAmt.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint("@fetchCourierCharge $e");
      resultValue = false;
    }

    return resultValue;
  }

  Future<bool> saveStudentPartPayment({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.studentPartPayment, body,
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }

  // get Cash Ledger
  Future<bool> getCashLedger() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.cashLedgerUrl, protected: true)
          .then((value) {
        debugPrint(value.toString());
        CashLedgerResponseModel model =
            CashLedgerResponseModel.fromJson(value.data);

        for (int i = 0; i < model.data.length; i++) {
          if (model.data[i].ledgerName.toLowerCase().removeAllWhitespace ==
              "undepositedcash") {
            // cashLedgerList.clear();
            // cashLedgerList.add(model.data[i]);
            cashLedgerName = model.data[i].ledgerName;
            cashLedgerId = model.data[i].ledgerId;
            break;
          }
        }

        cashLedgerList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // upload attachments
  Future<bool> updateAttachments({
    required dynamic formData,
  }) async {
    bool resultValue = false;
    debugPrint(formData.runtimeType.toString());
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.imageUpload, formData,
              custom: "multipart/form-data", protected: true)
          .then((value) {
        debugPrint('Attachment Updated Successfully');
        DocumentUploadResponseModel model =
            DocumentUploadResponseModel.fromJson(value.data);
        latestUploadedDocument.clear();
        latestUploadedDocument.add(model.data);

        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // document download
  Future<bool> documentDownload({required String documentID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(
              AppStrings.baseUrl +
                  AppStrings.documentDownloadBase64 +
                  documentID,
              protected: true)
          .then((value) {
        DocumentDownloadResponseModel model =
            DocumentDownloadResponseModel.fromJson(value.data);
        latestDownloadedDocument.clear();
        latestDownloadedDocument.add(model.data);
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      debugPrint("Func (documentDownload)=> $e");
    }

    return resultValue;
  }

// get BankName
  Future<bool> getBankName() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getBankName, protected: true)
          .then((value) {
        debugPrint(value.toString());
        BankNameResponseModel model =
            BankNameResponseModel.fromJson(value.data);
        bankNameList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

// get Admin BankName
  Future<bool> getSenderBankList({required String franchiseRequestId}) async {
    bool resultValue = false;
    List<FranchiseBank> receivedfranchiseBankList = [];
    try {
      await engine
          .get(
              AppStrings.baseUrl +
                  AppStrings.franchiseBanks +
                  franchiseRequestId,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        FranchiseBankListModel model =
            FranchiseBankListModel.fromJson(value.data);
        for (int i = 0; i < model.data.length; i++) {
          if (model.data[i].bank.toLowerCase().removeAllWhitespace !=
              "walletbank") {
            receivedfranchiseBankList.add(model.data[i]);
          }
        }
        franchiseBankList.value = receivedfranchiseBankList;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> registrationPayment({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.franchiseRegistrationPayment,
              body,
              protected: true)
          .then((value) {
        // WalletTopupResponseModel model =
        //     WalletTopupResponseModel.fromJson(value.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }

  Future<bool> getDashboardTotalDetails() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.dashboardTotalDetailUrl,
              protected: true)
          .then((value) async {
        debugPrint(value.toString());
        DashboardDetailModel model = DashboardDetailModel.fromJson(value.data);
        dashboardTotalData.clear();
        dashboardTotalData.add(model.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // account deletion request
  Future<bool> accountDeletionRequest() async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.accountDeletion,
              {"ContactID": SharedPreference.getString(AppStrings.contactID)},
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      debugPrint("Func (accountDeletionRequest) => $e");
    }

    return resultValue;
  }
}
