// To parse this JSON data, do
//
//     final adminBankResponseModel = adminBankResponseModelFromJson(jsonString);

import 'dart:convert';

AdminBankResponseModel adminBankResponseModelFromJson(String str) => AdminBankResponseModel.fromJson(json.decode(str));

String adminBankResponseModelToJson(AdminBankResponseModel data) => json.encode(data.toJson());

class AdminBankResponseModel {
  int code;
  String message;
  List<AdminBankList> data;

  AdminBankResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory AdminBankResponseModel.fromJson(Map<String, dynamic> json) => AdminBankResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<AdminBankList>.from(json["Data"].map((x) => AdminBankList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class AdminBankList {
  int slNo;
  String ledgerId;
  String ledgerName;
  String parentLedgerId;
  String categoryId;
  bool isLedgerGroup;
  bool allowCustomSubLedger;

  AdminBankList({
    required this.slNo,
    required this.ledgerId,
    required this.ledgerName,
    required this.parentLedgerId,
    required this.categoryId,
    required this.isLedgerGroup,
    required this.allowCustomSubLedger,
  });

  factory AdminBankList.fromJson(Map<String, dynamic> json) => AdminBankList(
    slNo: json["SlNo"],
    ledgerId: json["LedgerID"],
    ledgerName: json["LedgerName"],
    parentLedgerId: json["ParentLedgerID"],
    categoryId: json["CategoryID"],
    isLedgerGroup: json["IsLedgerGroup"],
    allowCustomSubLedger: json["AllowCustomSubLedger"],
  );

  Map<String, dynamic> toJson() => {
    "SlNo": slNo,
    "LedgerID": ledgerId,
    "LedgerName": ledgerName,
    "ParentLedgerID": parentLedgerId,
    "CategoryID": categoryId,
    "IsLedgerGroup": isLedgerGroup,
    "AllowCustomSubLedger": allowCustomSubLedger,
  };
}
