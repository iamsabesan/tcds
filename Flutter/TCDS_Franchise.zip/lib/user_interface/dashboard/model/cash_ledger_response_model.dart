// To parse this JSON data, do
//
//     final cashLedgerResponseModel = cashLedgerResponseModelFromJson(jsonString);

import 'dart:convert';

CashLedgerResponseModel cashLedgerResponseModelFromJson(String str) => CashLedgerResponseModel.fromJson(json.decode(str));

String cashLedgerResponseModelToJson(CashLedgerResponseModel data) => json.encode(data.toJson());

class CashLedgerResponseModel {
  int code;
  String message;
  List<CashLedgerList> data;

  CashLedgerResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CashLedgerResponseModel.fromJson(Map<String, dynamic> json) => CashLedgerResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CashLedgerList>.from(json["Data"].map((x) => CashLedgerList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CashLedgerList {
  String ledgerId;
  String ledgerName;
  String categoryId;
  String parentLedgerId;
  String accountType;
  String accountNumber;
  String accountName;

  CashLedgerList({
    required this.ledgerId,
    required this.ledgerName,
    required this.categoryId,
    required this.parentLedgerId,
    required this.accountType,
    required this.accountNumber,
    required this.accountName,
  });

  factory CashLedgerList.fromJson(Map<String, dynamic> json) => CashLedgerList(
    ledgerId: json["LedgerID"],
    ledgerName: json["LedgerName"],
    categoryId: json["CategoryID"],
    parentLedgerId: json["ParentLedgerID"],
    accountType: json["AccountType"],
    accountNumber: json["AccountNumber"],
    accountName: json["AccountName"],
  );

  Map<String, dynamic> toJson() => {
    "LedgerID": ledgerId,
    "LedgerName": ledgerName,
    "CategoryID": categoryId,
    "ParentLedgerID": parentLedgerId,
    "AccountType": accountType,
    "AccountNumber": accountNumber,
    "AccountName": accountName,
  };
}
