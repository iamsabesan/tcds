import 'dart:convert';

DashboardDetailModel dashboardDetailModelFromJson(String str) =>
    DashboardDetailModel.fromJson(json.decode(str));

String dashboardDetailModelToJson(DashboardDetailModel data) =>
    json.encode(data.toJson());

class DashboardDetailModel {
  int code;
  String message;
  DashboardDetailData data;

  DashboardDetailModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DashboardDetailModel.fromJson(Map<String, dynamic> json) =>
      DashboardDetailModel(
        code: json["Code"],
        message: json["Message"],
        data: DashboardDetailData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class DashboardDetailData {
  String approvalStartDate;
  String approvalEndDate;
  String subscriptionStartDate;
  String subscriptionEndDate;
  int approvalTotalDays;
  int approvalCompletedDays;
  int approvalRemainingDays;
  int subscriptionTotalDays;
  int subscriptionCompletedDays;
  int subscriptionRemainingDays;
  int courses;
  int inbox;
  double walletBalance;
  int activeBatch;
  int completedBatch;
  int alumniStudent;
  int currentStudent;
  int discontinuedStudent;
  double feesBalance;
  int materialPending;
  int examPending;
  int marksheetPending;
  int certificatePending;

  DashboardDetailData({
    required this.approvalStartDate,
    required this.approvalEndDate,
    required this.subscriptionStartDate,
    required this.subscriptionEndDate,
    required this.approvalTotalDays,
    required this.approvalCompletedDays,
    required this.approvalRemainingDays,
    required this.subscriptionTotalDays,
    required this.subscriptionCompletedDays,
    required this.subscriptionRemainingDays,
    required this.courses,
    required this.inbox,
    required this.walletBalance,
    required this.activeBatch,
    required this.completedBatch,
    required this.alumniStudent,
    required this.currentStudent,
    required this.discontinuedStudent,
    required this.feesBalance,
    required this.materialPending,
    required this.examPending,
    required this.marksheetPending,
    required this.certificatePending,
  });

  factory DashboardDetailData.fromJson(Map<String, dynamic> json) =>
      DashboardDetailData(
        approvalStartDate: json["ApprovalStartDate"],
        approvalEndDate: json["ApprovalEndDate"],
        subscriptionStartDate: json["SubscriptionStartDate"],
        subscriptionEndDate: json["SubscriptionEndDate"],
        approvalTotalDays: json["ApprovalTotalDays"],
        approvalCompletedDays: json["ApprovalCompletedDays"],
        approvalRemainingDays: json["ApprovalRemainingDays"],
        subscriptionTotalDays: json["SubscriptionTotalDays"],
        subscriptionCompletedDays: json["SubscriptionCompletedDays"],
        subscriptionRemainingDays: json["SubscriptionRemainingDays"],
        courses: json["Courses"],
        inbox: json["Inbox"],
        walletBalance: json["WalletBalance"],
        activeBatch: json["ActiveBatch"],
        completedBatch: json["CompletedBatch"],
        alumniStudent: json["AlumniStudent"],
        currentStudent: json["CurrentStudent"],
        discontinuedStudent: json["DiscontinuedStudent"],
        feesBalance: json["FeesBalance"],
        materialPending: json["MaterialPending"],
        examPending: json["ExamPending"],
        marksheetPending: json["MarksheetPending"],
        certificatePending: json["CertificatePending"],
      );

  Map<String, dynamic> toJson() => {
        "ApprovalStartDate": approvalStartDate,
        "ApprovalEndDate": approvalEndDate,
        "SubscriptionStartDate": subscriptionStartDate,
        "SubscriptionEndDate": subscriptionEndDate,
        "ApprovalTotalDays": approvalTotalDays,
        "ApprovalCompletedDays": approvalCompletedDays,
        "ApprovalRemainingDays": approvalRemainingDays,
        "SubscriptionTotalDays": subscriptionTotalDays,
        "SubscriptionCompletedDays": subscriptionCompletedDays,
        "SubscriptionRemainingDays": subscriptionRemainingDays,
        "Courses": courses,
        "Inbox": inbox,
        "WalletBalance": walletBalance,
        "ActiveBatch": activeBatch,
        "CompletedBatch": completedBatch,
        "AlumniStudent": alumniStudent,
        "CurrentStudent": currentStudent,
        "DiscontinuedStudent": discontinuedStudent,
        "FeesBalance": feesBalance,
        "MaterialPending": materialPending,
        "ExamPending": examPending,
        "MarksheetPending": marksheetPending,
        "CertificatePending": certificatePending,
      };
}
