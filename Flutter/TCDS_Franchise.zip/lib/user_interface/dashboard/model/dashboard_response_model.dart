// To parse this JSON data, do
//
//     final dashboardResponseModel = dashboardResponseModelFromJson(jsonString);

import 'dart:convert';

DashboardResponseModel dashboardResponseModelFromJson(String str) =>
    DashboardResponseModel.fromJson(json.decode(str));

String dashboardResponseModelToJson(DashboardResponseModel data) =>
    json.encode(data.toJson());

class DashboardResponseModel {
  int code;
  String message;
  DashboardData data;

  DashboardResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DashboardResponseModel.fromJson(Map<String, dynamic> json) =>
      DashboardResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: DashboardData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class DashboardData {
  double walletBalance;
  String date;
  int noOfCourse;
  int enquiry;
  int admission;
  int pending;
  int closed;
  int direct;
  int totalStrength;
  int studyingOffline;
  int studyingOnline;
  int studyingTotal;
  int completedOffline;
  int completedOnline;
  int completedTotal;
  int discontinuedOffline;
  int discontinuedOnline;
  int discontinuedTotal;
  int districtLvlRank;
  int districtLvlOutOff;
  int stateLvlRank;
  int stateLvlOutOff;
  int districtLvlAchievers;
  int stateLvlAchievers;

  DashboardData({
    required this.walletBalance,
    required this.date,
    required this.noOfCourse,
    required this.enquiry,
    required this.admission,
    required this.pending,
    required this.closed,
    required this.direct,
    required this.totalStrength,
    required this.studyingOffline,
    required this.studyingOnline,
    required this.studyingTotal,
    required this.completedOffline,
    required this.completedOnline,
    required this.completedTotal,
    required this.discontinuedOffline,
    required this.discontinuedOnline,
    required this.discontinuedTotal,
    required this.districtLvlRank,
    required this.districtLvlOutOff,
    required this.stateLvlRank,
    required this.stateLvlOutOff,
    required this.districtLvlAchievers,
    required this.stateLvlAchievers,
  });

  factory DashboardData.fromJson(Map<String, dynamic> json) => DashboardData(
        walletBalance: json["WalletBalance"],
        date: json["Date"],
        noOfCourse: json["NoOfCourse"],
        enquiry: json["Enquiry"],
        admission: json["Admission"],
        pending: json["Pending"],
        closed: json["Closed"],
        direct: json["Direct"],
        totalStrength: json["TotalStrength"],
        studyingOffline: json["StudyingOffline"],
        studyingOnline: json["StudyingOnline"],
        studyingTotal: json["StudyingTotal"],
        completedOffline: json["CompletedOffline"],
        completedOnline: json["CompletedOnline"],
        completedTotal: json["CompletedTotal"],
        discontinuedOffline: json["DiscontinuedOffline"],
        discontinuedOnline: json["DiscontinuedOnline"],
        discontinuedTotal: json["DiscontinuedTotal"],
        districtLvlRank: json["DistrictLvlRank"],
        districtLvlOutOff: json["DistrictLvlOutOff"],
        stateLvlRank: json["StateLvlRank"],
        stateLvlOutOff: json["StateLvlOutOff"],
        districtLvlAchievers: json["DistrictLvlAchievers"],
        stateLvlAchievers: json["StateLvlAchievers"],
      );

  Map<String, dynamic> toJson() => {
        "WalletBalance": walletBalance,
        "Date": date,
        "NoOfCourse": noOfCourse,
        "Enquiry": enquiry,
        "Admission": admission,
        "Pending": pending,
        "Closed": closed,
        "Direct": direct,
        "TotalStrength": totalStrength,
        "StudyingOffline": studyingOffline,
        "StudyingOnline": studyingOnline,
        "StudyingTotal": studyingTotal,
        "CompletedOffline": completedOffline,
        "CompletedOnline": completedOnline,
        "CompletedTotal": completedTotal,
        "DiscontinuedOffline": discontinuedOffline,
        "DiscontinuedOnline": discontinuedOnline,
        "DiscontinuedTotal": discontinuedTotal,
        "DistrictLvlRank": districtLvlRank,
        "DistrictLvlOutOff": districtLvlOutOff,
        "StateLvlRank": stateLvlRank,
        "StateLvlOutOff": stateLvlOutOff,
        "DistrictLvlAchievers": districtLvlAchievers,
        "StateLvlAchievers": stateLvlAchievers,
      };
}
