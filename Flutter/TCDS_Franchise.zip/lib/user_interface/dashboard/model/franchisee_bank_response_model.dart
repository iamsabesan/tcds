// To parse this JSON data, do
//
//     final franchiseeBankResponseModel = franchiseeBankResponseModelFromJson(jsonString);

import 'dart:convert';

FranchiseeBankResponseModel franchiseeBankResponseModelFromJson(String str) => FranchiseeBankResponseModel.fromJson(json.decode(str));

String franchiseeBankResponseModelToJson(FranchiseeBankResponseModel data) => json.encode(data.toJson());

class FranchiseeBankResponseModel {
  int code;
  String message;
  List<FranchiseeBankList> data;

  FranchiseeBankResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseeBankResponseModel.fromJson(Map<String, dynamic> json) => FranchiseeBankResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<FranchiseeBankList>.from(json["Data"].map((x) => FranchiseeBankList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class FranchiseeBankList {
  int slNo;
  String ledgerId;
  String ledgerName;
  String parentLedgerId;
  String categoryId;
  bool isLedgerGroup;
  bool allowCustomSubLedger;

  FranchiseeBankList({
    required this.slNo,
    required this.ledgerId,
    required this.ledgerName,
    required this.parentLedgerId,
    required this.categoryId,
    required this.isLedgerGroup,
    required this.allowCustomSubLedger,
  });

  factory FranchiseeBankList.fromJson(Map<String, dynamic> json) => FranchiseeBankList(
    slNo: json["SlNo"],
    ledgerId: json["LedgerID"],
    ledgerName: json["LedgerName"],
    parentLedgerId: json["ParentLedgerID"],
    categoryId: json["CategoryID"],
    isLedgerGroup: json["IsLedgerGroup"],
    allowCustomSubLedger: json["AllowCustomSubLedger"],
  );

  Map<String, dynamic> toJson() => {
    "SlNo": slNo,
    "LedgerID": ledgerId,
    "LedgerName": ledgerName,
    "ParentLedgerID": parentLedgerId,
    "CategoryID": categoryId,
    "IsLedgerGroup": isLedgerGroup,
    "AllowCustomSubLedger": allowCustomSubLedger,
  };
}
