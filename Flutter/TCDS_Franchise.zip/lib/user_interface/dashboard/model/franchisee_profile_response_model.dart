class FranchiseeProfileResponseModel {
  int code;
  String message;
  FranchiseeProfileData data;

  FranchiseeProfileResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseeProfileResponseModel.fromJson(Map<String, dynamic> json) =>
      FranchiseeProfileResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: FranchiseeProfileData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class FranchiseeProfileData {
  String franchiseeRequestId;
  String franchiseeCode;
  String branchName;
  String contactId;
  String contactName;
  String gender;
  String phone;
  String alternatePhone;
  String email;
  double walletBalance;
  String approvalStartDate;
  String approvalEndDate;
  String subscriptionStartDate;
  String subscriptionEndDate;
  List<Address> address;
  List<FranchiseeImg> franchiseeImgs;

  FranchiseeProfileData({
    required this.franchiseeRequestId,
    required this.franchiseeCode,
    required this.branchName,
    required this.contactId,
    required this.contactName,
    required this.gender,
    required this.phone,
    required this.alternatePhone,
    required this.email,
    required this.walletBalance,
    required this.approvalStartDate,
    required this.approvalEndDate,
    required this.subscriptionStartDate,
    required this.subscriptionEndDate,
    required this.address,
    required this.franchiseeImgs,
  });

  factory FranchiseeProfileData.fromJson(Map<String, dynamic> json) =>
      FranchiseeProfileData(
        franchiseeRequestId: json["FranchiseeRequestID"],
        franchiseeCode: json["FranchiseeCode"],
        branchName: json["BranchName"],
        contactId: json["ContactID"],
        contactName: json["ContactName"],
        gender: json["Gender"],
        phone: json["Phone"],
        alternatePhone: json["AlternatePhone"],
        email: json["Email"],
        walletBalance: json["WalletBalance"],
        approvalStartDate: json["ApprovalStartDate"],
        approvalEndDate: json["ApprovalEndDate"],
        subscriptionStartDate: json["SubscriptionStartDate"],
        subscriptionEndDate: json["SubscriptionEndDate"],
        address:
            List<Address>.from(json["Address"].map((x) => Address.fromJson(x))),
        franchiseeImgs: List<FranchiseeImg>.from(
            json["FranchiseeImgs"].map((x) => FranchiseeImg.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "FranchiseeRequestID": franchiseeRequestId,
        "FranchiseeCode": franchiseeCode,
        "BranchName": branchName,
        "ContactID": contactId,
        "ContactName": contactName,
        "Gender": gender,
        "Phone": phone,
        "AlternatePhone": alternatePhone,
        "Email": email,
        "WalletBalance": walletBalance,
        "ApprovalStartDate": approvalStartDate,
        "ApprovalEndDate": approvalEndDate,
        "SubscriptionStartDate": subscriptionStartDate,
        "SubscriptionEndDate": subscriptionEndDate,
        "Address": List<dynamic>.from(address.map((x) => x.toJson())),
        "FranchiseeImgs":
            List<dynamic>.from(franchiseeImgs.map((x) => x.toJson())),
      };
}

class Address {
  String contactId;
  String addressTypeId;
  String addressType;
  String address1;
  String address2;
  String area;
  String country;
  String state;
  String district;
  String pincode;
  String latitude;
  String longitude;
  String taluk;

  Address({
    required this.contactId,
    required this.addressTypeId,
    required this.addressType,
    required this.address1,
    required this.address2,
    required this.area,
    required this.country,
    required this.state,
    required this.district,
    required this.pincode,
    required this.latitude,
    required this.longitude,
    required this.taluk,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        contactId: json["ContactID"],
        addressTypeId: json["AddressTypeID"],
        addressType: json["AddressType"],
        address1: json["Address1"],
        address2: json["Address2"],
        area: json["Area"],
        country: json["Country"],
        state: json["State"],
        district: json["District"],
        pincode: json["Pincode"],
        latitude: json["Latitude"],
        longitude: json["Longitude"],
        taluk: json["Taluk"],
      );

  Map<String, dynamic> toJson() => {
        "ContactID": contactId,
        "AddressTypeID": addressTypeId,
        "AddressType": addressType,
        "Address1": address1,
        "Address2": address2,
        "Area": area,
        "Country": country,
        "State": state,
        "District": district,
        "Pincode": pincode,
        "Latitude": latitude,
        "Longitude": longitude,
        "Taluk": taluk,
      };
}

class FranchiseeImg {
  String franchiseeRequestId;
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;
  String? base64Image;

  FranchiseeImg({
    required this.franchiseeRequestId,
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
    this.base64Image,
  });

  factory FranchiseeImg.fromJson(Map<String, dynamic> json) => FranchiseeImg(
        franchiseeRequestId: json["FranchiseeRequestID"],
        documentName: json["DocumentName"],
        fileName: json["FileName"],
        documentType: json["DocumentType"],
        contentUrl: json["ContentUrl"],
      );

  Map<String, dynamic> toJson() => {
        "FranchiseeRequestID": franchiseeRequestId,
        "DocumentName": documentName,
        "FileName": fileName,
        "DocumentType": documentType,
        "ContentUrl": contentUrl,
      };
}
