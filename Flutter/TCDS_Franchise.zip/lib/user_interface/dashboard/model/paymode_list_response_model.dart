// To parse this JSON data, do
//
//     final paymodeListResponseModel = paymodeListResponseModelFromJson(jsonString);

import 'dart:convert';

PaymodeListResponseModel paymodeListResponseModelFromJson(String str) => PaymodeListResponseModel.fromJson(json.decode(str));

String paymodeListResponseModelToJson(PaymodeListResponseModel data) => json.encode(data.toJson());

class PaymodeListResponseModel {
  int code;
  String message;
  List<PaymodeList> data;

  PaymodeListResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory PaymodeListResponseModel.fromJson(Map<String, dynamic> json) => PaymodeListResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<PaymodeList>.from(json["Data"].map((x) => PaymodeList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class PaymodeList {
  String paymodeId;
  String paymode;

  PaymodeList({
    required this.paymodeId,
    required this.paymode,
  });

  factory PaymodeList.fromJson(Map<String, dynamic> json) => PaymodeList(
    paymodeId: json["PaymodeID"],
    paymode: json["Paymode"],
  );

  Map<String, dynamic> toJson() => {
    "PaymodeID": paymodeId,
    "Paymode": paymode,
  };
}
