// To parse this JSON data, do
//
//     final profileImageResponseModel = profileImageResponseModelFromJson(jsonString);

import 'dart:convert';

ProfileImageResponseModel profileImageResponseModelFromJson(String str) => ProfileImageResponseModel.fromJson(json.decode(str));

String profileImageResponseModelToJson(ProfileImageResponseModel data) => json.encode(data.toJson());

class ProfileImageResponseModel {
  int code;
  String message;
  List<ProfileImageData> data;

  ProfileImageResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory ProfileImageResponseModel.fromJson(Map<String, dynamic> json) => ProfileImageResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<ProfileImageData>.from(json["Data"].map((x) => ProfileImageData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class ProfileImageData {
  String contactId;
  String profileBase64;
  String mimeType;

  ProfileImageData({
    required this.contactId,
    required this.profileBase64,
    required this.mimeType,
  });

  factory ProfileImageData.fromJson(Map<String, dynamic> json) => ProfileImageData(
    contactId: json["ContactID"],
    profileBase64: json["ProfileBase64"],
    mimeType: json["MIMEType"],
  );

  Map<String, dynamic> toJson() => {
    "ContactID": contactId,
    "ProfileBase64": profileBase64,
    "MIMEType": mimeType,
  };
}
