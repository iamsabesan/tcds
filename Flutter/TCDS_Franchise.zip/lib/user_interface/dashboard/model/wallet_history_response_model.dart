// To parse this JSON data, do
//
//     final walletHistoryResponseModel = walletHistoryResponseModelFromJson(jsonString);

import 'dart:convert';

WalletHistoryResponseModel walletHistoryResponseModelFromJson(String str) => WalletHistoryResponseModel.fromJson(json.decode(str));

String walletHistoryResponseModelToJson(WalletHistoryResponseModel data) => json.encode(data.toJson());

class WalletHistoryResponseModel {
  int code;
  String message;
  WalletHistoryData data;

  WalletHistoryResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory WalletHistoryResponseModel.fromJson(Map<String, dynamic> json) => WalletHistoryResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: WalletHistoryData.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data.toJson(),
  };
}

class WalletHistoryData {
  OpeningBalance openingBalance;
  WalletBalance walletBalance;
  List<WalletHistory> walletHistory;

  WalletHistoryData({
    required this.openingBalance,
    required this.walletBalance,
    required this.walletHistory,
  });

  factory WalletHistoryData.fromJson(Map<String, dynamic> json) => WalletHistoryData(
    openingBalance: OpeningBalance.fromJson(json["OpeningBalance"]),
    walletBalance: WalletBalance.fromJson(json["WalletBalance"]),
    walletHistory: List<WalletHistory>.from(json["WalletHistory"].map((x) => WalletHistory.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "OpeningBalance": openingBalance.toJson(),
    "WalletBalance": walletBalance.toJson(),
    "WalletHistory": List<dynamic>.from(walletHistory.map((x) => x.toJson())),
  };
}

class OpeningBalance {
  double openingBalance;

  OpeningBalance({
    required this.openingBalance,
  });

  factory OpeningBalance.fromJson(Map<String, dynamic> json) => OpeningBalance(
    openingBalance: json["OpeningBalance"],
  );

  Map<String, dynamic> toJson() => {
    "OpeningBalance": openingBalance,
  };
}

class WalletBalance {
  double walletBalance;

  WalletBalance({
    required this.walletBalance,
  });

  factory WalletBalance.fromJson(Map<String, dynamic> json) => WalletBalance(
    walletBalance: json["WalletBalance"],
  );

  Map<String, dynamic> toJson() => {
    "WalletBalance": walletBalance,
  };
}

class WalletHistory {
  String transactionDate;
  String description;
  double amountIn;
  double amountOut;
  String status;
  double balance;

  WalletHistory({
    required this.transactionDate,
    required this.description,
    required this.amountIn,
    required this.amountOut,
    required this.status,
    required this.balance,
  });

  factory WalletHistory.fromJson(Map<String, dynamic> json) => WalletHistory(
    transactionDate: json["TransactionDate"],
    description: json["Description"],
    amountIn: json["AmountIn"],
    amountOut: json["AmountOut"],
    status: json["Status"],
    balance: json["Balance"],
  );

  Map<String, dynamic> toJson() => {
    "TransactionDate": transactionDate,
    "Description": description,
    "AmountIn": amountIn,
    "AmountOut": amountOut,
    "Status": status,
    "Balance": balance,
  };
}
