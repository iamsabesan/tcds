// To parse this JSON data, do
//
//     final walletTopupResponseModel = walletTopupResponseModelFromJson(jsonString);

import 'dart:convert';

WalletTopupResponseModel walletTopupResponseModelFromJson(String str) => WalletTopupResponseModel.fromJson(json.decode(str));

String walletTopupResponseModelToJson(WalletTopupResponseModel data) => json.encode(data.toJson());

class WalletTopupResponseModel {
  int code;
  String message;
  String data;

  WalletTopupResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory WalletTopupResponseModel.fromJson(Map<String, dynamic> json) => WalletTopupResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
