import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/user_interface/dashboard/view/wallet_topup_screen.dart';
import 'package:tcds/user_interface/dashboard/view/widgets/renewal_widgets.dart';
import 'package:tcds/user_interface/renewal/ui/renewal_detail_page.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/horiz_asset_text.dart';
import 'package:tcds/utils/helper_widgets/vertical_bar_indicator.dart';
import '../../../constants/app_string.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';
import '../../../utils/helper_widgets/timer_manager.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  DashboardController dashboardController = Get.put(DashboardController());
  DateFormat inputFormat = DateFormat("dd-MM-yyyy");
  bool canPop = false;
  bool firstLogin = true;
  int _selectedIndex = 2;

  // Raw base64 of Profile picture will updated in Init
  String profilePicture = '';

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);
  DateTime now = DateTime.now();
  late String todayDate;
  late String todayDayName;

  @override
  void initState() {
    super.initState();
    todayDate = DateFormat("dd-MM-yyyy").format(now);
    todayDayName = DateFormat('EEEE').format(now);
    getApiCall();
  }

  Future<void> getApiCall() async {
    await dashboardController.getDashboardData();
    await dashboardController.getFranchiseeProfilePicture();
    await dashboardController.getCashLedger();
    await dashboardController.getDashboardTotalDetails();
    int approvalRemainingDate =
        dashboardController.dashboardTotalData[0].approvalRemainingDays;
    int subscriptionRemainingDate =
        dashboardController.dashboardTotalData[0].subscriptionRemainingDays;
    double walletBalance =
        dashboardController.dashboardTotalData[0].walletBalance;
    if (SharedPreference.getBool(AppStrings.firstLogin) &&
        ((approvalRemainingDate < 15) || (subscriptionRemainingDate < 15))) {
      _showExpiryDialog(Get.context!, approvalRemainingDate,
          subscriptionRemainingDate, walletBalance);
    }
    profilePicture = SharedPreference.getString(AppStrings.userProfilePicture);
    TimerManager().startTimer();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const CustomDrawer(
        currentIndex: 0,
      ),
      appBar: AppBar(
        titleSpacing: 0,
        toolbarHeight: 70,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        foregroundColor: AppColor.blackColor,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        title: CustomText(
          fontSize: AppFontSize.size2.sp,
          text: "Dashboard",
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            _scaffoldKey.currentState!.openDrawer();
          },
        ),
        actions: [
          GestureDetector(
            onTap: () async {
              Get.to(() => const WalletTopupScreen(),
                  transition: Transition.rightToLeft,
                  duration: const Duration(milliseconds: 600));
            },
            child: Container(
              height: 45.w,
              width: 45.w,
              margin: const EdgeInsets.only(right: 10),
              alignment: Alignment.center,
              child: Image.asset(
                AssetPath.wallet,
                fit: BoxFit.contain,
              ),
            ),
          ),
        ],
      ),
      body: Obx(
        () => (dashboardController.dashboardLoader.value ||
                dashboardController.dashboardData.isEmpty)
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColor.primaryColor,
                ),
              )
            : PopScopeHandler(
                child: ListView(
                  children: [
                    // Welcome Banner
                    if (dashboardController.franchiseeProfileData.isNotEmpty)
                      Container(
                        width: width,
                        padding: const EdgeInsets.all(15),
                        clipBehavior: Clip.antiAlias,
                        decoration: BoxDecoration(
                          color: AppColor.pinkLight1,
                          border: const Border(
                              bottom: BorderSide(
                                  color: AppColor.pinkDark, width: 5)),
                          borderRadius: BorderRadiusDirectional.only(
                              bottomEnd: Radius.elliptical(40.w, 20.w),
                              bottomStart: Radius.elliptical(40.w, 20.w)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // welcome contents
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text:
                                        "Welcome ${dashboardController.franchiseeProfileData[0].contactName}...",
                                    fontWeight: FontWeight.bold,
                                    fontSize: AppFontSize.size3.sp,
                                    color: AppColor.blackColor,
                                    textAlign: TextAlign.start,
                                  ),
                                  const SizedBox(
                                    height: 8,
                                  ),
                                  CustomText(
                                    text:
                                        "🎓 ${dashboardController.franchiseeProfileData[0].branchName}",
                                    fontWeight: FontWeight.w500,
                                    fontSize: AppFontSize.size5.sp,
                                    color: AppColor.blackColor,
                                    textAlign: TextAlign.start,
                                  ),
                                  const SizedBox(
                                    height: 6,
                                  ),
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Icon(
                                        Icons.location_pin,
                                        color: AppColor.redColor,
                                        size: 15.sp,
                                      ),
                                      Expanded(
                                        child: CustomText(
                                          text:
                                              "${dashboardController.franchiseeProfileData[0].address[0].area}, ${dashboardController.franchiseeProfileData[0].address[0].taluk} ${dashboardController.franchiseeProfileData[0].address[0].district} - ${dashboardController.franchiseeProfileData[0].address[0].pincode}",
                                          fontWeight: FontWeight.w400,
                                          fontSize: AppFontSize.size6.sp,
                                          color: AppColor.blackColor,
                                          textAlign: TextAlign.start,
                                          overflow: TextOverflow.clip,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            // Owner profile picture
                            Container(
                              margin: const EdgeInsets.all(10),
                              clipBehavior: Clip.antiAlias,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    width: 5, color: AppColor.pinkDark),
                              ),
                              child: ClipOval(
                                // show base64 image only when it's not empty
                                // else show default image
                                child: profilePicture.isNotEmpty
                                    ? Image.memory(
                                        base64Decode(
                                          profilePicture,
                                        ),
                                        height: 65.w,
                                        width: 65.w,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                Image.asset(
                                          AssetPath.defaultProfile,
                                          height: 65.w,
                                          width: 65.w,
                                          fit: BoxFit.cover,
                                        ),
                                      )
                                    : Image.asset(
                                        AssetPath.defaultProfile,
                                        height: 65.w,
                                        width: 65.w,
                                        fit: BoxFit.cover,
                                      ),
                              ),
                            )
                          ],
                        ),
                      ),

                    // date time informations box
                    Padding(
                      padding: EdgeInsets.all(20.w),
                      child: Row(
                        children: [
                          Expanded(
                              child: DateTimeBox(
                            boxColor: AppColor.primaryColor,
                            content: todayDate,
                            title: "Date",
                          )),
                          SizedBox(
                            width: 10.w,
                          ),
                          Expanded(
                              child: DateTimeBox(
                            boxColor: AppColor.lightGreen,
                            content: todayDayName,
                            title: "Day",
                          )),
                        ],
                      ),
                    ),

                    // Enquiry Card
                    Container(
                      margin: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColor.lightOrange1,
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            padding: EdgeInsets.all(5.w),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColor.whiteColor,
                            ),
                            child: Image.asset(
                              AssetPath.enquiry,
                              height: 30.w,
                              width: 30.w,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          CustomText(
                            text: dashboardController.dashboardData[0].enquiry
                                .toString(),
                            fontSize: AppFontSize.size3.sp,
                            color: AppColor.primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                          CustomText(
                            text: 'Enquiry',
                            fontSize: AppFontSize.size4.sp,
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w400,
                          ),
                          const Divider(
                            color: AppColor.whiteColor,
                            thickness: 2,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 33,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    CustomText(
                                      text: dashboardController
                                          .dashboardData[0].admission
                                          .toString(),
                                      fontSize: AppFontSize.size3.sp,
                                      color: AppColor.primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    CustomText(
                                      text: 'Admission',
                                      fontSize: AppFontSize.size4.sp,
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 2,
                                height: 40.w,
                                color: AppColor.whiteColor,
                              ),
                              Expanded(
                                flex: 33,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    CustomText(
                                      text: dashboardController
                                          .dashboardData[0].pending
                                          .toString(),
                                      fontSize: AppFontSize.size3.sp,
                                      color: AppColor.primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    CustomText(
                                      text: 'Pending',
                                      fontSize: AppFontSize.size4.sp,
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: 2,
                                height: 40.w,
                                color: AppColor.whiteColor,
                              ),
                              Expanded(
                                flex: 33,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    CustomText(
                                      text: dashboardController
                                          .dashboardData[0].closed
                                          .toString(),
                                      fontSize: AppFontSize.size3.sp,
                                      color: AppColor.primaryColor,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    CustomText(
                                      text: 'Closed',
                                      fontSize: AppFontSize.size4.sp,
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    // Direct Registration and Total Strength
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildInfoCard(
                            AssetPath.directRegistration,
                            dashboardController.dashboardData[0].direct
                                .toString(),
                            'Direct Registration',
                            AppColor.progressBarBlue.withAlpha(100),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          _buildInfoCard(
                            AssetPath.courseDashboard,
                            dashboardController.dashboardData[0].totalStrength
                                .toString(),
                            'Total Strength',
                            Colors.orange.withAlpha(100),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    // Franchisee Rank and Achievers Award
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildRankCard(
                            dashboardController.dashboardData[0].stateLvlRank
                                .toString(),
                            dashboardController.dashboardData[0].stateLvlOutOff
                                .toString(),
                            dashboardController.dashboardData[0].districtLvlRank
                                .toString(),
                            dashboardController
                                .dashboardData[0].districtLvlOutOff
                                .toString(),
                            'Admission Rank',
                            AssetPath.rank,
                          ),
                          _buildRankCard(
                              dashboardController
                                  .dashboardData[0].stateLvlAchievers
                                  .toString(),
                              // null,
                              dashboardController
                                  .dashboardData[0].stateLvlOutOff
                                  .toString(),
                              dashboardController.dashboardData[0]
                                          .districtLvlAchievers ==
                                      0
                                  ? null
                                  : dashboardController
                                      .dashboardData[0].districtLvlAchievers
                                      .toString(),
                              // null,
                              dashboardController
                                  .dashboardData[0].districtLvlOutOff
                                  .toString(),
                              'Transaction Rank',
                              AssetPath.award),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),
                    // Progress Cards
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Row(
                        children: [
                          _buildProgressCard(
                            'Studying',
                            dashboardController
                                .dashboardData[0].studyingOffline,
                            dashboardController.dashboardData[0].studyingOnline,
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          _buildProgressCard(
                            'Completed',
                            dashboardController
                                .dashboardData[0].completedOffline,
                            dashboardController
                                .dashboardData[0].completedOnline,
                          ),
                          const SizedBox(
                            width: 8,
                          ),
                          _buildProgressCard(
                            'Discontinued',
                            dashboardController
                                .dashboardData[0].discontinuedOffline,
                            dashboardController
                                .dashboardData[0].discontinuedOnline,
                          ),
                        ],
                      ),
                    ),
                    /*  const SizedBox(height: 20),
                    // Fees data section
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: Row(
                        children: [
                          Expanded(
                              flex: 33,
                              child: FeesBox(
                                currencyFormat: currencyFormat,
                                title: "Total Fees",
                                regular: 45000,
                                online: 55000,
                                total: 100000,
                              )),
                          const SizedBox(
                            width: 5,
                          ),
                          Expanded(
                              flex: 33,
                              child: FeesBox(
                                currencyFormat: currencyFormat,
                                title: "Fees Collected",
                                regular: 30000,
                                online: 20000,
                                total: 50000,
                              )),
                          const SizedBox(
                            width: 5,
                          ),
                          Expanded(
                              flex: 33,
                              child: FeesBox(
                                currencyFormat: currencyFormat,
                                title: "Fees Balance",
                                regular: 25000,
                                online: 25000,
                                total: 50000,
                              )),
                        ],
                      ),
                    ), */

                    const SizedBox(height: 40),
                    // Quick Links
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: 'Quick Links',
                            fontSize: 14.sp,
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.bold,
                            textAlign: TextAlign.left,
                          ),
                          Divider(
                            color: Colors.grey.withAlpha(80),
                            thickness: 1.5,
                          ),
                        ],
                      ),
                    ),
                    // Quick Snippets
                    if (dashboardController.dashboardTotalData.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Wrap(
                          alignment: WrapAlignment.center,
                          spacing: 10,
                          runSpacing: 20,
                          children: [
                            // Approval renewal
                            ApprovalRenewalWidget(
                                dashboardDetailData:
                                    dashboardController.dashboardTotalData[0]),

                            // Subscription
                            SubscriptionRenewalWidget(
                                dashboardDetailData:
                                    dashboardController.dashboardTotalData[0]),
                            // Wallet
                            WalletRenewalWidget(
                                dashboardDetailData:
                                    dashboardController.dashboardTotalData[0]),
                          ],
                        ),
                      ),

                    const SizedBox(
                      height: 20,
                    ),

                    GridView.count(
                      crossAxisCount: 4,
                      shrinkWrap: true,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 15,
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      physics: const NeverScrollableScrollPhysics(),
                      childAspectRatio: 0.8,
                      children: [
                        _buildQuickLink(
                          AssetPath.courseDashboard,
                          'Course',
                          () {
                            Get.toNamed('/course_details_screen',
                                arguments: {"withBack": true});
                          },
                          AppColor.pinkLight,
                        ),
                        _buildQuickLink(
                          AssetPath.studentsDashboard,
                          'Students',
                          () {
                            Get.toNamed('/student_list_screen',
                                arguments: {"withBack": true});
                          },
                          AppColor.pinkLight,
                        ),
                        _buildQuickLink(
                          AssetPath.feesDashboard,
                          'Fees',
                          () {
                            Get.toNamed('/fees_collection_list',
                                arguments: {"withBack": true});
                          },
                          AppColor.pinkLight,
                        ),
                        _buildQuickLink(
                          AssetPath.materialDashboard,
                          'Material',
                          () {
                            Get.toNamed('/material_indent',
                                arguments: {"withBack": true});
                          },
                          AppColor.pinkLight,
                        ),
                        _buildQuickLink(
                          AssetPath.examDashboard,
                          'Exam',
                          () {
                            Get.toNamed('/exam_indent',
                                arguments: {"withBack": true});
                          },
                          AppColor.yellowLight,
                        ),
                        _buildQuickLink(
                          AssetPath.stocksDashboard,
                          'Stocks',
                          () {
                            Get.toNamed('/stock_list_screen',
                                arguments: {"withBack": true});
                          },
                          AppColor.yellowLight,
                        ),
                        _buildQuickLink(
                          AssetPath.awardDashboard,
                          'Award',
                          () {
                            Get.toNamed('/achieversAward',
                                arguments: {"withBack": true});
                          },
                          AppColor.yellowLight,
                        ),
                        _buildQuickLink(
                          AssetPath.rankDashboard,
                          'Rank',
                          () {
                            Get.toNamed('/franchisee_ranking_screen',
                                arguments: {"withBack": true});
                          },
                          AppColor.yellowLight,
                        ),
                      ],
                    ),
                    const SizedBox(height: 60),
                  ],
                ),
              ),
      ),
      floatingActionButton: Stack(
        alignment: Alignment.center,
        children: [
          // Outer Circle
          Container(
            width: 72,
            height: 72,
            decoration: const BoxDecoration(
              color: Color(0xFFCCE6FF), // Lighter blue
              shape: BoxShape.circle,
            ),
          ),
          // Inner Circle
          Container(
            width: 56,
            height: 56,
            decoration: const BoxDecoration(
              color: AppColor.primaryColor, // Darker blue
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.home,
              color: Colors.white,
              size: 28,
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildInfoCard(
      String imagePath, String count, String title, Color bgColor) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.w),
        decoration: BoxDecoration(
          color: AppColor.whiteColor,
          border: Border.all(color: Colors.black.withValues(alpha: 0.1)),
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 1,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bgColor,
                    ),
                    child: Image.asset(
                      imagePath,
                      height: 30.w,
                      width: 30.w,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: count,
                    fontSize: AppFontSize.size3.sp,
                    color: AppColor.primaryColor,
                    fontWeight: FontWeight.bold,
                    textAlign: TextAlign.end,
                  ),
                  CustomText(
                    text: title,
                    fontSize: AppFontSize.size6.sp,
                    fontWeight: FontWeight.w400,
                    textAlign: TextAlign.end,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRankCard(
    String currentCountState,
    String? totalCountState,
    String? currentCountDistrict,
    String? totalCountDistrict,
    String title,
    String assetPath,
  ) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 5.w),
        decoration: BoxDecoration(
          // color: Colors.grey[100],
          color: AppColor.whiteColor,
          border: Border.all(color: Colors.grey.withAlpha(80)),
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: AppColor.green2,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(12.r),
                            topRight: Radius.circular(12.r))),
                    child: HorizAssetText(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      assetPath: assetPath,
                      valueText: title,
                      assetColor: AppColor.orange,
                      valueFontSize: AppFontSize.size4.sp,
                      valueFontWeight: FontWeight.w500,
                      valueTextColor: AppColor.primaryColor,
                      assetScale: 25.0,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(
              color: AppColor.greyColor,
              thickness: 0.5,
              height: 0,
            ),
            SizedBox(
              height: 2.w,
            ),
            Padding(
              padding: const EdgeInsets.all(5),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: currentCountState,
                                style: TextStyle(
                                  fontSize: AppFontSize.size3.sp,
                                  fontWeight: FontWeight.bold,
                                  color: AppColor.primaryColor,
                                ),
                              ),
                              if (totalCountState != null &&
                                  totalCountState != "null")
                                TextSpan(
                                  text: ' / $totalCountState',
                                  style: TextStyle(
                                    fontSize: AppFontSize.size5.sp,
                                    fontWeight: FontWeight.w400,
                                    color: AppColor.blackColor,
                                  ),
                                ),
                            ],
                          ),
                          textAlign: TextAlign.end,
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        CustomText(
                          text: "State Level",
                          fontSize: AppFontSize.size6.sp,
                          fontWeight: FontWeight.w400,
                          color: AppColor.blackColor,
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                  if (currentCountDistrict != null)
                    const SizedBox(
                      width: 5,
                    ),
                  if (currentCountDistrict != null)
                    Container(
                      width: 2.0,
                      height: 40.w,
                      color: Colors.grey.withAlpha(100),
                    ),
                  if (currentCountDistrict != null)
                    const SizedBox(
                      width: 5,
                    ),
                  if (currentCountDistrict != null)
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text.rich(
                            TextSpan(
                              children: [
                                TextSpan(
                                  text:
                                      currentCountDistrict, // The current value
                                  style: TextStyle(
                                    fontSize: AppFontSize.size3.sp,
                                    fontWeight: FontWeight.bold,
                                    color: AppColor.primaryColor,
                                  ),
                                ),
                                if (totalCountDistrict != null &&
                                    totalCountDistrict != "null")
                                  TextSpan(
                                    text:
                                        ' / $totalCountDistrict', // The total value
                                    style: TextStyle(
                                      fontSize: AppFontSize.size6.sp,
                                      fontWeight: FontWeight.w400,
                                      color: AppColor.blackColor,
                                    ),
                                  ),
                              ],
                            ),
                            textAlign: TextAlign.end,
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          CustomText(
                            text: "District Level",
                            fontSize: AppFontSize.size6.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColor.blackColor,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressCard(String title, int regular, int online) {
    return Expanded(
      child: Container(
        decoration: BoxDecoration(
          color: AppColor.whiteColor,
          border: Border.all(
            color: AppColor.grey.withAlpha(120),
          ),
          borderRadius: BorderRadius.circular(12.r),
        ),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                color: AppColor.blue2,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(12.r),
                    topRight: Radius.circular(12.r)),
              ),
              child: CustomText(
                text: title,
                fontSize: AppFontSize.size4.sp,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.center,
                color: AppColor.primaryColor,
              ),
            ),
            const Divider(
              color: AppColor.greyColor,
              thickness: 0.5,
              height: 0,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    flex: 2,
                    child: VerticalBarIndicator(
                      regular: regular,
                      online: online,
                      // maxValue: maxValue,
                      regularColor: AppColor.progressBarBlue,
                      onlineColor: AppColor.progressBarPeach,
                    ),
                  ),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                    flex: 8,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: CustomText(
                                text: "Regular",
                                fontSize: AppFontSize.size6.sp,
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Flexible(
                              child: CustomText(
                                text: regular.toString(),
                                fontSize: AppFontSize.size4.sp,
                                fontWeight: FontWeight.w500,
                                color: AppColor.blueColor,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: CustomText(
                                text: "Online",
                                fontSize: AppFontSize.size6.sp,
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            Flexible(
                              child: CustomText(
                                text: online.toString(),
                                fontSize: AppFontSize.size4.sp,
                                fontWeight: FontWeight.w500,
                                color: AppColor.redColor,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 5.w,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: CustomText(
                                text: "Total",
                                fontSize: AppFontSize.size5.sp,
                                fontWeight: FontWeight.w600,
                                color: AppColor.primaryColor,
                              ),
                            ),
                            Flexible(
                              child: CustomText(
                                text: (regular + online).toString(),
                                fontSize: AppFontSize.size5.sp,
                                fontWeight: FontWeight.w600,
                                color: AppColor.primaryColor,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickLink(
    String imagePath,
    String title,
    VoidCallback onTap,
    Color textBgColor,
  ) {
    return Ink(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.withAlpha(80)),
          borderRadius: BorderRadius.circular(12.r),
          color: AppColor.whiteColor,
          boxShadow: const [
            BoxShadow(
                color: AppColor.grey,
                blurRadius: 1,
                spreadRadius: 0.5,
                offset: Offset(1, 1))
          ]),
      child: InkWell(
        onTap: onTap,
        splashColor: Colors.white,
        focusColor: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Image.asset(
                  imagePath,
                  height: 40.w,
                  width: 40.w,
                  fit: BoxFit.fitWidth,
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(5),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                  color: textBgColor,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(12.r),
                      bottomRight: Radius.circular(12.r))),
              child: CustomText(
                text: title,
                maxLines: 2,
                fontSize: AppFontSize.size5.sp,
                fontWeight: FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showExpiryDialog(BuildContext context, int approvalRemainingDate,
      int subscriptionRemainingDate, double walletBalance) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: AppColor.lightWhite,
              title: const Center(
                  child: CustomText(
                text: "Alert",
                fontWeight: FontWeight.w600,
              )),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 15),
                  if (approvalRemainingDate < 15)
                    RichText(
                        text: TextSpan(children: [
                      const TextSpan(
                          text: "Your approval will expire in ",
                          style: TextStyle(
                            color: AppColor.blackColor,
                          )),
                      TextSpan(
                          text: "$approvalRemainingDate day(s).",
                          style: const TextStyle(
                              color: AppColor.redColor,
                              fontWeight: FontWeight.w500)),
                    ])),

                  const SizedBox(height: 10),
                  if (subscriptionRemainingDate < 15)
                    RichText(
                        text: TextSpan(children: [
                      const TextSpan(
                          text: "Your subscription will expire in ",
                          style: TextStyle(
                            color: AppColor.blackColor,
                          )),
                      TextSpan(
                          text: "$subscriptionRemainingDate day(s).",
                          style: const TextStyle(
                              color: AppColor.redColor,
                              fontWeight: FontWeight.w500)),
                    ])),

                  const SizedBox(height: 25),
                  InButton(
                    onTap: () async {
                      Get.back();
                      SharedPreference.putBool(AppStrings.firstLogin, false);
                      Get.to(() => const RenewalDetailPage());
                    },
                    withArrow: false,
                    text: "Renew",
                    color: AppColor.primaryColor,
                    verticalPadding: 10.w,
                  ),

                  // Wallet balance alert
                  if (walletBalance < 500)
                    Column(
                      children: [
                        const SizedBox(height: 25),
                        CustomText(
                          text: "WALLET BALANCE : $walletBalance",
                          fontWeight: FontWeight.w500,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const CustomText(
                          text:
                              "Your wallet balance is low. Maintain a minimum balance ₹500",
                          fontWeight: FontWeight.w400,
                          color: AppColor.redColor,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 20),
                        InButton(
                          onTap: () async {
                            Get.back();
                            SharedPreference.putBool(
                                AppStrings.firstLogin, false);
                            Get.to(() => const WalletTopupScreen(),
                                transition: Transition.rightToLeft,
                                duration: const Duration(milliseconds: 600));
                          },
                          withArrow: false,
                          text: "Top Up",
                          color: AppColor.blueColor,
                          verticalPadding: 10.w,
                        ),
                      ],
                    ),
                  const SizedBox(height: 30),
                ],
              ),
              actions: [
                IntrinsicWidth(
                  child: InButton(
                    onTap: () async {
                      SharedPreference.putBool(AppStrings.firstLogin, false);
                      Get.back();
                    },
                    withArrow: false,
                    text: "Skip",
                    color: AppColor.red2,
                    verticalPadding: 10.w,
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}

// WIDGET : To show date or time informations as a Box
class DateTimeBox extends StatelessWidget {
  final String title;
  final Color boxColor;
  final String content;
  const DateTimeBox(
      {super.key,
      required this.title,
      required this.boxColor,
      required this.content});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          alignment: Alignment.center,
          color: boxColor,
          child: CustomText(
            text: title,
            color: AppColor.whiteColor,
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
        Container(
          width: double.infinity,
          alignment: Alignment.center,
          padding: const EdgeInsets.all(5),
          decoration: const BoxDecoration(
              border: Border(
            bottom: BorderSide(color: AppColor.black2Color, width: 1),
            left: BorderSide(color: AppColor.black2Color, width: 1),
            right: BorderSide(color: AppColor.black2Color, width: 1),
          )),
          child: CustomText(
            text: content,
            fontWeight: FontWeight.w400,
            color: AppColor.blackColor,
          ),
        ),
      ],
    );
  }
}
