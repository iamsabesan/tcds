import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/constants/shared_preference.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/date_picker_textfield.dart';
import 'package:tcds/utils/helper_widgets/wallet_history_widget.dart';

class WalletHistoryScreen extends StatefulWidget {
  const WalletHistoryScreen({super.key});

  @override
  State<WalletHistoryScreen> createState() => _WalletHistoryScreenState();
}

class _WalletHistoryScreenState extends State<WalletHistoryScreen> {
  DashboardController dashboardController = Get.find<DashboardController>();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  TextEditingController fromDateCtrl = TextEditingController();
  TextEditingController toDateCtrl = TextEditingController();
  DateTime now = DateTime.now();
  bool scrLoader = true;

  @override
  void initState() {
    super.initState();
    loadCurrMonthHistory();
  }

  // initial load data
  Future<void> loadCurrMonthHistory() async {
    DateTime fromDateHolder = DateTime(now.year, now.month - 1, now.day);
    String fromDate = DateFormat('yyyy-MM-dd').format(fromDateHolder);
    String toDate = DateFormat('yyyy-MM-dd').format(now);
    fromDateCtrl.text = DateFormat('dd-MM-yyyy').format(fromDateHolder);
    toDateCtrl.text = DateFormat('dd-MM-yyyy').format(now);
    bool isFetched = await dashboardController.getWalletHistory(
      tenantBranchId: SharedPreference.getString(AppStrings.tenantBranchID),
      fromDate: fromDate,
      toDate: toDate,
    );

    if (isFetched) {
      setState(() {
        scrLoader = false;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    dashboardController.walletHistoryData.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        toolbarHeight: 70,
        titleSpacing: 0.7,
        backgroundColor: AppColor.whiteColor,
        surfaceTintColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Wallet History',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: scrLoader
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20.w,
                ),
                Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.w),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        flex: 40,
                        child: DatePickerTextField(
                          controller: fromDateCtrl,
                          labelText: 'From Date',
                        ),
                      ),
                      const Spacer(flex: 5),
                      Expanded(
                        flex: 40,
                        child: DatePickerTextField(
                          controller: toDateCtrl,
                          labelText: 'To Date',
                        ),
                      ),
                      const Spacer(
                        flex: 3,
                      ),
                      InkWell(
                        onTap: () async {
                          if (fromDateCtrl.text.isNotEmpty &&
                              toDateCtrl.text.isNotEmpty) {
                            try {
                              DateTime fDate = DateFormat("dd-MM-yyyy")
                                  .parse(fromDateCtrl.text);
                              DateTime tDate = DateFormat("dd-MM-yyyy")
                                  .parse(toDateCtrl.text);

                              if (fDate.isBefore(tDate) ||
                                  fDate.difference(tDate).inDays == 0) {
                                String fromDate =
                                    DateFormat('yyyy-MM-dd').format(fDate);
                                String toDate =
                                    DateFormat('yyyy-MM-dd').format(tDate);
                                debugPrint('Passing from date $fromDate');
                                debugPrint('Passing to date $toDate');
                                PleaseWaitLoader.openDialog();
                                await dashboardController
                                    .getWalletHistory(
                                  tenantBranchId: SharedPreference.getString(
                                      AppStrings.tenantBranchID),
                                  fromDate: fromDate,
                                  toDate: toDate,
                                )
                                    .then((value) {
                                  PleaseWaitLoader.closeDialog();
                                });
                              } else {
                                Get.snackbar(
                                  'Error Message',
                                  'Selected From date is greater than To date',
                                  colorText: AppColor.blackColor,
                                  padding: EdgeInsets.all(15.w),
                                  backgroundColor: AppColor.whiteColor,
                                );
                              }
                            } catch (e) {
                              debugPrint(e.toString());
                            }
                          } else {
                            Get.snackbar(
                              'Error Message',
                              'From date or To Date is Empty',
                              colorText: AppColor.blackColor,
                              padding: EdgeInsets.all(15.w),
                              backgroundColor: AppColor.whiteColor,
                            );
                          }
                        },
                        child: Padding(
                          padding: EdgeInsets.only(bottom: 5.w),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: AppColor.primaryColor,
                              borderRadius: BorderRadius.circular(10.w),
                            ),
                            padding: EdgeInsets.all(8.w),
                            child: Icon(
                              Icons.search_rounded,
                              color: AppColor.whiteColor,
                              size: 25.w,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                Expanded(
                  child: Obx(() {
                    if (dashboardController.walletHistoryData.isEmpty) {
                      return RefreshIndicator(
                        onRefresh: () async {
                          await dashboardController.getWalletHistory(
                            tenantBranchId: SharedPreference.getString(
                                AppStrings.tenantBranchID),
                            fromDate: fromDateCtrl.text,
                            toDate: toDateCtrl.text,
                          );
                        },
                        child: Center(
                          child: CustomText(
                            text: 'No data available',
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                            fontSize: AppFontSize.size3,
                          ),
                        ),
                      );
                    }
                    return ListView.builder(
                        itemCount: dashboardController
                            .walletHistoryData[0].walletHistory.length,
                        itemBuilder: (BuildContext context, int index) {
                          if (dashboardController.walletHistoryData.isEmpty ||
                              index >=
                                  dashboardController.walletHistoryData[0]
                                      .walletHistory.length) {
                            return const SizedBox(); // or handle appropriately
                          }
                          final data = dashboardController
                              .walletHistoryData[0].walletHistory;
                          String formattedDescription =
                              formatDescription(data[index].description);
                          return WalletHistoryWidget(
                            dateAndTime: data[index].transactionDate,
                            balance: data[index].balance.toString(),
                            status: data[index].status,
                            walletIn: data[index].amountIn.toString(),
                            walletOut: data[index].amountOut.toString(),
                            purpose: formattedDescription,
                            withForwardArrow: false,
                          );
                        });
                  }),
                )
              ],
            ),
    );
  }

  String formatDescription(String description) {
    if (description.contains("Admission Fees")) {
      // Split the description by commas to parse the individual details
      List<String> parts = description.split(", ");

      // Extract specific details
      String fees = parts
          .firstWhere((part) => part.contains("Admission Fees"))
          .split(":")[1]
          .trim();
      String course = parts
          .firstWhere((part) => part.contains("Course"))
          .split(":")[1]
          .trim();
      String studentId = parts
          .firstWhere((part) => part.contains("StudentID"))
          .split(":")[1]
          .trim();

      // Format the extracted details
      return "₹${fees.replaceAll(".00", "")} Admission • $course, • $studentId";
    } else {
      // For other descriptions, return as it is
      return description;
    }
  }
}
