import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/user_interface/dashboard/view/wallet_history_screen.dart';
import 'package:tcds/utils/helper_widgets/bottom_sheets.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:tcds/utils/helper_widgets/out_button.dart';
import 'package:tcds/utils/helper_widgets/pair_text.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';

class WalletTopupScreen extends StatefulWidget {
  const WalletTopupScreen({super.key});

  @override
  State<WalletTopupScreen> createState() => _WalletTopupScreenState();
}

class _WalletTopupScreenState extends State<WalletTopupScreen> {
  DashboardController dashboardController = Get.find<DashboardController>();

  bool canPop = false;
  double totalPayable = 0;

  late String selectedPaymentMethod;
  double totalPaid = 0;
  double paidAmount = 0;
  double balance = 0;

  TextEditingController amountCtrl = TextEditingController();

  List<Map<String, dynamic>> paymentDetails = [];
  // ignore: prefer_typing_uninitialized_variables
  var selectedPaymodeId;
  bool paymentDone = false;

  // final Set<String> completedPayments = {};
  // Map<String, bool> paymentConfirmed = {
  //   'Bank Transfer': false,
  //   'UPI': false,
  //   'Cash': false,
  //   'Bank Remittance': false,
  // };

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);

  @override
  void initState() {
    super.initState();
    dashboardController.getPayMode();
    getApiCall();
  }

  Future<void> getApiCall() async {
    await dashboardController.getPayMode();
    await dashboardController.getAdminBankName();
    await dashboardController.getFranchiseeBankName();
  }

  void _openBottomSheetForMethod(
      String paymentMode, String selectedPaymodeId) async {
    double remainingAmount = totalPayable - totalPaid;

    // // Check if payment is already confirmed for this mode
    // if (paymentConfirmed[paymentMode] == true) {
    //   Get.snackbar(
    //     'Error Message',
    //     'You already confirmed payment with $paymentMode.',
    //     colorText: AppColor.whiteColor,
    //     padding: EdgeInsets.all(15.w),
    //     backgroundColor: AppColor.primaryColor,
    //   );
    //   return;
    // }

    final result = await AppBottomSheets.paymentModeBottomSheet(
      walletAmount: amountCtrl.text,
      selectedPaymodeId: selectedPaymodeId,
      currencyFormat: currencyFormat,
      paymentMode: paymentMode.toLowerCase().removeAllWhitespace,
      payModeOriginal: paymentMode,
      context: context,
      remainingAmount: remainingAmount,
      adminBankList: dashboardController.adminBankList,
      franchiseeBankList: dashboardController.franchiseeBankList,
      // onSubmit: (details) {
      //   setState(() {
      //     // /*     completedPayments.add(paymentMode);
      //     // selectedPaymentMethod = paymentMode;*/
      //     //
      //     // if (paymentMode == "cash") {
      //     //   paymentDetails[paymentMode] = {
      //     //     'date': details['date'], // Only save the date for Cash
      //     //   };
      //     // } else {
      //     //   paymentDetails[paymentMode] = details; // Save all details for other modes
      //     // }
      //     // // paymentConfirmed[paymentMode] = true; // Mark this mode as confirmed
      //
      //     paymentDetails[paymentMode] = details; // Save payment details
      //     totalPaid += details['amount'] ?? 0; // Update total paid
      //     balance = totalPayable - totalPaid; // Update balance
      //   });

      // },
      // onCancel: () {
      //   setState(() {
      //     // paymentConfirmed[paymentMode] = false;
      //     // completedPayments.remove(paymentMode);
      //   });
      // },
    );

    debugPrint("Res $result");

    if (result != null) {
      setState(() {
        paymentDetails.add(result);
        totalPaid += double.tryParse(result['amount'] ?? 0) ?? 0;
        paidAmount = totalPaid;
        balance = totalPayable - totalPaid;
        paymentDone = true;
        // paymentConfirmed[paymentMode] = true; // Mark as confirmed
      });
    }
  }

  //
  // void markPaymentCompleted(String method) {
  //   setState(() {
  //     // paymentConfirmed[method] = true; // Mark the payment mode as completed
  //   });
  // }

/*  void removePayment(String paymentMode) {
    if (paymentDetails.containsKey(paymentMode)) {
      setState(() {
        totalPaid -= paymentDetails[paymentMode]['amount']; // Subtract amount from totalPaid
        balance = totalPayable - totalPaid; // Recalculate balance
        paymentDetails.remove(paymentMode); // Remove the payment details
        // paymentConfirmed[paymentMode] = false; // Mark as not confirmed
        if (totalPaid == 0) {
          paidAmount = 0; // Reset paidAmount if no payments remain
        }
      });
    }
  }*/

/*  void removePayment(String paymentMode) {
    setState(() {
      // Find the index of the payment to remove
      int indexToRemove = paymentDetails.indexWhere((payment) => payment['paymodeType'] == paymentMode);

      if (indexToRemove != -1) {
        // Parse 'amount' to a num (double or int) before subtracting
        double amountToRemove = double.tryParse(paymentDetails[indexToRemove]['amount'].toString()) ?? 0.0;

        totalPaid -= amountToRemove; // Subtract amount from totalPaid
        balance = totalPayable - totalPaid; // Recalculate balance

        // Remove the payment from the list
        paymentDetails.removeAt(indexToRemove);

        // Reset paidAmount if no payments remain
        if (totalPaid == 0) {
          balance = totalPayable;
        }
      }
    });
  }*/

  void removePayment(String paymentMode) {
    setState(() {
      // Find the index of the payment to remove
      int indexToRemove = paymentDetails
          .indexWhere((payment) => payment['paymodeType'] == paymentMode);

      if (indexToRemove != -1) {
        double amountToRemove = double.tryParse(
                paymentDetails[indexToRemove]['amount'].toString()) ??
            0.0;

        totalPaid -= amountToRemove;
        paidAmount -= amountToRemove;
        balance += amountToRemove;

        // Remove the payment from the list
        paymentDetails.removeAt(indexToRemove);

        // Reset paidAmount if no payments remain
        if (paymentDetails.isEmpty) {
          balance = totalPayable;
          totalPaid = 0.0;
        }
      }
    });
  }

  void updateAmount() {
    // Parse the amount entered by the user
    double enteredAmount = double.tryParse(amountCtrl.text) ?? 0;

    // If the entered amount is more than the amount payable, it should be accepted
    // if (enteredAmount > totalPayable) {
    //   setState(() {
    //     totalPayable = enteredAmount; // User entered an amount greater than the total payable
    //     balance = 0; // No balance left to pay
    //   });
    // } else {
    setState(() {
      totalPayable = enteredAmount;
      balance = totalPayable - totalPaid;
    });
    // }
  }

  // Helper to convert api format date string to user friendly
  String userDateFormartion(String stringAPIDate) {
    return DateFormat('dd-MM-yyyy')
        .format(DateFormat('yyyy-MM-dd').parse(stringAPIDate));
  }

  @override
  Widget build(BuildContext context) {
    // double balance = totalPayable - totalPaid;
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        titleSpacing: 0.1,
        toolbarHeight: 70,
        elevation: 2,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black3Color,
        scrolledUnderElevation: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Wallet Topup',
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        actions: [
          GestureDetector(
            onTap: () {
              Get.to(() => const WalletHistoryScreen(),
                  transition: Transition.rightToLeft,
                  duration: const Duration(milliseconds: 600));
            },
            child: Container(
              margin: const EdgeInsets.only(right: 10),
              height: 45.w,
              width: 45.w,
              alignment: Alignment.center,
              child: Image.asset(
                AssetPath.history,
                fit: BoxFit.contain,
              ),
            ),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            // Close any active snackbar before navigating back
            try {
              Get.closeCurrentSnackbar();
            } catch (e) {
              // Ignore snackbar close errors
            }
            Get.back();
          },
        ),
      ),
      body: PopScopeHandler(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: [
                  // Warning banner when Wallet amount is less than 500
                  if (dashboardController.dashboardData.isNotEmpty &&
                      dashboardController.dashboardData[0].walletBalance < 500)
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                          color: AppColor.redShade100,
                          shape: BoxShape.rectangle,
                          border: Border(
                              left: BorderSide(
                            color: AppColor.redColor,
                            width: 5,
                          ))),
                      child: const CustomText(
                        text:
                            "NOTE: Maintain a minimum balance of ₹500 in your wallet.",
                      ),
                    ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        PairText(
                          keyText: "Current Balance",
                          valueText: currencyFormat.format(dashboardController
                              .dashboardData[0].walletBalance),
                          valueSize: AppFontSize.size3.sp,
                          valueWeight: FontWeight.bold,
                          valueColor: AppColor.orange,
                        ),
                        SizedBox(height: 15.w),
                        CustomTextField(
                          labelText: "Topup Amount",
                          controller: amountCtrl,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          validator: (val) {
                            if (val != null && val.isEmpty) {
                              return "Required";
                            } else if (val != null &&
                                val.isNotEmpty &&
                                (int.tryParse(val) ?? 0) < 500) {
                              return "Please enter an amount higher than 500";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (value) {
                            updateAmount(); // Update the amount whenever the user types
                          },
                        ),
                        const SizedBox(height: 10),
                        Center(
                          child: Wrap(
                            alignment: WrapAlignment.start,
                            direction: Axis.horizontal,
                            runSpacing: 10,
                            spacing: 15,
                            children: [
                              500,
                              1000,
                              5000,
                              10000,
                            ].map((e) {
                              return InkWell(
                                onTap: () {
                                  setState(() {
                                    amountCtrl.text = e.toString();
                                    updateAmount();
                                  });
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 5, horizontal: 10),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: AppColor.grey2,
                                    ),
                                    shape: BoxShape.rectangle,
                                    color: AppColor.whiteColor,
                                    borderRadius: BorderRadius.circular(6.w),
                                  ),
                                  child: CustomText(
                                    text: "₹$e",
                                    color: AppColor.blackColor,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 25),
                        CustomText(
                          text: "Payment Method",
                          color: AppColor.blackColor,
                          fontSize: AppFontSize.size3.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final method in [
                              ['Bank Transfer'],
                              ['UPI', 'Cash'],
                              ['Bank Remittance']
                            ])
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: method
                                    .map((m) => Expanded(
                                          child: InkWell(
                                            borderRadius:
                                                BorderRadius.circular(12.r),
                                            onTap: () {
                                              debugPrint(m);
                                              if (amountCtrl.text == "0" ||
                                                  amountCtrl.text == "0.0" ||
                                                  amountCtrl.text
                                                          .removeAllWhitespace ==
                                                      "") {
                                                Get.snackbar(
                                                  'Top up amount',
                                                  'Please , enter a valid Topup amount',
                                                  colorText:
                                                      AppColor.whiteColor,
                                                  padding: EdgeInsets.all(15.w),
                                                  backgroundColor:
                                                      AppColor.primaryColor,
                                                );
                                              } else {
                                                setState(() {
                                                  selectedPaymentMethod = m;
                                                  for (var i = 0;
                                                      i <
                                                          dashboardController
                                                              .payModeList
                                                              .length;
                                                      i++) {
                                                    if (dashboardController
                                                            .payModeList[i]
                                                            .paymode
                                                            .toLowerCase()
                                                            .removeAllWhitespace ==
                                                        m
                                                            .toLowerCase()
                                                            .removeAllWhitespace) {
                                                      selectedPaymodeId =
                                                          dashboardController
                                                              .payModeList[i]
                                                              .paymodeId;
                                                    }
                                                  }
                                                });
                                                _openBottomSheetForMethod(
                                                    m, selectedPaymodeId);
                                              }
                                            },
                                            child: Container(
                                              margin: EdgeInsets.symmetric(
                                                  horizontal: 15.w,
                                                  vertical: 5.w),
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 10.w),
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: Colors.grey),
                                                borderRadius:
                                                    BorderRadius.circular(12.r),
                                                color: Colors.white,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 15.w),
                                                    child: CustomText(
                                                      text: m,
                                                      fontSize:
                                                          AppFontSize.size4.sp,
                                                    ),
                                                  ),
                                                  // if (selectedPaymentMethod == m || completedPayments.contains(m))
                                                  // if (paymentConfirmed[m] == true)
                                                  //   Padding(
                                                  //     padding: const EdgeInsets.only(right: 8.0),
                                                  //     child: Container(
                                                  //       decoration: const BoxDecoration(
                                                  //         shape: BoxShape.circle,
                                                  //         color: Colors.green,
                                                  //       ),
                                                  //       child: const Icon(
                                                  //         Icons.check,
                                                  //         color: Colors.white,
                                                  //         size: 25.0,
                                                  //       ),
                                                  //     ),
                                                  //   ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ))
                                    .toList(),
                              ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: AppColor.grey3,
                              borderRadius: BorderRadius.circular(12.r)),
                          margin: const EdgeInsets.all(5),
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    text: "Amount Payable",
                                    color: AppColor.primaryColor,
                                    fontSize: AppFontSize.size4.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  CustomText(
                                    // text: "₹${payableAmount}",
                                    text: currencyFormat.format(totalPayable),
                                    color: AppColor.green,
                                    fontSize: AppFontSize.size3.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ],
                              ),
                              if (paymentDetails.isNotEmpty) const Divider(),
                              SizedBox(
                                height: 10.w,
                              ),
                              Column(
                                children: List.generate(paymentDetails.length,
                                    (int historyIndex) {
                                  String mode = paymentDetails[historyIndex]
                                      ["paymodeOriginal"];

                                  return ListTile(
                                      contentPadding: EdgeInsets.zero,
                                      title: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            flex: 35,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Flexible(
                                                      flex: 70,
                                                      child: CustomText(
                                                        text: "$mode:",
                                                        color:
                                                            AppColor.blackColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        maxLines: 2,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        fontSize: AppFontSize
                                                            .size5.sp,
                                                      ),
                                                    ),
                                                    if (mode.toUpperCase() ==
                                                            'UPI' ||
                                                        mode
                                                                .toLowerCase()
                                                                .removeAllWhitespace ==
                                                            'bankremittance')
                                                      if (mode.toUpperCase() ==
                                                              'UPI' ||
                                                          mode
                                                                  .toLowerCase()
                                                                  .removeAllWhitespace ==
                                                              'bankremittance')
                                                        // InkWell(
                                                        //   onTap: () {
                                                        //     _showImageDialog(
                                                        //         context,
                                                        //         paymentDetails[
                                                        //                 historyIndex]
                                                        //             [
                                                        //             "DocumentID"]);
                                                        //   },
                                                        //   child:
                                                        Flexible(
                                                          flex: 30,
                                                          child: Image.asset(
                                                            'assets/file_image.png', // Replace with your asset path
                                                            scale: 1.5,
                                                          ),
                                                        ),
                                                    // ),
                                                  ],
                                                ),
                                                CustomText(
                                                  text: userDateFormartion(
                                                      paymentDetails[
                                                              historyIndex]
                                                          ["transactionDate"]),
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize:
                                                      AppFontSize.size5.sp,
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(width: 5.w),
                                          Expanded(
                                            flex: 40,
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                if (paymentDetails[historyIndex]
                                                        ["fromLedgerName"] !=
                                                    null)
                                                  CustomText(
                                                    text:
                                                        "From : ${paymentDetails[historyIndex]["fromLedgerName"]}",
                                                    color: AppColor.black2Color,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize:
                                                        AppFontSize.size5.sp,
                                                  ),
                                                if (paymentDetails[historyIndex]
                                                        ["toLedgerName"] !=
                                                    null)
                                                  CustomText(
                                                    text:
                                                        "To : ${paymentDetails[historyIndex]["toLedgerName"]}",
                                                    color: AppColor.black2Color,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize:
                                                        AppFontSize.size5.sp,
                                                  ),
                                                if (paymentDetails[historyIndex]
                                                        ["transactionNo"] !=
                                                    null)
                                                  CustomText(
                                                    text:
                                                        "#${paymentDetails[historyIndex]["transactionNo"]}",
                                                    color: AppColor.black2Color,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize:
                                                        AppFontSize.size5.sp,
                                                  ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 25,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                CustomText(
                                                  text:
                                                      " ₹${paymentDetails[historyIndex]["amount"]}",
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize:
                                                      AppFontSize.size4.sp,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
                                      trailing: InkWell(
                                        borderRadius:
                                            BorderRadius.circular(12.r),
                                        onTap: () {
                                          removePayment(
                                              paymentDetails[historyIndex]
                                                  ['paymodeType']);
                                        },
                                        child: const Icon(Icons.cancel,
                                            color: Colors.red),
                                      )

                                      // SizedBox(
                                      //   width: 20.w,
                                      //   child: IconButton(
                                      //     icon: const Icon(Icons.cancel,
                                      //         color: Colors.red),
                                      //     onPressed: () {
                                      //       removePayment(
                                      //           paymentDetails[historyIndex]
                                      //               ['paymodeType']);
                                      //     },
                                      //     // onPressed: () => removePayment(mode),
                                      //   ),
                                      // ),
                                      );
                                }),
                              ),
                              if (paymentDetails.isNotEmpty) const Divider(),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    text: "Amount Paid",
                                    color: AppColor.primaryColor,
                                    fontSize: AppFontSize.size4.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  CustomText(
                                    text: currencyFormat.format(paidAmount),
                                    color: AppColor.green,
                                    fontSize: AppFontSize.size4.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.w,
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  CustomText(
                                    text: "Balance",
                                    color: AppColor.primaryColor,
                                    fontSize: AppFontSize.size4.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  CustomText(
                                    text: currencyFormat.format(balance),
                                    color: AppColor.redColor,
                                    fontSize: AppFontSize.size4.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 25.0),
                      child: InkWell(
                        child: OutButton(
                          onTap: () {
                            // Close any active snackbar before navigating back
                            try {
                              Get.closeCurrentSnackbar();
                            } catch (e) {
                              // Ignore snackbar close errors
                            }
                            Get.back();
                          },
                          withArrow: false,
                          text: "Back",
                          verticalPadding: 10.w,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 25.w,
                  ),
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 25.0),
                      child: InkWell(
                        child: InButton(
                          onTap: () async {
                            if ((int.tryParse(amountCtrl.text) ?? 0) == 0 ||
                                amountCtrl.text.removeAllWhitespace == "") {
                              Get.snackbar(
                                'Top-Up Amount',
                                'Please enter a valid Topup amount',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                            } else if ((int.tryParse(amountCtrl.text) ?? 0) <
                                500) {
                              Get.snackbar(
                                'Top-Up Amount',
                                'The minimum top-up amount is ₹500. Please enter a higher amount.',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                            } else if (!paymentDone) {
                              Get.snackbar(
                                'Payment',
                                'Payment is not done',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                            } else if ((paymentDone && balance != 0) ||
                                (paidAmount !=
                                    (double.tryParse(amountCtrl.text) ?? 0))) {
                              Get.snackbar(
                                'Amount Tally',
                                'Amount is not tallied',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                            } else {
                              debugPrint("Else");
                              final body = {
                                "walletAmount": amountCtrl.text,
                                "paymentItems": paymentDetails,
                              };

                              // log(body.toString());

                              // call api
                              PleaseWaitLoader.openDialog();
                              final bool isTopUpAdded =
                                  await dashboardController.submitWalletTop(
                                      body: body);
                              PleaseWaitLoader.closeDialog();
                              if (isTopUpAdded) {
                                // succes message
                                debugPrint("Topup added");
                                // Close any active snackbar before navigating back
                                try {
                                  Get.closeCurrentSnackbar();
                                } catch (e) {
                                  // Ignore snackbar close errors
                                }
                                Get.back();
                                showSuccessDialog(
                                    context: Get.context!,
                                    message:
                                        'Wallet topup request send successfully');
                              }
                            }
                            // prepare json to send
                          },
                          withArrow: false,
                          text: "Submit",
                          color: AppColor.primaryColor,
                          verticalPadding: 10.w,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /* void _showImageDialog(BuildContext context, paymentDetail) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Row for the heading and close button
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "UPI", // Heading text
                      style: TextStyle(
                        fontSize: AppFontSize.size2.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: AppColor.deleteRed),
                      onPressed: () {
                        Navigator.of(context).pop(); // Close the dialog
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () async {
                        // Get.to(const WalletTopupScreen());
                        PleaseWaitLoader.openDialog();
                        // Download document API
                        bool isDownloaded =
                            await dashboardController.documentDownload(
                          documentID: paymentDetail.toString(),
                        );
                        PleaseWaitLoader.closeDialog();
                        if (!isDownloaded ||
                            dashboardController
                                .latestDownloadedDocument.isEmpty) {
                          FileDownloadHelper.showToast(
                              "Failed to Download", AppColor.redColor);

                          return;
                        }
                        String base64Image = dashboardController
                            .latestDownloadedDocument[0].profileBase64;
                        String fileName = dashboardController
                            .latestDownloadedDocument[0].fileName;
                        String mimeType = dashboardController
                            .latestDownloadedDocument[0].mimeType;
                        if (fileName.isEmpty || base64Image.isEmpty) {
                          FileDownloadHelper.showToast(
                              "Something went wrong", AppColor.redColor);

                          return;
                        }
                        int sdkVersion =
                            await FileDownloadHelper.getAndroidSdkVersion();
                        if (sdkVersion >= 29) {
                          debugPrint("Android 10 or above detected");
                          bool result = await FileDownloadHelper.scopedDownload(
                              fileName, base64Image, mimeType);
                          FileDownloadHelper.showToast(
                              result
                                  ? "Downloaded Successfully"
                                  : "Failed to Download",
                              result ? AppColor.green : AppColor.redColor);
                        } else {
                          // Handle download path for legacy storage if needed
                          debugPrint("Below Android 10 detected");
                          bool result = await FileDownloadHelper.directDownload(
                              base64Image, fileName);
                          FileDownloadHelper.showToast(
                              result
                                  ? "Downloaded Successfully"
                                  : "Failed to Download",
                              result ? AppColor.green : AppColor.redColor);
                        }
                      },
                      child: Container(
                        height: 45, // Reduced height
                        width: 45, // Reduced width
                        alignment: Alignment.center,
                        child: Image.asset(
                          AssetPath.wallet,
                          fit: BoxFit
                              .contain, // Ensures the image fits inside the container
                          scale: 3.0, // Adjust scale for better control
                        ),
                      ),
                    ),
                  ],
                ),
                // Space between heading and image
                // The image inside the dialog
                // Image.memory(
                //   base64Decode(base64Image),
                //   width: 300,
                //   height: 300,
                //   fit: BoxFit.cover,
                // ),
              ],
            ),
          ),
        );
      },
    );
  } */
}
