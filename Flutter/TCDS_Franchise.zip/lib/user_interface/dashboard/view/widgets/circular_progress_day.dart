import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/font_sizes.dart';
import '../../../../constants/colors.dart';
import '../../../../utils/helper_widgets/custom_text.dart';

class CircularProgressDay extends StatelessWidget {
  final double progressValue;
  final int remainingDays;
  final int totalDays;
  final Color? primaryColor;
  final Color? secondaryColor;
  final double? progressBarSize;
  const CircularProgressDay(
      {super.key,
      required this.progressValue,
      required this.remainingDays,
      this.primaryColor,
      this.secondaryColor,
      this.progressBarSize,
      required this.totalDays});

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        SizedBox(
          width: progressBarSize ?? 60.w,
          height: progressBarSize ?? 60.w,
          child: CircularProgressIndicator(
            value: progressValue,
            backgroundColor: secondaryColor ?? AppColor.skyBlue,
            strokeWidth: 8,
            valueColor: AlwaysStoppedAnimation<Color>(
                primaryColor ?? AppColor.blueColor),
          ),
        ),
        SizedBox(
          width: (progressBarSize ?? 60.w) * 0.8,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomText(
                text: remainingDays.toString(),
                fontSize: AppFontSize.size5.sp,
                fontWeight: FontWeight.w600,
                color: remainingDays < 10
                    ? AppColor.redColor
                    : AppColor.blackColor,
                textAlign: TextAlign.start,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(
                width: (progressBarSize ?? 60.w) * 0.7,
                child: Divider(
                  color: primaryColor,
                  height: 4,
                  thickness: 1,
                ),
              ),
              CustomText(
                text: "$totalDays days",
                fontSize: AppFontSize.size6.sp,
                fontWeight: FontWeight.w400,
                color: AppColor.blackColor,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
