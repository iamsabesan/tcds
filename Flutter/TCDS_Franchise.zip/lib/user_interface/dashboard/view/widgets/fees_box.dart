import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/font_sizes.dart';
import '../../../../constants/colors.dart';
import '../../../../utils/helper_widgets/custom_text.dart';

class FeesBox extends StatelessWidget {
  final NumberFormat currencyFormat;
  final String title;
  final double regular;
  final double online;
  final double total;
  const FeesBox(
      {super.key,
      required this.currencyFormat,
      required this.title,
      required this.regular,
      required this.online,
      required this.total});

  @override
  Widget build(BuildContext context) {
    // Colors
    final greyAlpha120 = AppColor.grey.withAlpha(120);
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(12.r)),
          border: Border.all(color: greyAlpha120)),
      child: Column(
        children: [
          Container(
            clipBehavior: Clip.antiAlias,
            padding: const EdgeInsets.all(10),
            alignment: Alignment.center,
            width: double.infinity,
            decoration: BoxDecoration(
              color: AppColor.pinkLight1,
              borderRadius: BorderRadius.vertical(top: Radius.circular(12.r)),
            ),
            child: CustomText(
              text: title,
              fontWeight: FontWeight.w500,
              color: AppColor.blackColor,
            ),
          ),
          Divider(
            color: greyAlpha120,
            height: 0,
          ),
          Padding(
            padding: const EdgeInsets.all(6),
            child: Column(
              children: [
                _pairText(
                    currencyFormat: currencyFormat,
                    key: "Regular",
                    value: regular,
                    valueColor: AppColor.blueColor),
                const SizedBox(
                  height: 5,
                ),
                _pairText(
                    currencyFormat: currencyFormat,
                    key: "Online",
                    value: online,
                    valueColor: AppColor.red2),
                const SizedBox(
                  height: 5,
                ),
                _pairText(
                    currencyFormat: currencyFormat,
                    key: "Total",
                    value: total,
                    valueColor: AppColor.green),
              ],
            ),
          )
        ],
      ),
    );
  }
}

Widget _pairText({
  required String key,
  required double value,
  Color? valueColor,
  required NumberFormat currencyFormat,
}) {
  return Row(
    children: [
      Expanded(
        flex: 35,
        child: CustomText(
          text: key,
          fontWeight: FontWeight.w400,
          fontSize: AppFontSize.size6.sp,
        ),
      ),
      Expanded(
        flex: 65,
        child: CustomText(
          textAlign: TextAlign.center,
          text: value.toStringAsFixed(0),
          fontWeight: FontWeight.w500,
          color: valueColor,
          fontSize: AppFontSize.size5.sp,
        ),
      ),
    ],
  );
}
