import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../utils/helper_widgets/custom_text.dart';

class FromToDate extends StatelessWidget {
  final Color fromColor;
  final Color toColor;
  final Color? textColor;
  final String fromDate;
  final String toDate;
  final bool verticalDirection;

  const FromToDate(
      {super.key,
      required this.fromColor,
      required this.toColor,
      required this.fromDate,
      required this.toDate,
      this.textColor,
      this.verticalDirection = false});

  @override
  Widget build(BuildContext context) {
    return verticalDirection
        ? Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _dateChip(color: fromColor, text: fromDate, textColor: textColor),
              IntrinsicHeight(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minHeight: 15),
                  child: VerticalDivider(
                    color: fromColor,
                  ),
                ),
              ),
              Icon(
                Icons.calendar_month,
                size: 20.w,
                color: fromColor,
              ),
              IntrinsicHeight(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(minHeight: 15),
                  child: VerticalDivider(
                    color: toColor,
                  ),
                ),
              ),
              _dateChip(
                  color: toColor,
                  text: toDate,
                  textColor: textColor,
                  topBorder: false),
            ],
          )
        : Row(
            children: [
              _dateChip(color: fromColor, text: fromDate, textColor: textColor),
              Flexible(
                child: Divider(
                  color: fromColor,
                ),
              ),
              Icon(
                Icons.calendar_month,
                size: 20.w,
                color: fromColor,
              ),
              Flexible(
                child: Divider(
                  color: toColor,
                ),
              ),
              _dateChip(
                  color: toColor,
                  text: toDate,
                  textColor: textColor,
                  topBorder: false),
            ],
          );
  }
}

// WIDGET: Chip like design to show dates
Widget _dateChip({
  required Color color,
  Color? textColor,
  required String text,
  bool topBorder = true,
}) {
  return Container(
    padding: const EdgeInsets.all(6),
    decoration: BoxDecoration(
      color: color.withAlpha(80),
      border: Border(
        top: topBorder ? BorderSide(color: color, width: 4) : BorderSide.none,
        bottom:
            !topBorder ? BorderSide(color: color, width: 4) : BorderSide.none,
      ),
      borderRadius: BorderRadius.circular(12.r),
    ),
    child: CustomText(
      text: text,
      fontSize: 10.sp,
      color: textColor ?? Colors.black,
      fontWeight: FontWeight.w500,
    ),
  );
}
