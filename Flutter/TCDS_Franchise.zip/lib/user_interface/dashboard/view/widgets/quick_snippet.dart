import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import '../../../../constants/font_sizes.dart';
import '../../../../utils/helper_widgets/custom_text.dart';

class QuickSnippet extends StatelessWidget {
  final Color bgColor;
  final String title;
  final Color headerBgColor;
  final Widget child;
  final double width;
  final void Function()? onTap;
  const QuickSnippet(
      {super.key,
      required this.bgColor,
      required this.headerBgColor,
      required this.child,
      required this.title,
      this.width = 200,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return Ink(
      width: width,
      decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(12.r),
          boxShadow: const [
            BoxShadow(
                color: AppColor.grey,
                blurRadius: 3,
                spreadRadius: 1,
                offset: Offset(2, 2))
          ]),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12.r),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: headerBgColor,
                borderRadius: BorderRadius.vertical(top: Radius.circular(12.r)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      text: title,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size5.sp,
                      color: AppColor.whiteColor,
                    ),
                    Container(
                      decoration:
                          BoxDecoration(color: bgColor, shape: BoxShape.circle),
                      child: const Icon(
                        Icons.navigate_next_rounded,
                        size: 20,
                      ),
                    )
                  ],
                ),
              ),
            ),
            child,
          ],
        ),
      ),
    );
  }
}
