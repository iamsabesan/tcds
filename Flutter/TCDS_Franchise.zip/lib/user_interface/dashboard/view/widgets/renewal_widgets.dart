import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/wallet_topup_screen.dart';
import '../../../../constants/colors.dart';
import '../../../../utils/helper_widgets/custom_text.dart';
import '../../../renewal/ui/approval_renewal_page.dart';
import '../../../renewal/ui/subscription_renewal_page.dart';
import '../../model/dashboard_detail_model.dart';
import 'circular_progress_day.dart';
import 'from_to_date.dart';
import 'quick_snippet.dart';

// WIDGET: package of all required widgets for to show Approwal renewal
class ApprovalRenewalWidget extends StatefulWidget {
  final DashboardDetailData dashboardDetailData;
  const ApprovalRenewalWidget({super.key, required this.dashboardDetailData});

  @override
  State<ApprovalRenewalWidget> createState() => _ApprovalRenewalWidgetState();
}

class _ApprovalRenewalWidgetState extends State<ApprovalRenewalWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    return QuickSnippet(
      onTap: () => Get.to(() => const ApprovalRenewalPage(),
          transition: Transition.rightToLeft,
          duration: const Duration(milliseconds: 600)),
      width: width,
      bgColor: AppColor.blue2,
      headerBgColor: AppColor.blueColor,
      title: "Approval Renewal",
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressDay(
                  progressBarSize: 95.w,
                  progressValue:
                      widget.dashboardDetailData.approvalCompletedDays /
                          widget.dashboardDetailData.approvalTotalDays,
                  remainingDays:
                      widget.dashboardDetailData.approvalRemainingDays,
                  totalDays: widget.dashboardDetailData.approvalTotalDays,
                ),
                SizedBox(
                  width: width * 0.4,
                  child: FromToDate(
                      verticalDirection: true,
                      fromColor: AppColor.green,
                      toColor: AppColor.sandalDark,
                      fromDate: widget.dashboardDetailData.approvalStartDate,
                      toDate: widget.dashboardDetailData.approvalEndDate),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            if (widget.dashboardDetailData.approvalRemainingDays < 10)
              const ExpireSoon(),

            //
          ],
        ),
      ),
    );
  }
}

// WIDGET : Expiring soon widget
class ExpireSoon extends StatefulWidget {
  const ExpireSoon({super.key});

  @override
  State<ExpireSoon> createState() => _ExpireSoonState();
}

class _ExpireSoonState extends State<ExpireSoon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..repeat(reverse: true);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
        animation: _controller,
        builder: (BuildContext context, Widget? child) {
          return Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              // color: Colors.red.shade100,
              gradient: LinearGradient(
                colors: const [
                  AppColor.redShade200,
                  AppColor.redShade100,
                  AppColor.redShade200
                ],
                stops: [0, _controller.value, 1],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.warning, color: Colors.red),
                SizedBox(width: 6),
                Text("Expiring soon!",
                    style: TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold)),
              ],
            ),
          );
        });
  }
}

// WIDGET : package of widgets to show subscription renewal details
class SubscriptionRenewalWidget extends StatelessWidget {
  final DashboardDetailData dashboardDetailData;
  const SubscriptionRenewalWidget(
      {super.key, required this.dashboardDetailData});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    return QuickSnippet(
      onTap: () => Get.to(() => const SubscriptionRenewalPage(),
          transition: Transition.rightToLeft,
          duration: const Duration(milliseconds: 600)),
      width: width * 0.47,
      bgColor: AppColor.tealLight,
      headerBgColor: Colors.teal,
      title: "Subscription Renewal",
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            CircularProgressDay(
              progressBarSize: 80.w,
              primaryColor: Colors.teal,
              secondaryColor: Colors.teal[100] ?? AppColor.green2,
              progressValue: dashboardDetailData.subscriptionCompletedDays /
                  dashboardDetailData.subscriptionTotalDays,
              remainingDays: dashboardDetailData.subscriptionRemainingDays,
              totalDays: dashboardDetailData.subscriptionTotalDays,
            ),
            const SizedBox(
              height: 20,
            ),
            FromToDate(
                fromColor: AppColor.green,
                toColor: AppColor.sandalDark,
                fromDate: dashboardDetailData.subscriptionStartDate,
                toDate: dashboardDetailData.subscriptionEndDate),
            const SizedBox(
              height: 15,
            ),
            if (dashboardDetailData.subscriptionRemainingDays < 10)
              const ExpireSoon(),

            //
          ],
        ),
      ),
    );
  }
}

// WIDGET :  wallet renewal
class WalletRenewalWidget extends StatelessWidget {
  final DashboardDetailData dashboardDetailData;

  const WalletRenewalWidget({super.key, required this.dashboardDetailData});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width;
    NumberFormat currencyFormat =
        NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);
    return QuickSnippet(
      onTap: () {
        Get.to(() => const WalletTopupScreen(),
            transition: Transition.rightToLeft,
            duration: const Duration(milliseconds: 600));
      },
      width: width * 0.4,
      bgColor: AppColor.orangeShade,
      headerBgColor: AppColor.orange,
      title: "Wallet Balance",
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Icon(
              Icons.wallet_rounded,
              color: AppColor.orange,
              size: 75.w,
            ),
            const SizedBox(
              height: 15,
            ),
            CustomText(
              text: currencyFormat.format(dashboardDetailData.walletBalance),
              fontWeight: FontWeight.w500,
              fontSize: (AppFontSize.size1 + 5).sp,
            ),
            const SizedBox(
              height: 15,
            ),
          ],
        ),
      ),
    );
  }
}
