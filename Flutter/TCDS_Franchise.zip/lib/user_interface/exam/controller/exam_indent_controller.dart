// import 'dart:convert';
// import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/exam/model/certificate_tracking_response_model.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../dashboard/model/profile_image_response_model.dart';
import '../model/batch_student_list_model.dart';
import '../model/course_batch_list_model.dart';

class ExamIndentController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxList<CertificateTrackingList> certificateTrackingList =
      <CertificateTrackingList>[].obs;
  RxBool certificateTrackingScreenLoader = false.obs;
  RxBool certificateTrackingListLoader = false.obs;

  // fetched image holder
  List<ProfileImageData> profileImageDataList = <ProfileImageData>[];
  RxList<BatchListData> batchDataList = <BatchListData>[].obs;
  RxList<BatchStudentData> batchStudentDataList = <BatchStudentData>[].obs;

  Future<bool> getCertificateTracking(
      {required String status, String? fromDate, String? toDate}) async {
    bool resultValue = false;
    certificateTrackingListLoader.value = true;
    try {
      await engine
          .get(
              AppStrings.baseUrl +
                  AppStrings.getCertificateIndentTrackingUrl +
                  status +
                  ((fromDate != null && toDate != null)
                      ? "&fromDate=$fromDate&toDate=$toDate"
                      : ""),
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        CertificateTrackingResponseModel model =
            CertificateTrackingResponseModel.fromJson(value.data);
        certificateTrackingList.value = model.data;
        resultValue = true;
        certificateTrackingListLoader.value = false;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> certificateReceive({required dynamic body}) async {
    bool resultValue = false;

    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.certificateReceive, body)
          .then((value) {
        // ReceiveMaterialResponseModel model = ReceiveMaterialResponseModel.fromJson(value.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Get Profile picture
  Future<bool> getProfilePicture({required String contactID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getProfileImage + contactID,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        ProfileImageResponseModel model =
            ProfileImageResponseModel.fromJson(value.data);
        profileImageDataList = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      profileImageDataList.clear();
    }

    return resultValue;
  }

  Future<bool> getCourseBatchList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.batchDataUrl)
          .then((value) {
        // log(jsonEncode(value.data));
        CourseBatchListModel model = CourseBatchListModel.fromJson(value.data);
        batchDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getBatchStudentList({required String batchId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.batchStudentListUrl + batchId)
          .then((value) {
        // log(jsonEncode(value.data));
        BatchStudentListModel model =
            BatchStudentListModel.fromJson(value.data);
        batchStudentDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      // PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> updateMark({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.updateMarkUrl, body,
              protected: true)
          .then((value) {
        // WalletTopupResponseModel model =
        //     WalletTopupResponseModel.fromJson(value.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }
}
