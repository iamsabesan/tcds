class BatchMappingDetails {
  String batchMappingId;
  String courseName;
  String courseId;
  String batchName;
  String batchId;
  String studentId;
  int totalStudent;
  int indentStudent;
  double examFees;
  int semester ;
  String examDate;
  int? index;
  double? singleExamFees;

  BatchMappingDetails({
    required this.batchMappingId,
    required this.courseName,
    required this.courseId,
    required this.batchName,
    required this.batchId,
    required this.studentId,
    required this.totalStudent,
    required this.indentStudent,
    required this.examFees,
    required this.semester,
    required this.examDate,
    this.index,
    this.singleExamFees
  });

  factory BatchMappingDetails.fromJson(Map<String, dynamic> json) => BatchMappingDetails(
    batchMappingId: json["batchMappingId"],
    courseId: json["courseId"],
    courseName: json["courseName"],
    batchName: json["batchName"],
    batchId: json["batchId"],
    studentId: json["studentId"],
    totalStudent: json["totalStudent"],
    indentStudent: json["indentStudent"],
    examFees: json["examFees"],
    semester: json["semester"],
    examDate: json["examDate"],
    index: json["index"],
    singleExamFees: json["singleExamFees"],
  );

  Map<String, dynamic> toJson() => {
    "batchMappingId": batchMappingId,
    "courseName": courseName,
    "courseId": courseId,
    "batchName": batchName,
    "batchId": batchId,
    "studentId": studentId,
    "totalStudent": totalStudent,
    "indentStudent": indentStudent,
    "examFees": examFees,
    "semester": semester,
    "examDate": examDate,
    "index": index,
    "singleExamFees": singleExamFees,
  };
}