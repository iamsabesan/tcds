// To parse this JSON data, do
//
//     final batchStudentListModel = batchStudentListModelFromJson(jsonString);

import 'dart:convert';

BatchStudentListModel batchStudentListModelFromJson(String str) => BatchStudentListModel.fromJson(json.decode(str));

String batchStudentListModelToJson(BatchStudentListModel data) => json.encode(data.toJson());

class BatchStudentListModel {
  int code;
  String message;
  List<BatchStudentData> data;

  BatchStudentListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory BatchStudentListModel.fromJson(Map<String, dynamic> json) => BatchStudentListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<BatchStudentData>.from(json["Data"].map((x) => BatchStudentData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class BatchStudentData {
  String studentId;
  String examIndentTransId;
  String contactId;
  String studentName;
  String batchMappingId;
  String subjectMappingId;
  String subjectName;
  String rollNumber;
  String materialId;
  int semester;
  int theoryMarks;
  int practicalMarks;
  String status;

  BatchStudentData({
    required this.studentId,
    required this.examIndentTransId,
    required this.contactId,
    required this.studentName,
    required this.batchMappingId,
    required this.subjectMappingId,
    required this.subjectName,
    required this.rollNumber,
    required this.materialId,
    required this.semester,
    required this.theoryMarks,
    required this.practicalMarks,
    required this.status,
  });

  factory BatchStudentData.fromJson(Map<String, dynamic> json) => BatchStudentData(
    studentId: json["StudentID"],
    examIndentTransId: json["ExamIndentTransID"],
    contactId: json["ContactID"],
    studentName: json["StudentName"],
    batchMappingId: json["BatchMappingID"],
    subjectMappingId: json["SubjectMappingID"],
    subjectName: json["SubjectName"],
    rollNumber: json["RollNumber"],
    materialId: json["MaterialID"],
    semester: json["Semester"],
    theoryMarks: json["TheoryMarks"],
    practicalMarks: json["PracticalMarks"],
    status: json["Status"],
  );

  Map<String, dynamic> toJson() => {
    "StudentID": studentId,
    "ExamIndentTransID": examIndentTransId,
    "ContactID": contactId,
    "StudentName": studentName,
    "BatchMappingID": batchMappingId,
    "SubjectMappingID": subjectMappingId,
    "SubjectName": subjectName,
    "RollNumber": rollNumber,
    "MaterialID": materialId,
    "Semester": semester,
    "TheoryMarks": theoryMarks,
    "PracticalMarks": practicalMarks,
    "Status": status,
  };
}
