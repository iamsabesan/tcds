import 'dart:convert';

CertificateTrackingResponseModel certificateTrackingResponseModelFromJson(
        String str) =>
    CertificateTrackingResponseModel.fromJson(json.decode(str));

String certificateTrackingResponseModelToJson(
        CertificateTrackingResponseModel data) =>
    json.encode(data.toJson());

class CertificateTrackingResponseModel {
  int code;
  String message;
  List<CertificateTrackingList> data;

  CertificateTrackingResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CertificateTrackingResponseModel.fromJson(
          Map<String, dynamic> json) =>
      CertificateTrackingResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<CertificateTrackingList>.from(
            json["Data"].map((x) => CertificateTrackingList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CertificateTrackingList {
  String certificateIndentId;
  String tenantBranchId;
  String indentNumber;
  String indentDate;
  int totalStudents;
  int orderedMarksheet;
  int despatchedMarksheet;
  int receivedMarksheet;
  int pendingMarksheet;
  int orderedCertificate;
  int despatchedCertificate;
  int receivedCertificate;
  int pendingCertificate;
  String status;
  List<IndentTran> indentTrans;

  CertificateTrackingList({
    required this.certificateIndentId,
    required this.tenantBranchId,
    required this.indentNumber,
    required this.indentDate,
    required this.totalStudents,
    required this.orderedMarksheet,
    required this.despatchedMarksheet,
    required this.receivedMarksheet,
    required this.pendingMarksheet,
    required this.orderedCertificate,
    required this.despatchedCertificate,
    required this.receivedCertificate,
    required this.pendingCertificate,
    required this.status,
    required this.indentTrans,
  });

  factory CertificateTrackingList.fromJson(Map<String, dynamic> json) =>
      CertificateTrackingList(
        certificateIndentId: json["CertificateIndentID"],
        tenantBranchId: json["TenantBranchID"],
        indentNumber: json["IndentNumber"],
        indentDate: json["IndentDate"],
        totalStudents: json["TotalStudents"],
        orderedMarksheet: json["OrderedMarksheet"],
        despatchedMarksheet: json["DespatchedMarksheet"],
        receivedMarksheet: json["ReceivedMarksheet"],
        pendingMarksheet: json["PendingMarksheet"],
        orderedCertificate: json["OrderedCertificate"],
        despatchedCertificate: json["DespatchedCertificate"],
        receivedCertificate: json["ReceivedCertificate"],
        pendingCertificate: json["PendingCertificate"],
        status: json["Status"],
        indentTrans: List<IndentTran>.from(
            json["IndentTrans"].map((x) => IndentTran.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CertificateIndentID": certificateIndentId,
        "TenantBranchID": tenantBranchId,
        "IndentNumber": indentNumber,
        "IndentDate": indentDate,
        "TotalStudents": totalStudents,
        "OrderedMarksheet": orderedMarksheet,
        "DispatchedMarksheet": despatchedMarksheet,
        "ReceivedMarksheet": receivedMarksheet,
        "PendingMarksheet": pendingMarksheet,
        "OrderedCertificate": orderedCertificate,
        "DespatchedCertificate": despatchedCertificate,
        "ReceivedCertificate": receivedCertificate,
        "PendingCertificate": pendingCertificate,
        "Status": status,
        "IndentTrans": List<dynamic>.from(indentTrans.map((x) => x.toJson())),
      };
}

class IndentTran {
  String certificateAndMarksheetId;
  String examIndentTransId;
  String certificateIndentId;
  String contactId;
  String printType;
  String status;
  String deliveryModeId;
  String deliveryMode;
  String trackingId;
  String studentName;
  String rollNumber;
  String course;
  String semester;
  String dispatchDate;
  String receivedDate;
  String issuedDate;

  IndentTran({
    required this.certificateAndMarksheetId,
    required this.examIndentTransId,
    required this.certificateIndentId,
    required this.contactId,
    required this.printType,
    required this.status,
    required this.deliveryModeId,
    required this.deliveryMode,
    required this.trackingId,
    required this.studentName,
    required this.rollNumber,
    required this.course,
    required this.semester,
    required this.dispatchDate,
    required this.receivedDate,
    required this.issuedDate,
  });

  factory IndentTran.fromJson(Map<String, dynamic> json) => IndentTran(
        certificateAndMarksheetId: json["CertificateAndMarksheetID"],
        examIndentTransId: json["ExamIndentTransID"],
        certificateIndentId: json["CertificateIndentID"],
        contactId: json["ContactID"],
        printType: json["PrintType"],
        status: json["Status"],
        deliveryModeId: json["DeliveryModeID"],
        deliveryMode: json["DeliveryMode"],
        trackingId: json["TrackingID"],
        studentName: json["StudentName"],
        rollNumber: json["RollNumber"],
        course: json["Course"],
        semester: json["Semester"],
        dispatchDate: json["DespatchDate"],
        receivedDate: json["ReceivedDate"],
        issuedDate: json["IssuedDate"],
      );

  Map<String, dynamic> toJson() => {
        "CertificateAndMarksheetID": certificateAndMarksheetId,
        "ExamIndentTransID": examIndentTransId,
        "CertificateIndentID": certificateIndentId,
        'ContactID': contactId,
        "PrintType": printType,
        "Status": status,
        "DeliveryModeID": deliveryModeId,
        "DeliveryMode": deliveryMode,
        "TrackingID": trackingId,
        "StudentName": studentName,
        "RollNumber": rollNumber,
        "Course": course,
        "Semester": semester,
        "DispatchDate": dispatchDate,
        "ReceivedDate": receivedDate,
        "IssuedDate": issuedDate,
      };
}
