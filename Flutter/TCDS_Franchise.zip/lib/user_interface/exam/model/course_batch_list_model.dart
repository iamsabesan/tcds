class CourseBatchListModel {
  int code;
  String message;
  List<BatchListData> data;

  CourseBatchListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourseBatchListModel.fromJson(Map<String, dynamic> json) =>
      CourseBatchListModel(
        code: json["Code"],
        message: json["Message"],
        data: List<BatchListData>.from(
            json["Data"].map((x) => BatchListData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class BatchListData {
  String courseBatchId;
  String batchNumber;
  String courseName;
  String facultyName;
  String facultyId;
  String timing;
  String batchType;
  String shortName;

  BatchListData({
    required this.courseBatchId,
    required this.batchNumber,
    required this.courseName,
    required this.facultyName,
    required this.facultyId,
    required this.timing,
    required this.batchType,
    required this.shortName,
  });

  factory BatchListData.fromJson(Map<String, dynamic> json) => BatchListData(
        courseBatchId: json["CourseBatchID"],
        batchNumber: json["BatchNumber"],
        courseName: json["CourseName"],
        facultyName: json["FacultyName"],
        facultyId: json["FacultyID"],
        timing: json["Timing"],
        batchType: json["BatchType"],
        shortName: json["ShortName"],
      );

  Map<String, dynamic> toJson() => {
        "CourseBatchID": courseBatchId,
        "BatchNumber": batchNumber,
        "CourseName": courseName,
        "FacultyName": facultyName,
        "FacultyID": facultyId,
        "Timing": timing,
        "BatchType": batchType,
        "ShortName": shortName
      };
}
