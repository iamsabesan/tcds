class FranchiseCourseBatchListModel {
  int code;
  String message;
  List<CourseBatchData> data;

  FranchiseCourseBatchListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseCourseBatchListModel.fromJson(Map<String, dynamic> json) =>
      FranchiseCourseBatchListModel(
        code: json["Code"],
        message: json["Message"],
        data: List<CourseBatchData>.from(
            json["Data"].map((x) => CourseBatchData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CourseBatchData {
  String batchNumber;
  String courseBatchId;
  String timing;
  String facultyId;
  String facultyName;
  String batchType;

  CourseBatchData({
    required this.batchNumber,
    required this.courseBatchId,
    required this.timing,
    required this.facultyId,
    required this.facultyName,
    required this.batchType,
  });

  factory CourseBatchData.fromJson(Map<String, dynamic> json) =>
      CourseBatchData(
        batchNumber: json["BatchNumber"],
        courseBatchId: json["CourseBatchID"],
        timing: json["Timing"],
        facultyId: json["FacultyID"],
        facultyName: json["FacultyName"],
        batchType: json["BatchType"],
      );

  Map<String, dynamic> toJson() => {
        "BatchNumber": batchNumber,
        "CourseBatchID": courseBatchId,
        "Timing": timing,
        "FacultyID": facultyId,
        "FacultyName": facultyName,
        "BatchType": batchType,
      };
}
