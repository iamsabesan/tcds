// To parse this JSON data, do
//
//     final franchiseCourseListModel = franchiseCourseListModelFromJson(jsonString);

import 'dart:convert';

FranchiseCourseListModel franchiseCourseListModelFromJson(String str) => FranchiseCourseListModel.fromJson(json.decode(str));

String franchiseCourseListModelToJson(FranchiseCourseListModel data) => json.encode(data.toJson());

class FranchiseCourseListModel {
  int code;
  String message;
  List<FranchiseCourseData> data;

  FranchiseCourseListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseCourseListModel.fromJson(Map<String, dynamic> json) => FranchiseCourseListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<FranchiseCourseData>.from(json["Data"].map((x) => FranchiseCourseData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class FranchiseCourseData {
  String courseId;
  String shortName;
  String course;
  String courseType;
  int semester;
  String duration;
  String durationType;
  String certificatePrintName;
  double courseFees;
  double examFees;
  double admissionFees;
  double totalFees;

  FranchiseCourseData({
    required this.courseId,
    required this.shortName,
    required this.course,
    required this.courseType,
    required this.semester,
    required this.duration,
    required this.durationType,
    required this.certificatePrintName,
    required this.courseFees,
    required this.examFees,
    required this.admissionFees,
    required this.totalFees,
  });

  factory FranchiseCourseData.fromJson(Map<String, dynamic> json) => FranchiseCourseData(
    courseId: json["CourseID"],
    shortName: json["ShortName"],
    course: json["Course"],
    courseType: json["CourseType"],
    semester: json["Semester"],
    duration: json["Duration"],
    durationType: json["DurationType"],
    certificatePrintName: json["CertificatePrintName"],
    courseFees: json["CourseFees"],
    examFees: json["ExamFees"],
    admissionFees: json["AdmissionFees"],
    totalFees: json["TotalFees"],
  );

  Map<String, dynamic> toJson() => {
    "CourseID": courseId,
    "ShortName": shortName,
    "Course": course,
    "CourseType": courseType,
    "Semester": semester,
    "Duration": duration,
    "DurationType": durationType,
    "CertificatePrintName": certificatePrintName,
    "CourseFees": courseFees,
    "ExamFees": examFees,
    "AdmissionFees": admissionFees,
    "TotalFees": totalFees,
  };
}
