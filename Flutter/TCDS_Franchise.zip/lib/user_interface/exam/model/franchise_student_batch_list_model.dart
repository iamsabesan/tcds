// To parse this JSON data, do
//
//     final franchiseStudentBatchListModel = franchiseStudentBatchListModelFromJson(jsonString);

import 'dart:convert';

FranchiseStudentBatchListModel franchiseStudentBatchListModelFromJson(String str) => FranchiseStudentBatchListModel.fromJson(json.decode(str));

String franchiseStudentBatchListModelToJson(FranchiseStudentBatchListModel data) => json.encode(data.toJson());

class FranchiseStudentBatchListModel {
  int code;
  String message;
  List<BatchStudentData> data;

  FranchiseStudentBatchListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseStudentBatchListModel.fromJson(Map<String, dynamic> json) => FranchiseStudentBatchListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<BatchStudentData>.from(json["Data"].map((x) => BatchStudentData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class BatchStudentData {
  String batchMappingId;
  String studentId;
  String contactName;
  String rollNumber;
  int semester;

  BatchStudentData({
    required this.batchMappingId,
    required this.studentId,
    required this.contactName,
    required this.rollNumber,
    required this.semester,
  });

  factory BatchStudentData.fromJson(Map<String, dynamic> json) => BatchStudentData(
    batchMappingId: json["BatchMappingID"],
    studentId: json["StudentID"],
    contactName: json["ContactName"],
    rollNumber: json["RollNumber"],
    semester: json["Semester"],
  );

  Map<String, dynamic> toJson() => {
    "BatchMappingID": batchMappingId,
    "StudentID": studentId,
    "ContactName": contactName,
    "RollNumber": rollNumber,
    "Semester": semester,
  };
}
