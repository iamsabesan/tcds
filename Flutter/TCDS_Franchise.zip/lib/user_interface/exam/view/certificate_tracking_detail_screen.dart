import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/exam/controller/exam_indent_controller.dart';
import 'package:tcds/utils/helper_functions/common_dialogs.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_widget_two.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import '../model/certificate_tracking_response_model.dart';

class CertificateTrackingDetailScreen extends StatefulWidget {
  final List<IndentTran> indentTrans;
  final String indentNumber;
  final String selectedStatus;

  const CertificateTrackingDetailScreen({
    super.key,
    required this.indentTrans,
    required this.indentNumber,
    required this.selectedStatus,
  });

  @override
  State<CertificateTrackingDetailScreen> createState() =>
      _CertificateTrackingDetailScreenState();
}

class _CertificateTrackingDetailScreenState
    extends State<CertificateTrackingDetailScreen> {
  // find controller
  ExamIndentController examIndentController = Get.find<ExamIndentController>();

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);

  // Process the grouped data into the desired format
  List<Map<String, dynamic>> dispatchedGroups = [];
  List<Map<String, dynamic>> receivedGroups = [];
  List<Map<String, dynamic>> pendingGroups = [];
  List<Map<String, dynamic>> selectedCertificates = [];

  Future<void> processIndentTrans(List<IndentTran> indentTrans) async {
    // Group IndentTrans by TrackingID
    final groupedData =
        groupBy(indentTrans, (IndentTran trans) => trans.trackingId);

    for (var entry in groupedData.entries) {
      String trackingID = entry.key;
      List<IndentTran> items = entry.value;

      // Initialize variables
      String deliveryPartner = items.first.deliveryMode;
      String dispatchedDate = items.first.dispatchDate.split(' ')[0];
      List<Map<String, dynamic>> groupItems = [];

      // Fetch profile pictures and prepare group items
      for (var item in items) {
        bool isImageFetched = await examIndentController.getProfilePicture(
            contactID: item.contactId);
        String? profileBase64 = (isImageFetched &&
                examIndentController.profileImageDataList.isNotEmpty)
            ? examIndentController.profileImageDataList.first.profileBase64
            : null;

        groupItems.add({
          "studentName": item.studentName,
          "studentRole": item.rollNumber,
          "printType": item.printType,
          "semester": item.semester,
          "base64": profileBase64,
          "isSelected": false,
          "examIndentTransID": item.examIndentTransId,
        });
      }

      // Determine the group based on the status
      Map<String, dynamic> groupData = {
        "trackingID": trackingID,
        "deliveryPartner": deliveryPartner,
        "dispatchedDate": dispatchedDate,
        "items": groupItems,
      };

      // Add the group data to the appropriate list

      if (items.any((item) => item.status.toUpperCase() == "DESPATCHED")) {
        dispatchedGroups.add(groupData);
      } else if (items.any((item) {
        final String statusAsUpp = item.status.toUpperCase();
        return (statusAsUpp == "RECEIVED" || statusAsUpp == "ISSUED");
      })) {
        receivedGroups.add(groupData);
      } else if (items.any((item) => item.status.toUpperCase() == "PENDING")) {
        pendingGroups.add(groupData);
      }
    }

    setState(() {});

    // Log or update state with the grouped data
    debugPrint('Despatched Groups: $dispatchedGroups');
    debugPrint('Received Groups: $receivedGroups');
    debugPrint('Pending Groups: $pendingGroups');
  }

  @override
  void initState() {
    processIndentTrans(widget.indentTrans);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColor.whiteColor,
        appBar: AppBar(
          elevation: 2,
          shadowColor: AppColor.black3Color,
          surfaceTintColor: AppColor.whiteColor,
          scrolledUnderElevation: 2,
          titleSpacing: 0,
          backgroundColor: AppColor.whiteColor,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_outlined),
            onPressed: () {
              Get.back();
            },
          ),
          title: CustomText(
            text: widget.indentNumber,
            fontSize: AppFontSize.size2,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(50.w), // Adjust height as needed

            child: Column(
              children: [
                TabBar(
                  labelColor: AppColor.blackColor,
                  indicatorColor: AppColor.orange,
                  dividerColor: AppColor.whiteColor,
                  tabs: [
                    Tab(
                        text:
                            "Despatched (${_calculateTotalQuantity(dispatchedGroups)})"),
                    Tab(
                        text:
                            "Received (${_calculateTotalQuantity(receivedGroups)})"),
                    Tab(
                        text:
                            "Pending (${_calculateTotalQuantity(pendingGroups)})"),
                  ],
                ),
              ],
            ),
          ),
        ),
        body: TabBarView(
          children: [
            dispatchedTab(),
            receivedTab(),
            pendingTab(),
          ],
        ),
      ),
    );
  }

  Widget dispatchedTab() {
    return Column(
      children: [
        SizedBox(
          height: 20.w,
        ),
        Expanded(
          child: dispatchedGroups.isEmpty
              ? Center(
                  child: Text(
                    "No Data Available",
                    style: TextStyle(
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w500,
                      color: AppColor.primaryColor,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: dispatchedGroups.length,
                  itemBuilder: (context, groupIndex) {
                    final group = dispatchedGroups[groupIndex];
                    return Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.w),
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(12.w),
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(15.r),
                              color: AppColor.grey3,
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomText(
                                        text:
                                            "Tracking ID: ${group['trackingID']}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size4,
                                        color: AppColor.blackColor,
                                      ),
                                      CustomText(
                                        text:
                                            "Dispatched : ${group['dispatchedDate']}",
                                        // text: "Delivery Partner: ${group['deliveryPartner']}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size4,
                                        color: AppColor.blackColor,
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      CustomText(
                                        text:
                                            "Delivery Partner: ${group['deliveryPartner']}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size4,
                                        color: AppColor.blackColor,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: (group["items"]
                                    as List<Map<String, dynamic>>)
                                .map((item) => Container(
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(15.r)),
                                      child: Column(
                                        children: [
                                          CheckboxListTile(
                                            contentPadding: EdgeInsets.zero,
                                            value: item["isSelected"],
                                            onChanged: (value) {
                                              setState(() {
                                                item["isSelected"] =
                                                    !item["isSelected"];
                                                if (item["isSelected"]) {
                                                  selectedCertificates.add(
                                                    {
                                                      "examIndentId": item[
                                                          "examIndentTransID"],
                                                      "printType":
                                                          item["printType"],
                                                    },
                                                  );
                                                } else {
                                                  selectedCertificates.removeWhere(
                                                      (element) =>
                                                          element[
                                                              "examIndentId"] ==
                                                          item[
                                                              "examIndentTransID"]
                                                      // {
                                                      //   "examIndentId": item["examIndentTransID"],
                                                      //   "printType": item["printType"],
                                                      // },
                                                      );
                                                }
                                                debugPrint(selectedCertificates
                                                    .toString());
                                              });
                                            },
                                            controlAffinity:
                                                ListTileControlAffinity.leading,
                                            // Ensures checkbox is on the left
                                            title: Column(
                                              children: [
                                                SizedBox(
                                                  width: 5.w,
                                                ),
                                                CustomWidgetTwo(
                                                  currencyFormat:
                                                      currencyFormat,
                                                  text1: item["studentName"],
                                                  text2: item["studentRole"],
                                                  text3: item["printType"],
                                                  withDivider: false,
                                                  withForwardArrow: false,
                                                  text4: item["semester"],
                                                  base64: item["base64"],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ))
                                .toList(),
                          )
                        ],
                      ),
                    );
                  },
                ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 130.w, vertical: 10.w),
          child: InButton(
            color: AppColor.primaryColor,
            onTap: _moveToReceived,
            text: "Receive",
            textColor: AppColor.whiteColor,
            withArrow: false,
            textSize: AppFontSize.size4,
          ),
        ),
      ],
    );
  }

  Widget receivedTab() {
    return receivedGroups.isEmpty
        ? Center(
            child: Text(
              "No Data Available",
              style: TextStyle(
                fontSize: AppFontSize.size4,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
              ),
            ),
          )
        : ListView(
            children: _buildGroupList(receivedGroups),
          );
  }

  Widget pendingTab() {
    return pendingGroups.isEmpty
        ? Center(
            child: Text(
              "No Data Available",
              style: TextStyle(
                fontSize: AppFontSize.size4,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
              ),
            ),
          )
        : ListView(
            children: _buildGroupList(pendingGroups),
          );
  }

  List<Widget> _buildGroupList(List<Map<String, dynamic>> groups) {
    return groups.map((group) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.w),
        child: Column(
            children: List.generate(
          group["items"].length,
          (itemindex) => Container(
            decoration:
                BoxDecoration(borderRadius: BorderRadius.circular(15.r)),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 5.w),
              child: Column(
                children: [
                  CustomWidgetTwo(
                    currencyFormat: currencyFormat,
                    text1: group["items"][itemindex]["studentName"],
                    text2: group["items"][itemindex]["studentRole"],
                    text3: group["items"][itemindex]["printType"],
                    withDivider: false,
                    withForwardArrow: false,
                    base64: group["items"][itemindex]["base64"],
                    text4: group["items"][itemindex]["semester"],
                  ),
                  /*   Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomText(
                                      text: item["name"],
                                      fontWeight: FontWeight.w500,
                                      fontSize: AppFontSize.size4,
                                      color: AppColor.primaryColor,
                                    ),
                                    CustomText(
                                      text: item["type"],
                                      fontWeight: FontWeight.w500,
                                      fontSize: AppFontSize.size4,
                                      color: AppColor.black2Color,
                                    ),
                                  ],
                                ),
                                Spacer(),
                                // Creates space between item details and quantity

                                CustomText(
                                  text: "${item['quantity']} Quantity",
                                  fontWeight: FontWeight.w500,
                                  fontSize: AppFontSize.size4,
                                  color: AppColor.black2Color,
                                ),
                              ],
                            ),*/
                  const Divider(
                    color: AppColor.greyColor,
                    thickness: 1.5,
                  )
                ],
              ),
            ),
          ),
        )),
      );
    }).toList();
  }

  //to receive certificate in ui

/*  void _moveToReceived() {
    setState(() {
      dispatchedGroups = dispatchedGroups
          .map((group) {
            final selectedItems = (group["items"] as List<Map<String, dynamic>>).where((item) => item["isSelected"] as bool).toList();
            if (selectedItems.isNotEmpty) {
              receivedGroups.add({
                "trackingID": group["trackingID"],
                "deliveryPartner": group["deliveryPartner"],
                "dispatchedDate": group["dispatchedDate"],
                "items": selectedItems,
              });
            }
            return {
              ...group,
              "items": (group["items"] as List<Map<String, dynamic>>).where((item) => !(item["isSelected"] as bool)).toList(),
            };
          })
          .where((group) => (group["items"] as List).isNotEmpty)
          .toList();
    });
  }*/

  void _moveToReceived() async {
    // Proceed if there are selected materials
    if (selectedCertificates.isNotEmpty) {
      // Prepare the data for the API call
      var body = selectedCertificates.map((item) {
        return {
          "examIndentTransID":
              item["examIndentId"], // Use the correct key for examIndentTransId
          "printType": item["printType"], // Use the correct key for printType
        };
      }).toList();

      // Debugging: Print the data being sent to the API
      debugPrint("Sending materialIndent data: $body");

      // Call the API to move materials to received
      bool apiResult =
          await examIndentController.certificateReceive(body: body);

      if (apiResult) {
        setState(() {
          // Update the dispatchedGroups to move selected items to received
          dispatchedGroups = dispatchedGroups
              .map((group) {
                final selectedItems =
                    (group["items"] as List<Map<String, dynamic>>)
                        .where((item) => item["isSelected"] as bool)
                        .toList();

                if (selectedItems.isNotEmpty) {
                  receivedGroups.add({
                    "trackingID": group["trackingID"],
                    "deliveryPartner": group["deliveryPartner"],
                    "dispatchedDate": group["dispatchedDate"],
                    "items": selectedItems,
                  });
                }

                // Update dispatchedGroups by removing selected items
                return {
                  ...group,
                  "items": (group["items"] as List<Map<String, dynamic>>)
                      .where((item) => !(item["isSelected"] as bool))
                      .toList(),
                };
              })
              .where((group) => (group["items"] as List).isNotEmpty)
              .toList();
        });

        // After successful API call and updating the groups, show a success message
        debugPrint("Materials received and updated.");
        showInformationDialog(
            context: Get.context!, message: "Received Successfully");
        Get.back();
        bool trackingApiResult =
            await examIndentController.getCertificateTracking(
          status: widget.selectedStatus,
        );
        if (trackingApiResult) {
          debugPrint("Material tracking data refreshed successfully.");
        } else {
          debugPrint("Failed to refresh material tracking data.");
        }
      } else {
        // Handle API failure (e.g., show a failure message)
        debugPrint("Failed to update received materials.");
      }
    } else {
      // No items selected, show a message
      debugPrint("No items selected to move to received.");
    }
  }

  int _calculateTotalQuantity(List<Map<String, dynamic>> groups) {
    int totalCount = 0;

    for (var group in groups) {
      totalCount += group["items"].length as int;
    }

    return totalCount;
  }
}
