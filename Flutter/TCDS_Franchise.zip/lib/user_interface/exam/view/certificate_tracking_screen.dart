import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/exam/controller/exam_indent_controller.dart';

import 'package:tcds/utils/helper_widgets/bullet_text.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import '../../../utils/helper_widgets/date_range_filter_section.dart';
import '../../../utils/helper_widgets/forward_arrow_widget.dart';
import '../model/certificate_tracking_response_model.dart';
import 'certificate_tracking_detail_screen.dart';

class CertificateTrackingScreen extends StatefulWidget {
  const CertificateTrackingScreen({super.key});

  @override
  State<CertificateTrackingScreen> createState() =>
      _CertificateTrackingScreenState();
}

class _CertificateTrackingScreenState extends State<CertificateTrackingScreen> {
  ExamIndentController examIndentController = Get.put(ExamIndentController());

  final List<String> statuses = ["Pending", "Despatched", "Received"];
  String selectedStatus = "Pending";

  // boolean helper for to show date filters when Status equals Recieved
  bool isReceived = false;

  TextEditingController fromDateController = TextEditingController();
  TextEditingController toDateController = TextEditingController();
  TextEditingController dateRangeController = TextEditingController();

  DateFormat apiDateFormat = DateFormat("yyyy-MM-dd");
  DateFormat userDateFormat = DateFormat("dd-MM-yyyy");

  DateTime now = DateTime.now();

  Future<void> getApiCall(String status) async {
    // if status is Received pass dates also
    if (isReceived) {
      if (fromDateController.text.isEmpty || toDateController.text.isEmpty) {
        toDateController.text = userDateFormat.format(now);
        String tempFromD =
            userDateFormat.format(DateTime(now.year, now.month, 1));
        fromDateController.text = tempFromD;
      }

      DateTime fromDate = userDateFormat.parse(fromDateController.text);
      DateTime toDate = userDateFormat.parse(toDateController.text);
      String paresedFromD = apiDateFormat.format(fromDate);
      String paresedToD = apiDateFormat.format(toDate);
      await examIndentController.getCertificateTracking(
        status: status,
        fromDate: paresedFromD,
        toDate: paresedToD,
      );
      return;
    }
    examIndentController.getCertificateTracking(
      status: selectedStatus,
    );
  }

  @override
  void initState() {
    getApiCall(selectedStatus);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        toolbarHeight: 70,
        titleSpacing: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Certificate/Marksheet Tracking',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 30.w,
          ),
          // Dropdown for status selection
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8.w, horizontal: 15.w),
            child: DropdownButtonFormField<String>(
              initialValue: selectedStatus,
              dropdownColor: AppColor.whiteColor,
              items: statuses.map((status) {
                return DropdownMenuItem(
                  value: status,
                  child: Text(status),
                );
              }).toList(),
              decoration: InputDecoration(
                labelText: "Select Status",
                labelStyle: const TextStyle(color: AppColor.blackColor),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black.withValues(alpha: 0.1),
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColor.primaryColor),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                border: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: AppColor.grey2,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
              ),
              borderRadius: BorderRadius.circular(10.0),
              style: const TextStyle(color: AppColor.blackColor),
              enableFeedback: true,
              onChanged: (newValue) {
                if (newValue != selectedStatus) {
                  setState(() {
                    // show Date pickers when status is in "Received"
                    selectedStatus = newValue!;
                    isReceived = selectedStatus == "Received";
                  });
                  getApiCall(selectedStatus);
                }
              },
              isExpanded: true,
            ),
          ),
          const SizedBox(height: 15),
          // Date filter section
          if (isReceived)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w),
              child: DateRangeFilterSection(
                fromDateController: fromDateController,
                toDateController: toDateController,
                dateRangeController: dateRangeController,
                searchOnTap: () => getApiCall(selectedStatus),
              ),
            ),
          const SizedBox(height: 15),
          Expanded(
            child: Obx(
              () {
                return examIndentController.certificateTrackingListLoader.value
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: AppColor.primaryColor,
                        ),
                      )
                    : examIndentController.certificateTrackingList.isEmpty
                        ? Center(
                            child: CustomText(
                              text: 'No data available',
                              fontWeight: FontWeight.w500,
                              color: AppColor.primaryColor,
                              fontSize: AppFontSize.size3,
                            ),
                          )
                        : ListView.builder(
                            itemCount: examIndentController
                                .certificateTrackingList.length,
                            itemBuilder: (context, index) {
                              return certificateTrackingWidget(
                                certificateData: examIndentController
                                    .certificateTrackingList[index],
                              );
                            },
                          );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget certificateTrackingWidget({
    required CertificateTrackingList certificateData,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 10.w),
      child: Column(
        children: [
          InkWell(
            onTap: () {
              Get.to(
                  () => CertificateTrackingDetailScreen(
                        selectedStatus: selectedStatus,
                        indentNumber: certificateData.indentNumber.toString(),
                        indentTrans: certificateData.indentTrans,
                      ),
                  transition: Transition.rightToLeft,
                  duration: const Duration(milliseconds: 600));
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 12,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text: certificateData.indentNumber,
                            fontSize: AppFontSize.size5,
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                          ),
                          CustomText(
                            text: certificateData.status,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size5,
                            color: certificateData.status
                                        .toLowerCase()
                                        .removeAllWhitespace ==
                                    "received"
                                ? AppColor.green // for 'received'
                                : certificateData.status
                                            .toLowerCase()
                                            .removeAllWhitespace ==
                                        "pending"
                                    ? AppColor.redColor // for 'pending'
                                    : certificateData.status
                                                .toLowerCase()
                                                .removeAllWhitespace ==
                                            "partialpending"
                                        ? AppColor
                                            .blueColor // for 'partial pending'
                                        : certificateData.status
                                                    .toLowerCase()
                                                    .removeAllWhitespace ==
                                                "dispatched"
                                            ? AppColor
                                                .orange // for 'dispatched'
                                            : AppColor
                                                .black2Color, // default color if none of the conditions match
                          )
                        ],
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      // Indent date and amount row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text: certificateData.indentDate,
                            fontSize: AppFontSize.size5,
                            fontWeight: FontWeight.w500,
                            color: AppColor.black2Color,
                          ),
                          CustomText(
                            text: "Students : ${certificateData.totalStudents}",
                            fontSize: AppFontSize.size5,
                            fontWeight: FontWeight.w500,
                            color: AppColor.blackColor,
                          ),
                        ],
                      ),
                      SizedBox(height: 8.w),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          BulletText(
                            label: "Certificates",
                            withBullet: false,
                            value:
                                certificateData.orderedCertificate.toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Dispatched",
                            value: certificateData.despatchedCertificate
                                .toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Received",
                            value:
                                certificateData.receivedCertificate.toString(),
                            valueColor: AppColor.green,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Pending",
                            value:
                                certificateData.pendingCertificate.toString(),
                            labelColor: AppColor.blackColor,
                            valueColor: AppColor.redColor,
                            fontSize: AppFontSize.size6,
                          ),
                        ],
                      ),
                      SizedBox(height: 8.w),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          BulletText(
                            label: "Marksheets",
                            withBullet: false,
                            value:
                                certificateData.orderedCertificate.toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Dispatched",
                            value:
                                certificateData.despatchedMarksheet.toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Received",
                            value: certificateData.receivedMarksheet.toString(),
                            valueColor: AppColor.green,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size5,
                          ),
                          BulletText(
                            label: "Pending",
                            value: certificateData.pendingMarksheet.toString(),
                            labelColor: AppColor.blackColor,
                            valueColor: AppColor.redColor,
                            fontSize: AppFontSize.size6,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(top: 15.w),
                          child: ForwardArrowWidget(
                            onTap: () {
                              /*     List<IndentTran> indentTrans = [];

                              List<IndentTran> dispatchedGroups = [];
                              List<IndentTran> pendingGroups = [];
                              List<IndentTran> receivedGroups = [];

                              for (int i = 0; i < indentTrans.length; i++) {
                                // Declare i as an integer in the loop.
                                if (indentTrans[i].status.toLowerCase() == "dispatched") {
                                  dispatchedGroups.add(indentTrans[i]);
                                } else if (indentTrans[i].status.toLowerCase() == "pending") {
                                  pendingGroups.add(indentTrans[i]);
                                } else if (indentTrans[i].status.toLowerCase() == "received") {
                                  receivedGroups.add(indentTrans[i]);
                                }
                              }*/
                              Get.to(
                                  () => CertificateTrackingDetailScreen(
                                        selectedStatus: selectedStatus,
                                        indentNumber: certificateData
                                            .indentNumber
                                            .toString(),
                                        indentTrans:
                                            certificateData.indentTrans,
                                        // dispatchedGroups : dispatchedGroups,
                                        // pendingGroups : pendingGroups,
                                        // receivedGroups : receivedGroups,
                                      ),
                                  transition: Transition.rightToLeft,
                                  duration: const Duration(milliseconds: 600));
                            },
                          ),
                        ),
                      ],
                    )),
              ],
            ),
          ),
          SizedBox(
            height: 5.w,
          ),
          const Divider(
            thickness: 1.0,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }
}
