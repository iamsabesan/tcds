import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/get_core.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/exam/view/certificate_tracking_screen.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';

import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/horiz_asset_text.dart';
import 'package:tcds/utils/helper_widgets/pop_scope_handler.dart';

import 'indent_creation.dart';
import 'mark_updation_screen.dart';

class ExamIndentMainScreen extends StatefulWidget {
  const ExamIndentMainScreen({super.key});

  @override
  State<ExamIndentMainScreen> createState() => _ExamIndentMainScreenState();
}

class _ExamIndentMainScreenState extends State<ExamIndentMainScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int _selectedIndex = 4;
  bool withBackArrow = false;
  @override
  void initState() {
    super.initState();
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 4,
        ),
      ),
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        titleSpacing: 0,
        toolbarHeight: 70,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        title: CustomText(
          text: 'Exam',
          fontSize: AppFontSize.size2,
          fontWeight: FontWeight.w500,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!
                      .openDrawer(); // Handle back navigation
                },
              ),
      ),
      body: PopScopeHandler(
        child: Column(
          children: [
            SizedBox(
              height: 15.w,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.0),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColor.greyColor,
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () =>
                          Get.to(() => const ExamIndentCreate(), //-- New
                              // const ExamIntentCreationScreen(), //-- Old
                              transition: Transition.rightToLeft,
                              duration: const Duration(milliseconds: 600)),
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.w, horizontal: 15.w),
                                child: HorizAssetText(
                                  assetPath: AssetPath.filterIcon,
                                  assetColor: AppColor.blackColor,
                                  assetScale: 25.0,
                                  valueText: "Indent",
                                  valueTextColor: AppColor.blackColor,
                                  valueFontSize: AppFontSize.size2,
                                  valueFontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              color: AppColor.blackColor,
                              size: 18.0,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Divider(
                      thickness: 1.5,
                      height: 0,
                      color: AppColor.greyColor,
                    ),
                    InkWell(
                      onTap: () {
                        Get.to(const CertificateTrackingScreen(),
                            transition: Transition.rightToLeft,
                            duration: const Duration(milliseconds: 600));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Row(
                          children: [
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.w, horizontal: 15.w),
                                child: HorizAssetText(
                                  assetPath: AssetPath.trackingIcon,
                                  assetScale: 25.0,
                                  valueText: "Tracking",
                                  valueTextColor: AppColor.blackColor,
                                  valueFontSize: AppFontSize.size2,
                                  valueFontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              color: AppColor.blackColor,
                              size: 18.0,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Divider(
                      thickness: 1.5,
                      height: 0,
                      color: AppColor.greyColor,
                    ),
                    InkWell(
                      onTap: () {
                        Get.to(const MarkUpdationScreen(),
                            transition: Transition.rightToLeft,
                            duration: const Duration(milliseconds: 600));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(6),
                        child: Row(
                          children: [
                            Expanded(
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                    vertical: 10.w, horizontal: 15.w),
                                child: HorizAssetText(
                                  assetPath: AssetPath.trackingIcon,
                                  assetScale: 25.0,
                                  valueText: "Mark Updation",
                                  valueTextColor: AppColor.blackColor,
                                  valueFontSize: AppFontSize.size2,
                                  valueFontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                            const Icon(
                              Icons.arrow_forward_ios,
                              color: AppColor.blackColor,
                              size: 18.0,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
