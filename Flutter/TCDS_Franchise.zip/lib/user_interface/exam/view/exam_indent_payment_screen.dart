import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/exam/view/exam_indent_main_screen.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/bottom_sheets.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/out_button.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';
import '../../dashboard/controller/dashboard_controller.dart';

class ExamIndentPaymentScreen extends StatefulWidget {
  final List<Map<String, dynamic>>? receivedData;
  final double totalAmnt;
  const ExamIndentPaymentScreen(
      {super.key, this.receivedData, required this.totalAmnt});

  @override
  State<ExamIndentPaymentScreen> createState() =>
      _ExamIndentPaymentScreenState();
}

class _ExamIndentPaymentScreenState extends State<ExamIndentPaymentScreen> {
  DashboardController dashboardController = Get.put(DashboardController());

  bool canPop = false;

  double totalPayable = 0;
  double courierCharge = 0;

  late String selectedPaymentMethod;
  double totalPaid = 0;
  double balance = 5000;
  TextEditingController amountCtrl = TextEditingController();

  List<Map<String, dynamic>> paymentDetails = [];
  // ignore: prefer_typing_uninitialized_variables
  var selectedPaymodeId;
  bool allowPayment = false;
  // final Set<String> completedPayments = {};
  // Map<String, bool> paymentConfirmed = {
  //   'Bank Transfer': false,
  //   'UPI': false,
  //   'Cash': false,
  //   'Bank Remittance': false,
  // };

  NumberFormat currencyFormat =
      NumberFormat.currency(symbol: "₹", decimalDigits: 2, locale: "hi_IN");

  @override
  void initState() {
    super.initState();

    getApiCall(); // Set the initial value to the amount payable
    _calculateTotalPayable();
  }

  Future<void> getApiCall() async {
    await dashboardController.getPayMode();
    await dashboardController.getCashLedger();
    await dashboardController.getAdminBankName();
    await dashboardController.getFranchiseeBankName();
    await dashboardController.fetchCourierCharge();
  }

  void _calculateTotalPayable() {
    courierCharge = dashboardController.courierAmt.value.toDouble();
    totalPayable = widget.totalAmnt + courierCharge;
  }

  void _openBottomSheetForMethod(
      String paymentMode, String selectedPaymodeId) async {
    _calculateTotalPayable();
    double remainingAmount = totalPayable - totalPaid;

    // // Check if payment is already confirmed for this mode
    // if (paymentConfirmed[paymentMode] == true) {
    //   Get.snackbar(
    //     'Error Message',
    //     'You already confirmed payment with $paymentMode.',
    //     colorText: AppColor.whiteColor,
    //     padding: EdgeInsets.all(15.w),
    //     backgroundColor: AppColor.primaryColor,
    //   );
    //   return;
    // }

    final result = await AppBottomSheets.indentPaymentBottomSheet(
      selectedPaymodeId: selectedPaymodeId,
      currencyFormat: currencyFormat,
      paymentMode: paymentMode.toLowerCase().removeAllWhitespace,
      payModeOriginal: paymentMode,
      context: context,
      remainingAmount: remainingAmount,
      adminBankList: dashboardController.adminBankList,
      franchiseeBankList: dashboardController.franchiseeBankList,
      // onSubmit: (details) {
      //   setState(() {
      //     // /*     completedPayments.add(paymentMode);
      //     // selectedPaymentMethod = paymentMode;*/
      //     //
      //     // if (paymentMode == "cash") {
      //     //   paymentDetails[paymentMode] = {
      //     //     'date': details['date'], // Only save the date for Cash
      //     //   };
      //     // } else {
      //     //   paymentDetails[paymentMode] = details; // Save all details for other modes
      //     // }
      //     // // paymentConfirmed[paymentMode] = true; // Mark this mode as confirmed
      //
      //     paymentDetails[paymentMode] = details; // Save payment details
      //     totalPaid += details['amount'] ?? 0; // Update total paid
      //     balance = totalPayable - totalPaid; // Update balance
      //   });

      // },
      // onCancel: () {
      //   setState(() {
      //     // paymentConfirmed[paymentMode] = false;
      //     // completedPayments.remove(paymentMode);
      //   });
      // },
    );

    debugPrint("Res $result");

    if (result != null) {
      setState(() {
        paymentDetails.add(result);
        totalPaid += double.tryParse(result['amount'] ?? 0) ?? 0;
        balance = totalPayable - totalPaid;
        allowPayment = true;
        // paymentConfirmed[paymentMode] = true; // Mark as confirmed
      });
    }
  }

  //
  // void markPaymentCompleted(String method) {
  //   setState(() {
  //     // paymentConfirmed[method] = true; // Mark the payment mode as completed
  //   });
  // }

/*  void removePayment(String paymentMode) {
    if (paymentDetails.containsKey(paymentMode)) {
      setState(() {
        totalPaid -= paymentDetails[paymentMode]['amount']; // Subtract amount from totalPaid
        balance = totalPayable - totalPaid; // Recalculate balance
        paymentDetails.remove(paymentMode); // Remove the payment details
        // paymentConfirmed[paymentMode] = false; // Mark as not confirmed
        if (totalPaid == 0) {
          paidAmount = 0; // Reset paidAmount if no payments remain
        }
      });
    }
  }*/

/*  void removePayment(String paymentMode) {
    setState(() {
      // Find the index of the payment to remove
      int indexToRemove = paymentDetails.indexWhere((payment) => payment['paymodeType'] == paymentMode);

      if (indexToRemove != -1) {
        // Parse 'amount' to a num (double or int) before subtracting
        double amountToRemove = double.tryParse(paymentDetails[indexToRemove]['amount'].toString()) ?? 0.0;

        totalPaid -= amountToRemove; // Subtract amount from totalPaid
        balance = totalPayable - totalPaid; // Recalculate balance

        // Remove the payment from the list
        paymentDetails.removeAt(indexToRemove);

        // Reset paidAmount if no payments remain
        if (totalPaid == 0) {
          balance = totalPayable;
        }
      }
    });
  }*/

  void removePayment(String paymentMode) {
    setState(() {
      // Find the index of the payment to remove
      int indexToRemove = paymentDetails
          .indexWhere((payment) => payment['paymodeType'] == paymentMode);

      if (indexToRemove != -1) {
        double amountToRemove = double.tryParse(
                paymentDetails[indexToRemove]['amount'].toString()) ??
            0.0;

        totalPaid -= amountToRemove;
        balance += amountToRemove;

        // Remove the payment from the list
        paymentDetails.removeAt(indexToRemove);

        // Reset paidAmount if no payments remain
        if (paymentDetails.isEmpty) {
          balance = totalPayable;
          totalPaid = 0.0;
        }
      }
    });
  }

  void updateAmount() {
    // Parse the amount entered by the user
    double enteredAmount = double.tryParse(amountCtrl.text) ?? 0;

    // If the entered amount is more than the amount payable, it should be accepted
    if (enteredAmount > totalPayable) {
      setState(() {
        totalPaid =
            enteredAmount; // User entered an amount greater than the total payable
        balance = 0; // No balance left to pay
      });
    } else {
      setState(() {
        totalPaid = enteredAmount;
        balance = totalPayable - totalPaid;
      });
    }
  }

  // Helper to convert api format date string to user friendly
  String userDateFormartion(String stringAPIDate) {
    return DateFormat('dd-MM-yyyy')
        .format(DateFormat('yyyy-MM-dd').parse(stringAPIDate));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        titleSpacing: 0.1,
        toolbarHeight: 70,
        scrolledUnderElevation: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Exam Payment',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        actions: const [],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: PopScopeHandler(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 1.w, horizontal: 4.w),
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: AppColor.greyColor,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withValues(alpha: 0.4),
                              blurRadius: 5.0),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: 15.w, vertical: 15.w),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 25.w),
                          CustomText(
                            text: "Payment Method",
                            color: AppColor.blackColor,
                            fontSize: AppFontSize.size3,
                            fontWeight: FontWeight.bold,
                          ),
                          SizedBox(height: 5.w),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              for (final method in [
                                ['Wallet', 'Bank Transfer'],
                                ['UPI', 'Cash'],
                                ['Bank Remittance']
                              ])
                                GestureDetector(
                                  onTap: () {
                                    _openBottomSheetForMethod(
                                        method.toString(), selectedPaymodeId);
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: method
                                        .map((m) => Expanded(
                                              child: GestureDetector(
                                                onTap: () {
                                                  debugPrint(m);
                                                  setState(() {
                                                    selectedPaymentMethod = m;
                                                    for (var i = 0;
                                                        i <
                                                            dashboardController
                                                                .payModeList
                                                                .length;
                                                        i++) {
                                                      if (dashboardController
                                                              .payModeList[i]
                                                              .paymode
                                                              .toLowerCase()
                                                              .removeAllWhitespace ==
                                                          m
                                                              .toLowerCase()
                                                              .removeAllWhitespace) {
                                                        selectedPaymodeId =
                                                            dashboardController
                                                                .payModeList[i]
                                                                .paymodeId;
                                                      }
                                                    }
                                                  });
                                                  _openBottomSheetForMethod(
                                                      m, selectedPaymodeId);
                                                },
                                                child: Container(
                                                  margin: EdgeInsets.symmetric(
                                                      horizontal: 15.w,
                                                      vertical: 5.w),
                                                  padding: EdgeInsets.symmetric(
                                                      vertical: 10.w),
                                                  decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: Colors.grey),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15.0),
                                                    // color: paymentConfirmed[m] == true ? Colors.green.withOpacity(0.2) : Colors.white,
                                                    // color: paymentConfirmed[m] == true ? Colors.green.withOpacity(0.2) : Colors.white,
                                                    color: Colors.white,
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    15.w),
                                                        child: CustomText(
                                                          text: m,
                                                          fontSize:
                                                              AppFontSize.size4,
                                                        ),
                                                      ),
                                                      // if (selectedPaymentMethod == m || completedPayments.contains(m))
                                                      // if (paymentConfirmed[m] == true)
                                                      //   Padding(
                                                      //     padding: const EdgeInsets.only(right: 8.0),
                                                      //     child: Container(
                                                      //       decoration: const BoxDecoration(
                                                      //         shape: BoxShape.circle,
                                                      //         color: Colors.green,
                                                      //       ),
                                                      //       child: const Icon(
                                                      //         Icons.check,
                                                      //         color: Colors.white,
                                                      //         size: 25.0,
                                                      //       ),
                                                      //     ),
                                                      //   ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ))
                                        .toList(),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(
                            height: 20.w,
                          ),
                          Card(
                            color: AppColor.grey3,
                            margin: EdgeInsets.all(5.w),
                            child: Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10.w, vertical: 10.w),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Item Amount",
                                        color: AppColor.primaryColor,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      CustomText(
                                        text: currencyFormat
                                            .format(widget.totalAmnt),
                                        color: AppColor.blackColor,
                                        fontSize: AppFontSize.size3,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10.w, vertical: 10.w),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Courier Charge",
                                        color: AppColor.primaryColor,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      Obx(
                                        () => CustomText(
                                          text: currencyFormat.format(
                                              dashboardController
                                                  .courierAmt.value
                                                  .toDouble()),
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size3,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10.w, vertical: 10.w),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Amount Payable",
                                        color: AppColor.primaryColor,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      Obx(
                                        () => CustomText(
                                          text: currencyFormat.format(
                                              widget.totalAmnt +
                                                  dashboardController
                                                      .courierAmt.value
                                                      .toDouble()),
                                          color: AppColor.green,
                                          fontSize: AppFontSize.size3,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                                if (paymentDetails.isNotEmpty)
                                  SizedBox(
                                    height: 10.w,
                                  ),
                                Column(
                                  children: List.generate(paymentDetails.length,
                                      (int historyIndex) {
                                    String mode = paymentDetails[historyIndex]
                                        ["paymodeOriginal"];

                                    return ListTile(
                                        title: Row(
                                          children: [
                                            Expanded(
                                              flex: 5,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Flexible(
                                                        child: CustomText(
                                                          text: mode,
                                                          color: AppColor
                                                              .blackColor,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                          maxLines: 2,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          fontSize:
                                                              AppFontSize.size4,
                                                        ),
                                                      ),
                                                      //NOTE: Removed this temporarily, cause there is no need to download the image that user uploaded
                                                      // and even so now user can't download it via API, since it not been activated yet.
                                                      if (mode.toUpperCase() ==
                                                              'UPI' ||
                                                          mode
                                                                  .toLowerCase()
                                                                  .removeAllWhitespace ==
                                                              'bankremittance')
                                                        SizedBox(width: 5.w),
                                                      if (mode.toUpperCase() ==
                                                              'UPI' ||
                                                          mode
                                                                  .toLowerCase()
                                                                  .removeAllWhitespace ==
                                                              'bankremittance')
                                                        Image.asset(
                                                          'assets/file_image.png',
                                                          height: 20.w,
                                                          width: 20.w,
                                                        ),
                                                      /*  InkWell(
                                                        onTap: () {
                                                          _showImageDialog(
                                                              context,
                                                              paymentDetails[
                                                                      historyIndex]
                                                                  [
                                                                  "DocumentID"]);
                                                        },
                                                        child: 
                                                        Image.asset(
                                                          'assets/file_image.png',
                                                          scale: 1.5,
                                                        ),
                                                      ), */
                                                    ],
                                                  ),
                                                  CustomText(
                                                    text: userDateFormartion(
                                                        paymentDetails[
                                                                historyIndex][
                                                            "transactionDate"]),
                                                    color: AppColor.blackColor,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: AppFontSize.size5,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              width: 10.w,
                                            ),
                                            Expanded(
                                              flex: 4,
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  if (paymentDetails[
                                                              historyIndex]
                                                          ["fromLedgerName"] !=
                                                      null)
                                                    CustomText(
                                                      text:
                                                          "From : ${paymentDetails[historyIndex]["fromLedgerName"]} ",
                                                      color:
                                                          AppColor.black2Color,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize:
                                                          AppFontSize.size5,
                                                    ),
                                                  if (paymentDetails[
                                                              historyIndex]
                                                          ["toLedgerName"] !=
                                                      null)
                                                    CustomText(
                                                      text:
                                                          "To : ${paymentDetails[historyIndex]["toLedgerName"]} ",
                                                      color:
                                                          AppColor.black2Color,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize:
                                                          AppFontSize.size5,
                                                    ),
                                                  if (paymentDetails[
                                                              historyIndex]
                                                          ["transactionNo"] !=
                                                      null)
                                                    CustomText(
                                                      text:
                                                          "#${paymentDetails[historyIndex]["transactionNo"]} ",
                                                      color:
                                                          AppColor.black2Color,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize:
                                                          AppFontSize.size5,
                                                    ),
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              width: 10.w,
                                            ),
                                            Expanded(
                                              flex: 3,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  CustomText(
                                                    text:
                                                        "₹${paymentDetails[historyIndex]["amount"]}",
                                                    color: AppColor.blackColor,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: AppFontSize.size4,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
                                        trailing: InkWell(
                                          borderRadius:
                                              BorderRadius.circular(12.r),
                                          onTap: () {
                                            removePayment(
                                                paymentDetails[historyIndex]
                                                    ['paymodeType']);
                                          },
                                          child: Icon(
                                            Icons.cancel,
                                            color: Colors.red,
                                            size: 20.w,
                                          ),
                                        ));
                                  }),
                                ),
                                if (paymentDetails.isNotEmpty) const Divider(),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10.w, vertical: 10.w),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Amount Paid",
                                        color: AppColor.primaryColor,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      CustomText(
                                        text: currencyFormat.format(totalPaid),
                                        color: AppColor.green,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                      left: 10.w, bottom: 10.w, right: 10.w),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      CustomText(
                                        text: "Balance",
                                        color: AppColor.primaryColor,
                                        fontSize: AppFontSize.size4,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      Obx(
                                        () => CustomText(
                                          text: currencyFormat.format(
                                              (widget.totalAmnt +
                                                      dashboardController
                                                          .courierAmt.value
                                                          .toDouble()) -
                                                  totalPaid),
                                          color: AppColor.redColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 25.0),
                      child: InkWell(
                        child: OutButton(
                          onTap: () {
                            Get.back();
                          },
                          withArrow: false,
                          text: "Back",
                          verticalPadding: 10.w,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 25.w,
                  ),
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 25.0),
                      child: InkWell(
                        child: InButton(
                          onTap: () async {
                            double courierCharge =
                                dashboardController.courierAmt.value.toDouble();
                            double reactiveTotalPayable =
                                widget.totalAmnt + courierCharge;
                            double reactiveBalance =
                                reactiveTotalPayable - totalPaid;

                            if ((allowPayment) && (reactiveBalance == 0)) {
                              final body = {
                                "batchMapping": widget.receivedData,
                                "totalAmount": reactiveTotalPayable,
                                "courierAmount": courierCharge,
                                "paymentItems": paymentDetails,
                              };

                              // log(body.toString());

                              // call api
                              PleaseWaitLoader.openDialog();
                              final bool isTopUpAdded =
                                  await dashboardController
                                      .saveExamIndentIndent(body: body);
                              PleaseWaitLoader.closeDialog();
                              if (isTopUpAdded) {
                                // succes message
                                debugPrint("Topup added");
                                Get.to(const ExamIndentMainScreen());
                                showSuccessDialog(
                                    context: Get.context!,
                                    message: 'Indent saved successfully');
                              }
                            } else {
                              Get.snackbar(
                                'Payable amount',
                                'The amount is not tallied',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                            }
                          },
                          withArrow: false,
                          text: "Submit",
                          color: AppColor.primaryColor,
                          verticalPadding: 10.w,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
