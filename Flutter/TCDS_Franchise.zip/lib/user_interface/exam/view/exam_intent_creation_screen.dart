/* import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/bottom_navigation.dart';
import '../../../utils/helper_widgets/bottom_sheets.dart';
import '../../../utils/helper_widgets/custom_drawer.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/exam_indent_two_line_widget.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../dashboard/view/dashboard_screen.dart';
import '../../students_list/controller/student_list_controller.dart';
import '../model/batch_mapping_model.dart';
import 'exam_indent_payment_screen.dart';

class ExamIntentCreationScreen extends StatefulWidget {
  const ExamIntentCreationScreen({super.key});

  @override
  State<ExamIntentCreationScreen> createState() =>
      _ExamIntentCreationScreenState();
}

class _ExamIntentCreationScreenState extends State<ExamIntentCreationScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  StudentListController studentListController =
      Get.put(StudentListController());
  int _selectedIndex = 4;
  int appliedFilterCount = 0;

  List<Map<String, dynamic>> orderDetail = [];
  List<BatchMappingDetails> batchMappingList = [];
  BatchMappingDetails batchMappingDetails = BatchMappingDetails(
      batchMappingId: '',
      examFees: 0,
      semester: 0,
      examDate: '',
      courseName: "",
      indentStudent: 0,
      totalStudent: 0,
      batchId: "",
      batchName: "",
      courseId: '',
      studentId: '');
  Map<String, List<BatchMappingDetails>> groupedData = {};
  double totalAmnt = 0;
  double previousAmnt = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 4,
        ),
      ),
      appBar: AppBar(
        titleSpacing: 0,
        toolbarHeight: 70,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Exam Indent',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 10.w, horizontal: 10.w),
            child: GestureDetector(
              onTap: () async {
                PleaseWaitLoader.openDialog();

                // Fetch required data for the filter screen
                await studentListController.getFranchiseCourseList();
                if (studentListController.franchiseCourseDataList.isNotEmpty) {
                  await studentListController.getFranchiseCourseBatchList(
                      courseId: studentListController
                          .franchiseCourseDataList[0].courseId);
                }

                // if (studentListController
                //     .franchiseCourseBatchDataList.isEmpty) {
                //   PleaseWaitLoader.closeDialog();
                //   Get.snackbar(
                //     'Students',
                //     'There is no students registered for the course',
                //     colorText: AppColor.whiteColor,
                //     padding: EdgeInsets.all(15.w),
                //     backgroundColor: AppColor.primaryColor,
                //   );

                //   return;
                // }

                if (studentListController
                    .franchiseCourseBatchDataList.isNotEmpty) {
                  await studentListController.getStudentListByBatch(
                      batchId: studentListController
                          .franchiseCourseBatchDataList[0].courseBatchId);
                }

                // await studentListController.getCourseListByFranchisee();
                PleaseWaitLoader.closeDialog();

                // Show filter bottom sheet
                final filterData = await AppBottomSheets.addExamIndent(
                  context: Get.context!,
                  create: true,
                  onFilterCountUpdated: (count) {
                    setState(() {
                      appliedFilterCount = count;
                      debugPrint(
                          "Filter count updated: $appliedFilterCount"); //// Update filter count dynamically
                    });
                  },
                );

                if (filterData != null) {
                  setState(() {
                    for (var part in filterData) {
                      String courseName = part.courseName;
                      bool isNewData = !batchMappingList.any((existingPart) =>
                          existingPart.batchMappingId == part.batchMappingId &&
                          existingPart.examDate == part.examDate);
                      if (isNewData) {
                        if (!groupedData.containsKey(courseName)) {
                          groupedData[courseName] = [];
                        }
                        groupedData[courseName]?.add(part);
                        totalAmnt += part.singleExamFees;
                        batchMappingList.add(part);
                      }
                    }

                    debugPrint("$groupedData");
                  });
                }
              },
              child: Container(
                height: 45, // Reduced height
                width: 45, // Reduced width
                decoration: BoxDecoration(
                  color: AppColor.whiteColor,
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(
                    color: AppColor.grey, // Set your desired border color here
                    width: 2, // Set the border width here
                  ),
                  // Replace with your AppColor.grey2 if defined
                  boxShadow: const [
                    BoxShadow(
                      color: AppColor.grey2, // Shadow color
                      blurRadius: 4,
                      spreadRadius: 1, // Spread radius
                      offset: Offset(4, 5), // Shadow offset (X and Y direction)
                    ),
                  ],
                ),
                alignment: Alignment.center,
                child: Image.asset(
                  AssetPath.plusIcon,
                  fit: BoxFit
                      .contain, // Ensures the image fits inside the container
                  scale: 3.0, // Adjust scale for better control
                ),
              ),
            ),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          if (batchMappingList.isEmpty)
            const Expanded(
                child: Center(
              child: CustomText(
                text: "Not added yet.",
              ),
            )),
          if (batchMappingList.isNotEmpty)
            Expanded(
              child: ListView(
                children: [
                  SizedBox(
                    height: 15.w,
                  ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          children: List.generate(groupedData.length,
                              (int historyIndex) {
                            final courseName =
                                groupedData.keys.elementAt(historyIndex);
                            var data =
                                groupedData.values.elementAt(historyIndex);
                            debugPrint(data.toString());
                            double totalExamFees = groupedData[courseName]!
                                .fold(0.0,
                                    (sum, part) => sum + part.singleExamFees!);
                            int indentStudentCount =
                                groupedData[courseName]!.length;
                            return Padding(
                              padding: EdgeInsets.symmetric(horizontal: 15.w),
                              child: InkWell(
                                onTap: () async {
                                  await studentListController
                                      .getFranchiseCourseList();
                                  await studentListController
                                      .getFranchiseCourseBatchList(
                                          courseId: groupedData[courseName]![0]
                                              .courseId);
                                  await studentListController
                                      .getStudentListByBatch(
                                          batchId: groupedData[courseName]![0]
                                              .batchId);
                                  final filterData =
                                      await AppBottomSheets.addExamIndent(
                                    context: Get.context!,
                                    create: false,
                                    index: historyIndex,
                                    orderDetail: groupedData[courseName],
                                    onFilterCountUpdated: (count) {
                                      setState(() {
                                        appliedFilterCount = count;
                                        debugPrint(
                                            "Filter count updated: $appliedFilterCount"); //// Update filter count dynamically
                                      });
                                    },
                                  );
                                  if (filterData != null) {
                                    if (filterData["isDeleted"] == true) {
                                      int indexValue = filterData["index"];
                                      batchMappingList.removeWhere((batch) {
                                        return groupedData[courseName]!.any(
                                            (comp) =>
                                                comp.batchMappingId ==
                                                    batch.batchMappingId &&
                                                comp.examDate ==
                                                    batch.examDate);
                                      });
                                      var data = groupedData.values
                                          .elementAt(indexValue);
                                      groupedData.remove(data[0].courseName);
                                      totalAmnt -= totalExamFees;
                                    } else {
                                      setState(() {
                                        for (var part
                                            in filterData["batchMappingList"]) {
                                          String courseName = part.courseName;
                                          bool lessValue =
                                              groupedData[courseName]!.length >
                                                  filterData["batchMappingList"]
                                                      .length;
                                          if (lessValue) {
                                            batchMappingList
                                                .removeWhere((batch) {
                                              return !filterData[
                                                      "batchMappingList"]
                                                  .any((comp) =>
                                                      comp.batchMappingId ==
                                                          batch
                                                              .batchMappingId &&
                                                      comp.examDate ==
                                                          batch.examDate);
                                            });
                                            groupedData[courseName] = [];
                                            // }
                                            groupedData[courseName]?.add(part);
                                            totalAmnt += part.examFees;
                                            // print(batchMappingList);
                                          } else {
                                            bool isNewData = !batchMappingList
                                                .any((existingPart) =>
                                                    existingPart
                                                            .batchMappingId ==
                                                        part.batchMappingId &&
                                                    existingPart.examDate ==
                                                        part.examDate);
                                            if (isNewData) {
                                              if (!groupedData
                                                  .containsKey(courseName)) {
                                                groupedData[courseName] = [];
                                              }
                                              groupedData[courseName]
                                                  ?.add(part);
                                              totalAmnt += part.examFees;
                                              batchMappingList.add(part);
                                            }
                                          }
                                        }
                                        totalAmnt -= totalExamFees;
                                        // for (var part in filterData) {
                                        //   totalAmnt+=part.examFees;
                                        //   batchMappingList.add(part);
                                        // }
                                        debugPrint("$groupedData");

                                        // totalAmnt+=filterData["totalPrice"];
                                        // paymentConfirmed[paymentMode] = true; // Mark as confirmed
                                      });
                                    }
                                    // else{
                                    //   int indexValue = filterData["index"];
                                    //   orderDetail[indexValue]['materialTypeID'] = filterData['materialTypeID'];
                                    //   orderDetail[indexValue]['materialType'] = filterData['materialType'];
                                    //   orderDetail[indexValue]['materialID'] = filterData['materialID'];
                                    //   orderDetail[indexValue]['materialName'] = filterData['materialName'];
                                    //   orderDetail[indexValue]['quantity'] = filterData['quantity'];
                                    //   orderDetail[indexValue]['totalPrice'] = filterData['totalPrice'];
                                    //   orderDetail[indexValue]['price'] = filterData['price'];
                                    //   orderDetail[indexValue]['gstPercent'] = filterData['gstPercent'];
                                    //   orderDetail[indexValue]['gstAmount'] = filterData['gstAmount'];
                                    //   orderDetail[indexValue]['taxableAmount'] = filterData['taxableAmount'];
                                    //   // previousAmnt-=filterData['totalPrice'];
                                    //   totalAmnt-=previousAmnt;
                                    //   totalAmnt+=filterData['totalPrice'];
                                    // }
                                    setState(() {});
                                  }
                                },
                                child: ExamIndentTwoLineWidget(
                                  withForwardArrow: true,
                                  title: courseName,
                                  indentStudent: indentStudentCount.toString(),
                                  totalStudent: data[0].totalStudent.toString(),
                                  price: totalExamFees.toString(),
                                  onTap: () async {},
                                ),
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          if (batchMappingList.isNotEmpty)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 40.w),
              child: Card(
                color: AppColor.containerGrey,
                margin: EdgeInsets.all(5.w),
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          CustomText(
                            text: "Total :",
                            color: AppColor.textHeaderClr,
                            fontSize: AppFontSize.size4,
                            fontWeight: FontWeight.w500,
                          ),
                          CustomText(
                            text: "₹ $totalAmnt",
                            color: AppColor.secondaryColor,
                            fontSize: AppFontSize.size4,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                      InkWell(
                        child: InButton(
                          onTap: () async {
                            orderDetail.clear();
                            debugPrint(batchMappingList.toString());
                            for (var part in batchMappingList) {
                              var filterData = {
                                'batchMappingID': part.batchMappingId,
                                'examFees': part.examFees,
                                'semester': part.semester,
                                'examDate': part.examDate,
                              };
                              orderDetail.add(filterData);
                            }
                            debugPrint(orderDetail.toString());
                            Get.to(
                                ExamIndentPaymentScreen(
                                  receivedData: orderDetail,
                                  totalAmnt: totalAmnt,
                                ),
                                transition: Transition.rightToLeft,
                                duration: const Duration(milliseconds: 600));
                          },
                          withArrow: false,
                          text: "Pay",
                          color: AppColor.primaryColor,
                          verticalPadding: 10.w,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
 */