import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/exam/model/franchise_student_batch_list_model.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';

import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../utils/helper_widgets/bottom_navigation.dart';
import '../../../utils/helper_widgets/custom_drawer.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/exam_indent_two_line_widget.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../dashboard/view/dashboard_screen.dart';
import '../../students_list/controller/student_list_controller.dart';
import '../model/franchise_course_batch_list_model.dart';
import '../model/franchise_course_list_model.dart';
import 'exam_indent_payment_screen.dart';
import 'widgets/add_indent_sheet.dart';

class ExamIndentCreate extends StatefulWidget {
  const ExamIndentCreate({super.key});

  @override
  State<ExamIndentCreate> createState() => _ExamIndentCreateState();
}

class _ExamIndentCreateState extends State<ExamIndentCreate> {
  int _selectedIndex = 4;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  StudentListController studentListController =
      Get.put(StudentListController());

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);

  // created indents holder
  List<Map<String, dynamic>> createdIndents = [];

  // Total payable amount
  double totalPayAmount = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 4,
        ),
      ),
      appBar: AppBar(
        titleSpacing: 0,
        toolbarHeight: 70,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Exam Indent',
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        actions: [
          InkWell(
            onTap: () async {
              // before open indent sheet lets fetch courses,batches and students in the batch to create a indent
              // fetch courses
              PleaseWaitLoader.openDialog();
              await studentListController.getFranchiseCourseList();
              //  fetch batches with course id
              if (studentListController.franchiseCourseDataList.isNotEmpty) {
                await studentListController.getFranchiseCourseBatchList(
                    courseId: studentListController
                        .franchiseCourseDataList[0].courseId);
                // fetch students with batch id
                if (studentListController
                    .franchiseCourseBatchDataList.isNotEmpty) {
                  await studentListController.getStudentListByBatch(
                      batchId: studentListController
                          .franchiseCourseBatchDataList[0].courseBatchId);
                }
              }
              PleaseWaitLoader.closeDialog();
              // open the sheet
              if (!context.mounted) return;
              final resultedData = await addIndentSheet(context: context);
              // if result had some value in it
              if (resultedData != null) {
                createdIndents.add(resultedData);
                totalPayAmount = 0;
                debugPrint("createdIndents $createdIndents");
                setState(() {
                  for (var element in createdIndents) {
                    totalPayAmount += element["examFees"];
                  }
                });
              }
            },
            child: Container(
              margin: EdgeInsets.only(right: 10.w),
              decoration: BoxDecoration(
                color: AppColor.whiteColor,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: AppColor.grey,
                  width: 2,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: AppColor.grey2,
                    blurRadius: 4,
                    spreadRadius: 1,
                    offset: Offset(4, 5),
                  ),
                ],
              ),
              child: Image.asset(
                AssetPath.plusIcon,
                fit: BoxFit.contain,
                height: 35.w,
                width: 35.w,
              ),
            ),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          // added indents
          Expanded(
              child: createdIndents.isEmpty
                  ? const Center(
                      child: CustomText(text: "No Indents Added"),
                    )
                  : ListView.builder(
                      padding: EdgeInsets.only(
                          top: 20.w, right: 20.w, left: 20.w, bottom: 100.w),
                      itemCount: createdIndents.length,
                      itemBuilder: (context, createdIndex) {
                        // get current index values from createdIndents
                        final courseData = createdIndents[createdIndex]
                            ["courseData"] as FranchiseCourseData;
                        final batchData = createdIndents[createdIndex]
                            ["batchData"] as CourseBatchData;
                        final String indentStudents =
                            createdIndents[createdIndex]["selectedStundets"]
                                .toString();
                        final String totalStudents =
                            createdIndents[createdIndex]["totalBatchStudents"]
                                .toString();
                        final double examTotalAmount =
                            ((double.tryParse(indentStudents) ?? 0) *
                                courseData.examFees);

                        return InkWell(
                          onTap: () async {
                            // fetch courses
                            PleaseWaitLoader.openDialog();
                            await studentListController
                                .getFranchiseCourseList();
                            //  fetch batches with course id
                            if (studentListController
                                .franchiseCourseDataList.isNotEmpty) {
                              await studentListController
                                  .getFranchiseCourseBatchList(
                                      courseId: courseData.courseId);
                              // fetch students with batch id
                              if (studentListController
                                  .franchiseCourseBatchDataList.isNotEmpty) {
                                await studentListController
                                    .getStudentListByBatch(
                                        batchId: batchData.courseBatchId);
                              }
                            }
                            PleaseWaitLoader.closeDialog();
                            // open the sheet
                            if (!context.mounted) return;
                            final resultedData = await addIndentSheet(
                                context: context,
                                openToEdit: true,
                                createdIndentData:
                                    createdIndents[createdIndex]);
                            // update the current createdIndents value by resultedData
                            if (resultedData != null) {
                              setState(() {
                                createdIndents[createdIndex] = resultedData;
                                totalPayAmount = 0;
                                debugPrint("createdIndents $createdIndents");
                                setState(() {
                                  for (var element in createdIndents) {
                                    totalPayAmount += element["examFees"];
                                  }
                                });
                              });
                            }
                          },
                          child: ExamIndentTwoLineWidget(
                            withForwardArrow: true,
                            title: courseData.shortName,
                            indentStudent: indentStudents,
                            totalStudent: totalStudents,
                            price: currencyFormat.format(examTotalAmount),
                          ),
                        );
                      })),

          // total pay section
          Card(
            color: AppColor.containerGrey,
            margin: EdgeInsets.only(bottom: 45.w, right: 10.w, left: 10.w),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CustomText(
                        text: "Total : ",
                        color: AppColor.textHeaderClr,
                        fontSize: AppFontSize.size4,
                        fontWeight: FontWeight.w500,
                      ),
                      CustomText(
                        text: currencyFormat.format(totalPayAmount),
                        color: AppColor.secondaryColor,
                        fontSize: AppFontSize.size4,
                        fontWeight: FontWeight.w500,
                      ),
                    ],
                  ),
                  InkWell(
                    child: InButton(
                      onTap: () async {
                        // AIM : generate body based on created indents length and it's selected student batch id
                        List<Map<String, dynamic>> payLoad = [];

                        // loop through created indents
                        for (var indent in createdIndents) {
                          // Here to pass exam fees we get course data
                          // and for batchMappingid and semester we get student data, cause each student will have different sem
                          final courseData =
                              indent["courseData"] as FranchiseCourseData;
                          final selectedStuData =
                              indent["selectedBatchStudentsData"]
                                  as List<BatchStudentData>;
                          for (var stuData in selectedStuData) {
                            payLoad.add({
                              'batchMappingID': stuData.batchMappingId,
                              'examFees': courseData.examFees,
                              'semester': stuData.semester,
                              'examDate': indent["examDate"],
                            });
                          }
                        }

                        debugPrint("Final Payload $payLoad");
                        Get.to(
                            ExamIndentPaymentScreen(
                              receivedData: payLoad,
                              totalAmnt: totalPayAmount,
                            ),
                            transition: Transition.rightToLeft,
                            duration: const Duration(milliseconds: 600));
                      },
                      withArrow: false,
                      text: "Pay",
                      color: AppColor.primaryColor,
                      verticalPadding: 10.w,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
