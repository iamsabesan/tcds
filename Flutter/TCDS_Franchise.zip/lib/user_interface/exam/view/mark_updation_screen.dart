import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/custom_textfield.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/out_button.dart';
import '../../../utils/helper_widgets/single_dropdown.dart';
import '../controller/exam_indent_controller.dart';
import '../model/batch_student_list_model.dart';

class MarkUpdationScreen extends StatefulWidget {
  const MarkUpdationScreen({super.key});

  @override
  State<MarkUpdationScreen> createState() => _MarkUpdationScreenState();
}

class _MarkUpdationScreenState extends State<MarkUpdationScreen> {
  ExamIndentController examIndentController = Get.put(ExamIndentController());
  final TextEditingController courseTypeCtrl = TextEditingController();
  final TextEditingController courseTypeTextCtrl = TextEditingController();
  Map<String, Map<int, List<BatchStudentData>>> groupedData = {};
  Map<String, TextEditingController> controllers = {};
  bool showLoader = true;
  int studentIndex = 0;
  int selectedSemester = 1; // Track currently selected semester
  List<int> availableSemesters =
      []; // List of available semesters for current student

  @override
  void initState() {
    super.initState();
    getApiCall();
  }

  @override
  void dispose() {
    // Dispose all controllers to avoid memory leaks
    for (var controller in controllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> getApiCall() async {
    setState(() {
      showLoader = true;
    });
    await examIndentController.getCourseBatchList();
    // if have any course fetch students list
    if (examIndentController.batchDataList.isNotEmpty) {
      await examIndentController.getBatchStudentList(
          batchId: examIndentController.batchDataList[0].courseBatchId);
      for (var material in examIndentController.batchStudentDataList) {
        String rollNo = material.rollNumber;
        int semester = material.semester;
        if (!groupedData.containsKey(rollNo)) {
          groupedData[rollNo] = {};
        }
        if (!groupedData[rollNo]!.containsKey(semester)) {
          groupedData[rollNo]![semester] = [];
        }
        groupedData[rollNo]![semester]!.add(material);
      }

      // Populate available semesters for current student
      if (groupedData.isNotEmpty) {
        String firstStudent = groupedData.keys.first;
        availableSemesters = groupedData[firstStudent]!.keys.toList()..sort();
        if (availableSemesters.isNotEmpty) {
          selectedSemester = availableSemesters.first;
        }
      }

      debugPrint(groupedData.toString());
    }

    setState(() {
      showLoader = false;
    });
  }

  bool validateFields() {
    bool isValid = true;

    // Iterate over subjects for the current student and selected semester only
    String studentName = groupedData.keys.elementAt(studentIndex);
    Map<int, List<BatchStudentData>> semesters = groupedData[studentName]!;

    // Only validate the selected semester
    if (semesters.containsKey(selectedSemester)) {
      for (var data in semesters[selectedSemester]!) {
        TextEditingController theoryController =
            getController(studentName, data.subjectName, 'Theory');
        TextEditingController practicalController =
            getController(studentName, data.subjectName, 'Practical');

        // Check if the theory and practical fields are not empty
        if (theoryController.text.isEmpty || practicalController.text.isEmpty) {
          isValid = false;
          break;
        }

        // You can also add numeric validation, for example, make sure the input is a valid number
        if (int.tryParse(theoryController.text) == null ||
            int.tryParse(practicalController.text) == null) {
          isValid = false;
          break;
        }

        // Optionally, check if the entered marks are within the valid range (e.g., between 0 and max marks)
        int theoryMarks = int.parse(theoryController.text);
        int practicalMarks = int.parse(practicalController.text);

        if (theoryMarks < 0 ||
            practicalMarks < 0 ||
            theoryMarks > data.theoryMarks ||
            practicalMarks > data.practicalMarks) {
          isValid = false;
          break;
        }
      }
    } else {
      isValid = false; // Selected semester not found
    }

    return isValid;
  }

  TextEditingController getController(
      String rollNo, String subjectName, String type) {
    String key = '${rollNo}_${subjectName}_$type';
    controllers.putIfAbsent(key, () => TextEditingController());
    return controllers[key]!;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        toolbarHeight: 70,
        titleSpacing: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Mark Updation',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 30.w,
          ),
          // Dropdown for batch selection - always visible
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.w),
            child: Obx(
              () => SingleSelectDropDown(
                key: UniqueKey(),
                valueController: courseTypeCtrl,
                valueTextController: courseTypeTextCtrl,
                data: List.generate(
                  examIndentController.batchDataList.length,
                  (index) => SingleSelectDropDownModel(
                    "${examIndentController.batchDataList[index].shortName}-${examIndentController.batchDataList[index].timing}",
                    examIndentController.batchDataList[index].courseBatchId,
                  ),
                ),
                labelText: 'Course',
                parentOnChangeCall: (value) async {
                  setState(() {
                    showLoader = true;
                    controllers.clear();
                    groupedData.clear();
                    studentIndex = 0;
                    availableSemesters.clear();
                  });
                  await examIndentController.getBatchStudentList(
                      batchId: courseTypeCtrl.text);
                  for (var material
                      in examIndentController.batchStudentDataList) {
                    String rollNo = material.rollNumber;
                    int semester = material.semester;
                    if (!groupedData.containsKey(rollNo)) {
                      groupedData[rollNo] = {};
                    }
                    if (!groupedData[rollNo]!.containsKey(semester)) {
                      groupedData[rollNo]![semester] = [];
                    }
                    groupedData[rollNo]![semester]!.add(material);
                  }

                  // Populate available semesters for current student
                  if (groupedData.isNotEmpty) {
                    String firstStudent = groupedData.keys.first;
                    availableSemesters =
                        groupedData[firstStudent]!.keys.toList()..sort();
                    if (availableSemesters.isNotEmpty) {
                      selectedSemester = availableSemesters.first;
                    }
                  }

                  debugPrint(groupedData.toString());
                  setState(() {
                    showLoader = false;
                  });
                },
              ),
            ),
          ),
          SizedBox(
            height: 20.w,
          ),
          // Semester selection - only show if multiple semesters available
          if (availableSemesters.length > 1)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.w),
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(color: AppColor.containerBorderGreyColor),
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.w),
                  child: DropdownButtonFormField<int>(
                    initialValue: selectedSemester,
                    decoration: const InputDecoration(
                      labelText: 'Select Semester',
                      border: InputBorder.none,
                    ),
                    items: availableSemesters
                        .map((semester) => DropdownMenuItem<int>(
                              value: semester,
                              child: CustomText(
                                text: 'Semester $semester',
                                fontSize: AppFontSize.size4.sp,
                                color: AppColor.black2Color,
                              ),
                            ))
                        .toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() {
                          selectedSemester = value;
                          // Clear controllers for different semester to avoid data mixing
                          controllers.clear();
                        });
                      }
                    },
                  ),
                ),
              ),
            ),
          SizedBox(
            height: 20.w,
          ),

          showLoader
              ? const Center(
                  child: CircularProgressIndicator(
                    color: AppColor.primaryColor,
                  ),
                )
              : examIndentController.batchDataList.isEmpty
                  ? const Center(
                      child: CustomText(text: "No data"),
                    )
                  : groupedData.isEmpty
                      ? Expanded(
                          child: Center(
                            child: CustomText(
                              text: "No Data",
                              fontSize: AppFontSize.size4.sp,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        )
                      : Expanded(
                          child: ListView.builder(
                            itemCount:
                                groupedData.keys.length, // Number of students
                            itemBuilder: (context, valueIndex) {
                              if (valueIndex != studentIndex) {
                                return const SizedBox
                                    .shrink(); // Don't display the student if it's not the selected one
                              }
                              String name = "";
                              String studentName = groupedData.keys
                                  .elementAt(studentIndex); // Get student name
                              Map<int, List<BatchStudentData>> semesters =
                                  groupedData[studentName]!;
                              if (semesters.isNotEmpty &&
                                  semesters[semesters.keys.first]!.isNotEmpty) {
                                name = semesters[semesters.keys.first]![0]
                                    .studentName; // Access studentName from BatchStudentData
                              }
                              return Card(
                                margin: const EdgeInsets.symmetric(
                                  vertical: 10,
                                ),
                                color: AppColor.whiteColor,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 10.0),
                                  // Padding inside card
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      // Student Name
                                      ListTile(
                                        title: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            CustomText(
                                              text:
                                                  "Student ${studentIndex + 1} of ${groupedData.keys.length}",
                                              // Max marks
                                              fontSize: 16.sp,
                                              color: AppColor.primaryColor,
                                              fontWeight: FontWeight.w700,
                                            ),
                                            if (studentIndex > 0)
                                              SizedBox(
                                                height: 10.w,
                                              ),
                                            if (studentIndex > 0)
                                              CustomText(
                                                text: courseTypeTextCtrl
                                                    .text, // Max marks
                                                fontSize: 16.sp,
                                                color: AppColor.primaryColor,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            Container(
                                              decoration: BoxDecoration(
                                                border: Border.all(
                                                  color: AppColor
                                                      .containerBorderGreyColor,
                                                  // Set the color of the border to blue
                                                  width: 3
                                                      .w, // Set the width of the border
                                                ),
                                                borderRadius: BorderRadius.circular(
                                                    8.0), // Optional: set a radius for rounded corners
                                              ),
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 15.w,
                                                    vertical: 5.w),
                                                child: Center(
                                                  child: Column(
                                                    children: [
                                                      CustomText(
                                                        text: name, // Max marks
                                                        fontSize: 16.sp,
                                                        color: AppColor
                                                            .secondaryColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                      CustomText(
                                                        text:
                                                            studentName, // Max marks
                                                        fontSize: 16.sp,
                                                        color: AppColor
                                                            .black2Color,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        subtitle: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            // Only show the selected semester
                                            if (semesters.containsKey(
                                                selectedSemester)) ...[
                                              Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 4.0),
                                                child: CustomText(
                                                  text:
                                                      'Semester: $selectedSemester', // Max marks
                                                  fontSize: 16.sp,
                                                  color: AppColor.black2Color,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                              // For each subject in the selected semester, create separate controllers for theory and practical
                                              ...semesters[selectedSemester]!
                                                  .map((data) {
                                                String subjectName =
                                                    data.subjectName;

                                                TextEditingController
                                                    theoryController =
                                                    getController(studentName,
                                                        subjectName, 'Theory');
                                                TextEditingController
                                                    practicalController =
                                                    getController(
                                                        studentName,
                                                        subjectName,
                                                        'Practical');

                                                return Padding(
                                                  padding: const EdgeInsets
                                                      .symmetric(vertical: 4.0),
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      CustomText(
                                                        text:
                                                            subjectName, // Max marks
                                                        fontSize: 14.sp,
                                                        color: AppColor
                                                            .primaryColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                      const SizedBox(height: 8),
                                                      // Row for Theory and Practical marks inputs
                                                      Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    25.w),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Expanded(
                                                              flex: 2,
                                                              child:
                                                                  CustomTextField(
                                                                inputFormatters: [
                                                                  LengthLimitingTextInputFormatter(
                                                                      3),
                                                                  FilteringTextInputFormatter
                                                                      .digitsOnly,
                                                                ],
                                                                labelText:
                                                                    "Theory",
                                                                controller:
                                                                    theoryController,
                                                                validator:
                                                                    (val) {
                                                                  return null;
                                                                },
                                                                suffixIcon:
                                                                    CustomText(
                                                                  text:
                                                                      '/${data.theoryMarks}',
                                                                  // Max marks
                                                                  fontSize:
                                                                      15.sp,
                                                                  color: AppColor
                                                                      .black3Color,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ),
                                                            ),
                                                            SizedBox(
                                                                width: 15.w),
                                                            Expanded(
                                                              flex: 2,
                                                              child:
                                                                  CustomTextField(
                                                                inputFormatters: [
                                                                  LengthLimitingTextInputFormatter(
                                                                      3),
                                                                  FilteringTextInputFormatter
                                                                      .digitsOnly,
                                                                ],
                                                                labelText:
                                                                    "Practical",
                                                                controller:
                                                                    practicalController,
                                                                validator:
                                                                    (val) {
                                                                  return null;
                                                                },
                                                                suffixIcon:
                                                                    CustomText(
                                                                  text:
                                                                      '/${data.practicalMarks}',
                                                                  // Max marks
                                                                  fontSize:
                                                                      15.sp,
                                                                  color: AppColor
                                                                      .black3Color,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              }),
                                            ],
                                          ],
                                        ),
                                      ),
                                      // Add buttons at the end of the card
                                      Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 25.w, vertical: 30.w),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            if (groupedData.keys.length > 1 &&
                                                studentIndex > 0)
                                              Expanded(
                                                flex: 1,
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 25.0),
                                                  child: InkWell(
                                                    child: OutButton(
                                                      onTap: () {
                                                        setState(() {
                                                          if (studentIndex >
                                                              0) {
                                                            studentIndex--; // Move to the previous student
                                                            // Update available semesters for new student
                                                            String
                                                                currentStudent =
                                                                groupedData.keys
                                                                    .elementAt(
                                                                        studentIndex);
                                                            availableSemesters =
                                                                groupedData[
                                                                        currentStudent]!
                                                                    .keys
                                                                    .toList()
                                                                  ..sort();
                                                            if (availableSemesters
                                                                    .isNotEmpty &&
                                                                !availableSemesters
                                                                    .contains(
                                                                        selectedSemester)) {
                                                              selectedSemester =
                                                                  availableSemesters
                                                                      .first;
                                                            }
                                                            controllers
                                                                .clear(); // Clear controllers to avoid data mixing
                                                          }
                                                        });
                                                      },
                                                      withArrow: false,
                                                      text: "Back",
                                                      verticalPadding: 10.w,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            if (groupedData.keys.length > 1 &&
                                                studentIndex > 0)
                                              SizedBox(width: 25.w),
                                            Expanded(
                                              flex: 1,
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 25.0),
                                                child: InkWell(
                                                  child: InButton(
                                                    onTap: () async {
                                                      if (validateFields()) {
                                                        if (studentIndex <
                                                            groupedData.keys
                                                                    .length -
                                                                1) {
                                                          studentIndex++; // Move to the next student
                                                          // Update available semesters for new student
                                                          String
                                                              currentStudent =
                                                              groupedData.keys
                                                                  .elementAt(
                                                                      studentIndex);
                                                          availableSemesters =
                                                              groupedData[
                                                                      currentStudent]!
                                                                  .keys
                                                                  .toList()
                                                                ..sort();
                                                          if (availableSemesters
                                                                  .isNotEmpty &&
                                                              !availableSemesters
                                                                  .contains(
                                                                      selectedSemester)) {
                                                            selectedSemester =
                                                                availableSemesters
                                                                    .first;
                                                          }
                                                          controllers
                                                              .clear(); // Clear controllers to avoid data mixing
                                                          setState(() {});
                                                        } else {
                                                          // Final submit - validate all and build details
                                                          if (validateAllStudents()) {
                                                            List<
                                                                    Map<String,
                                                                        dynamic>>
                                                                details =
                                                                buildAllDetails();
                                                            debugPrint(details
                                                                .toString());
                                                            PleaseWaitLoader
                                                                .openDialog();
                                                            final bool
                                                                valueUpdated =
                                                                await examIndentController
                                                                    .updateMark(
                                                                        body:
                                                                            details);
                                                            PleaseWaitLoader
                                                                .closeDialog();
                                                            if (valueUpdated) {
                                                              Get.back();
                                                              showSuccessDialog(
                                                                  context: Get
                                                                      .context!,
                                                                  message:
                                                                      'Mark update successfully');
                                                            }
                                                          } else {
                                                            Get.snackbar(
                                                              'Validation Failed',
                                                              "Please fill all fields correctly for all students.",
                                                              colorText: AppColor
                                                                  .white2Color,
                                                              padding:
                                                                  EdgeInsets
                                                                      .all(
                                                                          15.w),
                                                              backgroundColor:
                                                                  AppColor
                                                                      .primaryColor,
                                                            );
                                                          }
                                                        }
                                                      } else {
                                                        Get.snackbar(
                                                          'Data Not entered',
                                                          "Please fill all fields correctly for current student.",
                                                          colorText: AppColor
                                                              .white2Color,
                                                          padding:
                                                              EdgeInsets.all(
                                                                  15.w),
                                                          backgroundColor:
                                                              AppColor
                                                                  .primaryColor,
                                                        );
                                                      }
                                                    },
                                                    withArrow: false,
                                                    text: (studentIndex <
                                                            groupedData.keys
                                                                    .length -
                                                                1)
                                                        ? "Next"
                                                        : "Submit",
                                                    color:
                                                        AppColor.primaryColor,
                                                    verticalPadding: 10.w,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
        ],
      ),
    );
  }

  bool validateAllStudents() {
    for (String rollNo in groupedData.keys) {
      Map<int, List<BatchStudentData>> semesters = groupedData[rollNo]!;

      // Only validate semesters that have been filled
      for (int semesterNumber in semesters.keys) {
        List<BatchStudentData> semesterData = semesters[semesterNumber]!;

        for (var data in semesterData) {
          TextEditingController theoryController =
              getController(rollNo, data.subjectName, 'Theory');
          TextEditingController practicalController =
              getController(rollNo, data.subjectName, 'Practical');

          // Only validate if fields are filled (ignore empty fields for unfilled semesters)
          if (theoryController.text.isNotEmpty &&
              practicalController.text.isNotEmpty) {
            if (int.tryParse(theoryController.text) == null ||
                int.tryParse(practicalController.text) == null) {
              return false;
            }
            int theoryMarks = int.parse(theoryController.text);
            int practicalMarks = int.parse(practicalController.text);
            if (theoryMarks < 0 ||
                practicalMarks < 0 ||
                theoryMarks > data.theoryMarks ||
                practicalMarks > data.practicalMarks) {
              return false;
            }
          }
        }
      }
    }
    return true;
  }

  List<Map<String, dynamic>> buildAllDetails() {
    List<Map<String, dynamic>> details = [];
    for (String rollNo in groupedData.keys) {
      Map<int, List<BatchStudentData>> semesters = groupedData[rollNo]!;

      // Collect data for semesters that have been filled
      for (int semesterNumber in semesters.keys) {
        List<BatchStudentData> semesterData = semesters[semesterNumber]!;

        for (var data in semesterData) {
          TextEditingController theoryController =
              getController(rollNo, data.subjectName, 'Theory');
          TextEditingController practicalController =
              getController(rollNo, data.subjectName, 'Practical');

          // Only include in details if fields are filled (not empty)
          if (theoryController.text.isNotEmpty &&
              practicalController.text.isNotEmpty) {
            int theoryMarks = int.tryParse(theoryController.text) ?? 0;
            int practicalMarks = int.tryParse(practicalController.text) ?? 0;

            details.add({
              "BatchMappingID": data.batchMappingId,
              "ExamIndentTransID": data.examIndentTransId,
              "ObtainedPracticalMarks": practicalMarks,
              "ObtainedTheoryMarks": theoryMarks,
              "PracticalMarks": data.practicalMarks,
              "Semester": data.semester,
              "SubjectMappingID": data.subjectMappingId,
              "TheoryMarks": data.theoryMarks,
            });
          }
        }
      }
    }
    return details;
  }
}
