import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/exam/view/widgets/student_indent_dropdown.dart';
import 'package:tcds/utils/helper_functions/bottom_sheet_template.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:tcds/utils/helper_widgets/out_button.dart';
import '../../../../utils/helper_widgets/date_picker_textfield.dart';
import '../../../../utils/helper_widgets/single_dropdown.dart';
import '../../../students_list/controller/student_list_controller.dart';
import '../../model/franchise_course_batch_list_model.dart';
import '../../model/franchise_course_list_model.dart';

Future addIndentSheet({
  required BuildContext context,
  bool openToEdit = false,
  Map<String, dynamic>? createdIndentData,
}) async {
  // find student get ctrler
  StudentListController studentListController =
      Get.find<StudentListController>();

  DateFormat inpuDatetFormat = DateFormat('dd-MM-yyyy');
  DateFormat outputDateFormat = DateFormat('MM-dd-yyyy');

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  // text controllers
  TextEditingController courseNameTxtCtrl = TextEditingController();
  TextEditingController courseIDTxtCtrl = TextEditingController();
  TextEditingController batchNameTxtCtrl = TextEditingController();
  TextEditingController batchIDTxtCtrl = TextEditingController();
  TextEditingController studentNameTxtCtrl = TextEditingController();
  TextEditingController studentBatchIDTxtCtrl = TextEditingController();
  TextEditingController examDateTxtCtrl = TextEditingController();

  // if sheet is opened to edit let's assign initial selected values
  if (openToEdit && createdIndentData != null) {
    final courseData = createdIndentData["courseData"] as FranchiseCourseData;
    final batchData = createdIndentData["batchData"] as CourseBatchData;
    // assign to text ctrls
    courseNameTxtCtrl.text = courseData.shortName;
    courseIDTxtCtrl.text = courseData.courseId;
    batchNameTxtCtrl.text = batchData.batchNumber;
    batchIDTxtCtrl.text = batchData.courseBatchId;
    int selectedCount = createdIndentData["batchMappingIDs"]?.length ?? 0;
    studentNameTxtCtrl.text ==
        "$selectedCount ${selectedCount == 1 ? "Student" : "Students"}";
    studentBatchIDTxtCtrl.text = createdIndentData["batchMappingIDs"].join(",");
    examDateTxtCtrl.text = createdIndentData["examDate"];
  }

  return bottomSheetTemplate(
      context: context,
      // isDismissible: false,
      headerText: 'Add Indent',
      content: StatefulBuilder(builder: (context, indentState) {
        return Form(
          key: formKey,
          child: Column(
            children: [
              SingleSelectDropDown(
                key: UniqueKey(),
                labelText: "Course",
                valueController: courseIDTxtCtrl,
                valueTextController: courseNameTxtCtrl,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Course is required';
                  } else {
                    return null;
                  }
                },
                data: List.generate(
                  studentListController.franchiseCourseDataList.length,
                  (index) => SingleSelectDropDownModel(
                      studentListController
                          .franchiseCourseDataList[index].shortName,
                      studentListController
                          .franchiseCourseDataList[index].courseId),
                ),
                parentOnChangeCall: (value) async {
                  // clear text controllers
                  batchNameTxtCtrl.clear();
                  batchIDTxtCtrl.clear();
                  studentNameTxtCtrl.clear();
                  studentBatchIDTxtCtrl.clear();
                  examDateTxtCtrl.clear();
                  studentListController.franchiseStudentBatchDataList.clear();

                  await studentListController.getFranchiseCourseBatchList(
                      courseId: courseIDTxtCtrl.text);
                  if (studentListController
                      .franchiseCourseBatchDataList.isNotEmpty) {
                    await studentListController.getStudentListByBatch(
                        batchId: studentListController
                            .franchiseCourseBatchDataList[0].courseBatchId);
                  }
                  indentState(() {});
                },
              ),
              const SizedBox(
                height: 20,
              ),
              SingleSelectDropDown(
                key: UniqueKey(),
                labelText: "Batch",
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Batch is Required';
                  } else {
                    return null;
                  }
                },
                valueController: batchIDTxtCtrl,
                valueTextController: batchNameTxtCtrl,
                data: List.generate(
                  studentListController.franchiseCourseBatchDataList.length,
                  (index) => SingleSelectDropDownModel(
                      studentListController
                          .franchiseCourseBatchDataList[index].batchNumber,
                      studentListController
                          .franchiseCourseBatchDataList[index].courseBatchId),
                ),
                parentOnChangeCall: (value) async {
                  // clear text controllers
                  studentNameTxtCtrl.clear();
                  studentBatchIDTxtCtrl.clear();
                  examDateTxtCtrl.clear();
                  studentListController.franchiseStudentBatchDataList.clear();

                  if (studentListController
                      .franchiseCourseBatchDataList.isNotEmpty) {
                    await studentListController.getStudentListByBatch(
                        batchId: batchIDTxtCtrl.text);
                  }
                  indentState(() {});
                },
              ),
              // if (studentListController
              //     .franchiseStudentBatchDataList.isNotEmpty)
              const SizedBox(
                height: 20,
              ),
              StudentIndentDropdown(
                dropdownValues:
                    studentListController.franchiseStudentBatchDataList,
                nameTxtCtrl: studentNameTxtCtrl,
                idTxtCtrl: studentBatchIDTxtCtrl,
              ),
              const SizedBox(
                height: 20,
              ),
              DatePickerTextField(
                controller: examDateTxtCtrl,
                labelText: 'Exam Date',
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Exam Date is Required';
                  } else {
                    return null;
                  }
                },
              ),
            ],
          ),
        );
      }),
      footer: Padding(
        padding: EdgeInsets.all(20.w),
        child: Row(
          children: [
            Expanded(
                child: OutButton(
              onTap: () {
                // close sheet
                Get.back();
              },
              text: "Cancel",
            )),
            SizedBox(
              width: 20.w,
            ),
            Expanded(
                child: InButton(
              onTap: () {
                // validate
                if (formKey.currentState!.validate()) {
                  // collect selected data
                  final courseData =
                      studentListController.franchiseCourseDataList.firstWhere(
                    (element) => element.courseId == courseIDTxtCtrl.text,
                  );
                  final batchData = studentListController
                      .franchiseCourseBatchDataList
                      .firstWhere(
                    (element) => element.courseBatchId == batchIDTxtCtrl.text,
                  );
                  // get selected students batch id's
                  List<String> batchIDs = studentBatchIDTxtCtrl.text.split(",");

                  final selectedStudentsData =
                      studentListController.franchiseStudentBatchDataList
                          .where(
                            (stuData) =>
                                batchIDs.contains(stuData.batchMappingId),
                          )
                          .toList();

                  // get total exam fees amount
                  double examFees = courseData.examFees * batchIDs.length;
                  // send back generated payload
                  Get.back(result: {
                    "batchMappingIDs": batchIDs, // -- Selected Batch ID's
                    "selectedBatchStudentsData":
                        selectedStudentsData, // -- Selected Students Data
                    "courseData": courseData, // -- Selected Course Data
                    "batchData": batchData, // -- Selected Batch Data
                    "examFees": examFees,
                    "totalBatchStudents": studentListController
                        .franchiseStudentBatchDataList
                        .length, // -- Total students in the batch
                    "selectedStundets":
                        batchIDs.length, // -- indent added students count
                    "examDate": outputDateFormat
                        .format(inpuDatetFormat.parse(examDateTxtCtrl.text)),
                  });
                }
              },
              text: "Apply",
            )),
          ],
        ),
      ));
}
