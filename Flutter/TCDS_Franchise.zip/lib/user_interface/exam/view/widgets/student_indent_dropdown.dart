import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../../constants/colors.dart';
import '../../../../constants/font_sizes.dart';
import '../../../../utils/helper_widgets/custom_textfield.dart';
import '../../model/franchise_student_batch_list_model.dart';

class StudentIndentDropdown extends StatefulWidget {
  final List<BatchStudentData> dropdownValues;
  final TextEditingController nameTxtCtrl;
  final TextEditingController idTxtCtrl;
  const StudentIndentDropdown(
      {super.key,
      required this.dropdownValues,
      required this.nameTxtCtrl,
      required this.idTxtCtrl});

  @override
  State<StudentIndentDropdown> createState() => _StudentIndentDropdownState();
}

class _StudentIndentDropdownState extends State<StudentIndentDropdown> {
  // helper to show dropdown values
  bool showListValues = false;
  // helper Set to store selected students batch id
  Set<String> localSelectedBatchID = {};

  @override
  void initState() {
    // assign initial values of widget.idTxtCtrl
    String ids = widget.idTxtCtrl.text;
    if (widget.idTxtCtrl.text.isNotEmpty) {
      localSelectedBatchID.addAll(ids.split(","));
      int selectedCount = localSelectedBatchID.length;
      widget.nameTxtCtrl.text =
          "$selectedCount ${selectedCount == 1 ? "Student" : "Students"}";
      debugPrint("Init localSelectedBatchID $localSelectedBatchID");
    }
    super.initState();
  }

  @override
  void didUpdateWidget(covariant StudentIndentDropdown oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.idTxtCtrl.text != oldWidget.idTxtCtrl.text ||
        widget.dropdownValues != oldWidget.dropdownValues) {
      // call with postFrame to avoid build errors and update values
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showListValues = false;
        String ids = widget.idTxtCtrl.text;
        localSelectedBatchID.clear();
        if (ids.isNotEmpty) {
          localSelectedBatchID.addAll(ids.split(","));
        }

        int selectedCount = localSelectedBatchID.length;
        widget.nameTxtCtrl.text =
            "$selectedCount ${selectedCount == 1 ? "Student" : "Students"}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => setState(() => showListValues = !showListValues),
          child: Column(
            children: [
              CustomTextField(
                labelText: 'Student',
                controller: widget.nameTxtCtrl,
                enabled: false,
                autofocus: false,
                hintStyle: TextStyle(
                  fontSize: AppFontSize.size4.sp,
                  color: AppColor.black2Color,
                  fontWeight: FontWeight.w400,
                ),
                validator: (val) {
                  if (val == null || val.isEmpty) {
                    return 'Student is Required';
                  } else if (localSelectedBatchID.isEmpty) {
                    return "Select a Student";
                  } else {
                    return null;
                  }
                },
                suffixIcon: showListValues
                    ? const Icon(
                        Icons.keyboard_arrow_up_outlined,
                        color: AppColor.blackColor,
                      )
                    : const Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: AppColor.blackColor,
                      ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10.w),
        if (showListValues)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
                color: Colors.grey.withValues(alpha: 0.2),
                child: Row(
                  children: [
                    Expanded(
                      flex: 45,
                      child: Text(
                        'ID',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 5.w,
                    ),
                    Expanded(
                      flex: 45,
                      child: Text(
                        'NAME',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 5.w,
                    ),
                    Expanded(
                      flex: 10,
                      child: Text(
                        'SEM',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                constraints: BoxConstraints(maxHeight: height * 0.4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      constraints: BoxConstraints(maxHeight: height * 0.4),
                      child: ListView.builder(
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount: widget.dropdownValues.length,
                          itemBuilder: (context, index) {
                            String currentBatchID =
                                widget.dropdownValues[index].batchMappingId;
                            // will be true if already selected else false.
                            bool isSelected =
                                localSelectedBatchID.contains(currentBatchID);

                            return InkWell(
                              child: Container(
                                padding: EdgeInsets.symmetric(vertical: 15.h),
                                color: index % 2 == 0
                                    ? Colors.white
                                    : Colors.grey.withValues(alpha: 0.1),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 45,
                                      child: Row(
                                        children: [
                                          Checkbox(
                                            value: isSelected,
                                            onChanged: (bool? value) async {
                                              setState(() {
                                                if (value ?? false) {
                                                  localSelectedBatchID
                                                      .add(currentBatchID);
                                                } else {
                                                  localSelectedBatchID
                                                      .remove(currentBatchID);
                                                }
                                                debugPrint(
                                                    "Checkbox OC localSelectedBatchID $localSelectedBatchID");
                                                widget.idTxtCtrl.text =
                                                    localSelectedBatchID
                                                        .join(",");
                                                debugPrint(
                                                    "Hold ID's ${widget.idTxtCtrl.text}");
                                                // assign selected values count to text controller
                                                int selectedStudslLength =
                                                    localSelectedBatchID.length;
                                                widget.nameTxtCtrl.text =
                                                    "$selectedStudslLength ${selectedStudslLength == 1 ? "Student" : "Students"}";
                                              });
                                            },
                                            activeColor: Colors.orange,
                                            checkColor: Colors.white,
                                            materialTapTargetSize:
                                                MaterialTapTargetSize
                                                    .shrinkWrap,
                                            side: const BorderSide(
                                              color: Colors.orange,
                                              width: 2,
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          Expanded(
                                            child: Text(
                                              widget.dropdownValues[index]
                                                  .rollNumber,
                                              style: TextStyle(
                                                fontSize: 12.sp,
                                                color: Colors.black,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5.w,
                                    ),
                                    Expanded(
                                      flex: 45,
                                      child: Text(
                                        widget
                                            .dropdownValues[index].contactName,
                                        style: TextStyle(
                                          fontSize: 12.sp,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5.w,
                                    ),
                                    Expanded(
                                      flex: 10,
                                      child: Text(
                                        widget.dropdownValues[index].semester
                                            .toString(),
                                        style: TextStyle(
                                          fontSize: 12.sp,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ],
          )
      ],
    );
  }
}

// Indent - Student dropdown data model
class StudentIndentDropdownModel {
  final String batchMappingID;
  final String studentID;
  final String contactName;
  final String rollNumber;
  final int semester;

  StudentIndentDropdownModel(this.batchMappingID, this.studentID,
      this.contactName, this.rollNumber, this.semester);
}
