import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/fees_collection/model/document_download.dart';
import 'package:tcds/user_interface/fees_collection/model/fees_balance_response_model.dart';
import 'package:tcds/user_interface/fees_collection/model/student_payment_history_response_model.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import '../../dashboard/model/profile_image_response_model.dart';

class FeesCollectionController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxList<FeesBalanceList> feesBalanceList = <FeesBalanceList>[].obs;
  RxList<StudentPaymentList> studentPaymentList = <StudentPaymentList>[].obs;
  RxList<ProfileImageData> profileImageDataList = <ProfileImageData>[].obs;
  RxList<ProfileImageData> imageResponse = <ProfileImageData>[].obs;
  RxBool feesCollectionScreenLoader = false.obs;
  RxBool studentPaymentScreenLoader = false.obs;
  RxList<DocumentDownload> latestDownloadedDocument = <DocumentDownload>[].obs;

  Future<bool> getFeesBalanceListWithMappingId(
      {required String batchMappingId}) async {
    // feesCollectionScreenLoader.value = true;
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.feesBalanceList + batchMappingId)
          .then((value) async {
        FeesBalanceResponseModel model =
            FeesBalanceResponseModel.fromJson(value.data);
        feesBalanceList.value = model.data;
        // after fetched fees balance list let's loop through it for to get and store owner image as base64
        for (var i = 0; i < feesBalanceList.length; i++) {
          // Fetch the Base64 image for the current contact ID
          bool imageFetched =
              await getProfilePicture(contactID: feesBalanceList[i].contactId);
          if (imageFetched && profileImageDataList.isNotEmpty) {
            feesBalanceList[i].base64Image =
                profileImageDataList[0].profileBase64;
          }
        }
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // Get Profile picture
  Future<bool> getProfilePicture({required String contactID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getProfileImage + contactID,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        ProfileImageResponseModel model =
            ProfileImageResponseModel.fromJson(value.data);
        profileImageDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getStudentPaymentHistory(
      {required String batchMappingId}) async {
    studentPaymentScreenLoader.value = true;
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl +
              AppStrings.studentPaymentHistory +
              batchMappingId)
          .then((value) {
        StudentPaymentHistoryResponseModel model =
            StudentPaymentHistoryResponseModel.fromJson(value.data);
        studentPaymentList.value = model.data;
        studentPaymentScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> documentDownload({required String documentID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(
              AppStrings.baseUrl +
                  AppStrings.documentDownloadBase64 +
                  documentID,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        DocumentDownloadResponseModel model =
            DocumentDownloadResponseModel.fromJson(value.data);
        latestDownloadedDocument.clear();
        latestDownloadedDocument.add(model.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
