import 'dart:convert';

DocumentDownloadResponseModel documentDownloadResponseModelFromJson(
        String str) =>
    DocumentDownloadResponseModel.fromJson(json.decode(str));

String documentDownloadResponseModelToJson(
        DocumentDownloadResponseModel data) =>
    json.encode(data.toJson());

class DocumentDownloadResponseModel {
  int code;
  String message;
  DocumentDownload data;

  DocumentDownloadResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DocumentDownloadResponseModel.fromJson(Map<String, dynamic> json) =>
      DocumentDownloadResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: DocumentDownload.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class DocumentDownload {
  String documentId;
  String primaryKeyId;
  String documentType;
  String mimeType;
  String fileName;
  String fileExtension;
  String profileBase64;
  String thumbnailBase64;

  DocumentDownload({
    required this.documentId,
    required this.primaryKeyId,
    required this.documentType,
    required this.mimeType,
    required this.fileName,
    required this.fileExtension,
    required this.profileBase64,
    required this.thumbnailBase64,
  });

  factory DocumentDownload.fromJson(Map<String, dynamic> json) =>
      DocumentDownload(
        documentId: json["DocumentID"],
        primaryKeyId: json["PrimaryKeyID"],
        documentType: json["DocumentType"],
        mimeType: json["MIMEType"],
        fileName: json["FileName"],
        fileExtension: json["FileExtension"],
        profileBase64: json["ProfileBase64"],
        thumbnailBase64: json["ThumbnailBase64"],
      );

  Map<String, dynamic> toJson() => {
        "DocumentID": documentId,
        "PrimaryKeyID": primaryKeyId,
        "DocumentType": documentType,
        "MIMEType": mimeType,
        "FileName": fileName,
        "FileExtension": fileExtension,
        "ProfileBase64": profileBase64,
        "ThumbnailBase64": thumbnailBase64,
      };
}
