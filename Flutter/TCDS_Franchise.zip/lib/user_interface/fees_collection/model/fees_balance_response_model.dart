class FeesBalanceResponseModel {
  int code;
  String message;
  List<FeesBalanceList> data;

  FeesBalanceResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FeesBalanceResponseModel.fromJson(Map<String, dynamic> json) =>
      FeesBalanceResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<FeesBalanceList>.from(
            json["Data"].map((x) => FeesBalanceList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FeesBalanceList {
  String courseBatchId;
  String courseId;
  String batchMappingId;
  String contactId;
  String course;
  String courseType;
  String duration;
  double courseFees;
  double discount;
  double totalFees;
  double paidFees;
  double balance;
  bool isActive;
  bool isCompleted;
  String reason;
  int totalSemesters;
  String status;
  String startDate;
  String endDate;
  String rollNumber;
  String studentName;
  String shortCourseName;
  String? base64Image;

  FeesBalanceList({
    required this.courseBatchId,
    required this.courseId,
    required this.batchMappingId,
    required this.contactId,
    required this.course,
    required this.courseType,
    required this.duration,
    required this.courseFees,
    required this.discount,
    required this.totalFees,
    required this.paidFees,
    required this.balance,
    required this.isActive,
    required this.isCompleted,
    required this.reason,
    required this.totalSemesters,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.rollNumber,
    required this.studentName,
    required this.shortCourseName,
    this.base64Image,
  });

  factory FeesBalanceList.fromJson(Map<String, dynamic> json) =>
      FeesBalanceList(
        courseBatchId: json["CourseBatchID"],
        courseId: json["CourseID"],
        batchMappingId: json["BatchMappingID"],
        contactId: json["ContactID"],
        course: json["Course"],
        courseType: json["CourseType"],
        duration: json["Duration"],
        courseFees: json["CourseFees"],
        discount: json["Discount"],
        totalFees: json["TotalFees"],
        paidFees: json["PaidFees"],
        balance: json["Balance"],
        isActive: json["IsActive"],
        isCompleted: json["IsCompleted"],
        reason: json["Reason"],
        totalSemesters: json["TotalSemesters"],
        status: json["Status"],
        startDate: json["StartDate"],
        endDate: json["EndDate"],
        rollNumber: json["RollNumber"],
        studentName: json["StudentName"],
        shortCourseName: json["ShortName"],
      );

  Map<String, dynamic> toJson() => {
        "CourseBatchID": courseBatchId,
        "CourseID": courseId,
        "BatchMappingID": batchMappingId,
        "ContactID": contactId,
        "Course": course,
        "CourseType": courseType,
        "Duration": duration,
        "CourseFees": courseFees,
        "Discount": discount,
        "TotalFees": totalFees,
        "PaidFees": paidFees,
        "Balance": balance,
        "IsActive": isActive,
        "IsCompleted": isCompleted,
        "Reason": reason,
        "TotalSemesters": totalSemesters,
        "Status": status,
        "StartDate": startDate,
        "EndDate": endDate,
        "RollNumber": rollNumber,
        "StudentName": studentName,
        "ShortName": shortCourseName
      };
}
