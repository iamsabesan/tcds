// To parse this JSON data, do
//
//     final studentPaymentHistoryResponseModel = studentPaymentHistoryResponseModelFromJson(jsonString);

import 'dart:convert';

StudentPaymentHistoryResponseModel studentPaymentHistoryResponseModelFromJson(String str) => StudentPaymentHistoryResponseModel.fromJson(json.decode(str));

String studentPaymentHistoryResponseModelToJson(StudentPaymentHistoryResponseModel data) => json.encode(data.toJson());

class StudentPaymentHistoryResponseModel {
  int code;
  String message;
  List<StudentPaymentList> data;

  StudentPaymentHistoryResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StudentPaymentHistoryResponseModel.fromJson(Map<String, dynamic> json) => StudentPaymentHistoryResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<StudentPaymentList>.from(json["Data"].map((x) => StudentPaymentList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class StudentPaymentList {
  String voucherDate;
  String receiptNo;
  String paymentType;
  String tenantBranchTransId;
  double amount;
  List<Paymode> paymodes;

  StudentPaymentList({
    required this.voucherDate,
    required this.receiptNo,
    required this.paymentType,
    required this.tenantBranchTransId,
    required this.amount,
    required this.paymodes,
  });

  factory StudentPaymentList.fromJson(Map<String, dynamic> json) => StudentPaymentList(
    voucherDate: json["VoucherDate"],
    receiptNo: json["ReceiptNo"],
    paymentType: json["PaymentType"],
    tenantBranchTransId: json["TenantBranchTransID"],
    amount: json["Amount"],
    paymodes: List<Paymode>.from(json["Paymodes"].map((x) => Paymode.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "VoucherDate": voucherDate,
    "ReceiptNo": receiptNo,
    "PaymentType": paymentType,
    "TenantBranchTransID": tenantBranchTransId,
    "Amount": amount,
    "Paymodes": List<dynamic>.from(paymodes.map((x) => x.toJson())),
  };
}

class Paymode {
  String tenantBranchTransId;
  double amount;
  String payMode;
  String summary;
  String transactionDate;
  String documentId;

  Paymode({
    required this.tenantBranchTransId,
    required this.amount,
    required this.payMode,
    required this.summary,
    required this.transactionDate,
    required this.documentId,
  });

  factory Paymode.fromJson(Map<String, dynamic> json) => Paymode(
    tenantBranchTransId: json["TenantBranchTransID"],
    amount: json["Amount"],
    payMode: json["PayMode"],
    summary: json["Summary"],
    transactionDate: json["TransactionDate"],
    documentId: json["DocumentID"],
  );

  Map<String, dynamic> toJson() => {
    "TenantBranchTransID": tenantBranchTransId,
    "Amount": amount,
    "PayMode": payMode,
    "Summary": summary,
    "TransactionDate": transactionDate,
    "DocumentID": documentId,
  };
}
