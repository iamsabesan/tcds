import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/fees_collection/controller/fees_collection_controller.dart';
import 'package:tcds/user_interface/fees_collection/model/fees_balance_response_model.dart';
import 'package:tcds/user_interface/fees_collection/view/student_detail_screen.dart';
import 'package:tcds/user_interface/students_list/controller/student_list_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_widget_two.dart';
import 'package:tcds/utils/helper_widgets/name_mobile_dropdown.dart';

import '../../../utils/helper_widgets/pop_scope_handler.dart';

class FeesCollectionListScreen extends StatefulWidget {
  final String? filteredStudentId;

  const FeesCollectionListScreen({
    super.key,
    this.filteredStudentId,
  });

  @override
  State<FeesCollectionListScreen> createState() =>
      _FeesCollectionListScreenState();
}

int _selectedIndex = 9;

class _FeesCollectionListScreenState extends State<FeesCollectionListScreen> {
  FeesCollectionController feesCollectionController =
      Get.put(FeesCollectionController());
  StudentListController studentListController =
      Get.put(StudentListController());
  DashboardController dashboardController = Get.put(DashboardController());

  NameMobileDropDownModel? selectedStudent;

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);
  NumberFormat zeroDecFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '', decimalDigits: 0);
  NumberFormat rsCurrencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: 'Rs.', decimalDigits: 2);

  bool withBackArrow = false;
  @override
  void initState() {
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }

    getApiCall();
    filteredList = feesCollectionController.feesBalanceList;
    super.initState();
  }

  List<FeesBalanceList> filteredList = [];

  TextEditingController nameMobCtrl = TextEditingController();
  TextEditingController nameMobTextCtrl = TextEditingController();

  Future<void> getApiCall() async {
    setState(() {
      feesCollectionController.feesCollectionScreenLoader.value = true;
    });
    // call students list
    await studentListController.getStudentListByBatchWise();
    // await feesCollectionController.getFeesBalanceListWithMappingId();
    setState(() {
      feesCollectionController.feesCollectionScreenLoader.value = false;
    });
  }
/* 
  void filterList() {
    String query = nameMobCtrl.text.toLowerCase();
    setState(() {
      filteredList = feesCollectionController.feesBalanceList.where((item) {
        return item.studentName.toLowerCase().contains(query) ||
            item.rollNumber.toLowerCase().contains(query) ||
            item.course.toLowerCase().contains(query);
      }).toList();
    });
  } */

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final TextEditingController valueController = TextEditingController();
  final TextEditingController batchMappingIDController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 2,
        ),
      ),
      appBar: AppBar(
        scrolledUnderElevation: 2,
        toolbarHeight: 70,
        backgroundColor: AppColor.whiteColor,
        titleSpacing: 0,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        title: CustomText(
          text: "Fees Collection",
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                  // Handle menu action
                },
              ),
      ),
      body: PopScopeHandler(
        child: feesCollectionController.feesCollectionScreenLoader.value
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColor.primaryColor,
                ),
              )
            : Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 20),
                    child: Obx(
                      () => NameMobileDropDown(
                        dropdownValues: List.generate(
                            studentListController
                                .studentByBranchWiseList.length, (index) {
                          batchMappingIDController.text = studentListController
                              .studentByBranchWiseList[index].batchMappingId;
                          return NameMobileDropDownModel(
                            studentListController
                                .studentByBranchWiseList[index].studentName
                                .toString(),
                            studentListController
                                .studentByBranchWiseList[index].phone,
                            studentListController
                                .studentByBranchWiseList[index].rollNumber,
                            studentListController
                                .studentByBranchWiseList[index].batchMappingId,
                          );
                        }),
                        controller: nameMobCtrl,
                        onParentTap: () async {
                          setState(() {});
                        },
                        valueController: nameMobTextCtrl,
                        labelText: 'Name/Mobile',
                      ),
                    ),
                  ),
                  Obx(
                    () => Expanded(
                      child: feesCollectionController.feesBalanceList.isEmpty
                          ? Center(
                              child: CustomText(
                                text: 'No data available',
                                fontWeight: FontWeight.w500,
                                color: AppColor.secondaryColor,
                                fontSize: AppFontSize.size3.sp,
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.only(bottom: 150),
                              itemCount: feesCollectionController
                                  .feesBalanceList.length,
                              itemBuilder: (BuildContext context, int index) {
                                final feesData = feesCollectionController
                                    .feesBalanceList[index];
                                debugPrint("List");
                                return CustomWidgetTwo(
                                  currencyFormat: currencyFormat,
                                  base64: feesData.base64Image,
                                  text3Color: AppColor.primaryColor,
                                  text4Color: AppColor.blackColor,
                                  text6Color: AppColor.primaryColor,
                                  text5Color: AppColor.primaryColor,
                                  text1: feesData.studentName,
                                  text2: feesData.rollNumber,
                                  text3: feesData.duration,
                                  text4: "S:${feesData.startDate}",
                                  text5: feesData.shortCourseName,
                                  text6: "E:${feesData.endDate}",
                                  withDivider: true,
                                  withForwardArrow: true,
                                  onTap: () {
                                    debugPrint(
                                        "Contact ID : ${feesCollectionController.feesBalanceList[index].contactId}");
                                    Get.to(
                                        () => StudentDetailScreen(
                                              rsCurrencyFormat:
                                                  rsCurrencyFormat,
                                              batchMappingId:
                                                  feesCollectionController
                                                      .feesBalanceList[index]
                                                      .batchMappingId,
                                              feesBalanceList:
                                                  feesCollectionController
                                                      .feesBalanceList[index],
                                            ),
                                        transition: Transition.rightToLeft,
                                        duration:
                                            const Duration(milliseconds: 600));
                                  },
                                  children: [
                                    Flexible(
                                      child: Align(
                                        alignment: Alignment.centerLeft,
                                        child: CustomText(
                                          text:
                                              "TOT: ${zeroDecFormat.format(feesData.totalFees)}",
                                          color: AppColor.primaryColor,
                                          fontWeight: FontWeight.w600,
                                          fontSize: AppFontSize.size5.sp,
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: CustomText(
                                          text:
                                              "PAID: ${zeroDecFormat.format(feesData.paidFees)}",
                                          color: AppColor.green,
                                          fontWeight: FontWeight.w600,
                                          fontSize: AppFontSize.size5.sp,
                                        ),
                                      ),
                                    ),
                                    Flexible(
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: CustomText(
                                          text:
                                              "BAL: ${zeroDecFormat.format(feesData.balance)}",
                                          color: AppColor.deleteRed,
                                          fontWeight: FontWeight.w600,
                                          fontSize: AppFontSize.size5.sp,
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                    ),
                  ),
                ],
              ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.offAll(() => const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
