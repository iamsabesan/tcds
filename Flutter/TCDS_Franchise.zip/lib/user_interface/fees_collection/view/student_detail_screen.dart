import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/user_interface/fees_collection/controller/fees_collection_controller.dart';
import 'package:tcds/user_interface/students_list/controller/student_list_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_sheets.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';
import 'package:tcds/utils/helper_widgets/paymode_bottom_sheet.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/custom_textfield.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/out_button.dart';
import '../model/fees_balance_response_model.dart';

class StudentDetailScreen extends StatefulWidget {
  final String batchMappingId;
  final FeesBalanceList feesBalanceList;
  final NumberFormat rsCurrencyFormat;
  const StudentDetailScreen(
      {super.key,
      required this.batchMappingId,
      required this.feesBalanceList,
      required this.rsCurrencyFormat});

  @override
  State<StudentDetailScreen> createState() => _StudentDetailScreenState();
}

class _StudentDetailScreenState extends State<StudentDetailScreen>
    with SingleTickerProviderStateMixin {
  StudentListController studentListController =
      Get.put(StudentListController());
  FeesCollectionController feesCollectionController =
      Get.find<FeesCollectionController>();
  DashboardController dashboardController = Get.put(DashboardController());
  bool isApiCalled = false;

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);

  late String selectedPaymentMethod;
  double totalPayable = 0;
  double totalPaid = 0;
  double paidAmount = 0;
  double balance = 0;
  double amountEnteredInText = 0;
  double amountEnteredInBs = 0;
  bool allowPayment = false;
  bool paymentEntered = false;

  TextEditingController amountCtrl = TextEditingController();

  List<Map<String, dynamic>> paymentDetails = [];
  // ignore: prefer_typing_uninitialized_variables
  var selectedPaymodeId;
  void removePayment(String paymentMode) {
    setState(() {
      // Find the index of the payment to remove
      int indexToRemove = paymentDetails
          .indexWhere((payment) => payment['paymodeType'] == paymentMode);

      if (indexToRemove != -1) {
        double amountToRemove = double.tryParse(
                paymentDetails[indexToRemove]['amount'].toString()) ??
            0.0;
        paymentDetails.removeAt(indexToRemove);

        // Reset paidAmount if no payments remain
        if (paymentDetails.isEmpty) {
          balance = amountEnteredInText;
          amountEnteredInBs = 0.0;
          paidAmount = 0.0;
        } else {
          paidAmount -= amountToRemove;
          amountEnteredInBs -= amountToRemove;
          balance += amountToRemove;
        }

        // Remove the payment from the list
      }
    });
  }

  void updateAmount() {
    // Parse the amount entered by the user
    double enteredAmount = double.tryParse(amountCtrl.text) ?? 0;

    // If the entered amount is more than the amount payable, it should be accepted
    if (enteredAmount > totalPayable) {
      setState(() {
        totalPaid =
            enteredAmount; // User entered an amount greater than the total payable
        balance = 0; // No balance left to pay
      });
      Get.snackbar(
        'Fees Receivable',
        'Amount entered is Higher than Payable amount',
        colorText: AppColor.whiteColor,
        padding: EdgeInsets.all(15.w),
        backgroundColor: AppColor.primaryColor,
      );
    } else {
      setState(() {
        allowPayment = true;
        totalPaid = enteredAmount;
        amountEnteredInText = enteredAmount;
        balance = amountEnteredInText;
        // balance = totalPayable - totalPaid;
      });
    }
  }

  // Helper to convert api format date string to user friendly
  String userDateFormartion(String stringAPIDate) {
    return DateFormat('dd-MM-yyyy')
        .format(DateFormat('yyyy-MM-dd').parse(stringAPIDate));
  }

  @override
  void initState() {
    super.initState();
    totalPayable = widget.feesBalanceList.balance;
    if (!isApiCalled) {
      getApiCall();
      isApiCalled = true;

      // Mark as called
    }
    _tabController = TabController(length: 2, vsync: this, initialIndex: 0);
  }

  Future<void> getApiCall() async {
    await feesCollectionController.getStudentPaymentHistory(
        batchMappingId: widget.batchMappingId);
    await dashboardController.getPayMode();
    await dashboardController.getCashLedger();
    await dashboardController.getAdminBankName();
    await dashboardController.getFranchiseeBankName();
  }

  late TabController _tabController;

  void navigateIndex(int index) {
    _tabController.animateTo(index);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        titleSpacing: 0,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: "Fees Collection",
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundColor: AppColor.whiteColor,
                      maxRadius: 25.w,
                      minRadius: 15.w,
                      child: Container(
                        constraints: const BoxConstraints.expand(),
                        clipBehavior: Clip.antiAlias,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                        ),
                        // Show default profile image if profile pic value is emypty
                        // else show actual image
                        child: ClipOval(
                          // show base64 image only when it's not empty
                          // else show default image
                          child: widget.feesBalanceList.base64Image != null
                              ? Image.memory(
                                  base64Decode(
                                      widget.feesBalanceList.base64Image!),
                                  height: 50.w,
                                  width: 50.w,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Image.asset(
                                    AssetPath.userIcon,
                                    height: 50.w,
                                    width: 50.w,
                                    fit: BoxFit.cover,
                                  ),
                                )
                              : Image.asset(
                                  AssetPath.userIcon,
                                  height: 50.w,
                                  width: 50.w,
                                  fit: BoxFit.cover,
                                ),
                        ),
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Flexible(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                child: CustomText(
                                  text: widget.feesBalanceList.studentName,
                                  fontSize: AppFontSize.size3.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.primaryColor,
                                ),
                              ),
                              Flexible(
                                child: CustomText(
                                  text: widget.feesBalanceList.duration,
                                  fontSize: AppFontSize.size4.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.black2Color,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                child: CustomText(
                                  text: widget.feesBalanceList.shortCourseName,
                                  fontSize: AppFontSize.size4.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.black2Color,
                                ),
                              ),
                              Flexible(
                                child: CustomText(
                                  text: widget.feesBalanceList.rollNumber,
                                  fontSize: AppFontSize.size4.sp,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.pink,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          CustomText(
                            text: widget.feesBalanceList.course,
                            color: AppColor.orange,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size4.sp,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                child: CustomText(
                                  text:
                                      'Start : ${widget.feesBalanceList.startDate}',
                                  fontSize: AppFontSize.size4.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.black2Color,
                                ),
                              ),
                              Flexible(
                                child: CustomText(
                                  text:
                                      'End : ${widget.feesBalanceList.endDate}',
                                  fontSize: AppFontSize.size4.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppColor.black2Color,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    /* Flexible(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          CustomText(
                            text: widget.feesBalanceList.course,
                            color: AppColor.orange,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size4.sp,
                            overflow: TextOverflow.ellipsis,
                          ),
                          CustomText(
                            text: 'End : ${widget.feesBalanceList.endDate}',
                            fontSize: AppFontSize.size4.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.black2Color,
                          ),
                        ],
                      ),
                    ) */
                  ],
                ),
              ],
            ),
          ),
          TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: 'Fees Payment'),
              Tab(text: 'Fees History'),
            ],
            indicatorColor: AppColor.orange,
            labelColor: AppColor.orange,
            unselectedLabelColor: AppColor.blackColor,
            unselectedLabelStyle: const TextStyle(
              fontWeight: FontWeight.w400,
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                Column(
                  children: [
                    Expanded(
                      child: ListView(
                        children: [
                          SizedBox(
                            height: 10.w,
                          ),
                          _buildFeeRow(
                              'Course Fees',
                              widget.rsCurrencyFormat
                                  .format(widget.feesBalanceList.courseFees)),
                          _buildFeeRow(
                              'Discount Amount',
                              widget.rsCurrencyFormat.format((widget
                                      .feesBalanceList.courseFees *
                                  (widget.feesBalanceList.discount / 100)))),
                          _buildFeeRow(
                              'Total Fees',
                              widget.rsCurrencyFormat
                                  .format(widget.feesBalanceList.totalFees)),
                          _buildFeeRow('Discount(%)',
                              '${widget.feesBalanceList.discount} %'),
                          _buildFeeRow(
                              'Fees Paid',
                              widget.rsCurrencyFormat
                                  .format(widget.feesBalanceList.paidFees),
                              AppColor.green),
                          _buildFeeRow(
                              'Balance Fees',
                              widget.rsCurrencyFormat
                                  .format(widget.feesBalanceList.balance),
                              AppColor.redColor),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 15),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 15),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: CustomTextField(
                                    labelText: "Fees Receivable",
                                    controller: amountCtrl,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.digitsOnly,
                                    ],
                                    onChanged: (value) {
                                      updateAmount(); // Update the amount whenever the user types
                                    },
                                  ),
                                ),
                                const SizedBox(height: 15),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: Center(
                                    child: Wrap(
                                      spacing: 15,
                                      runSpacing: 15,
                                      alignment: WrapAlignment.start,
                                      children: [
                                        500,
                                        1000,
                                        5000,
                                        10000,
                                      ].map((e) {
                                        return GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              amountCtrl.text = e.toString();
                                              updateAmount();
                                            });
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5, horizontal: 5),
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: AppColor.grey2,
                                              ),
                                              shape: BoxShape.rectangle,
                                              color: AppColor.whiteColor,
                                              borderRadius:
                                                  BorderRadius.circular(6.w),
                                            ),
                                            child: CustomText(
                                              text: "₹$e",
                                              color: AppColor.blackColor,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                ),
                                SizedBox(height: 25.w),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: CustomText(
                                    text: "Payment Method",
                                    color: AppColor.blackColor,
                                    fontSize: AppFontSize.size3.sp,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(height: 5.w),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    for (final method in [
                                      ['Wallet', 'Bank Transfer'],
                                      ['UPI', 'Cash'],
                                      ['Bank Remittance']
                                    ])
                                      GestureDetector(
                                        /*  onTap: () {
                                          if (((amountCtrl.text == "") ||
                                              (amountCtrl.text == "0"))) {
                                            Get.snackbar(
                                              'Fees Receivable',
                                              'Enter the amount in Fees Receivable',
                                              colorText: AppColor.whiteColor,
                                              padding: EdgeInsets.all(15.w),
                                              backgroundColor:
                                                  AppColor.primaryColor,
                                            );
                                          } else if (!allowPayment) {
                                            Get.snackbar(
                                              'Fees Receivable',
                                              'Enter Correct amount',
                                              colorText: AppColor.whiteColor,
                                              padding: EdgeInsets.all(15.w),
                                              backgroundColor:
                                                  AppColor.primaryColor,
                                            );
                                          } else {
                                            _openBottomSheetForMethod(
                                                method.toString(),
                                                selectedPaymodeId);
                                          }
                                        }, */
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: method
                                              .map((m) => Expanded(
                                                    child: InkWell(
                                                      onTap: () {
                                                        debugPrint(m);
                                                        setState(() {
                                                          selectedPaymentMethod =
                                                              m;
                                                          for (var i = 0;
                                                              i <
                                                                  dashboardController
                                                                      .payModeList
                                                                      .length;
                                                              i++) {
                                                            if (dashboardController
                                                                    .payModeList[
                                                                        i]
                                                                    .paymode
                                                                    .toLowerCase()
                                                                    .removeAllWhitespace ==
                                                                m
                                                                    .toLowerCase()
                                                                    .removeAllWhitespace) {
                                                              selectedPaymodeId =
                                                                  dashboardController
                                                                      .payModeList[
                                                                          i]
                                                                      .paymodeId;
                                                            }
                                                          }
                                                        });
                                                        if (((amountCtrl.text ==
                                                                "") ||
                                                            (amountCtrl.text ==
                                                                "0"))) {
                                                          Get.snackbar(
                                                            'Fees Receivable',
                                                            'Enter the amount in Fees Receivable',
                                                            colorText: AppColor
                                                                .whiteColor,
                                                            padding:
                                                                EdgeInsets.all(
                                                                    15.w),
                                                            backgroundColor:
                                                                AppColor
                                                                    .primaryColor,
                                                          );
                                                        } else if (!allowPayment) {
                                                          Get.snackbar(
                                                            'Fees Receivable',
                                                            'Enter Correct amount',
                                                            colorText: AppColor
                                                                .whiteColor,
                                                            padding:
                                                                EdgeInsets.all(
                                                                    15.w),
                                                            backgroundColor:
                                                                AppColor
                                                                    .primaryColor,
                                                          );
                                                        } else {
                                                          _openBottomSheetForMethod(
                                                              m.toString(),
                                                              selectedPaymodeId);
                                                        }
                                                      },
                                                      child: Container(
                                                        margin: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    15.w,
                                                                vertical: 5.w),
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                vertical: 10.w),
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border.all(
                                                              color:
                                                                  Colors.grey),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      15.0),
                                                          color: Colors.white,
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Padding(
                                                              padding: EdgeInsets
                                                                  .symmetric(
                                                                      horizontal:
                                                                          15.w),
                                                              child: CustomText(
                                                                text: m,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size4
                                                                        .sp,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ))
                                              .toList(),
                                        ),
                                      ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20.w,
                                ),
                                Card(
                                  color: AppColor.grey3,
                                  margin: const EdgeInsets.all(5),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Amount Payable",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size4.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              // text: "₹${payableAmount}",
                                              text: currencyFormat.format(
                                                  double.tryParse(
                                                          amountCtrl.text) ??
                                                      0),
                                              color: AppColor.green,
                                              fontSize: AppFontSize.size3.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                        const Divider(),
                                        // if (paymentDetails.isNotEmpty) const Divider(),
                                        SizedBox(
                                          height: 10.w,
                                        ),
                                        Column(
                                          children: List.generate(
                                              paymentDetails.length,
                                              (int historyIndex) {
                                            String mode =
                                                paymentDetails[historyIndex]
                                                    ["paymodeOriginal"];

                                            return ListTile(
                                              contentPadding: EdgeInsets.zero,
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    flex: 3,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Flexible(
                                                              child: CustomText(
                                                                text: mode,
                                                                color: AppColor
                                                                    .blackColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                maxLines: 2,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size5
                                                                        .sp,
                                                              ),
                                                            ),
                                                            if (mode.toUpperCase() ==
                                                                    'UPI' ||
                                                                mode
                                                                        .toLowerCase()
                                                                        .removeAllWhitespace ==
                                                                    'bankremittance') // Condition for specific modes
                                                              SizedBox(
                                                                  width: 5.w),
                                                            if (mode.toUpperCase() ==
                                                                    'UPI' ||
                                                                mode
                                                                        .toLowerCase()
                                                                        .removeAllWhitespace ==
                                                                    'bankremittance')
                                                              // InkWell(
                                                              // onTap: () {
                                                              //   // _showImageDialog(context, paymentDetails[historyIndex]["DocumentID"]);
                                                              // },
                                                              // child:
                                                              Image.asset(
                                                                'assets/file_image.png', // Replace with your asset path
                                                                height: 20.w,
                                                                width: 20.w,
                                                              ),
                                                            // ),
                                                          ],
                                                        ),
                                                        CustomText(
                                                          text: userDateFormartion(
                                                              paymentDetails[
                                                                      historyIndex]
                                                                  [
                                                                  "transactionDate"]),
                                                          color: AppColor
                                                              .blackColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontSize: AppFontSize
                                                              .size5.sp,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 5.w,
                                                  ),
                                                  if (mode.toLowerCase() !=
                                                      "cash")
                                                    Expanded(
                                                      flex: 4,
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          // CustomText(
                                                          //   text:
                                                          //       "From : ${paymentDetails[historyIndex]["fromLedgerName"]}",
                                                          //   color: AppColor
                                                          //       .black2Color,
                                                          //   fontWeight:
                                                          //       FontWeight.w400,
                                                          //   fontSize:
                                                          //       AppFontSize
                                                          //           .size5.sp,
                                                          // ),
                                                          CustomText(
                                                            text:
                                                                "To : ${paymentDetails[historyIndex]["toLedgerName"]}",
                                                            color: AppColor
                                                                .black2Color,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size5.sp,
                                                          ),
                                                          if (paymentDetails[
                                                                      historyIndex]
                                                                  [
                                                                  "transactionNo"] !=
                                                              null)
                                                            CustomText(
                                                              text:
                                                                  "#${paymentDetails[historyIndex]["transactionNo"]}",
                                                              color: AppColor
                                                                  .black2Color,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize:
                                                                  AppFontSize
                                                                      .size5.sp,
                                                            ),
                                                        ],
                                                      ),
                                                    ),
                                                  Expanded(
                                                    flex: 3,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        CustomText(
                                                          text: currencyFormat.format(
                                                              double.tryParse(paymentDetails[
                                                                          historyIndex]
                                                                      [
                                                                      "amount"]) ??
                                                                  0),
                                                          color: AppColor
                                                              .blackColor,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize: AppFontSize
                                                              .size4.sp,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
                                              trailing: InkWell(
                                                borderRadius:
                                                    BorderRadius.circular(12.r),
                                                onTap: () {
                                                  removePayment(paymentDetails[
                                                          historyIndex]
                                                      ['paymodeType']);
                                                },
                                                child: Icon(
                                                  Icons.cancel,
                                                  color: Colors.red,
                                                  size: 20.w,
                                                ),
                                              ),
                                            );
                                          }),
                                        ),
                                        if (paymentDetails.isNotEmpty)
                                          const Divider(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Amount Paid",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size4.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              text: currencyFormat
                                                  .format(paidAmount),
                                              color: AppColor.green,
                                              fontSize: AppFontSize.size4.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.w,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Balance",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size4.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              text: currencyFormat
                                                  .format(balance),
                                              color: AppColor.redColor,
                                              fontSize: AppFontSize.size4.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: 25.w, vertical: 30.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            flex: 1,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 25.0),
                              child: InkWell(
                                child: OutButton(
                                  onTap: () {
                                    Get.back();
                                  },
                                  withArrow: false,
                                  text: "Back",
                                  verticalPadding: 10.w,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 25.w,
                          ),
                          Expanded(
                            flex: 1,
                            child: Padding(
                              padding: const EdgeInsets.only(right: 25.0),
                              child: InkWell(
                                child: InButton(
                                  onTap: () async {
                                    if ((paymentEntered) && (balance == 0)) {
                                      // prepare json to send
                                      final body = {
                                        "batchMappingID": widget
                                            .feesBalanceList.batchMappingId,
                                        "paymentItems": paymentDetails,
                                      };

                                      // log(body.toString());

                                      // call api
                                      // PleaseWaitLoader.openDialog();
                                      final bool isTopUpAdded =
                                          await dashboardController
                                              .saveStudentPartPayment(
                                                  body: body);
                                      PleaseWaitLoader.closeDialog();
                                      if (isTopUpAdded) {
                                        // succes message
                                        debugPrint("Topup added");
                                        Get.back();
                                        await feesCollectionController
                                            .getStudentPaymentHistory(
                                                batchMappingId:
                                                    widget.batchMappingId);
                                        // navigateIndex(1);
                                        showSuccessDialog(
                                            context: Get.context!,
                                            message: 'Fees Paid Successfully');
                                      }
                                    } else {
                                      Get.snackbar(
                                        'Payable amount',
                                        'The amount is not tallied',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    }
                                  },
                                  withArrow: false,
                                  text: "Submit",
                                  color: AppColor.primaryColor,
                                  verticalPadding: 10.w,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Obx(
                  () => feesCollectionController
                          .studentPaymentScreenLoader.value
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: AppColor.primaryColor,
                          ),
                        )
                      : feesCollectionController.studentPaymentList.isEmpty
                          ? Center(
                              child: Column(
                                children: [
                                  CustomText(
                                    text: 'No data available',
                                    fontWeight: FontWeight.w500,
                                    color: AppColor.primaryColor,
                                    fontSize: AppFontSize.size3.sp,
                                  ),
                                ],
                              ),
                            )
                          : RefreshIndicator(
                              onRefresh: () async {
                                await feesCollectionController
                                    .getStudentPaymentHistory(
                                  batchMappingId: widget.batchMappingId,
                                );
                              },
                              child: ListView.builder(
                                itemCount: feesCollectionController
                                    .studentPaymentList.length,
                                itemBuilder: (context, index) {
                                  final history = feesCollectionController
                                      .studentPaymentList[index];
                                  return InkWell(
                                    onTap: () {
                                      PaymodeBottomSheet.payModeHistory(
                                          context: context,
                                          currencyFormat: currencyFormat,
                                          paymentDetails:
                                              feesCollectionController
                                                  .studentPaymentList[index]
                                                  .paymodes,
                                          documentDownload:
                                              feesCollectionController
                                                  .latestDownloadedDocument);
                                    },
                                    child: ListTile(
                                      title: CustomText(
                                        text: history.receiptNo,
                                        color: AppColor.blueColor,
                                        fontSize: AppFontSize.size4.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      subtitle: CustomText(
                                        text: history.voucherDate,
                                        color: AppColor.black2Color,
                                        fontSize: AppFontSize.size4.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      trailing: SizedBox(
                                        width: 150,
                                        child: Row(
                                          mainAxisSize: MainAxisSize
                                              .min, // Ensures the Row only takes the space it needs
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Expanded(
                                              flex: 2,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  CustomText(
                                                    text: currencyFormat
                                                        .format(history.amount),
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColor.orange,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                  CustomText(
                                                    text: history.paymentType,
                                                    fontWeight: FontWeight.w500,
                                                    color: AppColor.blackColor,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(
                                                width:
                                                    8), // Add spacing between the two columns
                                            const Column(
                                              mainAxisAlignment: MainAxisAlignment
                                                  .center, // Align the arrow vertically
                                              children: [
                                                ForwardArrowWidget(
                                                    /*   onTap: () {
                                                    PaymodeBottomSheet.payModeHistory(
                                                        context: context,
                                                        currencyFormat:
                                                            currencyFormat,
                                                        paymentDetails:
                                                            feesCollectionController
                                                                .studentPaymentList[
                                                                    index]
                                                                .paymodes,
                                                        documentDownload:
                                                            feesCollectionController
                                                                .latestDownloadedDocument);
                                                  }, */
                                                    ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeeRow(String label, String value, [Color? color]) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5.w, horizontal: 25.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: CustomText(
              text: label,
              fontSize: AppFontSize.size4.sp,
              color: color ?? AppColor.textBlackColor,
              fontWeight: FontWeight.w400,
            ),
          ),
          CustomText(
            text: ":",
            fontSize: AppFontSize.size4.sp,
            color: color ?? AppColor.textBlackColor,
            fontWeight: FontWeight.w400,
          ),
          Expanded(
            child: Align(
              alignment: Alignment.centerRight,
              child: CustomText(
                text: value,
                fontSize: AppFontSize.size4.sp,
                fontWeight: FontWeight.w500,
                color: color ?? AppColor.textBlackColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _openBottomSheetForMethod(
      String paymentMode, String selectedPaymodeId) async {
    // double remainingAmount = amountEnteredInText - totalPaid;
    double amntToBeTallied = amountEnteredInText - amountEnteredInBs;

    // // Check if payment is already confirmed for this mode
    // if (paymentConfirmed[paymentMode] == true) {
    //   Get.snackbar(
    //     'Error Message',
    //     'You already confirmed payment with $paymentMode.',
    //     colorText: AppColor.whiteColor,
    //     padding: EdgeInsets.all(15.w),
    //     backgroundColor: AppColor.primaryColor,
    //   );
    //   return;
    // }

    final result = await AppBottomSheets.feesPaymentModeBottomSheet(
      walletAmount: amountCtrl.text,
      currencyFormat: currencyFormat,
      selectedPaymodeId: selectedPaymodeId,
      paymentMode: paymentMode.toLowerCase().removeAllWhitespace,
      payModeOriginal: paymentMode,
      context: context,
      remainingAmount: amntToBeTallied,
      adminBankList: dashboardController.adminBankList,
      franchiseeBankList: dashboardController.franchiseeBankList,
      // onSubmit: (details) {
      //   setState(() {
      //     // /*     completedPayments.add(paymentMode);
      //     // selectedPaymentMethod = paymentMode;*/
      //     //
      //     // if (paymentMode == "cash") {
      //     //   paymentDetails[paymentMode] = {
      //     //     'date': details['date'], // Only save the date for Cash
      //     //   };
      //     // } else {
      //     //   paymentDetails[paymentMode] = details; // Save all details for other modes
      //     // }
      //     // // paymentConfirmed[paymentMode] = true; // Mark this mode as confirmed
      //
      //     paymentDetails[paymentMode] = details; // Save payment details
      //     totalPaid += details['amount'] ?? 0; // Update total paid
      //     balance = totalPayable - totalPaid; // Update balance
      //   });

      // },
      // onCancel: () {
      //   setState(() {
      //     // paymentConfirmed[paymentMode] = false;
      //     // completedPayments.remove(paymentMode);
      //   });
      // },
    );

    debugPrint("Res $result");

    if (result != null) {
      setState(() {
        paymentDetails.add(result);
        totalPaid += double.tryParse(result['amount'] ?? 0) ?? 0;
        amountEnteredInBs += double.tryParse(result['amount'] ?? 0) ?? 0;
        paidAmount = amountEnteredInBs;
        balance = amountEnteredInText - amountEnteredInBs;
        paymentEntered = true;
        // paymentConfirmed[paymentMode] = true; // Mark as confirmed
      });
    }
  }
}
