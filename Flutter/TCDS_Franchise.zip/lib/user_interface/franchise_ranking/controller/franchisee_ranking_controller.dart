import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/achievers_award/model/image_response_model.dart';
import 'package:tcds/user_interface/achievers_award/model/level_response_model.dart';
import 'package:tcds/user_interface/franchise_ranking/model/level_franchisee_ranking.dart';
import 'package:tcds/user_interface/franchise_ranking/model/type_response_model.dart';
import 'package:tcds/user_interface/registration/model/country_model.dart';
import 'package:tcds/user_interface/registration/model/district_model.dart';
import 'package:tcds/user_interface/registration/model/state_model.dart';

class FranchiseeRankingController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxBool franchiseeRankingScreenLoader = false.obs;
  RxList<FranchiseeRankingList> franchiseeList = <FranchiseeRankingList>[].obs;
  RxList<Map<String, List<FranchiseeRankingList>>> groupedRankList =
      <Map<String, List<FranchiseeRankingList>>>[].obs;
  RxList<String> levelList = <String>[].obs;
  RxList<String> typeList = <String>[].obs;
  RxList<CountryList> countryList = <CountryList>[].obs;
  RxList<DistrictList> districtList = <DistrictList>[].obs;
  RxList<StateList> stateList = <StateList>[].obs;
  Map<String, Map<String, List<FranchiseeRankingList>>> groupedRanks = {};
  RxList<ImageResponseModel> imageResponse = <ImageResponseModel>[].obs;

  Map<String, List<dynamic>> stateWiseData = {};
  Map<String, List<dynamic>> districtWiseData = {};

  Future<bool> getDistrictFranchiseeList({required dynamic body}) async {
    bool resultValue = false;
    franchiseeRankingScreenLoader.value = true;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getDistrictLevelFranchiseeList,
              body)
          .then((value) async {
        // log(jsonEncode(value.data));
        FranchiseeResponseModel model =
            FranchiseeResponseModel.fromJson(value.data);
        franchiseeList.value = model.data;

        // after fetched centres let's loop through it for to get and store owner image as base64
        for (var i = 0; i < franchiseeList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: franchiseeList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            franchiseeList[i].base64Image = splitRawBase64;
          } else {
            franchiseeList[i].base64Image = null;
          }
        }

        // after fetched awards data completely let's filter it based on state or district
        groupedRankList.value = groupBy(franchiseeList,
                (rank) => rank.district.toLowerCase().removeAllWhitespace)
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedRankList.toString());

        debugPrint(value.data.toString());
        franchiseeRankingScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> getStateFranchiseeList({required dynamic body}) async {
    bool resultValue = false;
    franchiseeRankingScreenLoader.value = true;
    try {
      await engine
          .post(
              AppStrings.baseUrl + AppStrings.getStateLevelFranchiseeList, body)
          .then((value) async {
        // log(jsonEncode(value.data));
        FranchiseeResponseModel model =
            FranchiseeResponseModel.fromJson(value.data);
        franchiseeList.value = model.data;
        // after fetched centres let's loop through it for to get and store owner image as base64
        for (var i = 0; i < franchiseeList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: franchiseeList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            franchiseeList[i].base64Image = splitRawBase64;
          } else {
            franchiseeList[i].base64Image = null;
          }
        }
        groupedRankList.value = groupBy(franchiseeList,
                (rank) => rank.state.removeAllWhitespace.toLowerCase())
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedRankList.toString());

        debugPrint(value.data.toString());
        franchiseeRankingScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Get image details
  Future<bool> getImageDetails({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageResponseModel model = ImageResponseModel.fromJson(value.data);
          imageResponse.clear();
          imageResponse.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }

  Future<bool> getLevel() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.levelUrl, protected: true)
          .then((value) {
        debugPrint(value.toString());
        LevelResponseModel model = LevelResponseModel.fromJson(value.data);
        levelList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getTypeStatus() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getTypeStatus, protected: true)
          .then((value) {
        debugPrint(value.toString());
        TypeResponseModel model = TypeResponseModel.fromJson(value.data);
        typeList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get country list
  Future<bool> getCountryList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.countryListUrl, protected: true)
          .then((value) {
        debugPrint(value.toString());
        CountryResponseModel model = CountryResponseModel.fromJson(value.data);
        countryList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get state list
  Future<bool> getStateList({required String countryId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.stateListUrl + countryId,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        StateResponseModel model = StateResponseModel.fromJson(value.data);
        stateList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get district list
  Future<bool> getDistrictList({required String stateId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.districtListUrl + stateId,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        DistrictResponseModel model =
            DistrictResponseModel.fromJson(value.data);
        districtList.value = model.data;
        // Add an extra custom option - ALL
        districtList.insert(
            0, DistrictList(districtId: -1, districtName: 'ALL'));
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
