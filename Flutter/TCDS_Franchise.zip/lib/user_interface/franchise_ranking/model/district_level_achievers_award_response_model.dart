// To parse this JSON data, do
//
//     final districtLevelAchieversAwardResponseModel = districtLevelAchieversAwardResponseModelFromJson(jsonString);

import 'dart:convert';

DistrictLevelAchieversAwardResponseModel districtLevelAchieversAwardResponseModelFromJson(String str) => DistrictLevelAchieversAwardResponseModel.fromJson(json.decode(str));

String districtLevelAchieversAwardResponseModelToJson(DistrictLevelAchieversAwardResponseModel data) => json.encode(data.toJson());

class DistrictLevelAchieversAwardResponseModel {
  int code;
  String message;
  List<DistrictLevelAwardsList> data;

  DistrictLevelAchieversAwardResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DistrictLevelAchieversAwardResponseModel.fromJson(Map<String, dynamic> json) => DistrictLevelAchieversAwardResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<DistrictLevelAwardsList>.from(json["Data"].map((x) => DistrictLevelAwardsList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class DistrictLevelAwardsList {
  String tenantBranchId;
  String contactId;
  String contactName;
  String state;
  String district;
  String area;
  String taluk;
  int totalCount;
  int rank;
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;

  DistrictLevelAwardsList({
    required this.tenantBranchId,
    required this.contactId,
    required this.contactName,
    required this.state,
    required this.district,
    required this.area,
    required this.taluk,
    required this.totalCount,
    required this.rank,
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
  });

  factory DistrictLevelAwardsList.fromJson(Map<String, dynamic> json) => DistrictLevelAwardsList(
    tenantBranchId: json["TenantBranchID"],
    contactId: json["ContactID"],
    contactName: json["ContactName"],
    state: json["State"],
    district: json["District"],
    area: json["Area"],
    taluk: json["Taluk"],
    totalCount: json["TotalCount"],
    rank: json["Rank"],
    documentName: json["DocumentName"],
    fileName: json["FileName"],
    documentType: json["DocumentType"],
    contentUrl: json["ContentUrl"],
  );

  Map<String, dynamic> toJson() => {
    "TenantBranchID": tenantBranchId,
    "ContactID": contactId,
    "ContactName": contactName,
    "State": state,
    "District": district,
    "Area": area,
    "Taluk": taluk,
    "TotalCount": totalCount,
    "Rank": rank,
    "DocumentName": documentName,
    "FileName": fileName,
    "DocumentType": documentType,
    "ContentUrl": contentUrl,
  };
}
