class FranchiseeResponseModel {
  int code;
  String message;
  List<FranchiseeRankingList> data;

  FranchiseeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseeResponseModel.fromJson(Map<String, dynamic> json) =>
      FranchiseeResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<FranchiseeRankingList>.from(
            json["Data"].map((x) => FranchiseeRankingList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FranchiseeRankingList {
  String tenantBranchId;
  String contactId;
  String contactName;
  String state;
  String district;
  String area;
  String taluk;
  int totalCount;
  int rank;
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;
  String? base64Image;
  int stateCount;
  String franchiseeCode;
  String centreName;
  int purchaseRank;
  String districtRank;

  FranchiseeRankingList({
    required this.tenantBranchId,
    required this.contactId,
    required this.contactName,
    required this.state,
    required this.district,
    required this.area,
    required this.taluk,
    required this.totalCount,
    required this.rank,
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
    required this.stateCount,
    required this.franchiseeCode,
    required this.centreName,
    required this.purchaseRank,
    required this.districtRank,
    this.base64Image,
  });

  factory FranchiseeRankingList.fromJson(Map<String, dynamic> json) =>
      FranchiseeRankingList(
        tenantBranchId: json["TenantBranchID"],
        contactId: json["ContactID"],
        contactName: json["ContactName"],
        state: json["State"],
        district: json["District"],
        area: json["Area"],
        taluk: json["Taluk"],
        totalCount: json["TotalCount"],
        rank: json["Rank"],
        documentName: json["DocumentName"],
        fileName: json["FileName"],
        documentType: json["DocumentType"],
        contentUrl: json["ContentUrl"],
        stateCount: json["StateCount"],
        franchiseeCode: json["FranchiseeCode"],
        centreName: json["CentreName"],
        purchaseRank: json["PurchaseRank"],
        districtRank: json["DistrictRank"],
      );

  Map<String, dynamic> toJson() => {
        "TenantBranchID": tenantBranchId,
        "ContactID": contactId,
        "ContactName": contactName,
        "State": state,
        "District": district,
        "Area": area,
        "Taluk": taluk,
        "TotalCount": totalCount,
        "Rank": rank,
        "DocumentName": documentName,
        "FileName": fileName,
        "DocumentType": documentType,
        "ContentUrl": contentUrl,
        "DistrictRank": districtRank,
      };
}
