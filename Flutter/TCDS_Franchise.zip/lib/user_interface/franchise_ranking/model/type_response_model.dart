
// To parse this JSON data, do
//
//     final typeResponseModel = typeResponseModelFromJson(jsonString);

import 'dart:convert';

TypeResponseModel typeResponseModelFromJson(String str) => TypeResponseModel.fromJson(json.decode(str));

String typeResponseModelToJson(TypeResponseModel data) => json.encode(data.toJson());

class TypeResponseModel {
  int code;
  String message;
  List<String> data;

  TypeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory TypeResponseModel.fromJson(Map<String, dynamic> json) => TypeResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<String>.from(json["Data"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x)),
  };
}
