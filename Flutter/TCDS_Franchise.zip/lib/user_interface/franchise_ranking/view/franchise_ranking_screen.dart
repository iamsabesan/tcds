import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/franchise_ranking/controller/franchisee_ranking_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/pop_scope_handler.dart';
import 'package:tcds/utils/helper_widgets/searchable_dropdown.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import '../../registration/model/country_model.dart';
import '../../registration/model/state_model.dart';
import '../model/level_franchisee_ranking.dart';

class FranchiseeRankingScreen extends StatefulWidget {
  const FranchiseeRankingScreen({super.key});

  @override
  State<FranchiseeRankingScreen> createState() =>
      _FranchiseeRankingScreenState();
}

class _FranchiseeRankingScreenState extends State<FranchiseeRankingScreen> {
  FranchiseeRankingController franchiseeRankingController =
      Get.put(FranchiseeRankingController());

  int _selectedIndex = 1;
  bool withBackArrow = false;
  @override
  void initState() {
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
    getApiCall();

    final currentYear = DateTime.now().year;
    years =
        List.generate(currentYear - 2023, (index) => (2024 + index).toString());
    selectedYear = currentYear.toString(); // Default to current year

    super.initState();
  }

  TextEditingController levelCtrl = TextEditingController();
  TextEditingController levelTextCtrl = TextEditingController();
  TextEditingController stateCtrl = TextEditingController();
  TextEditingController stateTextCtrl = TextEditingController();
  TextEditingController districtCtrl = TextEditingController();
  TextEditingController districtTextCtrl = TextEditingController();
  TextEditingController typeCtrl = TextEditingController();
  TextEditingController typeTextCtrl = TextEditingController();

  late String selectedYear;
  late List<String> years;

  Future<void> getApiCall() async {
    await franchiseeRankingController.getCountryList();
    await franchiseeRankingController.getLevel();
    await franchiseeRankingController.getTypeStatus();
    // get country id of india
    CountryList india = franchiseeRankingController.countryList.firstWhere(
      (element) {
        return element.countryName.toLowerCase() == "india";
      },
      orElse: () => franchiseeRankingController.countryList.first,
    );
    // get state list based on country india
    await franchiseeRankingController.getStateList(
        countryId: india.countryId.toString());

    if (franchiseeRankingController.stateList.isNotEmpty) {
      // fetch state 'Tamil Nadu' to set as Default state
      final StateList defaultState =
          franchiseeRankingController.stateList.firstWhere(
        (element) {
          return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
              "tamilnadu";
        },
        orElse: () => franchiseeRankingController.stateList.first,
      );
      // Assign default value as TamilNadu to State
      stateTextCtrl.text = defaultState.stateProvinceName;
      stateCtrl.text = defaultState.stateProvinceId.toString();

      await franchiseeRankingController.getDistrictList(
          stateId: defaultState.stateProvinceId.toString());

      if (franchiseeRankingController.levelList.isNotEmpty &&
          franchiseeRankingController.levelList[0].removeAllWhitespace
                  .toLowerCase() ==
              "statelevel" &&
          franchiseeRankingController.typeList.isNotEmpty &&
          franchiseeRankingController.typeList[0].removeAllWhitespace != "") {
        franchiseeRankingController.getStateFranchiseeList(body: {
          "Year": selectedYear,
          "State": defaultState.stateProvinceName,
          "Type": franchiseeRankingController.typeList[0].removeAllWhitespace,
        });
      } else {
        franchiseeRankingController.getDistrictFranchiseeList(body: {
          "Year": selectedYear,
          "State": defaultState.stateProvinceName,
          "District": franchiseeRankingController.districtList[0].districtName,
          "Type": franchiseeRankingController.typeList[0].removeAllWhitespace,
        });
      }
    }
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool showDistrict = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 8,
        ),
      ),
      appBar: AppBar(
        titleSpacing: 0,
        toolbarHeight: 70,
        backgroundColor: AppColor.whiteColor,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        title: CustomText(
          text: 'Franchisee Ranking',
          fontSize: AppFontSize.size2,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!
                      .openDrawer(); // Handle back navigation
                },
              ),
        actions: [
          DropdownButton<String>(
            value: selectedYear,
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.black,
            ),
            dropdownColor: Colors.white,
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 18,
            ),
            underline: Container(),
            onChanged: (String? newValue) {
              setState(() {
                selectedYear = newValue!;
              });
            },
            items: years.map<DropdownMenuItem<String>>((String year) {
              return DropdownMenuItem<String>(
                value: year,
                child: Text(
                  year,
                  style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 18,
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 15.w),
        ],
      ),
      body: PopScopeHandler(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Obx(
                      () => SearchableDropdown(
                        // key: UniqueKey(),
                        valueController: levelCtrl,
                        valueTextController: levelTextCtrl,
                        items: List.generate(
                            franchiseeRankingController.levelList.length,
                            (index) => SingleSelectDropDownModel(
                                franchiseeRankingController.levelList[index],
                                franchiseeRankingController.levelList[index]
                                    .toLowerCase())),
                        labelText: 'Select Level',
                        parentOnChangeCall: () async {
                          if (levelCtrl.text.removeAllWhitespace ==
                              "districtlevel") {
                            setState(() {
                              showDistrict = true;
                            });
                            districtCtrl.clear();
                            districtTextCtrl.clear();
                            await franchiseeRankingController.getDistrictList(
                              stateId: stateCtrl.text,
                            );
                            franchiseeRankingController
                                .typeList[0].removeAllWhitespace;

                            if (franchiseeRankingController
                                .districtList.isNotEmpty) {
                              await franchiseeRankingController
                                  .getDistrictFranchiseeList(body: {
                                "Year": selectedYear,
                                "State": stateTextCtrl.text.removeAllWhitespace,
                                "District": franchiseeRankingController
                                    .districtList[0].districtName,
                                "Type": typeTextCtrl.text == ""
                                    ? franchiseeRankingController
                                        .typeList[0].removeAllWhitespace
                                    : typeTextCtrl.text,
                              });
                            }
                          } else {
                            setState(() {
                              showDistrict = false;
                            });
                            franchiseeRankingController
                                .getStateFranchiseeList(body: {
                              "Year": selectedYear,
                              "State": stateTextCtrl.text.removeAllWhitespace,
                              "Type": typeTextCtrl.text == ""
                                  ? franchiseeRankingController
                                      .typeList[0].removeAllWhitespace
                                  : typeTextCtrl.text,
                            });
                          }
                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10.w,
                  ),
                  Expanded(
                    child: Obx(
                      () => SearchableDropdown(
                        // key: UniqueKey(),
                        valueController: stateCtrl,
                        valueTextController: stateTextCtrl,
                        items: List.generate(
                          franchiseeRankingController.stateList.length,
                          (index) => SingleSelectDropDownModel(
                            franchiseeRankingController
                                .stateList[index].stateProvinceName,
                            franchiseeRankingController
                                .stateList[index].stateProvinceId
                                .toString(),
                          ),
                        ),
                        labelText: 'Select State',
                        parentOnChangeCall: () async {
                          districtCtrl.clear();
                          districtTextCtrl.clear();
                          await franchiseeRankingController.getDistrictList(
                            stateId: stateCtrl.text,
                          );
                          if (levelCtrl.text.isNotEmpty &&
                              levelCtrl.text.removeAllWhitespace
                                      .removeAllWhitespace ==
                                  "statelevel") {
                            await franchiseeRankingController
                                .getStateFranchiseeList(body: {
                              "Year": selectedYear,
                              "State": stateTextCtrl.text.removeAllWhitespace,
                              "Type": typeTextCtrl.text == ""
                                  ? franchiseeRankingController
                                      .typeList[0].removeAllWhitespace
                                  : typeTextCtrl.text,
                            });
                          } else {
                            if (franchiseeRankingController
                                .districtList.isNotEmpty) {
                              await franchiseeRankingController
                                  .getDistrictFranchiseeList(body: {
                                "Year": selectedYear,
                                "State": stateTextCtrl.text.removeAllWhitespace,
                                "District": franchiseeRankingController
                                    .districtList[0].districtName,
                                "Type": typeTextCtrl.text,
                              });
                            }
                          }
                        },
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20.w,
              ),
              if ((levelCtrl.text.toLowerCase().removeAllWhitespace ==
                      "statelevel") ||
                  levelCtrl.text == "") ...[
                /*  Obx(
                  () => SearchableDropdown(
                    // key: UniqueKey(),
                    valueController: typeCtrl,
                    valueTextController: typeTextCtrl,
                    items: List.generate(
                        franchiseeRankingController.typeList.length,
                        (index) => SingleSelectDropDownModel(
                            franchiseeRankingController.typeList[index],
                            franchiseeRankingController.typeList[index]
                                .toLowerCase())),
                    labelText: 'Select Type',
                  ),
                ), */
                Obx(
                  () => SearchableDropdown(
                    // key: UniqueKey(),
                    valueController: typeCtrl,
                    valueTextController: typeTextCtrl,
                    items: List.generate(
                        franchiseeRankingController.typeList.length,
                        (index) => SingleSelectDropDownModel(
                            franchiseeRankingController.typeList[index],
                            franchiseeRankingController.typeList[index]
                                .toLowerCase())),
                    parentOnChangeCall: () async {
                      await franchiseeRankingController
                          .getStateFranchiseeList(body: {
                        "Year": selectedYear,
                        "State": stateTextCtrl.text.removeAllWhitespace,
                        "Type": typeTextCtrl.text == ""
                            ? franchiseeRankingController
                                .typeList[0].removeAllWhitespace
                            : typeTextCtrl.text,
                      });
                    },
                    labelText: 'Select Type',
                  ),
                ),
              ],
              if (levelCtrl.text.toLowerCase().removeAllWhitespace ==
                  "districtlevel") ...[
                Row(
                  children: [
                    Expanded(
                      child: Obx(
                        () => SearchableDropdown(
                          // key: UniqueKey(),
                          valueController: districtCtrl,
                          valueTextController: districtTextCtrl,
                          items: List.generate(
                            franchiseeRankingController.districtList.length,
                            (index) => SingleSelectDropDownModel(
                              franchiseeRankingController
                                  .districtList[index].districtName,
                              franchiseeRankingController
                                  .districtList[index].districtId
                                  .toString(),
                            ),
                          ),
                          parentOnChangeCall: () async {
                            await franchiseeRankingController
                                .getDistrictFranchiseeList(body: {
                              "Year": selectedYear,
                              "State": stateTextCtrl.text.removeAllWhitespace,
                              "District":
                                  districtTextCtrl.text.removeAllWhitespace,
                              "Type": typeTextCtrl.text == ""
                                  ? franchiseeRankingController
                                      .typeList[0].removeAllWhitespace
                                  : typeTextCtrl.text,
                            });
                          },
                          labelText: 'Select District',
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Expanded(
                      child: Obx(
                        () => SearchableDropdown(
                          // key: UniqueKey(),
                          valueController: typeCtrl,
                          valueTextController: typeTextCtrl,
                          items: List.generate(
                              franchiseeRankingController.typeList.length,
                              (index) => SingleSelectDropDownModel(
                                  franchiseeRankingController.typeList[index],
                                  franchiseeRankingController.typeList[index]
                                      .toLowerCase())),
                          parentOnChangeCall: () async {
                            await franchiseeRankingController
                                .getDistrictFranchiseeList(body: {
                              "Year": selectedYear,
                              "State": stateTextCtrl.text.removeAllWhitespace,
                              "District":
                                  districtTextCtrl.text.removeAllWhitespace,
                              "Type": typeTextCtrl.text == ""
                                  ? franchiseeRankingController
                                      .typeList[0].removeAllWhitespace
                                  : typeTextCtrl.text,
                            });
                          },
                          labelText: 'Select Type',
                        ),
                      ),
                    ),
                  ],
                )
              ],
              SizedBox(height: 30.w),
              Obx(
                () {
                  // an bool value to identitfy current level is in District
                  bool isDistrict =
                      levelCtrl.text.toLowerCase().removeAllWhitespace ==
                          "districtlevel";
                  if (franchiseeRankingController
                      .franchiseeRankingScreenLoader.value) {
                    return const Center(
                      child: CircularProgressIndicator(
                        color: AppColor.primaryColor,
                      ),
                    );
                  } else if (franchiseeRankingController
                      .groupedRankList.isEmpty) {
                    return Center(
                      child: CustomText(
                        text: "No Data available",
                        color: AppColor.primaryColor,
                        fontSize: AppFontSize.size3,
                        fontWeight: FontWeight.w500,
                      ),
                    );
                  } else {
                    // get first data of the fetched list to show total centre count in state
                    final firstRankData =
                        franchiseeRankingController.franchiseeList.first;
                    // check is type "Both Admission and Transaction" to show different trailing
                    final isBothType =
                        typeTextCtrl.text.toLowerCase().removeAllWhitespace ==
                            "bothadmissionandtransactionwise";
                    return Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          // heading
                          CustomText(
                            text:
                                "${isDistrict ? "DISTRICT" : "STATE"} LEVEL RANK",
                            color: AppColor.redColor,
                            fontWeight: FontWeight.bold,
                            fontSize: AppFontSize.size2.sp,
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          CustomText(
                            text: "[ ${typeTextCtrl.text.toUpperCase()} ]",
                            color: AppColor.green,
                            fontWeight: FontWeight.bold,
                            fontSize: AppFontSize.size3.sp,
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          // total centres count
                          CustomText(
                            text:
                                "${stateTextCtrl.text.toUpperCase().removeAllWhitespace} (${isDistrict ? firstRankData.stateCount : firstRankData.totalCount})",
                            fontSize: AppFontSize.size3.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Expanded(
                            child: ListView.builder(
                              padding: const EdgeInsets.only(bottom: 80),
                              scrollDirection: Axis.vertical,
                              itemCount: franchiseeRankingController
                                  .groupedRankList
                                  .length, // Show the selected state or district only
                              itemBuilder: (context, index) {
                                // store current data map
                                Map<String, List<FranchiseeRankingList>> temp =
                                    franchiseeRankingController
                                        .groupedRankList[index];
                                String currentKey = temp.keys.first;
                                List<FranchiseeRankingList> rankingList =
                                    temp[currentKey] ?? [];
                                debugPrint("Current Key $currentKey");
                                return Card(
                                  color: AppColor.lightBlue,
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 8.w,
                                    ),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: AppColor.greyColor,
                                        strokeAlign: 0.1,
                                      ),
                                      borderRadius: BorderRadius.circular(15.0),
                                    ),
                                    child: ExpansionTile(
                                      /*  initiallyExpanded: true,
                                      enabled: isDistrict,
                                      // trailing:
                                      //     isDistrict ? null : const SizedBox(),
                                      tilePadding: const EdgeInsets.all(0),
                                      childrenPadding: const EdgeInsets.all(0),
                                      backgroundColor: AppColor.lightBlue,
                                      iconColor: AppColor.primaryColor, */
                                      initiallyExpanded: true,
                                      dense: !isDistrict,
                                      trailing:
                                          isDistrict ? null : const SizedBox(),
                                      // disable expand button while in state mode / (Since we show only one for state)
                                      enabled: isDistrict,
                                      tilePadding: EdgeInsets.zero,
                                      childrenPadding: EdgeInsets.zero,
                                      minTileHeight: isDistrict ? null : 0,
                                      backgroundColor: AppColor.lightBlue,
                                      iconColor: isDistrict
                                          ? AppColor.primaryColor
                                          : AppColor.lightBlue,
                                      collapsedIconColor: AppColor.blackColor,
                                      /*    leading: isDistrict
                                          ? CircleAvatar(
                                              backgroundColor:
                                                  AppColor.lightOrange,
                                              child: CustomText(
                                                text:
                                                    "${rankingList.first.totalCount}",
                                                color: AppColor.orange,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            )
                                          : null, */
                                      title: isDistrict
                                          // since we show only count in district there is no need to show in state
                                          ? Row(
                                              children: [
                                                CustomText(
                                                  text:
                                                      // levelCtrl.text
                                                      //             .removeAllWhitespace ==
                                                      //         "districtlevel"
                                                      //     ?
                                                      "${index + 1}. ${rankingList.first.district.toUpperCase()}"
                                                  // :
                                                  // rankingList.first
                                                  //     .state
                                                  , // state not needed
                                                  fontSize:
                                                      AppFontSize.size4.sp,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                CustomText(
                                                  text:
                                                      " (${rankingList.first.totalCount})",
                                                  color: AppColor.primaryColor,
                                                  fontSize: AppFontSize.size4,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ],
                                            )
                                          : const SizedBox(),
                                      children: List.generate(
                                          rankingList.length, (rankIndex) {
                                        return Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            // Tile Widget
                                            Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                // Profile image
                                                Container(
                                                  height: 60.w,
                                                  width: 60.w,
                                                  clipBehavior: Clip.antiAlias,
                                                  decoration:
                                                      const BoxDecoration(
                                                          shape:
                                                              BoxShape.circle),
                                                  // show base64 image only when it's not empty
                                                  // else show default image
                                                  child: rankingList[rankIndex]
                                                              .base64Image !=
                                                          null
                                                      ? Image.memory(
                                                          base64Decode(
                                                              rankingList[
                                                                      rankIndex]
                                                                  .base64Image!),
                                                          height: 25.w,
                                                          width: 25.w,
                                                          fit: BoxFit.cover,
                                                          errorBuilder: (context,
                                                                  error,
                                                                  stackTrace) =>
                                                              Image.asset(
                                                            AssetPath.userIcon,
                                                            height: 50.w,
                                                            width: 50.w,
                                                            fit: BoxFit.cover,
                                                          ),
                                                        )
                                                      : Image.asset(
                                                          AssetPath.userIcon,
                                                          height: 25.w,
                                                          width: 25.w,
                                                          fit: BoxFit.cover,
                                                        ),
                                                ),
                                                SizedBox(width: 10.w),
                                                // Personal data
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      CustomText(
                                                        text: rankingList[
                                                                rankIndex]
                                                            .contactName,
                                                        color:
                                                            AppColor.blackColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        maxLines: 2,
                                                        fontSize: AppFontSize
                                                            .size4.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      CustomText(
                                                        text: rankingList[
                                                                rankIndex]
                                                            .centreName,
                                                        color:
                                                            AppColor.blackColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        maxLines: 2,
                                                        fontSize: AppFontSize
                                                            .size4.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      if (isBothType) ...[
                                                        CustomText(
                                                          text: rankingList[
                                                                  rankIndex]
                                                              .franchiseeCode,
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: AppFontSize
                                                              .size4.sp,
                                                        ),
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                      ],
                                                      CustomText(
                                                        text: rankingList[
                                                                rankIndex]
                                                            .area,
                                                        color:
                                                            AppColor.blackColor,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        maxLines: 2,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: AppFontSize
                                                            .size4.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      CustomText(
                                                        text: rankingList[
                                                                rankIndex]
                                                            .taluk,
                                                        color:
                                                            AppColor.blackColor,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        maxLines: 2,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: AppFontSize
                                                            .size4.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      if (!isDistrict)
                                                        CustomText(
                                                          text: rankingList[
                                                                  rankIndex]
                                                              .district,
                                                          color: AppColor
                                                              .blackColor,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 2,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontSize: AppFontSize
                                                              .size4.sp,
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(width: 10.w),
                                                // Ranks & Franchise code
                                                isBothType
                                                    ? Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceEvenly,
                                                        children: [
                                                          Column(
                                                            children: [
                                                              CustomText(
                                                                text: "AD",
                                                                color: Colors
                                                                    .green,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size5,
                                                              ),
                                                              CustomText(
                                                                text: (isDistrict &&
                                                                        districtTextCtrl.text.toLowerCase() ==
                                                                            "all")
                                                                    ? rankingList[
                                                                            rankIndex]
                                                                        .districtRank
                                                                        .padLeft(
                                                                            2,
                                                                            "0")
                                                                    : rankingList[
                                                                            rankIndex]
                                                                        .rank
                                                                        .toString()
                                                                        .padLeft(
                                                                            2,
                                                                            "0"),
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size3,
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 50.w,
                                                          ),
                                                          Container(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        10.w,
                                                                    vertical:
                                                                        5),
                                                            color:
                                                                AppColor.red2,
                                                            child: CustomText(
                                                              text: rankingList[
                                                                      rankIndex]
                                                                  .purchaseRank
                                                                  .toString()
                                                                  .padLeft(
                                                                      3, "0"),
                                                              color: AppColor
                                                                  .whiteColor,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize:
                                                                  AppFontSize
                                                                      .size4.sp,
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    : Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .end,
                                                        children: [
                                                          CustomText(
                                                            text: (isDistrict &&
                                                                    districtTextCtrl
                                                                            .text
                                                                            .toLowerCase() ==
                                                                        "all")
                                                                ? rankingList[
                                                                        rankIndex]
                                                                    .districtRank
                                                                    .padLeft(
                                                                        2, "0")
                                                                : rankingList[
                                                                        rankIndex]
                                                                    .rank
                                                                    .toString()
                                                                    .padLeft(
                                                                        2, "0"),
                                                            color: Colors
                                                                .deepOrangeAccent,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4,
                                                          ),
                                                          CustomText(
                                                            text: rankingList[
                                                                    rankIndex]
                                                                .franchiseeCode,
                                                            color: AppColor
                                                                .primaryColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                        ],
                                                      ),
                                              ],
                                            ),
                                            //
                                            /*  ListTile(
                                              minVerticalPadding: 0,
                                              isThreeLine: true,

                                              contentPadding:
                                                  const EdgeInsets.all(0),
                                              leading: Container(
                                                height: 60.w,
                                                width: 60.w,
                                                clipBehavior: Clip.antiAlias,
                                                decoration: const BoxDecoration(
                                                    shape: BoxShape.circle),
                                                // show base64 image only when it's not empty
                                                // else show default image
                                                child: rankingList[rankIndex]
                                                            .base64Image !=
                                                        null
                                                    ? Image.memory(
                                                        base64Decode(
                                                            rankingList[
                                                                    rankIndex]
                                                                .base64Image!),
                                                        height: 25.w,
                                                        width: 25.w,
                                                        fit: BoxFit.cover,
                                                        errorBuilder: (context,
                                                                error,
                                                                stackTrace) =>
                                                            Image.asset(
                                                          AssetPath.userIcon,
                                                          height: 50.w,
                                                          width: 50.w,
                                                          fit: BoxFit.cover,
                                                        ),
                                                      )
                                                    : Image.asset(
                                                        AssetPath.userIcon,
                                                        height: 25.w,
                                                        width: 25.w,
                                                        fit: BoxFit.cover,
                                                      ),
                                              ),

                                              title: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CustomText(
                                                    text: rankingList[rankIndex]
                                                        .contactName,
                                                    color: AppColor.blackColor,
                                                    fontWeight: FontWeight.w500,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  CustomText(
                                                    text: rankingList[rankIndex]
                                                        .centreName,
                                                    color: AppColor.blackColor,
                                                    fontWeight: FontWeight.w500,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                ],
                                              ),
                                              subtitle: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  CustomText(
                                                    text: rankingList[rankIndex]
                                                        .area,
                                                    color: AppColor.blackColor,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  CustomText(
                                                    text: rankingList[rankIndex]
                                                        .taluk,
                                                    color: AppColor.blackColor,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 2,
                                                    fontWeight: FontWeight.w400,
                                                    fontSize:
                                                        AppFontSize.size4.sp,
                                                  ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  if (!isDistrict)
                                                    CustomText(
                                                      text:
                                                          rankingList[rankIndex]
                                                              .district,
                                                      color:
                                                          AppColor.blackColor,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 2,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                      fontSize:
                                                          AppFontSize.size4.sp,
                                                    ),
                                                ],
                                              ),
                                              // change trailing widgets based on Selected Type (Both)
                                              trailing: isBothType
                                                  ? Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        Column(
                                                          children: [
                                                            CustomText(
                                                              text: "AD",
                                                              color:
                                                                  Colors.green,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize:
                                                                  AppFontSize
                                                                      .size5,
                                                            ),
                                                            CustomText(
                                                              text:
                                                                  "${rankingList[rankIndex].rank}"
                                                                      .padLeft(
                                                                          2,
                                                                          '0'),
                                                              color:
                                                                  Colors.black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize:
                                                                  AppFontSize
                                                                      .size3,
                                                            ),
                                                          ],
                                                        ),
                                                        Container(
                                                          padding: EdgeInsets
                                                              .symmetric(
                                                                  horizontal:
                                                                      10.w,
                                                                  vertical: 5),
                                                          color: AppColor.red2,
                                                          child: CustomText(
                                                            text:
                                                                "${rankingList[rankIndex].purchaseRank}",
                                                            color: AppColor
                                                                .whiteColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size4.sp,
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  : Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        CustomText(
                                                          text:
                                                              "${rankingList[rankIndex].rank}"
                                                                  .padLeft(
                                                                      2, '0'),
                                                          color: Colors
                                                              .deepOrangeAccent,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize:
                                                              AppFontSize.size3,
                                                        ),
                                                        CustomText(
                                                          text: rankingList[
                                                                  rankIndex]
                                                              .franchiseeCode,
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: AppFontSize
                                                              .size5.sp,
                                                        ),
                                                      ],
                                                    ),
                                            ), */
                                            if (rankIndex !=
                                                (rankingList.length - 1))
                                              const Divider(
                                                // Divider after the subtitle
                                                color: AppColor.greyColor,
                                                thickness: 0.5,
                                              )
                                            else
                                              SizedBox(height: 10.w)
                                          ],
                                        );
                                      }),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
