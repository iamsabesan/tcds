import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/shared_preference.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/login/model/bearer_response_model.dart';
import 'package:tcds/user_interface/login/model/login_response_model.dart';

class LoginController extends GetxController {
  HttpEngine engine = HttpEngine();

  @override
  void onInit() {
    // netWorkChecker();
    super.onInit();
  }

  Future<bool> getAuth(
      {required String password, required String loginName}) async {
    Map<String, dynamic> body = {
      "loginName": loginName,
      "password": password,
      "TenantID": (AppStrings.baseUrl == "http://192.168.1.10:8084/" ||
              AppStrings.baseUrl == "http://gateway.dawn.dt/")
          ? AppStrings.tenantLocalID
          : AppStrings.tenantLiveID
    };
    bool resultValue = false;

    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.logInUrl, body,
              protected: false)
          .then((value) {
        LoginResponseModel auth = LoginResponseModel.fromJson(value.data);

        // Store required values in local storage
        SharedPreference.putString(
            AppStrings.accessToken, auth.data!.bearerToken!);
        SharedPreference.putString(
            AppStrings.refreshToken, auth.data!.refreshToken!);
        SharedPreference.putBool(AppStrings.isLoggedIn, true);
        // Decode Bearer Token
        Map<String, dynamic> decodedToken =
            JwtDecoder.decode(auth.data!.bearerToken!);
        debugPrint('-----\n');
        debugPrint(decodedToken.toString());
        debugPrint('-----\n');

        BearerResponseModel decryptedData =
            BearerResponseModel.fromJson(decodedToken);
        SharedPreference.putString(
            AppStrings.profileName, decryptedData.userName);
        SharedPreference.putString(AppStrings.position,
            decryptedData.authRole.join(',').replaceAll(r'"', ''));
        SharedPreference.putString(
            AppStrings.contactID, decryptedData.contactId.toString());
        SharedPreference.putString(
            AppStrings.tenantBranchID, decryptedData.tenantBranchId.toString());
        debugPrint(decryptedData.userName.toString());
        debugPrint(decryptedData.logoUrl.toString());
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
