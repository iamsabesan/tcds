import 'dart:convert';
import 'package:tcds/utils/helper_functions/bot_crypto/aes_decrypter.dart';

BearerResponseModel bearerResponseModelFromJson(String str) =>
    BearerResponseModel.fromJson(json.decode(str));

String bearerResponseModelToJson(BearerResponseModel data) =>
    json.encode(data.toJson());

class BearerResponseModel {
  String platformId;
  String userName;
  String loginName;
  String userId;
  String contactId;
  List<String> authRole;
  String timeZone;
  String languageCulture;
  String dateTimeFormat;
  String dateFormat;
  String timeFormat;
  String currency;
  String currencySymbol;
  String currencyCode;
  String tenantId;
  String logoUrl;
  String tenantName;
  String tenantBranchId;
  String tenantBranchName;
  String activeTheme;
  int nbf;
  int exp;
  String iss;
  String aud;

  BearerResponseModel({
    required this.platformId,
    required this.userName,
    required this.loginName,
    required this.userId,
    required this.contactId,
    required this.authRole,
    required this.timeZone,
    required this.languageCulture,
    required this.dateTimeFormat,
    required this.dateFormat,
    required this.timeFormat,
    required this.currency,
    required this.currencySymbol,
    required this.currencyCode,
    required this.tenantId,
    required this.logoUrl,
    required this.tenantName,
    required this.tenantBranchId,
    required this.tenantBranchName,
    required this.activeTheme,
    required this.nbf,
    required this.exp,
    required this.iss,
    required this.aud,
  });

  factory BearerResponseModel.fromJson(Map<String, dynamic> json) =>
      BearerResponseModel(
        platformId: BotCrypto.decryptData(encryptedText: json["PlatformID"]),
        userName: BotCrypto.decryptData(encryptedText: json["UserName"]),
        loginName: BotCrypto.decryptData(encryptedText: json["LoginName"]),
        userId: BotCrypto.decryptData(encryptedText: json["UserID"]),
        contactId: BotCrypto.decryptData(encryptedText: json["ContactID"]),

        // After decrypt the AuthRole converting it to List<String> cause it's an Array
        authRole: BotCrypto.decryptData(encryptedText: json["AuthRole"])
            .replaceAll('[', '')
            .replaceAll(']', '')
            .split(','),
        timeZone: BotCrypto.decryptData(encryptedText: json["TimeZone"]),
        languageCulture:
            BotCrypto.decryptData(encryptedText: json["LanguageCulture"]),
        dateTimeFormat:
            BotCrypto.decryptData(encryptedText: json["DateTimeFormat"]),
        dateFormat: BotCrypto.decryptData(encryptedText: json["DateFormat"]),
        timeFormat: BotCrypto.decryptData(encryptedText: json["TimeFormat"]),
        currency: BotCrypto.decryptData(encryptedText: json["Currency"]),
        currencySymbol: json["CurrencySymbol"],
        currencyCode:
            BotCrypto.decryptData(encryptedText: json["CurrencyCode"]),
        tenantId: BotCrypto.decryptData(encryptedText: json["TenantID"]),
        logoUrl: BotCrypto.decryptData(encryptedText: json["LogoURL"]),
        tenantName: BotCrypto.decryptData(encryptedText: json["TenantName"]),
        tenantBranchId:
            BotCrypto.decryptData(encryptedText: json["TenantBranchID"]),
        tenantBranchName:
            BotCrypto.decryptData(encryptedText: json["TenantBranchName"]),
        activeTheme: BotCrypto.decryptData(encryptedText: json["ActiveTheme"]),
        nbf: json["nbf"],
        exp: json["exp"],
        iss: json["iss"],
        aud: json["aud"],
      );

  Map<String, dynamic> toJson() => {
        "PlatformID": platformId,
        "UserName": userName,
        "LoginName": loginName,
        "UserID": userId,
        "ContactID": contactId,
        "AuthRole": authRole,
        "TimeZone": timeZone,
        "LanguageCulture": languageCulture,
        "DateTimeFormat": dateTimeFormat,
        "DateFormat": dateFormat,
        "TimeFormat": timeFormat,
        "Currency": currency,
        "CurrencySymbol": currencySymbol,
        "CurrencyCode": currencyCode,
        "TenantID": tenantId,
        "LogoURL": logoUrl,
        "TenantName": tenantName,
        "TenantBranchID": tenantBranchId,
        "TenantBranchName": tenantBranchName,
        "ActiveTheme": activeTheme,
        "nbf": nbf,
        "exp": exp,
        "iss": iss,
        "aud": aud,
      };
}
