class LoginResponseModel {
  int? code;
  String? message;
  Data? data;

  LoginResponseModel({this.code, this.message, this.data});

  LoginResponseModel.fromJson(Map<String, dynamic> json) {
    code = json['Code'];
    message = json['Message'];
    data = json['Data'] != null ? Data.fromJson(json['Data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Code'] = code;
    data['Message'] = message;
    if (this.data != null) {
      data['Data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? bearerToken;
  String? validFrom;
  String? validTo;
  String? refreshToken;
  String? refreshTokenValidTo;

  Data(
      {this.bearerToken,
        this.validFrom,
        this.validTo,
        this.refreshToken,
        this.refreshTokenValidTo});

  Data.fromJson(Map<String, dynamic> json) {
    bearerToken = json['BearerToken'];
    validFrom = json['ValidFrom'];
    validTo = json['ValidTo'];
    refreshToken = json['RefreshToken'];
    refreshTokenValidTo = json['RefreshTokenValidTo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['BearerToken'] = bearerToken;
    data['ValidFrom'] = validFrom;
    data['ValidTo'] = validTo;
    data['RefreshToken'] = refreshToken;
    data['RefreshTokenValidTo'] = refreshTokenValidTo;
    return data;
  }
}
