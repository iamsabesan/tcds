import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/routes/routes.dart';
import 'package:tcds/user_interface/login/controller/login_controller.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import '../../../constants/app_string.dart';
import '../../../constants/colors.dart';
import '../../../constants/shared_preference.dart';
import '../../dashboard/controller/dashboard_controller.dart';
import '../../registration/view/get_details_page.dart';
import '../../renewal/ui/renewal_detail_page.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginController logInController = Get.put(LoginController());
  DashboardController dashboardController = Get.put(DashboardController());
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  TextEditingController emailCtrl = TextEditingController();
  TextEditingController pwdCtrl = TextEditingController();

  bool isPwd = true;

  // Error Texts
  String? emailErrorText;
  String? passwordErrorText;

  FocusNode passwordFocus = FocusNode();
  FocusNode emailFocus = FocusNode();
  DateTime now = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 80.w,
            ),
            Image.asset(
              AssetPath.logo1,
              scale: 8.00,
            ),
            SizedBox(
              height: 20.w,
            ),
            Image.asset(
              AssetPath.logo2,
              scale: 3.00,
            ),
            SizedBox(
              height: 60.w,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  CustomText(
                    text: "Welcome Back !",
                    color: AppColor.secondaryColor,
                    fontSize: AppFontSize.size1,
                    fontWeight: FontWeight.w600,
                    textAlign: TextAlign.start,
                  ),
                  SizedBox(
                    height: 5.w,
                  ),
                  CustomText(
                    text: "Please login to Continue",
                    color: AppColor.blackColor,
                    fontSize: AppFontSize.size3,
                  ),
                  SizedBox(
                    height: 55.w,
                  ),
                  Form(
                    key: formKey,
                    child: Column(
                      children: [
                        CustomTextField(
                          labelText: "Email ID",
                          controller: emailCtrl,
                          errorText: emailErrorText,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(40)
                          ],
                          validator: (value) {
                            if (value != null && value.isEmpty) {
                              return "Enter a valid mail";
                            }
                            return null;
                          },
                          onChanged: (value) {
                            setState(() {
                              if (value.isEmpty) {
                                emailErrorText = "Username is Required";
                              } else {
                                bool userName = RegExp(
                                        r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
                                    .hasMatch(value);
                                if (userName) {
                                  emailErrorText = null;
                                } else {
                                  emailErrorText = "Enter a valid mail";
                                }
                              }
                            });
                          },
                          prefixIcon: Image.asset(
                            AssetPath.mailBlue,
                            scale: 20.0,
                            color: AppColor.darkGreyColor,
                          ),
                        ),
                        const SizedBox(height: 20),
                        CustomTextField(
                          labelText: 'Password',
                          controller: pwdCtrl,
                          obscureText: isPwd,
                          onChanged: (value) {
                            setState(() {
                              if (value.isEmpty) {
                                passwordErrorText = "Password is Required";
                              } else {
                                passwordErrorText = null;
                              }
                            });
                          },
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(15)
                          ],
                          prefixIcon: Image.asset(
                            AssetPath.padLock,
                            scale: 22.00,
                            color: AppColor.darkGreyColor,
                          ),
                          validator: (value) {
                            if (value != null && value.isEmpty) {
                              return "Password is required";
                            }
                            return null;
                          },
                          suffixIcon: GestureDetector(
                            onTap: () {
                              setState(() {
                                isPwd = !isPwd;
                              });
                            },
                            child: Image.asset(
                              isPwd
                                  ? AssetPath.inVisibleEyeIcon
                                  : AssetPath.visibleEyeIcon,
                              scale: 20.0,
                              color: AppColor.black2Color,
                            ),
                          ),
                        ),
                        SizedBox(height: 10.w),
                        CustomText(
                          text: "See the Password in your Email ID",
                          color: AppColor.orange1,
                          fontWeight: FontWeight.w500,
                          fontSize: 14.sp,
                        ),
                        SizedBox(height: 60.w),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 110.w),
                          child: InButton(
                            text: 'Login',
                            textSize: AppFontSize.size2.sp,
                            textWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                            withArrow: false,
                            verticalPadding: 12.w,
                            onTap: () {
                              validateInputs();
                            },
                            borderRadius: BorderRadius.circular(25.r),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        GestureDetector(
                          onTap: () async {
                            bool res = await logInController.getAuth(
                                password: "India_123",
                                loginName: 'tcdsguest@gmail.com');
                            if (res) {
                              SharedPreference.putBool(
                                  AppStrings.isLoggedIn, false);
                              Get.to(() => const GetDetailsPage());
                            }
                          },
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text:
                                      "Are you looking for a new franchisee? ",
                                  style: TextStyle(
                                    color: AppColor.blackColor,
                                    fontSize: AppFontSize.size3,
                                  ),
                                ),
                                TextSpan(
                                  text: "Register",
                                  style: TextStyle(
                                      color: AppColor
                                          .secondaryColor, // Set the color to orange
                                      fontSize: AppFontSize.size3,
                                      fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void validateInputs() {
    if (formKey.currentState!.validate()) {
      PleaseWaitLoader.openDialog();
      logInController
          .getAuth(password: pwdCtrl.text, loginName: emailCtrl.text)
          .then(
        (value) async {
          PleaseWaitLoader.closeDialog();
          if (value) {
            SharedPreference.putBool(AppStrings.isLoggedIn, true);
            SharedPreference.putBool(AppStrings.firstLogin, true);
            await dashboardController.getDashboardTotalDetails();
            DateTime approvalDate = _parseDate(
              dashboardController.dashboardTotalData[0].approvalEndDate,
            );
            DateTime subscriptionDate = _parseDate(
              dashboardController.dashboardTotalData[0].subscriptionEndDate,
            );
            if ((now.isAfter(approvalDate)) ||
                (now.isAfter(subscriptionDate))) {
              SharedPreference.putBool(AppStrings.expire, true);
              Get.to(const RenewalDetailPage());
              debugPrint("Date Expires");
            } else {
              SharedPreference.putBool(AppStrings.expire, false);
              Get.offAllNamed(Routes.dashboardScreen);
              debugPrint("Date is valid");
            }
            emailCtrl.clear();
            pwdCtrl.clear();
          }
        },
      );
    }
  }

  DateTime _parseDate(String dateStr) {
    List<String> parts = dateStr.split('-');
    int day = int.parse(parts[0]);
    int month = int.parse(parts[1]);
    int year = int.parse(parts[2]);

    // Return a DateTime object for the given date
    return DateTime(year, month, day);
  }
}
