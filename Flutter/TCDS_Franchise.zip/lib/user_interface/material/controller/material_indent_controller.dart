import 'dart:convert';
// import 'dart:developer';
import 'package:collection/collection.dart';
import 'package:dio/dio.dart' as dr;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/material/model/material_indent_status_response_model.dart';
import 'package:tcds/user_interface/material/model/stock_list_material.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_functions/file_download_helper.dart';
import '../model/hq_stock_list.dart';
import '../model/material_tracking_response_model.dart';

class MaterialIndentController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxBool stockListScreenLoader = false.obs;
  RxBool hqStockListScreenLoader = false.obs;
  RxBool materialTrackingScreenLoader = false.obs;
  RxList<StockList> localStockList = <StockList>[].obs;
  RxList<HQStock> hqStockList = <HQStock>[].obs;
  RxMap<String, List<HQStock>> hqMaterialWiseStocks =
      <String, List<HQStock>>{}.obs;
  RxMap<String, List<StockList>> localMaterialWiseStocks =
      <String, List<StockList>>{}.obs;
  RxList<HQStock> hqFilteredStocks = <HQStock>[].obs;
  RxList<StockList> localFilteredStocks = <StockList>[].obs;
  RxList<String> filterKeys = <String>[].obs;
  RxList<String> materialIndentStatusList = <String>[].obs;
  RxList<MaterialTrackingList> materialTrackingList =
      <MaterialTrackingList>[].obs;

  Future<bool> getStockList() async {
    bool resultValue = false;
    stockListScreenLoader.value = true;

    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.stockListUrl, protected: true)
          .then((value) {
        debugPrint("=== STOCK LIST API RESPONSE ===");
        debugPrint("Raw API Response: ${value.toString()}");

        StockListResponseModel model =
            StockListResponseModel.fromJson(value.data);
        localStockList.value = model.data;

        debugPrint("Parsed Stock List: ${localStockList.length} items");
        for (var stock in localStockList) {
          debugPrint("  - ${stock.materialName} (${stock.materialType})");
        }

        // Clear existing data first
        localMaterialWiseStocks.clear();
        filterKeys.clear();
        localFilteredStocks.clear();

        // Group by material type
        localMaterialWiseStocks.value =
            groupBy(localStockList, (stock) => stock.materialType);

        debugPrint("=== MATERIAL TYPE GROUPING ===");
        localMaterialWiseStocks.forEach((key, value) {
          debugPrint("$key: ${value.length} items");
        });

        // Get sorted filter keys
        filterKeys.value = localMaterialWiseStocks.keys.toList()..sort();
        debugPrint("Filter Keys: $filterKeys");

        // Set initial filtered stocks
        if (filterKeys.isNotEmpty) {
          String firstKey = filterKeys.first;
          localFilteredStocks.value = localMaterialWiseStocks[firstKey] ?? [];
          debugPrint(
              "Initial filter set to: $firstKey, items: ${localFilteredStocks.length}");
        }

        resultValue = true;
      }).whenComplete(() {
        stockListScreenLoader.value = false;
      });
    } catch (e) {
      stockListScreenLoader.value = false;
      resultValue = false;
      debugPrint("getStockList error: $e");
    }

    return resultValue;
  }

  Future<bool> getHQStockList() async {
    bool resultValue = false;
    hqStockListScreenLoader.value = true;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.hqStockListUrl, protected: true)
          .then((value) {
        debugPrint("=== HQ STOCK LIST API RESPONSE ===");
        debugPrint("Raw API Response: ${value.toString()}");

        HqStockModel model = HqStockModel.fromJson(value.data);
        hqStockList.value = model.data;

        debugPrint("Parsed HQ Stock List: ${hqStockList.length} items");
        for (var stock in hqStockList) {
          debugPrint("  - ${stock.materialName} (${stock.materialType})");
        }

        // Clear existing data first
        hqMaterialWiseStocks.clear();
        filterKeys.clear();
        hqFilteredStocks.clear();

        // Group by material type
        hqMaterialWiseStocks.value =
            groupBy(hqStockList, (stock) => stock.materialType);

        debugPrint("=== HQ MATERIAL TYPE GROUPING ===");
        hqMaterialWiseStocks.forEach((key, value) {
          debugPrint("$key: ${value.length} items");
        });

        // Get sorted filter keys
        filterKeys.value = hqMaterialWiseStocks.keys.toList()..sort();
        debugPrint("HQ Filter Keys: $filterKeys");

        // Set initial filtered stocks
        if (filterKeys.isNotEmpty) {
          String firstKey = filterKeys.first;
          hqFilteredStocks.value = hqMaterialWiseStocks[firstKey] ?? [];
          debugPrint(
              "Initial HQ filter set to: $firstKey, items: ${hqFilteredStocks.length}");
        }

        resultValue = true;
      }).whenComplete(() {
        hqStockListScreenLoader.value = false;
      });
    } catch (e) {
      hqStockListScreenLoader.value = false;
      resultValue = false;
      debugPrint("getHQStockList error: $e");
    }

    return resultValue;
  }

//get material indent status
  Future<bool> getIndentStatus() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.materialIndentStatus,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        MaterialIndentStatusResponseModel model =
            MaterialIndentStatusResponseModel.fromJson(value.data);
        materialIndentStatusList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  //done for material indent tracking

  /* Future<bool> getMaterialTracking({required dynamic body}) async {
    bool resultValue = false;
    materialTrackingScreenLoader.value = true;
    try {
      await engine.post(AppStrings.baseUrl + AppStrings.getMaterialIndentTrackingUrl, body).then((value) {
        //debugPrint(value.data.toString());
        final result = jsonModelConvert(value.toString());
        debugPrint(result.toString());
        MaterialTrackingResponseNewModel model = MaterialTrackingResponseNewModel.fromJson(result);
        debugPrint(model.toString());
        */ /*MaterialTrackingResponseModel model = MaterialTrackingResponseModel.fromJson(value.data);
        materialTrackingList.value = model.data;
        */ /*
        resultValue = true;
        materialTrackingScreenLoader.value = false;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }*/

  Future<bool> submitToReceivedMaterial({required dynamic body}) async {
    bool resultValue = false;

    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getReceivedMaterial, body)
          .then((value) {
        // ReceiveMaterialResponseModel model = ReceiveMaterialResponseModel.fromJson(value.data);

        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> getMaterialTracking({required dynamic body}) async {
    bool resultValue = false;
    materialTrackingScreenLoader.value = true;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getMaterialIndentTrackingUrl,
              body)
          .then((value) {
        // log(jsonEncode(value.data));
        MaterialIndentResponseModel model =
            MaterialIndentResponseModel.fromJson(value.data);
        materialTrackingList.value = model.data;

        resultValue = true;
        materialTrackingScreenLoader.value = false;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  //Model Formation Method
  jsonModelConvert(String inputValue) {
    Map<String, dynamic> input = jsonDecode(inputValue);
    List<dynamic> data = input["Data"];

    for (var item in data) {
      List<dynamic> indentTrans = item["IndentTrans"];
      Map<String, dynamic> groupedIndentTrans = {};

      for (var trans in indentTrans) {
        String status = trans["Status"];
        String trackingID = trans["TrackingID"];
        if (groupedIndentTrans[status] == null) {
          groupedIndentTrans[status] = [];
        }
        var existingTrackingGroup = groupedIndentTrans[status].firstWhere(
            (e) => e["TrackingID"] == trackingID,
            orElse: () => null);
        if (existingTrackingGroup == null) {
          groupedIndentTrans[status].add({
            "TrackingID": trackingID,
            "DeliveryMode": trans["DeliveryMode"],
            "DespatchDate": trans["DespatchDate"],
            "details": []
          });
          existingTrackingGroup =
              groupedIndentTrans[status].last; // Point to the newly added group
        }
        existingTrackingGroup["details"].add({
          "BranchMaterialIndentID": trans["BranchMaterialIndentID"],
          "MaterialIndentTransID": trans["MaterialIndentTransID"],
          "DeliveryModeID": trans["DeliveryModeID"],
          "MaterialType": trans["MaterialType"],
          "MaterialName": trans["MaterialName"],
          "Price": trans["Price"],
          "Quantity": trans["Quantity"],
          "GST": trans["GST"],
          "GSTPrice": trans["GSTPrice"],
          "Total": trans["Total"],
          "ReceivedDate": trans["ReceivedDate"]
        });
      }

      item["IndentTrans"] = groupedIndentTrans;
    }
    //debugPrint(input.toString(), wrapWidth: 102400);
    // log(jsonEncode(input.toString()));
    return input;
  }

  Future<bool> invoiceDownload(
      {required String invoiceNo, required String fileName}) async {
    bool resultValue = false;
    dr.Dio dio = dr.Dio();
    // Map<String, dynamic> result = {
    //   'fileData': null,
    //   'mimeType': null,
    //   'success': false,
    // };

    try {
      Map<String, String> mainHeaders = {
        "Authorization":
            "Bearer ${SharedPreference.getString(AppStrings.accessToken)}",
        AppStrings.contentType: AppStrings.contentTypeValue
      };
      dio.options.headers = mainHeaders;
      dr.Response response = await dio.get(
        AppStrings.baseUrl + AppStrings.invoiceDownload + invoiceNo,
        options: dr.Options(
            responseType: dr.ResponseType.bytes), // Set responseType to bytes
      );
      if (response.statusCode == 200) {
        // Successfully received the file

        // Get the MIME type (Content-Type header)
        String? mimeType = response.headers.value('content-type');

        // Store the file data as bytes
        Uint8List fileData = response.data;

        bool result = await FileDownloadHelper.downloadFromUint8List(
            fileName, fileData, mimeType!);

        resultValue = result;
      } else {
        debugPrint("Error: ${response.statusCode}");
        resultValue = false;
      }
      return resultValue;
      // return response.data; // PDF data as bytes
    } catch (e) {
      resultValue = false;
      debugPrint("Func (invoiceDownload)=> $e");
      throw Exception('Failed to load PDF: $e');
    }
  }
}
