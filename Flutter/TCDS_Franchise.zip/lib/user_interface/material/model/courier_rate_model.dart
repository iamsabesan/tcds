class CourierRateModel {
  int code;
  String message;
  int data;

  CourierRateModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourierRateModel.fromJson(Map<String, dynamic> json) =>
      CourierRateModel(
        code: json["Code"],
        message: json["Message"],
        data: json["Data"],
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data,
      };
}
