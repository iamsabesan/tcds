class HqStockModel {
  int code;
  String message;
  List<HQStock> data;

  HqStockModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory HqStockModel.fromJson(Map<String, dynamic> json) => HqStockModel(
        code: json["Code"],
        message: json["Message"],
        data: List<HQStock>.from(json["Data"].map((x) => HQStock.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class HQStock {
  String materialId;
  String materialType;
  String materialName;
  int minimumStock;
  double price;
  int currentStock;

  HQStock({
    required this.materialId,
    required this.materialType,
    required this.materialName,
    required this.minimumStock,
    required this.price,
    required this.currentStock,
  });

  factory HQStock.fromJson(Map<String, dynamic> json) => HQStock(
        materialId: json["MaterialID"],
        materialType: json["MaterialType"],
        materialName: json["MaterialName"],
        minimumStock: json["MinimumStock"],
        price: json["Price"],
        currentStock: json["CurrentStock"],
      );

  Map<String, dynamic> toJson() => {
        "MaterialID": materialId,
        "MaterialType": materialType,
        "MaterialName": materialName,
        "MinimumStock": minimumStock,
        "Price": price,
        "CurrentStock": currentStock,
      };
}
