// To parse this JSON data, do
//
//     final materialIndentStatusResponseModel = materialIndentStatusResponseModelFromJson(jsonString);

import 'dart:convert';

MaterialIndentStatusResponseModel materialIndentStatusResponseModelFromJson(String str) => MaterialIndentStatusResponseModel.fromJson(json.decode(str));

String materialIndentStatusResponseModelToJson(MaterialIndentStatusResponseModel data) => json.encode(data.toJson());

class MaterialIndentStatusResponseModel {
  int code;
  String message;
  List<String> data;

  MaterialIndentStatusResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory MaterialIndentStatusResponseModel.fromJson(Map<String, dynamic> json) => MaterialIndentStatusResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<String>.from(json["Data"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x)),
  };
}
