class MaterialIndentResponseModel {
  int code;
  String message;
  List<MaterialTrackingList> data;

  MaterialIndentResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory MaterialIndentResponseModel.fromJson(Map<String, dynamic> json) =>
      MaterialIndentResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<MaterialTrackingList>.from(
            json["Data"].map((x) => MaterialTrackingList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class MaterialTrackingList {
  Indent indent;
  List<MaterialIndentTran> indentTrans;
  List<PaymentDetail> paymentDetails;

  MaterialTrackingList({
    required this.indent,
    required this.indentTrans,
    required this.paymentDetails,
  });

  factory MaterialTrackingList.fromJson(Map<String, dynamic> json) =>
      MaterialTrackingList(
        indent: Indent.fromJson(json["Indent"]),
        indentTrans: List<MaterialIndentTran>.from(
            json["IndentTrans"].map((x) => MaterialIndentTran.fromJson(x))),
        paymentDetails: List<PaymentDetail>.from(
            json["PaymentDetails"].map((x) => PaymentDetail.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Indent": indent.toJson(),
        "IndentTrans": List<dynamic>.from(indentTrans.map((x) => x.toJson())),
        "PaymentDetails":
            List<dynamic>.from(paymentDetails.map((x) => x.toJson())),
      };
}

class Indent {
  String branchMaterialIndentId;
  String indentNumber;
  String indentDate;
  String invoiceNo;
  String invoiceDate;
  int total;
  int ordered;
  int received;
  int dispatched;
  int pending;
  double amount;
  String status;

  Indent({
    required this.branchMaterialIndentId,
    required this.indentNumber,
    required this.indentDate,
    required this.invoiceNo,
    required this.invoiceDate,
    required this.total,
    required this.ordered,
    required this.received,
    required this.dispatched,
    required this.pending,
    required this.amount,
    required this.status,
  });

  factory Indent.fromJson(Map<String, dynamic> json) => Indent(
        branchMaterialIndentId: json["BranchMaterialIndentID"],
        indentNumber: json["IndentNumber"],
        indentDate: json["IndentDate"],
        invoiceNo: json["InvoiceNo"],
        invoiceDate: json["InvoiceDate"],
        total: json["Total"],
        ordered: json["Ordered"],
        received: json["Received"],
        dispatched: json["Despatched"],
        pending: json["Pending"],
        amount: json["Amount"],
        status: json["Status"],
      );

  Map<String, dynamic> toJson() => {
        "BranchMaterialIndentID": branchMaterialIndentId,
        "IndentNumber": indentNumber,
        "IndentDate": indentDate,
        "InvoiceNo": invoiceNo,
        "InvoiceDate": invoiceDate,
        "Total": total,
        "Ordered": ordered,
        "Received": received,
        "Despatched": dispatched,
        "Pending": pending,
        "Amount": amount,
        "Status": status,
      };
}

class MaterialIndentTran {
  String branchMaterialIndentId;
  String materialIndentTransId;
  String materialType;
  String materialName;
  String deliveryMode;
  String deliveryModeID;
  String trackingId;
  double price;
  int quantity;
  double gst;
  double gstPrice;
  double total;
  String dispatchDate;
  String receivedDate;
  String status;

  MaterialIndentTran({
    required this.branchMaterialIndentId,
    required this.materialIndentTransId,
    required this.materialType,
    required this.materialName,
    required this.trackingId,
    required this.deliveryMode,
    required this.deliveryModeID,
    required this.price,
    required this.quantity,
    required this.gst,
    required this.gstPrice,
    required this.total,
    required this.dispatchDate,
    required this.receivedDate,
    required this.status,
  });

  factory MaterialIndentTran.fromJson(Map<String, dynamic> json) =>
      MaterialIndentTran(
        branchMaterialIndentId: json["BranchMaterialIndentID"],
        materialIndentTransId: json["MaterialIndentTransID"],
        materialType: json["MaterialType"],
        materialName: json["MaterialName"],
        trackingId: json["TrackingID"],
        deliveryMode: json["DeliveryMode"],
        deliveryModeID: json["DeliveryModeID"],
        price: json["Price"],
        quantity: json["Quantity"],
        gst: json["GST"],
        gstPrice: json["GSTPrice"],
        total: json["Total"],
        dispatchDate: json["DespatchDate"],
        receivedDate: json["ReceivedDate"],
        status: json["Status"],
      );

  Map<String, dynamic> toJson() => {
        "BranchMaterialIndentID": branchMaterialIndentId,
        "MaterialIndentTransID": materialIndentTransId,
        "MaterialType": materialType,
        "MaterialName": materialName,
        "DeliveryModeID": deliveryModeID,
        "DeliveryMode": deliveryMode,
        "Price": price,
        "Quantity": quantity,
        "GST": gst,
        "GSTPrice": gstPrice,
        "Total": total,
        "DespatchDate": dispatchDate,
        "ReceivedDate": receivedDate,
        "Status": status,
      };
}

class PaymentDetail {
  String transactionDate;
  String summary;
  double amount;
  String payMode;
  String documentId;

  PaymentDetail({
    required this.transactionDate,
    required this.summary,
    required this.amount,
    required this.payMode,
    required this.documentId,
  });

  factory PaymentDetail.fromJson(Map<String, dynamic> json) => PaymentDetail(
        transactionDate: json["TransactionDate"],
        summary: json["Summary"],
        amount: json["Amount"],
        payMode: json["PayMode"],
        documentId: json["DocumentID"],
      );

  Map<String, dynamic> toJson() => {
        "TransactionDate": transactionDate,
        "Summary": summary,
        "Amount": amount,
        "PayMode": payMode,
        "DocumentID": documentId,
      };
}
