import 'dart:convert';

MaterialTrackingIndentResponseNewModel materialTrackingResponseNewModelFromJson(String str) => MaterialTrackingIndentResponseNewModel.fromJson(json.decode(str));

String materialTrackingResponseNewModelToJson(MaterialTrackingIndentResponseNewModel data) => json.encode(data.toJson());

class MaterialTrackingIndentResponseNewModel {
    int code;
    String message;
    List<Datum> data;

    MaterialTrackingIndentResponseNewModel({
        required this.code,
        required this.message,
        required this.data,
    });

    factory MaterialTrackingIndentResponseNewModel.fromJson(Map<String, dynamic> json) => MaterialTrackingIndentResponseNewModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
    };
}

class Datum {
    Indent indent;
    IndentTrans indentTrans;
    List<PaymentDetail> paymentDetails;

    Datum({
        required this.indent,
        required this.indentTrans,
        required this.paymentDetails,
    });

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        indent: Indent.fromJson(json["Indent"]),
        indentTrans: IndentTrans.fromJson(json["IndentTrans"]),
        paymentDetails: List<PaymentDetail>.from(json["PaymentDetails"].map((x) => PaymentDetail.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "Indent": indent.toJson(),
        "IndentTrans": indentTrans.toJson(),
        "PaymentDetails": List<dynamic>.from(paymentDetails.map((x) => x.toJson())),
    };
}

class Indent {
    String branchMaterialIndentId;
    String indentNumber;
    String indentDate;
    String invoiceNo;
    String invoiceDate;
    int total;
    int ordered;
    int received;
    int despatched;
    int pending;
    double amount;
    String status;

    Indent({
        required this.branchMaterialIndentId,
        required this.indentNumber,
        required this.indentDate,
        required this.invoiceNo,
        required this.invoiceDate,
        required this.total,
        required this.ordered,
        required this.received,
        required this.despatched,
        required this.pending,
        required this.amount,
        required this.status,
    });

    factory Indent.fromJson(Map<String, dynamic> json) => Indent(
        branchMaterialIndentId: json["BranchMaterialIndentID"],
        indentNumber: json["IndentNumber"],
        indentDate: json["IndentDate"],
        invoiceNo: json["InvoiceNo"],
        invoiceDate: json["InvoiceDate"],
        total: json["Total"],
        ordered: json["Ordered"],
        received: json["Received"],
        despatched: json["Despatched"],
        pending: json["Pending"],
        amount: json["Amount"],
        status: json["Status"],
    );

    Map<String, dynamic> toJson() => {
        "BranchMaterialIndentID": branchMaterialIndentId,
        "IndentNumber": indentNumber,
        "IndentDate": indentDate,
        "InvoiceNo": invoiceNo,
        "InvoiceDate": invoiceDate,
        "Total": total,
        "Ordered": ordered,
        "Received": received,
        "Despatched": despatched,
        "Pending": pending,
        "Amount": amount,
        "Status": status,
    };
}

class IndentTrans {
    List<Dispatched> dispatched;
    List<Dispatched> pending;

    IndentTrans({
        required this.dispatched,
        required this.pending,
    });

    factory IndentTrans.fromJson(Map<String, dynamic> json) => IndentTrans(
        dispatched: List<Dispatched>.from(json["DISPATCHED"].map((x) => Dispatched.fromJson(x))),
        pending: List<Dispatched>.from(json["PENDING"].map((x) => Dispatched.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "DISPATCHED": List<dynamic>.from(dispatched.map((x) => x.toJson())),
        "PENDING": List<dynamic>.from(pending.map((x) => x.toJson())),
    };
}

class Dispatched {
    String trackingId;
    String deliveryMode;
    String despatchDate;
    List<Detail> details;

    Dispatched({
        required this.trackingId,
        required this.deliveryMode,
        required this.despatchDate,
        required this.details,
    });

    factory Dispatched.fromJson(Map<String, dynamic> json) => Dispatched(
        trackingId: json["TrackingID"],
        deliveryMode: json["DeliveryMode"],
        despatchDate: json["DespatchDate"],
        details: List<Detail>.from(json["details"].map((x) => Detail.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "TrackingID": trackingId,
        "DeliveryMode": deliveryMode,
        "DespatchDate": despatchDate,
        "details": List<dynamic>.from(details.map((x) => x.toJson())),
    };
}

class Detail {
    String branchMaterialIndentId;
    String materialIndentTransId;
    String deliveryModeId;
    String materialType;
    String materialName;
    double price;
    int quantity;
    double gst;
    double gstPrice;
    double total;
    String receivedDate;

    Detail({
        required this.branchMaterialIndentId,
        required this.materialIndentTransId,
        required this.deliveryModeId,
        required this.materialType,
        required this.materialName,
        required this.price,
        required this.quantity,
        required this.gst,
        required this.gstPrice,
        required this.total,
        required this.receivedDate,
    });

    factory Detail.fromJson(Map<String, dynamic> json) => Detail(
        branchMaterialIndentId: json["BranchMaterialIndentID"],
        materialIndentTransId: json["MaterialIndentTransID"],
        deliveryModeId: json["DeliveryModeID"],
        materialType: json["MaterialType"],
        materialName: json["MaterialName"],
        price: json["Price"],
        quantity: json["Quantity"],
        gst: json["GST"],
        gstPrice: json["GSTPrice"],
        total: json["Total"],
        receivedDate: json["ReceivedDate"],
    );

    Map<String, dynamic> toJson() => {
        "BranchMaterialIndentID": branchMaterialIndentId,
        "MaterialIndentTransID": materialIndentTransId,
        "DeliveryModeID": deliveryModeId,
        "MaterialType": materialType,
        "MaterialName": materialName,
        "Price": price,
        "Quantity": quantity,
        "GST": gst,
        "GSTPrice": gstPrice,
        "Total": total,
        "ReceivedDate": receivedDate,
    };
}

class PaymentDetail {
    String transactionDate;
    String summary;
    double amount;
    String payMode;
    String documentId;

    PaymentDetail({
        required this.transactionDate,
        required this.summary,
        required this.amount,
        required this.payMode,
        required this.documentId,
    });

    factory PaymentDetail.fromJson(Map<String, dynamic> json) => PaymentDetail(
        transactionDate: json["TransactionDate"],
        summary: json["Summary"],
        amount: json["Amount"],
        payMode: json["PayMode"],
        documentId: json["DocumentID"],
    );

    Map<String, dynamic> toJson() => {
        "TransactionDate": transactionDate,
        "Summary": summary,
        "Amount": amount,
        "PayMode": payMode,
        "DocumentID": documentId,
    };
}
