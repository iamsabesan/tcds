// To parse this JSON data, do
//
//     final receiveMaterialResponseModel = receiveMaterialResponseModelFromJson(jsonString);

import 'dart:convert';

ReceiveMaterialResponseModel receiveMaterialResponseModelFromJson(String str) => ReceiveMaterialResponseModel.fromJson(json.decode(str));

String receiveMaterialResponseModelToJson(ReceiveMaterialResponseModel data) => json.encode(data.toJson());

class ReceiveMaterialResponseModel {
  int code;
  String message;
  String data;

  ReceiveMaterialResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory ReceiveMaterialResponseModel.fromJson(Map<String, dynamic> json) => ReceiveMaterialResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
