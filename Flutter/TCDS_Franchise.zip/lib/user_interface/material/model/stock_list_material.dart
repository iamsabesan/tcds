// To parse this JSON data, do
//
//     final stockListResponseModel = stockListResponseModelFromJson(jsonString);

import 'dart:convert';

StockListResponseModel stockListResponseModelFromJson(String str) => StockListResponseModel.fromJson(json.decode(str));

String stockListResponseModelToJson(StockListResponseModel data) => json.encode(data.toJson());

class StockListResponseModel {
  int code;
  String message;
  List<StockList> data;

  StockListResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StockListResponseModel.fromJson(Map<String, dynamic> json) => StockListResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<StockList>.from(json["Data"].map((x) => StockList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class StockList {
  String materialId;
  int currentStock;
  String materialType;
  String materialName;
  double price;

  StockList({
    required this.materialId,
    required this.currentStock,
    required this.materialType,
    required this.materialName,
    required this.price,
  });

  factory StockList.fromJson(Map<String, dynamic> json) => StockList(
    materialId: json["MaterialID"],
    currentStock: json["CurrentStock"],
    materialType: json["MaterialType"],
    materialName: json["MaterialName"],
    price: json["Price"],
  );

  Map<String, dynamic> toJson() => {
    "MaterialID": materialId,
    "CurrentStock": currentStock,
    "MaterialType": materialType,
    "MaterialName": materialName,
    "Price": price,
  };
}
