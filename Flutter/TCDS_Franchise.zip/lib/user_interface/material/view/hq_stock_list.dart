import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/material/controller/material_indent_controller.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_widget_one.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';

class HqStockList extends StatefulWidget {
  const HqStockList({super.key});

  @override
  State<HqStockList> createState() => _HqStockListState();
}

class _HqStockListState extends State<HqStockList> {
  MaterialIndentController materialController =
      Get.find<MaterialIndentController>();

  NumberFormat rsFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: 'Rs.', decimalDigits: 0);

  Future<void> getApiCall() async {
    await materialController.getHQStockList();
    filterKeys = materialController.filterKeys;
    if (filterKeys.isNotEmpty) {
      String firstKey = filterKeys.first;
      filterIDTxtCtrl.text = firstKey.toLowerCase();
      filterTxtCtrl.text = firstKey;

      // Set initial filtered stocks
      materialController.hqFilteredStocks.value =
          materialController.hqMaterialWiseStocks[firstKey] ?? [];
    }
  }

  TextEditingController filterIDTxtCtrl = TextEditingController();
  TextEditingController filterTxtCtrl = TextEditingController();
  late List<String> filterKeys;

  @override
  void initState() {
    getApiCall();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();

    materialController.filterKeys.clear();
    materialController.hqFilteredStocks.clear();
    materialController.hqMaterialWiseStocks.clear();
    materialController.hqStockList.clear();
    debugPrint("HQ Widget Disposed");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 5,
        ),
      ),
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        toolbarHeight: 70,
        titleSpacing: 0,
        title: CustomText(
          text: "Head Office Stocks",
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Obx(() {
        return materialController.hqStockListScreenLoader.value
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColor.primaryColor,
                ),
              )
            : RefreshIndicator(
                onRefresh: () async {
                  // Save current selection before refresh
                  String currentSelection = filterTxtCtrl.text;

                  await materialController.getHQStockList();

                  // Restore the selection after refresh
                  filterKeys = materialController.filterKeys;
                  if (filterKeys.isNotEmpty) {
                    // Check if the previous selection still exists
                    if (filterKeys.contains(currentSelection)) {
                      filterTxtCtrl.text = currentSelection;
                      filterIDTxtCtrl.text = currentSelection.toLowerCase();
                      materialController.hqFilteredStocks.value =
                          materialController
                                  .hqMaterialWiseStocks[currentSelection] ??
                              [];
                    } else {
                      // Fall back to first item if previous selection doesn't exist
                      String firstKey = filterKeys.first;
                      filterTxtCtrl.text = firstKey;
                      filterIDTxtCtrl.text = firstKey.toLowerCase();
                      materialController.hqFilteredStocks.value =
                          materialController.hqMaterialWiseStocks[firstKey] ??
                              [];
                    }
                  }
                },
                child: Column(
                  children: [
                    SizedBox(
                      height: 30.w,
                    ),
                    // filter dropdown
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: SingleSelectDropDown(
                        labelText: "Material Type",
                        valueController: filterIDTxtCtrl,
                        valueTextController: filterTxtCtrl,
                        data: List.generate(
                          filterKeys.length,
                          (index) {
                            return SingleSelectDropDownModel(filterKeys[index],
                                filterKeys[index].toLowerCase());
                          },
                        ),
                        parentOnChangeCall: (value) {
                          if (value != null) {
                            debugPrint("=== HQ FILTER CHANGE EVENT ===");
                            debugPrint("Selected value: ${value.value}");
                            debugPrint(
                                "Current text before: ${filterTxtCtrl.text}");
                            debugPrint(
                                "Available material types: ${materialController.hqMaterialWiseStocks.keys.toList()}");

                            // The dropdown component automatically updates the text controllers
                            // So we can directly use value.value for filtering

                            var filteredItems = materialController
                                    .hqMaterialWiseStocks[value.value] ??
                                [];

                            debugPrint(
                                "Found ${filteredItems.length} items for ${value.value}");
                            materialController.hqFilteredStocks.value =
                                filteredItems;

                            debugPrint(
                                "Updated HQ filtered stocks: ${materialController.hqFilteredStocks.length} items");
                            for (var stock
                                in materialController.hqFilteredStocks) {
                              debugPrint(
                                  "  - ${stock.materialName} (${stock.materialType})");
                            }
                          }
                        },
                      ),
                    ),

                    // list data
                    if (materialController.hqFilteredStocks.isNotEmpty)
                      Expanded(
                        child: ListView.builder(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15.w, vertical: 30),
                            itemCount:
                                materialController.hqFilteredStocks.length,
                            itemBuilder: (BuildContext context, int index) {
                              return CustomWidgetOne(
                                orderNumber: index + 1,
                                amount: rsFormat.format(materialController
                                    .hqFilteredStocks[index].price),
                                courseName: materialController
                                    .hqFilteredStocks[index].materialName,
                                keyText1: materialController
                                    .hqFilteredStocks[index].currentStock
                                    .toString(),
                                // keyText2: "Type",
                                valueText1: "Nos.",
                                // valueText2: materialController
                                //     .hqFilteredStocks[index].materialType,
                                withDivider: true,
                                withForwardArrow: false,
                                withKeyText2: false,
                              );
                            }),
                      ),
                    if (materialController.hqFilteredStocks.isEmpty)
                      const Expanded(
                          child: Center(
                        child: CustomText(
                          text: "No Data",
                          color: AppColor.blackColor,
                        ),
                      )),
                  ],
                ),
              );
      }),
    );
  }
}
