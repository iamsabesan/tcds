import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/material/view/indent_payment_screen.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/bottom_navigation.dart';
import '../../../utils/helper_widgets/bottom_sheets.dart';
import '../../../utils/helper_widgets/custom_drawer.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/custom_widget_two_line.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../dashboard/view/dashboard_screen.dart';
import '../../students_list/controller/student_list_controller.dart';

class IndentCreationScreen extends StatefulWidget {
  const IndentCreationScreen({super.key});

  @override
  State<IndentCreationScreen> createState() => _IndentCreationScreenState();
}

class _IndentCreationScreenState extends State<IndentCreationScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  StudentListController studentListController =
      Get.put(StudentListController());
  int _selectedIndex = 3;
  int appliedFilterCount = 0;
  List<Map<String, dynamic>> orderDetail = [];
  double totalAmnt = 0;
  double previousAmnt = 0;

  NumberFormat currencyFormat =
      NumberFormat.currency(decimalDigits: 2, symbol: "₹", locale: "hi_IN");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 3,
        ),
      ),
      appBar: AppBar(
        titleSpacing: 0,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        toolbarHeight: 70,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Material Indent',
          fontSize: AppFontSize.size2.sp,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        actions: [
          InkWell(
            onTap: () async {
              PleaseWaitLoader.openDialog();
              // Fetch required data for the filter screen
              await studentListController.getMaterialTypeList();
              if (studentListController.materialTypeDataList.isNotEmpty) {
                await studentListController.getMaterialList(
                    materialTypeId: studentListController
                        .materialTypeDataList[0].materialTypeId);
              }
              // await studentListController.getCourseListByFranchisee();
              PleaseWaitLoader.closeDialog();

              if (studentListController.materialDataList.isNotEmpty) {
                // Show filter bottom sheet
                final filterData = await AppBottomSheets.addIndent(
                  // getBatch: studentListController.batchListByCourseId,
                  context: Get.context!,
                  create: true,
                  onFilterCountUpdated: (count) {
                    setState(() {
                      appliedFilterCount = count;
                      debugPrint(
                          "Filter count updated: $appliedFilterCount"); // Update filter count dynamically
                    });
                  },
                  // courseList: studentListController.courseListByFranchisee,
                );

                if (filterData != null) {
                  setState(() {
                    orderDetail.add(filterData);
                    totalAmnt += filterData["totalPrice"];
                    // paymentConfirmed[paymentMode] = true; // Mark as confirmed
                  });
                }
              }
            },
            child: Container(
              height: 45.w,
              width: 45.w,
              margin: const EdgeInsets.only(right: 15),
              decoration: BoxDecoration(
                color: AppColor.whiteColor,
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(
                  color: AppColor.grey,
                  width: 2,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: AppColor.grey2,
                    blurRadius: 4,
                    spreadRadius: 1,
                    offset: Offset(4, 5),
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: Image.asset(
                AssetPath.plusIcon,
                fit: BoxFit.contain,
                height: 25.w,
                width: 25.w,
              ),
            ),
          ),
        ],
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          if (orderDetail.isEmpty)
            Expanded(
              child: Center(
                child: CustomText(
                  text: "Not added yet.",
                  fontSize: AppFontSize.size4.sp,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          if (orderDetail.isNotEmpty)
            Expanded(
              child: ListView(
                children: [
                  SizedBox(
                    height: 15.w,
                  ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 15.w, vertical: 5.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Column(
                          children: List.generate(orderDetail.length,
                              (int historyIndex) {
                            final data = orderDetail[historyIndex];
                            debugPrint(data["materialType"]);
                            return InkWell(
                              onTap: () async {
                                await studentListController.getMaterialList(
                                    materialTypeId: data["materialTypeID"]);
                                previousAmnt = data["totalPrice"];
                                final filterData =
                                    await AppBottomSheets.addIndent(
                                  // getBatch:
                                  //     studentListController.batchListByCourseId,
                                  context: Get.context!,
                                  create: false,
                                  orderDetail: data,
                                  index: historyIndex,
                                  previousAmnt: data["totalPrice"],
                                  onFilterCountUpdated: (count) {
                                    setState(() {
                                      appliedFilterCount = count;
                                      debugPrint(
                                          "Filter count updated: $appliedFilterCount"); //// Update filter count dynamically
                                    });
                                  },
                                  // courseList: studentListController
                                  // .courseListByFranchisee,
                                );
                                if (filterData != null) {
                                  if (filterData["isDeleted"] == true) {
                                    int indexValue = filterData["index"];
                                    orderDetail.removeAt(indexValue);
                                    totalAmnt -= previousAmnt;
                                  } else {
                                    int indexValue = filterData["index"];
                                    orderDetail[indexValue]['materialTypeID'] =
                                        filterData['materialTypeID'];
                                    orderDetail[indexValue]['materialType'] =
                                        filterData['materialType'];
                                    orderDetail[indexValue]['materialID'] =
                                        filterData['materialID'];
                                    orderDetail[indexValue]['materialName'] =
                                        filterData['materialName'];
                                    orderDetail[indexValue]['quantity'] =
                                        filterData['quantity'];
                                    orderDetail[indexValue]['totalPrice'] =
                                        filterData['totalPrice'];
                                    orderDetail[indexValue]['price'] =
                                        filterData['price'];
                                    orderDetail[indexValue]['gstPercent'] =
                                        filterData['gstPercent'];
                                    orderDetail[indexValue]['gstAmount'] =
                                        filterData['gstAmount'];
                                    orderDetail[indexValue]['taxableAmount'] =
                                        filterData['taxableAmount'];
                                    // previousAmnt-=filterData['totalPrice'];
                                    totalAmnt -= previousAmnt;
                                    totalAmnt += filterData['totalPrice'];
                                  }
                                  setState(() {});
                                }
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 15.w),
                                child: CustomWidgetTwoLine(
                                  withForwardArrow: true,
                                  title: data["materialType"],
                                  duration: data["quantity"],
                                  courseType: data["materialName"].toString(),
                                  price:
                                      currencyFormat.format(data["totalPrice"]),
                                  onTap: () async {},
                                ),
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          if (orderDetail.isNotEmpty)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 40.w),
              child: Card(
                color: AppColor.containerGrey,
                margin: EdgeInsets.all(5.w),
                child: Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          CustomText(
                            text: "Total : ",
                            color: AppColor.textHeaderClr,
                            fontSize: AppFontSize.size4,
                            fontWeight: FontWeight.w500,
                          ),
                          CustomText(
                            text: currencyFormat.format(totalAmnt),
                            color: AppColor.secondaryColor,
                            fontSize: AppFontSize.size4,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                      InkWell(
                        child: InButton(
                          onTap: () async {
                            debugPrint(orderDetail.toString());
                            Get.to(
                                () => IndentPaymentScreen(
                                      receivedData: orderDetail,
                                      totalAmnt: totalAmnt,
                                    ),
                                transition: Transition.rightToLeft,
                                duration: const Duration(milliseconds: 600));
                          },
                          withArrow: false,
                          text: "Pay",
                          color: AppColor.primaryColor,
                          verticalPadding: 10.w,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
