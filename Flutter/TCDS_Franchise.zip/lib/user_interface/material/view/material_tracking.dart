import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/material/controller/material_indent_controller.dart';
import 'package:tcds/user_interface/material/model/material_tracking_response_model.dart';
import 'package:tcds/user_interface/material/view/material_tracking_detail_screen.dart';
import 'package:tcds/utils/helper_widgets/bullet_text.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/date_range_filter_section.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';

class MaterialTrackingScreen extends StatefulWidget {
  const MaterialTrackingScreen({super.key});

  @override
  State<MaterialTrackingScreen> createState() => _MaterialTrackingScreenState();
}

class _MaterialTrackingScreenState extends State<MaterialTrackingScreen> {
  MaterialIndentController materialController =
      Get.put(MaterialIndentController());

  String selectedStatus = "Pending";

  final List<String> status = ["Pending", "Despatched", "Received"];
  // DateFormat inputFormat = DateFormat("dd-MM-yyyy hh:mm:ss a");

  // // Define the desired output format
  // DateFormat outputFormat = DateFormat("dd-MM-yyyy");

  NumberFormat currencyFormat =
      NumberFormat.currency(decimalDigits: 2, symbol: "₹", locale: "hi_IN");

  // boolean helper for to show date filters when Status equals Recieved
  bool isReceived = false;

  TextEditingController fromDateController = TextEditingController();
  TextEditingController toDateController = TextEditingController();
  TextEditingController dateRangeController = TextEditingController();

  DateFormat apiDateFormat = DateFormat("yyyy-MM-dd");
  DateFormat userDateFormat = DateFormat("dd-MM-yyyy");

  DateTime now = DateTime.now();

  @override
  void initState() {
    getApiCall(selectedStatus);
    super.initState();
  }

  Future<void> getApiCall(String status) async {
    // if status is Received pass dates also
    if (isReceived) {
      if (fromDateController.text.isEmpty || toDateController.text.isEmpty) {
        toDateController.text = userDateFormat.format(now);
        String tempFromD =
            userDateFormat.format(DateTime(now.year, now.month, 1));
        fromDateController.text = tempFromD;
      }

      DateTime fromDate = userDateFormat.parse(fromDateController.text);
      DateTime toDate = userDateFormat.parse(toDateController.text);
      String paresedFromD = apiDateFormat.format(fromDate);
      String paresedToD = apiDateFormat.format(toDate);
      await materialController.getMaterialTracking(body: {
        "Status": status,
        "FromDate": paresedFromD,
        "ToDate": paresedToD,
      });

      return;
    }

    await materialController.getMaterialTracking(body: {
      "Status": status,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        toolbarHeight: 70,
        titleSpacing: 0,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Tracking',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 30.w),
          // Dropdown for status selection
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.w),
            child: DropdownButtonFormField<String>(
              initialValue: selectedStatus,
              dropdownColor: AppColor.whiteColor,
              items: status.map((status) {
                return DropdownMenuItem(
                  value: status,
                  child: Text(status),
                );
              }).toList(),
              decoration: InputDecoration(
                labelText: "Select Status",
                labelStyle: const TextStyle(color: AppColor.blackColor),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black.withValues(alpha: 0.1),
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: AppColor.primaryColor),
                  // borderSide: BorderSide(
                  //   color: AppColor.grey2,
                  //   width: 1.5,
                  // ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                border: OutlineInputBorder(
                  borderSide: const BorderSide(
                    color: AppColor.grey2,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
              ),
              borderRadius: BorderRadius.circular(10.0),
              style: const TextStyle(color: AppColor.blackColor),
              enableFeedback: true,
              onChanged: (newValue) {
                if (newValue != selectedStatus) {
                  setState(() {
                    // show Date pickers when status is in "Received"
                    selectedStatus = newValue!;
                    isReceived = selectedStatus == "Received";
                  });
                  getApiCall(selectedStatus);
                }
              },
              isExpanded: true,
            ),
          ),

          const SizedBox(height: 15),
          // Date filter section
          if (isReceived)
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 15.w),
              child: DateRangeFilterSection(
                fromDateController: fromDateController,
                toDateController: toDateController,
                dateRangeController: dateRangeController,
                searchOnTap: () => getApiCall(selectedStatus),
              ),
            ),
          const SizedBox(height: 15),
          // List of filtered indents
          Expanded(
            child: Obx(
              () {
                return materialController.materialTrackingScreenLoader.value
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: AppColor.primaryColor,
                        ),
                      )
                    : materialController.materialTrackingList.isEmpty
                        ? Center(
                            child: CustomText(
                              text: 'No data available',
                              fontWeight: FontWeight.w500,
                              color: AppColor.primaryColor,
                              fontSize: AppFontSize.size3,
                            ),
                          )
                        : ListView.builder(
                            itemCount:
                                materialController.materialTrackingList.length,
                            itemBuilder: (context, index) {
                              // final trackingData = materialController.materialTrackingList[index];
                              return materialTrackingWidget(
                                materialTrackingData: materialController
                                    .materialTrackingList[index],
                              );
                            },
                          );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget materialTrackingWidget(
      {required MaterialTrackingList materialTrackingData}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 15.w),
      child: Column(
        children: [
          InkWell(
            onTap: () {
              Get.to(
                  () => MaterialDetailsScreen(
                        selectedStatus: selectedStatus,
                        indentNumber:
                            materialTrackingData.indent.indentNumber.toString(),
                        indentTrans: materialTrackingData.indentTrans,
                        indent: materialTrackingData.indent,
                        paymentDetails: materialTrackingData.paymentDetails,
                      ),
                  transition: Transition.rightToLeft,
                  duration: const Duration(milliseconds: 600));
            },
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 12,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text: materialTrackingData.indent.indentNumber,
                            fontSize: AppFontSize.size4.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                          ),
                          Row(
                            children: [
                              CustomText(
                                text: materialTrackingData.indent.total
                                    .toString(),
                                fontSize: AppFontSize.size4.sp,
                                fontWeight: FontWeight.w500,
                                color: AppColor.blueColor,
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              CustomText(
                                text: "Items",
                                fontSize: AppFontSize.size4.sp,
                                fontWeight: FontWeight.w500,
                                color: AppColor.blackColor,
                              ),
                            ],
                          ),
                          CustomText(
                            text: materialTrackingData.indent.status,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size4.sp,
                            color: materialTrackingData.indent.status
                                        .toLowerCase()
                                        .removeAllWhitespace ==
                                    "received"
                                ? AppColor.green // for 'received'
                                : materialTrackingData.indent.status
                                            .toLowerCase()
                                            .removeAllWhitespace ==
                                        "pending"
                                    ? AppColor.redColor // for 'pending'
                                    : materialTrackingData.indent.status
                                                .toLowerCase()
                                                .removeAllWhitespace ==
                                            "partialpending"
                                        ? AppColor
                                            .blueColor // for 'partial pending'
                                        : materialTrackingData.indent.status
                                                    .toLowerCase()
                                                    .removeAllWhitespace ==
                                                "dispatched"
                                            ? AppColor
                                                .orange // for 'dispatched'
                                            : AppColor
                                                .black2Color, // default color if none of the conditions match
                          )
                        ],
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      // Indent date and amount row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text:
                                //  outputFormat.format(inputFormat
                                //     .parse(materialTrackingData.indent.indentDate)),
                                materialTrackingData.indent.indentDate,
                            fontSize: AppFontSize.size4.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.black2Color,
                          ),
                          CustomText(
                            text: currencyFormat
                                .format(materialTrackingData.indent.amount),
                            fontSize: AppFontSize.size4.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.blackColor,
                          ),
                        ],
                      ),
                      SizedBox(height: 8.w),
                      // Quantities row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          BulletText(
                            label: "Ordered",
                            withBullet: false,
                            value:
                                materialTrackingData.indent.ordered.toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size4.sp,
                          ),
                          BulletText(
                            label: "Dispatched",
                            value: materialTrackingData.indent.dispatched
                                .toString(),
                            valueColor: AppColor.orange,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size4.sp,
                          ),
                          BulletText(
                            label: "Received",
                            value:
                                materialTrackingData.indent.received.toString(),
                            valueColor: AppColor.green,
                            labelColor: AppColor.blackColor,
                            fontSize: AppFontSize.size4.sp,
                          ),
                          BulletText(
                            label: "Pending",
                            value:
                                materialTrackingData.indent.pending.toString(),
                            labelColor: AppColor.blackColor,
                            valueColor: AppColor.redColor,
                            fontSize: AppFontSize.size6.sp,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                    flex: 1,
                    child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(top: 15.w),
                          child: ForwardArrowWidget(
                            onTap: () {
                              Get.to(
                                () => MaterialDetailsScreen(
                                  selectedStatus: selectedStatus,
                                  indentNumber: materialTrackingData
                                      .indent.indentNumber
                                      .toString(),
                                  indentTrans: materialTrackingData.indentTrans,
                                  indent: materialTrackingData.indent,
                                  paymentDetails:
                                      materialTrackingData.paymentDetails,
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    )),
              ],
            ),
          ),
          SizedBox(
            height: 5.w,
          ),
          const Divider(
            thickness: 1.0,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }
}
