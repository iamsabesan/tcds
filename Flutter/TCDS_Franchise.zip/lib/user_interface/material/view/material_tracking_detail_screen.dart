import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get_core/get_core.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/material/controller/material_indent_controller.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:collection/collection.dart';
import '../model/material_tracking_response_model.dart';

class MaterialDetailsScreen extends StatefulWidget {
  final Indent indent;
  final List<MaterialIndentTran> indentTrans;
  final String indentNumber;
  final List<PaymentDetail> paymentDetails;
  final String selectedStatus;

  // final List<IndentTran> dispatchedGroups;
  // final List<IndentTran> pendingGroups;
  // final List<IndentTran> receivedGroups;

  const MaterialDetailsScreen({
    super.key,
    required this.indent,
    required this.indentTrans,
    required this.indentNumber,
    required this.paymentDetails,
    required this.selectedStatus,
    // required this.dispatchedGroups,
    // required this.pendingGroups,
    // required this.receivedGroups,
  });

  @override
  State<MaterialDetailsScreen> createState() => _MaterialDetailsScreenState();
}

class _MaterialDetailsScreenState extends State<MaterialDetailsScreen> {
  int _selectedIndex = 2;

  MaterialIndentController materialController =
      Get.find<MaterialIndentController>();

  List<Map<String, dynamic>> dispatchedGroups = [];
  List<Map<String, dynamic>> receivedGroups = [];
  List<Map<String, dynamic>> pendingGroups = [];
  List<Map<String, dynamic>> selectedMaterials = [];

  NumberFormat currencyFormat =
      NumberFormat.currency(decimalDigits: 2, symbol: "₹", locale: "hi_IN");

  Future<void> processIndentTrans(List<MaterialIndentTran> indentTrans) async {
    // Group IndentTrans by TrackingID
    final groupedData =
        groupBy(indentTrans, (MaterialIndentTran trans) => trans.trackingId);
    for (var entry in groupedData.entries) {
      String trackingID = entry.key;
      List<MaterialIndentTran> items = entry.value;

      String dispatchedDate = items.first.dispatchDate.split(' ')[0];
      String deliveryPartner = items.first.deliveryMode;
      List<Map<String, dynamic>> groupItems = [];

      for (var item in items) {
        groupItems.add({
          "materialName": item.materialName,
          "materialType": item.materialType,
          "quantity": item.quantity,
          "isSelected": false,
          "materialIndentTransId": item.materialIndentTransId
        });
      }
      // Determine the group based on the status
      if (items.any((item) => item.status.toUpperCase() == "DISPATCHED")) {
        dispatchedGroups.add({
          "trackingID": trackingID,
          "deliveryPartner": deliveryPartner,
          "dispatchedDate": dispatchedDate,
          "items": groupItems,
        });
      }
      if (items.any((item) => item.status.toUpperCase() == "RECEIVED")) {
        receivedGroups.add({
          "trackingID": trackingID,
          "deliveryPartner": deliveryPartner,
          "dispatchedDate": dispatchedDate,
          "items": groupItems,
        });
      }
      if (items.any((item) => ((item.status.toUpperCase() == "PENDING") ||
          (item.status.toUpperCase() == "ORDERED") ||
          item.status.toUpperCase() == "ACCEPTED"))) {
        pendingGroups.add({
          "trackingID": trackingID,
          "deliveryPartner": deliveryPartner,
          "dispatchedDate": dispatchedDate,
          "items": groupItems,
        });
      }
    }

    setState(() {});

    // Log or update state with the grouped data
    debugPrint('Dispatched Groups: $dispatchedGroups');
    debugPrint('Received Groups: $receivedGroups');
    debugPrint('Pending Groups: $pendingGroups');
  }

  bool isExpanded = false;

  @override
  void initState() {
    processIndentTrans(widget.indentTrans);
    super.initState();
  }

  // int _calculateTotalQuantity(List<MaterialIndentTran> group) {
  //   return group.fold(0, (sum, item) => sum + (item.quantity ?? 0)); // Adjust this based on your IndentTran class
  // }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColor.whiteColor,
        appBar: AppBar(
          elevation: 2,
          shadowColor: AppColor.black3Color,
          surfaceTintColor: AppColor.whiteColor,
          scrolledUnderElevation: 2,
          titleSpacing: 0,
          backgroundColor: AppColor.whiteColor,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_outlined),
            onPressed: () {
              Get.back();
            },
          ),
          title: CustomText(
            text: widget.indentNumber,
            fontSize: AppFontSize.size2,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(50.w), // Adjust height as needed
            child: Column(
              children: [
                TabBar(
                  labelColor: AppColor.blackColor,
                  indicatorColor: AppColor.orange,
                  dividerColor: AppColor.whiteColor,
                  tabs: [
                    Tab(text: "Dispatched (${dispatchedGroups.length})"),
                    Tab(
                        text:
                            "Received (${receivedGroups.length})"), //_calculateTotalQuantity(receivedGroups)
                    Tab(text: "Pending (${pendingGroups.length})"),
                    /*  Tab(text: "Dispatched (${widget.indent.dispatched})"),
                    Tab(
                        text:
                            "Received (${widget.indent.received})"), //_calculateTotalQuantity(receivedGroups)
                    Tab(text: "Pending (${widget.indent.pending})"), */
                  ],
                ),
              ],
            ),
          ),
        ),
        body: Stack(children: [
          Column(
            children: [
              Expanded(
                child: TabBarView(
                  children: [
                    dispatchedTab(),
                    receivedTab(),
                    pendingTab(),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Expanded Content (Above "Total" Row)
                    if (isExpanded)
                      Container(
                        height: MediaQuery.of(context).size.height * 0.3,
                        // Adjust height of expanded content as needed
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        decoration: BoxDecoration(
                          color: AppColor.accordionColor,
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(15.w),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (widget.indent.invoiceNo != "")
                              InkWell(
                                onTap: () async {
                                  PleaseWaitLoader.openDialog();
                                  bool isDownloaded =
                                      await materialController.invoiceDownload(
                                          invoiceNo: widget
                                              .indent.branchMaterialIndentId,
                                          fileName: widget.indentNumber);
                                  if (isDownloaded) {
                                    Fluttertoast.showToast(
                                      msg:
                                          "Your invoice has been downloaded successfully.",
                                      backgroundColor: AppColor.primaryColor,
                                      textColor: AppColor.whiteColor,
                                      fontSize: AppFontSize.size3.sp,
                                    );
                                  } else {
                                    Fluttertoast.showToast(
                                      msg:
                                          "We couldn't download your invoice. Please try again.",
                                      backgroundColor: AppColor.redShade200,
                                      textColor: AppColor.blackColor,
                                      fontSize: AppFontSize.size3.sp,
                                    );
                                  }
                                  PleaseWaitLoader.closeDialog();
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CustomText(
                                        text: "Download Invoice",
                                        fontSize: AppFontSize.size3,
                                        color: AppColor.primaryColor,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      Image.asset(
                                        AssetPath.downloadInvoice,
                                        scale: 1.0,
                                        color: AppColor.secondaryColor,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            Expanded(
                              child: ListView.builder(
                                itemCount: widget.paymentDetails.length,
                                padding:
                                    const EdgeInsets.symmetric(vertical: 20),
                                itemBuilder: (context, index) {
                                  final paymentDetail = widget.paymentDetails;

                                  return Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            flex: 4,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomText(
                                                  text: paymentDetail[index]
                                                      .payMode,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: AppFontSize.size4,
                                                  color: AppColor.blackColor,
                                                ),
                                                SizedBox(height: 2.w),
                                                CustomText(
                                                  text: paymentDetail[index]
                                                      .transactionDate
                                                      .split(' ')[0],
                                                  // Replace with actual date if available in `paymentDetail`
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: AppFontSize.size5,
                                                  color: AppColor.black2Color,
                                                  maxLines: 2,
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomText(
                                                  text: paymentDetail[index]
                                                      .summary
                                                      .trimLeft(),
                                                  fontSize: AppFontSize.size4,
                                                  color: AppColor.black2Color,
                                                  maxLines: 3,
                                                ),
                                                if (widget.indent.invoiceNo
                                                        .isNotEmpty &&
                                                    paymentDetail[index]
                                                            .payMode
                                                            .toLowerCase() ==
                                                        "cash")
                                                  CustomText(
                                                    text:
                                                        "INV-${widget.indent.invoiceNo}",
                                                    fontSize: AppFontSize.size4,
                                                    color: AppColor.black2Color,
                                                    maxLines: 2,
                                                  ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 3,
                                            child: Column(
                                              children: [
                                                CustomText(
                                                  text: currencyFormat.format(
                                                      paymentDetail[index]
                                                          .amount),
                                                  fontSize: AppFontSize.size4,
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      const Divider(),
                                    ],
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),

                    // Total Row (Always Fixed at the Bottom)
                    Container(
                      color: AppColor.accordionColor,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            isExpanded = !isExpanded;
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CustomText(
                                text: "Total",
                                fontSize: AppFontSize.size4,
                                fontWeight: FontWeight.w500,
                              ),
                              Row(
                                children: [
                                  CustomText(
                                    text: currencyFormat
                                        .format(_calculateTotalAmount()),
                                    fontSize: AppFontSize.size4,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  Icon(
                                    isExpanded
                                        ? Icons.keyboard_arrow_down
                                        : Icons.keyboard_arrow_up,
                                    color: Colors.orange,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ]),

        // Accordion at the Bottom

        floatingActionButton: GestureDetector(
          onTap: () {
            setState(() {
              _selectedIndex = 2; // Select the Home tab
            });
            Get.to(const DashboardScreen());
          },
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer Circle
              Container(
                width: 72,
                height: 72,
                decoration: const BoxDecoration(
                  color: Color(0xFFCCE6FF), // Lighter blue
                  shape: BoxShape.circle,
                ),
              ),
              // Inner Circle
              Container(
                width: 56,
                height: 56,
                decoration: const BoxDecoration(
                  color: AppColor.primaryColor, // Darker blue
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.home,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ],
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: CustomBottomNavigationBar(
          selectedIndex: _selectedIndex,
          onItemSelected: (int index) {
            setState(() {
              _selectedIndex = index;
            });
          },
        ),
      ),
    );
  }

  // Calculate total amount from paymentDetails
  double _calculateTotalAmount() {
    return widget.paymentDetails
        .fold(0.0, (sum, detail) => sum + (detail.amount));
  }

  // chekc is empty, then return NA
  String checkEmptyWithNA(String checkString) {
    if (checkString.isEmpty) return "NA";
    return checkString;
  }

  Widget dispatchedTab() {
    return dispatchedGroups.isEmpty
        ? Center(
            child: Text(
              "No Data Available",
              style: TextStyle(
                fontSize: AppFontSize.size4,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
              ),
            ),
          )
        : Column(
            children: [
              SizedBox(
                height: 20.w,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: dispatchedGroups.length,
                  itemBuilder: (context, groupIndex) {
                    final group = dispatchedGroups[groupIndex];
                    return Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.w),
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 10.w, vertical: 15.w),
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(15.r),
                              color: AppColor.grey3,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomText(
                                        text:
                                            "Tracking ID: ${checkEmptyWithNA(group['trackingID'])}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size5,
                                        color: AppColor.blackColor,
                                      ),
                                      CustomText(
                                        text:
                                            "Dispatched : ${checkEmptyWithNA(group['dispatchedDate'])}",
                                        // text: "Delivery Partner: ${group['deliveryPartner']}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size5,
                                        color: AppColor.blackColor,
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      CustomText(
                                        text:
                                            "Delivery Partner: ${checkEmptyWithNA(group['deliveryPartner'])}",
                                        fontWeight: FontWeight.w500,
                                        fontSize: AppFontSize.size5,
                                        color: AppColor.blackColor,
                                      ),
                                      SizedBox(
                                        height: 20.w,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            children: (group["items"]
                                    as List<Map<String, dynamic>>)
                                .map((item) => Container(
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(15.r)),
                                      child: Column(
                                        children: [
                                          CheckboxListTile(
                                            contentPadding: EdgeInsets.zero,
                                            value: item["isSelected"],
                                            onChanged: (value) {
                                              setState(() {
                                                item["isSelected"] =
                                                    value ?? false;
                                                if (item["isSelected"]) {
                                                  selectedMaterials.add(
                                                    {
                                                      "materialIndentTransId": item[
                                                          "materialIndentTransId"],
                                                    },
                                                  );
                                                } else {
                                                  selectedMaterials.removeWhere(
                                                      (element) =>
                                                          element[
                                                              "materialIndentTransId"] ==
                                                          item[
                                                              "materialIndentTransId"]);
                                                }
                                                debugPrint(selectedMaterials
                                                    .toString());
                                              });
                                            },
                                            controlAffinity:
                                                ListTileControlAffinity.leading,
                                            // Ensures checkbox is on the left
                                            title: Column(children: [
                                              Row(
                                                children: [
                                                  // Checkbox(
                                                  //   value: item["isSelected"],
                                                  //   onChanged: (value) {
                                                  //     setState(() {
                                                  //       item["isSelected"] = value!;
                                                  //     });
                                                  //   },
                                                  // ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      CustomText(
                                                        text: item[
                                                            "materialName"],
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize:
                                                            AppFontSize.size4,
                                                        color: AppColor
                                                            .primaryColor,
                                                      ),
                                                      CustomText(
                                                        text: item[
                                                            "materialType"],
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize:
                                                            AppFontSize.size4,
                                                        color: AppColor
                                                            .black2Color,
                                                      ),
                                                    ],
                                                  ),
                                                  const Spacer(),
                                                  // Creates space between item details and quantity

                                                  CustomText(
                                                    text:
                                                        "${item['quantity']} Quantity",
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: AppFontSize.size4,
                                                    color: AppColor.black2Color,
                                                  ),
                                                ],
                                              ),
                                            ]),
                                          ),
                                          const Divider(
                                            color: AppColor.greyColor,
                                            thickness: 1.5,
                                          )
                                        ],
                                      ),
                                    ))
                                .toList(),
                          )
                        ],
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding:
                    EdgeInsets.symmetric(horizontal: 130.w, vertical: 50.w),
                child: InButton(
                  color: AppColor.primaryColor,
                  onTap: _moveToReceived,
                  text: "Receive",
                  textColor: AppColor.whiteColor,
                  withArrow: false,
                  textSize: AppFontSize.size4,
                ),
              ),
            ],
          );
  }

  Widget receivedTab() {
    return receivedGroups.isEmpty
        ? Center(
            child: Text(
              "No Data Available",
              style: TextStyle(
                fontSize: AppFontSize.size4,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
              ),
            ),
          )
        : ListView(
            children: _buildGroupList(receivedGroups),
          );
  }

  Widget pendingTab() {
    return pendingGroups.isEmpty
        ? Center(
            child: Text(
              "No Data Available",
              style: TextStyle(
                fontSize: AppFontSize.size4,
                fontWeight: FontWeight.w500,
                color: AppColor.primaryColor,
              ),
            ),
          )
        : ListView(
            children: _buildGroupList(pendingGroups),
          );
  }

/*
  Widget receivedTab() {
    return ListView(
      children: _buildGroupList(widget.receivedGroups),
    );
  }

  Widget pendingTab() {
    return ListView(
      children: _buildGroupList(widget.pendingGroups),
    );
  }*/

  List<Widget> _buildGroupList(List<Map<String, dynamic>> groups) {
    return groups.map((group) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.w),
        child: Column(
          children: [
            Column(
              children: (group["items"] as List<Map<String, dynamic>>)
                  .map(
                    (item) => Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15.r)),
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 10.w, vertical: 5.w),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomText(
                                      text: item["materialName"],
                                      fontWeight: FontWeight.w500,
                                      fontSize: AppFontSize.size4,
                                      color: AppColor.primaryColor,
                                    ),
                                    CustomText(
                                      text: item["materialType"],
                                      fontWeight: FontWeight.w500,
                                      fontSize: AppFontSize.size4,
                                      color: AppColor.black2Color,
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                // Creates space between item details and quantity

                                CustomText(
                                  text: "${item['quantity']} Quantity",
                                  fontWeight: FontWeight.w500,
                                  fontSize: AppFontSize.size4,
                                  color: AppColor.black2Color,
                                ),
                              ],
                            ),
                            const Divider(
                              color: AppColor.greyColor,
                              thickness: 1.5,
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      );
    }).toList();
  }

  // int _calculateTotalQuantity(List<Map<String, dynamic>> groups) {
  //   int totalCount = 0;

  //   for (var group in groups) {
  //     totalCount += group["items"].length as int;
  //   }

  //   return totalCount;
  // }

  //to receive the materials in ui

  /*Future<void> _moveToReceived() async {
    setState(() {
      dispatchedGroups = dispatchedGroups
          .map((group) {
        final selectedItems = (group["items"] as List<Map<String, dynamic>>).where((item) => item["isSelected"] as bool).toList();
        if (selectedItems.isNotEmpty) {
          receivedGroups.add({
            "trackingID": group["trackingID"],
            "deliveryPartner": group["deliveryPartner"],
            "dispatchedDate": group["dispatchedDate"],
            "items": selectedItems,
            "materialIndent": selectedItems
                .map((item) =>
            {
              "materialIndentTransID": item["materialIndentTransID"]
            })
                .toList(),
          });
        }
        return {
          ...group,
          "items": (group["items"] as List<Map<String, dynamic>>).where((item) => !(item["isSelected"] as bool)).toList(),
        };
      })
          .where((group) => (group["items"] as List).isNotEmpty)
          .toList();
    });

    List<Map<String, dynamic>> materialIndent = receivedGroups
        .expand((group) => (group["materialIndent"] as List<Map<String, dynamic>>)) // Cast to List<Map<String, dynamic>>
        .toList();

    if (materialIndent.isNotEmpty) {
      var body = {
        "materialIndent": materialIndent,
      };

      // Calling the API to send the materialIndent data
      bool apiResult = await materialController.getReceivedMaterial(body: body);

      if (apiResult) {
        // Handle successful API response
        debugPrint("Material received successfully");
      } else {
        // Handle failure
        debugPrint("Failed to receive material");
      }
    }
  }*/

  void _moveToReceived() async {
    // Proceed if there are selected materials
    if (selectedMaterials.isNotEmpty) {
      // Prepare the data for the API call
      var body = {
        "materialIndent": selectedMaterials.map((item) {
          return {
            "materialIndentTransID": item["materialIndentTransId"],
          };
        }).toList(),
      };

      // Debugging: Print the data being sent to the API
      debugPrint("Sending materialIndent data: $body");

      // Call the API to move materials to received
      bool apiResult =
          await materialController.submitToReceivedMaterial(body: body);

      if (apiResult) {
        setState(() {
          // Update the dispatchedGroups to move selected items to received
          dispatchedGroups = dispatchedGroups
              .map((group) {
                final selectedItems =
                    (group["items"] as List<Map<String, dynamic>>)
                        .where((item) => item["isSelected"] as bool)
                        .toList();

                if (selectedItems.isNotEmpty) {
                  receivedGroups.add({
                    "trackingID": group["trackingID"],
                    "deliveryPartner": group["deliveryPartner"],
                    "dispatchedDate": group["dispatchedDate"],
                    "items": selectedItems,
                  });
                }

                // Update dispatchedGroups by removing selected items
                return {
                  ...group,
                  "items": (group["items"] as List<Map<String, dynamic>>)
                      .where((item) => !(item["isSelected"] as bool))
                      .toList(),
                };
              })
              .where((group) => (group["items"] as List).isNotEmpty)
              .toList();
        });

        // After successful API call and updating the groups, show a success message
        debugPrint("Materials received and updated.");
        Get.back();
        bool trackingApiResult = await materialController.getMaterialTracking(
          body: {"Status": widget.selectedStatus},
        );
        if (trackingApiResult) {
          debugPrint("Material tracking data refreshed successfully.");
        } else {
          debugPrint("Failed to refresh material tracking data.");
        }
      } else {
        // Handle API failure (e.g., show a failure message)
        debugPrint("Failed to update received materials.");
      }
    } else {
      // No items selected, show a message
      debugPrint("No items selected to move to received.");
    }
  }
}
