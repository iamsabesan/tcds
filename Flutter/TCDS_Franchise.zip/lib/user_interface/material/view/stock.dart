import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/material/controller/material_indent_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import '../../../constants/asset_paths.dart';
import '../../../utils/helper_widgets/horiz_asset_text.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';
import 'hq_stock_list.dart';
import 'stock_list.dart';

class AllStocks extends StatefulWidget {
  const AllStocks({super.key});

  @override
  State<AllStocks> createState() => AllStocksState();
}

class AllStocksState extends State<AllStocks> {
  MaterialIndentController materialController =
      Get.put(MaterialIndentController());

  int _selectedIndex = 7;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool withBackArrow = false;
  @override
  void initState() {
    super.initState();
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 5,
        ),
      ),
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        toolbarHeight: 70,
        titleSpacing: 0,
        title: CustomText(
          text: "Stock List - Material",
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
      ),
      body: PopScopeHandler(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppColor.greyColor,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(8.r),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: () => Get.to(() => const HqStockList(),
                        transition: Transition.rightToLeft,
                        duration: const Duration(milliseconds: 600)),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: HorizAssetText(
                              assetPath: AssetPath.hqStock,
                              assetScale: 25.0,
                              valueText: "Head Office Stocks",
                              valueTextColor: AppColor.blackColor,
                              valueFontSize: AppFontSize.size2.sp,
                              valueFontWeight: FontWeight.w500,
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: AppColor.blackColor,
                            size: 18.0,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Divider(
                    thickness: 1.5,
                    height: 0,
                    color: AppColor.greyColor,
                  ),
                  InkWell(
                    onTap: () => Get.to(() => const StockListScreen(),
                        transition: Transition.rightToLeft,
                        duration: const Duration(milliseconds: 600)),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          Expanded(
                            child: HorizAssetText(
                              assetPath: AssetPath.centreStock,
                              assetScale: 25.0,
                              valueText: "My Centre Stocks",
                              valueTextColor: AppColor.blackColor,
                              valueFontSize: AppFontSize.size2.sp,
                              valueFontWeight: FontWeight.w500,
                            ),
                          ),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: AppColor.blackColor,
                            size: 18.w,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }
}
