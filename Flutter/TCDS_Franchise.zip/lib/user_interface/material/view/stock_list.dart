import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/material/controller/material_indent_controller.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_widget_one.dart';
import '../../../utils/helper_widgets/single_dropdown.dart';

class StockListScreen extends StatefulWidget {
  const StockListScreen({super.key});

  @override
  State<StockListScreen> createState() => _StockListScreenState();
}

class _StockListScreenState extends State<StockListScreen> {
  MaterialIndentController materialController =
      Get.find<MaterialIndentController>();

  NumberFormat rsFormat =
      NumberFormat.currency(locale: 'hi_IN', symbol: 'Rs.', decimalDigits: 0);

  TextEditingController filterIDTxtCtrl = TextEditingController();
  TextEditingController filterTxtCtrl = TextEditingController();
  late List<String> filterKeys;

  Future<void> getApiCall() async {
    await materialController.getStockList();
    filterKeys = materialController.filterKeys;
    if (filterKeys.isNotEmpty) {
      String firstKey = filterKeys.first;
      filterIDTxtCtrl.text = firstKey.toLowerCase();
      filterTxtCtrl.text = firstKey;

      // Set initial filtered stocks
      materialController.localFilteredStocks.value =
          materialController.localMaterialWiseStocks[firstKey] ?? [];
    }
  }

  @override
  void initState() {
    getApiCall();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();

    materialController.filterKeys.clear();
    materialController.localStockList.clear();
    materialController.localMaterialWiseStocks.clear();
    materialController.localFilteredStocks.clear();
    debugPrint("HQ Widget Disposed");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 5,
        ),
      ),
      appBar: AppBar(
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        backgroundColor: AppColor.whiteColor,
        toolbarHeight: 70,
        titleSpacing: 0,
        title: CustomText(
          text: "My Centre Stocks",
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Obx(() {
        return materialController.stockListScreenLoader.value
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColor.primaryColor,
                ),
              )
            : RefreshIndicator(
                onRefresh: () async {
                  // Save current selection before refresh
                  String currentSelection = filterTxtCtrl.text;

                  await materialController.getStockList();

                  // Restore the selection after refresh
                  filterKeys = materialController.filterKeys;
                  if (filterKeys.isNotEmpty) {
                    // Check if the previous selection still exists
                    if (filterKeys.contains(currentSelection)) {
                      filterTxtCtrl.text = currentSelection;
                      filterIDTxtCtrl.text = currentSelection.toLowerCase();
                      materialController.localFilteredStocks.value =
                          materialController
                                  .localMaterialWiseStocks[currentSelection] ??
                              [];
                    } else {
                      // Fall back to first item if previous selection doesn't exist
                      String firstKey = filterKeys.first;
                      filterTxtCtrl.text = firstKey;
                      filterIDTxtCtrl.text = firstKey.toLowerCase();
                      materialController.localFilteredStocks.value =
                          materialController
                                  .localMaterialWiseStocks[firstKey] ??
                              [];
                    }
                  }
                },
                child: Column(
                  children: [
                    SizedBox(
                      height: 30.w,
                    ),
                    // filter dropdown
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: SingleSelectDropDown(
                        labelText: "Material Type",
                        valueController: filterIDTxtCtrl,
                        valueTextController: filterTxtCtrl,
                        data: List.generate(
                          filterKeys.length,
                          (index) {
                            return SingleSelectDropDownModel(filterKeys[index],
                                filterKeys[index].toLowerCase());
                          },
                        ),
                        parentOnChangeCall: (value) {
                          if (value != null) {
                            debugPrint("=== FILTER CHANGE EVENT ===");
                            debugPrint("Selected value: ${value.value}");
                            debugPrint(
                                "Current text before: ${filterTxtCtrl.text}");
                            debugPrint(
                                "Available material types: ${materialController.localMaterialWiseStocks.keys.toList()}");

                            // The dropdown component automatically updates the text controllers
                            // So we can directly use value.value for filtering

                            var filteredItems = materialController
                                    .localMaterialWiseStocks[value.value] ??
                                [];

                            debugPrint(
                                "Found ${filteredItems.length} items for ${value.value}");
                            materialController.localFilteredStocks.value =
                                filteredItems;

                            debugPrint(
                                "Updated filtered stocks: ${materialController.localFilteredStocks.length} items");
                            for (var stock
                                in materialController.localFilteredStocks) {
                              debugPrint(
                                  "  - ${stock.materialName} (${stock.materialType})");
                            }
                          }
                        },
                      ),
                    ),

                    // list data
                    if (materialController.localFilteredStocks.isNotEmpty)
                      Expanded(
                        child: ListView.builder(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15.w, vertical: 15.w),
                            itemCount:
                                materialController.localFilteredStocks.length,
                            itemBuilder: (BuildContext context, int index) {
                              return CustomWidgetOne(
                                orderNumber: index + 1,
                                amount: rsFormat.format(materialController
                                    .localFilteredStocks[index].price),
                                courseName: materialController
                                    .localFilteredStocks[index].materialName,
                                keyText1: materialController
                                    .localFilteredStocks[index].currentStock
                                    .toString(),
                                // keyText2: "Type",
                                valueText1: "Nos.",
                                // valueText2: materialController
                                //     .localFilteredStocks[index].materialType,
                                withDivider: true,
                                withForwardArrow: false,
                                withKeyText2: false,
                              );
                            }),
                      ),
                    if (materialController.localFilteredStocks.isEmpty)
                      const Expanded(
                          child: Center(
                        child: CustomText(
                          text: "No Data",
                          color: AppColor.blackColor,
                        ),
                      )),
                  ],
                ),
              );
      }),
    );
  }
}
