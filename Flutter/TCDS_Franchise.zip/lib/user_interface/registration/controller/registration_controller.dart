import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/registration/model/bank_account_type_model.dart';
import 'package:tcds/user_interface/registration/model/bank_name_model.dart';
import 'package:tcds/user_interface/registration/model/country_model.dart';
import 'package:tcds/user_interface/registration/model/district_model.dart';
import 'package:tcds/user_interface/registration/model/document_upload.dart';
import 'package:tcds/user_interface/registration/model/gender_types.dart';
import 'package:tcds/user_interface/registration/model/phone_code_response_model.dart';
import 'package:tcds/user_interface/registration/model/request_otp_response_model.dart';
import 'package:tcds/user_interface/registration/model/state_model.dart';

import '../../../constants/shared_preference.dart';
import '../model/franchise_registration_model.dart';

class RegistrationController extends GetxController {
// engine instance
  HttpEngine engine = HttpEngine();

  RequestOTPData? requestOTPResponse;
  RxList<RequestOTPData> requestedOTP = <RequestOTPData>[].obs;
  var isDistrictVisible = false.obs;

  RxList<PhoneCodeList> phoneCodesData = <PhoneCodeList>[].obs;
  RxList<CountryList> countryList = <CountryList>[].obs;
  RxList<DistrictList> districtList = <DistrictList>[].obs;
  RxList<StateList> stateList = <StateList>[].obs;
  RxList<GenderTypeData> genderTypesList = <GenderTypeData>[].obs;
  RxList<String> accountList = <String>[].obs;
  RxList<BankNameList> bankNameList = <BankNameList>[].obs;
  RxList<String> accountTypeList = <String>[].obs;
  // RxList<String> lat = <String>[].obs;
  // RxList<String> long = <String>[].obs;
  RxString lat = "".obs;  // Declare observable lat variable
  RxString long = "".obs;  // Declare observable long variable

  RxList<DocumentUploadData> latestUploadedDocument = <DocumentUploadData>[].obs;

  // get gender types
  Future<bool> getGenderTypes() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.getGenderTypes, protected: true).then((value) {
        debugPrint(value.toString());
        GenderTypesResponseModel model = GenderTypesResponseModel.fromJson(value.data);
        genderTypesList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // Get Phone Codes
  Future<bool> getPhoneCodes() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.phoneCodeUrl, protected: true).then((value) {
        debugPrint(value.toString());
        PhoneCodeResponseModel model = PhoneCodeResponseModel.fromJson(value.data);
        phoneCodesData.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get accountType
  Future<bool> getBankAccountType() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.getAccountType, protected: true).then((value) {
        debugPrint(value.toString());
        BankAccTypeResponseModel model = BankAccTypeResponseModel.fromJson(value.data);
        accountTypeList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // get BankName
  Future<bool> getBankName() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.getBankName, protected: true).then((value) {
        debugPrint(value.toString());
        BankNameResponseModel model = BankNameResponseModel.fromJson(value.data);
        bankNameList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // get country list
  Future<bool> getCountryList() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.countryListUrl, protected: true).then((value) {
        debugPrint(value.toString());
        CountryResponseModel model = CountryResponseModel.fromJson(value.data);
        countryList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get state list
  Future<bool> getStateList({required String countryId}) async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.stateListUrl + countryId, protected: true).then((value) {
        debugPrint(value.toString());
        StateResponseModel model = StateResponseModel.fromJson(value.data);
        stateList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get district list
  Future<bool> getDistrictList({required String stateId}) async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.districtListUrl + stateId, protected: true).then((value) {
        debugPrint(value.toString());
        DistrictResponseModel model = DistrictResponseModel.fromJson(value.data);
        districtList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // Request OTP
  Future<bool> requestOTP({required body}) async {
    bool resultValue = false;
    try {
      await engine.post(AppStrings.baseUrl + AppStrings.requestOtp, body, protected: true).then((value) {
        debugPrint(value.toString());
        RequestOtpResponseModel model = RequestOtpResponseModel.fromJson(value.data);
        requestOTPResponse = model.data;
        requestedOTP.clear();
        requestedOTP.add(model.data);
        debugPrint('Request OTP otpTransId ${requestOTPResponse!.emailOtpTransId}');
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // Verify OTP
  Future<bool> verifyOTP({required body}) async {
    bool resultValue = false;
    try {
      await engine.post(AppStrings.baseUrl + AppStrings.verifyOTP, body, protected: true).then((value) {
        debugPrint(value.toString());
        if(value.data["Code"]==400) {
          resultValue = false;
        }else{
          resultValue = true;
        }
      });
    } catch (e) {
      resultValue = false;
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // get gender types
  Future<bool> getAccountType() async {
    bool resultValue = false;
    try {
      await engine.get(AppStrings.baseUrl + AppStrings.getAccountType, protected: true).then((value) {
        debugPrint(value.toString());
        BankAccTypeResponseModel model = BankAccTypeResponseModel.fromJson(value.data);
        accountList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }




  // resend OTP
  Future<bool> resendOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.otpResend, body,
          protected: true)
          .then((value) {
        debugPrint(value.toString());
        RequestOtpResponseModel model = RequestOtpResponseModel.fromJson(value.data);
        requestOTPResponse = model.data;
        requestedOTP.add(model.data);
        debugPrint('Request OTP otpTransId ${requestOTPResponse!.emailOtpTransId}');
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (resendOTP) => $e");
    }

    return result;
  }

  Future<bool> registerFranchise({
    required dynamic formData,
  })
  async {
    bool resultValue = false;
    debugPrint(formData.runtimeType.toString());
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.registerFranchise, formData,
          custom: "multipart/form-data", protected: true)
          .then((value) {
        debugPrint('Profile Updated Successfully');
        FranchiseRegistrationModel model =
        FranchiseRegistrationModel.fromJson(value.data);
        SharedPreference.putString(AppStrings.franchiseeRequestID, model.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
