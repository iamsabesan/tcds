// To parse this JSON data, do
//
//     final bankAccTypeResponseModel = bankAccTypeResponseModelFromJson(jsonString);

import 'dart:convert';

BankAccTypeResponseModel bankAccTypeResponseModelFromJson(String str) => BankAccTypeResponseModel.fromJson(json.decode(str));

String bankAccTypeResponseModelToJson(BankAccTypeResponseModel data) => json.encode(data.toJson());

class BankAccTypeResponseModel {
  int code;
  String message;
  List<String> data;

  BankAccTypeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory BankAccTypeResponseModel.fromJson(Map<String, dynamic> json) => BankAccTypeResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<String>.from(json["Data"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x)),
  };
}
