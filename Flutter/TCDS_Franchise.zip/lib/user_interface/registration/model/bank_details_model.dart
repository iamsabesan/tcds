class BankDetails {
  String accountType;
  String accountName;
  String accountNumber;
  String bank;
  String ifsc;
  String description;
  String branchName;

  BankDetails({
    required this.accountType,
    required this.accountName,
    required this.accountNumber,
    required this.bank,
    required this.ifsc,
    required this.description,
    required this.branchName,
  });

  factory BankDetails.fromJson(Map<String, dynamic> json) => BankDetails(
    accountType: json["accountType"],
    accountName: json["accountName"],
    accountNumber: json["accountNumber"],
    bank: json["bank"],
    ifsc: json["ifsc"],
    description: json["description"],
    branchName: json["branchName"],
  );

  Map<String, dynamic> toJson() => {
    "accountType": accountType,
    "accountName": accountName,
    "accountNumber": accountNumber,
    "bank": bank,
    "ifsc": ifsc,
    "description": description,
    "branchName": branchName,
  };
}