// To parse this JSON data, do
//
//     final bankNameResponseModel = bankNameResponseModelFromJson(jsonString);

import 'dart:convert';

BankNameResponseModel bankNameResponseModelFromJson(String str) => BankNameResponseModel.fromJson(json.decode(str));

String bankNameResponseModelToJson(BankNameResponseModel data) => json.encode(data.toJson());

class BankNameResponseModel {
  int code;
  String message;
  List<BankNameList> data;

  BankNameResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory BankNameResponseModel.fromJson(Map<String, dynamic> json) => BankNameResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<BankNameList>.from(json["Data"].map((x) => BankNameList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class BankNameList {
  int slNo;
  String bankId;
  String bankName;

  BankNameList({
    required this.slNo,
    required this.bankId,
    required this.bankName,
  });

  factory BankNameList.fromJson(Map<String, dynamic> json) => BankNameList(
    slNo: json["SlNo"],
    bankId: json["BankID"],
    bankName: json["BankName"],
  );

  Map<String, dynamic> toJson() => {
    "SlNo": slNo,
    "BankID": bankId,
    "BankName": bankName,
  };
}
