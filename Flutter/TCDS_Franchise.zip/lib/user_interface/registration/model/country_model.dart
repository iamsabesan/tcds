// To parse this JSON data, do
//
//     final countryResponseModel = countryResponseModelFromJson(jsonString);

import 'dart:convert';

CountryResponseModel countryResponseModelFromJson(String str) => CountryResponseModel.fromJson(json.decode(str));

String countryResponseModelToJson(CountryResponseModel data) => json.encode(data.toJson());

class CountryResponseModel {
  int code;
  String message;
  List<CountryList> data;

  CountryResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CountryResponseModel.fromJson(Map<String, dynamic> json) => CountryResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CountryList>.from(json["Data"].map((x) => CountryList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CountryList {
  int countryId;
  String countryName;

  CountryList({
    required this.countryId,
    required this.countryName,
  });

  factory CountryList.fromJson(Map<String, dynamic> json) => CountryList(
    countryId: json["CountryID"],
    countryName: json["CountryName"],
  );

  Map<String, dynamic> toJson() => {
    "CountryID": countryId,
    "CountryName": countryName,
  };
}
