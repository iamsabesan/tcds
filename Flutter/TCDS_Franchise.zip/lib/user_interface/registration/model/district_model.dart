// To parse this JSON data, do
//
//     final districtResponseModel = districtResponseModelFromJson(jsonString);

import 'dart:convert';

DistrictResponseModel districtResponseModelFromJson(String str) => DistrictResponseModel.fromJson(json.decode(str));

String districtResponseModelToJson(DistrictResponseModel data) => json.encode(data.toJson());

class DistrictResponseModel {
  int code;
  String message;
  List<DistrictList> data;

  DistrictResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DistrictResponseModel.fromJson(Map<String, dynamic> json) => DistrictResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<DistrictList>.from(json["Data"].map((x) => DistrictList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class DistrictList {
  int districtId;
  String districtName;

  DistrictList({
    required this.districtId,
    required this.districtName,
  });

  factory DistrictList.fromJson(Map<String, dynamic> json) => DistrictList(
    districtId: json["DistrictID"],
    districtName: json["DistrictName"],
  );

  Map<String, dynamic> toJson() => {
    "DistrictID": districtId,
    "DistrictName": districtName,
  };
}
