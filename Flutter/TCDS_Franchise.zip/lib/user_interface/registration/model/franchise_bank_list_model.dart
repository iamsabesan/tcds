// To parse this JSON data, do
//
//     final franchiseBankListModel = franchiseBankListModelFromJson(jsonString);

import 'dart:convert';

FranchiseBankListModel franchiseBankListModelFromJson(String str) => FranchiseBankListModel.fromJson(json.decode(str));

String franchiseBankListModelToJson(FranchiseBankListModel data) => json.encode(data.toJson());

class FranchiseBankListModel {
  int code;
  String message;
  List<FranchiseBank> data;

  FranchiseBankListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseBankListModel.fromJson(Map<String, dynamic> json) => FranchiseBankListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<FranchiseBank>.from(json["Data"].map((x) => FranchiseBank.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class FranchiseBank {
  String accountId;
  String accountType;
  String accountName;
  String accountNumber;
  String bank;
  String ifsc;
  String branchName;
  String notes;

  FranchiseBank({
    required this.accountId,
    required this.accountType,
    required this.accountName,
    required this.accountNumber,
    required this.bank,
    required this.ifsc,
    required this.branchName,
    required this.notes,
  });

  factory FranchiseBank.fromJson(Map<String, dynamic> json) => FranchiseBank(
    accountId: json["AccountID"],
    accountType: json["AccountType"],
    accountName: json["AccountName"],
    accountNumber: json["AccountNumber"],
    bank: json["Bank"],
    ifsc: json["IFSC"],
    branchName: json["BranchName"],
    notes: json["Notes"],
  );

  Map<String, dynamic> toJson() => {
    "AccountID": accountId,
    "AccountType": accountType,
    "AccountName": accountName,
    "AccountNumber": accountNumber,
    "Bank": bank,
    "IFSC": ifsc,
    "BranchName": branchName,
    "Notes": notes,
  };
}
