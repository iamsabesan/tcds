// To parse this JSON data, do
//
//     final franchiseRegistrationModel = franchiseRegistrationModelFromJson(jsonString);

import 'dart:convert';

FranchiseRegistrationModel franchiseRegistrationModelFromJson(String str) => FranchiseRegistrationModel.fromJson(json.decode(str));

String franchiseRegistrationModelToJson(FranchiseRegistrationModel data) => json.encode(data.toJson());

class FranchiseRegistrationModel {
  int code;
  String message;
  String data;

  FranchiseRegistrationModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseRegistrationModel.fromJson(Map<String, dynamic> json) => FranchiseRegistrationModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
