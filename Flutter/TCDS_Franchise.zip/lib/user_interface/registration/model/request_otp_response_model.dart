// To parse this JSON data, do
//
//     final requestOtpResponseModel = requestOtpResponseModelFromJson(jsonString);

import 'dart:convert';

RequestOtpResponseModel requestOtpResponseModelFromJson(String str) =>
    RequestOtpResponseModel.fromJson(json.decode(str));

String requestOtpResponseModelToJson(RequestOtpResponseModel data) =>
    json.encode(data.toJson());

class RequestOtpResponseModel {
  int code;
  String message;
  RequestOTPData data;

  RequestOtpResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RequestOtpResponseModel.fromJson(Map<String, dynamic> json) =>
      RequestOtpResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: RequestOTPData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class RequestOTPData {
  String emailOtpTransId;
  int emailValidityTime;

  RequestOTPData({
    required this.emailOtpTransId,
    required this.emailValidityTime,
  });

  factory RequestOTPData.fromJson(Map<String, dynamic> json) => RequestOTPData(
        emailOtpTransId: json["OTPTransID"],
        emailValidityTime: json["ValidityTime"],
      );

  Map<String, dynamic> toJson() => {
        "EmailOTPTransID": emailOtpTransId,
        "EmailValidityTime": emailValidityTime,
      };
}
