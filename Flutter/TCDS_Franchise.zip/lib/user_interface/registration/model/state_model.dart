
import 'dart:convert';

StateResponseModel stateResponseModelFromJson(String str) => StateResponseModel.fromJson(json.decode(str));

String stateResponseModelToJson(StateResponseModel data) => json.encode(data.toJson());

class StateResponseModel {
  int code;
  String message;
  List<StateList> data;

  StateResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StateResponseModel.fromJson(Map<String, dynamic> json) => StateResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<StateList>.from(json["Data"].map((x) => StateList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class StateList {
  int stateProvinceId;
  String stateProvinceName;

  StateList({
    required this.stateProvinceId,
    required this.stateProvinceName,
  });

  factory StateList.fromJson(Map<String, dynamic> json) => StateList(
    stateProvinceId: json["StateProvinceID"],
    stateProvinceName: json["StateProvinceName"],
  );

  Map<String, dynamic> toJson() => {
    "StateProvinceID": stateProvinceId,
    "StateProvinceName": stateProvinceName,
  };
}
