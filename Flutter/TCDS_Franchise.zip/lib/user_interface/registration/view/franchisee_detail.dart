import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:get/get_utils/get_utils.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/registration/model/country_model.dart';
import 'package:tcds/user_interface/registration/model/state_model.dart';
import 'package:tcds/user_interface/registration/view/location_screen.dart';
import 'package:tcds/utils/helper_widgets/bottom_sheets.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/grey_box.dart';
import 'package:tcds/utils/helper_widgets/info_pop_up_widget.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import 'package:tcds/utils/helper_widgets/uploading_file_widget.dart';

import '../../../utils/helper_functions/formatters.dart';

class FranchiseeDetailsForm extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  // final TextEditingController franchiseeName;
  // final TextEditingController franchiseeAddress;
  // final TextEditingController actHolderName;
  // final TextEditingController bankName;
  // final TextEditingController actNum;
  // final TextEditingController branch;
  // final TextEditingController notes;

  const FranchiseeDetailsForm({
    super.key,
    required this.formKey,
    // required this.franchiseeName,
    // required this.franchiseeAddress,
    // required this.actHolderName,
    // required this.bankName,
    // required this.actNum,
    // required this.branch,
    // required this.notes ,
  });

  @override
  State<FranchiseeDetailsForm> createState() => _FranchiseeDetailsFormState();
}

class _FranchiseeDetailsFormState extends State<FranchiseeDetailsForm> {
  RegistrationController registrationController =
      Get.find<RegistrationController>();

  // Controllers for input fields
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController address1Ctrl = TextEditingController();
  TextEditingController address2Ctrl = TextEditingController();
  TextEditingController talukCtrl = TextEditingController();
  TextEditingController areaCtrl = TextEditingController();
  TextEditingController countryCtrl = TextEditingController();
  TextEditingController countryTextCtrl = TextEditingController();
  TextEditingController stateCtrl = TextEditingController();
  TextEditingController stateTextCtrl = TextEditingController();
  TextEditingController districtCtrl = TextEditingController();
  TextEditingController districtTextCtrl = TextEditingController();
  TextEditingController pincodeCtrl = TextEditingController();
  TextEditingController pincodeTextCtrl = TextEditingController();
  TextEditingController accTypeCtrl = TextEditingController();
  TextEditingController accTypeTextCtrl = TextEditingController();
  TextEditingController accNumCtrl = TextEditingController();
  TextEditingController bankNameCtrl = TextEditingController();
  TextEditingController bankNameTextCtrl = TextEditingController();
  TextEditingController ifscCtrl = TextEditingController();
  TextEditingController branchCtrl = TextEditingController();
  TextEditingController accountHolderNameCtrl = TextEditingController();
  TextEditingController notesCtrl = TextEditingController();

  final ImagePicker picker = ImagePicker();

  List<File> buildingElevationImages = [];
  List<File> classRoomImages = [];
  List<File> laboratoryImages = [];

  // IFSC Code Validator
  String? validateIfscCode(String? value) {
    if (value == null || value.isEmpty) {
      return 'IFSC Code is required';
    }

    // IFSC code format: 11 characters (4 alphabets + 0 + 6 alphanumeric)
    // Pattern: First 4 characters are alphabets, 5th is 0, last 6 are alphanumeric
    final ifscPattern = RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$');

    if (!ifscPattern.hasMatch(value)) {
      return 'Invalid IFSC format. Use format: ABCD012345 (4 letters + 0 + 6 alphanumeric)';
    }

    return null;
  }

  // Function to pick images and check file size limit
  Future<void> pickImage(List<File> targetList) async {
    final pickedFiles = await showModalBottomSheet<List<XFile>>(
      context: context,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(
                Icons.camera_alt,
              ),
              title: CustomText(
                text: 'Take a picture',
                fontSize: AppFontSize.size4.sp,
              ),
              onTap: () async {
                try {
                  final cameraImage =
                      await picker.pickImage(source: ImageSource.camera);
                  Get.back(
                      result: cameraImage != null ? [cameraImage] : <XFile>[]);
                } catch (e) {
                  debugPrint("Error taking picture: $e");
                }
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.photo_library,
              ),
              title: CustomText(
                text: 'Choose from gallery',
                fontSize: AppFontSize.size4.sp,
              ),
              onTap: () async {
                try {
                  Get.back(result: await picker.pickMultiImage());
                } catch (e) {
                  debugPrint("Error while choose: $e");
                }
              },
            ),
          ],
        );
      },
    );

    if (pickedFiles != null && pickedFiles.isNotEmpty) {
      // Convert XFile to File and check file size limit
      List<File> files = pickedFiles.map((xfile) => File(xfile.path)).toList();

      // Check for large files
      bool hasLargeFile =
          files.any((file) => file.lengthSync() > 2 * 1024 * 1024);
      if (hasLargeFile) {
        // Show dialog if any file exceeds 2 MB
        showDialog(
          context: Get.context!,
          builder: (context) => InfoPopUpWidget(
            title: 'Information',
            content: CustomText(
              text: 'File size exceeds 2MB. Please choose a smaller file.',
              color: AppColor.blackColor,
              fontWeight: FontWeight.w500,
              fontSize: AppFontSize.size4.sp,
            ),
          ),
        );
      } else {
        targetList.addAll(files);
      }
    }
  }

  @override
  void initState() {
    getApiCall();
    super.initState();
  }

  Future<void> getApiCall() async {
    registrationController.countryList.clear();
    registrationController.stateList.clear();
    registrationController.districtList.clear();
    await registrationController.getCountryList();

    await registrationController.getBankName();

    //
    if (registrationController.countryList.isNotEmpty) {
      CountryList countryIndia = registrationController.countryList.firstWhere(
        (element) {
          return element.countryName.toLowerCase() == "india";
        },
        orElse: () {
          return registrationController.countryList[0];
        },
      );
      debugPrint("Country Name = ${countryIndia.countryName}");
      countryCtrl.clear();
      countryTextCtrl.clear();
      countryTextCtrl.text = countryIndia.countryName.toString();
      countryCtrl.text = countryIndia.countryId.toString();

      await registrationController.getStateList(countryId: countryCtrl.text);
    }
    if (registrationController.stateList.isNotEmpty) {
      StateList stateTamilNadu = registrationController.stateList.firstWhere(
        (element) =>
            element.stateProvinceName.removeAllWhitespace.toLowerCase() ==
            "tamilnadu",
        orElse: () => registrationController.stateList[0],
      );

      debugPrint("State Name = ${stateTamilNadu.stateProvinceName}");
      stateCtrl.text = stateTamilNadu.stateProvinceId
          .toString(); // Set the ID for the dropdown
      stateTextCtrl.text =
          stateTamilNadu.stateProvinceName; // Set the name for the dropdown

      await registrationController.getDistrictList(stateId: stateCtrl.text);
    }

    if (registrationController.districtList.isNotEmpty) {
      districtCtrl.text =
          registrationController.districtList[0].districtId.toString();
      districtTextCtrl.text =
          registrationController.districtList[0].districtName.toString();
    } else {
      districtCtrl.clear();
      districtTextCtrl.clear();
    }
    // new values
    debugPrint(
        'Country ${countryCtrl.text}, State ${stateCtrl.text} District ${districtCtrl.text}');
  }

  /* Future<void> _addImage(String section) async {
    // Use ImagePicker to pick images from gallery
    final XFile? pickedImage = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        // imageSections[section]?.add(File(pickedImage.path)); // Use File for local path
      });
    }
  }*/

  /*void _removeImage(String section, int index) {
    setState(() {
      imageSections[section]?.removeAt(index);
    });
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.all(15.w),
                  child: Form(
                    key: widget.formKey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 15.w,
                        ),
                        CustomTextField(
                          labelText: "Franchisee Name",
                          controller: nameCtrl,
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                            labelText: "Address 1", controller: address1Ctrl),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                            labelText: "Address 2", controller: address2Ctrl),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                            labelText: "Taluk", controller: talukCtrl),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                            labelText: "Area", controller: areaCtrl),
                        SizedBox(
                          height: 40.w,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: Obx(
                                () => SingleSelectDropDown(
                                  key: UniqueKey(),
                                  labelText: 'Country',
                                  filled: false,
                                  valueController: countryCtrl,
                                  valueTextController: countryTextCtrl,
                                  data: List.generate(
                                    registrationController.countryList.length,
                                    (index) => SingleSelectDropDownModel(
                                        registrationController
                                            .countryList[index].countryName,
                                        registrationController
                                            .countryList[index].countryId
                                            .toString()),
                                  ),
                                  parentOnChangeCall: (value) async {
                                    // PleaseWaitLoader.openDialog();
                                    // clear before assign new values
                                    registrationController.stateList.clear();
                                    stateCtrl.clear();
                                    stateTextCtrl.clear();
                                    registrationController.districtList.clear();
                                    districtCtrl.clear();
                                    districtTextCtrl.clear();

                                    bool res = await registrationController
                                        .getStateList(
                                      countryId: countryCtrl.text,
                                    );

                                    if (res &&
                                        registrationController
                                            .stateList.isNotEmpty) {
                                      // if state fetched succesfully lets get district
                                      stateCtrl.text = registrationController
                                          .stateList[0].stateProvinceId
                                          .toString();
                                      stateTextCtrl.text =
                                          registrationController
                                              .stateList[0].stateProvinceName
                                              .toString();
                                      // ignore: unused_local_variable
                                      bool res = await registrationController
                                          .getDistrictList(
                                        stateId: registrationController
                                            .stateList[0].stateProvinceId
                                            .toString(),
                                      );
                                    }

                                    if (res &&
                                        registrationController
                                            .districtList.isNotEmpty) {
                                      // if state fetched succesfully lets get district
                                      districtCtrl.text = registrationController
                                          .districtList[0].districtId
                                          .toString();
                                      districtTextCtrl.text =
                                          registrationController
                                              .districtList[0].districtName
                                              .toString();
                                    }
                                    // new values
                                    debugPrint(
                                        'Country ${countryCtrl.text}, State ${stateCtrl.text} District ${districtCtrl.text}');
                                  },
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 15.w,
                            ),
                            Expanded(
                              flex: 2,
                              child: Obx(
                                () => SingleSelectDropDown(
                                  key: UniqueKey(),
                                  labelText: 'State',
                                  filled: false,
                                  valueController: stateCtrl,
                                  valueTextController: stateTextCtrl,
                                  data: List.generate(
                                    registrationController.stateList.length,
                                    (index) => SingleSelectDropDownModel(
                                        registrationController
                                            .stateList[index].stateProvinceName,
                                        registrationController
                                            .stateList[index].stateProvinceId
                                            .toString()),
                                  ),
                                  parentOnChangeCall: (value) async {
                                    registrationController.districtList.clear();
                                    districtCtrl.clear();
                                    districtTextCtrl.clear();
                                    // if state fetched succesfully lets get district
                                    bool res = await registrationController
                                        .getDistrictList(
                                      stateId: stateCtrl.text,
                                    );
                                    if (res &&
                                        registrationController
                                            .districtList.isNotEmpty) {
                                      // if state fetched succesfully lets get district
                                      districtCtrl.text = registrationController
                                          .districtList[0].districtId
                                          .toString();
                                      districtTextCtrl.text =
                                          registrationController
                                              .districtList[0].districtName
                                              .toString();
                                    }
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: Obx(
                                () => SingleSelectDropDown(
                                  key: UniqueKey(),
                                  filled: false,
                                  labelText: 'District',
                                  valueController: districtCtrl,
                                  valueTextController: districtTextCtrl,
                                  data: List.generate(
                                    registrationController.districtList.length,
                                    (index) => SingleSelectDropDownModel(
                                        registrationController
                                            .districtList[index].districtName,
                                        registrationController
                                            .districtList[index].districtId
                                            .toString()),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 15.w,
                            ),
                            Expanded(
                              flex: 2,
                              child: CustomTextField(
                                labelText: "Pincode",
                                controller: pincodeCtrl,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomText(
                          text: "Bank Account Information",
                          color: AppColor.primary2Color,
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                          height: 30.w,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 4, // Adjust width for the dropdown
                              child: SingleSelectDropDown(
                                  key: UniqueKey(),
                                  filled: false,
                                  labelText: 'Account Number',
                                  valueController: accTypeCtrl,
                                  valueTextController: accTypeTextCtrl,
                                  data: [
                                    SingleSelectDropDownModel(
                                        "Savings Account", "Savings Account"),
                                    SingleSelectDropDownModel(
                                        "Current Account", "Current Account"),
                                  ]),
                            ),
                            Expanded(
                              flex: 6, // Adjust width for the text field
                              child: TextField(
                                controller:
                                    accNumCtrl, // Use Controller binding
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Account Number', // Customize
                                ),
                                keyboardType: TextInputType.number,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        Obx(
                          () => SingleSelectDropDown(
                            key: UniqueKey(),
                            labelText: 'Bank Name',
                            valueController: bankNameCtrl,
                            valueTextController: bankNameTextCtrl,
                            data: List.generate(
                              registrationController.bankNameList.length,
                              (index) => SingleSelectDropDownModel(
                                  registrationController
                                      .bankNameList[index].bankName,
                                  registrationController
                                      .bankNameList[index].bankId
                                      .toString()),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        Row(
                          children: [
                            Expanded(
                              flex: 2,
                              child: CustomTextField(
                                labelText: "IFSC",
                                controller: ifscCtrl,
                                // validator: validateIfscCode,
                                validator: (val) {
                                  if (val == null || val.isEmpty) {
                                    return 'IFSC Code is required';
                                  }

                                  // IFSC code format: 11 characters (4 alphabets + 0 + 6 alphanumeric)
                                  // Pattern: First 4 characters are alphabets, 5th is 0, last 6 are alphanumeric
                                  final ifscPattern =
                                      RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$');

                                  if (!ifscPattern.hasMatch(val)) {
                                    return 'Invalid IFSC format. ex: ABCD012345';
                                  }

                                  return null;
                                },
                                inputFormatters: [
                                  // Uppercase formatter
                                  UpperCaseTextFormatter(),
                                  // Length and character restriction
                                  FilteringTextInputFormatter.allow(
                                    RegExp(r'^[A-Z0-9]{0,11}$'),
                                  ),
                                ],
                                textCapitalization:
                                    TextCapitalization.characters,
                                maxLength: 11,
                              ),
                            ),
                            SizedBox(
                              width: 15.w,
                            ),
                            Expanded(
                              flex: 2,
                              child: CustomTextField(
                                labelText: "Branch",
                                controller: branchCtrl,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                          labelText: "Account Holder Name",
                          controller: accountHolderNameCtrl,
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomTextField(
                          labelText: "Notes",
                          controller: notesCtrl,
                          maxLines: 3,
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: () {
                                AppBottomSheets.addAnotherBankDetail(
                                  context: context,
                                );
                              },
                              child: Container(
                                padding: EdgeInsets.all(1.w),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColor.orange,
                                ),
                                child: const Icon(
                                  Icons.add,
                                  size: 22.0,
                                  color: AppColor.whiteColor,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 5.w,
                            ),
                            CustomText(
                              text: "Add Another Bank Detail",
                              color: AppColor.primary2Color,
                              fontSize: AppFontSize.size3,
                              fontWeight: FontWeight.w500,
                              textAlign: TextAlign.end,
                            ),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 30.w,
                            ),
                            Container(
                              width: 185.w,
                              padding: EdgeInsets.symmetric(
                                  vertical: 1.w, horizontal: 4.w),
                              decoration: const BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: AppColor.primary2Color,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 40.w,
                        ),
                        CustomText(
                          text: "Add Images",
                          color: AppColor.primary2Color,
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                          height: 10.w,
                        ),
                        buildImagePickerSection(
                          title: 'Building Elevation',
                          imageList: buildingElevationImages,
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        buildImagePickerSection(
                          title: 'Laboratory',
                          imageList: laboratoryImages,
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        buildImagePickerSection(
                          title: 'Class Room',
                          imageList: classRoomImages,
                        ),
                        /*    Container(
                          decoration: BoxDecoration(color: AppColor.grey3, borderRadius: BorderRadius.circular(10.r)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              InkWell(
                                onTap: () async {
                                  await pickImage();
                                  setState(() {});
                                  // Refresh
                                },
                                child: Container(
                                  margin: EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.w),
                                  width: 110.w,
                                  height: 110.w,
                                  child: DottedBorder(
                                    radius: Radius.circular(10.r),
                                    borderType: BorderType.rRect,
                                    child: Image.asset(
                                      AssetPath.addPhotoIcon,
                                      scale: 13.00,
                                    ),
                                  ),
                                ),
                              ),

                              // Display selected images
                              Expanded(
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Row(
                                    children: List.generate(
                                      buildingElevationImages.length,
                                      (index) {
                                        return Stack(
                                          children: [
                                            Container(
                                              margin: EdgeInsets.only(right: 10.w, top: 10.w, bottom: 10.w),
                                              decoration: BoxDecoration(border: Border.all(color: AppColor.black2Color)),
                                              child: Image.file(
                                                buildingElevationImages[index],
                                                width: 110.w,
                                                height: 110.w,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            // remove icon to remove images
                                            Positioned(
                                              right: 0,
                                              top: 0,
                                              child: InkWell(
                                                onTap: () {
                                                  // remove image from selected list
                                                  buildingElevationImages.removeAt(index);
                                                  setState(() {});
                                                  // refresh state
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: AppColor.whiteColor,
                                                  ),
                                                  child: Icon(
                                                    Icons.remove_circle_outlined,
                                                    color: AppColor.redColor,
                                                    size: 30.w,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),*/
                        /* ...imageSections.entries.map((entry) {
                          final sectionName = entry.key;
                          final images = entry.value;
                          return Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 15.w,
                                ),
                                CustomText(
                                  text: sectionName,
                                  fontSize: AppFontSize.size5,
                                  fontWeight: FontWeight.w400,
                                  color: AppColor.blackColor,
                                ),
                                SizedBox(height: 5.w),
                                Container(
                                  padding: EdgeInsets.all(5.w),
                                  decoration: BoxDecoration(
                                    color: AppColor.whiteColor,
                                    borderRadius: BorderRadius.circular(5.r),
                                  ),
                                  child: SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Row(
                                      children: [
                                        ...images
                                            .asMap()
                                            .entries
                                            .map((entry) {
                                          final index = entry.key;
                                          final image = entry.value;
                                          return Stack(
                                            alignment: Alignment.topRight,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(right: 8.0),
                                                child: image,
                                              ),
                                              GestureDetector(
                                                onTap: () => _removeImage(sectionName, index),
                                                child: CircleAvatar(
                                                  radius: 12,
                                                  backgroundColor: Colors.red,
                                                  child: Icon(
                                                    Icons.close,
                                                    size: 16,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          );
                                        }).toList(),
                                        GestureDetector(
                                          onTap: () async {
                                            FilePickerResult? result = await _addImage(sectionName);

                                            if (result != null) {
                                              File file = File(result.files.single.path!);
                                              String fileName = result.files.single.name;
                                              debugPrint(fileName);

                                              // Optionally handle the Dio file upload here
                                              dio.MultipartFile.fromFile(
                                                file.path,
                                                filename: fileName,
                                                contentType: media.MediaType(
                                                  'image',
                                                  file.path
                                                      .split('.')
                                                      .last
                                                      .toLowerCase(),
                                                ),
                                              );

                                              // Update the state with the selected image
                                              setState(() {
                                                imageSections[sectionName]?.add(Image.file(
                                                  file, fit: BoxFit.cover, // Make sure the image covers the space without overflow
                                                  width: 100, // Set width to fit container size
                                                  height: 100,
                                                ));
                                              });
                                            }
                                            else {
                                              // If user cancels the image picker, reset the image for the section
                                              setState(() {
                                                imageSections[sectionName] = []; // Clear images for the section
                                              });
                                              debugPrint('Image picker was canceled or no file selected');
                                            }
                                          },
                                          child: Container(
                                            height: 100,
                                            width: 100,
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.grey,
                                                strokeAlign: 0.5,
                                                style: BorderStyle.solid,
                                              ),
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: imageSections[sectionName]!.isEmpty // Check if an image is selected
                                                ? Icon(Icons.add_a_photo_outlined, color: Colors.grey) // If no image, show the icon
                                                : ClipRRect(
                                              // If an image is selected, display it
                                              borderRadius: BorderRadius.circular(8),
                                              child: imageSections[sectionName]!.last,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),*/
                        SizedBox(
                          height: 15.w,
                        ),
                        CustomText(
                          text: 'Location',
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                          color: AppColor.primaryColor,
                        ),
                        SizedBox(
                          height: 10.w,
                        ),
                        Container(
                          height: 200,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Center(
                            child: Text(
                              'Map Placeholder',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 16),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10.w,
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.to(() => const LocationScreen());
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              CustomText(
                                text: "Select Location",
                                color: AppColor.primary2Color,
                                fontSize: AppFontSize.size4,
                                fontWeight: FontWeight.w500,
                                textAlign: TextAlign.end,
                              ),
                            ],
                          ),
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 30.w,
                            ),
                            Container(
                              width: 100.w,
                              padding: EdgeInsets.symmetric(
                                  vertical: 1.w, horizontal: 4.w),
                              decoration: const BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: AppColor.primary2Color,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildImagePickerSection({
    required String title,
    required List<File> imageList,
  }) {
    return GreyBox(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              text: title,
              color: AppColor.black2Color,
              fontSize: AppFontSize.size4,
            ),
            Container(
              decoration: BoxDecoration(
                  color: AppColor.grey3,
                  borderRadius: BorderRadius.circular(10.r)),
              child: Row(
                children: [
                  InkWell(
                    onTap: () async {
                      await pickImage(imageList);
                      setState(() {});
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(
                          horizontal: 10.w, vertical: 10.w),
                      width: 110.w,
                      height: 110.w,
                      child: DottedBorder(
                        radius: Radius.circular(10.r),
                        borderType: BorderType.rRect,
                        child: Image.asset(
                          AssetPath.addPhotoIcon,
                          scale: 13.00,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          imageList.length,
                          (index) => Stack(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                    right: 10.w, top: 10.w, bottom: 10.w),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: AppColor.black2Color)),
                                child: Image.file(
                                  imageList[index],
                                  width: 110.w,
                                  height: 110.w,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: InkWell(
                                  onTap: () {
                                    imageList.removeAt(index);
                                    setState(() {});
                                  },
                                  child: Container(
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColor.whiteColor,
                                    ),
                                    child: Icon(
                                      Icons.remove_circle_outlined,
                                      color: AppColor.redColor,
                                      size: 30.w,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
