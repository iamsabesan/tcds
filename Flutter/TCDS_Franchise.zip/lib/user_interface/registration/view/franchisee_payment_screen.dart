// import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/utils/helper_widgets/bottom_sheets.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:tcds/utils/helper_widgets/out_button.dart';
import 'package:tcds/utils/helper_widgets/pair_text.dart';
import '../../../constants/app_string.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/shared_preference.dart';
import '../../../routes/routes.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../widgets/custom_progress_indicator.dart';
import '../../registration_status/model/franchise_request_model.dart';

class FranchiseePaymentScreen extends StatefulWidget {
  final EnquiryDetail? enquiryData;

  const FranchiseePaymentScreen({super.key, this.enquiryData});

  @override
  State<FranchiseePaymentScreen> createState() =>
      _FranchiseePaymentScreenState();
}

class _FranchiseePaymentScreenState extends State<FranchiseePaymentScreen> {
  DashboardController dashboardController = Get.put(DashboardController());

  late String selectedPaymentMethod;
  double totalPayable = 0;
  double totalPaid = 0;
  double paidAmount = 0;
  double balance = 0;
  // ignore: prefer_typing_uninitialized_variables
  var selectedPaymodeId;
  Map<String, dynamic> paymentDetails = {};
  List<Map<String, dynamic>> totalPaymentDetails = [];
  bool allowPayment = false;
  // List<Map<String, dynamic>> paymentDetails = [];
  final Set<String> completedPayments = {};
  Map<String, bool> paymentConfirmed = {
    'Bank Transfer': false,
    'UPI': false,
    'Cash': false,
    'Bank Remittance': false,
  };

  void _openBottomSheetForMethod(
      String paymentMode, String selectedPaymodeId) async {
    totalPayable = widget.enquiryData!.feesDetails[0].newFees;
    double remainingAmount = totalPayable - totalPaid;

    // Check if payment is already confirmed for this mode
    if (paymentConfirmed[paymentMode] == true) {
      Get.snackbar(
        'Error Message',
        'You already confirmed payment with $paymentMode.',
        colorText: AppColor.blackColor,
        padding: EdgeInsets.all(15.w),
        backgroundColor: AppColor.whiteColor,
      );
      return;
    }

    final result = await AppBottomSheets.registrationPaymentModeBottomSheet(
      selectedPaymodeId: selectedPaymodeId,
      walletAmount: widget.enquiryData!.feesDetails[0].newFees.toString(),
      paymentMode: paymentMode,
      adminBankList: dashboardController.adminBankList,
      franchiseeBankList: dashboardController.franchiseeBankList,
      context: context,
      remainingAmount: remainingAmount,
      // onSubmit: (details) {
      //   setState(() {
      //     completedPayments.add(paymentMode);
      //     selectedPaymentMethod = paymentMode;
      //
      //     paymentConfirmed[paymentMode] = true; // Mark this mode as confirmed
      //     paymentDetails[paymentMode] = details; // Save payment details
      //     totalPaid += details['amount']; // Update total paid
      //     balance = totalPayable - totalPaid; // Update balance
      //   });
      //   Navigator.of(context).pop();
      // },
      // onCancel: () {
      //   setState(() {
      //     completedPayments.remove(paymentMode);
      //   });
      // },
    );

    if (result != null) {
      setState(() {
        paymentDetails[paymentMode] = result;
        totalPaymentDetails.add(paymentDetails);
        totalPaid += double.tryParse(result['paymodeValue'] ?? 0) ?? 0;
        paidAmount = totalPaid;
        balance = totalPayable - totalPaid;
        allowPayment = true;
        // paymentConfirmed[paymentMode] = true; // Mark as confirmed
      });
    }
  }

/*  void removePayment(String paymentMode) {
    setState(() {
      totalPaid -= paymentDetails[paymentMode]['amount'];
      balance = totalPayable - totalPaid;
      paymentDetails.remove(paymentMode);
      paymentConfirmed[paymentMode] = false;
    });
  }*/

  void markPaymentCompleted(String method) {
    setState(() {
      paymentConfirmed[method] = true; // Mark the payment mode as completed
    });
  }

  void removePayment(String paymentMode) {
    if (paymentDetails.containsKey(paymentMode)) {
      setState(() {
        double amountToRemove = double.tryParse(
                paymentDetails[paymentMode]['paymodeValue'].toString()) ??
            0.0;

        totalPaid -= amountToRemove;
        paidAmount -= amountToRemove;
        balance += amountToRemove;

        // Remove the payment from the list
        paymentDetails.remove(paymentMode);

        // Reset paidAmount if no payments remain
        if (paymentDetails.isEmpty) {
          balance = totalPayable;
          totalPaid = 0.0;
        }
        // totalPaid -=  double.tryParse(paymentDetails[paymentMode]['paymodeValue'])!; // Subtract amount from totalPaid
        // balance = totalPayable - totalPaid; // Recalculate balance
        // paymentDetails.remove(paymentMode); // Remove the payment details
        // paymentConfirmed[paymentMode] = false; // Mark as not confirmed
        // if (totalPaid == 0) {
        //   paidAmount = 0; // Reset paidAmount if no payments remain
        // }
      });
    }
  }

  @override
  void initState() {
    super.initState();

    getApiCall();
    // amountCtrl.text = totalPayable.toString(); // Set the initial value to the amount payable
  }

  Future<void> getApiCall() async {
    dashboardController.regStatusLoader.value = true;
    await dashboardController.getPayMode();
    await dashboardController.getSenderBankList(
        franchiseRequestId: widget.enquiryData!.franchiseeRequestId);
    await dashboardController.getCashLedger();
    await dashboardController.getBankName();
    await dashboardController.getAdminBankName();
    dashboardController.regStatusLoader.value = false;
  }

  @override
  Widget build(BuildContext context) {
    // double balance = payableAmount - totalPaid;
    double balance = totalPayable - totalPaid;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.1,
        toolbarHeight: 70,
        automaticallyImplyLeading: false,
        scrolledUnderElevation: 0,
        title: CustomText(
          text: 'Registration Payment',
          fontSize: AppFontSize.size2,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            // Handle back navigation
            Get.back();
          },
        ),
      ),
      body: Obx(
        () => dashboardController.regStatusLoader.value
            ? const CustomProgressIndicator()
            : Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 1.w, horizontal: 4.w),
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: AppColor.greyColor,
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.4),
                                    blurRadius: 5.0),
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 13.w, vertical: 15.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                PairText(
                                  keyText: "Registration Fees ",
                                  // valueText: "${'₹'} ${payableAmount.toString()}",
                                  valueText:
                                      "${'₹'} ${widget.enquiryData!.feesDetails[0].newFees}",
                                  valueSize: AppFontSize.size3,
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                CustomText(
                                  text:
                                      "(Includes ${widget.enquiryData!.feesDetails[0].duration} Approval fees + ${widget.enquiryData!.feesDetails[0].subscriptionDuration} of Subscription fees)",
                                  fontSize: AppFontSize.size4,
                                  fontWeight: FontWeight.w400,
                                ),
                                SizedBox(
                                  height: 20.w,
                                ),
                                CustomText(
                                  text: "Payment Mode",
                                  color: AppColor.blackColor,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Wrap(
                                  spacing: 8,
                                  runSpacing: 8,
                                  children: [
                                    for (final method in [
                                      ['Bank Transfer'],
                                      ['UPI', 'Cash'],
                                      ['Bank Remittance']
                                    ])
                                      GestureDetector(
                                        onTap: () {
                                          _openBottomSheetForMethod(
                                              method.toString(),
                                              selectedPaymodeId);
                                        },
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: method
                                              .map((m) => Expanded(
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        //worked by vindhiya
                                                        // setState(() {
                                                        //   selectedPaymentMethod = m;
                                                        // });
                                                        // _openBottomSheetForMethod(m);
                                                        setState(() {
                                                          selectedPaymentMethod =
                                                              m;
                                                          for (var i = 0;
                                                              i <
                                                                  dashboardController
                                                                      .payModeList
                                                                      .length;
                                                              i++) {
                                                            if (dashboardController
                                                                    .payModeList[
                                                                        i]
                                                                    .paymode
                                                                    .toLowerCase()
                                                                    .removeAllWhitespace ==
                                                                m
                                                                    .toLowerCase()
                                                                    .removeAllWhitespace) {
                                                              selectedPaymodeId =
                                                                  dashboardController
                                                                      .payModeList[
                                                                          i]
                                                                      .paymodeId;
                                                            }
                                                          }
                                                        });
                                                        _openBottomSheetForMethod(
                                                            m,
                                                            selectedPaymodeId);
                                                      },
                                                      child: Container(
                                                        margin: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    10.w,
                                                                vertical: 5.w),
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                vertical: 10.w),
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border.all(
                                                              color:
                                                                  Colors.grey),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      10.0),
                                                          color:
                                                              paymentConfirmed[
                                                                          // ignore: collection_methods_unrelated_type
                                                                          method] ==
                                                                      true
                                                                  ? Colors.green
                                                                      .withValues(
                                                                          alpha:
                                                                              0.2)
                                                                  : Colors
                                                                      .white,
                                                        ),
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                          children: [
                                                            Padding(
                                                              padding: EdgeInsets
                                                                  .symmetric(
                                                                      horizontal:
                                                                          15.w),
                                                              child: CustomText(
                                                                text: m,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size3,
                                                              ),
                                                            ),
                                                            // if (selectedPaymentMethod == m || completedPayments.contains(m))
                                                            if (paymentConfirmed[
                                                                    // ignore: collection_methods_unrelated_type
                                                                    method] ==
                                                                true)
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        right:
                                                                            8.0),
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      const BoxDecoration(
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    color: Colors
                                                                        .green,
                                                                  ),
                                                                  child:
                                                                      const Icon(
                                                                    Icons.check,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 25.0,
                                                                  ),
                                                                ),
                                                              ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ))
                                              .toList(),
                                        ),
                                      ),
                                  ],
                                ),
                                SizedBox(
                                  height: 20.w,
                                ),
                                Card(
                                  color: AppColor.whiteColor,
                                  margin: EdgeInsets.all(5.w),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Amount Payable",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              // text: "₹${payableAmount}",
                                              text: "₹$totalPayable",
                                              color: AppColor.green,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                        // const Divider(),
                                        if (paymentDetails.isNotEmpty)
                                          const Divider(),
                                        SizedBox(
                                          height: 10.w,
                                        ),
                                        ...paymentDetails.entries.map((entry) {
                                          final mode = entry.key;
                                          final detail = entry.value;
                                          DateTime parsedDate =
                                              DateFormat('yyyy-MM-dd').parse(
                                                  detail['transactionDate']);
                                          return ListTile(
                                              title: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    flex: 4,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            Flexible(
                                                              child: CustomText(
                                                                text: "$mode:",
                                                                color: AppColor
                                                                    .blackColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                maxLines: 2,
                                                                overflow:
                                                                    TextOverflow
                                                                        .ellipsis,
                                                                fontSize:
                                                                    AppFontSize
                                                                        .size5
                                                                        .sp,
                                                              ),
                                                            ),
                                                            if (mode == 'UPI' ||
                                                                mode ==
                                                                    'Bank Remittance') // Condition for specific modes
                                                              SizedBox(
                                                                  width: 5.w),
                                                            if (mode == 'UPI' ||
                                                                mode ==
                                                                    'Bank Remittance')
                                                              Image.asset(
                                                                AssetPath
                                                                    .fileSearch,
                                                                height: 25.w,
                                                                width: 25.w,
                                                              ),
                                                          ],
                                                        ),
                                                        CustomText(
                                                          text: DateFormat(
                                                                  'dd-MM-yyyy')
                                                              .format(
                                                                  parsedDate),
                                                          color: AppColor
                                                              .black2Color,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontSize: AppFontSize
                                                              .size5.sp,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  if (mode.toLowerCase() !=
                                                      "cash")
                                                    SizedBox(
                                                      width: 5.w,
                                                    ),
                                                  if (mode.toLowerCase() !=
                                                      "cash")
                                                    Expanded(
                                                      flex: 4,
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text:
                                                                "From : ${detail["fromLedgerName"]}",
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size5.sp,
                                                          ),
                                                          CustomText(
                                                            text:
                                                                "To : ${detail["toLedgerName"]}",
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size5.sp,
                                                          ),
                                                          CustomText(
                                                            text:
                                                                "#${detail["transactionNo"]}",
                                                            color: AppColor
                                                                .black2Color,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize:
                                                                AppFontSize
                                                                    .size5.sp,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  Expanded(
                                                    flex: 2,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        CustomText(
                                                          text:
                                                              " ₹${detail['paymodeValue']}",
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontSize:
                                                              AppFontSize.size4,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
                                              trailing: InkWell(
                                                onTap: () => removePayment(
                                                    detail['paymodeType']),
                                                child: Icon(
                                                  Icons.cancel,
                                                  color: Colors.red,
                                                  size: 25.w,
                                                ),
                                              )
                                              //  IconButton(
                                              //   padding: EdgeInsets.zero,
                                              //   icon: Icon(
                                              //     Icons.cancel,
                                              //     color: Colors.red,
                                              //     size: 25.w,
                                              //   ),
                                              //   onPressed: () {
                                              //     removePayment(
                                              //         detail['paymodeType']);
                                              //   },
                                              //   // onPressed: () => removePayment(mode),
                                              // ),
                                              );
                                        }),
                                        // const Divider(),
                                        if (paymentDetails.isNotEmpty)
                                          const Divider(),

                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Amount Paid",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              text: "₹ $paidAmount",
                                              color: AppColor.green,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.w,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            CustomText(
                                              text: "Balance",
                                              color: AppColor.primaryColor,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            CustomText(
                                              text: "₹ $balance",
                                              color: balance == 0
                                                  ? AppColor.green
                                                  : AppColor.redColor,
                                              fontSize: AppFontSize.size3,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10.w,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding:
                        EdgeInsets.symmetric(horizontal: 25.w, vertical: 30.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          flex: 1,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 25.0),
                            child: InkWell(
                              child: OutButton(
                                onTap: () => Get.back(),
                                withArrow: false,
                                text: "Back",
                                verticalPadding: 10.w,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 25.w,
                        ),
                        Expanded(
                          flex: 1,
                          child: Padding(
                            padding: const EdgeInsets.only(right: 25.0),
                            child: InkWell(
                              child: InButton(
                                onTap: () async {
                                  if ((allowPayment) && (balance == 0)) {
                                    List<Map<String, dynamic>>
                                        paymentItemsList = [];
                                    paymentDetails.forEach((key, value) {
                                      paymentItemsList.add(
                                          value); // Add the object inside 'Cash' to the list
                                    });

                                    // Update the original JSON structure
                                    // paymentDetails = paymentItemsList;
                                    //
                                    // // Print the updated JSON
                                    // print(originalJson);
                                    final body = {
                                      "franchiseeRequestID": widget
                                          .enquiryData!.franchiseeRequestId,
                                      "walletAmount": widget
                                          .enquiryData!.feesDetails[0].newFees,
                                      "paymentItems": paymentItemsList,
                                    };

                                    // log(body.toString());

                                    // call api
                                    PleaseWaitLoader.openDialog();
                                    final bool isTopUpAdded =
                                        await dashboardController
                                            .registrationPayment(body: body);
                                    PleaseWaitLoader.closeDialog();
                                    if (isTopUpAdded) {
                                      // succes message
                                      SharedPreference.putString(
                                          AppStrings.regPaymentStatus,
                                          "regPaymentStatus");
                                      debugPrint("Topup added");
                                      Get.offAllNamed(
                                          Routes.registrationPaymentStatus);
                                      // Get.to(const RegistrationPaymentStatusPage());
                                      // showSuccessDialog(context: Get.context!, message: 'Payment done successfully successfully');
                                    }
                                  } else {
                                    Get.snackbar(
                                      'Payable amount',
                                      'The amount is not tallied',
                                      colorText: AppColor.whiteColor,
                                      padding: EdgeInsets.all(15.w),
                                      backgroundColor: AppColor.primaryColor,
                                    );
                                  }
                                },
                                withArrow: false,
                                text: "Submit",
                                color: AppColor.primaryColor,
                                verticalPadding: 10.w,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
