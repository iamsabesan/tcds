import 'dart:async';
import 'dart:convert';

import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoding/geocoding.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dio/dio.dart' as dio;
import 'package:http_parser/http_parser.dart' as media;
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:tcds/user_interface/login/view/login_screen.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../routes/routes.dart';
import '../../../utils/helper_functions/formatters.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/bottom_sheets.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/custom_textfield.dart';
import '../../../utils/helper_widgets/grey_box.dart';
import '../../../utils/helper_widgets/grey_container_widget.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/info_pop_up_widget.dart';
import '../../../utils/helper_widgets/list_tile.dart';
import '../../../utils/helper_widgets/out_button.dart';
import '../../../utils/helper_widgets/phone_textfield.dart';
import '../../../utils/helper_widgets/single_dropdown.dart';
import '../../../utils/helper_widgets/stepper.dart';
import '../../../utils/helper_widgets/uploading_file_widget.dart';
import '../../registration_status/model/franchise_request_model.dart';
import '../controller/registration_controller.dart';
import '../model/bank_details_model.dart';
import '../model/country_model.dart';
import '../model/state_model.dart';
import 'map_view.dart';

class GetDetailsPage extends StatefulWidget {
  final EnquiryDetail? enquiryData;
  const GetDetailsPage({super.key, this.enquiryData});

  @override
  State<GetDetailsPage> createState() => _GetDetailsPageState();
}

class _GetDetailsPageState extends State<GetDetailsPage>
    with TickerProviderStateMixin {
  // find register controller
  // RegisterController registerController = Get.find<RegisterController>();
  // // find register address controller
  // RegisterAddressController registerAddressController =
  //     Get.put(RegisterAddressController());

  // tab bar view controller
  TabController? tabController;
  late LatLng getUserPosition;
  RegistrationController registrationController =
      Get.put(RegistrationController());
  // LoginController logInController = Get.put(LoginController());

  // Student details fields
  File? selectedImage;
  final RxInt _secondsRemaining = 0.obs;

  List<String> genderTitles = ["Mr.", "Mrs.", "Miss", "Ms.", "Mx."];

  TextEditingController nameCtrl = TextEditingController();
  TextEditingController genderCtrl = TextEditingController();
  TextEditingController genderIDCtrl = TextEditingController();
  TextEditingController genderTitleCtrl = TextEditingController();
  TextEditingController genderTitleIDCtrl = TextEditingController();
  TextEditingController dobCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController altMobCodeCtrl = TextEditingController();
  TextEditingController altMobCtrl = TextEditingController();
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController verifyOTPCtrl = TextEditingController();
  TextEditingController qualificationCtrl = TextEditingController();
  TextEditingController qualificationIDCtrl = TextEditingController();
  TextEditingController parentNameDDCtrl = TextEditingController();
  TextEditingController parentNameDDIDCtrl = TextEditingController();
  TextEditingController parentNameCtrl = TextEditingController();
  TextEditingController occupationCtrl = TextEditingController();
  TextEditingController occupationIDCtrl = TextEditingController();
  TextEditingController reasonCtrl = TextEditingController();
  TextEditingController reasonIDCtrl = TextEditingController();
  TextEditingController stateCtrl = TextEditingController();
  TextEditingController stateTextCtrl = TextEditingController();
  TextEditingController districtCtrl = TextEditingController();
  TextEditingController districtTextCtrl = TextEditingController();
  TextEditingController pincodeCtrl = TextEditingController();
  TextEditingController pincodeTextCtrl = TextEditingController();
  late List<Placemark> placeMark;
  // show verification code field helper
  bool showVerificationCode = false;
  // check whether otp verified or not
  RxBool doesOTPVerified = false.obs;
  bool verificationClicked = false;

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> franchiseEmailForm = GlobalKey<FormState>();
  GlobalKey<FormState> studentVerifyEmailForm = GlobalKey<FormState>();
  GlobalKey<FormState> communicationValidForm = GlobalKey<FormState>();
  GlobalKey<FormState> permValidForm = GlobalKey<FormState>();
  GlobalKey<FormState> studentDetailValidForm = GlobalKey<FormState>();

  // -- Student details fields

// Address details fields
  // form key
  GlobalKey<FormState> addressDetailsForm = GlobalKey<FormState>();
  // -- Communication address fields
  TextEditingController comAddress1Ctrl = TextEditingController();
  TextEditingController comAddress2Ctrl = TextEditingController();
  TextEditingController comTalukCtrl = TextEditingController();
  TextEditingController comAreaCtrl = TextEditingController();
  TextEditingController comCountryCtrl = TextEditingController();
  TextEditingController countryCtrl = TextEditingController();
  TextEditingController countryTextCtrl = TextEditingController();
  TextEditingController comCountryIDCtrl = TextEditingController();
  TextEditingController comStateCtrl = TextEditingController();
  TextEditingController comStateIDCtrl = TextEditingController();
  TextEditingController comDistrictCtrl = TextEditingController();
  TextEditingController comDistrictIDCtrl = TextEditingController();
  TextEditingController comPinCodeCtrl = TextEditingController();
  TextEditingController talukCtrl = TextEditingController();

  // // address details page helpers
  // List<Country> comCountries = <Country>[];
  // List<States> comState = <States>[];
  // List<District> comDistrict = <District>[];
  // List<Country> permCountries = <Country>[];
  // List<States> permState = <States>[];
  // List<District> permDistrict = <District>[];

  // -- Permanent address fields
  TextEditingController permAddress1Ctrl = TextEditingController();
  TextEditingController permAddress2Ctrl = TextEditingController();
  TextEditingController permTalukCtrl = TextEditingController();
  TextEditingController permAreaCtrl = TextEditingController();
  TextEditingController permCountryCtrl = TextEditingController();
  TextEditingController permCountryIDCtrl = TextEditingController();
  TextEditingController permStateCtrl = TextEditingController();
  TextEditingController permStateIDCtrl = TextEditingController();
  TextEditingController permDistrictCtrl = TextEditingController();
  TextEditingController permDistrictIDCtrl = TextEditingController();
  TextEditingController permPinCodeCtrl = TextEditingController();
  TextEditingController accTypeCtrl = TextEditingController();
  TextEditingController accTypeTextCtrl = TextEditingController();
  TextEditingController accNumCtrl = TextEditingController();
  TextEditingController bankNameCtrl = TextEditingController();
  TextEditingController bankNameTextCtrl = TextEditingController();

  // -- Address details fields
  // final bool _isChecked = false;
  String? account;
  List<File> buildingElevationImages = [];
  List<File> classRoomImages = [];
  List<File> laboratoryImages = [];
  final Set<Marker> markers = {};
  final Completer<GoogleMapController> mapController =
      Completer<GoogleMapController>();
  bool nextPosition = false;
  List<BankDetails> bankList = [];
  BankDetails firstBankDetail = BankDetails(
      accountType: '',
      accountName: '',
      accountNumber: "",
      bank: '',
      ifsc: '',
      description: '',
      branchName: '');
  late TabController _bankTabController;
  GlobalKey<FormState> studentEmailForm = GlobalKey<FormState>();
  late Timer _timer;
  bool showMap = false;
  List<FranchiseeImg> buildingElevationImagesBck = [];
  List<FranchiseeImg> classRoomImagesBck = [];
  List<FranchiseeImg> laboratoryImagesBck = [];
  Map<String, List<FranchiseeImg>> groupedImage = {};

  // Text editing controllers for bank details
  late TextEditingController _accountNumberController;
  late TextEditingController _ifscController;
  late TextEditingController _branchController;
  late TextEditingController _accountNameController;
  late TextEditingController _notesController;

  @override
  void initState() {
    getUserPosition =
        const LatLng(11.673990, 78.128216); //11.673990,78.128216);
    setState(() {
      markers.add(
        Marker(
          markerId: const MarkerId(''),
          icon: BitmapDescriptor.defaultMarker,
          position: getUserPosition,
        ),
      );
    });
    addressDetailAPICalls();
    _timer = Timer(
      const Duration(seconds: 30),
      () {},
    );
    tabController = TabController(length: 3, vsync: this, initialIndex: 0);

    _bankTabController = TabController(length: 1, vsync: this);

    // Initialize bank detail controllers
    _accountNumberController = TextEditingController();
    _ifscController = TextEditingController();
    _branchController = TextEditingController();
    _accountNameController = TextEditingController();
    _notesController = TextEditingController();

    // Add listeners to update bank details in real-time
    _accountNumberController.addListener(_updateFirstBankDetail);
    _ifscController.addListener(_updateFirstBankDetail);
    _branchController.addListener(_updateFirstBankDetail);
    _accountNameController.addListener(_updateFirstBankDetail);
    _notesController.addListener(_updateFirstBankDetail);

    // default assign

    super.initState();

    // Set initial values if enquiry data exists (after bankList is populated)
    if (widget.enquiryData != null && bankList.isNotEmpty) {
      _accountNumberController.text = bankList[0].accountNumber.toString();
      _ifscController.text = bankList[0].ifsc;
      _branchController.text = bankList[0].branchName;
      _accountNameController.text = bankList[0].accountName;
      _notesController.text = bankList[0].description;
    }
  }

  @override
  void dispose() {
    // Remove listeners and dispose controllers
    _accountNumberController.removeListener(_updateFirstBankDetail);
    _ifscController.removeListener(_updateFirstBankDetail);
    _branchController.removeListener(_updateFirstBankDetail);
    _accountNameController.removeListener(_updateFirstBankDetail);
    _notesController.removeListener(_updateFirstBankDetail);

    _accountNumberController.dispose();
    _ifscController.dispose();
    _branchController.dispose();
    _accountNameController.dispose();
    _notesController.dispose();

    tabController?.dispose();
    if (_timer.isActive) {
      _timer.cancel();
    }
    super.dispose();
  }

  // Clean up temporary files when navigating away
  Future<void> _cleanupTemporaryFiles() async {
    try {
      if (_imagesDirectory != null && _imagesDirectory!.existsSync()) {
        final files = _imagesDirectory!.listSync();
        for (var file in files) {
          if (file is File && file.path.contains('franchise_')) {
            // Only delete files older than 1 hour to avoid deleting currently used files
            if (DateTime.now().difference(file.statSync().modified).inHours >
                1) {
              await file.delete();
            }
          }
        }
      }
    } catch (e) {
      debugPrint("Error cleaning up temporary files: $e");
    }
  }

  // call api's that required to show this screen
  Future<void> addressDetailAPICalls() async {
    if (widget.enquiryData != null) {
      nameCtrl.text = widget.enquiryData!.contactName;
      genderCtrl.text = widget.enquiryData!.gender.toUpperCase();
      // genderIDCtrl.text=widget.enquiryData!.gender.toLowerCase();
      mobileCtrl.text = widget.enquiryData!.phone;
      altMobCtrl.text = widget.enquiryData!.alternatePhone;
      emailCtrl.text = widget.enquiryData!.email;
      comAddress1Ctrl.text = widget.enquiryData!.address[0].address1;
      comAddress2Ctrl.text = widget.enquiryData!.address[0].address2;
      talukCtrl.text = widget.enquiryData!.address[0].area;
      comAreaCtrl.text = widget.enquiryData!.address[0].area;
      countryTextCtrl.text = widget.enquiryData!.address[0].country;
      stateTextCtrl.text = widget.enquiryData!.address[0].state;
      districtTextCtrl.text = widget.enquiryData!.address[0].district;
      pincodeCtrl.text = widget.enquiryData!.address[0].pincode;
      // Note: The actual bank detail values are set in the initState after bankList is populated
      // These are just for reference - the real values come from the enquiry data
      account = widget.enquiryData!.banks[0].accountType.toString();
      bankNameCtrl.text = widget.enquiryData!.banks[0].bank;
      showMap = true;
      getUserPosition = LatLng(
          double.parse(widget.enquiryData!.address[0].latitude),
          double.parse(widget.enquiryData!.address[0].longitude));
      markers.add(
        Marker(
          markerId: const MarkerId(''),
          icon: BitmapDescriptor.defaultMarker,
          position: getUserPosition,
        ),
      );
      for (var material in widget.enquiryData!.franchiseeImgs) {
        String semester = material.documentName;
        if (!groupedImage.containsKey(semester)) {
          groupedImage[semester] = [];
        }
        groupedImage[semester]?.add(material);
        // semesterTotalMarks[semester]!["TotalMarks"] = (semesterTotalMarks[semester]!["TotalMarks"]! + material.totalMarks);
        // semesterTotalMarks[semester]!["TheoryMarks"] = semesterTotalMarks[semester]!["TheoryMarks"]! + material.theoryMarks;
        // semesterTotalMarks[semester]!["PracticalMarks"] = semesterTotalMarks[semester]!["PracticalMarks"]! + material.practicalMarks;
      }
      buildingElevationImagesBck = groupedImage["OutletImage"]!;
      classRoomImagesBck = groupedImage["ClassRoomImage"]!;
      laboratoryImagesBck = groupedImage["LaboratoryImage"]!;
      for (var bank in widget.enquiryData!.banks) {
        BankDetails fetchedBank = BankDetails(
            accountType: '',
            accountName: '',
            accountNumber: "",
            bank: '',
            ifsc: '',
            description: '',
            branchName: '');
        fetchedBank.accountType = bank.accountType.toString();
        fetchedBank.accountNumber = bank.accountNumber;
        fetchedBank.bank = bank.bank;
        fetchedBank.ifsc = bank.ifsc;
        fetchedBank.branchName = bank.branchName;
        fetchedBank.accountName = bank.accountName;
        fetchedBank.description = bank.bank;
        bankList.add(fetchedBank);
      }
      debugPrint("${bankList.length}");
    }
    // registrationController.getPhoneCodes();
    registrationController.getGenderTypes();
    await registrationController.getAccountType();
    await registrationController.getBankName();
    await registrationController.getPhoneCodes();
    if (registrationController.accountList.isNotEmpty) {
      account = registrationController.accountList.last;
    }
    registrationController.countryList.clear();
    registrationController.stateList.clear();
    registrationController.districtList.clear();
    await registrationController.getCountryList();

    await registrationController.getBankName();

    //
    if (registrationController.countryList.isNotEmpty) {
      CountryList countryIndia = registrationController.countryList.firstWhere(
        (element) {
          return element.countryName.toLowerCase() == "india";
        },
        orElse: () {
          return registrationController.countryList[0];
        },
      );
      debugPrint("Country Name = ${countryIndia.countryName}");
      countryCtrl.clear();
      countryTextCtrl.clear();
      countryTextCtrl.text = countryIndia.countryName.toString();
      countryCtrl.text = countryIndia.countryId.toString();

      await registrationController.getStateList(countryId: countryCtrl.text);
    }
    if (registrationController.stateList.isNotEmpty) {
      StateList stateTamilNadu = registrationController.stateList.firstWhere(
        (element) =>
            element.stateProvinceName.removeAllWhitespace.toLowerCase() ==
            "tamilnadu",
        orElse: () => registrationController.stateList[0],
      );

      debugPrint("State Name = ${stateTamilNadu.stateProvinceName}");
      stateCtrl.text = stateTamilNadu.stateProvinceId
          .toString(); // Set the ID for the dropdown
      stateTextCtrl.text =
          stateTamilNadu.stateProvinceName; // Set the name for the dropdown

      await registrationController.getDistrictList(stateId: stateCtrl.text);
    }

    if (registrationController.districtList.isNotEmpty) {
      districtCtrl.text =
          registrationController.districtList[0].districtId.toString();
      districtTextCtrl.text =
          registrationController.districtList[0].districtName.toString();
    } else {
      districtCtrl.clear();
      districtTextCtrl.clear();
    }
    // new values
    debugPrint(
        'Country ${countryCtrl.text}, State ${stateCtrl.text} District ${districtCtrl.text}');
  }

  // layer function for navigation
  void navigateIndex(int index) {
    tabController?.animateTo(index);
    setState(() {});
  }

  final ImagePicker picker = ImagePicker();

  // Directory for permanent image storage
  Directory? _imagesDirectory;

  // Initialize the images directory
  Future<void> _initializeImagesDirectory() async {
    _imagesDirectory ??= await getApplicationDocumentsDirectory();
  }

  // Copy image to permanent location
  Future<File> _copyImageToPermanentLocation(File sourceFile) async {
    await _initializeImagesDirectory();

    final String fileName =
        'franchise_${DateTime.now().millisecondsSinceEpoch}_${sourceFile.path.split('/').last}';
    final File destinationFile = File('${_imagesDirectory!.path}/$fileName');

    // Copy the file to permanent location
    return await sourceFile.copy(destinationFile.path);
  }

  // Function to pick images and check file size limit
  Future<void> pickImage() async {
    final pickedFiles = await showModalBottomSheet<XFile>(
      context: context,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(
                Icons.camera_alt,
              ),
              title: CustomText(
                text: 'Take a picture',
                fontSize: 16.sp,
              ),
              onTap: () async {
                try {
                  final cameraImage =
                      await picker.pickImage(source: ImageSource.camera);
                  Get.back(result: cameraImage);
                } catch (e) {
                  debugPrint("Error taking picture: $e");
                }
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.photo_library,
              ),
              title: CustomText(
                text: 'Choose from gallery',
                fontSize: 16.sp,
              ),
              onTap: () async {
                try {
                  Get.back(
                      result:
                          await picker.pickImage(source: ImageSource.gallery));
                } catch (e) {
                  debugPrint("Error while choose: $e");
                }
              },
            ),
          ],
        );
      },
    );

    if (pickedFiles != null) {
      // Convert XFile to File and check file size limit
      File file = File(pickedFiles.path);

      // Check for large files
      bool hasLargeFile = file.lengthSync() > 2 * 1024 * 1024;
      if (hasLargeFile) {
        Fluttertoast.showToast(
            msg: "File size exceeds 2MB. Please choose a smaller file.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: AppColor.primaryColor,
            textColor: AppColor.whiteColor,
            fontSize: 14);
      } else {
        // Copy image to permanent storage before using
        selectedImage = await _copyImageToPermanentLocation(file);
      }
    }
  }

  Future<void> pickImages(List<File> targetList) async {
    final pickedFiles = await showModalBottomSheet<List<XFile>>(
      context: context,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(
                Icons.camera_alt,
              ),
              title: CustomText(
                text: 'Take a picture',
                fontSize: AppFontSize.size4.sp,
              ),
              onTap: () async {
                try {
                  final cameraImage =
                      await picker.pickImage(source: ImageSource.camera);
                  Get.back(
                      result: cameraImage != null ? [cameraImage] : <XFile>[]);
                } catch (e) {
                  debugPrint("Error taking picture: $e");
                }
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.photo_library,
              ),
              title: CustomText(
                text: 'Choose from gallery',
                fontSize: AppFontSize.size4.sp,
              ),
              onTap: () async {
                try {
                  Get.back(result: await picker.pickMultiImage());
                } catch (e) {
                  debugPrint("Error while choose: $e");
                }
              },
            ),
          ],
        );
      },
    );

    if (pickedFiles != null && pickedFiles.isNotEmpty) {
      // Convert XFile to File and check file size limit
      List<File> files = pickedFiles.map((xfile) => File(xfile.path)).toList();

      // Check for large files
      bool hasLargeFile =
          files.any((file) => file.lengthSync() > 2 * 1024 * 1024);
      if (hasLargeFile) {
        // Show dialog if any file exceeds 2 MB
        showDialog(
          context: Get.context!,
          builder: (context) => InfoPopUpWidget(
            title: 'Information',
            content: CustomText(
              text: 'File size exceeds 2MB. Please choose a smaller file.',
              color: AppColor.blackColor,
              fontWeight: FontWeight.w500,
              fontSize: AppFontSize.size4.sp,
            ),
          ),
        );
      } else {
        // Copy all images to permanent storage before adding to target list
        for (File file in files) {
          File permanentFile = await _copyImageToPermanentLocation(file);
          targetList.add(permanentFile);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: PreferredSize(
          preferredSize: Size(double.infinity, 120.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(bottom: 15.w),
                decoration: const BoxDecoration(
                  color: AppColor.whiteColor,
                  boxShadow: [
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(
                        color: AppColor.grey,
                        offset: Offset(0, 6),
                        spreadRadius: 0.5,
                        blurRadius: 4),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 20.w,
                    ),
                    InkWell(
                      splashColor: AppColor.black2Color,
                      onTap: () async {
                        await _cleanupTemporaryFiles();
                        if (!context.mounted) return;
                        _showExitDialog(context);
                        // Get.back();
                      },
                      child: Icon(
                        Icons.arrow_back_ios_new_outlined,
                        size: 30.w,
                      ),
                    ),
                    SizedBox(
                      width: 15.w,
                    ),
                    Flexible(
                      child: CustomText(
                        text: "Franchisee Registration",
                        fontSize: 20.sp,
                        color: AppColor.blackColor,
                        fontWeight: FontWeight.w400,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    )
                  ],
                ),
              ),
            ],
          )),
      body: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            // stepper widget
            stepper(stepCount: (tabController?.index ?? 0) + 1),
            SizedBox(
              height: 10.w,
            ),
            // tab bar view based on stepper widget
            Expanded(
              child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: tabController,
                  children: [
                    registrantDetails(),
                    franchiseDetails(),
                    confirmDetails(),
                  ]),
            )
          ],
        ),
      ),
    );
  }

  Widget registrantDetails() {
    return StatefulBuilder(builder: (context, studentDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: studentDetailsForm,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // profile picture
                InkWell(
                    onTap: () async {
                      await pickImage();
                      // refresh student details state
                      studentDetailsState(() {});
                    },
                    child: selectedImage != null
                        ? Stack(
                            children: [
                              ClipOval(
                                child: Image.file(
                                  selectedImage!,
                                  width: 130.w,
                                  height: 130.w,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                bottom: 5.w,
                                right: 5.w,
                                child: Image.asset(
                                  AssetPath.cameraFrame,
                                  scale: 18,
                                ),
                              ),
                            ],
                          )
                        : widget.enquiryData != null
                            ? Stack(
                                children: [
                                  ClipOval(
                                    child: Image.memory(
                                      base64Decode(widget.enquiryData!
                                          .franchiseeImgs[0].fetchedBase64!),
                                      height: 100.w,
                                      width: 100.w,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) =>
                                              Image.asset(
                                        AssetPath.defaultProfile,
                                        height: 100.w,
                                        width: 100.w,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 5.w,
                                    right: 5.w,
                                    child: Image.asset(
                                      AssetPath.cameraFrame,
                                      scale: 18,
                                    ),
                                  ),
                                ],
                              )
                            : Stack(
                                children: [
                                  Image.asset(
                                    AssetPath.uploadProfile,
                                    scale: 4,
                                  ),
                                  Positioned(
                                    bottom: 5.w,
                                    right: 5.w,
                                    child: Image.asset(
                                      AssetPath.cameraFrame,
                                      scale: 18,
                                    ),
                                  ),
                                ],
                              )),
                SizedBox(
                  height: 30.w,
                ),
                // student details

                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 3,
                      child: Padding(
                        padding: EdgeInsets.only(top: 2.w),
                        child: SingleSelectDropDown(
                          key: UniqueKey(),
                          labelText: 'Title',
                          valueController: genderTitleIDCtrl,
                          valueTextController: genderTitleCtrl,
                          enabled: widget.enquiryData != null ? false : true,
                          filled: false,
                          validator: (val) {
                            if (val != null && val.isEmpty) {
                              return 'Title is required';
                            } else {
                              return null;
                            }
                          },
                          data: List.generate(
                            genderTitles.length,
                            (index) => SingleSelectDropDownModel(
                                genderTitles[index],
                                genderTitles[index].toLowerCase()),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Expanded(
                      flex: 7,
                      child: CustomTextField(
                        labelText: "Name",
                        // onSaved: (value) => _formData['name'] = value,
                        prefixIcon: Image.asset(
                          AssetPath.userIcon,
                          scale: 25.0,
                          color: AppColor.orange,
                        ),
                        controller: nameCtrl,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "Name is required";
                          } else {
                            return null;
                          }
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30.w,
                ),
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: 'Gender',
                    valueController: genderIDCtrl,
                    valueTextController: genderCtrl,
                    enabled: widget.enquiryData != null ? false : true,
                    filled: false,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Gender is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registrationController.genderTypesList.length,
                      (index) => SingleSelectDropDownModel(
                          registrationController
                              .genderTypesList[index].genderName,
                          registrationController.genderTypesList[index].genderId
                              .toString()),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                PhoneTextField(
                    controller: mobileCtrl,
                    enabled: widget.enquiryData != null ? false : true,
                    mobileCodecontroller: mobileCodeCtrl,
                    labelText: "Mobile"),
                SizedBox(
                  height: 30.w,
                ),
                PhoneTextField(
                    withValidator: false,
                    enabled: widget.enquiryData != null ? false : true,
                    controller: altMobCtrl,
                    mobileCodecontroller: altMobCodeCtrl,
                    labelText: "Alternate Mobile"),
                SizedBox(
                  height: 30.w,
                ),
                if (!showVerificationCode)
                  Container(
                    padding: EdgeInsets.all(20.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.grey),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Column(
                      children: [
                        Form(
                          key: studentEmailForm,
                          child: CustomTextField(
                            labelText: "Email",
                            enabled: widget.enquiryData != null ? false : true,
                            controller: emailCtrl,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Email is required';
                              } else if (!RegExp(
                                      r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                                  .hasMatch(value)) {
                                return "Invalid email address";
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(
                          height: 30.w,
                        ),
                        if (widget.enquiryData == null)
                          Align(
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                              width: 100.w,
                              child: InButton(
                                onTap: () async {
                                  // first validate email field has valid value
                                  if (studentEmailForm.currentState!
                                      .validate()) {
                                    PleaseWaitLoader.openDialog();
                                    // if valid mail
                                    bool doesOTPRequested =
                                        await registrationController
                                            .requestOTP(body: {
                                      "Email": emailCtrl.text,
                                    });
                                    PleaseWaitLoader.closeDialog();
                                    if (doesOTPRequested) {
                                      studentDetailsState(() {
                                        // change [showVerificationCode] value
                                        showVerificationCode =
                                            !showVerificationCode;
                                      });

                                      // assign fetched otp time to [_secondsRemaining]
                                      _secondsRemaining.value =
                                          registrationController
                                                  .requestedOTP.isNotEmpty
                                              ? registrationController
                                                  .requestedOTP[0]
                                                  .emailValidityTime
                                              : 30;
                                      // [_startTimer] after expiry time fetched
                                      _startTimer(
                                        seconds: _secondsRemaining.value,
                                      );
                                    }
                                  }
                                  //
                                },
                                // horizPad: 5.w,
                                text: 'Send Code',
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),

                // verify email
                if (showVerificationCode)
                  Container(
                    padding: EdgeInsets.all(20.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.grey),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // change mail address
                        RichText(
                            text: TextSpan(children: [
                          TextSpan(
                              text: "${emailCtrl.text}  ",
                              style: TextStyle(
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 14.sp,
                              )),
                          TextSpan(
                              text: "Change",
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  _timer.cancel();
                                  // change otp to not verified
                                  doesOTPVerified.value = false;
                                  // clear verification code controllers
                                  verifyOTPCtrl.clear();

                                  studentDetailsState(() {
                                    // change [showVerificationCode] value
                                    showVerificationCode =
                                        !showVerificationCode;
                                  });
                                },
                              style: TextStyle(
                                decoration: TextDecoration.underline,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 14.sp,
                              )),
                        ])),
                        SizedBox(
                          height: 30.w,
                        ),

                        // verify otp field
                        Form(
                          key: studentVerifyEmailForm,
                          child: CustomTextField(
                            labelText: "Verification Code",
                            controller: verifyOTPCtrl,
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Verification Code is required';
                              }
                              return null;
                            },
                          ),
                        ),

                        // resend and timer
                        if (!verificationClicked)
                          Obx(
                            () => Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                TextButton(
                                  onPressed: _secondsRemaining.value == 0
                                      ? () async {
                                          // stop timer
                                          _timer.cancel();

                                          // request new otp
                                          PleaseWaitLoader.openDialog();
                                          bool doesOTPResended =
                                              await registrationController
                                                  .resendOTP(body: {
                                            "Email": emailCtrl.text,
                                          });
                                          PleaseWaitLoader.closeDialog();

                                          // if otp resended sucessfully
                                          if (doesOTPResended) {
                                            doesOTPVerified.value = false;
                                            verifyOTPCtrl.clear();
                                            // assign fetched otp time to [_secondsRemaining]
                                            _secondsRemaining.value =
                                                registrationController
                                                        .requestedOTP.isNotEmpty
                                                    ? registrationController
                                                        .requestedOTP[0]
                                                        .emailValidityTime
                                                    : 30;
                                            // [_startTimer] after expiry time fetched
                                            _startTimer(
                                              seconds: _secondsRemaining.value,
                                            );
                                          }
                                        }
                                      : null,
                                  child: CustomText(
                                    text: "Resend",
                                    color: _secondsRemaining.value == 0
                                        ? AppColor.primaryColor
                                        : AppColor.grey,
                                  ),
                                ),
                                CustomText(
                                  text: _secondsRemaining.value > 0
                                      ? "Resend in ${_secondsRemaining.value} s"
                                      : "You can resend now",
                                  color: AppColor.grey,
                                ),
                              ],
                            ),
                          ),

                        SizedBox(
                          height: 20.w,
                        ),

                        // verify button
                        Obx(
                          () => Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              width: 100.w,
                              child: InButton(
                                color: doesOTPVerified.value
                                    ? AppColor.grey
                                    : AppColor.primaryColor,
                                onTap: !doesOTPVerified.value
                                    ? () async {
                                        if (studentVerifyEmailForm.currentState!
                                            .validate()) {
                                          // verify  otp
                                          PleaseWaitLoader.openDialog();
                                          doesOTPVerified.value =
                                              await registrationController
                                                  .verifyOTP(body: {
                                            if (registrationController
                                                .requestedOTP.isNotEmpty)
                                              "EmailOTPTransID":
                                                  registrationController
                                                      .requestedOTP[0]
                                                      .emailOtpTransId
                                                      .toString(),
                                            "EmailOTPCode": verifyOTPCtrl.text,
                                          });
                                          PleaseWaitLoader.closeDialog();

                                          // if otp verified sucessfully
                                          if (doesOTPVerified.value) {
                                            verificationClicked =
                                                !verificationClicked;
                                            setState(() {});
                                            Get.snackbar(
                                              'Email Verification',
                                              'Email verification success',
                                              colorText: AppColor.whiteColor,
                                              padding: EdgeInsets.all(15.w),
                                              backgroundColor:
                                                  AppColor.primaryColor,
                                            );
                                            // stop timer
                                            _timer.cancel();
                                            // assign '0' to [_secondsRemaining]
                                            _secondsRemaining.value = 0;
                                          }
                                        }
                                      }
                                    : null,
                                // horizPad: 5.w,
                                text: 'Verify',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                // Form(
                //   key: franchiseEmailForm,
                //   child: CustomTextField(
                //     prefixIcon: Image.asset(
                //       AssetPath.mailBlue,
                //       scale: 22.0,
                //       color: AppColor.violetColor,
                //     ),
                //
                //     labelText: "Email",
                //     controller: emailCtrl,
                //     validator: (value) {
                //       if (value == null || value.isEmpty) {
                //         return 'required';
                //       } else if (!RegExp(
                //           r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                //           .hasMatch(value)) {
                //         return "Invalid email address";
                //       }
                //       return null;
                //     },
                //   ),
                // ),

                SizedBox(
                  height: 60.w,
                ),

                // next button
                SizedBox(
                  width: 150.w,
                  child: InButton(
                    withArrow: true,
                    onTap: () {
                      if (widget.enquiryData == null) {
                        // validate all fields

                        // bool franchiseMailEntered =
                        studentEmailForm.currentState?.validate() ?? false;
                        // bool franchiseMailVerified =
                        studentVerifyEmailForm.currentState?.validate() ??
                            false;
                        bool studentDetailsValidated =
                            studentDetailsForm.currentState!.validate();

                        debugPrint(
                            "studentDetailsValidated $studentDetailsValidated");
                        // debugPrint("emailValidated $emailValidated");

                        // if(!emailValidated){
                        //   Get.snackbar(
                        //     'Email Validation',
                        //     'Email is not validated',
                        //     colorText: AppColor.whiteColor,
                        //     padding: EdgeInsets.all(15.w),
                        //     backgroundColor: AppColor.primaryColor,
                        //   );
                        // }

                        if (selectedImage == null) {
                          //
                          Get.snackbar(
                            'Registration Details',
                            'Please upload your profile picture to proceed.',
                            colorText: AppColor.whiteColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.primaryColor,
                          );
                        } else if (!showVerificationCode) {
                          Get.snackbar(
                            'Franchisee Details',
                            'Email Verification is not done',
                            colorText: AppColor.whiteColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.primaryColor,
                          );
                        } else if (!verificationClicked) {
                          Get.snackbar(
                            'Franchisee Details',
                            'Please, verify Mail with Verification code',
                            colorText: AppColor.whiteColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.primaryColor,
                          );
                        } else if (verificationClicked &&
                            showVerificationCode &&
                            studentDetailsValidated &&
                            selectedImage != null) {
                          debugPrint('Franchisee Detail Details Validated!! ');
                          // if all fields are validated successfully navigate to Address Details
                          navigateIndex(1);
                        } else {
                          debugPrint('No Conditions matches...');
                          Get.snackbar(
                            'Franchisee Details',
                            'It seems some fields are incomplete. Please check and fill them correctly.',
                            colorText: AppColor.whiteColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.primaryColor,
                          );
                        }
                      } else {
                        if (selectedImage == null) {
                          //
                          Get.snackbar(
                            'Registration Details',
                            'Please upload your profile picture to proceed.',
                            colorText: AppColor.whiteColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.primaryColor,
                          );
                        } else {
                          navigateIndex(1);
                        }
                      }
                    },
                  ),
                ),

                SizedBox(
                  height: 30.w,
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // franchisee details
  Widget franchiseDetails() {
    return StatefulBuilder(builder: (context, addressDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Form(
                key: communicationValidForm,
                child: StatefulBuilder(builder: (context, comSetState) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 30.w,
                      ),
                      // student details
                      CustomTextField(
                        labelText: "Address 1",
                        controller: comAddress1Ctrl,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Address 1 is required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        labelText: "Address 2",
                        controller: comAddress2Ctrl,
                        enabled: widget.enquiryData != null ? false : true,
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        labelText: "Taluk",
                        controller: talukCtrl,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Taluk is required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        labelText: "Area",
                        controller: comAreaCtrl,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Area is required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Obx(
                              () => SingleSelectDropDown(
                                key: UniqueKey(),
                                labelText: 'Country',
                                filled: false,
                                valueController: countryCtrl,
                                valueTextController: countryTextCtrl,
                                enabled:
                                    widget.enquiryData != null ? false : true,
                                data: List.generate(
                                  registrationController.countryList.length,
                                  (index) => SingleSelectDropDownModel(
                                      registrationController
                                          .countryList[index].countryName,
                                      registrationController
                                          .countryList[index].countryId
                                          .toString()),
                                ),
                                parentOnChangeCall: (value) async {
                                  // PleaseWaitLoader.openDialog();
                                  // clear before assign new values
                                  registrationController.stateList.clear();
                                  stateCtrl.clear();
                                  stateTextCtrl.clear();
                                  registrationController.districtList.clear();
                                  districtCtrl.clear();
                                  districtTextCtrl.clear();

                                  bool res =
                                      await registrationController.getStateList(
                                    countryId: countryCtrl.text,
                                  );

                                  if (res &&
                                      registrationController
                                          .stateList.isNotEmpty) {
                                    // if state fetched succesfully lets get district
                                    stateCtrl.text = registrationController
                                        .stateList[0].stateProvinceId
                                        .toString();
                                    stateTextCtrl.text = registrationController
                                        .stateList[0].stateProvinceName
                                        .toString();
                                    // ignore: unused_local_variable
                                    bool res = await registrationController
                                        .getDistrictList(
                                      stateId: registrationController
                                          .stateList[0].stateProvinceId
                                          .toString(),
                                    );
                                  }

                                  if (res &&
                                      registrationController
                                          .districtList.isNotEmpty) {
                                    // if state fetched succesfully lets get district
                                    districtCtrl.text = registrationController
                                        .districtList[0].districtId
                                        .toString();
                                    districtTextCtrl.text =
                                        registrationController
                                            .districtList[0].districtName
                                            .toString();
                                  }
                                  // new values
                                  debugPrint(
                                      'Country ${countryCtrl.text}, State ${stateCtrl.text} District ${districtCtrl.text}');
                                },
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 15.w,
                          ),
                          Expanded(
                            flex: 2,
                            child: Obx(
                              () => SingleSelectDropDown(
                                key: UniqueKey(),
                                labelText: 'State',
                                filled: false,
                                valueController: stateCtrl,
                                valueTextController: stateTextCtrl,
                                enabled:
                                    widget.enquiryData != null ? false : true,
                                data: List.generate(
                                  registrationController.stateList.length,
                                  (index) => SingleSelectDropDownModel(
                                      registrationController
                                          .stateList[index].stateProvinceName,
                                      registrationController
                                          .stateList[index].stateProvinceId
                                          .toString()),
                                ),
                                parentOnChangeCall: (value) async {
                                  registrationController.districtList.clear();
                                  districtCtrl.clear();
                                  districtTextCtrl.clear();
                                  // if state fetched succesfully lets get district
                                  bool res = await registrationController
                                      .getDistrictList(
                                    stateId: stateCtrl.text,
                                  );
                                  if (res &&
                                      registrationController
                                          .districtList.isNotEmpty) {
                                    // if state fetched succesfully lets get district
                                    districtCtrl.text = registrationController
                                        .districtList[0].districtId
                                        .toString();
                                    districtTextCtrl.text =
                                        registrationController
                                            .districtList[0].districtName
                                            .toString();
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 40.w,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Obx(
                              () => SingleSelectDropDown(
                                key: UniqueKey(),
                                filled: false,
                                labelText: 'District',
                                valueController: districtCtrl,
                                valueTextController: districtTextCtrl,
                                enabled:
                                    widget.enquiryData != null ? false : true,
                                data: List.generate(
                                  registrationController.districtList.length,
                                  (index) => SingleSelectDropDownModel(
                                      registrationController
                                          .districtList[index].districtName,
                                      registrationController
                                          .districtList[index].districtId
                                          .toString()),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 15.w,
                          ),
                          Expanded(
                            flex: 2,
                            child: CustomTextField(
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(6),
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              labelText: "Pincode",
                              controller: pincodeCtrl,
                              enabled:
                                  widget.enquiryData != null ? false : true,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Pincode is required';
                                }
                                if (val!.length < 6) {
                                  return '6 digit pincode required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomText(
                        text: "Bank Account Information",
                        color: AppColor.primary2Color,
                        fontSize: AppFontSize.size3,
                        fontWeight: FontWeight.w500,
                      ),

                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        keyboardType: TextInputType.number,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(18),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        labelText: "Account Number",
                        controller: _accountNumberController,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Account Number is required';
                          } else {
                            return null;
                          }
                        },
                        prefixIcon: Obx(
                          () => Container(
                            padding: EdgeInsets.only(left: 10.w),
                            constraints: BoxConstraints(
                              maxWidth: 150.w,
                            ),
                            child: Center(
                              child: DropdownButton<String>(
                                value: account,
                                padding: const EdgeInsets.all(0),
                                menuMaxHeight: 250.w,
                                isExpanded: true,
                                underline: const SizedBox(),
                                dropdownColor: AppColor.whiteColor,
                                isDense: true,
                                alignment: Alignment.center,
                                // iconSize: 0,
                                style: TextStyle(
                                    color: AppColor.black2Color,
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w500),
                                onChanged: (String? newValue) {
                                  setState(() {
                                    account = newValue;
                                    // Update the first bank detail immediately
                                    _updateFirstBankDetail();
                                  });
                                },
                                items: registrationController.accountList
                                    .map<DropdownMenuItem<String>>(
                                        (String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    alignment: Alignment.centerLeft,
                                    child: SingleChildScrollView(
                                      scrollDirection: Axis.horizontal,
                                      child: Text(
                                        value,
                                        style: TextStyle(
                                          color: AppColor.black2Color,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14.sp,
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),

                                icon: Icon(
                                  Icons.keyboard_arrow_down_sharp,
                                  size: 25.w,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Obx(
                        () => SingleSelectDropDown(
                          key: UniqueKey(),
                          labelText: 'Bank Name',
                          valueController: bankNameCtrl,
                          valueTextController: bankNameTextCtrl,
                          enabled: widget.enquiryData != null ? false : true,
                          data: List.generate(
                            registrationController.bankNameList.length,
                            (index) => SingleSelectDropDownModel(
                                registrationController
                                    .bankNameList[index].bankName,
                                registrationController
                                    .bankNameList[index].bankId
                                    .toString()),
                          ),
                          parentOnChangeCall: (value) {
                            // Update the first bank detail immediately when bank name changes
                            _updateFirstBankDetail();
                          },
                        ),
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: CustomTextField(
                              labelText: "IFSC",
                              controller: _ifscController,
                              enabled:
                                  widget.enquiryData != null ? false : true,
                              validator: (val) {
                                if (val == null || val.isEmpty) {
                                  return 'IFSC Code is required';
                                }

                                // IFSC code format: 11 characters (4 alphabets + 0 + 6 alphanumeric)
                                // Pattern: First 4 characters are alphabets, 5th is 0, last 6 are alphanumeric
                                final ifscPattern =
                                    RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$');

                                if (!ifscPattern.hasMatch(val)) {
                                  return 'Invalid IFSC format. ex: ABCD0123456';
                                }

                                return null;
                              },
                              inputFormatters: [
                                // Uppercase formatter
                                UpperCaseTextFormatter(),
                                // // Length and character restriction
                                // FilteringTextInputFormatter.allow(
                                //   RegExp(r'^[A-Z0-9]{0,11}$'),
                                // ),
                                LengthLimitingTextInputFormatter(11),
                              ],
                              textCapitalization: TextCapitalization.characters,
                              maxLength: 11,
                            ),
                          ),
                          SizedBox(
                            width: 15.w,
                          ),
                          Expanded(
                            flex: 2,
                            child: CustomTextField(
                              labelText: "Branch",
                              controller: _branchController,
                              enabled:
                                  widget.enquiryData != null ? false : true,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Branch is required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        labelText: "Account Holder Name",
                        controller: _accountNameController,
                        enabled: widget.enquiryData != null ? false : true,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Account holder Name is required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        contentPadding: EdgeInsets.symmetric(
                            vertical: 10.w, horizontal: 10.w),
                        labelText: "Notes",
                        controller: _notesController,
                        enabled: widget.enquiryData != null ? false : true,
                        maxLines: 3,
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      if (widget.enquiryData == null)
                        InkWell(
                          onTap: () async {
                            // Always update the first bank detail with current form values
                            // Always update the first bank detail with current form values
                            if (bankList.isEmpty) {
                              firstBankDetail.accountType = account!;
                              firstBankDetail.accountNumber =
                                  _accountNumberController.text;
                              firstBankDetail.bank = bankNameTextCtrl.text;
                              firstBankDetail.ifsc = _ifscController.text;
                              firstBankDetail.branchName =
                                  _branchController.text;
                              firstBankDetail.accountName =
                                  _accountNameController.text;
                              firstBankDetail.description =
                                  _notesController.text;
                              bankList.add(firstBankDetail);
                            } else {
                              // Update the first bank detail with current form values
                              bankList[0].accountType = account!;
                              bankList[0].accountNumber =
                                  _accountNumberController.text;
                              bankList[0].bank = bankNameTextCtrl.text;
                              bankList[0].ifsc = _ifscController.text;
                              bankList[0].branchName = _branchController.text;
                              bankList[0].accountName =
                                  _accountNameController.text;
                              bankList[0].description = _notesController.text;
                            }
                            final res =
                                await AppBottomSheets.addAnotherBankDetail(
                              context: context,
                            );
                            if (res != null) {
                              bankList.add(res);
                              setState(() {});
                            }
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                padding: EdgeInsets.all(1.w),
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppColor.orange,
                                ),
                                child: const Icon(
                                  Icons.add,
                                  size: 22.0,
                                  color: AppColor.whiteColor,
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              CustomText(
                                text: "Add Another Bank Detail",
                                color: AppColor.primary2Color,
                                fontSize: AppFontSize.size3,
                                fontWeight: FontWeight.w500,
                                textAlign: TextAlign.end,
                              ),
                            ],
                          ),
                        ),
                      if (widget.enquiryData == null)
                        SizedBox(
                          width: 5.w,
                        ),
                      if (widget.enquiryData == null)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 30.w,
                            ),
                            Container(
                              width: 185.w,
                              padding: EdgeInsets.symmetric(
                                  vertical: 1.w, horizontal: 4.w),
                              decoration: const BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: AppColor.primary2Color,
                              ),
                            ),
                          ],
                        ),
                      if ((bankList.length > 1) && (widget.enquiryData == null))
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            children: List.generate(
                              bankList.length - 1,
                              (index) {
                                // Calculate the bank number starting from 2
                                int bankNumber = index + 2;
                                int indexNumber = index + 1;

                                // Function to get the ordinal suffix
                                String getOrdinalSuffix(int number) {
                                  if (number >= 11 && number <= 13) {
                                    return '${number}th';
                                  }
                                  switch (number % 10) {
                                    case 1:
                                      return '${number}st';
                                    case 2:
                                      return '${number}nd';
                                    case 3:
                                      return '${number}rd';
                                    default:
                                      return '${number}th';
                                  }
                                }

                                return Stack(
                                  children: [
                                    InkWell(
                                      onTap: () async {
                                        var res = await AppBottomSheets
                                            .addAnotherBankDetail(
                                                context: context,
                                                index: indexNumber,
                                                bank: bankList[indexNumber],
                                                bankList: bankList);
                                        if (res != null) {
                                          if (res["isDeleted"] == true) {
                                            int indexValue = res["index"];
                                            bankList.removeAt(indexValue);
                                          } else {
                                            int indexValue = res["index"];
                                            firstBankDetail =
                                                res["firstBankDetail"];
                                            bankList[indexValue].accountType =
                                                firstBankDetail.accountType;
                                            bankList[indexValue].accountNumber =
                                                firstBankDetail.accountNumber;
                                            bankList[indexValue].bank =
                                                firstBankDetail.bank;
                                            bankList[indexValue].ifsc =
                                                firstBankDetail.ifsc;
                                            bankList[indexValue].branchName =
                                                firstBankDetail.branchName;
                                            bankList[indexValue].accountName =
                                                firstBankDetail.accountName;
                                            bankList[indexValue].description =
                                                firstBankDetail.description;
                                          }
                                          setState(() {});
                                        }
                                      },
                                      child: CustomText(
                                        text:
                                            "${getOrdinalSuffix(bankNumber)} Bank, ",
                                        color: AppColor.primary2Color,
                                        fontSize: AppFontSize.size3,
                                        fontWeight: FontWeight.w500,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                      CustomText(
                        text: "Add Images",
                        color: AppColor.primary2Color,
                        fontSize: AppFontSize.size3.sp,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                        height: 10.w,
                      ),
                      ((widget.enquiryData != null) ||
                              (buildingElevationImages.isEmpty))
                          ? showImagePickerBackend(
                              title: 'Building Elevation',
                              imageList: buildingElevationImagesBck,
                              selectedImageList: buildingElevationImages)
                          : buildImagePickerSection(
                              title: 'Building Elevation test',
                              imageList: buildingElevationImages,
                            ),
                      SizedBox(
                        height: 20.w,
                      ),
                      ((widget.enquiryData != null) ||
                              (laboratoryImages.isEmpty))
                          ? showImagePickerBackend(
                              title: 'Laboratory',
                              imageList: laboratoryImagesBck,
                              selectedImageList: laboratoryImages)
                          : buildImagePickerSection(
                              title: 'Laboratory',
                              imageList: laboratoryImages,
                            ),
                      SizedBox(
                        height: 20.w,
                      ),
                      ((widget.enquiryData != null) ||
                              (classRoomImages.isEmpty))
                          ? showImagePickerBackend(
                              title: 'Class Room',
                              imageList: classRoomImagesBck,
                              selectedImageList: classRoomImages)
                          : buildImagePickerSection(
                              title: 'Class Room',
                              imageList: classRoomImages,
                            ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomText(
                        text: "Location",
                        color: AppColor.primary2Color,
                        fontSize: AppFontSize.size3,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                        height: 10.w,
                      ),
                      showMap ? const SizedBox(height: 15.0) : const SizedBox(),
                      showMap
                          ? Stack(
                              children: [
                                SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height / 4.0,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(18.0),
                                          boxShadow: const [
                                            BoxShadow(
                                                color: AppColor.black2Color,
                                                blurRadius: 8.0,
                                                offset: Offset(0, 1))
                                          ]),
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(18.0),
                                        child: GoogleMap(
                                          markers: markers,
                                          zoomGesturesEnabled: true,
                                          zoomControlsEnabled: true,
                                          myLocationEnabled: true,
                                          myLocationButtonEnabled: true,
                                          buildingsEnabled: false,
                                          mapType: MapType.normal,
                                          initialCameraPosition: CameraPosition(
                                            target: getUserPosition,
                                            zoom: 15,
                                          ),
                                          onMapCreated: (GoogleMapController
                                              gmController) {
                                            mapController
                                                .complete(gmController);
                                            setState(() {
                                              nextPosition = true;
                                            });
                                          },
                                          onCameraMoveStarted: () {
                                            // Handle map interaction
                                          },
                                          onCameraIdle: () {
                                            // Handle when map stops moving
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                // Positioned(
                                //   right: 0,
                                //   child: Padding(
                                //     padding: const EdgeInsets.all(20.0),
                                //     child: GestureDetector(
                                //       onTap: () async {
                                //         FocusScope.of(context).unfocus();
                                //         await getMapData(context);
                                //       },
                                //       child: Container(
                                //         padding: const EdgeInsets.all(5.0),
                                //         decoration: BoxDecoration(
                                //             borderRadius: BorderRadius.circular(5.0),
                                //             color: AppColor.primaryColor,
                                //             boxShadow: const [
                                //               BoxShadow(
                                //                 color: Colors.black12,
                                //                 offset: Offset(3, 3),
                                //                 blurRadius: 8.0,
                                //               ),
                                //             ],
                                //             border: Border.all(
                                //                 color: AppColor.whiteColor, width: 1.0)),
                                //         child: Icon(
                                //           Icons.edit,
                                //           color: AppColor.whiteColor,
                                //         ),
                                //       ),
                                //     ),
                                //   ),
                                // )
                              ],
                            )
                          : const SizedBox(),
                      SizedBox(height: 15.w),
                      if (widget.enquiryData == null)
                        InkWell(
                          onTap: () async {
                            FocusScope.of(context).unfocus();
                            await getMapData(context);
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Image.asset(
                                AssetPath.navigate,
                                scale: 22.0,
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              CustomText(
                                text: "Select a location",
                                color: AppColor.primary2Color,
                                fontSize: AppFontSize.size3,
                                fontWeight: FontWeight.w500,
                                textAlign: TextAlign.end,
                              ),
                            ],
                          ),
                        ),
                      if (widget.enquiryData == null)
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 30.w,
                            ),
                            Container(
                              width: 150.w,
                              padding: EdgeInsets.symmetric(
                                  vertical: 1.w, horizontal: 4.w),
                              decoration: const BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: AppColor.primary2Color,
                              ),
                            ),
                          ],
                        ),
                      SizedBox(
                        height: 30.w,
                      ),
                      // previous & next button
                      Padding(
                        padding: EdgeInsets.only(bottom: 25.w),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 150.w,
                              child: OutButton(
                                onTap: () {
                                  navigateIndex(0);
                                },
                                text: 'Previous',
                                color: AppColor.secondaryColor,
                                withArrow: true,
                              ),
                            ),
                            SizedBox(
                              width: 20.w,
                            ),
                            SizedBox(
                              width: 150.w,
                              child: InButton(
                                color: AppColor.primaryColor,
                                withArrow: true,
                                onTap: () {
                                  if (widget.enquiryData == null) {
                                    if (communicationValidForm.currentState!
                                        .validate()) {
                                      if (buildingElevationImages.isEmpty) {
                                        //
                                        Get.snackbar(
                                          'Franchisee Details',
                                          'Please upload your Bulding elevation image to proceed.',
                                          colorText: AppColor.whiteColor,
                                          padding: EdgeInsets.all(15.w),
                                          backgroundColor:
                                              AppColor.primaryColor,
                                        );
                                      } else if (laboratoryImages.isEmpty) {
                                        //
                                        Get.snackbar(
                                          'Franchisee Details',
                                          'Please upload your Laboratory image to proceed.',
                                          colorText: AppColor.whiteColor,
                                          padding: EdgeInsets.all(15.w),
                                          backgroundColor:
                                              AppColor.primaryColor,
                                        );
                                      } else if (classRoomImages.isEmpty) {
                                        //
                                        Get.snackbar(
                                          'Franchisee Details',
                                          'Please upload your Class room image to proceed.',
                                          colorText: AppColor.whiteColor,
                                          padding: EdgeInsets.all(15.w),
                                          backgroundColor:
                                              AppColor.primaryColor,
                                        );
                                      } else if (!showMap) {
                                        //
                                        Get.snackbar(
                                          'Location',
                                          'Please Select your Location',
                                          colorText: AppColor.whiteColor,
                                          padding: EdgeInsets.all(15.w),
                                          backgroundColor:
                                              AppColor.primaryColor,
                                        );
                                      } else {
                                        // Always ensure the first bank detail has current values
                                        if (bankList.isEmpty) {
                                          firstBankDetail.accountType =
                                              account!;
                                          firstBankDetail.accountNumber =
                                              _accountNumberController.text;
                                          firstBankDetail.bank =
                                              bankNameTextCtrl.text;
                                          firstBankDetail.ifsc =
                                              _ifscController.text;
                                          firstBankDetail.branchName =
                                              _branchController.text;
                                          firstBankDetail.accountName =
                                              _accountNameController.text;
                                          firstBankDetail.description =
                                              _notesController.text;
                                          bankList.add(firstBankDetail);
                                        } else {
                                          // Update existing first bank detail
                                          bankList[0].accountType = account!;
                                          bankList[0].accountNumber =
                                              _accountNumberController.text;
                                          bankList[0].bank =
                                              bankNameTextCtrl.text;
                                          bankList[0].ifsc =
                                              _ifscController.text;
                                          bankList[0].branchName =
                                              _branchController.text;
                                          bankList[0].accountName =
                                              _accountNameController.text;
                                          bankList[0].description =
                                              _notesController.text;
                                        }
                                        setState(() {});
                                        _bankTabController = TabController(
                                            length: bankList.length,
                                            vsync: this);

                                        //
                                        debugPrint(
                                            'Franchisee Detail Details Validated!! ');
                                        // if all fields are validated successfully navigate to Address Details
                                        navigateIndex(2);
                                      }
                                    }
                                  } else {
                                    if (buildingElevationImages.isEmpty) {
                                      //
                                      Get.snackbar(
                                        'Franchisee Details',
                                        'Please upload your Bulding elevation image to proceed.',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    } else if (laboratoryImages.isEmpty) {
                                      //
                                      Get.snackbar(
                                        'Franchisee Details',
                                        'Please upload your Laboratory image to proceed.',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    } else if (classRoomImages.isEmpty) {
                                      //
                                      Get.snackbar(
                                        'Franchisee Details',
                                        'Please upload your Class room image to proceed.',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    } else {
                                      _bankTabController = TabController(
                                          length: bankList.length, vsync: this);

                                      //
                                      debugPrint(
                                          'Franchisee Detail Details Validated!! ');
                                      // if all fields are validated successfully navigate to Address Details
                                      navigateIndex(2);
                                    }
                                  }
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ],
          ),
        ),
      );
    });
  }

  // confirm details tab
  Widget confirmDetails() {
    return StatefulBuilder(builder: (context, confirmDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: studentDetailsForm,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  height: 30.w,
                ),
                // profile picture
                Center(
                  child: InkWell(
                      onTap: () async {},
                      child: selectedImage == null
                          ? Stack(
                              children: [
                                Image.asset(
                                  AssetPath.uploadProfile,
                                  scale: 4,
                                ),
                              ],
                            )
                          : Stack(
                              children: [
                                ClipOval(
                                  child: Image.file(
                                    selectedImage!,
                                    width: 130.w,
                                    height: 130.w,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            )),
                ),
                SizedBox(
                  height: 10.w,
                ),
                // profile picture
                SizedBox(
                  height: 20.w,
                ),
                CustomText(
                  text: 'Registration Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      CentreListTile(
                        assetName: AssetPath.owner,
                        title: 'Name',
                        subTitle: nameCtrl.text,
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.gender,
                        title: 'Gender',
                        subTitle: genderCtrl.text,
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.mobile,
                        title: 'Mobile',
                        subTitle: '+91 ${mobileCtrl.text}',
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.mobile,
                        title: 'Alternate Mobile',
                        subTitle: '+91 ${altMobCtrl.text}',
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.mail,
                        title: 'Email ID',
                        subTitle: emailCtrl.text,
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Franchisee Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      const CentreListTile(
                        assetName: AssetPath.company,
                        title: 'Franchisee Name',
                        subTitle: "TCDS Computer Education",
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.location,
                        title: 'Communication Address',
                        subTitle:
                            '${comAddress1Ctrl.text} ${comAddress2Ctrl.text}    \n ${comAreaCtrl.text} \n ${districtTextCtrl.text} ${stateTextCtrl.text} \n ${countryTextCtrl.text}-${pincodeCtrl.text} ',
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Bank Account Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      TabBar(
                        controller: _bankTabController,
                        tabs: List<Widget>.generate(
                          bankList.isNotEmpty ? bankList.length : 1,
                          (index) {
                            return Tab(
                              text: bankList[index].bank,
                              // Assuming 'name' is a field in your course object
                            );
                          },
                        ),
                        isScrollable: true,
                        tabAlignment: TabAlignment.center,
                        indicatorColor: Colors.orange,
                        labelColor: AppColor.blackColor,
                        unselectedLabelColor: Colors.grey,
                      ),
                      SizedBox(
                        height: 330,
                        // Adjust the height for TabBarView
                        child: TabBarView(
                          controller: _bankTabController,
                          children: List<Widget>.generate(
                            bankList.isNotEmpty ? bankList.length : 1,
                            (index) {
                              return SingleChildScrollView(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CentreListTile(
                                      assetName: AssetPath.owner,
                                      title: "Account Holder Name",
                                      subTitle: bankList[index].accountName,
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.bank,
                                      title: "Bank Name",
                                      subTitle: bankList[index].bank,
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.company,
                                      title: "Account Number",
                                      subTitle: bankList[index]
                                          .accountNumber
                                          .toString(),
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.location,
                                      title: "IFSC/Branch",
                                      subTitle:
                                          "${bankList[index].ifsc} ${bankList[index].branchName} ",
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.notes,
                                      title: "Notes",
                                      subTitle: bankList[index].description,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Attachments',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                    child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      showImagePickerSection(
                        title: 'Building Elevation',
                        imageList: buildingElevationImages,
                      ),
                      showImagePickerSection(
                        title: 'Laboratory',
                        imageList: laboratoryImages,
                      ),
                      showImagePickerSection(
                        title: 'Classroom',
                        imageList: classRoomImages,
                      ),
                    ],
                  ),
                )),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Location',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                Stack(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 4.0,
                      child: Padding(
                        padding: const EdgeInsets.all(5),
                        child: Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18.0),
                              boxShadow: const [
                                BoxShadow(
                                    color: AppColor.black2Color,
                                    blurRadius: 8.0,
                                    offset: Offset(0, 1))
                              ]),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(18.0),
                            child: GoogleMap(
                              markers: markers,
                              zoomGesturesEnabled: true,
                              zoomControlsEnabled: true,
                              myLocationEnabled: true,
                              myLocationButtonEnabled: true,
                              buildingsEnabled: false,
                              mapType: MapType.normal,
                              initialCameraPosition: CameraPosition(
                                target: getUserPosition,
                                zoom: 15,
                              ),
                              onMapCreated: (GoogleMapController gmController) {
                                mapController.complete(gmController);
                                setState(() {
                                  nextPosition = true;
                                });
                              },
                              onCameraMoveStarted: () {
                                // Handle map interaction
                              },
                              onCameraIdle: () {
                                // Handle when map stops moving
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(
                  height: 30.w,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 150.w,
                      child: OutButton(
                        onTap: () {
                          navigateIndex(1);
                        },
                        text: 'Back',
                        color: AppColor.secondaryColor,
                      ),
                    ),
                    SizedBox(
                      width: 20.w,
                    ),
                    SizedBox(
                      width: 150.w,
                      child: InButton(
                        color: AppColor.primaryColor,
                        text: 'Submit',
                        onTap: () async {
                          // variable to send documnt id's as list

                          // Check if profile image exists before processing
                          if (selectedImage == null ||
                              !selectedImage!.existsSync()) {
                            Get.snackbar(
                              'Image Error',
                              'Profile image is missing. Please select your profile picture again.',
                              colorText: AppColor.whiteColor,
                              padding: EdgeInsets.all(15.w),
                              backgroundColor: AppColor.primaryColor,
                            );
                            return;
                          }

                          File file = selectedImage!;
                          debugPrint(file.path);
                          List<String> parts = file.path.split("/");

                          String fileName = parts.last;
                          debugPrint(fileName);
                          debugPrint('File name $fileName');
                          String extention =
                              file.path.split('.').last.toLowerCase();
                          debugPrint('Extention $extention');
                          Map<String, dynamic> formFields = {
                            "EntityName": "Profile",
                            "ownerImage": await dio.MultipartFile.fromFile(
                              file.path,
                              filename: fileName,
                              contentType: media.MediaType(
                                extention.toLowerCase() == 'pdf'
                                    ? 'application'
                                    : 'image',
                                extention,
                              ),
                            ),
                            "contactTitle": genderTitleCtrl.text,
                            "contactName": nameCtrl.text,
                            "gender": genderCtrl.text,
                            "phoneCode": mobileCodeCtrl.text,
                            "phone": widget.enquiryData == null
                                ? mobileCtrl.text
                                : mobileCtrl.text.split(' ')[1],
                            if (altMobCtrl.text.isNotEmpty)
                              "alternatePhoneCode": altMobCodeCtrl.text,
                            if (altMobCtrl.text.isNotEmpty)
                              "alternatePhone": widget.enquiryData == null
                                  ? altMobCtrl.text
                                  : altMobCtrl.text.split(' ')[1],
                            "email": emailCtrl.text,
                            "taluk": talukCtrl.text,
                            "franchiseeName": "TCDS Computer Education",
                            "address1": comAddress1Ctrl.text,
                            "address2": comAddress2Ctrl.text,
                            "area": comAreaCtrl.text,
                            "country": countryTextCtrl.text,
                            "state": stateTextCtrl.text,
                            "district": districtTextCtrl.text,
                            "pincode": pincodeCtrl.text,
                            "latitude": getUserPosition.latitude,
                            "longitude": getUserPosition.longitude,
                            if (widget.enquiryData == null)
                              "EmailOTPTransID": registrationController
                                  .requestedOTP[0].emailOtpTransId
                          };

                          // Loop through the bankList and add the required fields dynamically
                          for (int i = 0; i < bankList.length; i++) {
                            BankDetails bank = bankList[i];

                            formFields.addAll({
                              "bankAccount[$i][AccountType]": bank.accountType,
                              "bankAccount[$i][AccountName]": bank.accountName,
                              "bankAccount[$i][AccountNumber]":
                                  bank.accountNumber.toString(),
                              "bankAccount[$i][Bank]": bank.bank,
                              "bankAccount[$i][IFSC]": bank.ifsc,
                              "bankAccount[$i][Description]": bank.description,
                              "bankAccount[$i][BranchName]": bank.branchName,
                            });
                          }

                          // log("Form Fields $formFields");

                          dio.FormData formData =
                              dio.FormData.fromMap(formFields);

                          // print(formData.fields);
                          // debugPrint('Form data ${formData.boundary}');
                          for (File imageFile in buildingElevationImages) {
                            // Check if file exists before processing
                            if (!imageFile.existsSync()) {
                              Get.snackbar(
                                'Image Error',
                                'Building elevation image is missing. Please select the images again.',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                              return;
                            }

                            String filePath = imageFile.path;
                            List<String> parts = filePath.split("/");
                            String fileName = parts.last;
                            String extention =
                                filePath.split('.').last.toLowerCase();

                            // Add document image to form data
                            formData.files.add(MapEntry(
                              "outletImage", // Key for document images
                              await dio.MultipartFile.fromFile(
                                filePath,
                                filename: fileName,
                                contentType: media.MediaType(
                                  extention.toLowerCase() == 'pdf'
                                      ? 'application'
                                      : 'image',
                                  extention,
                                ),
                              ),
                            ));
                          }
                          for (File imageFile in laboratoryImages) {
                            // Check if file exists before processing
                            if (!imageFile.existsSync()) {
                              Get.snackbar(
                                'Image Error',
                                'Laboratory image is missing. Please select the images again.',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                              return;
                            }

                            String filePath = imageFile.path;
                            List<String> parts = filePath.split("/");
                            String fileName = parts.last;
                            String extention =
                                filePath.split('.').last.toLowerCase();

                            // Add document image to form data
                            formData.files.add(MapEntry(
                              "laboratoryImage", // Key for document images
                              await dio.MultipartFile.fromFile(
                                filePath,
                                filename: fileName,
                                contentType: media.MediaType(
                                  extention.toLowerCase() == 'pdf'
                                      ? 'application'
                                      : 'image',
                                  extention,
                                ),
                              ),
                            ));
                          }
                          for (File imageFile in classRoomImages) {
                            // Check if file exists before processing
                            if (!imageFile.existsSync()) {
                              Get.snackbar(
                                'Image Error',
                                'Class room image is missing. Please select the images again.',
                                colorText: AppColor.whiteColor,
                                padding: EdgeInsets.all(15.w),
                                backgroundColor: AppColor.primaryColor,
                              );
                              return;
                            }

                            String filePath = imageFile.path;
                            List<String> parts = filePath.split("/");
                            String fileName = parts.last;
                            String extention =
                                filePath.split('.').last.toLowerCase();

                            // Add document image to form data
                            formData.files.add(MapEntry(
                              "classRoomImage", // Key for document images
                              await dio.MultipartFile.fromFile(
                                filePath,
                                filename: fileName,
                                contentType: media.MediaType(
                                  extention.toLowerCase() == 'pdf'
                                      ? 'application'
                                      : 'image',
                                  extention,
                                ),
                              ),
                            ));
                          }
                          // Open please wait loader
                          PleaseWaitLoader.openDialog();
                          // Calling Profile Upload Api
                          await registrationController
                              .registerFranchise(formData: formData)
                              .then(
                            (value) async {
                              // Close please wait loader
                              PleaseWaitLoader.closeDialog();

                              if (value) {
                                Get.offAllNamed(Routes.registrationStatus);
                              }
                            },
                          );

                          // bool value = await registerController.createUser(
                          //     body: requestBody);
                          // debugPrint(value.toString());
                          // if (value) {
                          // Get.toNamed(Routes.registrationStatus);
                          // }
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30.w,
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // stepper widget
  Widget stepper({required int stepCount}) {
    return Row(
      children: [
        // show stepper widgets with some conditions to match stepper effect
        Flexible(
          child: StepperPattern(
            title: "Registrant Details",
            isActive: stepCount == 1,
            stepNumber: "1",
            leftDividerColor: null,
            rightDividerColor: stepCount > 1 ? AppColor.primaryColor : null,
            withLeftDivider: false,
          ),
        ),
        Flexible(
          child: StepperPattern(
            title: "Franchisee Details",
            isActive: stepCount == 2,
            leftDividerColor: stepCount > 1 ? AppColor.primaryColor : null,
            rightDividerColor: stepCount > 2 ? AppColor.primaryColor : null,
            stepNumber: "2",
          ),
        ),
        Flexible(
          child: StepperPattern(
            title: "Confirmation",
            isActive: stepCount == 3,
            leftDividerColor: stepCount > 2 ? AppColor.primaryColor : null,
            rightDividerColor: null,
            stepNumber: "3",
            withRightDivider: false,
          ),
        ),
      ],
    );
  }

  Widget buildImagePickerSection({
    required String title,
    required List<File> imageList,
  }) {
    return GreyBox(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              text: title,
              color: AppColor.black2Color,
              fontSize: AppFontSize.size4,
            ),
            Container(
              decoration: BoxDecoration(
                  color: AppColor.grey3,
                  borderRadius: BorderRadius.circular(10.r)),
              child: Row(
                children: [
                  InkWell(
                    onTap: () async {
                      await pickImages(imageList);
                      setState(() {});
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(
                          horizontal: 10.w, vertical: 10.w),
                      width: 110.w,
                      height: 110.w,
                      child: DottedBorder(
                        radius: Radius.circular(10.r),
                        borderType: BorderType.rRect,
                        child: Image.asset(
                          AssetPath.addPhotoIcon,
                          scale: 13.00,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          imageList.length,
                          (index) => Stack(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                    right: 10.w, top: 10.w, bottom: 10.w),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: AppColor.black2Color)),
                                child: Image.file(
                                  imageList[index],
                                  width: 110.w,
                                  height: 110.w,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: InkWell(
                                  onTap: () {
                                    imageList.removeAt(index);
                                    setState(() {});
                                  },
                                  child: Container(
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColor.whiteColor,
                                    ),
                                    child: Icon(
                                      Icons.remove_circle_outlined,
                                      color: AppColor.redColor,
                                      size: 30.w,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget showImagePickerSection({
    required String title,
    required List<File> imageList,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          text: title,
          color: AppColor.titleColor,
          fontWeight: FontWeight.w600,
        ),
        Row(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    imageList.length,
                    (index) => Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                              right: 10.w, top: 10.w, bottom: 10.w),
                          decoration: BoxDecoration(
                              border: Border.all(color: AppColor.black2Color)),
                          child: Image.file(
                            imageList[index],
                            width: 110.w,
                            height: 110.w,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> getMapData(context) async {
    // var permission = await Permission.location.status;
    var result = await permissionStatus(context);
    if (result) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) =>
              const GetMapView(position: LatLng(11.673990, 78.128216)),
        ),
      );
      debugPrint(" value: $result");
      if (result != null) {
        getUserPosition = result["markPosition"];
        showMap = result["showMap"];
        markers.clear();

        placeMark = await placemarkFromCoordinates(
          getUserPosition.latitude,
          getUserPosition.longitude,
        );
        // areaNameController.text = placeMark[0].subLocality;
        // districtNameController.text = placeMark[0].locality;
        // stateNameController.text = placeMark[0].administrativeArea;
        // postalCodeController.text = placeMark[0].postalCode;
        // setState(() {});

        markers.add(
          Marker(
            markerId: const MarkerId(''),
            position:
                LatLng(getUserPosition.latitude, getUserPosition.longitude),
          ),
        );
        if (nextPosition) {
          final GoogleMapController controller = await mapController.future;
          controller.animateCamera(
            CameraUpdate.newCameraPosition(
              CameraPosition(target: getUserPosition, zoom: 14),
            ),
          );
        }
        setState(() {});
        // locationPick =
        //     getUserPosition.toString().replaceAll(RegExp(r"[^\d.,-]+"), '');
      }
    } else {
      await Permission.location.request().isGranted;
    }
  }

  Future<bool> permissionStatus(BuildContext context) async {
    var status = await Permission.location.status;
    if (status.isGranted) {
      return true;
    } else {
      if (await Permission.location.request().isGranted) {
        return true;
      } else {
        return false;
      }
    }
  }

  void _startTimer({required int seconds}) {
    _secondsRemaining.value = seconds;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining.value > 0) {
        _secondsRemaining.value--;
      } else {
        timer.cancel();
      }
    });
  }

  Widget showImagePickerBackend({
    required String title,
    required List<FranchiseeImg> imageList,
    required List<File> selectedImageList,
  }) {
    return GreyBox(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: title,
            color: AppColor.titleColor,
            fontWeight: FontWeight.w600,
          ),
          Row(
            children: [
              InkWell(
                onTap: () async {
                  FocusScope.of(context).requestFocus(FocusNode());
                  await pickImages(selectedImageList);
                  debugPrint("${selectedImageList.length}");
                  setState(() {});
                },
                child: Container(
                  margin:
                      EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.w),
                  width: 110.w,
                  height: 110.w,
                  child: DottedBorder(
                    radius: Radius.circular(10.r),
                    borderType: BorderType.rRect,
                    child: Image.asset(
                      AssetPath.addPhotoIcon,
                      scale: 13.00,
                    ),
                  ),
                ),
              ),
              selectedImageList.isEmpty
                  ? Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: List.generate(
                            imageList.length,
                            (index) => Stack(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(
                                        right: 10.w, top: 10.w, bottom: 10.w),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: AppColor.black2Color)),
                                    child: Image.memory(
                                      base64Decode(
                                          imageList[index].fetchedBase64!),
                                      height: 100.w,
                                      width: 100.w,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) =>
                                              Image.asset(
                                        AssetPath.defaultProfile,
                                        height: 100.w,
                                        width: 100.w,
                                        fit: BoxFit.cover,
                                      ),
                                    )),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  : Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: List.generate(
                            selectedImageList.length,
                            (index) => Stack(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(
                                      right: 10.w, top: 10.w, bottom: 10.w),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppColor.black2Color)),
                                  child: Image.file(
                                    selectedImageList[index],
                                    width: 110.w,
                                    height: 110.w,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Positioned(
                                  right: 0,
                                  top: 0,
                                  child: InkWell(
                                    onTap: () {
                                      selectedImageList.removeAt(index);
                                      setState(() {});
                                    },
                                    child: Container(
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: AppColor.whiteColor,
                                      ),
                                      child: Icon(
                                        Icons.remove_circle_outlined,
                                        color: AppColor.redColor,
                                        size: 30.w,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
            ],
          ),
        ],
      ),
    );
  }

  // Method to update the first bank detail in real-time
  void _updateFirstBankDetail() {
    if (bankList.isNotEmpty) {
      bankList[0].accountType = account ?? '';
      bankList[0].accountNumber = _accountNumberController.text;
      bankList[0].bank = bankNameTextCtrl.text;
      bankList[0].ifsc = _ifscController.text;
      bankList[0].branchName = _branchController.text;
      bankList[0].accountName = _accountNameController.text;
      bankList[0].description = _notesController.text;

      // Update the main controllers to keep them in sync
      bankNameTextCtrl.text = bankNameTextCtrl.text;
    }
  }

  void _showExitDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Are you sure you want to go back?"),
          actions: [
            TextButton(
              onPressed: () {
                // Close the dialog and navigate back
                Get.to(const LoginScreen());
              },
              child: const Text("Yes"),
            ),
            TextButton(
              onPressed: () {
                // Close the dialog and stay on the current page
                Navigator.of(context).pop();
              },
              child: const Text("No"),
            ),
          ],
        );
      },
    );
  }
}
