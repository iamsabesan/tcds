// ignore_for_file: unnecessary_null_comparison

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../constants/colors.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../controller/registration_controller.dart';

class GetMapView extends StatefulWidget {
  final LatLng position;

  const GetMapView({super.key, required this.position});

  @override
  State<GetMapView> createState() => _GetMapViewState();
}

class _GetMapViewState extends State<GetMapView> {
  late LatLng getUserPosition;
  RegistrationController registerController =
      Get.find<RegistrationController>();
  Future<void> getMapData(context) async {
    var permission = await Permission.location.status;
    if (permission.isGranted) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => GetMapView(position: getUserPosition),
        ),
      );
      setState(() {
        getUserPosition = result;
      });
      markers.add(
        Marker(
          markerId: const MarkerId(''),
          position: LatLng(getUserPosition.latitude, getUserPosition.longitude),
        ),
      );
    } else {
      await Permission.location.request().isGranted;
    }
    if (!mounted) return;
    setState(() {});
  }

  Set<Marker> markers = {};
  bool isLocated = false;
  final Completer<GoogleMapController> mapController =
      Completer<GoogleMapController>();
  late LatLng markPosition;
  LatLng defLatLng = const LatLng(0.0, 0.0);

  @override
  void initState() {
    markers.clear();
    markers.add(
      Marker(
        markerId: const MarkerId('User Location'),
        icon: BitmapDescriptor.defaultMarker,
        position: LatLng(widget.position.latitude, widget.position.longitude),
      ),
    );
    markPosition = widget.position;
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () {
        return Future.value(true);
      },
      child: Scaffold(
        extendBody: true,
        appBar: AppBar(
          backgroundColor: AppColor.whiteColor,
          leading: InkWell(
            splashColor: AppColor.black2Color,
            onTap: () {
              Get.back();
            },
            child: Icon(
              Icons.arrow_back_ios_new_outlined,
              size: 30.w,
            ),
          ),
          title: CustomText(
            text: "Select Location",
            fontSize: 16.sp,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        body: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  Expanded(
                    flex: 70,
                    child: GoogleMap(
                      markers: markers,
                      myLocationButtonEnabled: true,
                      myLocationEnabled: true,
                      buildingsEnabled: false,
                      cameraTargetBounds: CameraTargetBounds.unbounded,
                      zoomGesturesEnabled: true,
                      zoomControlsEnabled: true,
                      mapType: MapType.normal,
                      onTap: (mark) async {
                        markers.clear();
                        Marker m = Marker(
                          markerId: const MarkerId('1'),
                          position: mark,
                          icon: BitmapDescriptor.defaultMarker,
                        );
                        markers.add(m);

                        registerController.lat.value = mark.latitude.toString();
                        registerController.long.value =
                            mark.longitude.toString();
                        setState(() {
                          markPosition = mark;
                        });
                      },
                      initialCameraPosition: CameraPosition(
                        target: widget.position == null
                            ? defLatLng
                            : LatLng(
                                widget.position.latitude,
                                widget.position.longitude,
                              ),
                        zoom: widget.position == null ? 0.0 : 15.0,
                      ),
                      onMapCreated: (GoogleMapController gmController) async {
                        mapController.complete(gmController);
                        setState(() {});
                      },
                      onCameraMoveStarted: () {
                        // Handle map interaction
                      },
                      onCameraIdle: () {
                        // Handle when map stops moving
                      },
                    ),
                  ),
                  Expanded(
                    flex: 15,
                    child: SizedBox(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20.w),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 150.w,
                                      child:
                                          // Obx(() {
                                          //   registerController.lat.value="";
                                          //   registerController.long.value="";
                                          //  return
                                          InButton(
                                        text: "Confirm Location",
                                        withArrow: false,
                                        onTap: () {
                                          // Access observable variables inside onTap

                                          registerController.lat.value =
                                              markPosition.latitude.toString();
                                          registerController.long.value =
                                              markPosition.longitude.toString();
                                          final result = {
                                            'markPosition': markPosition,
                                            'showMap': true,
                                          };

                                          Navigator.pop(context, result);
                                        },
                                      ),
                                      //  ;
                                      // }
                                      // ),
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            // SizedBox(height: 20.w,),
                            // SizedBox(
                            //   width: 150.w,
                            //   child: InButton(
                            //     text: "Confirm Location",
                            //     withArrow: false,
                            //     onTap: () {
                            //       registerController.lat.value=markPosition.latitude.toString();
                            //       registerController.long.value=markPosition.longitude.toString();
                            //       Navigator.pop(context, markPosition);
                            //     },
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              // Positioned(
              //   right: 10,
              //   bottom: 100,
              //   child: GestureDetector(
              //     onTap: () async {
              //       // Request location permission
              //       await requestPermission();
              //
              //       // Check if permission is granted
              //       PermissionStatus status = await Permission.location.status;
              //       if (status.isGranted) {
              //         try {
              //           Position position = await Geolocator.getCurrentPosition();
              //           markPosition = LatLng(position.latitude, position.longitude);
              //           setState(() {
              //             markers.clear();
              //           });
              //           markers.add(
              //             Marker(
              //               markerId: const MarkerId('current_position'),
              //               position: LatLng(11.673990,78.128216),
              //             ),
              //           );
              //
              //           final GoogleMapController controllerMap = await mapController.future;
              //           controllerMap.animateCamera(
              //             CameraUpdate.newCameraPosition(
              //               CameraPosition(
              //                 target: LatLng(11.673990,78.128216),
              //                 zoom: 15,
              //               ),
              //             ),
              //           );
              //         } catch (e) {
              //           print('Error: $e');
              //         }
              //       } else {
              //         // Handle permission denial, maybe show a dialog to inform the user
              //         print('Permission denied');
              //       }
              //     },
              //
              //
              //     child: Container(
              //       decoration: const BoxDecoration(
              //           color: Colors.white,
              //           shape: BoxShape.circle,
              //           boxShadow: [
              //             BoxShadow(color: Colors.grey, blurRadius: 8.0),
              //           ]),
              //       padding: const EdgeInsets.all(13.0),
              //       child: const Icon(
              //         Icons.my_location,
              //       ),
              //     ),
              //   ),
              // ),
              Positioned(
                right: 20,
                bottom: 250,
                child: locationUpdateButton(context),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget locationUpdateButton(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        // Request location permission
        await requestPermission();

        // Check if permission is granted
        PermissionStatus status = await Permission.location.status;
        if (status.isGranted) {
          try {
            Position position = await Geolocator.getCurrentPosition();
            markPosition = LatLng(position.latitude, position.longitude);
            setState(() {
              markers.clear();
            });
            markers.add(
              const Marker(
                markerId: MarkerId('current_position'),
                position: LatLng(11.673990, 78.128216),
              ),
            );

            final GoogleMapController controllerMap =
                await mapController.future;
            controllerMap.animateCamera(
              CameraUpdate.newCameraPosition(
                const CameraPosition(
                  target: LatLng(11.673990, 78.128216),
                  zoom: 15,
                ),
              ),
            );
          } catch (e) {
            debugPrint('Error: $e');
          }
        } else {
          // Handle permission denial, maybe show a dialog to inform the user
          debugPrint('Permission denied');
        }
      },
      // Navigator.pop(context, markPosition);
      child: Container(
        decoration: const BoxDecoration(color: Colors.white, boxShadow: [
          BoxShadow(color: Colors.grey, blurRadius: 8.0),
        ]),
        padding: const EdgeInsets.all(8.0),
        child: const Row(
          children: [
            Icon(
              Icons.my_location,
              color: Colors.orange,
              size: 40.0,
            ),
            SizedBox(width: 8.0), // Space between icon and text
            Text(
              'Use My Current Location', // Your text
              style: TextStyle(
                color: AppColor.blackColor,
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> requestPermission() async {
    PermissionStatus status = await Permission.location.request();

    if (status.isGranted) {
      debugPrint('Location permission granted');
    } else {
      debugPrint('Location permission denied');
    }
  }
}
