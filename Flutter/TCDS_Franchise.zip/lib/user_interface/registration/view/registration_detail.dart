/* import 'dart:async';

import 'dart:io';

import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:http_parser/http_parser.dart' as media;
import 'package:dio/dio.dart' as dio;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/shared_preference.dart';
import 'package:tcds/user_interface/login/controller/login_controller.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/registration/model/request_otp_response_model.dart';
import 'package:tcds/utils/helper_functions/common_dialogs.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';

class RegistrationDetailForm extends StatefulWidget {
  // final TextEditingController nameCtrl;

  // final TextEditingController genderCtrl;
  // final TextEditingController mobileCtrl;
  // final TextEditingController altMobileCtrl;
  // final TextEditingController emailCtrl;

  final GlobalKey<FormState> formKey;

  const RegistrationDetailForm({
    super.key,
    required this.formKey,
    // required this.nameCtrl,
    // required this.genderCtrl,
    // required this.mobileCtrl,
    // required this.altMobileCtrl,
    // required this.emailCtrl,
  });

  @override
  State<RegistrationDetailForm> createState() => _RegistrationDetailFormState();
}

class _RegistrationDetailFormState extends State<RegistrationDetailForm> {
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  GlobalKey<FormState> mailKey = GlobalKey<FormState>();

  RegistrationController registrationController =
      Get.put(RegistrationController());

  // find login controller
  LoginController loginController = Get.find<LoginController>();

  String? emailErrorText;
  String? verificationErrorText;

  final Map<String, dynamic> _formData = {};

  RequestOTPData? requestOTPResponse;

  TextEditingController nameCtrl = TextEditingController();
  TextEditingController genderCtrl = TextEditingController();
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController genderTextCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController altMobileCtrl = TextEditingController();
  TextEditingController altMobileCodeCtrl = TextEditingController();
  TextEditingController verificationCodeCtrl = TextEditingController();

  @override
  void initState() {
    registrationController.getPhoneCodes();
    registrationController.getGenderTypes();
    super.initState();
  }

  bool isVerificationStage = false;

  String email = '';

  int timerDuration = 20;

  // 3 minutes in seconds
  Timer? timer;

  void startTimer() {
    timer?.cancel(); // Cancel any existing timer
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (timerDuration > 0) {
        setState(() {
          timerDuration--;
        });
      } else {
        timer.cancel();
      }
    });
  }

  void resetTimer() {
    setState(() {
      timerDuration = 180;
    });
    startTimer();
  }

  void requestOtp() {
    String value;
    value = emailCtrl.text;

    if (emailErrorText == null) {
      try {
        PleaseWaitLoader.openDialog();
        // call guest login before request OTP cause to find database from backend
        loginController
            .getAuth(password: "India_123", loginName: 'tcdsguest@gmail.com')
            .then(
          (res) {
            // if guest login successful
            if (res) {
              // set logged in status as bool to prevent opening dashboard since we logged in using guest acc
              SharedPreference.putBool(AppStrings.isLoggedIn, false);
              // request mobile OTP
              //test mail : kannanece44@gmail.com
              registrationController.requestOTP(body: {"Email": value}).then(
                (res) {
                  PleaseWaitLoader.closeDialog();
                  if (res) {
                    setState(() {
                      email = emailCtrl.text;
                      isVerificationStage = true;
                    });
                    resetTimer();
                  }
                },
              );
            }
            //
          },
        );
      } catch (e) {
        debugPrint('Forgot PS catch $e');
      }
    }
  }

  void verifyOtp(String otp) {
    PleaseWaitLoader.openDialog();
    verificationErrorText = null;
    timer!.cancel();
    try {
      registrationController.verifyOTP(body: {
        "EmailOTPTransID": registrationController.requestOTPResponse == null
            ? ''
            : registrationController.requestOTPResponse!.emailOtpTransId
                .toString(),
        "EmailOTPCode": verificationCodeCtrl.text,
      }).then(
        (res) {
          PleaseWaitLoader.closeDialog();
          if (!mounted) return;
          showSuccessDialog(
              context: context, message: 'OTP Verified Successfully!');
        },
      );
    } catch (e) {
      debugPrint('While Verify OTP -> $e');
    }
    setState(() {
      isVerificationStage = false; // Go back to the original stage or proceed
    });
  }

  // file pick function
  Future<FilePickerResult?> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'png', 'jpeg'],
    );
    if (result != null) {
      PlatformFile file = result.files.single;
      String fileExtension = file.extension?.toLowerCase() ?? '';
      // check if any extention type selected
      // check if file size exceeds 2 mb
      if (!['jpg', 'png', 'jpeg'].contains(fileExtension)) {
        showInformationDialog(
          context: Get.context!,
          message: 'Invalid file type. Please select a JPG, PNG, or JPEG file.',
        );
        return null;
      } else if (file.size > 2 * 1024 * 1024) {
        // File size exceeds 2MB
        showInformationDialog(
            context: Get.context!,
            message: 'File size exceeds 2MB. Please choose a smaller file.');
        return null;
      } else {
        debugPrint('File picked: ${file.path}');
        return result;
      }
    } else {
      debugPrint('No file picked');
      return null;
    }
  }

  File? _imageFile;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    // String timerText = "${(timerDuration ~/ 60).toString().padLeft(2, '0')}:${(timerDuration % 60).toString().padLeft(2, '0')} min";
    return SingleChildScrollView(
      padding: EdgeInsets.all(15.w),
      child: Form(
        key: widget.formKey,
        child: Column(
          children: [
            SizedBox(
              height: width * 0.35,
              child: Center(
                child: InkWell(
                  borderRadius: BorderRadius.circular(60.r),
                  onTap: () async {
                    // Upload profile image
                    FilePickerResult? result = await _pickFile();

                    if (result != null) {
                      File file = File(result.files.single.path!);
                      String fileName = result.files.single.name;
                      debugPrint(fileName);

                      // Optionally handle the Dio file upload here
                      dio.MultipartFile.fromFile(
                        file.path,
                        filename: fileName,
                        contentType: media.MediaType(
                          'image',
                          file.path.split('.').last.toLowerCase(),
                        ),
                      );

                      // Update the state with the selected image
                      setState(() {
                        _imageFile = file;
                      });
                    }
                  },
                  child: Stack(
                    children: [
                      // Profile image
                      CircleAvatar(
                        backgroundColor: AppColor.whiteColor,
                        maxRadius: 60.w,
                        minRadius: 55.w,
                        child: Container(
                          constraints: const BoxConstraints.expand(),
                          clipBehavior: Clip.hardEdge,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColor.lightWhite,
                          ),
                          child: _imageFile == null
                              ? Image.asset(
                                  AssetPath.userIcon,
                                  color: AppColor.greyColor,
                                  fit: BoxFit.contain,
                                )
                              : Image.file(
                                  _imageFile!, // Display the selected image file
                                  fit: BoxFit.cover,
                                ),
                        ),
                      ),
                      // Camera icon
                      // if (_imageFile == null)
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Container(
                          padding: EdgeInsets.all(5.w),
                          height: (width * 0.30) * 0.38,
                          width: (width * 0.30) * 0.38,
                          child: Image.asset(
                            AssetPath.cameraIcon,
                            color: AppColor.primary2Color,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 30.w),
            Row(
              children: [
                Expanded(
                  flex: 4,
                  child: CustomTextField(
                    labelText: "Name",
                    onSaved: (value) => _formData['name'] = value,
                    prefixIcon: Image.asset(
                      AssetPath.userIcon,
                      scale: 25.0,
                      color: AppColor.orange,
                    ),
                    controller: nameCtrl,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return "Name is required";
                      } else {
                        return null;
                      }
                    },
                  ),
                ),
                SizedBox(
                  width: 15.w,
                ),
                Expanded(
                  flex: 2,
                  child: Obx(
                    () => SingleSelectDropDown(
                      key: UniqueKey(),
                      labelText: 'Gender',
                      valueController: genderCtrl,
                      valueTextController: genderTextCtrl,
                      filled: false,
                      validator: (val) {
                        if (val != null && val.isEmpty) {
                          return 'Gender is required';
                        } else {
                          return null;
                        }
                      },
                      data: List.generate(
                        registrationController.genderTypesList.length,
                        (index) => SingleSelectDropDownModel(
                            registrationController
                                .genderTypesList[index].genderName,
                            registrationController
                                .genderTypesList[index].genderId
                                .toString()),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 40.w,
            ),
            // PhoneTextField(
            //   hintText: "",
            //   assetPath: AssetPath.mobile,
            //   controller: mobileCtrl,
            //   mobileCodecontroller: mobileCodeCtrl,
            //   labelText: "Mobile",
            //   withPrefixAsset: true,
            //   validator: (val) {
            //     if (val != null && val.isEmpty) {
            //       return 'Mobile number is required';
            //     } else {
            //       return null;
            //     }
            //   },
            // ),
            // SizedBox(
            //   height: 40.w,
            // ),
            // PhoneTextField(
            //   hintText: "",
            //   assetPath: AssetPath.mobile,
            //   controller: altMobileCtrl,
            //   mobileCodecontroller: altMobileCodeCtrl,
            //   labelText: "Alternate Mobile",
            //   withPrefixAsset: true,
            //   withValidator: false,
            // ),
            SizedBox(
              height: 40.w,
            ),
            /*if (!isVerificationStage)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.w),
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  border: Border.all(
                    color: AppColor.greyColor,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomTextField(
                      labelText: "Email ID",
                      prefixIcon: Image.asset(
                        AssetPath.mailBlue,
                        scale: 22.0,
                        color: AppColor.violetColor,
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return "Email ID is required";
                        } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                          return "Enter a valid email";
                        }
                        return null;
                      },
                      controller: emailCtrl,
                      errorText: emailErrorText,
                    ),
                    SizedBox(
                      height: 40.w,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 100.0),
                      child: InButton(
                        color: AppColor.primaryColor,
                        verticalPadding: 5.w,
                        textSize: AppFontSize.size4,
                        onTap: () {
                          requestOtp();
                        },
                        withArrow: false,
                        text: "Send Code",
                        textColor: AppColor.whiteColor,
                      ),
                    ),
                  ],
                ),
              ),
            if (isVerificationStage)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.w),
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  border: Border.all(
                    color: AppColor.greyColor,
                  ),
                  borderRadius: BorderRadius.circular(12.r),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        CustomText(
                          text: email,
                          fontSize: AppFontSize.size4,
                          color: AppColor.blackColor,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                          width: 60.w,
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  isVerificationStage = false; // Go back to email entry
                                });
                              },
                              child: CustomText(
                                text: "Change",
                                fontSize: AppFontSize.size3,
                                color: AppColor.primary2Color,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Spacer(),
                        Container(
                          width: 58.w,
                          padding: EdgeInsets.symmetric(vertical: 1.w, horizontal: 4.w),
                          decoration: BoxDecoration(
                            shape: BoxShape.rectangle,
                            color: AppColor.primary2Color,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 15.w,
                    ),
                    CustomTextField(
                      labelText: "Verification Code",
                      controller: verificationCodeCtrl,
                      errorText: verificationErrorText,
                      inputFormatters: [LengthLimitingTextInputFormatter(6)],
                      keyboardType: const TextInputType.numberWithOptions(decimal: false),
                      validator: (value) {
                        if (verificationCodeCtrl.text.isEmpty) {
                          return "Enter Valid OTP";
                        } else {
                          return null;
                        }
                      },
                    ),
                    SizedBox(
                      height: 15.w,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            resetTimer();
                          },
                          child: CustomText(
                            text: "Resend",
                            fontSize: AppFontSize.size3,
                            color: AppColor.primaryColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        CustomText(
                          text: timerText,
                          fontSize: AppFontSize.size3,
                          color: AppColor.blackColor,
                          fontWeight: FontWeight.w400,
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 100.0),
                      child: InButton(
                        color: AppColor.primaryColor,
                        verticalPadding: 5.w,
                        textSize: AppFontSize.size4,
                        onTap: () {
                          verifyOtp(verificationCodeCtrl.text);
                        },
                        withArrow: false,
                        text: "Verify",
                        textColor: AppColor.whiteColor,
                      ),
                    ),
                  ],
                ),
              ),*/
          ],
        ),
      ),
    );
  }
}
 */
