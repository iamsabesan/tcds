import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/user_interface/registration_status/model/franchise_request_model.dart';

import '../../../constants/app_string.dart';
import '../../../constants/colors.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_widgets/bottom_sheets.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../widgets/custom_progress_indicator.dart';
import '../../login/view/login_screen.dart';
import '../../registration_status/controller/registration_status_controller.dart';
import 'franchisee_payment_screen.dart';

class RegistrationPaymentStatusPage extends StatefulWidget {
  const RegistrationPaymentStatusPage({super.key});

  @override
  State<RegistrationPaymentStatusPage> createState() =>
      _RegistrationPaymentStatusPageState();
}

class _RegistrationPaymentStatusPageState
    extends State<RegistrationPaymentStatusPage> {
  RegistrationStatusController registerStatusController =
      Get.put(RegistrationStatusController());
  bool showButton = false;
  String lastStatus = "";
  bool regPaymentStatusLoader = false;

  @override
  void initState() {
    neccessaryAPICalls();
    super.initState();
  }

  Future<void> neccessaryAPICalls() async {
    regPaymentStatusLoader = true;
    setState(() {});

    await registerStatusController.studentDetail(
        studentEnquiryId:
            SharedPreference.getString(AppStrings.franchiseeRequestID));

    for (int i = 0;
        i < registerStatusController.franchiseEnquiryDetail[0].payments.length;
        i++) {
      if (i ==
          registerStatusController.franchiseEnquiryDetail[0].payments.length -
              1) {
        lastStatus = registerStatusController
            .franchiseEnquiryDetail[0].payments[i].status;
        if (lastStatus.toLowerCase() != "pending") {
          showButton = true;
        }
      }
    }

    regPaymentStatusLoader = false;
    setState(() {});
  }

  Widget _buildStatusBanner() {
    final status = lastStatus.toLowerCase();

    if (status == "pending") {
      return _buildPendingBanner();
    } else if (status == "approved") {
      return _buildApprovedBanner();
    }
    return const SizedBox.shrink();
  }

  Widget _buildPendingBanner() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.w),
      padding: EdgeInsets.all(10.w),
      decoration: BoxDecoration(
        color: AppColor.primaryColor,
        borderRadius: BorderRadius.circular(12.w),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info, color: AppColor.redColor, size: 24.w),
              SizedBox(width: 10.w),
              CustomText(
                text: "PAYMENT VERIFICATION",
                fontSize: 16.sp,
                color: AppColor.whiteColor,
                fontWeight: FontWeight.w600,
              ),
            ],
          ),
          SizedBox(height: 15.w),
          Container(
            padding: EdgeInsets.all(15.w),
            decoration: BoxDecoration(
              color: AppColor.whiteColor,
              borderRadius: BorderRadius.circular(8.w),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(Icons.notifications_active,
                      color: AppColor.deleteRed, size: 40.w),
                ),
                SizedBox(height: 10.w),
                const CustomText(
                  text: "Dear Sir / Madam,",
                  fontWeight: FontWeight.w400,
                ),
                SizedBox(height: 10.w),
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                    ),
                    children: const [
                      TextSpan(
                          text:
                              "Kindly wait until your Payment verification and Approval Status change from "),
                      TextSpan(
                        text: "PENDING",
                        style: TextStyle(
                            color: AppColor.pendingColor,
                            fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: " into "),
                      TextSpan(
                        text: "APPROVED",
                        style: TextStyle(
                            color: AppColor.green, fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: "."),
                    ],
                  ),
                ),
                SizedBox(height: 10.w),
                CustomText(
                  text: "(This will take from 30 minutes to 3 working days)",
                  color: AppColor.orange1,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w400,
                ),
                SizedBox(height: 10.w),
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                    ),
                    children: const [
                      TextSpan(text: "If you received "),
                      TextSpan(
                        text: "APPROVED",
                        style: TextStyle(
                            color: AppColor.green, fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: ", now you scroll down and click the "),
                      TextSpan(
                        text: "Continue Button",
                        style: TextStyle(
                            color: AppColor.primaryColor,
                            fontWeight: FontWeight.w600),
                      ),
                      TextSpan(
                          text:
                              " to Login into your TCDS FRANCHISEE Mobile App..."),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildApprovedBanner() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.w),
      padding: EdgeInsets.all(10.w),
      decoration: BoxDecoration(
        color: const Color.fromARGB(255, 38, 126, 42),
        borderRadius: BorderRadius.circular(12.w),
      ),
      child: Column(
        children: [
          CustomText(
            text: "Congratulations",
            fontSize: 20.sp,
            color: AppColor.whiteColor,
            fontWeight: FontWeight.w700,
          ),
          SizedBox(height: 15.w),
          Container(
            padding: EdgeInsets.all(15.w),
            decoration: BoxDecoration(
              color: AppColor.whiteColor,
              borderRadius: BorderRadius.circular(8.w),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(Icons.celebration,
                      color: AppColor.secondaryColor, size: 50.w),
                ),
                SizedBox(height: 10.w),
                const CustomText(
                  text: "Dear Sir / Madam,",
                  fontWeight: FontWeight.w400,
                ),
                SizedBox(height: 10.w),
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                    ),
                    children: const [
                      TextSpan(text: "Your Centre has been "),
                      TextSpan(
                        text: "APPROVED",
                        style: TextStyle(
                            color: AppColor.green, fontWeight: FontWeight.w600),
                      ),
                      TextSpan(
                          text:
                              " and ACTIVATED. So you can now scroll down and click the "),
                      TextSpan(
                        text: "Continue Button",
                        style: TextStyle(
                            color: AppColor.primaryColor,
                            fontWeight: FontWeight.w600),
                      ),
                      TextSpan(
                          text:
                              " to Login into your TCDS FRANCHISEE Mobile App..."),
                    ],
                  ),
                ),
                SizedBox(height: 20.w),
                // Email Field
                AbsorbPointer(
                  child: Opacity(
                    opacity: 0.6,
                    child: TextFormField(
                      enabled: false,
                      decoration: InputDecoration(
                        hintText: "Type your Registered Email ID",
                        hintStyle: TextStyle(
                            color: AppColor.orange1,
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w500),
                        prefixIcon: const Icon(
                          Icons.email_outlined,
                          color: AppColor.darkGreyColor,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                          borderSide: const BorderSide(color: AppColor.grey),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15.w),
                // Password Field
                AbsorbPointer(
                  child: Opacity(
                    opacity: 0.6,
                    child: TextFormField(
                      enabled: false,
                      obscureText: true,
                      decoration: InputDecoration(
                        hintText: "See in your Registered Email ID",
                        hintStyle: TextStyle(
                            color: AppColor.orange1,
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w500),
                        prefixIcon: const Icon(
                          Icons.lock_outline,
                          color: AppColor.darkGreyColor,
                        ),
                        suffixIcon: const Icon(
                          Icons.visibility_outlined,
                          color: AppColor.black2Color,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                          borderSide: const BorderSide(color: AppColor.grey),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /* Widget _buildApprovedBanner() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 20.w),
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        color: AppColor.secondaryColor,
        borderRadius: BorderRadius.circular(12.w),
      ),
      child: Column(
        children: [
          CustomText(
            text: "Congratulations",
            fontSize: 20.sp,
            color: AppColor.whiteColor,
            fontWeight: FontWeight.w700,
          ),
          SizedBox(height: 15.w),
          Container(
            padding: EdgeInsets.all(15.w),
            decoration: BoxDecoration(
              color: AppColor.whiteColor,
              borderRadius: BorderRadius.circular(8.w),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.celebration, 
                    color: AppColor.secondaryColor, size: 40.w),
                SizedBox(height: 10.w),
                const CustomText(
                  text: "Dear Sir / Madam,",
                  fontWeight: FontWeight.w400,
                ),
                SizedBox(height: 10.w),
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                    ),
                    children: const [
                      TextSpan(text: "Your Centre has been "),
                      TextSpan(
                        text: "APPROVED and ACTIVATED",
                        style: TextStyle(color: AppColor.secondaryColor, fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: ". So you can now scroll down and click the "),
                      TextSpan(
                        text: "Continue Button",
                        style: TextStyle(color: AppColor.primaryColor, fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: " to Login into your TCDS FRANCHISE Mobile App..."),
                    ],
                  ),
                ),
                SizedBox(height: 20.w),
                // Email Field
                AbsorbPointer(
                  child: Opacity(
                    opacity: 0.6,
                    child: TextFormField(
                      enabled: false,
                      decoration: InputDecoration(
                        labelText: "Email ID",
                        hintText: "Type your Registered Email ID",
                        hintStyle: TextStyle(
                          color: AppColor.deleteRed,
                          fontSize: 12.sp,
                        ),
                        prefixIcon: Icon(
                          Icons.email_outlined,
                          color: AppColor.darkGreyColor,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                          borderSide: BorderSide(color: AppColor.grey),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 15.w),
                // Password Field
                AbsorbPointer(
                  child: Opacity(
                    opacity: 0.6,
                    child: TextFormField(
                      enabled: false,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: "Password",
                        hintText: "See in your Registered Email ID",
                        hintStyle: TextStyle(
                          color: AppColor.deleteRed,
                          fontSize: 12.sp,
                        ),
                        prefixIcon: Icon(
                          Icons.lock_outline,
                          color: AppColor.darkGreyColor,
                        ),
                        suffixIcon: Icon(
                          Icons.visibility_outlined,
                          color: AppColor.black2Color,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                        ),
                        disabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8.w),
                          borderSide: BorderSide(color: AppColor.grey),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
   */

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        shadowColor: AppColor.grey,
        elevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        automaticallyImplyLeading: false,
        title: CustomText(
          text: "Registration Payment",
          fontSize: 16.sp,
          color: AppColor.blackColor,
          maxLines: 1,
          fontWeight: FontWeight.w500,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: regPaymentStatusLoader
          ? const CustomProgressIndicator()
          : Column(
              children: [
                Expanded(
                  child: ListView(
                    children: [
                      // Payment list
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: registerStatusController
                            .franchiseEnquiryDetail[0].payments.length,
                        padding: EdgeInsets.symmetric(
                            horizontal: 20.w, vertical: 30),
                        itemBuilder: (context, index) {
                          return InkWell(
                            overlayColor: const WidgetStatePropertyAll(
                                AppColor.whiteColor),
                            onTap: () {
                              _openBottomSheetForMethod(registerStatusController
                                  .franchiseEnquiryDetail[0].payments[index]);
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Flexible(
                                      flex: 70,
                                      child: CustomText(
                                        text: registerStatusController
                                            .franchiseEnquiryDetail[0]
                                            .payments[index]
                                            .voucherDate,
                                        color: AppColor.primaryColor,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16.sp,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                    Flexible(
                                      flex: 30,
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.end,
                                        children: [
                                          Flexible(
                                            child: CustomText(
                                              text: registerStatusController
                                                  .franchiseEnquiryDetail[0]
                                                  .payments[index]
                                                  .status,
                                              color: registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .payments[index]
                                                          .status
                                                          .toLowerCase() ==
                                                      "pending"
                                                  ? AppColor.pendingColor
                                                  : registerStatusController
                                                              .franchiseEnquiryDetail[
                                                                  0]
                                                              .payments[index]
                                                              .status
                                                              .toLowerCase() ==
                                                          "rejected"
                                                      ? AppColor.deleteRed
                                                      : AppColor.green,
                                              fontSize: 16.sp,
                                              fontWeight: FontWeight.w500,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          SizedBox(width: 10.w),
                                          Icon(
                                            Icons.arrow_forward_ios_rounded,
                                            color: AppColor.black3Color,
                                            size: 20.w,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                if (registerStatusController
                                        .franchiseEnquiryDetail[0]
                                        .payments[index]
                                        .status
                                        .toLowerCase() ==
                                    "rejected")
                                  SizedBox(height: 10.w),
                                if (registerStatusController
                                        .franchiseEnquiryDetail[0]
                                        .payments[index]
                                        .status
                                        .toLowerCase() ==
                                    "rejected")
                                  CustomText(
                                    text: registerStatusController
                                        .franchiseEnquiryDetail[0]
                                        .payments[index]
                                        .reason,
                                    fontWeight: FontWeight.w400,
                                    color: AppColor.black3Color,
                                  ),
                                SizedBox(height: 10.w),
                                const Divider(color: AppColor.grey),
                                SizedBox(height: 10.w),
                              ],
                            ),
                          );
                        },
                      ),
                      // Status Banner
                      _buildStatusBanner(),
                    ],
                  ),
                ),
                if (showButton)
                  Padding(
                    padding: EdgeInsets.only(bottom: 15.w),
                    child: SizedBox(
                      width: 150.w,
                      child: InButton(
                        text: "Continue",
                        onTap: () {
                          if (lastStatus.toLowerCase() == "rejected") {
                            Get.to(FranchiseePaymentScreen(
                              enquiryData: registerStatusController
                                  .franchiseEnquiryDetail[0],
                            ));
                          } else {
                            SharedPreference.putString(
                                AppStrings.regPaymentStatus, "");
                            SharedPreference.putString(
                                AppStrings.franchiseeRequestID, "");
                            Get.offAll(const LoginScreen());
                          }
                        },
                      ),
                    ),
                  )
              ],
            ),
    );
  }

  void _openBottomSheetForMethod(DataPayment payment) async {
    final result = await AppBottomSheets.paymentDetailBottomSheet(
      paymentDetails: payment,
      context: context,
    );

    if (result != null) {
      setState(() {});
    }
  }
}
