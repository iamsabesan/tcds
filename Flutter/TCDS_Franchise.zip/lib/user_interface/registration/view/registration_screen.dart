/* import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/login/controller/login_controller.dart';
import 'package:tcds/user_interface/registration/view/confirmation_screen.dart';
import 'package:tcds/user_interface/registration/view/franchisee_detail.dart';
import 'package:tcds/user_interface/registration/view/registration_detail.dart';
import 'package:tcds/user_interface/registration/view/registration_status_screen.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

class FranchiseeRegistrationScreen extends StatefulWidget {
  const FranchiseeRegistrationScreen({super.key});

  @override
  State<FranchiseeRegistrationScreen> createState() =>
      _FranchiseeRegistrationScreenState();
}

class _FranchiseeRegistrationScreenState
    extends State<FranchiseeRegistrationScreen> {
  LoginController logInController = Get.put(LoginController());

  final _formKeys = [
    GlobalKey<FormState>(), // RegistrationDetailForm
    GlobalKey<FormState>(), // FranchiseeDetailsForm
    GlobalKey<FormState>(), // ConfirmationScreen (if needed)
  ];

  int _currentStep = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        titleSpacing: 0.1,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: "Franchisee Registration",
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 1.5.w, horizontal: 4.w),
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: AppColor.greyColor,
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.4),
                    blurRadius: 5.0),
              ],
            ),
          ),
          SizedBox(
            height: 10.w,
          ),
          _buildCustomStepper(),
          Expanded(
            child: _getStepContent(),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 70.0),
        child: Row(
          mainAxisAlignment: _currentStep == 0
              ? MainAxisAlignment.center // Center the single button
              : MainAxisAlignment
                  .spaceBetween, // Space buttons apart for steps 1 and 2
          children: [
            if (_currentStep > 0) // Show "Previous" button on steps 1 and 2
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    if (_currentStep > 0) _currentStep--;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColor.whiteColor,
                  padding: EdgeInsets.symmetric(vertical: 10.w),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                ),
                child: const CustomText(
                  text: "Back",
                  color: AppColor.secondaryColor,
                ),
              ),
            ElevatedButton(
              onPressed: () {
                final currentFormKey = _formKeys[_currentStep];
                if (currentFormKey.currentState?.validate() ?? false) {
                  if (_currentStep < 2) {
                    setState(() => _currentStep++);
                  } else {
                    Get.offAll(
                        () => const FranchiseeRegistrationStatusScreen());
                  }
                } else {
                  Get.snackbar(
                    'Error Message',
                    'Please fill all the required details',
                    colorText: AppColor.blackColor,
                    padding: EdgeInsets.all(15.w),
                    backgroundColor: AppColor.whiteColor,
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: _currentStep < 2
                    ? AppColor.primary2Color // Next button
                    : AppColor.primary2Color, // Submit button
                padding: EdgeInsets.symmetric(vertical: 10.w, horizontal: 40.w),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.r),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomText(
                    text: _currentStep < 2 ? "Next" : "Submit",
                    color: AppColor.whiteColor,
                  ),
                  SizedBox(
                    width: 20.w,
                  ),
                  Image.asset(
                    AssetPath.rightArrow,
                    scale: 30.0,
                    color: AppColor.whiteColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomStepper() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5.w, horizontal: 10.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          _buildStep(
            stepNumber: 1,
            title: "Registrant Details",
            isActive: _currentStep == 0,
            isCompleted: _currentStep > 0,
          ),
          _buildLine(isCompleted: _currentStep > 0),
          _buildStep(
            stepNumber: 2,
            title: "Franchisee Details",
            isActive: _currentStep == 1,
            isCompleted: _currentStep > 1,
          ),
          _buildLine(isCompleted: _currentStep > 1),
          _buildStep(
            stepNumber: 3,
            title: "Confirmation",
            isActive: _currentStep == 2,
            isCompleted: false,
          ),
        ],
      ),
    );
  }

  Widget _buildStep({
    required int stepNumber,
    required String title,
    required bool isActive,
    required bool isCompleted,
  }) {
    return Column(
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            color: isActive || isCompleted
                ? AppColor.orange
                : AppColor.black2Color,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        const SizedBox(height: 8),
        isActive
            ? Container(
                padding: const EdgeInsets.all(2.0),
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColor.whiteColor,
                    border: Border.all(color: AppColor.primaryColor)),
                child: CircleAvatar(
                  radius: 15,
                  backgroundColor: isActive || isCompleted
                      ? AppColor.primaryColor
                      : Colors.grey,
                  child: Text(
                    "$stepNumber",
                    style: const TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              )
            : CircleAvatar(
                radius: 15,
                backgroundColor: Colors.grey.withValues(alpha: 0.3),
                child: Text(
                  "$stepNumber",
                  style: TextStyle(
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size4),
                ),
              ),
      ],
    );
  }

  Widget _buildLine({required bool isCompleted}) {
    return Expanded(
      child: Column(
        children: [
          SizedBox(
            height: 20.w,
          ),
          Container(
            height: 1.5,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }

  Widget _getStepContent() {
    switch (_currentStep) {
      case 0:
        return RegistrationDetailForm(
          formKey: _formKeys[0],
          // nameCtrl: nameCtrl,
          // emailCtrl: emailCtrl,
          // genderCtrl: genderCtrl,
          // altMobileCtrl: altMobileCtrl,
          // mobileCtrl: mobileCtrl,
        );
      case 1:
        return FranchiseeDetailsForm(
          formKey: _formKeys[1],
          // actNum: actNumCtrl,
          // branch: branchCtrl,
          // notes: notesCtrl,
          // bankName: bankNameCtrl,
          // actHolderName: actHolderNameCtrl,
          // franchiseeName: franchiseeNameCtrl,
          // franchiseeAddress: franchiseeAddressCtrl,
        );
      case 2:
        return ConfirmationScreen(
          formKey: _formKeys[2],
          // nameCtrl: nameCtrl,
          // emailCtrl: emailCtrl,
          // genderCtrl: genderCtrl,
          // altMobileCtrl: altMobileCtrl,
          // mobileCtrl: mobileCtrl,
          //
          // actNum: actNumCtrl,
          // branch: branchCtrl,
          // notes: notesCtrl,
          // bankName: bankNameCtrl,
          // actHolderName: actHolderNameCtrl,
          // franchiseeName: franchiseeNameCtrl,
          // franchiseeAddress: franchiseeAddressCtrl,
        );
      default:
        return const SizedBox.shrink();
    }
  }
}
/*

import 'dart:io';
import 'package:flutter/services.dart';
import 'package:http_parser/http_parser.dart' as media;
import 'package:dio/dio.dart' as dio;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/login/controller/login_controller.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/registration/model/request_otp_response_model.dart';
import 'package:tcds/user_interface/registration/view/registration_status_screen.dart';
import 'package:tcds/utils/helper_functions/common_dialogs.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:tcds/utils/helper_widgets/phone_textfield.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import 'dart:async';
import '../../../constants/shared_preference.dart';

class FranchiseeRegistrationScreen extends StatefulWidget {
  const FranchiseeRegistrationScreen({Key? key}) : super(key: key);

  @override
  _FranchiseeRegistrationScreenState createState() => _FranchiseeRegistrationScreenState();
}

class _FranchiseeRegistrationScreenState extends State<FranchiseeRegistrationScreen> {
  int _currentStep = 0;
  final List<GlobalKey<FormState>> _formKeys = [GlobalKey<FormState>(), GlobalKey<FormState>(), GlobalKey<FormState>()];

  RegistrationController registrationController = Get.put(RegistrationController());

  // find login controller
  LoginController loginController = Get.find<LoginController>();

  String? emailErrorText;
  String? verificationErrorText;

  RequestOTPData? requestOTPResponse;

  @override
  void initState() {
    registrationController.getPhoneCodes();
    registrationController.getGenderTypes();
    super.initState();
  }

  TextEditingController nameCtrl = TextEditingController();
  TextEditingController genderCtrl = TextEditingController();
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController genderTextCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController altMobileCtrl = TextEditingController();
  TextEditingController altMobileCodeCtrl = TextEditingController();
  TextEditingController verificationCodeCtrl = TextEditingController();

  bool isVerificationStage = false;

  String email = '';

  int timerDuration = 20;

  // 3 minutes in seconds
  Timer? timer;

  void startTimer() {
    timer?.cancel(); // Cancel any existing timer
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (timerDuration > 0) {
        setState(() {
          timerDuration--;
        });
      } else {
        timer.cancel();
      }
    });
  }

  void resetTimer() {
    setState(() {
      timerDuration = 180;
    });
    startTimer();
  }

  void requestOtp() {
    String value;
    value = emailCtrl.text;

    if (emailErrorText == null) {
      try {
        PleaseWaitLoader.openDialog();
        // call guest login before request OTP cause to find database from backend
        loginController.getAuth(password: "India_123", loginName: 'tcdsguest@gmail.com').then(
          (res) {
            // if guest login successful
            if (res) {
              // set logged in status as bool to prevent opening dashboard since we logged in using guest acc
              SharedPreference.putBool(AppStrings.isLoggedIn, false);
              // request mobile OTP
              //test mail : kannanece44@gmail.com
              registrationController.requestOTP(body: {"Email": value}).then(
                (res) {
                  PleaseWaitLoader.closeDialog();
                  if (res) {
                    setState(() {
                      email = emailCtrl.text;
                      isVerificationStage = true;
                    });
                    resetTimer();
                  }
                },
              );
            }
            //
          },
        );
      } catch (e) {
        debugPrint('Forgot PS catch $e');
      }
    }
  }

  void verifyOtp(String otp) {
    PleaseWaitLoader.openDialog();
    verificationErrorText = null;
    timer!.cancel();
    try {
      registrationController.verifyOTP(body: {
        "EmailOTPTransID":
            registrationController.requestOTPResponse == null ? '' : registrationController.requestOTPResponse!.emailOtpTransId.toString(),
        "EmailOTPCode": verificationCodeCtrl.text,
      }).then(
        (res) {
          PleaseWaitLoader.closeDialog();
          showSuccessDialog(context: context, message: 'OTP Verified Successfully!');
        },
      );
    } catch (e) {
      debugPrint('While Verify OTP -> $e');
    }
    setState(() {
      isVerificationStage = false; // Go back to the original stage or proceed
    });
  }

  // file pick function
  Future<FilePickerResult?> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'png', 'jpeg'],
    );
    if (result != null) {
      PlatformFile file = result.files.single;
      String fileExtension = file.extension?.toLowerCase() ?? '';
      // check if any extention type selected
      // check if file size exceeds 2 mb
      if (!['jpg', 'png', 'jpeg'].contains(fileExtension)) {
        showInformationDialog(
          context: Get.context!,
          message: 'Invalid file type. Please select a JPG, PNG, or JPEG file.',
        );
        return null;
      } else if (file.size > 2 * 1024 * 1024) {
        // File size exceeds 2MB
        showInformationDialog(context: Get.context!, message: 'File size exceeds 2MB. Please choose a smaller file.');
        return null;
      } else {
        debugPrint('File picked: ${file.path}');
        return result;
      }
    } else {
      debugPrint('No file picked');
      return null;
    }
  }

  File? _imageFile;

  // Step list with form content for each step
  List<Step> stepList() => [
        Step(
          title: SizedBox.shrink(),
          content: Column(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.width * 0.35,
                child: Center(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(60.r),
                    onTap: () async {
                      // Upload profile image
                      FilePickerResult? result = await _pickFile();

                      if (result != null) {
                        File file = File(result.files.single.path!);
                        String fileName = result.files.single.name;
                        debugPrint(fileName);

                        // Optionally handle the Dio file upload here
                        dio.MultipartFile.fromFile(
                          file.path,
                          filename: fileName,
                          contentType: media.MediaType(
                            'image',
                            file.path.split('.').last.toLowerCase(),
                          ),
                        );

                        // Update the state with the selected image
                        setState(() {
                          _imageFile = file;
                        });
                      }
                    },
                    child: Stack(
                      children: [
                        // Profile image
                        CircleAvatar(
                          backgroundColor: AppColor.whiteColor,
                          maxRadius: 60.w,
                          minRadius: 55.w,
                          child: Container(
                            constraints: const BoxConstraints.expand(),
                            clipBehavior: Clip.hardEdge,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: AppColor.lightWhite,
                            ),
                            child: _imageFile == null
                                ? Image.asset(
                                    AssetPath.userIcon,
                                    color: AppColor.greyColor,
                                    fit: BoxFit.contain,
                                  )
                                : Image.file(
                                    _imageFile!, // Display the selected image file
                                    fit: BoxFit.cover,
                                  ),
                          ),
                        ),
                        // Camera icon
                        // if (_imageFile == null)
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: EdgeInsets.all(5.w),
                            height: (MediaQuery.of(context).size.width * 0.30) * 0.38,
                            width: (MediaQuery.of(context).size.width * 0.30) * 0.38,
                            child: Image.asset(
                              AssetPath.cameraIcon,
                              color: AppColor.primary2Color,
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30.w),
              Row(
                children: [
                  Expanded(
                    flex: 4,
                    child: CustomTextField(
                      labelText: "Name",
                      prefixIcon: Image.asset(
                        AssetPath.userIcon,
                        scale: 25.0,
                        color: AppColor.orange,
                      ),
                      controller: nameCtrl,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Name is required";
                        } else {
                          return null;
                        }
                      },
                    ),
                  ),
                  SizedBox(
                    width: 15.w,
                  ),
                  Expanded(
                    flex: 2,
                    child: Obx(
                      () => SingleSelectDropDown(
                        key: UniqueKey(),
                        labelText: 'Gender',
                        valueController: genderCtrl,
                        valueTextController: genderTextCtrl,
                        filled: false,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Gender is required';
                          } else {
                            return null;
                          }
                        },
                        data: List.generate(
                          registrationController.genderTypesList.length,
                          (index) => SingleSelectDropDownModel(registrationController.genderTypesList[index].genderName,
                              registrationController.genderTypesList[index].genderId.toString()),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 40.w,
              ),
              PhoneTextField(
                hintText: "",
                assetPath: AssetPath.mobile,
                controller: mobileCtrl,
                mobileCodecontroller: mobileCodeCtrl,
                labelText: "Mobile",
                withPrefixAsset: true,
                validator: (val) {
                  if (val != null && val.isEmpty) {
                    return 'Mobile number is required';
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 40.w,
              ),
              PhoneTextField(
                hintText: "",
                assetPath: AssetPath.mobile,
                controller: altMobileCtrl,
                mobileCodecontroller: altMobileCodeCtrl,
                labelText: "Alternate Mobile",
                withPrefixAsset: true,
                withValidator: false,
              ),
              SizedBox(
                height: 40.w,
              ),
              if (!isVerificationStage)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.w),
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    border: Border.all(
                      color: AppColor.greyColor,
                    ),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      CustomTextField(
                        labelText: "Email ID",
                        prefixIcon: Image.asset(
                          AssetPath.mailBlue,
                          scale: 22.0,
                          color: AppColor.violetColor,
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Email ID is required";
                          } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                            return "Enter a valid email";
                          }
                          return null;
                        },
                        controller: emailCtrl,
                        errorText: emailErrorText,
                      ),
                      SizedBox(
                        height: 40.w,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 100.0),
                        child: InButton(
                          color: AppColor.primaryColor,
                          verticalPadding: 5.w,
                          textSize: AppFontSize.size4,
                          onTap: () {
                            requestOtp();
                          },
                          withArrow: false,
                          text: "Send Code",
                          textColor: AppColor.whiteColor,
                        ),
                      ),
                    ],
                  ),
                ),
              if (isVerificationStage)
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 40.w),
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    border: Border.all(
                      color: AppColor.greyColor,
                    ),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          CustomText(
                            text: email,
                            fontSize: AppFontSize.size4,
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w500,
                          ),
                          SizedBox(
                            width: 60.w,
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.centerRight,
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    isVerificationStage = false; // Go back to email entry
                                  });
                                },
                                child: CustomText(
                                  text: "Change",
                                  fontSize: AppFontSize.size3,
                                  color: AppColor.primary2Color,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Spacer(),
                          Container(
                            width: 58.w,
                            padding: EdgeInsets.symmetric(vertical: 1.w, horizontal: 4.w),
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: AppColor.primary2Color,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 15.w,
                      ),
                      CustomTextField(
                        labelText: "Verification Code",
                        controller: verificationCodeCtrl,
                        errorText: verificationErrorText,
                        inputFormatters: [LengthLimitingTextInputFormatter(6)],
                        keyboardType: const TextInputType.numberWithOptions(decimal: false),
                        validator: (value) {
                          if (verificationCodeCtrl.text.isEmpty) {
                            return "Enter Valid OTP";
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 15.w,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              resetTimer();
                            },
                            child: CustomText(
                              text: "Resend",
                              fontSize: AppFontSize.size3,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          CustomText(
                            text:
                                "${(timerDuration ~/ 60).toString().padLeft(2, '0')}:${(timerDuration % 60).toString().padLeft(2, '0')} min",
                            fontSize: AppFontSize.size3,
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w400,
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 100.0),
                        child: InButton(
                          color: AppColor.primaryColor,
                          verticalPadding: 5.w,
                          textSize: AppFontSize.size4,
                          onTap: () {
                            verifyOtp(verificationCodeCtrl.text);
                          },
                          withArrow: false,
                          text: "Verify",
                          textColor: AppColor.whiteColor,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          isActive: _currentStep == 0,
          state: _currentStep == 0 ? StepState.editing : StepState.complete,
        ),
        */
/*   Step(
      title: const Text('Franchisee Details'),
      content: Column(
        children: [
          TextFormField(
            controller: franchiseeNameCtrl,
            decoration: const InputDecoration(labelText: 'Franchisee Name'),
            validator: (value) => value!.isEmpty ? 'Please enter franchisee name' : null,
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: franchiseeAddressCtrl,
            decoration: const InputDecoration(labelText: 'Franchisee Address'),
            validator: (value) => value!.isEmpty ? 'Please enter franchisee address' : null,
          ),
        ],
      ),
      isActive: _currentStep == 1,
      state: _currentStep == 1 ? StepState.editing : StepState.complete,
    ),*//*

        */
/* Step(
      title: const Text('Confirmation'),
      content: Column(
        children: [
          Text('Name: ${nameCtrl.text}'),
          Text('Email: ${emailCtrl.text}'),
          Text('Mobile: ${mobileCtrl.text}'),
          Text('Franchisee Name: ${franchiseeNameCtrl.text}'),
          Text('Franchisee Address: ${franchiseeAddressCtrl.text}'),
        ],
      ),
      isActive: _currentStep == 2,
      state: StepState.complete,
    ),*//*

      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        titleSpacing: 0.1,
        backgroundColor: Colors.white,
        title: const Text(
          "Franchisee Registration",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_outlined),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Column(
        children: [
          _buildCustomStepper(),
          Expanded(
            child: Stepper(
              type: StepperType.horizontal,
              currentStep: _currentStep,
              steps: stepList(),
              onStepContinue: () {
                if (_currentStep < (stepList().length - 1)) {
                  setState(() {
                    _currentStep++;
                  });
                } else {
                  Get.offAll(() => const FranchiseeRegistrationStatusScreen());
                }
              },
              onStepCancel: () {
                if (_currentStep > 0) {
                  setState(() {
                    _currentStep--;
                  });
                }
              },
              onStepTapped: (int index) {
                setState(() {
                  _currentStep = index;
                });
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 70.0),
        child: Row(
          mainAxisAlignment: _currentStep == 0 ? MainAxisAlignment.center : MainAxisAlignment.spaceBetween,
          children: [
            if (_currentStep > 0)
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    if (_currentStep > 0) _currentStep--;
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: const Text("Back", style: TextStyle(color: Colors.orange)),
              ),
            ElevatedButton(
              onPressed: () {
                final currentFormKey = _formKeys[_currentStep];
                if (currentFormKey.currentState?.validate() ?? false) {
                  if (_currentStep < 2) {
                    setState(() => _currentStep++);
                  } else {
                    Get.offAll(() => const FranchiseeRegistrationStatusScreen());
                  }
                } else {
                  Get.snackbar(
                    'Error Message',
                    'Please fill all the required details',
                    colorText: Colors.black,
                    padding: const EdgeInsets.all(15.0),
                    backgroundColor: Colors.white,
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 40.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text("Next", style: TextStyle(color: Colors.white)),
                  Icon(Icons.arrow_forward, color: Colors.white),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomStepper() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          _buildStep(
            stepNumber: 1,
            title: "Registrant Details",
            isActive: _currentStep == 0,
            isCompleted: _currentStep > 0,
          ),
          _buildLine(isCompleted: _currentStep > 0),
          _buildStep(
            stepNumber: 2,
            title: "Franchisee Details",
            isActive: _currentStep == 1,
            isCompleted: _currentStep > 1,
          ),
          _buildLine(isCompleted: _currentStep > 1),
          _buildStep(
            stepNumber: 3,
            title: "Confirmation",
            isActive: _currentStep == 2,
            isCompleted: false,
          ),
        ],
      ),
    );
  }

  Widget _buildStep({
    required int stepNumber,
    required String title,
    required bool isActive,
    required bool isCompleted,
  }) {
    return Column(
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 12,
            color: isActive || isCompleted ? Colors.orange : Colors.black,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        const SizedBox(height: 8),
        isActive
            ? Container(
                padding: const EdgeInsets.all(2.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(color: Colors.orange),
                ),
                child: CircleAvatar(
                  radius: 15,
                  backgroundColor: isActive || isCompleted ? Colors.orange : Colors.grey,
                  child: Text(
                    "$stepNumber",
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                ),
              )
            : CircleAvatar(
                radius: 15,
                backgroundColor: Colors.grey.withValues(alpha:0.3),
                child: Text(
                  "$stepNumber",
                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w500, fontSize: 14),
                ),
              ),
      ],
    );
  }

  Widget _buildLine({required bool isCompleted}) {
    return Expanded(
      child: Column(
        children: [
          const SizedBox(height: 20.0),
          Container(
            height: 1.0,
            color: isCompleted ? Colors.orange : Colors.grey,
          ),
        ],
      ),
    );
  }
}
*/
 */
