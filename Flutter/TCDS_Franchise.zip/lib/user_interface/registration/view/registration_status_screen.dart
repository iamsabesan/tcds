/* import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/grey_box.dart';
import 'package:tcds/utils/helper_widgets/horiz_asset_text.dart';

class FranchiseeRegistrationStatusScreen extends StatefulWidget {
  const FranchiseeRegistrationStatusScreen({super.key});

  @override
  State<FranchiseeRegistrationStatusScreen> createState() =>
      _FranchiseeRegistrationStatusScreenState();
}

class _FranchiseeRegistrationStatusScreenState
    extends State<FranchiseeRegistrationStatusScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  String registrationStatus = "Approved";

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  final List<String> elevationImagePaths = [
    'assets/Bank.png',
    'assets/Dashboard.png',
    'assets/Enquiry.png',
    'assets/Fees.png',
  ];

  final List<String> laboratoryImagePaths = [
    'assets/Exam.png',
    'assets/Franchise.png',
    'assets/Notes.png',
  ];
  final List<String> classRoomImagePaths = [
    'assets/Logout.png',
    'assets/mail_login.png',
    'assets/padlock.png',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: "Franchisee Registration",
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: null,
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 1.5.w, horizontal: 4.w),
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: AppColor.greyColor,
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withValues(alpha: 0.4),
                    blurRadius: 5.0),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.all(15.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (registrationStatus == "Pending") ...[
                          Row(
                            children: [
                              CustomText(
                                text: "Approval Status : ",
                                color: AppColor.blackColor,
                                fontSize: AppFontSize.size4,
                              ),
                              Expanded(
                                child: HorizAssetText(
                                  assetPath: AssetPath.pending,
                                  valueText: "Pending",
                                  valueFontSize: AppFontSize.size4,
                                  assetScale: 30.0,
                                  valueTextColor: AppColor.orange,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 2.w,
                          ),
                          CustomText(
                            text: "Registration requested date 02/02/2024",
                            color: AppColor.blackColor,
                            fontSize: AppFontSize.size4,
                          ),
                        ],
                        if (registrationStatus == "Rejected") ...[
                          Row(
                            children: [
                              CustomText(
                                text: "Approval Status : ",
                                color: AppColor.blackColor,
                                fontSize: AppFontSize.size4,
                              ),
                              Expanded(
                                child: HorizAssetText(
                                  assetPath: AssetPath.rejected,
                                  valueText: "Rejected",
                                  valueFontSize: AppFontSize.size4,
                                  assetScale: 30.0,
                                  valueTextColor: AppColor.orange,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20.w,
                          ),
                          Material(
                            elevation: 2,
                            shadowColor: Colors.black.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(15.0),
                            child: Container(
                              width: double.infinity,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10.w, vertical: 10.w),
                              decoration: BoxDecoration(
                                shape: BoxShape.rectangle,
                                border: Border.all(color: AppColor.black2Color),
                                borderRadius: BorderRadius.circular(5.0),
                                boxShadow: const [
                                  BoxShadow(
                                    color: AppColor.lightGrey, // Shadow color
                                    offset: Offset(4,
                                        8), // Offset of the shadow (horizontal, vertical)
                                    blurRadius: 2, // Blur radius
                                    spreadRadius:
                                        5.0, // Spread radius of the shadow
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: "Reason for Rejection",
                                    color: AppColor.blackColor,
                                    fontWeight: FontWeight.w500,
                                    fontSize: AppFontSize.size4,
                                  ),
                                  SizedBox(
                                    height: 2.w,
                                  ),
                                  CustomText(
                                    text:
                                        "Please upload clear image of classroom",
                                    color: AppColor.blackColor,
                                    fontWeight: FontWeight.w400,
                                    fontSize: AppFontSize.size4,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                        if (registrationStatus == "Approved") ...[
                          Row(
                            children: [
                              CustomText(
                                text: "Approval Status : ",
                                color: AppColor.blackColor,
                                fontSize: AppFontSize.size4,
                              ),
                              Expanded(
                                child: HorizAssetText(
                                  assetPath: AssetPath.approved,
                                  valueText: "Approved",
                                  valueFontSize: AppFontSize.size4,
                                  assetScale: 30.0,
                                  valueTextColor: AppColor.orange,
                                ),
                              ),
                            ],
                          ),
                        ],
                        SizedBox(
                          height: 15.w,
                        ),
                        const Center(
                          child: Stack(
                            children: [
                              CircleAvatar(
                                radius: 50,
                                backgroundColor: AppColor.greyColor,
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        CustomText(
                          text: "Registrant Details",
                          color: AppColor.primary2Color,
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(height: 20.h),
                        GreyBox(
                            child: Padding(
                          padding: EdgeInsets.all(10.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          AssetPath.userIcon,
                                          color: AppColor.orange,
                                          scale: 25.0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 50,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: "Name",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        CustomText(
                                          text: "Prakash",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.w,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          AssetPath.gender,
                                          color: AppColor.violetColor,
                                          scale: 1.0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 50,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: "Gender",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        CustomText(
                                          text: "Male",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.w,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          AssetPath.mobile,
                                          scale: 22.0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 50,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: "Mobile",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        CustomText(
                                          text: "+91 9234702702",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.w,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          AssetPath.mobile,
                                          scale: 22.0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 50,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: "Alternate Mobile",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        CustomText(
                                          text: "+91 8238479234",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10.w,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Expanded(
                                    flex: 15,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Image.asset(
                                          AssetPath.mailLogin,
                                          color: AppColor.violetColor,
                                          scale: 25.0,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    flex: 50,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: "Email ID",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        CustomText(
                                          text: "Prakash@gmail.com",
                                          color: AppColor.blackColor,
                                          fontSize: AppFontSize.size4,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        )),
                        SizedBox(
                          height: 20.w,
                        ),
                        CustomText(
                          text: "Franchisee Details",
                          color: AppColor.primary2Color,
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        GreyBox(
                          child: Padding(
                            padding: EdgeInsets.all(10.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.franchisee,
                                            scale: 22.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Franchisee Name",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text: "TCDS",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.addressLocation,
                                            scale: 22.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Address",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text:
                                                "5/331, Devanagaoundanur, Veerapampalayam \n sankari.",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                            maxLines: 2,
                                          ),
                                          CustomText(
                                            text: "Salem, Tamilnadu",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                            maxLines: 2,
                                          ),
                                          CustomText(
                                            text: "India - 637301",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                            maxLines: 2,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        CustomText(
                          text: "Bank Account Details",
                          color: AppColor.primary2Color,
                          fontSize: AppFontSize.size3,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        GreyBox(
                          child: Padding(
                            padding: EdgeInsets.all(10.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                TabBar(
                                  controller: _tabController,
                                  tabs: const [
                                    Tab(text: '1st Bank'),
                                    Tab(text: '2nd Bank'),
                                  ],
                                  indicatorColor: Colors.orange,
                                  labelColor: Colors.orange,
                                  unselectedLabelColor: Colors.grey,
                                ),
                                SizedBox(
                                  height: 20.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.userIcon,
                                            color: AppColor.orange,
                                            scale: 25.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Account Holder Name",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text: "Prakash",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.bank,
                                            scale: 25.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Bank Name",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text: "State Bank of India",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.franchisee,
                                            scale: 22.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Account Number",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text: "Savings - 564987654",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.addressLocation,
                                            scale: 22.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "IFSC/Branch",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text: "SBIN90234809324 - Sankari",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Expanded(
                                      flex: 15,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Image.asset(
                                            AssetPath.notes,
                                            scale: 25.0,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 50,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Notes",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          CustomText(
                                            text:
                                                "SKDFJ aslkfjwr sdofjweoiru sdfjwoieruwe riworuweior siofknf wjriowr skfjwior lsdkfjwioer asdfjwier klskfjewior siruwirk kfjwierks iwruwir sdkfjweior ajreiworuweior iwoerwir oiweruwer iwoerur weirueiui ruweir ",
                                            color: AppColor.blackColor,
                                            fontSize: AppFontSize.size4,
                                            fontWeight: FontWeight.w400,
                                            maxLines: 3,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 30.w,
                        ),
                        CustomText(
                          text: "Attachments",
                          fontWeight: FontWeight.w500,
                          color: AppColor.primaryColor,
                          fontSize: AppFontSize.size3,
                        ),
                        SizedBox(
                          height: 5.w,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5.w),
                          child: GreyBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 15.w,
                                ),
                                CustomText(
                                  text: "Building Elevation",
                                  fontWeight: FontWeight.w600,
                                  color: AppColor.blackColor,
                                  fontSize: AppFontSize.size3,
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                _buildImageRow(context, elevationImagePaths),
                                SizedBox(
                                  height: 20.w,
                                ),
                                CustomText(
                                  text: "Laboratory",
                                  fontWeight: FontWeight.w600,
                                  color: AppColor.blackColor,
                                  fontSize: AppFontSize.size3,
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                _buildImageRow(context, laboratoryImagePaths),
                                SizedBox(
                                  height: 20.w,
                                ),
                                CustomText(
                                  text: "Class Room",
                                  fontWeight: FontWeight.w600,
                                  color: AppColor.blackColor,
                                  fontSize: AppFontSize.size3,
                                ),
                                SizedBox(
                                  height: 10.w,
                                ),
                                _buildImageRow(context, classRoomImagePaths),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.w,
                        ),
                        CustomText(
                          text: "Location",
                          fontWeight: FontWeight.w500,
                          color: AppColor.primaryColor,
                          fontSize: AppFontSize.size3,
                        ),
                        SizedBox(
                          height: 5.w,
                        ),
                        Container(
                          height: 200,
                          decoration: BoxDecoration(
                            color: Colors.grey[300],
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Center(
                            child: Text(
                              'Map Placeholder',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageRow(BuildContext context, List<String> imagePaths) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: imagePaths
            .map((path) => GestureDetector(
                  onTap: () => _showImagePopup(
                      context, imagePaths, imagePaths.indexOf(path)),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 15.w),
                      child: Image.asset(
                        path,
                        height: 100,
                        width: 100,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ))
            .toList(),
      ),
    );
  }

  void _showImagePopup(
      BuildContext context, List<String> imagePaths, int initialIndex) {
    int currentIndex = initialIndex;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "Building Elevation",
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 300,
                    height: 300,
                    child: Image.asset(
                      imagePaths[currentIndex],
                      fit: BoxFit.cover,
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        onPressed: currentIndex > 0
                            ? () {
                                setState(() {
                                  currentIndex--;
                                });
                              }
                            : null,
                      ),
                      IconButton(
                        icon: const Icon(Icons.arrow_forward),
                        onPressed: currentIndex < imagePaths.length - 1
                            ? () {
                                setState(() {
                                  currentIndex++;
                                });
                              }
                            : null,
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  /* Widget _buildNewFeature() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'New Feature Section',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        const Text(
          'This section represents the newly added feature with relevant widgets.',
          style: TextStyle(fontSize: 14),
        ),
        ElevatedButton(
          onPressed: () {
            // Implement the new feature's logic here
          },
          child: const Text('Action Button'),
        ),
      ],
    );
  } */
}
 */
