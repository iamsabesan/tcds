// import 'dart:convert';
// import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get/utils.dart';

import '../../../constants/app_string.dart';
import '../../../http_engine/engine.dart';
import '../model/franchise_request_model.dart';
import '../model/image_response.dart';

class RegistrationStatusController extends GetxController {
  HttpEngine engine = HttpEngine();

  RxList<EnquiryDetail> franchiseEnquiryDetail = <EnquiryDetail>[].obs;
  RxList<ImageModel> imageResponce = <ImageModel>[].obs;
  // screen loader bools
  RxBool centresScrLoader = false.obs;
  RxBool centresListLoader = false.obs;
  RxBool regStatusLoader = false.obs;
  // RxBool regPaymentStatusLoader = false.obs;

  //fetch student detail
  Future<bool> studentDetail({required String studentEnquiryId}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.userData + studentEnquiryId,
              protected: true)
          .then(
        (value) async {
          // log(jsonEncode(value.data));
          FranchiseRequestModel model =
              FranchiseRequestModel.fromJson(value.data);
          for (var i = 0; i < model.data.franchiseeImgs.length; i++) {
            // fetch base64 for an owner image
            await getImageDetails(
                imgID: model.data.franchiseeImgs[i].contentUrl);
            // after fetched, store it inside ownerimage model for easy reference
            if (imageResponce.isNotEmpty) {
              // split raw base64 cause data does not contain it as raw
              String splitRawBase64 = imageResponce[0].data.split(",")[1];
              model.data.franchiseeImgs[i].fetchedBase64 = splitRawBase64;
            } else {
              // if not fetched, let's assign null to identify later
              model.data.franchiseeImgs[i].fetchedBase64 = null;
            }
          }
          franchiseEnquiryDetail.clear();
          franchiseEnquiryDetail.add(model.data);
          if (franchiseEnquiryDetail.isNotEmpty) {
            franchiseEnquiryDetail.first.banks.removeWhere((item) =>
                item.bank.removeAllWhitespace.toLowerCase() == "walletbank");
          }

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }

  // Get image details
  Future<bool> getImageDetails({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageModel model = ImageModel.fromJson(value.data);
          imageResponce.clear();
          imageResponce.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }
}
