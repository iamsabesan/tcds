// To parse this JSON data, do
//
//     final franchiseRequestModel = franchiseRequestModelFromJson(jsonString);

import 'dart:convert';

FranchiseRequestModel franchiseRequestModelFromJson(String str) => FranchiseRequestModel.fromJson(json.decode(str));

String franchiseRequestModelToJson(FranchiseRequestModel data) => json.encode(data.toJson());

class FranchiseRequestModel {
  int code;
  String message;
  EnquiryDetail data;

  FranchiseRequestModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseRequestModel.fromJson(Map<String, dynamic> json) => FranchiseRequestModel(
    code: json["Code"],
    message: json["Message"],
    data: EnquiryDetail.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data.toJson(),
  };
}

class EnquiryDetail {
  String franchiseeRequestId;
  String packageLogId;
  String franchiseeCode;
  String branchName;
  String contactName;
  String gender;
  String phone;
  String alternatePhone;
  String email;
  String status;
  String reason;
  String requestDate;
  List<Address> address;
  List<FeesDetail> feesDetails;
  List<FranchiseeImg> franchiseeImgs;
  List<DataPayment> payments;
  List<Bank> banks;

  EnquiryDetail({
    required this.franchiseeRequestId,
    required this.packageLogId,
    required this.franchiseeCode,
    required this.branchName,
    required this.contactName,
    required this.gender,
    required this.phone,
    required this.alternatePhone,
    required this.email,
    required this.status,
    required this.reason,
    required this.requestDate,
    required this.address,
    required this.feesDetails,
    required this.franchiseeImgs,
    required this.payments,
    required this.banks,
  });

  factory EnquiryDetail.fromJson(Map<String, dynamic> json) => EnquiryDetail(
    franchiseeRequestId: json["FranchiseeRequestID"],
    packageLogId: json["PackageLogID"],
    franchiseeCode: json["FranchiseeCode"],
    branchName: json["BranchName"],
    contactName: json["ContactName"],
    gender: json["Gender"],
    phone: json["Phone"],
    alternatePhone: json["AlternatePhone"],
    email: json["Email"],
    status: json["Status"],
    reason: json["Reason"],
    requestDate: json["RequestDate"]??"",
    address: List<Address>.from(json["Address"].map((x) => Address.fromJson(x))),
    feesDetails: List<FeesDetail>.from(json["FeesDetails"].map((x) => FeesDetail.fromJson(x))),
    franchiseeImgs: List<FranchiseeImg>.from(json["FranchiseeImgs"].map((x) => FranchiseeImg.fromJson(x))),
    payments: List<DataPayment>.from(json["Payments"].map((x) => DataPayment.fromJson(x))),
    banks: List<Bank>.from(json["Banks"].map((x) => Bank.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "FranchiseeRequestID": franchiseeRequestId,
    "PackageLogID": packageLogId,
    "FranchiseeCode": franchiseeCode,
    "BranchName": branchName,
    "ContactName": contactName,
    "Gender": gender,
    "Phone": phone,
    "AlternatePhone": alternatePhone,
    "Email": email,
    "Status": status,
    "Reason": reason,
    "RequestDate": requestDate,
    "Address": List<dynamic>.from(address.map((x) => x.toJson())),
    "FeesDetails": List<dynamic>.from(feesDetails.map((x) => x)),
    "FranchiseeImgs": List<dynamic>.from(franchiseeImgs.map((x) => x.toJson())),
    "Payments": List<dynamic>.from(payments.map((x) => x.toJson())),
    "Banks": List<dynamic>.from(banks.map((x) => x.toJson())),
  };
}

class Address {
  String franchiseeRequestId;
  String address1;
  String address2;
  String area;
  String country;
  String state;
  String district;
  String pincode;
  String latitude;
  String longitude;

  Address({
    required this.franchiseeRequestId,
    required this.address1,
    required this.address2,
    required this.area,
    required this.country,
    required this.state,
    required this.district,
    required this.pincode,
    required this.latitude,
    required this.longitude,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
    franchiseeRequestId: json["FranchiseeRequestID"],
    address1: json["Address1"],
    address2: json["Address2"],
    area: json["Area"],
    country: json["Country"],
    state: json["State"],
    district: json["District"],
    pincode: json["Pincode"],
    latitude: json["Latitude"],
    longitude: json["Longitude"],
  );

  Map<String, dynamic> toJson() => {
    "FranchiseeRequestID": franchiseeRequestId,
    "Address1": address1,
    "Address2": address2,
    "Area": area,
    "Country": country,
    "State": state,
    "District": district,
    "Pincode": pincode,
    "Latitude": latitude,
    "Longitude": longitude,
  };
}

class FeesDetail {
  String franchiseeEnquiryId;
  String packageId;
  String duration;
  String subscriptionDuration;
  double actualFees;
  double newFees;

  FeesDetail({
    required this.franchiseeEnquiryId,
    required this.packageId,
    required this.duration,
    required this.subscriptionDuration,
    required this.actualFees,
    required this.newFees,
  });

  factory FeesDetail.fromJson(Map<String, dynamic> json) => FeesDetail(
    franchiseeEnquiryId: json["FranchiseeEnquiryID"],
    packageId: json["PackageID"],
    duration: json["Duration"],
    subscriptionDuration: json["SubscriptionDuration"],
    actualFees: json["ActualFees"],
    newFees: json["NewFees"],
  );

  Map<String, dynamic> toJson() => {
    "FranchiseeEnquiryID": franchiseeEnquiryId,
    "PackageID": packageId,
    "Duration": duration,
    "SubscriptionDuration": subscriptionDuration,
    "ActualFees": actualFees,
    "NewFees": newFees,
  };
}
class Bank {
  String accountId;
  String accountType;
  String accountName;
  String accountNumber;
  String bank;
  String ifsc;
  String branchName;
  String notes;

  Bank({
    required this.accountId,
    required this.accountType,
    required this.accountName,
    required this.accountNumber,
    required this.bank,
    required this.ifsc,
    required this.branchName,
    required this.notes,
  });

  factory Bank.fromJson(Map<String, dynamic> json) => Bank(
    accountId: json["AccountID"],
    accountType: json["AccountType"],
    accountName: json["AccountName"],
    accountNumber: json["AccountNumber"],
    bank: json["Bank"],
    ifsc: json["IFSC"],
    branchName: json["BranchName"],
    notes: json["Notes"],
  );

  Map<String, dynamic> toJson() => {
    "AccountID": accountId,
    "AccountType": accountType,
    "AccountName": accountName,
    "AccountNumber": accountNumber,
    "Bank": bank,
    "IFSC": ifsc,
    "BranchName": branchName,
    "Notes": notes,
  };
}

class FranchiseeImg {
  String franchiseeRequestId;
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;
  String? fetchedBase64;

  FranchiseeImg({
    required this.franchiseeRequestId,
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
     this.fetchedBase64,
  });

  factory FranchiseeImg.fromJson(Map<String, dynamic> json) => FranchiseeImg(
    franchiseeRequestId: json["FranchiseeRequestID"],
    documentName: json["DocumentName"],
    fileName: json["FileName"],
    documentType: json["DocumentType"],
    contentUrl: json["ContentUrl"],
  );

  Map<String, dynamic> toJson() => {
    "FranchiseeRequestID": franchiseeRequestId,
    "DocumentName": documentName,
    "FileName": fileName,
    "DocumentType": documentType,
    "ContentUrl": contentUrl,
  };
}

class DataPayment {
  String franchiseePaymentId;
  String receiptNo;
  String reason;
  String status;
  String voucherDate;
  String rejectedDate;
  double amount;
  List<PaymentPayment> payments;

  DataPayment({
    required this.franchiseePaymentId,
    required this.receiptNo,
    required this.reason,
    required this.status,
    required this.voucherDate,
    required this.rejectedDate,
    required this.amount,
    required this.payments,
  });

  factory DataPayment.fromJson(Map<String, dynamic> json) => DataPayment(
    franchiseePaymentId: json["FranchiseePaymentID"],
    receiptNo: json["ReceiptNo"],
    reason: json["Reason"],
    status: json["Status"],
    voucherDate: json["VoucherDate"],
    rejectedDate: json["RejectedDate"],
    amount: json["Amount"],
    payments: List<PaymentPayment>.from(json["Payments"].map((x) => PaymentPayment.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "FranchiseePaymentID": franchiseePaymentId,
    "ReceiptNo": receiptNo,
    "Reason": reason,
    "Status": status,
    "VoucherDate": voucherDate,
    "RejectedDate": rejectedDate,
    "Amount": amount,
    "Payments": List<dynamic>.from(payments.map((x) => x.toJson())),
  };
}

class PaymentPayment {
  String franchiseePaymentId;
  String franchiseePaymentTransId;
  String payMode;
  String summary;
  String transactionDate;
  double amount;
  String documentId;

  PaymentPayment({
    required this.franchiseePaymentId,
    required this.franchiseePaymentTransId,
    required this.payMode,
    required this.summary,
    required this.transactionDate,
    required this.amount,
    required this.documentId,
  });

  factory PaymentPayment.fromJson(Map<String, dynamic> json) => PaymentPayment(
    franchiseePaymentId: json["FranchiseePaymentID"],
    franchiseePaymentTransId: json["FranchiseePaymentTransID"],
    payMode: json["PayMode"],
    summary: json["Summary"],
    transactionDate: json["TransactionDate"],
    amount: json["Amount"],
    documentId: json["DocumentID"],
  );

  Map<String, dynamic> toJson() => {
    "FranchiseePaymentID": franchiseePaymentId,
    "FranchiseePaymentTransID": franchiseePaymentTransId,
    "PayMode": payMode,
    "Summary": summary,
    "TransactionDate": transactionDate,
    "Amount": amount,
    "DocumentID": documentId,
  };
}