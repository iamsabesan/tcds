import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tcds/user_interface/registration_status/model/franchise_request_model.dart';

import '../../../constants/app_string.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/grey_container_widget.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/list_tile.dart';
import '../../../widgets/custom_progress_indicator.dart';

// import '../../dashboard/model/franchisee_profile_response_model.dart';
import '../../registration/view/franchisee_payment_screen.dart';
import '../../registration/view/get_details_page.dart';
import '../controller/registration_status_controller.dart';

class RegistrationStatusPage extends StatefulWidget {
  const RegistrationStatusPage({super.key});

  @override
  State<RegistrationStatusPage> createState() => _RegistrationStatusPageState();
}

class _RegistrationStatusPageState extends State<RegistrationStatusPage>
    with TickerProviderStateMixin {
  // find register controller
  RegistrationStatusController registerStatusController =
      Get.find<RegistrationStatusController>();

  String approvalDate = "";
  late TabController _bankTabController;
  final Set<Marker> markers = {};
  final Completer<GoogleMapController> mapController =
      Completer<GoogleMapController>();
  bool nextPosition = false;
  late LatLng getUserPosition;
  String selectedImage = "";
  List<FranchiseeImg> buildingElevationImages = [];
  List<FranchiseeImg> classRoomImages = [];
  List<FranchiseeImg> laboratoryImages = [];
  Map<String, List<FranchiseeImg>> groupedImage = {};
  Map<int, List<FranchiseeImg>> groupedByClassRoom = {};
  Map<int, List<FranchiseeImg>> groupedByLaboratory = {};
  bool regStatusLoader = true;
  @override
  void initState() {
    neccessaryAPICalls();
    super.initState();
  }

  // call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    // registerStatusController.regStatusLoader.value = true;
    await registerStatusController.studentDetail(
        studentEnquiryId: SharedPreference.getString(AppStrings
            .franchiseeRequestID)); //"D8E3B6DC-3081-49B0-BB25-51C3618099B5"  "A7B726EC-3699-47CF-B067-6A1754C55485" SharedPreference.getString(AppStrings.franchiseeRequestID)
    selectedImage = registerStatusController
        .franchiseEnquiryDetail[0].franchiseeImgs[0].fetchedBase64!;

    _bankTabController = TabController(
        length: registerStatusController.franchiseEnquiryDetail[0].banks.length,
        vsync: this);
    getUserPosition = LatLng(
        double.parse(registerStatusController
            .franchiseEnquiryDetail[0].address[0].latitude),
        double.parse(registerStatusController
            .franchiseEnquiryDetail[0].address[0].longitude));
    // Output the formatted date

    markers.add(
      Marker(
        markerId: const MarkerId(''),
        icon: BitmapDescriptor.defaultMarker,
        position: getUserPosition,
      ),
    );
    for (var material
        in registerStatusController.franchiseEnquiryDetail[0].franchiseeImgs) {
      String semester = material.documentName;
      if (!groupedImage.containsKey(semester)) {
        groupedImage[semester] = [];
      }
      groupedImage[semester]?.add(material);
      // semesterTotalMarks[semester]!["TotalMarks"] = (semesterTotalMarks[semester]!["TotalMarks"]! + material.totalMarks);
      // semesterTotalMarks[semester]!["TheoryMarks"] = semesterTotalMarks[semester]!["TheoryMarks"]! + material.theoryMarks;
      // semesterTotalMarks[semester]!["PracticalMarks"] = semesterTotalMarks[semester]!["PracticalMarks"]! + material.practicalMarks;
    }
    buildingElevationImages = groupedImage["OutletImage"]!;
    classRoomImages = groupedImage["ClassRoomImage"]!;
    laboratoryImages = groupedImage["LaboratoryImage"]!;
    //SharedPref.getString(AppStrings.studentEnquiryID)
    // get country id of india
    // registerStatusController.regStatusLoader.value = false;
    // later required api calls
    regStatusLoader = false;
    setState(() {});
  }

  // textediting controller
  TextEditingController stateTxtCtrl = TextEditingController();
  TextEditingController stateIDCtrl = TextEditingController();
  TextEditingController districtTxtCtrl = TextEditingController();
  TextEditingController districtIDCtrl = TextEditingController();
  TextEditingController talukTxtCtrl = TextEditingController();
  TextEditingController talukIDCtrl = TextEditingController();

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> registeredFormKey = GlobalKey<FormState>();
  String profileImage = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        shadowColor: AppColor.grey,
        surfaceTintColor: AppColor.whiteColor,
        elevation: 4,
        automaticallyImplyLeading: false,
        title: CustomText(
          text: "Franchisee Registration",
          fontSize: 16.sp,
          color: AppColor.blackColor,
          maxLines: 1,
          fontWeight: FontWeight.w500,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      /*   appBar: PreferredSize(
          preferredSize: Size(double.infinity, 70.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(bottom: 15.w),
                decoration: const BoxDecoration(
                  color: AppColor.whiteColor,
                  boxShadow: [
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(
                        color: AppColor.grey,
                        offset: Offset(0, 6),
                        spreadRadius: 0.5,
                        blurRadius: 4),
                  ],
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          CustomText(
                            text: "Franchisee Registration",
                            fontSize: 16.sp,
                            color: AppColor.blackColor,
                            maxLines: 1,
                            fontWeight: FontWeight.w500,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )), */
      body:
          // Obx(
          //   () =>
          //   registerStatusController.regStatusLoader.value
          regStatusLoader
              ? const CustomProgressIndicator()
              //     : registerStatusController.franchiseEnquiryDetail[0].status ==
              //     "Registered"
              //     ?
              //     StatefulBuilder(builder: (context, confirmDetailsState) {
              //   return Padding(
              //     padding: EdgeInsets.symmetric(horizontal: 20.w),
              //     child: SingleChildScrollView(
              //       scrollDirection: Axis.vertical,
              //       child: Form(
              //         key: registeredFormKey,
              //         child: Column(
              //           crossAxisAlignment: CrossAxisAlignment.start,
              //           mainAxisAlignment: MainAxisAlignment.start,
              //           children: [
              //             GreyContainerWidget(
              //               child: Column(
              //                 children: [
              //                   Image.asset(
              //                     AssetPath.tcdsLogo,
              //                     scale: 5,
              //                   ),
              //                   SizedBox(
              //                     height: 20.w,
              //                   ),
              //
              //                   // login textfields
              //                   Align(
              //                     alignment: Alignment.center,
              //                     child: CustomText(
              //                       text: "Welcome Back !",
              //                       fontSize: 25.sp,
              //                       fontWeight: FontWeight.w500,
              //                       color: AppColor.secondaryColor,
              //                     ),
              //                   ),
              //                   SizedBox(
              //                     height: 20.w,
              //                   ),
              //                   CustomText(
              //                     text:
              //                     "Your login password is sent to your registered mail ID",
              //                     fontSize: 13.sp,
              //                     fontWeight: FontWeight.w500,
              //                     color: AppColor.blackColor,
              //                   ),
              //                   SizedBox(
              //                     height: 30.w,
              //                   ),
              //                   Row(
              //                     mainAxisAlignment:
              //                     MainAxisAlignment.center,
              //                     children: [
              //                       SizedBox(
              //                         width: 150.w,
              //                         child: InButton(
              //                           color: AppColor.primaryColor,
              //                           text: 'Re-apply',
              //                           onTap: () {
              //                             Get.toNamed(Routes.logIn);
              //                           },
              //                         ),
              //                       ),
              //                     ],
              //                   ),
              //                 ],
              //               ),
              //             ),
              //             SizedBox(
              //               height: 30.w,
              //             ),
              //             if (registerStatusController
              //                 .franchiseEnquiryDetail[0].isRejected)
              //               Row(
              //                 mainAxisAlignment: MainAxisAlignment.center,
              //                 children: [
              //                   SizedBox(
              //                     width: 150.w,
              //                     child: InButton(
              //                       color: AppColor.primaryColor,
              //                       text: 'Login',
              //                       onTap: () {
              //                         Get.toNamed(Routes.logIn);
              //                       },
              //                     ),
              //                   ),
              //                 ],
              //               ),
              //             SizedBox(
              //               height: 30.w,
              //             ),
              //           ],
              //         ),
              //       ),
              //     ),
              //   );
              // })
              : StatefulBuilder(builder: (context, confirmDetailsState) {
                  return Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Form(
                        key: studentDetailsForm,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 30.w,
                            ),
                            Row(
                              children: [
                                Expanded(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      CustomText(
                                        text: "Approval Status : ",
                                        fontSize: 14.sp,
                                        color: AppColor.blackColor,
                                        fontWeight: FontWeight.w500,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      Image.asset(
                                        registerStatusController
                                                    .franchiseEnquiryDetail[0]
                                                    .status
                                                    .toLowerCase() ==
                                                "rejected"
                                            ? AssetPath.rejected
                                            : registerStatusController
                                                        .franchiseEnquiryDetail[
                                                            0]
                                                        .status
                                                        .toLowerCase() ==
                                                    "pending"
                                                ? AssetPath.pending
                                                : AssetPath.approved,
                                        scale: 25,
                                      ),
                                      SizedBox(
                                        width: 5.w,
                                      ),
                                      CustomText(
                                        text: registerStatusController
                                            .franchiseEnquiryDetail[0].status,
                                        fontSize: 14.sp,
                                        color: AppColor.orange1,
                                        fontWeight: FontWeight.w400,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10.w,
                            ),
                            if (registerStatusController
                                    .franchiseEnquiryDetail[0].status
                                    .toLowerCase() ==
                                "pending")
                              Row(
                                children: [
                                  Expanded(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text:
                                              "Registration requested date : ",
                                          fontSize: 14.sp,
                                          color: AppColor.blackColor,
                                          fontWeight: FontWeight.w500,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        Image.asset(
                                          registerStatusController
                                                      .franchiseEnquiryDetail[0]
                                                      .status
                                                      .toLowerCase() ==
                                                  "rejected"
                                              ? AssetPath.rejected
                                              : registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .status
                                                          .toLowerCase() ==
                                                      "pending"
                                                  ? AssetPath.pending
                                                  : AssetPath.approved,
                                          scale: 25,
                                        ),
                                        SizedBox(
                                          width: 5.w,
                                        ),
                                        CustomText(
                                          text: registerStatusController
                                              .franchiseEnquiryDetail[0]
                                              .requestDate,
                                          fontSize: 14.sp,
                                          color: AppColor.subTitleColor,
                                          fontWeight: FontWeight.w400,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            if (registerStatusController
                                    .franchiseEnquiryDetail[0].status
                                    .toLowerCase() ==
                                "rejected")
                              SizedBox(
                                height: 15.w,
                              ),
                            if (registerStatusController
                                    .franchiseEnquiryDetail[0].status
                                    .toLowerCase() ==
                                "rejected")
                              Row(
                                children: [
                                  Expanded(
                                    child: GreyContainerWidget(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          CustomText(
                                            text: "Reason",
                                            fontSize: 14.sp,
                                            color: AppColor.blackColor,
                                            maxLines: 1,
                                            fontWeight: FontWeight.w500,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          CustomText(
                                            text: registerStatusController
                                                .franchiseEnquiryDetail[0]
                                                .reason,
                                            fontSize: 12.sp,
                                            color: AppColor.black3Color,
                                            maxLines: 2,
                                            fontWeight: FontWeight.w400,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                            SizedBox(
                              height: 30.w,
                            ),
                            Container(
                              margin: EdgeInsets.symmetric(vertical: 15.w),
                              padding: EdgeInsets.all(15.w),
                              decoration: BoxDecoration(
                                color: AppColor.deleteRed,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.error_outline,
                                        color: AppColor.whiteColor,
                                        size: 20.sp,
                                      ),
                                      SizedBox(width: 8.w),
                                      CustomText(
                                        text: 'ATTENTION',
                                        fontSize: 14.sp,
                                        color: AppColor.whiteColor,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10.w),
                                  Container(
                                    padding: EdgeInsets.all(12.w),
                                    decoration: BoxDecoration(
                                      color: AppColor.whiteColor,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  style: TextStyle(
                                                    fontSize: 12.sp,
                                                    color: AppColor.blackColor,
                                                    height: 1.5,
                                                  ),
                                                  children: const [
                                                    TextSpan(
                                                      text: 'Dear Sir / Madam,',
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w600),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          ' your request has been received. Kindly wait until your ',
                                                    ),
                                                    TextSpan(
                                                      text: 'Approval Status',
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w700),
                                                    ),
                                                    TextSpan(
                                                      text: ' change from ',
                                                    ),
                                                    TextSpan(
                                                      text: 'PENDING',
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: AppColor.orange1,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: ' to ',
                                                    ),
                                                    TextSpan(
                                                      text: 'APPROVED',
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: Colors.green,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          '. This will take from ',
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          '30 minutes to 3 working days',
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w700),
                                                    ),
                                                    TextSpan(text: '.\n\n'),
                                                    TextSpan(
                                                      text: 'If you received ',
                                                    ),
                                                    TextSpan(
                                                      text: 'APPROVED',
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: Colors.green,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          ', now you scroll down and click the ',
                                                    ),
                                                    TextSpan(
                                                      text: 'Continue Button',
                                                      style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.w700),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          ' to submit the Payment details.\n\n',
                                                    ),
                                                    TextSpan(
                                                      text: 'If you received ',
                                                    ),
                                                    TextSpan(
                                                      text: 'REJECTED',
                                                      style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color:
                                                            AppColor.deleteRed,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text:
                                                          ', kindly try to rectify and re-submit the Issues.',
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(height: 12.w),
                                              Container(
                                                padding: EdgeInsets.symmetric(
                                                  horizontal: 12.w,
                                                  vertical: 8.w,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: Colors.yellow.shade100,
                                                  borderRadius:
                                                      BorderRadius.circular(6),
                                                  border: Border.all(
                                                    color:
                                                        Colors.yellow.shade700,
                                                    width: 1.5,
                                                  ),
                                                ),
                                                child: CustomText(
                                                  text:
                                                      "PLEASE DON'T TRY TO UNINSTALL / RE-INSTALL THE APP UNTIL YOU GET THE RESULT AS APPROVED / REJECTED",
                                                  fontSize: 11.sp,
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w700,
                                                  maxLines: 5,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: 12.w),
                                        Container(
                                          padding: EdgeInsets.all(8.w),
                                          decoration: BoxDecoration(
                                            color: AppColor.deleteRed
                                                .withValues(alpha: 0.1),
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                              color: AppColor.deleteRed,
                                              width: 2,
                                            ),
                                          ),
                                          child: Column(
                                            children: [
                                              Icon(
                                                Icons.warning_amber_rounded,
                                                color: AppColor.deleteRed,
                                                size: 40.sp,
                                              ),
                                              SizedBox(height: 4.w),
                                              CustomText(
                                                text: 'IMPORTANT\nNOTICE',
                                                fontSize: 9.sp,
                                                color: AppColor.deleteRed,
                                                fontWeight: FontWeight.w800,
                                                textAlign: TextAlign.center,
                                                maxLines: 2,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 30.w,
                            ),
                            // profile picture
                            Center(
                              child: InkWell(
                                  onTap: () async {},
                                  child: selectedImage == ""
                                      ? Stack(
                                          children: [
                                            Image.asset(
                                              AssetPath.uploadProfile,
                                              height: 120.w,
                                              width: 120.w,
                                            ),
                                          ],
                                        )
                                      : Stack(
                                          children: [
                                            ClipOval(
                                              child: Image.memory(
                                                base64Decode(selectedImage),
                                                height: 120.w,
                                                width: 120.w,
                                                fit: BoxFit.cover,
                                                errorBuilder: (context, error,
                                                        stackTrace) =>
                                                    Image.asset(
                                                  AssetPath.defaultProfile,
                                                  height: 100.w,
                                                  width: 100.w,
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                          ],
                                        )),
                            ),

                            // profile picture
                            SizedBox(
                              height: 30.w,
                            ),
                            CustomText(
                              text: 'Registration Details',
                              fontSize: 16.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                            SizedBox(
                              height: 15.w,
                            ),
                            GreyContainerWidget(
                              child: Column(
                                children: [
                                  CentreListTile(
                                    assetName: AssetPath.owner,
                                    title: 'Name',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0].contactName,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.gender,
                                    title: 'Gender',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0].gender,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.mobile,
                                    title: 'Mobile',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0].phone,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.mobile,
                                    title: 'Alternate Mobile',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0]
                                        .alternatePhone,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.mail,
                                    title: 'Email ID',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0].email,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 30.w,
                            ),
                            CustomText(
                              text: 'Franchisee Details',
                              fontSize: 16.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                            SizedBox(
                              height: 15.w,
                            ),
                            GreyContainerWidget(
                              child: Column(
                                children: [
                                  CentreListTile(
                                    assetName: AssetPath.company,
                                    title: 'Franchisee Id',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0]
                                        .franchiseeCode,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.company,
                                    title: 'Franchisee Name',
                                    subTitle: registerStatusController
                                        .franchiseEnquiryDetail[0].branchName,
                                  ),
                                  SizedBox(
                                    height: 5.w,
                                  ),
                                  CentreListTile(
                                    assetName: AssetPath.location,
                                    title: 'Communication Address',
                                    subTitle:
                                        '${registerStatusController.franchiseEnquiryDetail[0].address[0].address1} ${registerStatusController.franchiseEnquiryDetail[0].address[0].address2}    \n ${registerStatusController.franchiseEnquiryDetail[0].address[0].area} \n ${registerStatusController.franchiseEnquiryDetail[0].address[0].district} ${registerStatusController.franchiseEnquiryDetail[0].address[0].state} \n ${registerStatusController.franchiseEnquiryDetail[0].address[0].country}-${registerStatusController.franchiseEnquiryDetail[0].address[0].pincode} ',
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 30.w,
                            ),
                            CustomText(
                              text: 'Bank Account Details',
                              fontSize: 16.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                            SizedBox(
                              height: 15.w,
                            ),
                            GreyContainerWidget(
                              child: Column(
                                children: [
                                  TabBar(
                                    controller: _bankTabController,
                                    tabs: List<Widget>.generate(
                                      registerStatusController
                                              .franchiseEnquiryDetail[0]
                                              .banks
                                              .isNotEmpty
                                          ? registerStatusController
                                              .franchiseEnquiryDetail[0]
                                              .banks
                                              .length
                                          : 1,
                                      (index) {
                                        return Tab(
                                          text: registerStatusController
                                              .franchiseEnquiryDetail[0]
                                              .banks[index]
                                              .bank,
                                          // Assuming 'name' is a field in your course object
                                        );
                                      },
                                    ),
                                    isScrollable: true,
                                    tabAlignment: TabAlignment.center,
                                    indicatorColor: Colors.orange,
                                    labelColor: AppColor.blackColor,
                                    unselectedLabelColor: Colors.grey,
                                  ),
                                  SizedBox(
                                    height: 330,
                                    // Adjust the height for TabBarView
                                    child: TabBarView(
                                      controller: _bankTabController,
                                      children: List<Widget>.generate(
                                        registerStatusController
                                                .franchiseEnquiryDetail[0]
                                                .banks
                                                .isNotEmpty
                                            ? registerStatusController
                                                .franchiseEnquiryDetail[0]
                                                .banks
                                                .length
                                            : 1,
                                        (index) {
                                          return SingleChildScrollView(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CentreListTile(
                                                  assetName: AssetPath.owner,
                                                  title: "Account Holder Name",
                                                  subTitle:
                                                      registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .banks[index]
                                                          .accountName,
                                                ),
                                                CentreListTile(
                                                  assetName: AssetPath.bank,
                                                  title: "Bank Name",
                                                  subTitle:
                                                      registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .banks[index]
                                                          .bank,
                                                ),
                                                CentreListTile(
                                                  assetName: AssetPath.company,
                                                  title: "Account Number",
                                                  subTitle:
                                                      registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .banks[index]
                                                          .accountNumber
                                                          .toString(),
                                                ),
                                                CentreListTile(
                                                  assetName: AssetPath.location,
                                                  title: "IFSC/Branch",
                                                  subTitle:
                                                      "${registerStatusController.franchiseEnquiryDetail[0].banks[index].ifsc} -${registerStatusController.franchiseEnquiryDetail[0].banks[index].branchName} ",
                                                ),
                                                CentreListTile(
                                                  assetName: AssetPath.notes,
                                                  title: "Notes",
                                                  subTitle:
                                                      registerStatusController
                                                          .franchiseEnquiryDetail[
                                                              0]
                                                          .banks[index]
                                                          .notes,
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 30.w,
                            ),
                            CustomText(
                              text: 'Attachments',
                              fontSize: 16.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                            SizedBox(
                              height: 15.w,
                            ),
                            GreyContainerWidget(
                                child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  showImagePickerSection(
                                    title: 'Building Elevation',
                                    imageList: buildingElevationImages,
                                  ),
                                  showImagePickerSection(
                                    title: 'Laboratory',
                                    imageList: laboratoryImages,
                                  ),
                                  showImagePickerSection(
                                    title: 'Classroom',
                                    imageList: classRoomImages,
                                  ),
                                ],
                              ),
                            )),
                            SizedBox(
                              height: 30.w,
                            ),
                            CustomText(
                              text: 'Location',
                              fontSize: 16.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                            SizedBox(
                              height: 15.w,
                            ),
                            Stack(
                              children: [
                                SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height / 4.0,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(18.0),
                                          boxShadow: const [
                                            BoxShadow(
                                                color: AppColor.black2Color,
                                                blurRadius: 8.0,
                                                offset: Offset(0, 1))
                                          ]),
                                      child: ClipRRect(
                                        borderRadius:
                                            BorderRadius.circular(18.0),
                                        child: GoogleMap(
                                          markers: markers,
                                          zoomGesturesEnabled: false,
                                          zoomControlsEnabled: false,
                                          buildingsEnabled: false,
                                          initialCameraPosition: CameraPosition(
                                            target: getUserPosition,
                                            zoom: 15,
                                          ),
                                          onMapCreated: (GoogleMapController
                                              gmController) {
                                            mapController
                                                .complete(gmController);
                                            setState(() {
                                              nextPosition = true;
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(
                              height: 30.w,
                            ),
                            if (registerStatusController
                                    .franchiseEnquiryDetail[0].status
                                    .toLowerCase() !=
                                "pending")
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 150.w,
                                    child: InButton(
                                      color: AppColor.primaryColor,
                                      text: registerStatusController
                                                  .franchiseEnquiryDetail[0]
                                                  .status
                                                  .toLowerCase() ==
                                              "approved"
                                          ? "Continue"
                                          : registerStatusController
                                                      .franchiseEnquiryDetail[0]
                                                      .status
                                                      .toLowerCase() ==
                                                  "approved"
                                              ? "Edit"
                                              : 'Edit',
                                      onTap: () {
                                        if (registerStatusController
                                                .franchiseEnquiryDetail[0]
                                                .status
                                                .toLowerCase() ==
                                            "approved") {
                                          // Get.toNamed(Routes.logInScreen);
                                          Get.offAll(
                                              () => FranchiseePaymentScreen(
                                                    enquiryData:
                                                        registerStatusController
                                                            .franchiseEnquiryDetail[0],
                                                  ));
                                        } else if (registerStatusController
                                                .franchiseEnquiryDetail[0]
                                                .status
                                                .toLowerCase() ==
                                            "rejected") {
                                          Get.offAll(() => GetDetailsPage(
                                                enquiryData:
                                                    registerStatusController
                                                        .franchiseEnquiryDetail[0],
                                              ));
                                        } else {
                                          Get.offAll(
                                              () => FranchiseePaymentScreen(
                                                    enquiryData:
                                                        registerStatusController
                                                            .franchiseEnquiryDetail[0],
                                                  ));
                                        }
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            SizedBox(
                              height: 30.w,
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }),
      // ),
    );
  }

  Widget showImagePickerSection({
    required String title,
    required List<FranchiseeImg> imageList,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          text: title,
          color: AppColor.titleColor,
          fontWeight: FontWeight.w600,
        ),
        Row(
          children: [
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    imageList.length,
                    (index) => Stack(
                      children: [
                        InkWell(
                          onTap: () {
                            _showImageDialog(
                                context,
                                imageList[index].fetchedBase64!,
                                imageList[index].documentName);
                          },
                          child: Container(
                              margin: EdgeInsets.only(
                                  right: 10.w, top: 10.w, bottom: 10.w),
                              decoration: BoxDecoration(
                                  border:
                                      Border.all(color: AppColor.black2Color)),
                              child: Image.memory(
                                base64Decode(imageList[index].fetchedBase64!),
                                height: 100.w,
                                width: 100.w,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Image.asset(
                                  AssetPath.defaultProfile,
                                  height: 100.w,
                                  width: 100.w,
                                  fit: BoxFit.cover,
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showImageDialog(
      BuildContext context, String base64Image, String documentName) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Row for the heading and close button
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      documentName, // Heading text
                      style: TextStyle(
                        fontSize: 20.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: AppColor.deleteRed),
                      onPressed: () {
                        Navigator.of(context).pop(); // Close the dialog
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 5), // Space between heading and image
                // The image inside the dialog
                Image.memory(
                  base64Decode(base64Image),
                  width: 300,
                  height: 300,
                  fit: BoxFit.cover,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
