import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../constants/app_string.dart';
import '../../../http_engine/engine.dart';
import '../model/renewal_payment_model.dart';

class ApprovalRenewalController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxBool approvalRenewalLoader = false.obs;
  RxList<RenewalPayment> renewalPaymemntList = <RenewalPayment>[].obs;

  Future<bool> getRenewalList({required String pageName}) async {
    bool resultValue = false;
    approvalRenewalLoader.value = true;
    List<RenewalPayment> adminBankBankEndList = [];
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.approvalRenewalUrl,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        RenewalPaymentModel model = RenewalPaymentModel.fromJson(value.data);
        for (int i = 0; i < model.data.length; i++) {
          if (model.data[i].packageType.removeAllWhitespace == pageName) {
            adminBankBankEndList.add(model.data[i]);
          }
        }
        renewalPaymemntList.value = adminBankBankEndList;
        approvalRenewalLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> makePayment({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.renewalSubscriptionPaymentUrl,
              body,
              protected: true)
          .then((value) {
        // RenewalResponseModel model =
        // RenewalResponseModel.fromJson(value.data);
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      resultValue = false;
    }

    return resultValue;
  }
}
