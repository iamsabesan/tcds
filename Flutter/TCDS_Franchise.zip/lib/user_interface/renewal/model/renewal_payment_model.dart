// To parse this JSON data, do
//
//     final renewalPaymentModel = renewalPaymentModelFromJson(jsonString);

import 'dart:convert';

RenewalPaymentModel renewalPaymentModelFromJson(String str) => RenewalPaymentModel.fromJson(json.decode(str));

String renewalPaymentModelToJson(RenewalPaymentModel data) => json.encode(data.toJson());

class RenewalPaymentModel {
  int code;
  String message;
  List<RenewalPayment> data;

  RenewalPaymentModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RenewalPaymentModel.fromJson(Map<String, dynamic> json) => RenewalPaymentModel(
    code: json["Code"],
    message: json["Message"],
    data: List<RenewalPayment>.from(json["Data"].map((x) => RenewalPayment.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class RenewalPayment {
  String packageId;
  String packageType;
  String packageName;
  double netPackageFees;
  String duration;
  String approvalStartDate;
  String approvalEndDate;
  String approvalStatus;
  String subscriptionStartDate;
  String subscriptionEndDate;

  RenewalPayment({
    required this.packageId,
    required this.packageType,
    required this.packageName,
    required this.netPackageFees,
    required this.duration,
    required this.approvalStartDate,
    required this.approvalEndDate,
    required this.approvalStatus,
    required this.subscriptionStartDate,
    required this.subscriptionEndDate,
  });

  factory RenewalPayment.fromJson(Map<String, dynamic> json) => RenewalPayment(
    packageId: json["PackageID"],
    packageType: json["PackageType"],
    packageName: json["PackageName"],
    netPackageFees: json["NetPackageFees"],
    duration: json["Duration"],
    approvalStartDate: json["ApprovalStartDate"],
    approvalEndDate: json["ApprovalEndDate"],
    approvalStatus: json["ApprovalStatus"],
    subscriptionStartDate: json["SubscriptionStartDate"],
    subscriptionEndDate: json["SubscriptionEndDate"],
  );

  Map<String, dynamic> toJson() => {
    "PackageID": packageId,
    "PackageType": packageType,
    "PackageName": packageName,
    "NetPackageFees": netPackageFees,
    "Duration": duration,
    "ApprovalStartDate": approvalStartDate,
    "ApprovalEndDate": approvalEndDate,
    "ApprovalStatus": approvalStatus,
    "SubscriptionStartDate": subscriptionStartDate,
    "SubscriptionEndDate": subscriptionEndDate,
  };
}
