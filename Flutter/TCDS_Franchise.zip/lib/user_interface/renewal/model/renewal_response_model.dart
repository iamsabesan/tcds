// To parse this JSON data, do
//
//     final renewalResponseModel = renewalResponseModelFromJson(jsonString);

import 'dart:convert';

RenewalResponseModel renewalResponseModelFromJson(String str) => RenewalResponseModel.fromJson(json.decode(str));

String renewalResponseModelToJson(RenewalResponseModel data) => json.encode(data.toJson());

class RenewalResponseModel {
  int code;
  String message;
  String data;

  RenewalResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RenewalResponseModel.fromJson(Map<String, dynamic> json) => RenewalResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
