import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/renewal/ui/renewal_detail_page.dart';
import 'package:tcds/utils/helper_widgets/grey_container_widget.dart';
import '../../../constants/app_string.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/approval_two_line_widget.dart';
import '../../../utils/helper_widgets/blue_border_container.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/pair_text.dart';
import '../../../utils/helper_widgets/wallet_container_widget.dart';
import '../../dashboard/controller/dashboard_controller.dart';
import '../../dashboard/model/paymode_list_response_model.dart';
import '../../dashboard/view/dashboard_screen.dart';
import '../../dashboard/view/wallet_topup_screen.dart';
import '../controller/approval_renewal_controller.dart';

class ApprovalRenewalPage extends StatefulWidget {
  const ApprovalRenewalPage({super.key});

  @override
  State<ApprovalRenewalPage> createState() => _ApprovalRenewalPageState();
}

class _ApprovalRenewalPageState extends State<ApprovalRenewalPage> {
  ApprovalRenewalController approvalRenewalController =
      Get.put(ApprovalRenewalController());
  late DashboardController dashboardController;
  bool showLoader = true;
  DateFormat inputFormat = DateFormat("dd-MM-yyyy hh:mm:ss a");

  // Define the desired output format
  DateFormat outputFormat = DateFormat("dd/MM/yyyy");
  PaymodeList payModeData = PaymodeList(paymodeId: '', paymode: '');
  List<Map<String, dynamic>> paymentDetails = [];
  DateTime now = DateTime.now();
  String todayDate = "";

  NumberFormat currencyFormat =
      NumberFormat.currency(symbol: "₹", decimalDigits: 2, locale: "hi_IN");
  @override
  void initState() {
    super.initState();
    try {
      dashboardController = Get.find<DashboardController>();
    } catch (e) {
      dashboardController = Get.put(DashboardController());
    }
    getApiCall();
  }

  Future<void> getApiCall() async {
    await dashboardController.getPayMode();
    await dashboardController.getDashboardData();
    payModeData = dashboardController.payModeList.firstWhere((element) {
      return element.paymode == "WALLET";
    });
    await approvalRenewalController.getRenewalList(pageName: 'APPROVAL');
    showLoader = false;
    setState(() {});
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  GlobalKey<FormState> approvalRenewalForm = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: AppColor.whiteColor,
        appBar: AppBar(
          titleSpacing: 0,
          toolbarHeight: 70,
          elevation: 2,
          shadowColor: AppColor.black3Color,
          surfaceTintColor: AppColor.whiteColor,
          scrolledUnderElevation: 2,
          backgroundColor: AppColor.whiteColor,
          title: CustomText(
            text: "Approval Renewal",
            fontSize: AppFontSize.size2,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body:
            // Obx(
            //       () =>
            showLoader
                ? const Center(
                    child: CircularProgressIndicator(
                      color: AppColor.primaryColor,
                    ),
                  )
                : StatefulBuilder(builder: (context, confirmDetailsState) {
                    return Column(
                      children: [
                        Expanded(
                          child: ListView(
                            children: [
                              SizedBox(
                                height: 50.w,
                              ),
                              // profile picture
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Center(
                                      child: Stack(
                                        children: [
                                          Image.asset(
                                            AssetPath.renewalWait,
                                            scale: 4,
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),
                                    PairText(
                                      keyText: "Approval Renewal",
                                      // valueText: "${'₹'} ${payableAmount.toString()}",
                                      valueText: currencyFormat.format(
                                          approvalRenewalController
                                              .renewalPaymemntList[0]
                                              .netPackageFees),
                                      valueSize: AppFontSize.size3,
                                      valueWeight: FontWeight.w400,
                                      valueColor: AppColor.subTitleColor,
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),
                                    BlueBorderContainer(
                                      borderColor: AppColor.primaryColor,
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10.w),
                                        child: ApprovalTwoLineWidget(
                                          title:
                                              "${approvalRenewalController.renewalPaymemntList[0].packageName.toString()} Term",
                                          duration:
                                              "${outputFormat.format(inputFormat.parse(approvalRenewalController.renewalPaymemntList[0].approvalStartDate))} - ${outputFormat.format(inputFormat.parse(approvalRenewalController.renewalPaymemntList[0].approvalEndDate))}",
                                          term: approvalRenewalController
                                              .renewalPaymemntList[0].duration,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),
                                    GreyContainerWidget(
                                        child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                flex: 6,
                                                child: BlueBorderContainer(
                                                  borderColor: AppColor
                                                      .containerBorderGreyColor,
                                                  child: WalletText(
                                                    assetName: AssetPath
                                                        .approvalWallet,
                                                    title: 'Current Balance',
                                                    subTitle:
                                                        currencyFormat.format(
                                                            dashboardController
                                                                .dashboardData[
                                                                    0]
                                                                .walletBalance),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10.w,
                                              ),
                                              Expanded(
                                                flex: 4,
                                                child: SizedBox(
                                                  child: InButton(
                                                    color:
                                                        AppColor.primaryColor,
                                                    text: "Add Fund",
                                                    onTap: () {
                                                      Get.to(
                                                          () =>
                                                              const WalletTopupScreen(),
                                                          transition: Transition
                                                              .rightToLeft,
                                                          duration:
                                                              const Duration(
                                                                  milliseconds:
                                                                      600));
                                                    },
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 20.w,
                                          ),
                                          Row(
                                            children: [
                                              const Icon(Icons.info,
                                                  color: AppColor
                                                      .primaryColor), // Information icon
                                              const SizedBox(
                                                  width:
                                                      10), // Space between icon and text
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "Please ensure your wallet has enough balance to complete the approval.",
                                                      style: TextStyle(
                                                        fontSize: 11.sp,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 30.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 150.w,
                                child: InButton(
                                  color: AppColor.primaryColor,
                                  text: "Pay",
                                  onTap: () async {
                                    if (dashboardController
                                            .dashboardData[0].walletBalance >
                                        approvalRenewalController
                                            .renewalPaymemntList[0]
                                            .netPackageFees) {
                                      paymentDetails.clear();
                                      var payment = {
                                        "paymentModeID": payModeData.paymodeId,
                                        "paymodeType": payModeData.paymode,
                                        "paymodeValue":
                                            approvalRenewalController
                                                .renewalPaymemntList[0]
                                                .netPackageFees
                                                .toString(),
                                        "amount": approvalRenewalController
                                            .renewalPaymemntList[0]
                                            .netPackageFees
                                            .toString(),
                                        "transactionDate":
                                            DateFormat('yyyy-MM-dd').format(now)
                                      };
                                      paymentDetails.add(payment);
                                      final body = {
                                        "packageID": approvalRenewalController
                                            .renewalPaymemntList[0].packageId,
                                        "transactionAmount":
                                            approvalRenewalController
                                                .renewalPaymemntList[0]
                                                .netPackageFees
                                                .toString(),
                                        "paymentType": payModeData.paymode,
                                        "paymentItems": paymentDetails
                                      };
                                      // log(body.toString());
                                      PleaseWaitLoader.openDialog();
                                      final bool paymentDone =
                                          await approvalRenewalController
                                              .makePayment(body: body);
                                      PleaseWaitLoader.closeDialog();
                                      if (paymentDone) {
                                        await dashboardController
                                            .getDashboardTotalDetails();
                                        DateTime approvalDate = _parseDate(
                                          dashboardController
                                              .dashboardTotalData[0]
                                              .approvalEndDate,
                                        );
                                        DateTime subscriptionDate = _parseDate(
                                          dashboardController
                                              .dashboardTotalData[0]
                                              .subscriptionEndDate,
                                        );
                                        if ((now.isAfter(approvalDate)) ||
                                            (now.isAfter(subscriptionDate))) {
                                          SharedPreference.putBool(
                                              AppStrings.expire, true);
                                          Get.to(
                                            const RenewalDetailPage(),
                                          );
                                          debugPrint("Renewal Needed");
                                        } else {
                                          // succes message
                                          debugPrint("Renewal Payment");
                                          SharedPreference.putBool(
                                              AppStrings.expire, false);
                                          Get.to(const DashboardScreen());
                                          showSuccessDialog(
                                              context: Get.context!,
                                              message:
                                                  'Payment done successfully');
                                        }
                                      }
                                    } else {
                                      Get.snackbar(
                                        'Insufficient Wallet Balance',
                                        'You don’t have enough balance to complete this action.',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  }));

    // );
  }

  DateTime _parseDate(String dateStr) {
    List<String> parts = dateStr.split('-');
    int day = int.parse(parts[0]);
    int month = int.parse(parts[1]);
    int year = int.parse(parts[2]);

    // Return a DateTime object for the given date
    return DateTime(year, month, day);
  }
}
