import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/renewal/ui/approval_renewal_page.dart';
import 'package:tcds/user_interface/renewal/ui/subscription_renewal_page.dart';
import 'package:tcds/utils/helper_widgets/pop_scope_handler.dart';
import '../../../constants/app_string.dart';
import '../../../constants/colors.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_widgets/blue_border_container.dart';
import '../../../utils/helper_widgets/custom_drawer.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/expiry_two_line_widget.dart';
import '../../dashboard/controller/dashboard_controller.dart';

class RenewalDetailPage extends StatefulWidget {
  const RenewalDetailPage({super.key});

  @override
  State<RenewalDetailPage> createState() => _RenewalDetailPageState();
}

class _RenewalDetailPageState extends State<RenewalDetailPage> {
  DashboardController dashboardController = Get.put(DashboardController());
  bool showLoader = true;
  DateFormat inputFormat = DateFormat("dd-MM-yyyy");
  // helper for to set, if expired renewal is only option in drawer
  late bool isLoggedin;
  late bool isExpired;

  // Define the desired output format
  DateFormat outputFormat = DateFormat("dd/MM/yyyy");

  @override
  void initState() {
    getApiCall();

    isLoggedin = SharedPreference.getBool(AppStrings.isLoggedIn);
    isExpired = SharedPreference.getBool(AppStrings.expire);
    super.initState();
  }

  Future<void> getApiCall() async {
    await dashboardController.getDashboardTotalDetails();
    await dashboardController.getFranchiseeProfilePicture();
    showLoader = false;
    setState(() {});
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return PopScopeHandler(
      child: Scaffold(
          key: _scaffoldKey,
          backgroundColor: AppColor.whiteColor,
          drawer: Drawer(
            child: CustomDrawer(
              currentIndex: (isLoggedin && isExpired) ? 0 : 9,
            ),
          ),
          appBar: AppBar(
            elevation: 2,
            shadowColor: AppColor.black3Color,
            surfaceTintColor: AppColor.whiteColor,
            scrolledUnderElevation: 2,
            backgroundColor: AppColor.whiteColor,
            toolbarHeight: 70,
            titleSpacing: 0,
            title: CustomText(
              text: "Renewal",
              fontSize: 18.sp,
              fontWeight: FontWeight.w500,
              color: AppColor.primaryColor,
            ),
            leading: IconButton(
              icon: const Icon(Icons.menu),
              onPressed: () {
                _scaffoldKey.currentState!.openDrawer();
              },
            ),
          ),
          body:
              // Obx(
              //       () =>
              showLoader
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: AppColor.primaryColor,
                      ),
                    )
                  : StatefulBuilder(builder: (context, confirmDetailsState) {
                      return ListView(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        children: [
                          Column(
                            children: [
                              InkWell(
                                onTap: () async {
                                  Get.to(() => const ApprovalRenewalPage(),
                                      transition: Transition.rightToLeft,
                                      duration:
                                          const Duration(milliseconds: 600));
                                },
                                child: BlueBorderContainer(
                                  borderColor: AppColor.shadowBorder,
                                  child: Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.w),
                                    child: ExpiryTwoLineWidget(
                                      title: "Approval Renewal",
                                      duration:
                                          "${outputFormat.format(inputFormat.parse(dashboardController.dashboardTotalData[0].approvalStartDate))} - ${outputFormat.format(inputFormat.parse(dashboardController.dashboardTotalData[0].approvalEndDate))}",
                                      //"${dashboardController.dashboardTotalData[0].approvalStartDate} - ${dashboardController.dashboardTotalData[0].approvalEndDate}",
                                      term: dashboardController
                                          .dashboardTotalData[0]
                                          .approvalRemainingDays,
                                      progress: dashboardController
                                              .dashboardTotalData[0]
                                              .approvalCompletedDays /
                                          dashboardController
                                              .dashboardTotalData[0]
                                              .approvalTotalDays,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              InkWell(
                                onTap: () async {
                                  Get.to(() => const SubscriptionRenewalPage(),
                                      transition: Transition.rightToLeft,
                                      duration:
                                          const Duration(milliseconds: 600));
                                },
                                child: BlueBorderContainer(
                                  borderColor: AppColor.shadowBorder,
                                  child: Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.w),
                                    child: ExpiryTwoLineWidget(
                                      title: "Subscription Renewal",
                                      duration:
                                          "${outputFormat.format(inputFormat.parse(dashboardController.dashboardTotalData[0].subscriptionStartDate))} - ${outputFormat.format(inputFormat.parse(dashboardController.dashboardTotalData[0].subscriptionEndDate))}",
                                      //duration:"${dashboardController.dashboardTotalData[0].subscriptionStartDate} - ${dashboardController.dashboardTotalData[0].subscriptionEndDate}",
                                      term: dashboardController
                                          .dashboardTotalData[0]
                                          .subscriptionRemainingDays,
                                      progress: dashboardController
                                              .dashboardTotalData[0]
                                              .subscriptionCompletedDays /
                                          dashboardController
                                              .dashboardTotalData[0]
                                              .subscriptionTotalDays,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: 15.w,
                              ),
                            ],
                          ),
                        ],
                      );
                    })),
    );

    // );
  }

  /* Widget _buildInfoCard(String title,String start, String end,String expiry) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 5.w),
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.w),
        decoration: BoxDecoration(
          // color: Colors.grey[100],
          color: AppColor.whiteColor,
          border: Border.all(color: Colors.black.withOpacity(0.1)),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomText(
                  text: title,
                  fontSize: AppFontSize.size3,
                  fontWeight: FontWeight.w700,
                  textAlign: TextAlign.end,
                ),
              ],
            ),
            SizedBox(height: 5.w,),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: "Start Date",
                        fontSize: AppFontSize.size5,
                        fontWeight: FontWeight.w400,
                        textAlign: TextAlign.end,
                      ),
                      CustomText(
                        text: "EndDate",
                        fontSize: AppFontSize.size5,
                        fontWeight: FontWeight.w400,
                        textAlign: TextAlign.end,
                      ),
                      CustomText(
                        text: "expires in :",
                        fontSize: AppFontSize.size5,
                        fontWeight: FontWeight.w400,
                        textAlign: TextAlign.end,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      CustomText(
                        text: start,
                        fontSize: AppFontSize.size4,
                        color: AppColor.primaryColor,
                        fontWeight: FontWeight.bold,
                        textAlign: TextAlign.start,
                      ),
                      CustomText(
                        text: end,
                        fontSize: AppFontSize.size4,
                        color: AppColor.deleteRed,
                        fontWeight: FontWeight.bold,
                        textAlign: TextAlign.start,
                      ),
                      CustomText(
                        text: "$expiry days",
                        fontSize: AppFontSize.size4,
                        color: AppColor.deleteRed,
                        fontWeight: FontWeight.bold,
                        textAlign: TextAlign.start,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  } */
}
