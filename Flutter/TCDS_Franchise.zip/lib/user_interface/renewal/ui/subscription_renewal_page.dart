import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/user_interface/renewal/ui/renewal_detail_page.dart';
import '../../../constants/app_string.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/font_sizes.dart';
import '../../../constants/shared_preference.dart';
import '../../../utils/helper_functions/common_dialogs.dart';
import '../../../utils/helper_functions/please_wait_loader.dart';
import '../../../utils/helper_widgets/approval_two_line_widget.dart';
import '../../../utils/helper_widgets/blue_border_container.dart';
import '../../../utils/helper_widgets/custom_text.dart';
import '../../../utils/helper_widgets/grey_container_widget.dart';
import '../../../utils/helper_widgets/in_button.dart';
import '../../../utils/helper_widgets/wallet_container_widget.dart';
import '../../dashboard/controller/dashboard_controller.dart';
import '../../dashboard/model/paymode_list_response_model.dart';
import '../../dashboard/view/dashboard_screen.dart';
import '../../dashboard/view/wallet_topup_screen.dart';
import '../controller/approval_renewal_controller.dart';
import '../model/renewal_payment_model.dart';

class SubscriptionRenewalPage extends StatefulWidget {
  const SubscriptionRenewalPage({super.key});

  @override
  State<SubscriptionRenewalPage> createState() =>
      _SubscriptionRenewalPageState();
}

class _SubscriptionRenewalPageState extends State<SubscriptionRenewalPage> {
  ApprovalRenewalController approvalRenewalController =
      Get.put(ApprovalRenewalController());
  late DashboardController dashboardController;
  bool showLoader = true;
  PaymodeList payModeData = PaymodeList(paymodeId: '', paymode: '');
  int selectedIndex = 0;
  DateFormat inputFormat = DateFormat("dd-MM-yyyy hh:mm:ss a");

  DateFormat outputFormat = DateFormat("dd/MM/yyyy");
  String selectedMonth = "";
  String startTime = "";
  String endTime = "";
  String amount = "";
  List<Map<String, dynamic>> paymentDetails = [];
  DateTime now = DateTime.now();
  String todayDate = "";
  String packageId = "";

  NumberFormat currencyFormat =
      NumberFormat.currency(symbol: "₹", decimalDigits: 2, locale: "hi_IN");

  @override
  void initState() {
    super.initState();
    try {
      dashboardController = Get.find<DashboardController>();
    } catch (e) {
      dashboardController = Get.put(DashboardController());
    }
    getApiCall();
  }

  Future<void> getApiCall() async {
    await dashboardController.getPayMode();
    await dashboardController.getDashboardData();
    payModeData = dashboardController.payModeList.firstWhere((element) {
      return element.paymode == "WALLET";
    });
    await approvalRenewalController.getRenewalList(pageName: 'SUBSCRIPTION');
    selectedMonth = approvalRenewalController.renewalPaymemntList[0].duration;
    startTime =
        approvalRenewalController.renewalPaymemntList[0].subscriptionStartDate;
    endTime =
        approvalRenewalController.renewalPaymemntList[0].subscriptionEndDate;
    packageId = approvalRenewalController.renewalPaymemntList[0].packageId;
    amount = approvalRenewalController.renewalPaymemntList[0].netPackageFees
        .toString();
    showLoader = false;
    setState(() {});
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: AppColor.whiteColor,
        appBar: AppBar(
          titleSpacing: 0,
          toolbarHeight: 70,
          elevation: 2,
          shadowColor: AppColor.black3Color,
          surfaceTintColor: AppColor.whiteColor,
          scrolledUnderElevation: 2,
          backgroundColor: AppColor.whiteColor,
          title: CustomText(
            text: "Subscription Renewal",
            fontSize: AppFontSize.size2,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios),
            onPressed: () {
              Get.back();
            },
          ),
        ),
        body:
            // Obx(
            //       () =>
            showLoader
                ? const Center(
                    child: CircularProgressIndicator(
                      color: AppColor.primaryColor,
                    ),
                  )
                : StatefulBuilder(builder: (context, confirmDetailsState) {
                    return Column(
                      children: [
                        Expanded(
                          child: ListView(
                            children: [
                              SizedBox(
                                height: 50.w,
                              ),
                              // profile picture
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 20.w),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Center(
                                      child: InkWell(
                                          onTap: () async {},
                                          child: Stack(
                                            children: [
                                              Image.asset(
                                                AssetPath.renewalWait,
                                                scale: 4,
                                              ),
                                            ],
                                          )),
                                    ),
                                    SizedBox(
                                      height: 40.w,
                                    ),
                                    BlueBorderContainer(
                                      borderColor: AppColor.primaryColor,
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10.w),
                                        child: ApprovalTwoLineWidget(
                                          title: "Subscription Term",
                                          duration:
                                              "${outputFormat.format(inputFormat.parse(startTime))} - ${outputFormat.format(inputFormat.parse(endTime))}",
                                          term: selectedMonth,
                                          onTap: () async {},
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),
                                    buildSubscriptionDetailWidget(
                                      paymentData: approvalRenewalController
                                          .renewalPaymemntList,
                                    ),
                                    GreyContainerWidget(
                                        child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                flex: 6,
                                                child: BlueBorderContainer(
                                                  borderColor: AppColor
                                                      .containerBorderGreyColor,
                                                  child: WalletText(
                                                    assetName: AssetPath
                                                        .approvalWallet,
                                                    title: 'Current Balance',
                                                    subTitle:
                                                        currencyFormat.format(
                                                            dashboardController
                                                                .dashboardData[
                                                                    0]
                                                                .walletBalance),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10.w,
                                              ),
                                              Expanded(
                                                flex: 4,
                                                child: SizedBox(
                                                  child: InButton(
                                                    color:
                                                        AppColor.primaryColor,
                                                    text: "Add Fund",
                                                    onTap: () {
                                                      Get.to(
                                                          const WalletTopupScreen());
                                                    },
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 20.w,
                                          ),
                                          Row(
                                            children: [
                                              const Icon(Icons.info,
                                                  color: AppColor
                                                      .primaryColor), // Information icon
                                              const SizedBox(
                                                  width:
                                                      10), // Space between icon and text
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      "Please ensure your wallet has enough balance to complete the approval.",
                                                      style: TextStyle(
                                                        fontSize: 11.sp,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                      maxLines: 2,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    )),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 30.w),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 150.w,
                                child: InButton(
                                  color: AppColor.primaryColor,
                                  text: "Pay",
                                  onTap: () async {
                                    if (dashboardController
                                            .dashboardData[0].walletBalance >
                                        double.parse(amount)) {
                                      // Show the confirmation dialog before proceeding
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title:
                                                const Text('Confirm Payment'),
                                            content: const Text(
                                                'Are you sure you want to make this payment?'),
                                            actions: <Widget>[
                                              // No button: closes the dialog
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.of(context)
                                                      .pop(); // Close the dialog
                                                },
                                                child: const Text('No'),
                                              ),
                                              // Yes button: performs the payment and proceeds
                                              TextButton(
                                                onPressed: () async {
                                                  Navigator.of(context)
                                                      .pop(); // Close the dialog

                                                  // Proceed with the payment logic
                                                  paymentDetails.clear();
                                                  var payment = {
                                                    "paymentModeID":
                                                        payModeData.paymodeId,
                                                    "paymodeType":
                                                        payModeData.paymode,
                                                    "paymodeValue": amount,
                                                    "amount": amount,
                                                    "transactionDate":
                                                        DateFormat('yyyy-MM-dd')
                                                            .format(now)
                                                  };
                                                  paymentDetails.add(payment);
                                                  final body = {
                                                    "packageID": packageId,
                                                    "transactionAmount": amount,
                                                    "paymentType":
                                                        payModeData.paymode,
                                                    "paymentItems":
                                                        paymentDetails
                                                  };
                                                  // log(body.toString());

                                                  PleaseWaitLoader.openDialog();
                                                  final bool paymentDone =
                                                      await approvalRenewalController
                                                          .makePayment(
                                                              body: body);
                                                  PleaseWaitLoader
                                                      .closeDialog();

                                                  if (paymentDone) {
                                                    await dashboardController
                                                        .getDashboardTotalDetails();
                                                    DateTime approvalDate =
                                                        _parseDate(dashboardController
                                                            .dashboardTotalData[
                                                                0]
                                                            .approvalEndDate);
                                                    DateTime subscriptionDate =
                                                        _parseDate(dashboardController
                                                            .dashboardTotalData[
                                                                0]
                                                            .subscriptionEndDate);

                                                    if ((now.isAfter(
                                                            approvalDate)) ||
                                                        (now.isAfter(
                                                            subscriptionDate))) {
                                                      SharedPreference.putBool(
                                                          AppStrings.expire,
                                                          true);
                                                      Get.to(
                                                          const RenewalDetailPage());
                                                      debugPrint(
                                                          "Renewal Needed");
                                                    } else {
                                                      // Success message
                                                      debugPrint(
                                                          "Subscription Payment");
                                                      SharedPreference.putBool(
                                                          AppStrings.expire,
                                                          false);
                                                      Get.to(
                                                          const DashboardScreen());
                                                      showSuccessDialog(
                                                        context: Get.context!,
                                                        message:
                                                            'Payment done successfully',
                                                      );
                                                    }
                                                  }
                                                },
                                                child: const Text('Yes'),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    } else {
                                      Get.snackbar(
                                        'Amount Tally',
                                        'Wallet Amount is In-sufficient',
                                        colorText: AppColor.whiteColor,
                                        padding: EdgeInsets.all(15.w),
                                        backgroundColor: AppColor.primaryColor,
                                      );
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  }));

    // );
  }

  Widget buildSubscriptionDetailWidget(
      {required List<RenewalPayment> paymentData}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(
                      paymentData.length,
                      (index) => GestureDetector(
                        onTap: () {
                          selectedIndex = index;
                          selectedMonth = paymentData[index].duration;
                          startTime = paymentData[index].subscriptionStartDate;
                          endTime = paymentData[index].subscriptionEndDate;
                          amount = paymentData[index].netPackageFees.toString();
                          packageId = paymentData[index].packageId.toString();
                          setState(() {});
                        },
                        child: Container(
                          margin: EdgeInsets.only(
                              right: 10.w, top: 10.w, bottom: 10.w),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: selectedIndex == index
                                      ? AppColor.secondaryColor
                                      : AppColor.white2Color,
                                  width: selectedIndex == index ? 3.w : 1.w),
                              borderRadius: BorderRadius.circular(5.w),
                              color: AppColor.white2Color),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 10.w, horizontal: 15.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // Icon
                                ClipOval(
                                  child: Container(
                                    height: selectedIndex == index
                                        ? 45.w
                                        : 40.w, // Reduced height
                                    width: selectedIndex == index
                                        ? 45.w
                                        : 40.w, // Reduced width
                                    alignment: Alignment.center,
                                    child: Image.asset(
                                      "assets/image${index + 1}.png",
                                      fit: BoxFit
                                          .contain, // Ensures the image fits inside the container
                                      scale:
                                          3.0, // Adjust scale for better control
                                    ),
                                  ),
                                ),
                                SizedBox(
                                    height:
                                        10.w), // Space between icon and text
                                // Title
                                Text(
                                  paymentData[index].duration,
                                  style: TextStyle(
                                    fontSize:
                                        selectedIndex == index ? 13.sp : 12.sp,
                                    fontWeight: FontWeight.w400,
                                    color: selectedIndex == index
                                        ? AppColor.secondaryColor
                                        : AppColor.subTitleColor,
                                  ),
                                ),
                                SizedBox(
                                    height: 5
                                        .w), // Space between title and subtitle
                                // Subtitle
                                Text(
                                  currencyFormat.format(
                                      paymentData[index].netPackageFees),
                                  style: TextStyle(
                                    fontSize:
                                        selectedIndex == index ? 15.sp : 14.sp,
                                    fontWeight: FontWeight.w500,
                                    color: selectedIndex == index
                                        ? AppColor.secondaryColor
                                        : AppColor.titleColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  DateTime _parseDate(String dateStr) {
    List<String> parts = dateStr.split('-');
    int day = int.parse(parts[0]);
    int month = int.parse(parts[1]);
    int year = int.parse(parts[2]);

    // Return a DateTime object for the given date
    return DateTime(year, month, day);
  }
}
