import 'dart:async';
import 'dart:collection';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/app_string.dart';
import 'package:tcds/http_engine/engine.dart';
import 'package:tcds/user_interface/dashboard/model/profile_image_response_model.dart';
import 'package:tcds/user_interface/students_list/model/batch_list_by_course_id_response_model.dart';
import 'package:tcds/user_interface/students_list/model/course_basic_info_response_model.dart';
import 'package:tcds/user_interface/students_list/model/course_list_by_franchisee_response_model.dart';
import 'package:tcds/user_interface/students_list/model/course_type_response_model.dart';
import 'package:tcds/user_interface/students_list/model/student_list_by_branch_wise.dart';
import 'package:tcds/user_interface/students_list/model/student_list_response_model.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';

import '../../exam/model/franchise_course_batch_list_model.dart';
import '../../exam/model/franchise_course_list_model.dart';
import '../../exam/model/franchise_student_batch_list_model.dart';
import '../model/material_list_model.dart';
import '../model/material_type_list_model.dart';

class StudentListController extends GetxController {
  HttpEngine engine = HttpEngine();
  RxBool studentListScreenLoader = false.obs;
  RxList<StudentList> studentList = <StudentList>[].obs;
  RxList<CourseTypeList> courseTypeList = <CourseTypeList>[].obs;
  RxList<StudentListBranchWiseData> studentByBranchWiseList =
      <StudentListBranchWiseData>[].obs;
  RxList<BatchListByCourseIdList> batchListByCourseId =
      <BatchListByCourseIdList>[].obs;
  RxList<ProfileImageData> profileImageDataList = <ProfileImageData>[].obs;
  RxList<CourseBasicList> courseBasicInfoList = <CourseBasicList>[].obs;
  RxList<CourseListByFranchisee> courseListByFranchisee =
      <CourseListByFranchisee>[].obs;
  RxList<MaterialTypeData> materialTypeDataList = <MaterialTypeData>[].obs;
  RxList<MaterialData> materialDataList = <MaterialData>[].obs;
  RxList<FranchiseCourseData> franchiseCourseDataList =
      <FranchiseCourseData>[].obs;
  RxList<CourseBatchData> franchiseCourseBatchDataList =
      <CourseBatchData>[].obs;
  RxList<BatchStudentData> franchiseStudentBatchDataList =
      <BatchStudentData>[].obs;

  // Image caching and loading state management
  final Map<String, String> _imageCache = HashMap<String, String>();
  final Map<String, bool> _imageLoadingStates = HashMap<String, bool>();

  // Getter for cached image
  String? getCachedImage(String contactId) => _imageCache[contactId];

  // Check if image is currently loading
  bool isImageLoading(String contactId) =>
      _imageLoadingStates[contactId] ?? false;

  // Set image loading state
  void setImageLoadingState(String contactId, bool loading) {
    _imageLoadingStates[contactId] = loading;
    update(); // Update the UI
  }

  // Cache image
  void cacheImage(String contactId, String base64Image) {
    _imageCache[contactId] = base64Image;
  }

  // Clear image cache
  void clearImageCache() {
    _imageCache.clear();
    _imageLoadingStates.clear();
  }

  Future<bool> getStudentList({required dynamic body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getStudentList, body)
          .then((value) async {
        StudentListResponseModel model =
            StudentListResponseModel.fromJson(value.data);
        studentList.value = model.data;

        // Start fetching images concurrently for all students
        _fetchImagesConcurrently();

        debugPrint(value.data.toString());
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Fetch images concurrently for all students
  void _fetchImagesConcurrently() {
    for (var i = 0; i < studentList.length; i++) {
      final student = studentList[i];
      final contactId = student.contactId;

      // Set initial loading state to false and image to null
      student.base64Image = null;

      // Check if image is already cached
      if (_imageCache.containsKey(contactId)) {
        student.base64Image = _imageCache[contactId]!;
        studentList[i] = student; // Update the student in the list
        continue;
      }

      // Start loading image asynchronously
      _loadStudentImage(i, contactId);
    }
  }

  // Load image for a specific student
  Future<void> _loadStudentImage(int index, String contactId) async {
    try {
      // Set loading state
      setImageLoadingState(contactId, true);

      // Fetch image
      final success = await getProfilePicture(contactID: contactId);

      if (success && profileImageDataList.isNotEmpty) {
        final base64Image = profileImageDataList[0].profileBase64;

        // Cache the image
        cacheImage(contactId, base64Image);

        // Update only the specific student's image
        if (index < studentList.length) {
          final student = studentList[index];
          student.base64Image = base64Image;
          studentList[index] = student;
        }
      } else {
        // Image not found, ensure it's null
        if (index < studentList.length) {
          final student = studentList[index];
          student.base64Image = null;
          studentList[index] = student;
        }
      }
    } catch (e) {
      debugPrint('Error loading image for contact $contactId: $e');
      // Set image to null on error
      if (index < studentList.length) {
        final student = studentList[index];
        student.base64Image = null;
        studentList[index] = student;
      }
    } finally {
      // Clear loading state
      setImageLoadingState(contactId, false);
    }
  }

  // Get Profile picture
  Future<bool> getProfilePicture({required String contactID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getProfileImage + contactID,
              protected: true)
          .then((value) {
        debugPrint(value.toString());
        ProfileImageResponseModel model =
            ProfileImageResponseModel.fromJson(value.data);
        profileImageDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
      profileImageDataList.clear();
    }

    return resultValue;
  }

  Future<bool> getCourseTypeList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseTypeUrl)
          .then((value) {
        CourseTypeResponseModel model =
            CourseTypeResponseModel.fromJson(value.data);
        courseTypeList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getStudentListByBatchWise() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.studentListByBranch)
          .then((value) {
        StudentListByBranchWiseResponseModel model =
            StudentListByBranchWiseResponseModel.fromJson(value.data);
        studentByBranchWiseList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getCourseBasicInfo() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseBasicInfo)
          .then((value) {
        CourseBasicInfoResponseModel model =
            CourseBasicInfoResponseModel.fromJson(value.data);
        courseBasicInfoList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getBatchListByCourseId({required String courseId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.batchListByCourseId + courseId)
          .then((value) {
        BatchListByCourseIdResponseModel model =
            BatchListByCourseIdResponseModel.fromJson(value.data);
        batchListByCourseId.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      // PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getCourseListByFranchisee() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseListByFranchisee)
          .then((value) {
        CourseListByFranchiseeResponseModel model =
            CourseListByFranchiseeResponseModel.fromJson(value.data);
        courseListByFranchisee.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getMaterialTypeList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.materialTypeList)
          .then((value) {
        MaterialTypeListModel model =
            MaterialTypeListModel.fromJson(value.data);
        materialTypeDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getMaterialList({required String materialTypeId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl +
              AppStrings.materialListByMaterialTypeId +
              materialTypeId)
          .then((value) {
        MaterialListModel model = MaterialListModel.fromJson(value.data);
        materialDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      // PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getFranchiseCourseList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.franchiseCourseListUrl)
          .then((value) {
        // log(jsonEncode(value.data));
        FranchiseCourseListModel model =
            FranchiseCourseListModel.fromJson(value.data);
        franchiseCourseDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getFranchiseCourseBatchList({required String courseId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl +
              AppStrings.getFranchiseCourseBatchListUrl +
              courseId)
          .then((value) {
        FranchiseCourseBatchListModel model =
            FranchiseCourseBatchListModel.fromJson(value.data);
        franchiseCourseBatchDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      // PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }

  Future<bool> getStudentListByBatch({required String batchId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl +
              AppStrings.getFranchiseStudentListByBatchUrl +
              batchId)
          .then((value) {
        FranchiseStudentBatchListModel model =
            FranchiseStudentBatchListModel.fromJson(value.data);
        franchiseStudentBatchDataList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      // PleaseWaitLoader.closeDialog();
      debugPrint(e.toString());
    }

    return resultValue;
  }
}
