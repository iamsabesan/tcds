// To parse this JSON data, do
//
//     final batchListByCourseIdResponseModel = batchListByCourseIdResponseModelFromJson(jsonString);

import 'dart:convert';

BatchListByCourseIdResponseModel batchListByCourseIdResponseModelFromJson(String str) => BatchListByCourseIdResponseModel.fromJson(json.decode(str));

String batchListByCourseIdResponseModelToJson(BatchListByCourseIdResponseModel data) => json.encode(data.toJson());

class BatchListByCourseIdResponseModel {
  int code;
  String message;
  List<BatchListByCourseIdList> data;

  BatchListByCourseIdResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory BatchListByCourseIdResponseModel.fromJson(Map<String, dynamic> json) => BatchListByCourseIdResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<BatchListByCourseIdList>.from(json["Data"].map((x) => BatchListByCourseIdList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class BatchListByCourseIdList {
  String batchNumber;
  String courseBatchId;
  String timing;
  String facultyId;
  String facultyName;
  String batchType;

  BatchListByCourseIdList({
    required this.batchNumber,
    required this.courseBatchId,
    required this.timing,
    required this.facultyId,
    required this.facultyName,
    required this.batchType,
  });

  factory BatchListByCourseIdList.fromJson(Map<String, dynamic> json) => BatchListByCourseIdList(
    batchNumber: json["BatchNumber"],
    courseBatchId: json["CourseBatchID"],
    timing: json["Timing"],
    facultyId: json["FacultyID"],
    facultyName: json["FacultyName"],
    batchType: json["BatchType"],
  );

  Map<String, dynamic> toJson() => {
    "BatchNumber": batchNumber,
    "CourseBatchID": courseBatchId,
    "Timing": timing,
    "FacultyID": facultyId,
    "FacultyName": facultyName,
    "BatchType": batchType,
  };
}
