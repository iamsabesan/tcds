// To parse this JSON data, do
//
//     final getCourseBasicInfoResponseModel = getCourseBasicInfoResponseModelFromJson(jsonString);

import 'dart:convert';

CourseBasicInfoResponseModel getCourseBasicInfoResponseModelFromJson(String str) => CourseBasicInfoResponseModel.fromJson(json.decode(str));

String getCourseBasicInfoResponseModelToJson(CourseBasicInfoResponseModel data) => json.encode(data.toJson());

class CourseBasicInfoResponseModel {
  int code;
  String message;
  List<CourseBasicList> data;

  CourseBasicInfoResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourseBasicInfoResponseModel.fromJson(Map<String, dynamic> json) => CourseBasicInfoResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CourseBasicList>.from(json["Data"].map((x) => CourseBasicList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CourseBasicList {
  String courseId;
  String shortName;
  String course;
  String courseType;
  int semester;
  String duration;
  double courseFees;
  double examFees;
  double admissionFees;
  double totalFees;

  CourseBasicList({
    required this.courseId,
    required this.shortName,
    required this.course,
    required this.courseType,
    required this.semester,
    required this.duration,
    required this.courseFees,
    required this.examFees,
    required this.admissionFees,
    required this.totalFees,
  });

  factory CourseBasicList.fromJson(Map<String, dynamic> json) => CourseBasicList(
    courseId: json["CourseID"],
    shortName: json["ShortName"],
    course: json["Course"],
    courseType: json["CourseType"],
    semester: json["Semester"],
    duration: json["Duration"],
    courseFees: json["CourseFees"],
    examFees: json["ExamFees"],
    admissionFees: json["AdmissionFees"],
    totalFees: json["TotalFees"],
  );

  Map<String, dynamic> toJson() => {
    "CourseID": courseId,
    "ShortName": shortName,
    "Course": course,
    "CourseType": courseType,
    "Semester": semester,
    "Duration": duration,
    "CourseFees": courseFees,
    "ExamFees": examFees,
    "AdmissionFees": admissionFees,
    "TotalFees": totalFees,
  };
}
