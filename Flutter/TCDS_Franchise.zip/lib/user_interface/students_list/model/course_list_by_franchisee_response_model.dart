// To parse this JSON data, do
//
//     final courseListByFranchiseeResponseModel = courseListByFranchiseeResponseModelFromJson(jsonString);

import 'dart:convert';

CourseListByFranchiseeResponseModel courseListByFranchiseeResponseModelFromJson(String str) => CourseListByFranchiseeResponseModel.fromJson(json.decode(str));

String courseListByFranchiseeResponseModelToJson(CourseListByFranchiseeResponseModel data) => json.encode(data.toJson());

class CourseListByFranchiseeResponseModel {
  int code;
  String message;
  List<CourseListByFranchisee> data;

  CourseListByFranchiseeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourseListByFranchiseeResponseModel.fromJson(Map<String, dynamic> json) => CourseListByFranchiseeResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CourseListByFranchisee>.from(json["Data"].map((x) => CourseListByFranchisee.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CourseListByFranchisee {
  String courseId;
  String shortName;
  String course;
  String courseType;
  int semester;
  String duration;
  double courseFees;
  double examFees;
  double admissionFees;
  double totalFees;

  CourseListByFranchisee({
    required this.courseId,
    required this.shortName,
    required this.course,
    required this.courseType,
    required this.semester,
    required this.duration,
    required this.courseFees,
    required this.examFees,
    required this.admissionFees,
    required this.totalFees,
  });

  factory CourseListByFranchisee.fromJson(Map<String, dynamic> json) => CourseListByFranchisee(
    courseId: json["CourseID"],
    shortName: json["ShortName"],
    course: json["Course"],
    courseType: json["CourseType"],
    semester: json["Semester"],
    duration: json["Duration"],
    courseFees: json["CourseFees"],
    examFees: json["ExamFees"],
    admissionFees: json["AdmissionFees"],
    totalFees: json["TotalFees"],
  );

  Map<String, dynamic> toJson() => {
    "CourseID": courseId,
    "ShortName": shortName,
    "Course": course,
    "CourseType": courseType,
    "Semester": semester,
    "Duration": duration,
    "CourseFees": courseFees,
    "ExamFees": examFees,
    "AdmissionFees": admissionFees,
    "TotalFees": totalFees,
  };
}
