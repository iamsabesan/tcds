// To parse this JSON data, do
//
//     final courseTypeResponseModel = courseTypeResponseModelFromJson(jsonString);

import 'dart:convert';

CourseTypeResponseModel courseTypeResponseModelFromJson(String str) => CourseTypeResponseModel.fromJson(json.decode(str));

String courseTypeResponseModelToJson(CourseTypeResponseModel data) => json.encode(data.toJson());

class CourseTypeResponseModel {
  int code;
  String message;
  List<CourseTypeList> data;

  CourseTypeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CourseTypeResponseModel.fromJson(Map<String, dynamic> json) => CourseTypeResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CourseTypeList>.from(json["Data"].map((x) => CourseTypeList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CourseTypeList {
  String courseTypeId;
  String courseType;

  CourseTypeList({
    required this.courseTypeId,
    required this.courseType,
  });

  factory CourseTypeList.fromJson(Map<String, dynamic> json) => CourseTypeList(
    courseTypeId: json["CourseTypeID"],
    courseType: json["CourseType"],
  );

  Map<String, dynamic> toJson() => {
    "CourseTypeID": courseTypeId,
    "CourseType": courseType,
  };
}
