// To parse this JSON data, do
//
//     final materialListModel = materialListModelFromJson(jsonString);

import 'dart:convert';

MaterialListModel materialListModelFromJson(String str) =>
    MaterialListModel.fromJson(json.decode(str));

String materialListModelToJson(MaterialListModel data) =>
    json.encode(data.toJson());

class MaterialListModel {
  int code;
  String message;
  List<MaterialData> data;

  MaterialListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory MaterialListModel.fromJson(Map<String, dynamic> json) =>
      MaterialListModel(
        code: json["Code"],
        message: json["Message"],
        data: List<MaterialData>.from(
            json["Data"].map((x) => MaterialData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class MaterialData {
  String materialId;
  String materialName;
  double price;
  int minimumStock;
  int openingStock;
  double cgst;
  double sgst;
  int currentStock;

  MaterialData({
    required this.materialId,
    required this.materialName,
    required this.price,
    required this.minimumStock,
    required this.openingStock,
    required this.currentStock,
    required this.cgst,
    required this.sgst,
  });

  factory MaterialData.fromJson(Map<String, dynamic> json) => MaterialData(
        materialId: json["MaterialID"],
        materialName: json["MaterialName"],
        price: json["Price"]?.toDouble(),
        minimumStock: json["MinimumStock"],
        openingStock: json["OpeningStock"],
        cgst: json["CGST"]?.toDouble(),
        sgst: json["SGST"]?.toDouble(),
        currentStock: json["CurrentStock"],
      );

  Map<String, dynamic> toJson() => {
        "MaterialID": materialId,
        "MaterialName": materialName,
        "Price": price,
        "MinimumStock": minimumStock,
        "OpeningStock": openingStock,
        "CGST": cgst,
        "SGST": sgst,
        "CurrentStock": currentStock,
      };
}
