// To parse this JSON data, do
//
//     final materialTypeListModel = materialTypeListModelFromJson(jsonString);

import 'dart:convert';

MaterialTypeListModel materialTypeListModelFromJson(String str) => MaterialTypeListModel.fromJson(json.decode(str));

String materialTypeListModelToJson(MaterialTypeListModel data) => json.encode(data.toJson());

class MaterialTypeListModel {
  int code;
  String message;
  List<MaterialTypeData> data;

  MaterialTypeListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory MaterialTypeListModel.fromJson(Map<String, dynamic> json) => MaterialTypeListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<MaterialTypeData>.from(json["Data"].map((x) => MaterialTypeData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class MaterialTypeData {
  String materialTypeId;
  String materialType;

  MaterialTypeData({
    required this.materialTypeId,
    required this.materialType,
  });

  factory MaterialTypeData.fromJson(Map<String, dynamic> json) => MaterialTypeData(
    materialTypeId: json["MaterialTypeID"],
    materialType: json["MaterialType"],
  );

  Map<String, dynamic> toJson() => {
    "MaterialTypeID": materialTypeId,
    "MaterialType": materialType,
  };
}
