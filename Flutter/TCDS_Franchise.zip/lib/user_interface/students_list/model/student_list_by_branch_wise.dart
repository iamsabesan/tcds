// To parse this JSON data, do
//
//     final studentListByBranchWiseResponseModel = studentListByBranchWiseResponseModelFromJson(jsonString);

import 'dart:convert';

StudentListByBranchWiseResponseModel studentListByBranchWiseResponseModelFromJson(String str) => StudentListByBranchWiseResponseModel.fromJson(json.decode(str));

String studentListByBranchWiseResponseModelToJson(StudentListByBranchWiseResponseModel data) => json.encode(data.toJson());

class StudentListByBranchWiseResponseModel {
  int code;
  String message;
  List<StudentListBranchWiseData> data;

  StudentListByBranchWiseResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StudentListByBranchWiseResponseModel.fromJson(Map<String, dynamic> json) => StudentListByBranchWiseResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<StudentListBranchWiseData>.from(json["Data"].map((x) => StudentListBranchWiseData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class StudentListBranchWiseData {
  String batchMappingId;
  String studentId;
  String contactId;
  String rollNumber;
  String studentName;
  String phone;
  String alternatePhone;
  String course;
  String batchNumber;
  String batchTime;

  StudentListBranchWiseData({
    required this.batchMappingId,
    required this.studentId,
    required this.contactId,
    required this.rollNumber,
    required this.studentName,
    required this.phone,
    required this.alternatePhone,
    required this.course,
    required this.batchNumber,
    required this.batchTime,
  });

  factory StudentListBranchWiseData.fromJson(Map<String, dynamic> json) => StudentListBranchWiseData(
    batchMappingId: json["BatchMappingID"],
    studentId: json["StudentID"],
    contactId: json["ContactID"],
    rollNumber: json["RollNumber"],
    studentName: json["StudentName"],
    phone: json["Phone"],
    alternatePhone: json["AlternatePhone"],
    course: json["Course"],
    batchNumber: json["BatchNumber"],
    batchTime: json["BatchTime"],
  );

  Map<String, dynamic> toJson() => {
    "BatchMappingID": batchMappingId,
    "StudentID": studentId,
    "ContactID": contactId,
    "RollNumber": rollNumber,
    "StudentName": studentName,
    "Phone": phone,
    "AlternatePhone": alternatePhone,
    "Course": course,
    "BatchNumber": batchNumber,
    "BatchTime": batchTime,
  };
}
