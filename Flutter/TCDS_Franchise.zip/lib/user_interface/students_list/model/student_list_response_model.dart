
// To parse this JSON data, do
//
//     final studentListResponseModel = studentListResponseModelFromJson(jsonString);

import 'dart:convert';

StudentListResponseModel studentListResponseModelFromJson(String str) => StudentListResponseModel.fromJson(json.decode(str));

String studentListResponseModelToJson(StudentListResponseModel data) => json.encode(data.toJson());

class StudentListResponseModel {
  int code;
  String message;
  List<StudentList> data;

  StudentListResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StudentListResponseModel.fromJson(Map<String, dynamic> json) => StudentListResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<StudentList>.from(json["Data"].map((x) => StudentList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class StudentList {
  String studentId;
  String contactId;
  String contactName;
  String phone;
  String rollNumber;
  String course;
  String dateOfAdmission;
  String fromDate;
  String toDate;
  String? base64Image;

  StudentList({
    required this.studentId,
    required this.contactId,
    required this.contactName,
    required this.phone,
    required this.rollNumber,
    required this.course,
    required this.dateOfAdmission,
    required this.fromDate,
    required this.toDate,
    this.base64Image,
  });

  factory StudentList.fromJson(Map<String, dynamic> json) => StudentList(
    studentId: json["StudentID"],
    contactId: json["ContactID"],
    contactName: json["ContactName"],
    phone: json["Phone"],
    rollNumber: json["RollNumber"],
    course: json["Course"],
    dateOfAdmission: json["DateOfAdmission"],
    fromDate: json["FromDate"],
    toDate: json["ToDate"],
  );

  Map<String, dynamic> toJson() => {
    "StudentID": studentId,
    "ContactID": contactId,
    "ContactName": contactName,
    "Phone": phone,
    "RollNumber": rollNumber,
    "Course": course,
    "DateOfAdmission": dateOfAdmission,
    "FromDate": fromDate,
    "ToDate": toDate,
  };
}
