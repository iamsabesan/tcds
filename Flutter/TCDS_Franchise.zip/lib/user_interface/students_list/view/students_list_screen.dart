import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/students_list/controller/student_list_controller.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/bottom_sheets.dart';
import 'package:tcds/utils/helper_widgets/custom_drawer.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../utils/helper_widgets/pop_scope_handler.dart';

class StudentListScreen extends StatefulWidget {
  const StudentListScreen({super.key});

  @override
  State<StudentListScreen> createState() => _StudentListScreenState();
}

class _StudentListScreenState extends State<StudentListScreen> {
  StudentListController studentListController =
      Get.put(StudentListController());
  RegistrationController registrationController =
      Get.put(RegistrationController());

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int appliedFilterCount = 0;

  int _selectedIndex = 6;
  bool withBackArrow = false;

  @override
  void initState() {
    final args = Get.arguments;
    if (args != null) {
      withBackArrow = args["withBack"];
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getApiCall();
      // Show the bottom sheet initially when the screen loads
    });
    super.initState();
  }

  String selectedStatus = '';
  String selectedCourseId = '';
  String selectedCourseBatchId = '';

  Future<void> getApiCall() async {
    await studentListController.getStudentListByBatchWise();
    await studentListController.getCourseTypeList();
    await studentListController.getCourseListByFranchisee();
    await registrationController.getGenderTypes();
    AppBottomSheets.studentListFilter(
      getBatch: studentListController.batchListByCourseId,
      context: Get.context!,
      onFilterCountUpdated: (count) {
        setState(() {
          appliedFilterCount = count; // Update filter count dynamically
        });
      },
      courseList: studentListController.courseListByFranchisee,
    );
  }

  bool canPop = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColor.whiteColor,
      drawer: const Drawer(
        child: CustomDrawer(
          currentIndex: 6,
        ),
      ),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 2,
        shadowColor: AppColor.black3Color,
        surfaceTintColor: AppColor.whiteColor,
        scrolledUnderElevation: 2,
        titleSpacing: 0,
        toolbarHeight: 70,
        title: CustomText(
          text: 'Student List',
          fontSize: AppFontSize.size2,
        ),
        leading: withBackArrow
            ? IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.arrow_back_ios_new_outlined))
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 12.w),
            child: Badge.count(
              count: appliedFilterCount,
              child: GestureDetector(
                onTap: () async {
                  PleaseWaitLoader.openDialog();

                  // Fetch required data for the filter screen
                  // await studentListController.getStudentListByBatchWise();
                  await studentListController.getCourseListByFranchisee();

                  PleaseWaitLoader.closeDialog();

                  // Show filter bottom sheet
                  final filterData = await AppBottomSheets.studentListFilter(
                    getBatch: studentListController.batchListByCourseId,
                    context: Get.context!,
                    onFilterCountUpdated: (count) {
                      setState(() {
                        appliedFilterCount = count;
                        debugPrint(
                            "Filter count updated: $appliedFilterCount"); //// Update filter count dynamically
                      });
                    },
                    courseList: studentListController.courseListByFranchisee,
                  );

                  if (filterData != null) {
                    if (filterData == "Reset") {
                      // Reset filters and data
                      setState(() {
                        selectedStatus = '';
                        selectedCourseId = '';
                        selectedCourseBatchId = '';
                        appliedFilterCount = 0; // Reset filter count
                        debugPrint(
                            "Filters reset, count set to: $appliedFilterCount");
                      });
                      // Call API without any filters
                      // await studentListController.getStudentList(body: {
                      //
                      // });
                    } else {
                      // Apply selected filters
                      setState(() {
                        selectedStatus = filterData["Status"] ?? '';
                        selectedCourseId = filterData["CourseID"] ?? '';
                        selectedCourseBatchId =
                            filterData["CourseBatchID"] ?? '';

                        // Update filter count
                        appliedFilterCount = [
                          selectedStatus,
                          selectedCourseId,
                          selectedCourseBatchId,
                        ].where((value) => value.isNotEmpty).length;
                      });

                      // Call API with selected filters
                      await studentListController.getStudentList(body: {
                        if (selectedStatus.isNotEmpty) "Status": selectedStatus,
                        if (selectedCourseId.isNotEmpty)
                          "CourseID": selectedCourseId,
                        if (selectedCourseBatchId.isNotEmpty)
                          "CourseBatchID": selectedCourseBatchId,
                      });
                    }
                  }
                },
                child: Image.asset(
                  AssetPath.filterIcon,
                  scale: 20.0,
                  color: AppColor.darkGrey,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Obx(
        () => studentListController.studentListScreenLoader.value
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppColor.primaryColor,
                ),
              )
            : PopScopeHandler(
                child: studentListController.studentList.isEmpty
                    ? Center(
                        child: CustomText(
                          text: 'No Data',
                          fontSize: AppFontSize.size3.sp,
                          color: AppColor.primaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      )
                    : SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 10.w,
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: 1.w, horizontal: 4.w),
                              decoration: const BoxDecoration(
                                shape: BoxShape.rectangle,
                                color: AppColor.whiteColor,
                              ),
                              child: Padding(
                                padding: EdgeInsets.only(
                                    left: 15.w,
                                    right: 15.w,
                                    top: 15.w,
                                    bottom: 100),
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount:
                                      studentListController.studentList.length,
                                  itemBuilder: (context, index) {
                                    if (studentListController
                                        .studentList.isNotEmpty) {
                                      return studentListWidget(
                                        contactId: studentListController
                                            .studentList[index].contactId,
                                        base64: studentListController
                                            .studentList[index].base64Image,
                                        course: studentListController
                                            .studentList[index].course,
                                        doa: studentListController
                                            .studentList[index].dateOfAdmission,
                                        fromDate: studentListController
                                            .studentList[index].fromDate,
                                        toDate: studentListController
                                            .studentList[index].toDate,
                                        rollNumber: studentListController
                                            .studentList[index].rollNumber,
                                        name: studentListController
                                            .studentList[index].contactName,
                                        mobileNum: studentListController
                                            .studentList[index].phone,
                                        isImageLoading: studentListController
                                            .isImageLoading(
                                                studentListController
                                                    .studentList[index]
                                                    .contactId),
                                        onTap: () {
                                          _makePhoneCall(studentListController
                                              .studentList[index].phone);
                                        },
                                      );
                                    }
                                    return null;
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
      ),
      floatingActionButton: GestureDetector(
        onTap: () {
          setState(() {
            _selectedIndex = 2; // Select the Home tab
          });
          Get.to(const DashboardScreen());
        },
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Outer Circle
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: Color(0xFFCCE6FF), // Lighter blue
                shape: BoxShape.circle,
              ),
            ),
            // Inner Circle
            Container(
              width: 56,
              height: 56,
              decoration: const BoxDecoration(
                color: AppColor.primaryColor, // Darker blue
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.home,
                color: Colors.white,
                size: 28,
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }

  Widget studentListWidget({
    required String contactId,
    required String? base64,
    required String name,
    required String rollNumber,
    required String mobileNum,
    required String course,
    required String doa,
    required String fromDate,
    required String toDate,
    required bool isImageLoading,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15.0),
        border: Border.all(
          color: AppColor.greyColor,
          width: 1.0,
        ),
      ),
      margin: EdgeInsets.only(top: 15.h),
      child: Padding(
        padding: EdgeInsets.all(15.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(
                  backgroundColor: AppColor.whiteColor,
                  maxRadius: 20.w,
                  minRadius: 15.w,
                  child: Container(
                    constraints: const BoxConstraints.expand(),
                    clipBehavior: Clip.hardEdge,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        // Background default image
                        ClipOval(
                          child: Image.asset(
                            AssetPath.userIcon,
                            height: 50.w,
                            width: 50.w,
                            fit: BoxFit.cover,
                          ),
                        ),
                        // Main image or loading indicator
                        ClipOval(
                          child: isImageLoading
                              ? Container(
                                  width: 50.w,
                                  height: 50.w,
                                  decoration: const BoxDecoration(
                                    color: AppColor.greyColor,
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Center(
                                    child: SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                AppColor.primaryColor),
                                      ),
                                    ),
                                  ),
                                )
                              : base64 != null
                                  ? AnimatedOpacity(
                                      opacity: 1.0,
                                      duration:
                                          const Duration(milliseconds: 300),
                                      child: Image.memory(
                                        base64Decode(base64),
                                        height: 50.w,
                                        width: 50.w,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                Container(
                                          width: 50.w,
                                          height: 50.w,
                                          decoration: const BoxDecoration(
                                            color: AppColor.greyColor,
                                            shape: BoxShape.circle,
                                          ),
                                          child: const Center(
                                            child: Icon(
                                              Icons.person,
                                              size: 30,
                                              color: AppColor.black2Color,
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              text: name,
                              fontSize: AppFontSize.size4,
                              fontWeight: FontWeight.w500,
                              color: AppColor.primaryColor,
                            ),
                            CustomText(
                              text: rollNumber,
                              fontSize: AppFontSize.size4,
                              fontWeight: FontWeight.w400,
                              color: AppColor.black2Color,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            InkWell(
                              onTap: onTap,
                              child: Image.asset(
                                AssetPath.phoneIcon,
                                scale: 25.0,
                                color: AppColor.blueColor,
                              ),
                            ),
                            SizedBox(
                              height: 5.w,
                            ),
                            CustomText(
                              text: mobileNum,
                              fontSize: AppFontSize.size4,
                              fontWeight: FontWeight.w400,
                              color: AppColor.black2Color,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 10.w),
            const Divider(
              color: AppColor.greyColor,
              thickness: 1.0,
              height: 1.0,
            ),
            SizedBox(height: 10.w),
            CustomText(
              text: course,
              fontSize: AppFontSize.size4,
              fontWeight: FontWeight.w500,
              color: AppColor.orange,
            ),
            SizedBox(height: 5.w),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomText(
                  text: 'DOA: $doa',
                  fontSize: AppFontSize.size4,
                  fontWeight: FontWeight.w500,
                  color: AppColor.black2Color,
                ),
                CustomText(
                  text: '$fromDate to $toDate',
                  fontSize: AppFontSize.size4,
                  fontWeight: FontWeight.w500,
                  color: AppColor.black2Color,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    final String formattedNumber = formatToIndianPhone(phoneNumber);

    final Uri launchUri = Uri(
      scheme: 'tel',
      path: formattedNumber,
    );

    await launchUrl(launchUri);
  }

  String formatToIndianPhone(String number) {
    // Remove non-digit characters
    String cleaned = number.replaceAll(RegExp(r'\D'), '');

    if (cleaned.length == 10) {
      return '+91$cleaned';
    } else if (cleaned.startsWith('91') && cleaned.length == 12) {
      return '+$cleaned';
    } else if (cleaned.startsWith('+91') && cleaned.length == 13) {
      return cleaned;
    } else {
      throw const FormatException("Invalid Indian phone number");
    }
  }
}
