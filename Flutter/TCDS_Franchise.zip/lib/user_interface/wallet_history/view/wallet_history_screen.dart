/* import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/bottom_navigation.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/date_picker_textfield.dart';
import 'package:tcds/utils/helper_widgets/wallet_history_widget.dart';

class WalletHistoryScreen extends StatefulWidget {
  const WalletHistoryScreen({super.key});

  @override
  State<WalletHistoryScreen> createState() => _WalletHistoryScreenState();
}

class _WalletHistoryScreenState extends State<WalletHistoryScreen> {
  TextEditingController fromDateCtrl = TextEditingController();
  TextEditingController toDateCtrl = TextEditingController();

  int _selectedIndex = 6;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        scrolledUnderElevation: 0,
        toolbarHeight: 70,
        backgroundColor: AppColor.whiteColor,
        title: CustomText(
          text: 'Wallet History',
          fontSize: AppFontSize.size2,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
        ),
        leading: IconButton(
          icon: const Icon(Icons.menu),
          onPressed: () {
            // Handle back navigation
          },
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.symmetric(vertical: 1.w, horizontal: 4.w),
            decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: AppColor.greyColor,
            ),
          ),
          SizedBox(
            height: 20.w,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.w),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Expanded(
                  flex: 40,
                  child: DatePickerTextField(
                    controller: fromDateCtrl,
                    labelText: 'From Date',
                  ),
                ),
                const Spacer(flex: 5),
                Expanded(
                  flex: 40,
                  child: DatePickerTextField(
                    controller: toDateCtrl,
                    labelText: 'To Date',
                  ),
                ),
                const Spacer(
                  flex: 3,
                ),
                InkWell(
                  onTap: () async {
                    /* if (fromDateController.text.isNotEmpty && toDateController.text.isNotEmpty) {
                      try {
                        DateTime fDate = DateFormat("dd-MM-yyyy").parse(fromDateController.text);
                        DateTime tDate = DateFormat("dd-MM-yyyy").parse(toDateController.text);

                        if (fDate.isBefore(tDate) || fDate.difference(tDate).inDays == 0) {
                          String fromDate = DateFormat('yyyy-MM-dd').format(fDate);
                          String toDate = DateFormat('yyyy-MM-dd').format(tDate);
                          debugPrint('Passing from date $fromDate');
                          debugPrint('Passing to date $toDate');
                          PleaseWaitLoader.openDialog();
                          await rewardsPointsController.getRewardPointRedeemList(body: {
                            "FromDate": fromDate,
                            "ToDate": toDate,
                          }).then((value) {
                            PleaseWaitLoader.closeDialog();
                          });
                        } else {
                          Get.snackbar(
                            'Error Message',
                            'Selected From date is greater than To date',
                            colorText: AppColor.blackColor,
                            padding: EdgeInsets.all(15.w),
                            backgroundColor: AppColor.whiteColor,
                          );
                        }
                      } catch (e) {
                        debugPrint(e.toString());
                      }
                    } else {
                      Get.snackbar(
                        'Error Message',
                        'From date or To Date is Empty',
                        colorText: AppColor.blackColor,
                        padding: EdgeInsets.all(15.w),
                        backgroundColor: AppColor.whiteColor,
                      );
                    }*/
                  },
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 5.w),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        color: AppColor.primaryColor,
                        borderRadius: BorderRadius.circular(10.w),
                      ),
                      padding: EdgeInsets.all(8.w),
                      child: Icon(
                        Icons.search_rounded,
                        color: AppColor.whiteColor,
                        size: 25.w,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 30.w,
          ),
          Expanded(
            child: ListView.builder(
                itemCount: 4,
                itemBuilder: (BuildContext context, int index) {
                  return const WalletHistoryWidget(
                    dateAndTime: "01/01/2024 10:00 AM",
                    balance: "3000",
                    status: "Pending",
                    walletIn: "2500",
                    walletOut: "500",
                    purpose: "Wallet Topup",
                    withForwardArrow: false,
                  );
                }),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: CustomBottomNavigationBar(
        selectedIndex: _selectedIndex,
        onItemSelected: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );

  }
}
 */