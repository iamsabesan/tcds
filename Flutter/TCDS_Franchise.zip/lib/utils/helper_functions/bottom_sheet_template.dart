// Basic Template
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../constants/colors.dart';
import '../helper_widgets/custom_text.dart';

bottomSheetTemplate(
    {required BuildContext context,
    required String? headerText,
    required Widget content,
    bool withDivider = true,
    Widget? footer,
    void Function()? closeOnTap,
    void Function()? saveOnTap,
    bool withDefaultPadding = true,
    bool isDismissible = true}) {
  return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      isDismissible: isDismissible,
      enableDrag: true,
      builder: (context) {
        return SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).viewInsets.bottom),
            child: Container(
              width: double.infinity,
              clipBehavior: Clip.antiAliasWithSaveLayer,
              decoration: BoxDecoration(
                color: AppColor.whiteColor,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.elliptical(40.w, 40.w),
                  topRight: Radius.elliptical(40.w, 40.w),
                ),
              ),
              // Contents
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 5.w,
                    width: 80.w,
                    margin: EdgeInsets.symmetric(vertical: 15.w),
                    decoration: BoxDecoration(
                        color: AppColor.grey,
                        borderRadius: BorderRadius.circular(5.r)),
                  ),
                  // Title text
                  if (headerText != null)
                    CustomText(
                      text: headerText,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: AppColor.primaryColor,
                    ),
                  if (headerText != null)
                    SizedBox(
                      height: 15.w,
                    ),
                  if (withDivider)
                    const Divider(
                      color: AppColor.grey,
                    ),
                  // Contents section
                  Padding(
                    padding: withDefaultPadding
                        ? EdgeInsets.all(20.w)
                        : const EdgeInsets.all(0),
                    child: content,
                  ),
                  // Footer Section
                  footer ??
                      Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 15.w, horizontal: 10.w),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: closeOnTap,
                              child: Icon(
                                Icons.close_rounded,
                                color: AppColor.secondaryColor,
                                size: 40.w,
                              ),
                            ),
                            SizedBox(
                              width: 20.w,
                            ),
                            InkWell(
                              onTap: saveOnTap,
                              child: Icon(
                                Icons.save_as_rounded,
                                color: AppColor.primaryColor,
                                size: 40.w,
                              ),
                            ),
                          ],
                        ),
                      ),
                ],
              ),
            ),
          ),
        );
      });
}
