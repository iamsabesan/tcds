import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';

class FileDownloadHelper {
  static const _channel = MethodChannel('download_helper');

  // Function to get SDK version
  static Future<int> getAndroidSdkVersion() async {
    if (Platform.isAndroid) {
      final int sdkVersion = await _channel.invokeMethod('getSdkVersion');
      return sdkVersion;
    }
    throw Exception("Not running on Android");
  }

  /// Scoped storage download after [Android_Version >= 10]
  static Future<bool> scopedDownload(
    String fileName,
    String base64Image,
    String mimeType,
  ) async {
    try {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        status = await Permission.storage.request();
        if (!status.isGranted) {
          return false;
        }
      }
      Uint8List fileBytes = base64Decode(base64Image);
      final result = await _channel.invokeMethod('saveFileToDownloads', {
        'fileName': fileName,
        'mimeType': mimeType,
        'bytes': fileBytes,
      });
      return result ?? false;
    } on PlatformException catch (e) {
      debugPrint("Failed to save file: ${e.message}");
      return false;
    }
  }

  /// Directly accsessing download folder  [Android_Version < 10 ]
  static Future<bool> directDownload(String base64Image, String name) async {
    var status = await Permission.storage.status;
    if (!status.isGranted) {
      status = await Permission.storage.request();
      if (!status.isGranted) {
        return false;
      }
    }
    var filePath = '/storage/emulated/0/Download/$name';
    try {
      Uint8List data = base64Decode(base64Image);
      var bytes = ByteData.view(data.buffer);
      final buffer = bytes.buffer;
      await File(filePath).writeAsBytes(
          buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
      return true;
    } catch (e) {
      debugPrint("Error saving file: $e");
      return false;
    }
  }

  // used to download files from unit8list directly
  static Future<bool> downloadFromUint8List(
    String fileName,
    Uint8List uInt8List,
    String mimeType,
  ) async {
    int sdkVersion = await FileDownloadHelper.getAndroidSdkVersion();

    if (sdkVersion >= 29) {
      debugPrint("Android 10 or above detected");
      try {
        // On Android 11+ (SDK 30+), storage permission may not be granted using Permission.storage due to Scoped Storage.
        // We can Use manageExternalStorage instead.but it needs clarification from PlayStore while publishing.
        // So that we use 'MediaStore', which used to store files for 30+ sdk's without any permission.

        final result = await _channel.invokeMethod('saveFileToDownloads', {
          'fileName': fileName,
          'mimeType': mimeType,
          'bytes': uInt8List,
        });
        return result ?? false;
      } on PlatformException catch (e) {
        debugPrint("Failed to save file: ${e.message}");
        return false;
      }
    }
    //
    else {
      debugPrint("Below Android 10 detected");
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        status = await Permission.storage.request();
        if (!status.isGranted) {
          return false;
        }
      }
      var filePath = '/storage/emulated/0/Download/$fileName';
      try {
        var bytes = ByteData.view(uInt8List.buffer);
        final buffer = bytes.buffer;
        await File(filePath).writeAsBytes(buffer.asUint8List(
            uInt8List.offsetInBytes, uInt8List.lengthInBytes));
        return true;
      } catch (e) {
        debugPrint("Error saving file: $e");
        return false;
      }
    }
  }

  static void showToast(String message, Color bgColor) {
    Fluttertoast.showToast(
      msg: message,
      backgroundColor: bgColor,
      textColor: AppColor.whiteColor,
      fontSize: AppFontSize.size3.sp,
    );
  }

  //
}
