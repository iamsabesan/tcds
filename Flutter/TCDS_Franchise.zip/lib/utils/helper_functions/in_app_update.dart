import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:in_app_update/in_app_update.dart';

import '../../constants/app_string.dart';

// NOTE : This calss will handle the In App Updation logic
class InAppUpdateHandler {
  // Check if any new update found
  static Future<void> checkForUpdate() async {
    try {
      final updateInfo = await InAppUpdate.checkForUpdate();
      if (updateInfo.updateAvailability == UpdateAvailability.updateAvailable) {
        if (updateInfo.immediateUpdateAllowed) {
          await performImmediateUpdate();
        } else if (updateInfo.flexibleUpdateAllowed) {
          await performFlexibleUpdate();
        }
      } else {
        // showSnack('No updates available.');
      }
    } catch (e) {
      debugPrint("Func (checkForUpdate)=> $e");
      // showSnack('Failed to check for updates.');
    }
  }

  // Perform immediate update
  static Future<void> performImmediateUpdate() async {
    try {
      final result = await InAppUpdate.performImmediateUpdate();
      if (result == AppUpdateResult.success) {
        showSnack('Update successful!');
      } else {
        showSnack('Update failed or was canceled.');
      }
    } catch (e) {
      debugPrint("Func (performImmediateUpdate)=> $e");
      showSnack('Failed to perform immediate update.');
    }
  }

  // Perform flexible update
  static Future<void> performFlexibleUpdate() async {
    try {
      await InAppUpdate.startFlexibleUpdate();
      await InAppUpdate.completeFlexibleUpdate();
      showSnack('Flexible update completed!');
    } catch (e) {
      debugPrint("Func (performFlexibleUpdate)=> $e");
      showSnack('Failed to perform flexible update.');
    }
  }

  // Snackbar to show error messages while Updating
  static showSnack(String msg) {
    try {
      // Check if GetX navigation is ready
      if (Get.isSnackbarOpen) {
        // If snackbar is already open, use debugPrint instead
        debugPrint('InAppUpdate: $msg');
      } else {
        Get.snackbar(AppStrings.appName, msg,
            snackPosition: SnackPosition.BOTTOM);
      }
    } catch (e) {
      // Fallback to debugPrint if GetX is not ready
      debugPrint('InAppUpdate: $msg (Error: $e)');
    }
  }
}
