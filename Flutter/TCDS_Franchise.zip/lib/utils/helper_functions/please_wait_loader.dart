import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';

class PleaseWaitLoader {
  static bool _isDialogOpen = false;
  static BuildContext? _dialogContext;

  // Show Please Wait Loader dialog...
  static Future<void> openDialog() async {
    // Prevent multiple dialogs from being opened
    if (_isDialogOpen) {
      return;
    }

    // Get valid context
    BuildContext? context = Get.context ?? Get.key.currentContext;
    if (context == null) {
      debugPrint('PleaseWaitLoader: No valid context available');
      return;
    }

    _dialogContext = context;
    _isDialogOpen = true;

    try {
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => PopScope(
          canPop: false,
          child: ClipRRect(
            clipBehavior: Clip.antiAliasWithSaveLayer,
            borderRadius: BorderRadius.circular(15.r),
            child: Dialog(
              backgroundColor: AppColor.white2Color,
              child: Container(
                padding: EdgeInsets.symmetric(vertical: 30.w, horizontal: 5.w),
                child: IntrinsicWidth(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const CircularProgressIndicator(
                        color: AppColor.primaryColor,
                      ),
                      SizedBox(
                        height: 15.w,
                      ),
                      CustomText(
                        text: 'Please Wait...',
                        fontSize: AppFontSize.size2.sp,
                        fontWeight: FontWeight.w500,
                        color: AppColor.blackColor,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    } catch (e) {
      debugPrint('PleaseWaitLoader: Error opening dialog: $e');
    } finally {
      _isDialogOpen = false;
    }
  }

  // Close the dialog if it's open
  static void closeDialog() {
    try {
      if (_isDialogOpen && _dialogContext != null) {
        // Use Navigator to close the dialog instead of Get.back()
        if (Navigator.canPop(_dialogContext!)) {
          Navigator.of(_dialogContext!).pop();
        }
        _isDialogOpen = false;
        _dialogContext = null;
      }
    } catch (e) {
      debugPrint('PleaseWaitLoader: Error closing dialog: $e');
      _isDialogOpen = false;
      _dialogContext = null;
    }
  }

  // Check if dialog is currently open
  static bool get isDialogOpen => _isDialogOpen;
}
