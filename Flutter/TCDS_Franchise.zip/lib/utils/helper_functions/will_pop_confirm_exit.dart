import 'package:tcds/constants/font_sizes.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/colors.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ConfirmExit {
  static DateTime? currentBackPressTime;
// Function that will ask user to confirm exit
  static Future<bool> onPopScope() async {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      await Fluttertoast.showToast(
          msg: "Press once again to Exit",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: AppColor.primary2Color,
          textColor: AppColor.whiteColor,
          fontSize: AppFontSize.size3.sp);
      return Future.value(false);
    }
    return Future.value(true);
  }
}
