import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/font_sizes.dart';

import '../../constants/colors.dart';

// ignore: must_be_immutable
class AccountDeletionTextField extends StatefulWidget {
  final String hintText;
  final String assetPath;

  // String? errorText;
  final bool withLabelText;
  final bool? filled;
  final TextEditingController controller;
  final TextEditingController mobileCodecontroller;
  final bool obscureText;
  final bool withSuffixIcon;
  final String? Function(String?)? validator;
  final double? height;
  final bool autofocus;
  final void Function(String)? onFieldSubmitted;
  final double? assetScale;
  final TextStyle? hintStyle;
  final Color? fillColor;
  final Color? assetColor;

  const AccountDeletionTextField({
    super.key,
    required this.hintText,
    required this.assetPath,
    required this.controller,
    this.validator,
    // this.errorText,
    this.withSuffixIcon = false,
    this.obscureText = false,
    this.height,
    this.autofocus = false,
    this.onFieldSubmitted,
    this.assetScale,
    required this.mobileCodecontroller,
    this.withLabelText = false,
    this.filled,
    this.hintStyle,
    this.fillColor,
    this.assetColor,
  });

  @override
  State<AccountDeletionTextField> createState() =>
      _AccountDeletionTextFieldState();
}

class _AccountDeletionTextFieldState extends State<AccountDeletionTextField> {
  late bool obscureText;
  late FocusNode _focusNode;

  // Drop down value holder
  String? dropdownValue = '+ 91';

  // Default Length
  int phoneNumberLength = 10;
  String? errorText;

  @override
  void initState() {
    obscureText = widget.obscureText;
    _focusNode = FocusNode();
    _focusNode.addListener(_onFocusChange);
    super.initState();
  }

  @override
  void dispose() {
    _focusNode.removeListener(_onFocusChange);
    _focusNode.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Container(
      margin: EdgeInsets.only(top: 2.w, left: 2.w),
      child: TextFormField(
        focusNode: _focusNode,
        autofocus: widget.autofocus,
        textAlign: TextAlign.start,
        controller: widget.controller,
        // validator: widget.validator,
        validator: (value) {
          if (value!.isEmpty || value.length < phoneNumberLength) {
            errorText = 'Mobile Number is Required';
          } else {
            errorText = null;
          }
          return errorText;
        },
        obscureText: obscureText,
        keyboardType: TextInputType.number,
        inputFormatters: [
          LengthLimitingTextInputFormatter(phoneNumberLength),
          FilteringTextInputFormatter.digitsOnly,
        ],
        onFieldSubmitted: widget.onFieldSubmitted,
        style: TextStyle(
          color: AppColor.blackColor,
          fontWeight: FontWeight.w500,
          fontSize: 16.sp,
        ),
        decoration: InputDecoration(
          // constraints: BoxConstraints(
          //     maxHeight: widget.height ?? 40.w, minHeight: 30.w),
          hintText: widget.hintText,
          errorText: errorText,
          errorMaxLines: 3,
          errorStyle: TextStyle(
            fontSize: 12.sp,
            color: AppColor.redColor,
            fontWeight: FontWeight.w400,
          ),

          prefixIcon: Padding(
            padding: EdgeInsets.only(left: 10.w, right: 10.w),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Image.asset(
                  scale: widget.assetScale ?? 25.00,
                  widget.assetPath,
                  color: widget.assetColor ?? AppColor.primaryColor,
                ),
                SizedBox(
                  width: 10.w,
                ),
                Flexible(
                  fit: FlexFit.loose,
                  child: DropdownButton<String>(
                    value: dropdownValue,
                    padding: const EdgeInsets.all(0),
                    menuMaxHeight: screenHeight * 0.4,
                    underline: const SizedBox(),
                    dropdownColor: AppColor.whiteColor,
                    isDense: true,
                    alignment: Alignment.centerRight,
                    // iconSize: 0,
                    style: TextStyle(
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.sp,
                    ),
                    // onChanged: (String? newValue) {
                    //   setState(() {
                    //     dropdownValue = newValue ?? '+91';
                    //     widget.mobileCodecontroller.text =
                    //         dropdownValue ?? '+91';
                    //     // Change phone number length according to the phone code
                    //     for (var element in CommonController.phoneCodes) {
                    //       if (element.phoneCode == dropdownValue) {
                    //         phoneNumberLength = element.phoneNumberLength;
                    //       }
                    //     }
                    //     print(dropdownValue);
                    //     print(phoneNumberLength);
                    //   });
                    // },
                    // items: CommonController.phoneCodes
                    //     .map<DropdownMenuItem<String>>(
                    //         (PhoneCodeData value) {
                    //   return DropdownMenuItem<String>(
                    //     value: value.phoneCode,
                    //     alignment: Alignment.centerLeft,
                    //     child: Text(
                    //       value.phoneCode,
                    //       style: TextStyle(
                    //         color: AppColor.blackColor,
                    //         fontWeight: FontWeight.w500,
                    //         fontSize: 16.sp,
                    //       ),
                    //     ),
                    //   );
                    // }).toList(),
                    items: [
                      DropdownMenuItem<String>(
                        value: '+ 91',
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '+ 91',
                          style: TextStyle(
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size4,
                          ),
                        ),
                      ),
                      DropdownMenuItem<String>(
                        value: '+ 92',
                        alignment: Alignment.centerLeft,
                        child: Text(
                          '+ 92',
                          style: TextStyle(
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w500,
                            fontSize: AppFontSize.size4,
                          ),
                        ),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        dropdownValue = value ?? '+ 91';
                      });
                    },
                    icon: Icon(
                      Icons.keyboard_arrow_down_sharp,
                      size: 25.w,
                    ),
                    // icon: const SizedBox.shrink(),
                  ),
                ),
              ],
            ),
          ),

          contentPadding: EdgeInsets.only(
            left: 70.w,
            right: 10.w,
            bottom: 0.w,
            top: 10.w,
          ),
          hintStyle: widget.hintStyle ??
              TextStyle(
                color: AppColor.black2Color,
                fontSize: AppFontSize.size3.sp,
              ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: AppColor.blackColor.withValues(alpha: 0.25),
              width: 1.5,
            ),
            borderRadius: BorderRadius.circular(8.r),
          ),
          fillColor: widget.fillColor ?? AppColor.grey3,
          filled: widget.filled ?? true,
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: AppColor.primaryColor),
            borderRadius: BorderRadius.circular(8.r),
          ),
          border: OutlineInputBorder(
            borderSide: const BorderSide(
              color: AppColor.blackColor,
            ),
            borderRadius: BorderRadius.circular(8.r),
          ),
        ),
      ),
    );
  }
}
