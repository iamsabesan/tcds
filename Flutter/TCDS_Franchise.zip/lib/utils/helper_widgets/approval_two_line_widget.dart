

import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';
import 'custom_text.dart';

class ApprovalTwoLineWidget extends StatefulWidget {
  final String title;
  final String duration;
  final String term;
  final void Function()? onTap;
  const ApprovalTwoLineWidget({
    super.key,
    required this.title,
    this.onTap,
    required this.duration,
    required this.term,
  });

  @override
  State<ApprovalTwoLineWidget> createState() => _ApprovalTwoLineWidgetState();
}

class _ApprovalTwoLineWidgetState extends State<ApprovalTwoLineWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Left Column
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: widget.title,
                    fontSize:15.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColor.primaryColor,
                  ),
                  const SizedBox(height: 7.0),
                  CustomText(
                    text: widget.duration,
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColor.blackColor,
                  ),
                ],
              ),
            ),
            // Right Column
            Expanded(
              flex: 4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                   SizedBox(height: 7.sp),
                  CustomText(
                    text: widget.term,
                    fontSize: 17.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColor.secondaryColor,
                  ),
                ],
              ),
            ),


          ],
        ),


      ],
    );
  }
}
