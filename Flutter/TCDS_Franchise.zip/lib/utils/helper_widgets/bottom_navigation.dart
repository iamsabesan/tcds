import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/user_interface/achievers_award/view/achievers_award_screen.dart';
import 'package:tcds/user_interface/dashboard/view/dashboard_screen.dart';
import 'package:tcds/user_interface/exam/view/exam_indent_main_screen.dart';
import 'package:tcds/user_interface/franchise_ranking/view/franchise_ranking_screen.dart';
import 'package:tcds/user_interface/material/view/material_indent_main_screen.dart';

class CustomBottomNavigationBar extends StatefulWidget {
  final int selectedIndex;
  final Function(int) onItemSelected;

  const CustomBottomNavigationBar({
    super.key,
    required this.selectedIndex,
    required this.onItemSelected,
  });

  @override
  State<CustomBottomNavigationBar> createState() =>
      _CustomBottomNavigationBarState();
}

class _CustomBottomNavigationBarState extends State<CustomBottomNavigationBar> {
  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: AppColor.whiteColor,
      shape: const CircularNotchedRectangle(),
      notchMargin: 8.0,
      height: 100.w,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30.0),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withValues(alpha: 0.3),
              spreadRadius: 2,
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildBottomNavigationItem("assets/Award.png", 0,
                "Admission Statistics"), // -- Award --Admission Statistics
            _buildBottomNavigationItem("assets/Rank.png", 1,
                "Account Statistics"), // -- Rank -- Account Statistics
            SizedBox(width: 40.w), // Space for the floating button
            _buildBottomNavigationItem("assets/Material.png", 3,
                "Material"), // -- Material --Downloads
            _buildBottomNavigationItem(
                "assets/Exam.png", 4, "Exam"), // -- Exam --Reports
          ],
        ),
      ),
    );
  }

/*  Widget _buildBottomNavigationItem(IconData icon, int index, String label) {
    final bool isSelected = widget.selectedIndex == index;
    return GestureDetector(
      onTap: () => widget.onItemSelected(index),

      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            size: 24,
            color: isSelected ? const Color(0xFF0078FF) : Colors.grey,
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: isSelected ? const Color(0xFF0078FF) : Colors.grey,
            ),
          ),
        ],
      ),
    );
  }*/

  Widget _buildBottomNavigationItem(String imagePath, int index, String label) {
    final bool isSelected = widget.selectedIndex == index;

    return GestureDetector(
      onTap: () {
        // Call the onItemSelected callback to change the selected index in the parent widget
        widget.onItemSelected(index);

        // Perform the navigation based on the selected index
        switch (index) {
          case 0:
            // Navigate to AchieversAwardScreen
            Get.to(() => const AchieversAwardScreen());
            break;
          case 1:
            // Navigate to FranchiseeRankingScreen
            Get.to(() => const FranchiseeRankingScreen());
            break;
          case 2:
            // Navigate to FranchiseeRankingScreen
            Get.to(() => const DashboardScreen());
            break;
          case 3:
            // Navigate to MaterialIndentMainScreen
            Get.to(() => const MaterialIndentMainScreen());
            break;
          case 4:
            // Navigate to ExamIndentMainScreen
            Get.to(() => const ExamIndentMainScreen());
            break;
          default:
            break;
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            imagePath,
            height: 22.w,
            width: 22.w,
            fit: BoxFit.contain,
            color: isSelected
                ? AppColor.primaryColor
                : AppColor.navigationIconColor,
          ),
          SizedBox(
            width: 80.w,
            child: Text(
              label,
              maxLines: 2,
              overflow: TextOverflow.clip,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12.sp,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected
                    ? AppColor.primaryColor
                    : AppColor.navigationIconColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
