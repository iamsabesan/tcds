import 'dart:io';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http_parser/http_parser.dart' as media;
import 'package:dio/dio.dart' as dio;

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/user_interface/dashboard/model/admin_bank_response_model.dart';
import 'package:tcds/user_interface/dashboard/model/franchisee_bank_response_model.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/students_list/controller/student_list_controller.dart';
import 'package:tcds/user_interface/students_list/model/batch_list_by_course_id_response_model.dart';
import 'package:tcds/user_interface/students_list/model/course_list_by_franchisee_response_model.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/course_type_dropdown.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';
import 'package:tcds/utils/helper_widgets/date_picker_textfield.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';
import 'package:tcds/utils/helper_widgets/out_button.dart';
import 'package:tcds/utils/helper_widgets/single_dropdown.dart';
import 'package:tcds/utils/helper_widgets/uploading_file_widget.dart';

import '../../user_interface/registration/model/bank_details_model.dart';
import '../../user_interface/registration_status/model/franchise_request_model.dart';
import '../../user_interface/students_list/model/material_list_model.dart';
import '../helper_functions/common_dialogs.dart';
import '../helper_functions/formatters.dart';

class AppBottomSheets {
  static template({
    required BuildContext context,
    required String? headerText,
    bool showDelete = false,
    bool showClose = false,
    String? header2Text,
    int? index,
    List<BankDetails>? bankList,
    BankDetails? bank,
    required Widget content,
    bool withDivider = true,
    String? outButtonText,
    String? inButtonText,
    bool? isDismissible,
    Widget? footer,
    bool withFooter = true,
    void Function()? closeOnTap,
    void Function()? saveOnTap,
    bool withDefaultPadding = true,
  }) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        enableDrag: true,
        isDismissible: isDismissible ?? true,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Container(
                width: double.infinity,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                decoration: BoxDecoration(
                  color: AppColor.whiteColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.elliptical(40.w, 40.w),
                    topRight: Radius.elliptical(40.w, 40.w),
                  ),
                ),
                // Contents
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 5.w,
                      width: 80.w,
                      margin: EdgeInsets.symmetric(vertical: 15.w),
                      decoration: BoxDecoration(
                          color: AppColor.greyColor,
                          borderRadius: BorderRadius.circular(5.r)),
                    ),
                    // Title text

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          if (headerText != null)
                            Flexible(
                              flex: 90,
                              child: Align(
                                alignment: Alignment.center,
                                child: CustomText(
                                  text: headerText,
                                  fontSize: AppFontSize.size3.sp,
                                  fontWeight: FontWeight.w600,
                                  color: AppColor.primaryColor,
                                ),
                              ),
                            ),
                          if (showDelete)
                            Flexible(
                              flex: 10,
                              child: InkWell(
                                onTap: () {
                                  Get.back(result: {
                                    "index": index,
                                    "isDeleted": true
                                  });
                                },
                                child: Image.asset(
                                  AssetPath.deleteBin,
                                  scale: 25.0,
                                  color: AppColor.deleteRed,
                                ),
                              ),
                            ),
                          if (showClose)
                            Flexible(
                              flex: 10,
                              child: InkWell(
                                onTap: closeOnTap,
                                child: Image.asset(
                                  AssetPath.closeIcon,
                                  scale: 25.0,
                                  // color: AppColor.deleteRed,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 5.w,
                    ),
                    if (header2Text != null) ...[
                      CustomText(
                        text: header2Text,
                        fontSize: AppFontSize.size4.sp,
                        fontWeight: FontWeight.w600,
                        color: AppColor.blackColor,
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                    ],
                    if (withDivider)
                      const Divider(
                        color: AppColor.greyColor,
                      ),
                    // Contents section
                    Padding(
                      padding: withDefaultPadding
                          ? EdgeInsets.all(20.w)
                          : const EdgeInsets.all(0),
                      child: content,
                    ),
                    // Footer Section
                    if (withFooter == true) ...[
                      footer ??
                          Padding(
                            padding: EdgeInsets.symmetric(
                                vertical: 15.w, horizontal: 10.w),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 25.0),
                                    child: InkWell(
                                      child: OutButton(
                                        onTap: closeOnTap,
                                        withArrow: false,
                                        text: outButtonText ?? "Cancel",
                                        verticalPadding: 10.w,
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 25.w,
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.only(right: 25.0),
                                    child: InkWell(
                                      child: InButton(
                                        onTap: saveOnTap,
                                        withArrow: false,
                                        text: inButtonText ?? "Submit",
                                        color: AppColor.primaryColor,
                                        verticalPadding: 10.w,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                    ],
                  ],
                ),
              ),
            ),
          );
        });
  }

  static paymentModeBottomSheet({
    required RxList<AdminBankList> adminBankList,
    required RxList<FranchiseeBankList> franchiseeBankList,
    required paymentMode,
    payModeOriginal,
    required NumberFormat currencyFormat,
    required BuildContext context,
    // required Function(Map<String, dynamic>) onSubmit,
    // required Function() onCancel,
    required double remainingAmount,
    String? initialTransId,
    required String walletAmount,
    required String selectedPaymodeId,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    DashboardController dashboardController = Get.find<DashboardController>();

    TextEditingController depositToCtrl = TextEditingController();
    TextEditingController depositToTextCtrl = TextEditingController();
    TextEditingController depositFromCtrl = TextEditingController();
    TextEditingController depositFromTextCtrl = TextEditingController();
    TextEditingController amtCtrl = TextEditingController();
    // TextEditingController amtTextCtrl = TextEditingController();
    TextEditingController transDateCtrl = TextEditingController();
    TextEditingController transIdCtrl = TextEditingController();
    // TextEditingController transIdTextCtrl = TextEditingController();

    // String depositFrom = "";
    // String depositTo = "";
    // DateTime? transactionDate;

    // If an initial transaction ID is passed, set it in the controller
    if (initialTransId != null) {
      transIdCtrl.text = initialTransId;
    }

    FilePickerResult? imageHolder;
    bool processingImage = false;

    Future<FilePickerResult?> pickFile() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpeg', 'jpg'],
      );
      if (result != null) {
        PlatformFile file = result.files.single;
        String fileExtension = file.extension?.toLowerCase() ?? '';
        // check if any extention type selected
        // check if file size exceeds 2 mb
        if (!['pdf', 'png', 'jpeg', 'jpg'].contains(fileExtension)) {
          showInformationDialog(
            context: Get.context!,
            message:
                'Invalid file type. Please select a JPG, PNG, JPEG or PDF file.',
          );
          return null;
        } else if (file.size > 2 * 1024 * 1024) {
          // File size exceeds 2MB
          showInformationDialog(
              context: Get.context!,
              message: 'File size exceeds 2MB. Please choose a smaller file.');
          return null;
        } else {
          debugPrint('File picked: ${file.path}');
          return result;
        }
      } else {
        debugPrint('No file picked');
        return null;
      }
    }

    return template(
        context: context,
        headerText: 'Payment Mode : $payModeOriginal',
        header2Text:
            "Approval Payable :${currencyFormat.format(remainingAmount)}",
        isDismissible: false,
        content: StatefulBuilder(builder: (context, setState) {
          return Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (paymentMode == "cash") ...[
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    hintText: "",
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      }
                      String trimmedValue =
                          value.replaceAll(RegExp(r'^0+'), '');

                      // If the value is now empty, it's essentially zero
                      if (trimmedValue.isEmpty ||
                          (double.tryParse(value) ?? 0) == 0) {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                if (paymentMode != "cash") ...[
                  SingleSelectDropDown(
                    labelText: "Deposit from",
                    valueController: depositFromCtrl,
                    valueTextController: depositFromTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit from is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.franchiseeBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController
                              .franchiseeBankList[index].ledgerName,
                          dashboardController
                              .franchiseeBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  SingleSelectDropDown(
                    labelText: "Deposit to",
                    valueController: depositToCtrl,
                    valueTextController: depositToTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit to is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.adminBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController.adminBankList[index].ledgerName,
                          dashboardController.adminBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      }
                      String trimmedValue =
                          value.replaceAll(RegExp(r'^0+'), '');

                      // If the value is now empty, it's essentially zero
                      if (trimmedValue.isEmpty ||
                          (double.tryParse(value) ?? 0) == 0) {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Transaction ID",
                    controller: transIdCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction ID is required';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                //
                ((paymentMode.toLowerCase().toString().removeAllWhitespace ==
                                "upi" ||
                            paymentMode
                                    .toLowerCase()
                                    .toString()
                                    .removeAllWhitespace ==
                                "bankremittance") &&
                        imageHolder == null)
                    ?
                    // image upload section
                    StatefulBuilder(builder: (context, attachmentState) {
                        return processingImage
                            ? ListTile(
                                leading: Image.asset(
                                  AssetPath.fileImage,
                                  scale: 0.9,
                                ),
                                title: const Center(
                                    child: CircularProgressIndicator()),
                                subtitle: null,
                                trailing: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                        icon: Image.asset(
                                          AssetPath.deleteIconWithBG,
                                          scale: 0.8,
                                        ),
                                        onPressed: () {
                                          imageHolder = null;
                                          processingImage = false;
                                          setState(() {});
                                        }),
                                  ],
                                ),
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: "Upload Attachment",
                                    fontSize: AppFontSize.size4,
                                    color: AppColor.blackColor,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      vertical: 10.w,
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () async {
                                              imageHolder = await pickFile();
                                              if (imageHolder != null) {
                                                // show inwidget-loader while uploading image
                                                attachmentState(() {
                                                  processingImage = true;
                                                });
                                                File file = File(imageHolder!
                                                    .files.single.path!);
                                                String fileName = imageHolder!
                                                    .files.single.name;
                                                debugPrint(
                                                    'File name $fileName');
                                                String extention = file.path
                                                    .split('.')
                                                    .last
                                                    .toLowerCase();
                                                debugPrint(
                                                    'Extention $extention');

                                                // Convert the selected file as form data to send
                                                dio.FormData formData =
                                                    dio.FormData.fromMap({
                                                  "EntityName": payModeOriginal,
                                                  "DocumentFile":
                                                      // file
                                                      await dio.MultipartFile
                                                          .fromFile(
                                                    file.path,
                                                    filename: fileName,
                                                    contentType:
                                                        media.MediaType(
                                                      extention.toLowerCase() ==
                                                              'pdf'
                                                          ? 'application'
                                                          : 'image',
                                                      extention,
                                                    ),
                                                  )
                                                });

                                                debugPrint(
                                                    'Form data ${formData.boundary}');
                                                // PleaseWaitLoader.openDialog();

                                                final bool isImageUploaded =
                                                    await dashboardController
                                                        .updateAttachments(
                                                            formData: formData);
                                                // PleaseWaitLoader.closeDialog();
                                                attachmentState(() {
                                                  processingImage = false;
                                                });
                                                if (isImageUploaded) {
                                                  setState(() {});
                                                }
                                              }
                                            },
                                            child: DottedBorder(
                                              color: AppColor.greyColor,
                                              strokeWidth: 4.5,
                                              dashPattern: const [12, 12],
                                              borderType: BorderType.rRect,
                                              radius: Radius.circular(8.r),
                                              child: Padding(
                                                padding: EdgeInsets.all(10.w),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Image.asset(
                                                      AssetPath.uploadIcon,
                                                      scale: 1.0,
                                                    ),
                                                    CustomText(
                                                      text: 'Choose a file',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    SizedBox(height: 5.w),
                                                    CustomText(
                                                      text:
                                                          'JPG, JPEG, PNG, and PDF formats, up to 2MB',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      color: AppColor.greyColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                    SizedBox(height: 10.w),
                                                    Container(
                                                      padding:
                                                          EdgeInsets.all(2.w),
                                                      decoration: BoxDecoration(
                                                        shape:
                                                            BoxShape.rectangle,
                                                        border: Border.all(
                                                          color: AppColor
                                                              .primaryColor,
                                                          width: 2.w,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.r),
                                                      ),
                                                      child: Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    4.w),
                                                        child: CustomText(
                                                          text: 'Browse File',
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontSize:
                                                              AppFontSize.size5,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 20.w,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                      })
                    : ((paymentMode == "upi" ||
                                paymentMode
                                        .toLowerCase()
                                        .toString()
                                        .removeAllWhitespace ==
                                    "bankremittance") &&
                            imageHolder != null)
                        ? ListTile(
                            leading: Image.asset(
                              AssetPath.fileImage,
                              scale: 0.9,
                            ),
                            title: Text(imageHolder!.files.single.name),
                            subtitle: null,
                            trailing: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                    icon: Image.asset(
                                      AssetPath.deleteIconWithBG,
                                      scale: 0.8,
                                    ),
                                    onPressed: () {
                                      imageHolder = null;
                                      setState(() {});
                                    }),
                              ],
                            ),
                          )
                        : const SizedBox(),
              ],
            ),
          );
        }),
        saveOnTap: () async {
          if (formKey.currentState!.validate()) {
            //date parsing for transaction Date
            String sendDate = transDateCtrl.text.isEmpty
                ? DateFormat('dd-MM-yyyy').format(DateTime.now())
                : transDateCtrl.text;
            DateTime parsedDate = DateFormat('dd-MM-yyyy').parse(sendDate);
            String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

            final double enteredAmount = double.parse(amtCtrl.text);

            if (enteredAmount > remainingAmount) {
              Get.snackbar(
                'Error Message',
                'Amount cannot exceed $remainingAmount.',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            } else if ((paymentMode == "upi" ||
                    paymentMode == "bankremittance") &&
                imageHolder == null) {
              Get.snackbar(
                'Error Message',
                'Please Proceed with Attachment',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            }

            Map<String, dynamic> sendBody = {};

            PleaseWaitLoader.openDialog();
            if (paymentMode == "cash") {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": walletAmount,
                "amount": amtCtrl.text,
                "fromLedgerName": dashboardController.cashLedgerName,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.cashLedgerId,
                "toLedgerName": dashboardController.cashLedgerName,
                // "DocumentID": "f3a6e66b-b0c1-4d20-84ae-8546bb97fea7"
              };
            }
            if (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                'banktransfer') {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": walletAmount,
                "amount": amtCtrl.text,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                // Add specific document ID for bank transfer
              };
            }
            if ((paymentMode.toLowerCase().toString().removeAllWhitespace ==
                    'bankremittance') ||
                (paymentMode == 'upi')) {
              // image upload api call

              // document id {controller}
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": walletAmount,
                "amount": amtCtrl.text,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                if (dashboardController.latestUploadedDocument.isNotEmpty)
                  "DocumentID":
                      dashboardController.latestUploadedDocument[0].documentId,
              };
            }

            debugPrint(sendBody.toString());
            PleaseWaitLoader.closeDialog();

            Get.back(result: sendBody);
          }
        },
        closeOnTap: () {
          Get.back();
        },
        inButtonText: "Save");
  }

  static indentPaymentBottomSheet({
    required RxList<AdminBankList> adminBankList,
    required RxList<FranchiseeBankList> franchiseeBankList,
    required paymentMode,
    required NumberFormat currencyFormat,
    payModeOriginal,
    required BuildContext context,
    // required Function(Map<String, dynamic>) onSubmit,
    // required Function() onCancel,
    required double remainingAmount,
    String? initialTransId,
    required String selectedPaymodeId,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    DashboardController dashboardController = Get.find<DashboardController>();

    TextEditingController depositToCtrl = TextEditingController();
    TextEditingController depositToTextCtrl = TextEditingController();
    TextEditingController depositFromCtrl = TextEditingController();
    TextEditingController depositFromTextCtrl = TextEditingController();
    TextEditingController amtCtrl = TextEditingController();
    // TextEditingController amtTextCtrl = TextEditingController();
    TextEditingController transDateCtrl = TextEditingController();
    TextEditingController transIdCtrl = TextEditingController();
    // TextEditingController transIdTextCtrl = TextEditingController();

    // String depositFrom = "";
    // String depositTo = "";
    // DateTime? transactionDate;

    // If an initial transaction ID is passed, set it in the controller
    if (initialTransId != null) {
      transIdCtrl.text = initialTransId;
    }

    FilePickerResult? imageHolder;
    bool processingImage = false;

    Future<FilePickerResult?> pickFile() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpeg', 'jpg'],
      );
      if (result != null) {
        PlatformFile file = result.files.single;
        String fileExtension = file.extension?.toLowerCase() ?? '';
        // check if any extention type selected
        // check if file size exceeds 2 mb
        if (!['pdf', 'png', 'jpeg', 'jpg'].contains(fileExtension)) {
          showInformationDialog(
            context: Get.context!,
            message:
                'Invalid file type. Please select a JPG, PNG, JPEG or PDF file.',
          );
          return null;
        } else if (file.size > 2 * 1024 * 1024) {
          // File size exceeds 2MB
          showInformationDialog(
              context: Get.context!,
              message: 'File size exceeds 2MB. Please choose a smaller file.');
          return null;
        } else {
          debugPrint('File picked: ${file.path}');
          return result;
        }
      } else {
        debugPrint('No file picked');
        return null;
      }
    }

    return template(
        context: context,
        headerText: 'Payment Mode : $payModeOriginal',
        header2Text:
            "Approval Payable :  ${currencyFormat.format(remainingAmount)}",
        isDismissible: false,
        content: StatefulBuilder(builder: (context, setState) {
          return Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (paymentMode == "cash" || paymentMode == "wallet") ...[
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    keyboardType: TextInputType.number,
                    hintText: "",
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      } else if ((int.tryParse(value) ?? 0) == 0) {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  if (paymentMode == "cash")
                    DatePickerTextField(
                      controller: transDateCtrl,
                      labelText: 'Transaction Date',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Transaction Date is Required';
                        } else {
                          return null;
                        }
                      },
                    ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                if (paymentMode != "cash" && paymentMode != "wallet") ...[
                  SingleSelectDropDown(
                    labelText: "Deposit from",
                    valueController: depositFromCtrl,
                    valueTextController: depositFromTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit from is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.franchiseeBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController
                              .franchiseeBankList[index].ledgerName,
                          dashboardController
                              .franchiseeBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  SingleSelectDropDown(
                    labelText: "Deposit to",
                    valueController: depositToCtrl,
                    valueTextController: depositToTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit to is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.adminBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController.adminBankList[index].ledgerName,
                          dashboardController.adminBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      } else if ((int.tryParse(value) ?? 0) == 0) {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Transaction ID",
                    controller: transIdCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction ID is required';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                //
                ((paymentMode == "upi" ||
                            paymentMode
                                    .toLowerCase()
                                    .toString()
                                    .removeAllWhitespace ==
                                "bankremittance") &&
                        imageHolder == null)
                    ?
                    // image upload section
                    StatefulBuilder(builder: (context, attachmentState) {
                        return processingImage
                            ? ListTile(
                                leading: Image.asset(
                                  AssetPath.fileImage,
                                  scale: 0.9,
                                ),
                                title: const Center(
                                    child: CircularProgressIndicator()),
                                subtitle: null,
                                trailing: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                        icon: Image.asset(
                                          AssetPath.deleteIconWithBG,
                                          scale: 0.8,
                                        ),
                                        onPressed: () {
                                          imageHolder = null;
                                          processingImage = false;
                                          setState(() {});
                                        }),
                                  ],
                                ),
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: "Upload Attachment",
                                    fontSize: AppFontSize.size4,
                                    color: AppColor.blackColor,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      vertical: 10.w,
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () async {
                                              imageHolder = await pickFile();
                                              if (imageHolder != null) {
                                                // show inwidget-loader while uploading image
                                                attachmentState(() {
                                                  processingImage = true;
                                                });
                                                File file = File(imageHolder!
                                                    .files.single.path!);
                                                String fileName = imageHolder!
                                                    .files.single.name;
                                                debugPrint(
                                                    'File name $fileName');
                                                String extention = file.path
                                                    .split('.')
                                                    .last
                                                    .toLowerCase();
                                                debugPrint(
                                                    'Extention $extention');

                                                // Convert the selected file as form data to send
                                                dio.FormData formData =
                                                    dio.FormData.fromMap({
                                                  "EntityName": payModeOriginal,
                                                  "DocumentFile":
                                                      // file
                                                      await dio.MultipartFile
                                                          .fromFile(
                                                    file.path,
                                                    filename: fileName,
                                                    contentType:
                                                        media.MediaType(
                                                      extention.toLowerCase() ==
                                                              'pdf'
                                                          ? 'application'
                                                          : 'image',
                                                      extention,
                                                    ),
                                                  )
                                                });

                                                debugPrint(
                                                    'Form data ${formData.boundary}');

                                                final bool isImageUploaded =
                                                    await dashboardController
                                                        .updateAttachments(
                                                            formData: formData);
                                                attachmentState(() {
                                                  processingImage = false;
                                                });
                                                if (isImageUploaded) {
                                                  setState(() {});
                                                }
                                              }
                                            },
                                            child: DottedBorder(
                                              color: AppColor.greyColor,
                                              strokeWidth: 4.5,
                                              dashPattern: const [12, 12],
                                              borderType: BorderType.rRect,
                                              radius: Radius.circular(8.r),
                                              child: Padding(
                                                padding: EdgeInsets.all(10.w),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Image.asset(
                                                      AssetPath.uploadIcon,
                                                      scale: 1.0,
                                                    ),
                                                    CustomText(
                                                      text: 'Choose a file',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    SizedBox(height: 5.w),
                                                    CustomText(
                                                      text:
                                                          'JPG, JPEG, PNG, and PDF formats, up to 2MB',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      color: AppColor.greyColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                    SizedBox(height: 10.w),
                                                    Container(
                                                      padding:
                                                          EdgeInsets.all(2.w),
                                                      decoration: BoxDecoration(
                                                        shape:
                                                            BoxShape.rectangle,
                                                        border: Border.all(
                                                          color: AppColor
                                                              .primaryColor,
                                                          width: 2.w,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.r),
                                                      ),
                                                      child: Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    4.w),
                                                        child: CustomText(
                                                          text: 'Browse File',
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontSize:
                                                              AppFontSize.size5,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 20.w,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                      })
                    : ((paymentMode == "upi" ||
                                paymentMode
                                        .toLowerCase()
                                        .toString()
                                        .removeAllWhitespace ==
                                    "bankremittance") &&
                            imageHolder != null)
                        ? ListTile(
                            leading: Image.asset(
                              AssetPath.fileImage,
                              scale: 0.9,
                            ),
                            title: Text(imageHolder!.files.single.name),
                            subtitle: null,
                            trailing: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                    icon: Image.asset(
                                      AssetPath.deleteIconWithBG,
                                      scale: 0.8,
                                    ),
                                    onPressed: () {
                                      imageHolder = null;
                                      processingImage = false;
                                      setState(() {});
                                    }),
                              ],
                            ),
                          )
                        : const SizedBox(),
              ],
            ),
          );
        }),
        saveOnTap: () async {
          if (formKey.currentState!.validate()) {
            //date parsing for transaction Date
            String sendDate = transDateCtrl.text.isEmpty
                ? DateFormat('dd-MM-yyyy').format(DateTime.now())
                : transDateCtrl.text;
            DateTime parsedDate = DateFormat('dd-MM-yyyy').parse(sendDate);
            String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

            final double enteredAmount = double.parse(amtCtrl.text);

            if (enteredAmount > remainingAmount) {
              Get.snackbar(
                'Error Message',
                'Amount cannot exceed $remainingAmount.',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            } else if ((paymentMode == "upi" ||
                    paymentMode == "bankremittance") &&
                imageHolder == null) {
              Get.snackbar(
                'Error Message',
                'Please Proceed with Attachment',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            }

            Map<String, dynamic> sendBody = {};

            PleaseWaitLoader.openDialog();
            if (paymentMode == "cash") {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                "fromLedgerName": dashboardController.cashLedgerName,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.cashLedgerId,
                "toLedgerName": dashboardController.cashLedgerName,
                // "DocumentID": "f3a6e66b-b0c1-4d20-84ae-8546bb97fea7"
              };
            }

            if (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                "wallet") {
              // // get current date
              // final currentDateFormat =
              //     DateFormat('yyyy-MM-dd').format(DateTime.now());

              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                "fromLedgerName":
                    dashboardController.walletFromLegerName ?? "-",
                "fromLedgerID": dashboardController.walletFromLegerID ?? "-",
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.walletToLegerID ?? "-",
                "toLedgerName": dashboardController.walletToLegerName ?? "-",
              };
            }
            if (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                'banktransfer') {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                // Add specific document ID for bank transfer
              };
            }
            if ((paymentMode.toLowerCase().toString().removeAllWhitespace ==
                    'bankremittance') ||
                (paymentMode == 'upi')) {
              // image upload api call

              // document id {controller}
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                if (dashboardController.latestUploadedDocument.isNotEmpty)
                  "DocumentID":
                      dashboardController.latestUploadedDocument[0].documentId,
              };
            }

            debugPrint(sendBody.toString());
            PleaseWaitLoader.closeDialog();

            Get.back(result: sendBody);
          }
        },
        closeOnTap: () {
          Get.back();
        },
        inButtonText: "Save");
  }

  static feesPaymentModeBottomSheet({
    required RxList<AdminBankList> adminBankList,
    required RxList<FranchiseeBankList> franchiseeBankList,
    required paymentMode,
    required NumberFormat currencyFormat,
    payModeOriginal,
    required BuildContext context,
    // required Function(Map<String, dynamic>) onSubmit,
    // required Function() onCancel,
    required double remainingAmount,
    String? initialTransId,
    required String walletAmount,
    required String selectedPaymodeId,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    DashboardController dashboardController = Get.find<DashboardController>();

    TextEditingController depositToCtrl = TextEditingController();
    TextEditingController depositToTextCtrl = TextEditingController();
    // TextEditingController depositFromCtrl = TextEditingController();
    // TextEditingController depositFromTextCtrl = TextEditingController();
    TextEditingController amtCtrl = TextEditingController();
    // TextEditingController amtTextCtrl = TextEditingController();
    TextEditingController transDateCtrl = TextEditingController();
    TextEditingController transIdCtrl = TextEditingController();
    // TextEditingController transIdTextCtrl = TextEditingController();

    // String depositFrom = "";
    // String depositTo = "";
    // DateTime? transactionDate;

    // If an initial transaction ID is passed, set it in the controller
    if (initialTransId != null) {
      transIdCtrl.text = initialTransId;
    }

    FilePickerResult? imageHolder;
    bool processingImage = false;

    Future<FilePickerResult?> pickFile() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpeg', 'jpg'],
      );
      if (result != null) {
        PlatformFile file = result.files.single;
        String fileExtension = file.extension?.toLowerCase() ?? '';
        // check if any extention type selected
        // check if file size exceeds 2 mb
        if (!['pdf', 'png', 'jpeg', 'jpg'].contains(fileExtension)) {
          showInformationDialog(
            context: Get.context!,
            message:
                'Invalid file type. Please select a JPG, PNG, JPEG or PDF file.',
          );
          return null;
        } else if (file.size > 2 * 1024 * 1024) {
          // File size exceeds 2MB
          showInformationDialog(
              context: Get.context!,
              message: 'File size exceeds 2MB. Please choose a smaller file.');
          return null;
        } else {
          debugPrint('File picked: ${file.path}');
          return result;
        }
      } else {
        debugPrint('No file picked');
        return null;
      }
    }

    return template(
        context: context,
        headerText: 'Payment Mode : $payModeOriginal',
        header2Text:
            "Approval Payable : ${currencyFormat.format(remainingAmount)}",
        isDismissible: false,
        content: StatefulBuilder(builder: (context, setState) {
          return Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (paymentMode == "cash" || paymentMode == "wallet") ...[
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    hintText: "",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  if (paymentMode == "cash")
                    DatePickerTextField(
                      controller: transDateCtrl,
                      labelText: 'Transaction Date',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Transaction Date is Required';
                        } else {
                          return null;
                        }
                      },
                    ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                if (paymentMode != "cash" && paymentMode != "wallet") ...[
                  SingleSelectDropDown(
                    labelText: "Deposit to",
                    valueController: depositToCtrl,
                    valueTextController: depositToTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit to is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.franchiseeBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController
                              .franchiseeBankList[index].ledgerName,
                          dashboardController
                              .franchiseeBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Transaction ID",
                    controller: transIdCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction ID is required';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                //
                ((paymentMode == "upi" || paymentMode == "bankremittance") &&
                        imageHolder == null)
                    ?
                    // image upload section
                    StatefulBuilder(builder: (context, attachmentState) {
                        return processingImage
                            ? ListTile(
                                leading: Image.asset(
                                  AssetPath.fileImage,
                                  scale: 0.9,
                                ),
                                title: const Center(
                                    child: CircularProgressIndicator()),
                                subtitle: null,
                                trailing: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                        icon: Image.asset(
                                          AssetPath.deleteIconWithBG,
                                          scale: 0.8,
                                        ),
                                        onPressed: () {
                                          imageHolder = null;
                                          processingImage = false;
                                          setState(() {});
                                        }),
                                  ],
                                ),
                              )
                            : Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  CustomText(
                                    text: "Upload Attachment",
                                    fontSize: AppFontSize.size4,
                                    color: AppColor.blackColor,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      vertical: 10.w,
                                    ),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () async {
                                              imageHolder = await pickFile();
                                              if (imageHolder != null) {
                                                // show inwidget-loader while uploading image
                                                attachmentState(() {
                                                  processingImage = true;
                                                });
                                                File file = File(imageHolder!
                                                    .files.single.path!);
                                                String fileName = imageHolder!
                                                    .files.single.name;
                                                debugPrint(
                                                    'File name $fileName');
                                                String extention = file.path
                                                    .split('.')
                                                    .last
                                                    .toLowerCase();
                                                debugPrint(
                                                    'Extention $extention');

                                                // Convert the selected file as form data to send
                                                dio.FormData formData =
                                                    dio.FormData.fromMap({
                                                  "EntityName": payModeOriginal,
                                                  "DocumentFile":
                                                      // file
                                                      await dio.MultipartFile
                                                          .fromFile(
                                                    file.path,
                                                    filename: fileName,
                                                    contentType:
                                                        media.MediaType(
                                                      extention.toLowerCase() ==
                                                              'pdf'
                                                          ? 'application'
                                                          : 'image',
                                                      extention,
                                                    ),
                                                  )
                                                });

                                                debugPrint(
                                                    'Form data ${formData.boundary}');

                                                final bool isImageUploaded =
                                                    await dashboardController
                                                        .updateAttachments(
                                                            formData: formData);
                                                attachmentState(() {
                                                  processingImage = false;
                                                });

                                                if (isImageUploaded) {
                                                  setState(() {});
                                                }
                                              }
                                            },
                                            child: DottedBorder(
                                              color: AppColor.greyColor,
                                              strokeWidth: 4.5,
                                              dashPattern: const [12, 12],
                                              borderType: BorderType.rRect,
                                              radius: Radius.circular(8.r),
                                              child: Padding(
                                                padding: EdgeInsets.all(10.w),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  children: [
                                                    Image.asset(
                                                      AssetPath.uploadIcon,
                                                      scale: 1.0,
                                                    ),
                                                    CustomText(
                                                      text: 'Choose a file',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    SizedBox(height: 5.w),
                                                    CustomText(
                                                      text:
                                                          'JPG, JPEG, PNG, and PDF formats, up to 2MB',
                                                      fontSize:
                                                          AppFontSize.size4,
                                                      color: AppColor.greyColor,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                    SizedBox(height: 10.w),
                                                    Container(
                                                      padding:
                                                          EdgeInsets.all(2.w),
                                                      decoration: BoxDecoration(
                                                        shape:
                                                            BoxShape.rectangle,
                                                        border: Border.all(
                                                          color: AppColor
                                                              .primaryColor,
                                                          width: 2.w,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.r),
                                                      ),
                                                      child: Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    4.w),
                                                        child: CustomText(
                                                          text: 'Browse File',
                                                          color: AppColor
                                                              .primaryColor,
                                                          fontSize:
                                                              AppFontSize.size5,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 20.w,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              );
                      })
                    : ((paymentMode == "upi" ||
                                paymentMode == "bankremittance") &&
                            imageHolder != null)
                        ? ListTile(
                            leading: Image.asset(
                              AssetPath.fileImage,
                              scale: 0.9,
                            ),
                            title: Text(imageHolder!.files.single.name),
                            subtitle: null,
                            trailing: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                    icon: Image.asset(
                                      AssetPath.deleteIconWithBG,
                                      scale: 0.8,
                                    ),
                                    onPressed: () {
                                      imageHolder = null;
                                      processingImage = false;
                                      setState(() {});
                                    }),
                              ],
                            ),
                          )
                        : const SizedBox(),
              ],
            ),
          );
        }),
        saveOnTap: () async {
          if (formKey.currentState!.validate()) {
            //date parsing for transaction Date
            String sendDate = transDateCtrl.text.isEmpty
                ? DateFormat('dd-MM-yyyy').format(DateTime.now())
                : transDateCtrl.text;
            DateTime parsedDate = DateFormat('dd-MM-yyyy').parse(sendDate);
            String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

            final double enteredAmount = double.parse(amtCtrl.text);

            if (enteredAmount > remainingAmount) {
              Get.snackbar(
                'Error Message',
                'Amount cannot exceed $remainingAmount.',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            } else if ((paymentMode == "upi" ||
                    paymentMode == "bankremittance") &&
                imageHolder == null) {
              Get.snackbar(
                'Error Message',
                'Please Proceed with Attachment',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            }

            Map<String, dynamic> sendBody = {};

            PleaseWaitLoader.openDialog();
            if (paymentMode == "cash") {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                // "fromLedgerName": dashboardController.cashLedgerName,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.cashLedgerId,
                "toLedgerName": dashboardController.cashLedgerName,
                // "DocumentID": "f3a6e66b-b0c1-4d20-84ae-8546bb97fea7"
              };
            }

            if (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                "wallet") {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                "fromLedgerName":
                    dashboardController.walletFromLegerName ?? "-",
                "fromLedgerID": dashboardController.walletFromLegerID ?? "-",
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.walletToLegerID ?? "-",
                "toLedgerName": dashboardController.walletToLegerName ?? "-",
              };
            }

            if (paymentMode == 'banktransfer') {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                // "fromLedgerID": depositFromCtrl.text,
                // "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                // Add specific document ID for bank transfer
              };
            }
            if ((paymentMode == 'bankremittance') || (paymentMode == 'upi')) {
              // image upload api call

              // document id {controller}
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeOriginal": payModeOriginal,
                "paymodeValue": amtCtrl.text,
                "amount": amtCtrl.text,
                // "fromLedgerID": depositFromCtrl.text,
                // "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                if (dashboardController.latestUploadedDocument.isNotEmpty)
                  "DocumentID":
                      dashboardController.latestUploadedDocument[0].documentId,
              };
            }

            debugPrint(sendBody.toString());
            PleaseWaitLoader.closeDialog();

            Get.back(result: sendBody);
          }
        },
        closeOnTap: () {
          Get.back();
        },
        inButtonText: "Save");
  }
  //old
  /* static payModeHistory({
    required BuildContext context,
  }) {
    Map<String, dynamic> paymentDetails = {};

    return template(
        context: context,
        headerText: "",
        content: Column(
          children: [
            ...paymentDetails.entries.map((entry) {
              final mode = entry.key;
              final detail = entry.value;
              return ListTile(
                title: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CustomText(
                                text: "$mode:",
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w500,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                fontSize: AppFontSize.size4,
                              ),
                              if (mode == 'UPI' || mode == 'Bank Remittance') // Condition for specific modes
                                SizedBox(width: 5.w),
                              if (mode == 'UPI' || mode == 'Bank Remittance')
                                Image.asset(
                                  'assets/file_image.png', // Replace with your asset path
                                  scale: 1.5,
                                ),
                            ],
                          ),
                          CustomText(
                            text: "${detail['date']}",
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w400,
                            fontSize: AppFontSize.size5,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 40.w,
                    ),
                    Expanded(
                      flex: 4,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: "From : ${detail['from']}: ",
                            color: AppColor.black2Color,
                            fontWeight: FontWeight.w400,
                            fontSize: AppFontSize.size5,
                          ),
                          CustomText(
                            text: "To : ${detail['to']}: ",
                            color: AppColor.black2Color,
                            fontWeight: FontWeight.w400,
                            fontSize: AppFontSize.size5,
                          ),
                          CustomText(
                            text: "#${detail['id']}: ",
                            color: AppColor.black2Color,
                            fontWeight: FontWeight.w400,
                            fontSize: AppFontSize.size5,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          CustomText(
                            text: " ₹${detail['amount']}",
                            color: AppColor.blackColor,
                            fontWeight: FontWeight.w600,
                            fontSize: AppFontSize.size4,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
              );
            }),
          ],
        ));
  }*/

  static addAnotherBankDetail({
    required BuildContext context,
    int? index,
    List<BankDetails>? bankList,
    BankDetails? bank,
    // required Function() onSubmit,
    // required Function() onCancel,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();
    // List<BankDetails> bankList=[];
    RegistrationController registrationController =
        Get.find<RegistrationController>();
    BankDetails firstBankDetail = BankDetails(
        accountType: '',
        accountName: '',
        accountNumber: "",
        bank: '',
        ifsc: '',
        description: '',
        branchName: '');
    // final TextEditingController accTypeCtrl =
    //     TextEditingController(text: bank != null ? bank.accountType : "");
    // final TextEditingController accTypeTextCtrl =
    //     TextEditingController(text: bank != null ? bank.accountType : "");
    // final TextEditingController accNumCtrl = TextEditingController(
    //     text: bank != null ? bank.accountNumber.toString() : "");
    final TextEditingController bankNameCtrl =
        TextEditingController(); //text: bank !=null ?bank.bank:""
    final TextEditingController bankNameTextCtrl = TextEditingController(
        text: bank != null ? bank.bank : ""); //text: bank !=null ?bank.bank:""
    final TextEditingController ifscCtrl =
        TextEditingController(text: bank != null ? bank.ifsc : "");
    final TextEditingController branchCtrl =
        TextEditingController(text: bank != null ? bank.branchName : ""); //
    final TextEditingController accountHolderNameCtrl =
        TextEditingController(text: bank != null ? bank.accountName : "");
    final TextEditingController notesCtrl =
        TextEditingController(text: bank != null ? bank.description : "");
    final TextEditingController acntNoTextCtrl = TextEditingController(
        text: bank != null ? bank.accountNumber.toString() : "");
    String? account = bank != null
        ? bank.accountType
        : registrationController.accountList.last;

    return template(
      context: context,
      headerText: 'Add Another Bank Details',
      showDelete: index == null ? false : true,
      index: index,
      bank: bank,
      bankList: bankList,
      content: StatefulBuilder(builder: (context, setState) {
        return Form(
          key: formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 4,
                    child: SingleSelectDropDown(
                      key: UniqueKey(),
                      labelText: 'Account Type',
                      valueController: TextEditingController(text: account),
                      valueTextController: TextEditingController(text: account),
                      validator: (val) {
                        if (val != null && val.isEmpty) {
                          return 'Account Type is required';
                        } else {
                          return null;
                        }
                      },
                      data: List.generate(
                        registrationController.accountList.length,
                        (index) => SingleSelectDropDownModel(
                          registrationController.accountList[index],
                          registrationController.accountList[index],
                        ),
                      ),
                      parentOnChangeCall: (value) {
                        setState(() {
                          account = value?.value ?? account;
                        });
                      },
                    ),
                  ),
                  SizedBox(width: 15.w),
                  Expanded(
                    flex: 6,
                    child: CustomTextField(
                      labelText: "Account Number",
                      controller: acntNoTextCtrl,
                      keyboardType: TextInputType.number,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(18),
                        FilteringTextInputFormatter.digitsOnly,
                      ],
                      validator: (val) {
                        if (val != null && val.isEmpty) {
                          return 'Account Number is required';
                        } else if ((int.tryParse(val ?? '0') ?? 0) == 0) {
                          return 'Account Number cannot be zero';
                        } else {
                          return null;
                        }
                      },
                    ),
                  ),
                ],
              ),
              // Container(
              //   // decoration: BoxDecoration(
              //   //   border: Border.all(color: Colors.grey),
              //   //   borderRadius: BorderRadius.circular(8.0),
              //   // ),
              //   child: Row(
              //     children: [
              //       Expanded(
              //         flex: 4, // Adjust width for the dropdown
              //         child: SingleSelectDropDown(
              //             key: UniqueKey(),
              //             filled: false,
              //             labelText: 'Account Number',
              //             valueController: accTypeCtrl,
              //             valueTextController: accTypeTextCtrl,
              //             data: [
              //               SingleSelectDropDownModel("Savings Account", "Savings Account"),
              //               SingleSelectDropDownModel("Current Account", "Current Account"),
              //             ]),
              //       ),
              //       Expanded(
              //         flex: 6, // Adjust width for the text field
              //         child: TextField(
              //           controller: accNumCtrl, // Use Controller binding
              //           decoration: const InputDecoration(
              //             border: InputBorder.none,
              //             hintText: 'Account Number', // Customize
              //           ),
              //           keyboardType: TextInputType.number,
              //         ),
              //       ),
              //     ],
              //   ),
              // ),
              SizedBox(
                height: 40.w,
              ),
              Obx(
                () => SingleSelectDropDown(
                  key: UniqueKey(),
                  labelText: 'Bank Name',
                  valueController: bankNameCtrl,
                  valueTextController: bankNameTextCtrl,
                  validator: (val) {
                    if (val != null && val.isEmpty) {
                      return 'Bank Name is required';
                    } else {
                      return null;
                    }
                  },
                  data: List.generate(
                    registrationController.bankNameList.length,
                    (index) => SingleSelectDropDownModel(
                        registrationController.bankNameList[index].bankName,
                        registrationController.bankNameList[index].bankId
                            .toString()),
                  ),
                ),
              ),
              SizedBox(
                height: 40.w,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: CustomTextField(
                      labelText: "IFSC",
                      controller: ifscCtrl,
                      validator: (val) {
                        if (val == null || val.isEmpty) {
                          return 'IFSC Code is required';
                        }

                        // IFSC code format: 11 characters (4 alphabets + 0 + 6 alphanumeric)
                        // Pattern: First 4 characters are alphabets, 5th is 0, last 6 are alphanumeric
                        final ifscPattern = RegExp(r'^[A-Z]{4}0[A-Z0-9]{6}$');

                        if (!ifscPattern.hasMatch(val)) {
                          return 'Invalid IFSC format. ex: ABCD0123456';
                        }

                        return null;
                      },
                      inputFormatters: [
                        // Uppercase formatter
                        UpperCaseTextFormatter(),
                        LengthLimitingTextInputFormatter(11),
                      ],
                      textCapitalization: TextCapitalization.characters,
                      maxLength: 11,
                    ),
                  ),
                  SizedBox(
                    width: 15.w,
                  ),
                  Expanded(
                    flex: 2,
                    child: CustomTextField(
                      labelText: "Branch",
                      controller: branchCtrl,
                      validator: (val) {
                        if (val != null && val.isEmpty) {
                          return 'Branch is required';
                        } else {
                          return null;
                        }
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 40.w,
              ),
              CustomTextField(
                labelText: "Account Holder Name",
                controller: accountHolderNameCtrl,
                validator: (val) {
                  if (val != null && val.isEmpty) {
                    return 'Account holder name is required';
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 40.w,
              ),
              CustomTextField(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 10.w, horizontal: 10.w),
                labelText: "Notes",
                controller: notesCtrl,
                maxLines: 3,
              ),
            ],
          ),
        );
      }),
      saveOnTap: () {
        if (formKey.currentState!.validate()) {
          if (index == null) {
            firstBankDetail.accountType = account!;
            firstBankDetail.accountType = account!;
            firstBankDetail.accountNumber = acntNoTextCtrl.text;
            firstBankDetail.bank = bankNameTextCtrl.text;
            firstBankDetail.ifsc = ifscCtrl.text;
            firstBankDetail.branchName = branchCtrl.text;
            firstBankDetail.accountName = accountHolderNameCtrl.text;
            firstBankDetail.description = notesCtrl.text;
            Get.back(result: firstBankDetail);
          } else {
            firstBankDetail.accountType = account!;
            firstBankDetail.accountType = account!;
            firstBankDetail.accountNumber = acntNoTextCtrl.text;
            firstBankDetail.bank = bankNameTextCtrl.text;
            firstBankDetail.ifsc = ifscCtrl.text;
            firstBankDetail.branchName = branchCtrl.text;
            firstBankDetail.accountName = accountHolderNameCtrl.text;
            firstBankDetail.description = notesCtrl.text;
            // bankList![index].accountType = account!;
            // bankList[index].accountType = account!;
            // bankList[index].accountNumber = int.parse(acntNoTextCtrl.text);
            // bankList[index].bank = bankNameTextCtrl.text;
            // bankList[index].ifsc = ifscCtrl.text;
            // bankList[index].branchName = branchCtrl.text;
            // bankList[index].accountName = accountHolderNameCtrl.text;
            // bankList[index].description = notesCtrl.text;
            Get.back(result: {
              "index": index,
              "isDeleted": false,
              "firstBankDetail": firstBankDetail
            });
          }
          // onSubmit(); // Call onSubmit to save and navigate
        }
      },
      closeOnTap: () {
        // onCancel();
        Get.back();
      },
      inButtonText: "Save",
      outButtonText: "Cancel",
    );
  }

  //student list - filter
  static studentListFilter({
    required RxList<CourseListByFranchisee> courseList,
    required RxList<BatchListByCourseIdList> getBatch,
    required BuildContext context,
    required Function(int) onFilterCountUpdated,
  }) {
    StudentListController studentListController =
        Get.find<StudentListController>();

    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    dynamic sheetState;

    TextEditingController statusCtrl = TextEditingController();
    TextEditingController statusTextCtrl = TextEditingController();
    TextEditingController courseTypeCtrl = TextEditingController();
    TextEditingController courseTypeTextCtrl = TextEditingController();
    TextEditingController batchCtrl = TextEditingController();
    TextEditingController batchTextCtrl = TextEditingController();

    return template(
      context: context,
      headerText: 'Filter',
      content: StatefulBuilder(builder: (context, setState) {
        sheetState = setState;
        return Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                SingleSelectDropDown(
                  key: UniqueKey(),
                  labelText: "Status",
                  valueController: statusCtrl,
                  valueTextController: statusTextCtrl,
                  data: [
                    SingleSelectDropDownModel("All", "All"),
                    SingleSelectDropDownModel("Studying", "Studying"),
                    SingleSelectDropDownModel("Completed", "Completed"),
                  ],
                ),
                SizedBox(
                  height: 25.w,
                ),
                CourseDropDown(
                  dropdownValues: List.generate(
                    courseList.length,
                    (index) => CourseDropDownModel(
                      courseList[index].course.toString(),
                      courseList[index].courseType.toString(),
                      courseList[index].courseId.toString(),
                    ),
                  ),
                  controller: courseTypeTextCtrl,
                  onParentTap: () async {
                    batchCtrl.clear();
                    batchTextCtrl.clear();
                    PleaseWaitLoader.openDialog();
                    await studentListController.getBatchListByCourseId(
                        courseId: courseTypeCtrl.text);
                    PleaseWaitLoader.closeDialog();
                  },
                  valueController: courseTypeCtrl,
                  labelText: 'Course Type',
                ),
                SizedBox(
                  height: 40.w,
                ),
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: "Batch",
                    valueController: batchCtrl,
                    data: List.generate(
                      studentListController.batchListByCourseId.length,
                      (index) => SingleSelectDropDownModel(
                          studentListController
                              .batchListByCourseId[index].batchNumber,
                          studentListController
                              .batchListByCourseId[index].courseBatchId
                              .toString()),
                    ),
                    valueTextController: batchTextCtrl,
                  ),
                ),
                SizedBox(
                  height: 25.w,
                ),
              ],
            ),
          ),
        );
      }),
      saveOnTap: () async {
        // Validate that all required fields are non-empty
        if (statusCtrl.text.isEmpty ||
            courseTypeCtrl.text.isEmpty ||
            batchCtrl.text.isEmpty) {
          Fluttertoast.showToast(
              msg: "Please fill all the required fields",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.TOP,
              timeInSecForIosWeb: 1,
              backgroundColor: AppColor.redColor,
              textColor: AppColor.whiteColor,
              fontSize: AppFontSize.size3.sp);

          // Get.snackbar('Error', 'Please fill all the required fields');
          return;
        }

        int filterCount = 3; // All three fields are required, so count is 3
        onFilterCountUpdated(filterCount);

        PleaseWaitLoader.openDialog();

        // Prepare filter data for API call
        final filterData = {
          'CourseID': courseTypeCtrl.text.trim(),
          'CourseBatchID': batchCtrl.text.trim(),
          'Status': statusTextCtrl.text.trim(),
        };

        debugPrint('Filter Data: $filterData');

        // Call the API to fetch the student list
        await studentListController
            .getStudentList(body: filterData)
            .then((value) {
          PleaseWaitLoader.closeDialog();

          // Pass filter count as a result and navigate back
          Get.back(result: filterData);
        });
      },
      closeOnTap: () {
        sheetState(() {
          studentListController.batchListByCourseId.clear();
          // Clear all the text controllers
          statusCtrl.clear();
          statusTextCtrl.clear();
          courseTypeCtrl.clear();
          courseTypeTextCtrl.clear();
          batchCtrl.clear();
          batchTextCtrl.clear();

          sheetState(() {
            // Add unique keys to force rebuild
            statusCtrl = TextEditingController();
            statusTextCtrl = TextEditingController();
            courseTypeCtrl = TextEditingController();
            courseTypeTextCtrl = TextEditingController();
            batchCtrl = TextEditingController();
            batchTextCtrl = TextEditingController();
            statusTextCtrl.text = "";
            statusCtrl.text = "";
          });

          // Reset filter count
          onFilterCountUpdated(0);

          // Call the API with empty filter data to reset
          final resetFilterData = {
            "CourseID": "",
            "CourseBatchID": "",
            "Status": "",
          };

          studentListController
              .getStudentList(body: resetFilterData)
              .then((value) {
            Fluttertoast.showToast(
                msg: "Filters have been reset successfully",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.TOP,
                timeInSecForIosWeb: 1,
                backgroundColor: AppColor.primaryColor,
                textColor: AppColor.whiteColor,
                fontSize: AppFontSize.size3.sp);
            // Get.snackbar('Reset', 'Filters have been reset successfully');
          });
        });
        Get.back();
      },
      outButtonText: "Reset Filter",
      inButtonText: "Apply",
    );
  }

/*   //exam indent creation
  static addExamIndent({
    // required RxList<CourseListByFranchisee> courseList,
    // required RxList<BatchListByCourseIdList> getBatch,
    required BuildContext context,
    required Function(int) onFilterCountUpdated,
    required bool create,
    List<BatchMappingDetails>? orderDetail,
    int? index,
    double? previousAmnt,
  }) {
    StudentListController studentListController =
        Get.find<StudentListController>();

    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    final GlobalKey<StudentDropDownState> studentDropDownKey =
        GlobalKey<StudentDropDownState>();

    TextEditingController courseTypeIdCtrl = TextEditingController(
        text: index == null ? "" : orderDetail![0].courseId);
    TextEditingController courseTypeTextCtrl = TextEditingController(
        text: index == null ? "" : orderDetail![0].courseName);
    TextEditingController batchIdCtrl = TextEditingController(
        text: index == null ? "" : orderDetail![0].batchId);
    TextEditingController batchTextCtrl = TextEditingController(
        text: index == null ? "" : orderDetail![0].batchName);
    TextEditingController studentIdCtrl = TextEditingController(
        text: index == null
            ? ""
            : orderDetail![0]
                .studentId); //text:index==null?"":orderDetail!["materialID"]
    TextEditingController countCtrl = TextEditingController(
        text: index == null
            ? ""
            : orderDetail![0]
                .indentStudent
                .toString()); //text:index==null?"":orderDetail!["materialID"]
    TextEditingController studentTextCtrl = TextEditingController(
        text: index == null
            ? ""
            : "${orderDetail![0].indentStudent} Student"); //text:index==null?"":orderDetail!["materialName"]
    TextEditingController transDateCtrl = TextEditingController(
        text: index == null ? "" : orderDetail![0].examDate);
    // TextEditingController comQuantityCtrl = TextEditingController(text:index==null?"":orderDetail!["quantity"]);
    // TextEditingController comPriceCtrl = TextEditingController(text:index==null?"":orderDetail!["price"].toString());
    // String quantity = "1";
    bool visibleValue = false;
    List<BatchStudentData> batchStudentList =
        studentListController.franchiseStudentBatchDataList;
    List<BatchMappingDetails> batchMappingList = [];
    // BatchMappingDetails batchMappingDetails = BatchMappingDetails(
    //     batchMappingId: '',
    //     examFees: 0,
    //     semester: 0,
    //     examDate: '',
    //     courseName: "",
    //     indentStudent: 0,
    //     totalStudent: 0,
    //     batchId: "",
    //     batchName: "",
    //     courseId: '',
    //     studentId: '');
    double examFees = index == null
        ? studentListController.franchiseCourseDataList[0].examFees
        : orderDetail![0].singleExamFees!;
    int semester = index == null
        ? studentListController.franchiseCourseDataList[0].semester
        : orderDetail![0].semester;
    DateFormat inputFormat = DateFormat('dd-MM-yyyy');
    DateFormat outputFormat = DateFormat('MM-dd-yyyy');
    List<String> parts = [];
    List<String> selectedStudentIDs = [];
    if (index != null) {
      parts = orderDetail![0].studentId.split(',');
      for (String part in parts) {
        selectedStudentIDs.add(part);
      }
    }
    double totalAmnt = 0;
    int selectedCount = index == null ? 0 : parts.length;

    return template(
      context: context,
      headerText: 'Add Indent',
      isDismissible: false,
      showDelete: !create ? true : false,
      index: index,
      content: StatefulBuilder(builder: (context, setState) {
        return Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                SingleSelectDropDown(
                  labelText: "Course",
                  valueController: courseTypeIdCtrl,
                  valueTextController: courseTypeTextCtrl,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Course is required';
                    } else {
                      return null;
                    }
                  },
                  data: List.generate(
                    studentListController.franchiseCourseDataList.length,
                    (index) => SingleSelectDropDownModel(
                        studentListController
                            .franchiseCourseDataList[index].shortName,
                        studentListController
                            .franchiseCourseDataList[index].courseId),
                  ),
                  parentOnChangeCall: (value) async {
                    batchIdCtrl.clear();
                    batchTextCtrl.clear();
                    studentTextCtrl.clear();
                    studentIdCtrl.clear();
                    visibleValue = false;
                    batchStudentList.clear();
                    PleaseWaitLoader.openDialog();
                    await studentListController.getFranchiseCourseBatchList(
                        courseId: value?.valueID ?? "");
                    if (studentListController
                        .franchiseCourseBatchDataList.isNotEmpty) {
                      await studentListController.getStudentListByBatch(
                          batchId: studentListController
                              .franchiseCourseBatchDataList[0].courseBatchId);

                      batchStudentList =
                          studentListController.franchiseStudentBatchDataList;
                    }
                    PleaseWaitLoader.closeDialog();
                    FranchiseCourseData data = studentListController
                        .franchiseCourseDataList
                        .firstWhere(
                      (material) => material.courseId == courseTypeIdCtrl.text,
                      orElse: () => FranchiseCourseData(
                          courseId: '',
                          shortName: '',
                          course: '',
                          courseType: '',
                          semester: 0,
                          duration: '',
                          durationType: '',
                          certificatePrintName: '',
                          courseFees: 0,
                          examFees: 0,
                          admissionFees: 0,
                          totalFees: 0),
                    );
                    examFees = data.examFees;
                    semester = data.semester;
                    studentDropDownKey
                        .currentState?.widget.resetSelectedStudents
                        ?.call();
                    setState(() {});
                  },
                ),
                SizedBox(
                  height: 25.w,
                ),
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: "Batch",
                    valueController: batchIdCtrl,
                    data: List.generate(
                      studentListController.franchiseCourseBatchDataList.length,
                      (index) => SingleSelectDropDownModel(
                          studentListController
                              .franchiseCourseBatchDataList[index].batchNumber,
                          studentListController
                              .franchiseCourseBatchDataList[index]
                              .courseBatchId),
                    ),
                    parentOnChangeCall: (value) async {
                      studentTextCtrl.clear();
                      studentIdCtrl.clear();
                      visibleValue = false;
                      batchStudentList.clear;
                      PleaseWaitLoader.openDialog();
                      await studentListController.getStudentListByBatch(
                          batchId: batchIdCtrl.text);
                      batchStudentList =
                          studentListController.franchiseStudentBatchDataList;
                      PleaseWaitLoader.closeDialog();
                      studentDropDownKey
                          .currentState?.widget.resetSelectedStudents
                          ?.call();
                      // comPriceCtrl.clear();

                      // MaterialData  data =
                      // studentListController.materialDataList.firstWhere(
                      //       (material) =>
                      //   material.materialId == batchIdCtrl.text,
                      //   orElse: () => MaterialData(
                      //     materialId: "", // Just a placeholder if no match is found
                      //     materialName: "",
                      //     price: 0.0, // Return a default value for price
                      //     minimumStock: 0,
                      //     openingStock: 0,
                      //     cgst: 0.0,
                      //     sgst: 0.0,
                      //   ),
                      // );
                      // price=data.price;
                      // gstPercent=data.cgst+data.sgst;
                      //
                      //
                      // debugPrint(price.toString());
                      // comPriceCtrl.text=price.toString();
                      // if((comQuantityCtrl.text=="")) {
                      //   selectedPrice= price;
                      //   gstAmount=(price*gstPercent)/100;
                      //   total=price +gstAmount;
                      // }else{
                      //   double newPrice=double.parse(quantity)*price;
                      //   selectedPrice =newPrice;
                      //   gstAmount=(newPrice*gstPercent)/100;
                      //   total=selectedPrice +gstAmount;
                      // }
                      setState(() {});
                    },
                    valueTextController: batchTextCtrl,
                  ),
                ),
                SizedBox(
                  height: 25.w,
                ),
                StudentDropDown(
                  key: studentDropDownKey,
                  dropdownValues:
                      List.generate(batchStudentList.length, (indexDD) {
                    bool containsAny = selectedStudentIDs.any((id) {
                      bool match =
                          batchStudentList[indexDD].batchMappingId.contains(id);
                      debugPrint(
                          'Checking if ${batchStudentList[indexDD].batchMappingId} contains $id: $match');
                      return match;
                    });

                    return StudentDropDownModel(
                      batchStudentList[indexDD].contactName,
                      batchStudentList[indexDD].rollNumber,
                      batchStudentList[indexDD].batchMappingId,
                      containsAny,
                    );
                  }),
                  selectedStudentIDs: selectedStudentIDs,
                  controller: studentTextCtrl,
                  /*   onParentTap: () async {
                    // batchCtrl.clear();
                    // batchTextCtrl.clear();
                    // PleaseWaitLoader.openDialog();
                    // await studentListController.getBatchListByCourseId(courseId: courseTypeCtrl.text);
                    // PleaseWaitLoader.closeDialog();
                  }, */
                  resetSelectedStudents: () {
                    // This will clear selectedStudentIDs in the StudentDropDown widget
                    setState(() {
                      selectedStudentIDs.clear();
                      countCtrl.clear();
                      studentTextCtrl.clear();
                      studentIdCtrl.clear();
                      selectedCount = 0;
                      totalAmnt = 0;
                    });
                  },
                  selectedCount: selectedCount,
                  valueController: studentIdCtrl,
                  countController: countCtrl,
                  labelText: 'Student',
                  isVisible: visibleValue,
                  getCountText: () {
                    // Now you can access the value of countController.text here
                    debugPrint(countCtrl.text);
                    totalAmnt = double.parse(countCtrl.text) * examFees;
                    setState(() {});
                    return totalAmnt
                        .toString(); // You can do whatever you need with the count value
                  },
                ),
                SizedBox(
                  height: 25.w,
                ),
                DatePickerTextField(
                  controller: transDateCtrl,
                  labelText: 'Exam Date',
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Exam Date is Required';
                    } else {
                      return null;
                    }
                  },
                  parentOnTap: () async {},
                ),
                SizedBox(
                  height: 25.w,
                ),
              ],
            ),
          ),
        );
      }),
      saveOnTap: () async {
        if (formKey.currentState!.validate()) {
          List<String> parts = studentIdCtrl.text.split(',');
          debugPrint(parts.length.toString());
          if (index != null) {
            for (String part in parts) {
              BatchMappingDetails batchMappingDetails = BatchMappingDetails(
                  batchMappingId: part,
                  examFees: totalAmnt,
                  semester: semester,
                  examDate: outputFormat
                      .format(inputFormat.parse(transDateCtrl.text)),
                  courseName: courseTypeTextCtrl.text,
                  courseId: courseTypeIdCtrl.text,
                  batchName: batchTextCtrl.text,
                  batchId: batchIdCtrl.text,
                  totalStudent: batchStudentList.length,
                  indentStudent: parts.length,
                  index: index,
                  studentId: '',
                  singleExamFees: examFees);

              batchMappingList.add(batchMappingDetails);
            }

            var totalData = {
              "isDeleted": false,
              "batchMappingList": batchMappingList
            };
            Get.back(result: totalData);
          } else {
            for (String part in parts) {
              BatchMappingDetails batchMappingDetails = BatchMappingDetails(
                batchMappingId: part,
                examFees: totalAmnt,
                semester: semester,
                examDate:
                    outputFormat.format(inputFormat.parse(transDateCtrl.text)),
                courseName: courseTypeTextCtrl.text,
                courseId: courseTypeIdCtrl.text,
                batchName: batchTextCtrl.text,
                batchId: batchIdCtrl.text,
                totalStudent: batchStudentList.length,
                indentStudent: parts.length,
                studentId: studentIdCtrl.text,
                singleExamFees: examFees,
              );

              batchMappingList.add(batchMappingDetails);
            }
            Get.back(result: batchMappingList);
          }
          debugPrint(batchMappingList.toString());
          // var totalData= {"isDeleted": false, "batchMappingList": batchMappingList};
          //  Get.back(result: totalData);
        }
        //   // Validate that all required fields are non-empty
        //   if (materialTypeTextCtrl.text.isEmpty || materialTextCtrl.text.isEmpty || comQuantityCtrl.text.isEmpty|| comPriceCtrl.text.isEmpty) {
        //     Get.snackbar('Error', 'Please fill all the required fields');
        //     return;
        //   }
        //
        //
        //   PleaseWaitLoader.openDialog();
        //   var filterData;
        //   // Prepare filter data for API call
        //   if(index ==null) {
        //     filterData = {
        //       'materialTypeID': materialTypeIdCtrl.text,
        //       'materialType': materialTypeTextCtrl.text,
        //       "materialID": materialIdCtrl.text,
        //       'materialName': materialTextCtrl.text,
        //       'quantity': comQuantityCtrl.text,
        //       'totalPrice': total,
        //       'price': comPriceCtrl.text,
        //       'gstPercent': gstPercent,
        //       'gstAmount': gstAmount,
        //       'taxableAmount': selectedPrice
        //     };
        //   }else{
        //     filterData = {
        //       'materialTypeID': materialTypeIdCtrl.text,
        //       'materialType': materialTypeTextCtrl.text,
        //       "materialID": materialIdCtrl.text,
        //       'materialName': materialTextCtrl.text,
        //       'quantity': comQuantityCtrl.text,
        //       'totalPrice': total,
        //       'price': comPriceCtrl.text,
        //       'gstPercent': gstPercent,
        //       'gstAmount': gstAmount,
        //       'taxableAmount': selectedPrice,
        //       'index':index
        //     };
        //   }
        //   debugPrint('Filter Data: $filterData');
        //
        //   // Call the API to fetch the student list
        //
        //   await PleaseWaitLoader.closeDialog();
        //
        //   // Pass filter count as a result and navigate back
        //   Get.back(result: filterData);
      },
      closeOnTap: () {
        courseTypeIdCtrl.clear();
        courseTypeTextCtrl.clear();
        // sheetState(() {
        //   // Clear all the text controllers
        //   statusCtrl.clear();
        //   statusTextCtrl.clear();
        //   courseTypeCtrl.clear();
        //   courseTypeTextCtrl.clear();
        //   batchCtrl.clear();
        //   batchTextCtrl.clear();
        //
        //   sheetState(() {
        //     // Add unique keys to force rebuild
        //     statusCtrl = TextEditingController();
        //     statusTextCtrl = TextEditingController();
        //     courseTypeCtrl = TextEditingController();
        //     courseTypeTextCtrl = TextEditingController();
        //     batchCtrl = TextEditingController();
        //     batchTextCtrl = TextEditingController();
        //     statusTextCtrl.text = "";
        //     statusCtrl.text = "";
        //   });
        //
        //   // Reset filter count
        //   onFilterCountUpdated(0);
        //
        //   // Call the API with empty filter data to reset
        //   final resetFilterData = {
        //     "CourseID": "",
        //     "CourseBatchID": "",
        //     "Status": "",
        //   };
        //
        //   studentListController.getStudentList(body: resetFilterData).then((value) {
        //     Get.snackbar('Reset', 'Filters have been reset successfully');
        //   });
        // });
        Get.back();
      },
      outButtonText: "Cancel",
      inButtonText: "Apply",
    );
  }
  */
  //indent creation
  static addIndent({
    // required RxList<CourseListByFranchisee> courseList,
    // required RxList<BatchListByCourseIdList> getBatch,
    required BuildContext context,
    required Function(int) onFilterCountUpdated,
    required bool create,
    Map<String, dynamic>? orderDetail,
    int? index,
    double? previousAmnt,
  }) {
    StudentListController studentListController =
        Get.find<StudentListController>();

    NumberFormat currencyFormat =
        NumberFormat.currency(locale: 'hi_IN', symbol: '₹', decimalDigits: 2);

    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    TextEditingController materialTypeIdCtrl = TextEditingController(
        text: index == null ? "" : orderDetail!["materialTypeID"]);
    TextEditingController materialTypeTextCtrl = TextEditingController(
        text: index == null ? "" : orderDetail!["materialType"]);
    TextEditingController materialIdCtrl = TextEditingController(
        text: index == null ? "" : orderDetail!["materialID"]);
    TextEditingController materialTextCtrl = TextEditingController(
        text: index == null ? "" : orderDetail!["materialName"]);
    TextEditingController comQuantityCtrl = TextEditingController(
        text: index == null ? "1" : orderDetail!["quantity"]);
    TextEditingController comPriceCtrl = TextEditingController(
        // text: index == null ? '' : orderDetail!["price"].toString()
        );
    TextEditingController currentStock = TextEditingController(
        // text: index == null ? "" : orderDetail!["minStock"].toString()
        );
    String quantity = "1";

    double price = studentListController.materialDataList[0].price;

    // materialTypeTextCtrl.clear();
    // materialTypeIdCtrl.clear();
    // materialIdCtrl.clear();
    // materialTextCtrl.clear();
    // comQuantityCtrl.clear();
    comPriceCtrl.text = index == null
        ? studentListController.materialDataList[0].price.toStringAsFixed(2)
        : (double.tryParse(orderDetail!["price"]) ?? 0).toStringAsFixed(2);
    currentStock.text = index == null
        ? studentListController.materialDataList[0].currentStock.toString()
        : orderDetail!["currentStock"].toString();
    double selectedPrice = index == null
        ? studentListController.materialDataList[0].price
        : orderDetail!["taxableAmount"];
    double gstPercent = index == null
        ? (studentListController.materialDataList[0].sgst +
            studentListController.materialDataList[0].cgst)
        : orderDetail!["gstPercent"];
    double gstAmount = index == null
        ? ((selectedPrice * gstPercent) / 100)
        : orderDetail!["gstAmount"];
    double total = index == null
        ? (selectedPrice + gstAmount)
        : orderDetail!["totalPrice"];
    return template(
      context: context,
      headerText: 'Filter',
      isDismissible: false,
      showDelete: !create ? true : false,
      index: index,
      content: StatefulBuilder(builder: (context, setState) {
        return Form(
          key: formKey,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                SingleSelectDropDown(
                  labelText: "Material Type",
                  valueController: materialTypeIdCtrl,
                  valueTextController: materialTypeTextCtrl,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Material Type is required';
                    } else {
                      return null;
                    }
                  },
                  data: List.generate(
                    studentListController.materialTypeDataList.length,
                    (index) => SingleSelectDropDownModel(
                        studentListController
                            .materialTypeDataList[index].materialType,
                        studentListController
                            .materialTypeDataList[index].materialTypeId),
                  ),
                  parentOnChangeCall: (value) async {
                    materialIdCtrl.clear();
                    materialTextCtrl.clear();
                    currentStock.clear();
                    comPriceCtrl.clear();
                    PleaseWaitLoader.openDialog();
                    await studentListController.getMaterialList(
                        materialTypeId: materialTypeIdCtrl.text);
                    PleaseWaitLoader.closeDialog();

                    // Reset all calculation variables for the new material type
                    price = studentListController.materialDataList[0].price;
                    currentStock.text = studentListController
                        .materialDataList[0].currentStock
                        .toString();
                    comQuantityCtrl.text = "1";
                    quantity =
                        "1"; // Update quantity variable to match controller

                    // Reset GST and total calculations
                    gstPercent =
                        studentListController.materialDataList[0].cgst +
                            studentListController.materialDataList[0].sgst;
                    selectedPrice = price;
                    gstAmount = (price * gstPercent) / 100;
                    total = selectedPrice + gstAmount;
                    comPriceCtrl.text = price.toStringAsFixed(2);

                    setState(() {});
                  },
                ),
                SizedBox(
                  height: 25.w,
                ),
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: "Material Name",
                    valueController: materialIdCtrl,
                    data: List.generate(
                      studentListController.materialDataList.length,
                      (index) => SingleSelectDropDownModel(
                          studentListController
                              .materialDataList[index].materialName,
                          studentListController
                              .materialDataList[index].materialId),
                    ),
                    parentOnChangeCall: (value) async {
                      comPriceCtrl.clear();
                      currentStock.clear();

                      MaterialData data =
                          studentListController.materialDataList.firstWhere(
                        (material) =>
                            material.materialId == materialIdCtrl.text,
                        orElse: () => MaterialData(
                          currentStock: 0,
                          materialId:
                              "", // Just a placeholder if no match is found
                          materialName: "",
                          price: 0.0, // Return a default value for price
                          minimumStock: 0,
                          openingStock: 0,
                          cgst: 0.0,
                          sgst: 0.0,
                        ),
                      );
                      price = data.price;
                      currentStock.text = data.currentStock.toString();
                      gstPercent = data.cgst + data.sgst;

                      debugPrint(price.toString());
                      comPriceCtrl.text = price.toStringAsFixed(2);
                      comQuantityCtrl.text = "1";
                      quantity =
                          "1"; // Update quantity variable to match controller
                      if ((comQuantityCtrl.text == "")) {
                        selectedPrice = price;
                        gstAmount = (price * gstPercent) / 100;
                        total = price + gstAmount;
                      } else {
                        double newPrice = double.parse(quantity) * price;
                        selectedPrice = newPrice;
                        gstAmount = (newPrice * gstPercent) / 100;
                        total = selectedPrice + gstAmount;
                      }
                      setState(() {});
                    },
                    valueTextController: materialTextCtrl,
                  ),
                ),
                SizedBox(
                  height: 25.w,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomTextField(
                          labelText: "In Stock",
                          enabled: false,
                          controller: currentStock,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          validator: (val) {
                            if (val != null && val.isEmpty) {
                              return 'Required';
                            } else {
                              return null;
                            }
                          }),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Expanded(
                      child: CustomTextField(
                        labelText: "Quantity",
                        controller: comQuantityCtrl,
                        inputFormatters: [
                          LengthLimitingTextInputFormatter(5),
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Required';
                          } else if ((int.tryParse(val!) ?? 0) == 0) {
                            return 'Qty cannot be zero';
                            // entered QTY cannot be greater that min stock
                          } else if ((int.tryParse(val) ?? 0) >
                              (int.tryParse(currentStock.text.isEmpty
                                      ? "0"
                                      : currentStock.text) ??
                                  0)) {
                            return 'Exceeded in Stock limit';
                          } else {
                            return null;
                          }
                        },
                        onChanged: (String? newValue) {
                          setState(() {
                            quantity = newValue == "" ? "1" : newValue ?? '1';
                            double nos = double.parse(quantity);
                            selectedPrice = price * nos;
                            gstAmount = (selectedPrice * gstPercent) / 100;
                            total = selectedPrice + gstAmount;
                          });

                          debugPrint("Filter count updated: $selectedPrice");
                        },
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Expanded(
                      child: CustomTextField(
                        labelText: "Price",
                        controller: comPriceCtrl,
                        enabled: false,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Required';
                          } else {
                            return null;
                          }
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 25.w,
                ),
                Card(
                  color: AppColor.containerGrey,
                  margin: EdgeInsets.all(5.w),
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 20.w, vertical: 10.w),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  text: "Taxable Amount",
                                  color: AppColor.textHeaderClr,
                                  fontSize: AppFontSize.size4,
                                  fontWeight: FontWeight.w500,
                                ),
                                CustomText(
                                  // text: "₹${payableAmount}",
                                  text: currencyFormat.format(selectedPrice),
                                  color: AppColor.subTitleColor,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10.w,
                            ),
                            /*  Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  text: "GST(%)",
                                  color: AppColor.textHeaderClr,
                                  fontSize: AppFontSize.size4,
                                  fontWeight: FontWeight.w500,
                                ),
                                CustomText(
                                  // text: "₹${payableAmount}",
                                  text: "$gstPercent %",
                                  color: AppColor.subTitleColor,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 10.w,
                            ), */
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  text: "GST($gstPercent %)",
                                  color: AppColor.textHeaderClr,
                                  fontSize: AppFontSize.size4,
                                  fontWeight: FontWeight.w500,
                                ),
                                CustomText(
                                  // text: "₹${payableAmount}",
                                  text: currencyFormat.format(gstAmount),
                                  color: AppColor.subTitleColor,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const Divider(),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: 20.w, vertical: 10.w),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomText(
                              text: "Total",
                              color: AppColor.textHeaderClr,
                              fontSize: AppFontSize.size4,
                              fontWeight: FontWeight.w500,
                            ),
                            CustomText(
                              // text: "₹${payableAmount}",
                              text: currencyFormat.format(total),
                              color: AppColor.secondaryColor,
                              fontSize: AppFontSize.size2,
                              fontWeight: FontWeight.w500,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }),
      saveOnTap: () async {
        // Validate that all required fields are non-empty
        if (materialTypeTextCtrl.text.isEmpty ||
            materialTextCtrl.text.isEmpty ||
            comQuantityCtrl.text.isEmpty ||
            comPriceCtrl.text.isEmpty) {
          Get.snackbar('Error', 'Please fill all the required fields');
          return;
        }

        if (formKey.currentState!.validate()) {
          PleaseWaitLoader.openDialog();
          Map<String, Object> filterData;
          // Prepare filter data for API call
          if (index == null) {
            filterData = {
              'materialTypeID': materialTypeIdCtrl.text,
              'materialType': materialTypeTextCtrl.text,
              "materialID": materialIdCtrl.text,
              'materialName': materialTextCtrl.text,
              'quantity': comQuantityCtrl.text,
              'totalPrice': total,
              'price': comPriceCtrl.text,
              'gstPercent': gstPercent,
              'gstAmount': gstAmount,
              'taxableAmount': selectedPrice,
              'currentStock': currentStock.text,
            };
          } else {
            filterData = {
              'materialTypeID': materialTypeIdCtrl.text,
              'materialType': materialTypeTextCtrl.text,
              "materialID": materialIdCtrl.text,
              'materialName': materialTextCtrl.text,
              'quantity': comQuantityCtrl.text,
              'totalPrice': total,
              'price': comPriceCtrl.text,
              'gstPercent': gstPercent,
              'gstAmount': gstAmount,
              'taxableAmount': selectedPrice,
              'currentStock': currentStock.text,
              'index': index
            };
          }
          debugPrint('Filter Data: $filterData');

          // Call the API to fetch the student list
          PleaseWaitLoader.closeDialog();

          // Pass filter count as a result and navigate back
          Get.back(result: filterData);
        } else {
          Get.snackbar('Error', 'Please fill all the required fields');
        }
      },
      closeOnTap: () {
        /*  sheetState(() {
          // Clear all the text controllers
          statusCtrl.clear();
          statusTextCtrl.clear();
          courseTypeCtrl.clear();
          courseTypeTextCtrl.clear();
          batchCtrl.clear();
          batchTextCtrl.clear();
        
          sheetState(() {
            // Add unique keys to force rebuild
            statusCtrl = TextEditingController();
            statusTextCtrl = TextEditingController();
            courseTypeCtrl = TextEditingController();
            courseTypeTextCtrl = TextEditingController();
            batchCtrl = TextEditingController();
            batchTextCtrl = TextEditingController();
            statusTextCtrl.text = "";
            statusCtrl.text = "";
          });
        
          // Reset filter count
          onFilterCountUpdated(0);
        
          // Call the API with empty filter data to reset
          final resetFilterData = {
            "CourseID": "",
            "CourseBatchID": "",
            "Status": "",
          };
        
          studentListController.getStudentList(body: resetFilterData).then((value) {
            Get.snackbar('Reset', 'Filters have been reset successfully');
          });
        }); */
        Get.back();
      },
      outButtonText: "Cancel",
      inButtonText: "Apply",
    );
  }

  static registrationPaymentModeBottomSheet({
    required RxList<AdminBankList> adminBankList,
    required RxList<FranchiseeBankList> franchiseeBankList,
    required paymentMode,
    payModeOriginal,
    required BuildContext context,
    // required Function(Map<String, dynamic>) onSubmit,
    // required Function() onCancel,
    required double remainingAmount,
    String? initialTransId,
    required String walletAmount,
    required String selectedPaymodeId,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    DashboardController dashboardController = Get.find<DashboardController>();

    TextEditingController depositToCtrl = TextEditingController();
    TextEditingController depositToTextCtrl = TextEditingController();
    TextEditingController depositFromCtrl = TextEditingController();
    TextEditingController depositFromTextCtrl = TextEditingController();
    TextEditingController amtCtrl = TextEditingController();
    TextEditingController transDateCtrl = TextEditingController();
    TextEditingController transIdCtrl = TextEditingController();

    // If an initial transaction ID is passed, set it in the controller
    if (initialTransId != null) {
      transIdCtrl.text = initialTransId;
    }

    FilePickerResult? imageHolder;

    Future<FilePickerResult?> pickFile() async {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'png', 'jpeg', 'jpg'],
      );
      if (result != null) {
        PlatformFile file = result.files.single;
        String fileExtension = file.extension?.toLowerCase() ?? '';
        // check if any extention type selected
        // check if file size exceeds 2 mb
        if (!['pdf', 'png', 'jpeg', 'jpg'].contains(fileExtension)) {
          showInformationDialog(
            context: Get.context!,
            message:
                'Invalid file type. Please select a JPG, PNG, JPEG or PDF file.',
          );
          return null;
        } else if (file.size > 2 * 1024 * 1024) {
          // File size exceeds 2MB
          showInformationDialog(
              context: Get.context!,
              message: 'File size exceeds 2MB. Please choose a smaller file.');
          return null;
        } else {
          debugPrint('File picked: ${file.path}');
          return result;
        }
      } else {
        debugPrint('No file picked');
        return null;
      }
    }

    return template(
        context: context,
        headerText: 'Payment Mode : $paymentMode',
        header2Text: "Approval Payable : ₹ $remainingAmount",
        isDismissible: false,
        content: StatefulBuilder(builder: (context, setState) {
          return Form(
            key: formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (paymentMode.toLowerCase() == "cash") ...[
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    hintText: "",
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      }
                      String trimmedValue =
                          value.replaceAll(RegExp(r'^0+'), '');

                      // If the value is now empty, it's essentially zero
                      if (trimmedValue.isEmpty ||
                          value == "0" ||
                          value == "0.0" ||
                          value == "0.00") {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                if (paymentMode.toLowerCase() != "cash") ...[
                  SingleSelectDropDown(
                    labelText: "Deposit from",
                    valueController: depositFromCtrl,
                    valueTextController: depositFromTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit from is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.franchiseBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController.franchiseBankList[index].bank,
                          dashboardController
                              .franchiseBankList[index].accountId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  SingleSelectDropDown(
                    labelText: "Deposit to",
                    valueController: depositToCtrl,
                    valueTextController: depositToTextCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Deposit to is required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      dashboardController.adminBankList.length,
                      (index) => SingleSelectDropDownModel(
                          dashboardController.adminBankList[index].ledgerName,
                          dashboardController.adminBankList[index].ledgerId),
                    ),
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Enter Amount",
                    controller: amtCtrl,
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Amount is required';
                      }
                      String trimmedValue =
                          value.replaceAll(RegExp(r'^0+'), '');

                      // If the value is now empty, it's essentially zero
                      if (trimmedValue.isEmpty ||
                          value == "0" ||
                          value == "0.0" ||
                          value == "0.00") {
                        return 'Amount cannot be zero';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  CustomTextField(
                    labelText: "Transaction ID",
                    controller: transIdCtrl,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction ID is required';
                      } else {
                        return null;
                      }
                    },
                    hintText: "",
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                  DatePickerTextField(
                    controller: transDateCtrl,
                    labelText: 'Transaction Date',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Transaction Date is Required';
                      } else {
                        return null;
                      }
                    },
                  ),
                  SizedBox(
                    height: 25.w,
                  ),
                ],
                //
                ((paymentMode.toLowerCase() == "upi" ||
                            paymentMode
                                    .toLowerCase()
                                    .toString()
                                    .removeAllWhitespace ==
                                "bankremittance") &&
                        imageHolder == null)
                    ?
                    // image upload section
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: "Upload Attachment",
                            fontSize: AppFontSize.size4,
                            color: AppColor.blackColor,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                              vertical: 10.w,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    onTap: () async {
                                      imageHolder = await pickFile();
                                      if (imageHolder != null) {
                                        File file = File(
                                            imageHolder!.files.single.path!);
                                        String fileName =
                                            imageHolder!.files.single.name;
                                        debugPrint('File name $fileName');
                                        String extention = file.path
                                            .split('.')
                                            .last
                                            .toLowerCase();
                                        debugPrint('Extention $extention');

                                        // Convert the selected file as form data to send
                                        dio.FormData formData =
                                            dio.FormData.fromMap({
                                          "EntityName": paymentMode,
                                          "DocumentFile":
                                              // file
                                              await dio.MultipartFile.fromFile(
                                            file.path,
                                            filename: fileName,
                                            contentType: media.MediaType(
                                              extention.toLowerCase() == 'pdf'
                                                  ? 'application'
                                                  : 'image',
                                              extention,
                                            ),
                                          )
                                        });

                                        debugPrint(
                                            'Form data ${formData.boundary}');
                                        PleaseWaitLoader.openDialog();

                                        final bool isImageUploaded =
                                            await dashboardController
                                                .updateAttachments(
                                                    formData: formData);
                                        PleaseWaitLoader.closeDialog();
                                        if (isImageUploaded) {
                                          setState(() {});
                                        }
                                      }
                                    },
                                    child: DottedBorder(
                                      color: AppColor.greyColor,
                                      strokeWidth: 4.5,
                                      dashPattern: const [12, 12],
                                      borderType: BorderType.rRect,
                                      radius: Radius.circular(8.r),
                                      child: Padding(
                                        padding: EdgeInsets.all(10.w),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              AssetPath.uploadIcon,
                                              scale: 1.0,
                                            ),
                                            CustomText(
                                              text: 'Choose a file',
                                              fontSize: AppFontSize.size4,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            SizedBox(height: 5.w),
                                            CustomText(
                                              text:
                                                  'JPG, JPEG, PNG, and PDF formats, up to 2MB',
                                              fontSize: AppFontSize.size4,
                                              color: AppColor.greyColor,
                                              fontWeight: FontWeight.bold,
                                            ),
                                            SizedBox(height: 10.w),
                                            Container(
                                              padding: EdgeInsets.all(2.w),
                                              decoration: BoxDecoration(
                                                shape: BoxShape.rectangle,
                                                border: Border.all(
                                                  color: AppColor.primaryColor,
                                                  width: 2.w,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(8.r),
                                              ),
                                              child: Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 4.w),
                                                child: CustomText(
                                                  text: 'Browse File',
                                                  color: AppColor.primaryColor,
                                                  fontSize: AppFontSize.size5,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20.w,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    : ((paymentMode.toLowerCase() == "upi" ||
                                paymentMode
                                        .toLowerCase()
                                        .toString()
                                        .removeAllWhitespace ==
                                    "bankremittance") &&
                            imageHolder != null)
                        ? ListTile(
                            leading: Image.asset(
                              AssetPath.fileImage,
                              scale: 0.9,
                            ),
                            title: Text(imageHolder!.files.single.name),
                            subtitle: null,
                            trailing: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                    icon: Image.asset(
                                      AssetPath.deleteIconWithBG,
                                      scale: 0.8,
                                    ),
                                    onPressed: () {
                                      imageHolder = null;
                                      setState(() {});
                                    }),
                              ],
                            ),
                          )
                        : const SizedBox(),
              ],
            ),
          );
        }),
        saveOnTap: () async {
          if (formKey.currentState!.validate()) {
            //date parsing for transaction Date
            DateTime parsedDate =
                DateFormat('dd-MM-yyyy').parse(transDateCtrl.text);
            String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);

            final double enteredAmount = double.parse(amtCtrl.text);

            if (enteredAmount > remainingAmount) {
              Get.snackbar(
                'Error Message',
                'Amount cannot exceed $remainingAmount.',
                colorText: AppColor.blackColor,
                padding: EdgeInsets.all(15.w),
                backgroundColor: AppColor.whiteColor,
              );
              return;
            }

            Map<String, dynamic> sendBody = {};

            PleaseWaitLoader.openDialog();
            if (paymentMode.toLowerCase() == "cash") {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeValue": amtCtrl.text,
                "amount": walletAmount,
                "fromLedgerName": dashboardController.cashLedgerName,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": dashboardController.cashLedgerId,
                "toLedgerName": dashboardController.cashLedgerName,
                // "DocumentID": "f3a6e66b-b0c1-4d20-84ae-8546bb97fea7"
              };
            }
            if (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                'banktransfer') {
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeValue": amtCtrl.text,
                "amount": walletAmount,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                // Add specific document ID for bank transfer
              };
            }
            if ((paymentMode.toLowerCase().toString().removeAllWhitespace ==
                    'bankremittance') ||
                (paymentMode.toLowerCase().toString().removeAllWhitespace ==
                    'upi')) {
              // image upload api call

              // document id {controller}
              sendBody = {
                "paymentModeID": selectedPaymodeId,
                "paymodeType": paymentMode,
                "paymodeValue": amtCtrl.text,
                "amount": walletAmount,
                "fromLedgerID": depositFromCtrl.text,
                "fromLedgerName": depositFromTextCtrl.text,
                "transactionNo": transIdCtrl.text,
                "transactionDate": formattedDate,
                "roundOff": 0,
                "bankCommision": 0,
                "toLedgerID": depositToCtrl.text,
                "toLedgerName": depositToTextCtrl.text,
                if (dashboardController.latestUploadedDocument.isNotEmpty)
                  "DocumentID":
                      dashboardController.latestUploadedDocument[0].documentId,
              };
            }

            debugPrint(sendBody.toString());
            PleaseWaitLoader.closeDialog();

            Get.back(result: sendBody);
          }
        },
        closeOnTap: () {
          Get.back();
        },
        inButtonText: "Save");
  }

  static paymentDetailBottomSheet({
    required DataPayment paymentDetails,
    required BuildContext context,
  }) {
    // Single form key to validate all fields together
    GlobalKey<FormState> formKey = GlobalKey<FormState>();

    return template(
        context: context,
        headerText: 'Payment  ',
        showClose: true,
        isDismissible: false,
        withFooter: false,
        content: StatefulBuilder(builder: (context, setState) {
          return Form(
            key: formKey,
            child: Container(
              color: AppColor.containerGrey,
              height: 200.w,
              child: ListView.builder(
                itemCount: paymentDetails.payments.length + 1,
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                itemBuilder: (context, index) {
                  // final mode = paymentDetails[index].payMode;
                  // final detail = paymentDetails[index];
                  // DateTime parsedDate = DateFormat('yyyy-MM-dd').parse(paymentDetails[index].transactionDate);
                  return paymentDetails.payments.length == index
                      ? Column(
                          children: [
                            const Divider(
                              color: AppColor.greyColor,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                CustomText(
                                  text: "Amount Paid",
                                  color: AppColor.primaryColor,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                                CustomText(
                                  text: "₹ ${paymentDetails.amount}",
                                  color: AppColor.green,
                                  fontSize: AppFontSize.size3,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                          ],
                        )
                      : ListTile(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                flex: 4,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Flexible(
                                          child: CustomText(
                                            text:
                                                "${paymentDetails.payments[index].payMode}:",
                                            color: AppColor.blackColor,
                                            fontWeight: FontWeight.w500,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            fontSize: AppFontSize.size4,
                                          ),
                                        ),
                                        if (paymentDetails
                                                    .payments[index].payMode ==
                                                'UPI' ||
                                            paymentDetails
                                                    .payments[index].payMode ==
                                                'Bank Remittance') // Condition for specific modes
                                          SizedBox(width: 5.w),
                                        if (paymentDetails
                                                    .payments[index].payMode ==
                                                'UPI' ||
                                            paymentDetails
                                                    .payments[index].payMode ==
                                                'Bank Remittance')
                                          Image.asset(
                                            AssetPath.fileSearch,
                                            height: 20.w,
                                            width: 20.w,
                                          ),
                                      ],
                                    ),
                                    CustomText(
                                      text: paymentDetails
                                          .payments[index].transactionDate,
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w400,
                                      fontSize: AppFontSize.size5,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 5.w,
                              ),
                              Expanded(
                                flex: 4,
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    CustomText(
                                      text: paymentDetails
                                          .payments[index].summary,
                                      color: AppColor.black2Color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: AppFontSize.size5.sp,
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                flex: 2,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    CustomText(
                                      text:
                                          " ₹${paymentDetails.payments[index].amount}",
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w600,
                                      fontSize: AppFontSize.size4,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          // subtitle: Text("From: ${detail['from']}, To: ${detail['to']}, Date: ${detail['date']}"),
                          // trailing: SizedBox(
                          //   width: 10.w,
                          //   child: IconButton(
                          //     icon: Icon(Icons.cancel, color: Colors.red),
                          //     onPressed: () => removePayment(mode),
                          //   ),
                          // ),
                        );
                },
              ),
            ),
          );
        }),
        // saveOnTap: () async {
        //   if (formKey.currentState!.validate()) {
        //     //date parsing for transaction Date
        //     DateTime parsedDate = DateFormat('dd-MM-yyyy').parse(transDateCtrl.text);
        //     String formattedDate = DateFormat('yyyy-MM-dd').format(parsedDate);
        //
        //     final double enteredAmount = double.parse(amtCtrl.text);
        //
        //     if (enteredAmount > remainingAmount) {
        //       Get.snackbar(
        //         'Error Message',
        //         'Amount cannot exceed $remainingAmount.',
        //         colorText: AppColor.blackColor,
        //         padding: EdgeInsets.all(15.w),
        //         backgroundColor: AppColor.whiteColor,
        //       );
        //       return;
        //     }
        //
        //     Map<String, dynamic> sendBody = {};
        //
        //     PleaseWaitLoader.openDialog();
        //     if (paymentMode.toLowerCase() == "cash") {
        //       sendBody = {
        //         "paymentModeID": selectedPaymodeId,
        //         "paymodeType": paymentMode,
        //         "paymodeValue": walletAmount,
        //         "amount": amtCtrl.text,
        //         "fromLedgerName": dashboardController.cashLedgerName,
        //         "transactionDate": formattedDate,
        //         "roundOff": 0,
        //         "bankCommision": 0,
        //         "toLedgerID": dashboardController.cashLedgerId,
        //         "toLedgerName": dashboardController.cashLedgerName,
        //         // "DocumentID": "f3a6e66b-b0c1-4d20-84ae-8546bb97fea7"
        //       };
        //     }
        //     if (paymentMode.toLowerCase().toString().removeAllWhitespace == 'banktransfer') {
        //       sendBody = {
        //         "paymentModeID": selectedPaymodeId,
        //         "paymodeType": paymentMode,
        //         "paymodeValue": walletAmount,
        //         "amount": amtCtrl.text,
        //         "fromLedgerID": depositFromCtrl.text,
        //         "fromLedgerName": depositFromTextCtrl.text,
        //         "transactionNo": transIdCtrl.text,
        //         "transactionDate": formattedDate,
        //         "roundOff": 0,
        //         "bankCommision": 0,
        //         "toLedgerID": depositToCtrl.text,
        //         "toLedgerName": depositToTextCtrl.text,
        //         // Add specific document ID for bank transfer
        //       };
        //     }
        //     if ((paymentMode.toLowerCase() == 'bankremittance') || (paymentMode.toLowerCase() == 'upi')) {
        //       // image upload api call
        //
        //       // document id {controller}
        //       sendBody = {
        //         "paymentModeID": selectedPaymodeId,
        //         "paymodeType": paymentMode,
        //         "paymodeValue": walletAmount,
        //         "amount": amtCtrl.text,
        //         "fromLedgerID": depositFromCtrl.text,
        //         "fromLedgerName": depositFromTextCtrl.text,
        //         "transactionNo": transIdCtrl.text,
        //         "transactionDate": formattedDate,
        //         "roundOff": 0,
        //         "bankCommision": 0,
        //         "toLedgerID": depositToCtrl.text,
        //         "toLedgerName": depositToTextCtrl.text,
        //         if (dashboardController.latestUploadedDocument.isNotEmpty)
        //           "DocumentID": dashboardController.latestUploadedDocument[0].documentId,
        //       };
        //     }
        //
        //     debugPrint(sendBody.toString());
        //     PleaseWaitLoader.closeDialog();
        //
        //     Get.back(result: sendBody);
        //   }
        // },
        closeOnTap: () {
          Get.back();
        },
        inButtonText: "Save");
  }
}
