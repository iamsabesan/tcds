import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';

class BulletText extends StatelessWidget {
  final String label;
  final String value;
  final bool showRupeeSymbol;
  final bool withBullet;
  final Color? valueColor;
  final Color? labelColor;
  final double? fontSize;

  const BulletText({
    super.key,
    required this.label,
    this.valueColor,
    this.labelColor,
    this.fontSize,
    required this.value,
    this.showRupeeSymbol = false, // Default is false
    this.withBullet = true, // Default is false
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        if (withBullet == true) ...[
          SizedBox(
            width: 5.w,
          ),
          Container(
            width: 6,
            height: 6,
            margin: EdgeInsets.only(right: 5.w),
            decoration: const BoxDecoration(
              color: AppColor.blackColor, // Bullet color
              shape: BoxShape.circle,
            ),
          ),
        ],
        SizedBox(
          width: 5.w,
        ),
        /*  CustomText(
          text: "${showRupeeSymbol ? '₹' : ''}$value $label",
          // Conditional rupee symbol
          fontWeight: FontWeight.w400,
          fontSize: AppFontSize.size4,
          color: valueColor ?? AppColor.black2Color,

          overflow: TextOverflow.ellipsis,
          maxLines: 1,
        ),*/
        RichText(
          text: TextSpan(
            children: [
              TextSpan(
                text: "${showRupeeSymbol ? '₹' : ''}$value ", // Value part
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: fontSize ?? AppFontSize.size5,
                  color:
                      valueColor ?? AppColor.blackColor, // Color for the value
                ),
              ),
              TextSpan(
                text: label, // Label part
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: AppFontSize.size5,
                  color:
                      labelColor ?? AppColor.blackColor, // Color for the label
                ),
              ),
            ],
          ),

          // Spacing between bullet points
        ),
      ],
    );
  }
}
