import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';

class CourseDropDown extends StatefulWidget {
  final List<CourseDropDownModel> dropdownValues;
  final String labelText;
  final String? errorText;
  final TextEditingController controller;
  final TextEditingController valueController;
  final TextStyle? labelStyle;

  final String? Function(String?)? validator;
  final void Function()? onParentTap;

  const CourseDropDown({
    super.key,
    required this.dropdownValues,
    required this.labelText,
    this.errorText,
    required this.controller,
    this.labelStyle,
    required this.valueController,
    this.validator,
    this.onParentTap,
  });

  @override
  State<CourseDropDown> createState() => _CourseDropDownState();
}

class _CourseDropDownState extends State<CourseDropDown> {
  bool isListVisible = false;
  String selectedValue = '';
  String selectedId = '';

  @override
  void initState() {
    widget.valueController.clear();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => setState(() => isListVisible = !isListVisible),
          child: Column(
            children: [
              CustomTextField(
                labelText: 'Course',
                controller: widget.controller,
                onTap: () => setState(() => isListVisible = !isListVisible),
                readOnly: true,
                enabled: false,
                autofocus: false,
                hintStyle: TextStyle(
                  fontSize: AppFontSize.size4.sp,
                  color: AppColor.black2Color,
                  fontWeight: FontWeight.w400,
                ),
                validator: (val) {
                  if (val!.isEmpty) {
                    return 'Required';
                  } else {
                    return null;
                  }
                },
                suffixIcon: isListVisible
                    ? const Icon(
                        Icons.keyboard_arrow_up_outlined,
                        color: AppColor.blackColor,
                      )
                    : const Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: AppColor.blackColor,
                      ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10.h),
        if (isListVisible)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
                color: Colors.grey.withValues(alpha: 0.2),
                child: Row(
                  children: [
                    Expanded(
                      flex: 50,
                      child: Text(
                        'Course',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 50,
                      child: Text(
                        'Course Type',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                constraints: BoxConstraints(maxHeight: height * 0.4),
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: widget.dropdownValues.length,
                        itemBuilder: (context, index) => InkWell(
                          onTap: () {
                            // Set selected value
                            selectedValue = widget.dropdownValues[index].course;
                            selectedId = widget.dropdownValues[index].courseID;
                            widget.controller.text = selectedValue;
                            widget.valueController.text = selectedId;

                            setState(() => isListVisible = false);

                            debugPrint('Course: ${widget.controller.text}');
                            debugPrint(
                                'Course ID: ${widget.valueController.text}');
                            if (widget.onParentTap != null) {
                              widget.onParentTap!();
                            }
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15.w, vertical: 15.h),
                            color: index % 2 == 0
                                ? Colors.white
                                : Colors.grey.withValues(alpha: 0.1),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 50,
                                  child: Text(
                                    widget.dropdownValues[index].course,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.black,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Expanded(
                                  flex: 50,
                                  child: Text(
                                    widget.dropdownValues[index].courseType,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.black,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
      ],
    );
  }
}

class CourseDropDownModel {
  final String course;
  final String courseType;
  final String courseID;

  CourseDropDownModel(
    this.course,
    this.courseType,
    this.courseID,
  );
}
