import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';

import 'custom_text.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final void Function()? onTap;
  final double? verticalPad;
  final double? horizontalPad;
  final double? fontSize;
  const CustomButton(
      {super.key,
      required this.text,
      this.onTap,
      this.verticalPad,
      this.horizontalPad,
      this.fontSize});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
            vertical: verticalPad ?? 5.w, horizontal: horizontalPad ?? 10.w),
        decoration: BoxDecoration(
          color: AppColor.secondaryColor,
          borderRadius: BorderRadius.circular(8.r),
        ),
        child: Center(
          child: CustomText(
              text: text,
              color: AppColor.whiteColor,
              fontSize: fontSize ?? AppFontSize.size4.sp,
              fontWeight: FontWeight.w500),
        ),
      ),
    );
  }
}
