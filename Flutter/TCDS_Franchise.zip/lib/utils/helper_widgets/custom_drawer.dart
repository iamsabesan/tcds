import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/routes/routes.dart';
import 'package:tcds/user_interface/dashboard/controller/dashboard_controller.dart';
import 'package:tcds/utils/helper_functions/common_dialogs.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:get/get.dart';
import 'package:tcds/utils/helper_widgets/drawer_tile.dart';
import 'package:tcds/utils/helper_widgets/timer_manager.dart';

import '../../constants/app_string.dart';
import '../../constants/shared_preference.dart';

class CustomDrawer extends StatefulWidget {
  final int currentIndex;

  const CustomDrawer({
    super.key,
    required this.currentIndex,
  });

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  DashboardController dashBoardController = Get.put(DashboardController());
  late int selectedIndex;
  bool showRenewal = SharedPreference.getBool(AppStrings.expire);

  // profile details holders will upadted by shredpref in int
  late String profilePicture;
  late String userName;
  late String userNumber;
  @override
  void initState() {
    selectedIndex = widget.currentIndex;
    profilePicture = SharedPreference.getString(AppStrings.userProfilePicture);
    userName = SharedPreference.getString(AppStrings.userName);
    userNumber = SharedPreference.getString(AppStrings.userNumber);

    super.initState();
  }

  List<Map<String, dynamic>> totalMenuData = [
    {
      "text": 'Dashboard',
      "icon": AssetPath.dashboard,
      "path": Routes.dashboardScreen,
    },
    {
      "text": 'Course',
      "icon": AssetPath.course,
      "path": Routes.courseDetailsScreen,
    },
    {
      "text": 'Fees',
      "icon": AssetPath.fees,
      "path": Routes.feesCollectionList,
    },
    {
      "text": 'Material',
      "icon": AssetPath.material,
      "path": Routes.materialIndent,
    },
    {
      "text": 'Exam',
      "icon": AssetPath.exam,
      "path": Routes.examIndent,
    },
    {
      "text": 'Stocks',
      "icon": AssetPath.stock,
      "path": Routes.stockListScreen,
    },
    {
      "text": 'Student',
      "icon": AssetPath.student,
      "path": Routes.studentsListScreen,
    },
    {
      "text": 'Award',
      "icon": AssetPath.award,
      "path": Routes.achieversAward,
    },
    {
      "text": 'Rank',
      "icon": AssetPath.rank,
      "path": Routes.franchiseeRankingScreen,
    },
    {
      "text": 'Renewal',
      "icon": AssetPath.renewal,
      "path": Routes.renewal,
    },
    // {
    //   "text": 'Approval Renewal',
    //   "icon": AssetPath.rank,
    //   "path": Routes.approvalRenewal,
    // },
    // {
    //   "text": 'Subscription Renewal',
    //   "icon": AssetPath.rank,
    //   "path": Routes.subscriptionRenewal,
    // },
    /*{
      "text": 'Delete Account',
      "icon": AssetPath.deleteAccount,
      "path": Routes.dashboardScreen,
    },
    {
      "text": 'Logout',
      "icon": AssetPath.logout,
      "path": Routes.dashboardScreen,
    },*/
  ];

  List<Map<String, dynamic>> get menuData {
    return totalMenuData.where((menuItem) {
      if (!showRenewal) {
        // If showRenewal is true, show all items including "Renewal"
        return true;
      } else {
        // If showRenewal is false, exclude the "Renewal" item
        return menuItem['text'] == 'Renewal';
      }
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        color: AppColor.whiteColor,
        child: Column(
          children: [
            // Drawer Header with Background Image
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                    'assets/logo_with_background.png',
                  ), // Path to logo_with_background.png
                  fit: BoxFit.fill,
                ),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 30.w),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 10.w,
                    ),
                    ClipOval(
                      // show base64 image only when it's not empty
                      // else show default image
                      child:
                          // (dashBoardController
                          //             .franchiseeProfileData.isNotEmpty &&
                          //         dashBoardController.franchiseeProfileData[0]
                          //             .franchiseeImgs.isNotEmpty &&
                          //         dashBoardController.profileImg.isNotEmpty)]

                          profilePicture.isNotEmpty
                              ? Image.memory(
                                  base64Decode(
                                    // dashBoardController.profileImg[0],
                                    profilePicture,
                                  ),
                                  height: 60.w,
                                  width: 60.w,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Image.asset(
                                    AssetPath.userIcon,
                                    height: 50.w,
                                    width: 50.w,
                                    fit: BoxFit.cover,
                                  ),
                                )
                              : Image.asset(
                                  AssetPath.userIcon,
                                  height: 50.w,
                                  width: 50.w,
                                  fit: BoxFit.cover,
                                ),
                    ),
                    SizedBox(
                      height: 10.w,
                    ),
                    CustomText(
                      // text:   dashBoardController.franchiseeProfileData.isNotEmpty
                      //     ? dashBoardController
                      //         .franchiseeProfileData[0].contactName
                      //     : "-",
                      text: userName.isNotEmpty ? userName : '-',
                      color: AppColor.whiteColor,
                      fontSize: AppFontSize.size2,
                      fontWeight: FontWeight.w500,
                    ),
                    CustomText(
                      // text: dashBoardController.franchiseeProfileData.isNotEmpty
                      //     ? dashBoardController.franchiseeProfileData[0].phone
                      //     : "-",
                      text: userNumber.isNotEmpty ? userNumber : '-',
                      color: AppColor.whiteColor,
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w400,
                    ),
                  ],
                ),
              ),
            ),

            // Drawer Items
            Expanded(
              child: Container(
                color: AppColor.whiteColor,
                child: ListView.builder(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                  itemCount: menuData.length,
                  itemBuilder: (context, index) {
                    return DrawerTile(
                      selectedIndex: selectedIndex,
                      activeIndex: index,
                      title: menuData[index]['text'],
                      assetPath: menuData[index]['icon'],
                      onTap: () {
                        if (selectedIndex != index) {
                          setState(() {
                            selectedIndex = index;
                          });
                          // Navigate to the selected route
                          String path = menuData[index]['path'];
                          Get.offAllNamed(path);
                        }
                      },
                    );
                  },
                ),
              ),
            ),

            DrawerTile(
              selectedIndex: selectedIndex,
              activeIndex: menuData.length,
              // Unique index
              title: 'Delete Account',
              assetPath: AssetPath.deleteAccount,
              onTap: () {
                setState(() {
                  selectedIndex = menuData.length;
                });
                showAccountDeletionDialog(
                    context: context, dashboardController: dashBoardController);
              },
            ),

            // Logout
            DrawerTile(
              selectedIndex: selectedIndex,
              activeIndex: menuData.length + 1,
              // Unique index
              title: 'Logout',
              assetPath: AssetPath.logout,
              onTap: () {
                setState(() {
                  selectedIndex = menuData.length + 1;
                });
                showConfirmationDialog(
                  context: context,
                  message: 'Are you sure to Logout?',
                  outButtonOnTap: () {
                    Get.back();
                  },
                  inButtonOnTap: () {
                    // Clear all stored values and navigate to login screen
                    // LocalStorage.clearAll();
                    TimerManager().cancelTimer();
                    SharedPreference.putBool(AppStrings.isLoggedIn, false);
                    SharedPreference.clearAll();
                    Get.offAllNamed(Routes.logInScreen);
                  },
                );
              },
            ),
            Container(
              height: 20,
              color: AppColor.whiteColor,
            )
          ],
        ),
      ),
    );
  }
}
