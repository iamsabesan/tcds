import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';

class CustomTextField extends StatefulWidget {
  final String labelText;
  final bool withLabelText;
  final bool filled;
  final String? errorText;
  final TextEditingController controller;
  final List<TextInputFormatter>? inputFormatters;
  final bool obscureText;
  final String? Function(String?)? validator;
  final TextStyle? hintStyle;
  final TextStyle? labelStyle;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double? height;
  final void Function()? onTap;
  final bool readOnly;
  final int? maxLength;
  final String? counterText;
  final TextInputType? keyboardType;
  final TextCapitalization? textCapitalization;
  final bool autofocus;
  final int? maxLines;
  final String? hintText;
  final EdgeInsetsGeometry? contentPadding;
  final double? verticalPadding;
  final bool? enabled;
  final void Function(String)? onChanged;
  final FocusNode? focusNode;
  final TextAlign textAlign;
  final void Function(String)? onFieldSubmitted;
  final void Function(String?)? onSaved;

  const CustomTextField({
    super.key,
    required this.labelText,
    required this.controller,
    this.validator,
    this.errorText,
    this.onSaved,
    this.contentPadding,
    this.textCapitalization,
    this.inputFormatters,
    this.obscureText = false,
    this.hintStyle,
    this.prefixIcon,
    this.suffixIcon,
    this.height,
    this.onTap,
    this.labelStyle,
    this.readOnly = false,
    this.maxLength,
    this.counterText,
    this.keyboardType,
    this.autofocus = false,
    this.maxLines = 1,
    this.hintText,
    this.verticalPadding,
    this.enabled = true,
    this.onChanged,
    this.focusNode,
    this.withLabelText = true,
    this.filled = false,
    this.textAlign = TextAlign.start,
    this.onFieldSubmitted,
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // title / label
        // if (widget.withLabelText)
        //   CustomText(
        //     text: widget.labelText,
        //     fontWeight: FontWeight.w400,
        //     color: AppColor.black2Color,
        //     fontSize: AppFontSize.size4.sp,
        //   ),
        if (widget.withLabelText)
          SizedBox(
            height: 2.5.w,
          ),

        // textfield
        TextFormField(
          focusNode: widget.focusNode,
          controller: widget.controller,
          enabled: widget.enabled,
          cursorColor: AppColor.secondaryColor,
          showCursor: true,
          textAlign: widget.textAlign,
          validator: widget.validator,
          readOnly: widget.readOnly,
          autofocus: widget.autofocus,
          textAlignVertical: TextAlignVertical.center,
          keyboardType: widget.keyboardType,
          obscureText: widget.obscureText,
          maxLength: widget.maxLength,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          inputFormatters: widget.inputFormatters,
          onFieldSubmitted: widget.onFieldSubmitted,
          onTap: widget.onTap,
          maxLines: widget.maxLines,
          onChanged: widget.onChanged ??
              (val) {
                widget.validator;
              },
          textCapitalization:
              widget.textCapitalization ?? TextCapitalization.none,
          style: TextStyle(
              color: AppColor.blackColor,
              fontSize: AppFontSize.size4.sp,
              fontWeight: FontWeight.w500),
          decoration: InputDecoration(
            floatingLabelBehavior: FloatingLabelBehavior.auto,
            labelText: widget.labelText,
            labelStyle: TextStyle(
                color: AppColor.blackColor, fontSize: AppFontSize.size4.sp),
            // constraints:
            //     BoxConstraints(maxHeight: widget.height ?? 55.w, minHeight: 50.w),
            hintText: widget.hintText,
            contentPadding: widget.contentPadding ??
                EdgeInsets.symmetric(
                    horizontal: 15.w, vertical: widget.verticalPadding ?? 1.w),
            errorText: widget.errorText,
            errorMaxLines: 3,
            errorStyle: TextStyle(
              fontSize: AppFontSize.size5.sp,
              color: AppColor.redColor,
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: widget.prefixIcon,

            suffixIconConstraints:
                BoxConstraints(maxHeight: 30.w, minHeight: 20.w),
            suffixIcon: Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.w),
              child: widget.suffixIcon,
            ),
            hintStyle: widget.hintStyle ??
                TextStyle(
                  color: AppColor.black2Color,
                  fontSize: AppFontSize.size3.sp,
                ),
            fillColor: AppColor.grey3,
            filled: widget.filled,
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black.withValues(alpha: 0.1),
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(8.r),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.primaryColor),
              // borderSide: BorderSide(
              //   color: AppColor.grey2,
              //   width: 1.5,
              // ),
              borderRadius: BorderRadius.circular(8.r),
            ),
            border: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColor.grey2,
              ),
              borderRadius: BorderRadius.circular(8.r),
            ),
          ),
        ),
      ],
    );
  }
}
