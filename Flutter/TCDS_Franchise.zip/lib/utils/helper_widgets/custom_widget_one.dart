import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/pair_text.dart';

import 'custom_text.dart';

class CustomWidgetOne extends StatefulWidget {
  final String valueText1;
  final String? valueText2;
  final String courseName;
  final String keyText1;
  final String? keyText2;
  final String amount;
  final bool withDivider;
  final bool withForwardArrow;
  final bool withKeyText2;
  final int orderNumber;

  // final bool isSelectActive;
  final void Function()? onTap;

  const CustomWidgetOne({
    super.key,

    // this.isSelectActive = false,
    this.onTap,
    required this.valueText1,
    required this.courseName,
    required this.keyText1,
    this.keyText2,
    this.valueText2,
    required this.amount,
    required this.withDivider,
    required this.withForwardArrow,
    required this.withKeyText2,
    required this.orderNumber,
  });

  @override
  State<CustomWidgetOne> createState() => _CustomWidgetOneState();
}

class _CustomWidgetOneState extends State<CustomWidgetOne> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: AppColor.white2Color,
      overlayColor: const WidgetStatePropertyAll(AppColor.white2Color),
      onTap: widget.onTap,
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Flexible(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: CustomText(
                    text: "${widget.orderNumber}. ${widget.courseName}",
                    color: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                    fontSize: AppFontSize.size4.sp,
                  ),
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
              Flexible(
                child: Align(
                  alignment: Alignment.center,
                  child: CustomText(
                    text: widget.amount,
                    color: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                    fontSize: AppFontSize.size4.sp,
                  ),
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
              Flexible(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: PairText(
                    keyText: widget.keyText1,
                    valueText: widget.valueText1,
                    separator: ' ',
                    keyColor: AppColor.secondaryColor,
                    valueColor: AppColor.secondaryColor,
                    keyWeight: FontWeight.w500,
                    valueWeight: FontWeight.w500,
                    keySize: AppFontSize.size4.sp,
                    valueSize: AppFontSize.size4.sp,
                  ),
                ),
              ),

              /* Expanded(
                flex: 5,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: widget.courseName,
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size4.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    PairText(
                      keyText: widget.keyText1,
                      valueText: widget.valueText1.toString(),
                      separator: ' - ',
                      keyColor: AppColor.blackColor,
                      valueColor: AppColor.blackColor,
                      keyWeight: FontWeight.w400,
                      valueWeight: FontWeight.w400,
                      keySize: AppFontSize.size4.sp,
                      valueSize: AppFontSize.size4.sp,
                    ),
                    SizedBox(
                      height: 4.w,
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 8,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomText(
                      text: widget.amount,
                      color: AppColor.secondaryColor,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size4.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    if (widget.withKeyText2) ...[
                      PairText(
                        keyText: widget.keyText2.toString(),
                        valueText: widget.valueText2.toString(),
                        separator: ' - ',
                        keyColor: AppColor.blackColor,
                        valueColor: AppColor.blackColor,
                        keyWeight: FontWeight.w400,
                        valueWeight: FontWeight.w400,
                        keySize: AppFontSize.size4.sp,
                        valueSize: AppFontSize.size4.sp,
                      ),
                    ],
                  ],
                ),
              ), */
              // if (widget.withForwardArrow)
              //   const Row(
              //     mainAxisAlignment: MainAxisAlignment.end,
              //     children: [
              //       Padding(
              //         padding: EdgeInsets.only(top: 8.0),
              //         child: ForwardArrowWidget(
              //             // onTap: widget.onTap,
              //             ),
              //       ),
              //     ],
              //   ),
              SizedBox(
                height: 20.w,
              ),
            ],
          ),
          const Divider(
            thickness: 0.5,
          ),
          SizedBox(
            height: 20.w,
          ),
        ],
      ),
    );
  }
}
