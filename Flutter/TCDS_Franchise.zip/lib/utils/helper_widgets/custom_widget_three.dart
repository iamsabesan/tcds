import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import '../../user_interface/course_details/model/course_detail_response_model.dart';
import 'forward_arrow_widget.dart';

class CustomWidgetThree extends StatefulWidget {
  final CourseDetailList data;
  final bool withForwardArrow;
  final void Function()? onTap;
  final NumberFormat currencyFormat;

  const CustomWidgetThree({
    super.key,
    this.onTap,
    required this.withForwardArrow,
    required this.data,
    required this.currencyFormat,
  });

  @override
  State<CustomWidgetThree> createState() => _CustomWidgetThreeState();
}

class _CustomWidgetThreeState extends State<CustomWidgetThree> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onTap,
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Column
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: widget.data.course,
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w500,
                      color: AppColor.primaryColor,
                    ),
                    const SizedBox(height: 6.0),
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.circle,
                              size: 10,
                              color: AppColor.primaryColor,
                            ),
                            const SizedBox(width: 8.0),
                            CustomText(
                              text: widget.data.shortName,
                              fontSize: AppFontSize.size5,
                              fontWeight: FontWeight.w400,
                              color: AppColor.blackColor,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.circle,
                              size: 10,
                              color: AppColor.primaryColor,
                            ),
                            const SizedBox(width: 8.0),
                            CustomText(
                              text: widget.data.duration,
                              fontSize: AppFontSize.size5,
                              fontWeight: FontWeight.w400,
                              color: AppColor.blackColor,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.circle,
                              size: 10,
                              color: AppColor.primaryColor,
                            ),
                            const SizedBox(width: 8.0),
                            CustomText(
                              text: '${widget.data.semester} Semester',
                              fontSize: AppFontSize.size5,
                              fontWeight: FontWeight.w400,
                              color: AppColor.blackColor,
                            ),
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.circle,
                              size: 10,
                              color: AppColor.primaryColor,
                            ),
                            const SizedBox(width: 8.0),
                            CustomText(
                              text: widget.data.eligibility,
                              fontSize: AppFontSize.size5,
                              fontWeight: FontWeight.w400,
                              color: AppColor.blackColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              // Right Column
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: widget.currencyFormat.format(widget.data.courseFees),
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                    color: AppColor.orange,
                  ),
                  // SizedBox(height: 5.h),
                  /*  CustomText(
                    text: widget.courseType,
                    fontSize: AppFontSize.size5,
                    fontWeight: FontWeight.w400,
                    color: AppColor.black2Color,
                  ), */
                ],
              ),
              SizedBox(
                width: 15.w,
              ),

              if (widget.withForwardArrow)
                const Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 8.0),
                      child: ForwardArrowWidget(),
                    ),
                  ],
                ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          const Divider(
            thickness: 1.0,
            height: 0,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }
}
