import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';
import '../../constants/asset_paths.dart';
import 'custom_text.dart';

class CustomWidgetTwo extends StatelessWidget {
  final String text1;
  final String text2;
  final String text3;
  final String? amount;
  final String? text4;
  final String? text5;
  final String? text6;
  final Color? text3Color;
  final Color? text4Color;
  final Color? text5Color;
  final Color? text6Color;
  final bool withDivider;
  final bool withForwardArrow;
  final String? base64;
  final List<Widget> children;
  final NumberFormat currencyFormat;

  // final bool isSelectActive;
  final void Function()? onTap;

  const CustomWidgetTwo({
    super.key,

    // this.isSelectActive = false,
    this.onTap,
    this.base64,
    required this.text1,
    required this.text2,
    required this.text3,
    this.amount,
    this.text4,
    this.text3Color,
    required this.withDivider,
    required this.withForwardArrow,
    this.text5,
    this.text6,
    this.text4Color,
    this.text5Color,
    this.text6Color,
    this.children = const [],
    required this.currencyFormat,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      splashColor: AppColor.white2Color,
      overlayColor: const WidgetStatePropertyAll(AppColor.white2Color),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 15.w),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(
                  backgroundColor: AppColor.whiteColor,
                  maxRadius: 20.w,
                  minRadius: 15.w,
                  child: Container(
                    constraints: const BoxConstraints.expand(),
                    clipBehavior: Clip.hardEdge,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                    ),
                    // Show default profile image if profile pic value is emypty
                    // else show actual image
                    child: ClipOval(
                      // show base64 image only when it's not empty
                      // else show default image
                      child: base64 != null
                          ? Image.memory(
                              base64Decode(base64!),
                              height: 50.w,
                              width: 50.w,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Image.asset(
                                AssetPath.userIcon,
                                height: 50.w,
                                width: 50.w,
                                fit: BoxFit.cover,
                              ),
                            )
                          : Image.asset(
                              AssetPath.userIcon,
                              height: 50.w,
                              width: 50.w,
                              fit: BoxFit.cover,
                            ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 5.w,
                ),
                Expanded(
                  child: Column(
                    // crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 5,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  text: text1,
                                  color: AppColor.primaryColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: AppFontSize.size5.sp,
                                  // overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                CustomText(
                                  text: text2,
                                  color: AppColor.blackColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: AppFontSize.size5.sp,
                                  // overflow: TextOverflow.ellipsis,
                                ),
                                if (text5 != null)
                                  const SizedBox(
                                    height: 5,
                                  ),
                                if (text5 != null)
                                  CustomText(
                                    text: text5 ?? "",
                                    color: text5Color ?? AppColor.blackColor,
                                    fontWeight: FontWeight.w600,
                                    fontSize: AppFontSize.size5.sp,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                          ),
                          Expanded(
                            flex: 5,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                CustomText(
                                  text: text3,
                                  color: text3Color ?? AppColor.blackColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: AppFontSize.size5.sp,
                                  // overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                CustomText(
                                  text: text4 ??
                                      currencyFormat.format(
                                          double.tryParse(amount ?? "0") ??
                                              0.0),
                                  color: text4Color ?? AppColor.blackColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: AppFontSize.size5.sp,
                                  // overflow: TextOverflow.ellipsis,
                                ),
                                if (text6 != null)
                                  const SizedBox(
                                    height: 5,
                                  ),
                                if (text6 != null)
                                  CustomText(
                                    text: text6 ?? "",
                                    color: text6Color ?? AppColor.blackColor,
                                    fontWeight: FontWeight.w600,
                                    fontSize: AppFontSize.size5.sp,
                                    // overflow: TextOverflow.ellipsis,
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      if (children.isNotEmpty)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: children,
                        ),
                    ],
                  ),
                ),
                if (withForwardArrow)
                  SizedBox(
                    width: 10.w,
                  ),
                if (withForwardArrow)
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: ForwardArrowWidget(
                      onTap: onTap,
                    ),
                  ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            if (children.isNotEmpty)
              const SizedBox(
                height: 10,
              ),
            if (withDivider)
              const Divider(
                thickness: 0.5,
                height: 0,
                color: AppColor.greyColor,
              ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
