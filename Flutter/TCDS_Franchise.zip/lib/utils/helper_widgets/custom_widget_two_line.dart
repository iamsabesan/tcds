import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import 'forward_arrow_widget.dart';

class CustomWidgetTwoLine extends StatefulWidget {
  final String title;
  final String duration;
  final String price;
  final String courseType;
  final bool withForwardArrow;
  final void Function()? onTap;

  const CustomWidgetTwoLine({
    super.key,
    required this.title,
    this.onTap,
    required this.duration,
    required this.price,
    required this.courseType,
    required this.withForwardArrow,
  });

  @override
  State<CustomWidgetTwoLine> createState() => _CustomWidgetTwoLineState();
}

class _CustomWidgetTwoLineState extends State<CustomWidgetTwoLine> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Left Column
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: widget.title,
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                    color: AppColor.primaryColor,
                  ),
                  const SizedBox(height: 4.0),
                  Row(
                    children: [
                      CustomText(
                        text: "Quantity : ${widget.duration}",
                        fontSize: AppFontSize.size5,
                        fontWeight: FontWeight.w400,
                        color: AppColor.blackColor,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Right Column
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: widget.courseType,
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                    color: AppColor.orange,
                  ),
                  SizedBox(height: 5.h),
                  CustomText(
                    text: widget.price,
                    fontSize: AppFontSize.size5,
                    fontWeight: FontWeight.w400,
                    color: AppColor.black2Color,
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 15.w,
            ),

            if (widget.withForwardArrow)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: ForwardArrowWidget(
                      onTap: widget.onTap,
                    ),
                  ),
                ],
              ),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        const Divider(
          thickness: 1.0,
          color: AppColor.greyColor,
        ),
      ],
    );
  }
}
