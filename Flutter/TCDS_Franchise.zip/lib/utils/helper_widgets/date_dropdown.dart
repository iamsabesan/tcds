import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../constants/colors.dart';
import '../../constants/font_sizes.dart';
import 'custom_text.dart';

class DateDropDown extends StatefulWidget {
  final List<DateDropDownValueModel> dropdownValues;
  final String? hintText;
  final String? errorText;
  final TextEditingController controller;
  final List<TextInputFormatter>? inputFormatters;
  final String? Function(String?)? validator;
  final TextStyle? hintStyle;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool withHeaderTitle;
  final String? headerText;
  final double? height;
  final dynamic parentSetState;
  final double? verticalPadding;
  final bool? filled;
  final Color? fillColor;
  final String labelText;
  final bool withLabelText;
  const DateDropDown({
    super.key,
    this.hintText,
    required this.controller,
    this.validator,
    this.errorText,
    this.inputFormatters,
    this.hintStyle,
    this.prefixIcon,
    this.withHeaderTitle = false,
    this.headerText,
    this.suffixIcon,
    this.height,
    required this.dropdownValues,
    this.parentSetState,
    this.verticalPadding,
    this.filled,
    this.fillColor,
    required this.labelText,
    this.withLabelText = true,
  });

  @override
  State<DateDropDown> createState() => _DateDropDownState();
}

class _DateDropDownState extends State<DateDropDown> {
  late String? selectedValue;
  @override
  void initState() {
    super.initState();
    setInitialValue();
  }

  // FUNCTION: To assign initial value based on [widget.controller]
  void setInitialValue() {
    try {
      selectedValue = widget.dropdownValues
          .firstWhere((element) => element.value == widget.controller.text)
          .value;
    } catch (e) {
      debugPrint("Error at Func-@setInitialValue => $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.withHeaderTitle)
          CustomText(
            text: widget.headerText!,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w400,
            fontSize: 14.sp,
          ),
        if (widget.withHeaderTitle)
          SizedBox(
            height: 5.w,
          ),
        DropdownButtonFormField(
          initialValue: selectedValue,
          menuMaxHeight: height * 0.35,
          isExpanded: true,
          isDense: true,
          style: TextStyle(
              color: AppColor.black2Color,
              fontSize: 14.sp,
              fontWeight: FontWeight.w500),
          items: widget.dropdownValues
              .map<DropdownMenuItem<String>>((DateDropDownValueModel value) {
            return DropdownMenuItem<String>(
                value: value.value.toString(),
                child: CustomText(
                  text: value.visibleText,
                  maxLines: 2,
                ));
          }).toList(),
          icon: const Icon(
            Icons.arrow_drop_down,
            color: AppColor.blackColor,
          ),
          onChanged: (value) {
            if (value != null) {
              selectedValue = value;
              widget.controller.text = selectedValue!;
              if (widget.parentSetState != null) {
                widget.parentSetState(() {});
              }
              debugPrint(widget.controller.text);
            }
          },
          decoration: InputDecoration(
            floatingLabelBehavior: FloatingLabelBehavior.auto,
            labelText: widget.labelText,
            labelStyle: TextStyle(
              color: AppColor.blackColor,
              fontSize: AppFontSize.size4.sp,
            ),
            contentPadding:
                EdgeInsets.symmetric(horizontal: 15.w, vertical: 1.w),
            hintText: widget.hintText,
            errorText: widget.errorText,
            errorMaxLines: 3,
            errorStyle: TextStyle(
              fontSize: 12.sp,
              color: AppColor.redColor,
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: widget.prefixIcon,
            suffixIcon: widget.suffixIcon,
            filled: widget.filled ?? false,
            fillColor: widget.fillColor,
            hintStyle: widget.hintStyle ??
                TextStyle(
                  color: AppColor.black2Color,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w400,
                ),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black.withValues(alpha: 0.1),
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.primaryColor),
              // borderSide: BorderSide(
              //   color: AppColor.grey2,
              //   width: 1.5,
              // ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            border: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColor.grey2,
              ),
              borderRadius: BorderRadius.circular(12.r),
            ),
          ),
          borderRadius: BorderRadius.circular(10.0),
        )
      ],
    );
  }
}

// Common Dropdown value model
class DateDropDownValueModel {
  final String value;
  final String visibleText;

  DateDropDownValueModel(this.value, this.visibleText);
}
