import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/asset_paths.dart';
import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';
import 'package:intl/intl.dart';

class DatePickerTextField extends StatefulWidget {
  final String labelText;
  final bool filled;
  final TextStyle? hintStyle;

  final bool withLabelText;
  final String? errorText;
  final TextStyle? labelStyle;
  final DateTime? lastDate;
  final DateTime? firstDate;
  final TextEditingController controller;
  final double? height;
  final double? fontSize;
  final double? verticalPadding;
  final bool withOnTap;
  final void Function()? parentOnTap;
  final void Function(String)? onChanged;
  final String? Function(String?)? validator;

  const DatePickerTextField({
    super.key,
    required this.controller,
    this.height,
    this.fontSize,
    this.verticalPadding,
    this.withOnTap = true,
    this.validator,
    required this.labelText,
    this.hintStyle,
    this.errorText,
    this.labelStyle,
    this.withLabelText = true,
    this.parentOnTap,
    this.onChanged,
    this.filled = false,
    this.lastDate,
    this.firstDate,
  });

  @override
  State<DatePickerTextField> createState() => _DatePickerTextFieldState();
}

class _DatePickerTextFieldState extends State<DatePickerTextField> {
  DateTime selectedDate = DateTime.now();

  // date picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: widget.firstDate ?? DateTime(1880, 1),
      lastDate: widget.lastDate ?? DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        widget.controller.text = DateFormat('dd-MM-yyyy').format(selectedDate);
      });
      // if Parent Set State is not null call it to refresh
      if (widget.parentOnTap != null) {
        // calling parent widget setState to reflect data that need to changed after date got selected
        widget.parentOnTap!();
      }
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // title / label
        /*  if (widget.withLabelText)
          CustomText(
            text: widget.labelText,
            fontWeight: FontWeight.w400,
            color: AppColor.black2Color,
            fontSize: AppFontSize.size4.sp,
          ),
        ,*/
        if (widget.withLabelText)
          SizedBox(
            height: 2.5.w,
          ),
        // date picker textfield
        TextFormField(
          controller: widget.controller,
          readOnly: true,
          validator: widget.validator,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          onTap: () => widget.withOnTap ? _selectDate(context) : null,
          onChanged: widget.onChanged,
          style: TextStyle(
              color: AppColor.blackColor,
              fontSize: AppFontSize.size4.sp,
              fontWeight: FontWeight.w500),
          decoration: InputDecoration(
            floatingLabelBehavior: FloatingLabelBehavior.auto,
            labelText: widget.labelText,
            labelStyle: TextStyle(
              color: AppColor.blackColor,
              fontSize: AppFontSize.size4.sp,
            ),
            isDense: true,
            // constraints:
            //     BoxConstraints(maxHeight: widget.height ?? 50.w, minHeight: 45.w),
            contentPadding:
                EdgeInsets.symmetric(horizontal: 15.w, vertical: 1.w),

            errorText: widget.errorText,
            errorMaxLines: 3,
            errorStyle: TextStyle(
              fontSize: AppFontSize.size5.sp,
              color: AppColor.redColor,
              fontWeight: FontWeight.w400,
            ),
            hintStyle: widget.hintStyle ??
                TextStyle(
                  color: AppColor.black2Color,
                  fontSize: AppFontSize.size3.sp,
                ),
            fillColor: AppColor.grey3,
            filled: widget.filled,
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black.withValues(alpha: 0.1),
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.primaryColor),
              // borderSide: BorderSide(
              //   color: AppColor.grey2,
              //   width: 1.5,
              // ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            border: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColor.grey2,
              ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            // suffixIconConstraints:
            //     BoxConstraints.tightFor(width: 30.w, height: 30.w),
            suffixIcon: Padding(
              padding: EdgeInsets.all(8.w),
              child: GestureDetector(
                onTap: () => widget.withOnTap ? _selectDate(context) : null,
                child: Image.asset(
                  AssetPath.calender,
                  height: 25.w,
                  width: 25.w,
                  fit: BoxFit.contain,
                ),
                // child: Icon(
                //   Icons.calendar_month_rounded,
                //   color: AppColor.secondaryColor,
                // ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
