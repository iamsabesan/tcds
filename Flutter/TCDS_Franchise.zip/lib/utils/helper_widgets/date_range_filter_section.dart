import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../constants/colors.dart';
import 'date_dropdown.dart';
import 'date_picker_textfield.dart';

class DateRangeFilterSection extends StatefulWidget {
  final bool withSearchIcon;
  final void Function()? onTap;
  final TextEditingController fromDateController;
  final TextEditingController toDateController;
  final TextEditingController dateRangeController;
  final String? Function(String?)? fromdateValidator;
  final String? Function(String?)? todateValidator;
  final void Function()? searchOnTap;
  const DateRangeFilterSection(
      {super.key,
      this.withSearchIcon = true,
      this.onTap,
      required this.fromDateController,
      required this.toDateController,
      this.fromdateValidator,
      this.todateValidator,
      required this.dateRangeController,
      this.searchOnTap});

  @override
  State<DateRangeFilterSection> createState() => _DateRangeFilterSectionState();
}

class _DateRangeFilterSectionState extends State<DateRangeFilterSection> {
  /*  // TextEditing Controllers
  TextEditingController dropDownController = TextEditingController(
      text: 'Today'); // Initialize with default value Today */

  // Function to assign values to controllers according to dropdown value
  void getDate() {
    try {
      DateTime now = DateTime.now();
      widget.toDateController.text = DateFormat('dd-MM-yyyy')
          .format(DateTime.now()); // Usually todate would be current date
      switch (widget.dateRangeController.text) {
        case 'Today':
          String returnDate = DateFormat('dd-MM-yyyy').format(DateTime.now());
          widget.fromDateController.text = returnDate;
          break;
        case 'This Week':
          int weekday = now.weekday;
          DateTime startOfWeek = now.subtract(Duration(days: weekday - 1));
          String fromDate = DateFormat('dd-MM-yyyy').format(startOfWeek);
          widget.fromDateController.text = fromDate;
          break;
        case 'This Month':
          String fromDate =
              DateFormat('dd-MM-yyyy').format(DateTime(now.year, now.month, 1));
          widget.fromDateController.text = fromDate;
          break;
        case 'Last 3 Months':
          String fromDate = DateFormat('dd-MM-yyyy')
              .format(DateTime(now.year, now.month - 3, now.day + 1));
          widget.fromDateController.text = fromDate;
          break;
        case 'Last 6 Months':
          String fromDate = DateFormat('dd-MM-yyyy')
              .format(DateTime(now.year, now.month - 6, now.day + 1));
          widget.fromDateController.text = fromDate;
          break;
        case 'Last 12 Months':
          String fromDate = DateFormat('dd-MM-yyyy')
              .format(DateTime(now.year, now.month - 12, now.day + 1));
          widget.fromDateController.text = fromDate;

          break;
        case 'This Year':
          String fromDate =
              DateFormat('dd-MM-yyyy').format(DateTime(now.year, 1, 1));
          widget.fromDateController.text = fromDate;
          break;
        case 'Last Year':
          String fromDate =
              DateFormat('dd-MM-yyyy').format(DateTime(now.year - 1, 1, 1));
          String toDate =
              DateFormat('dd-MM-yyyy').format(DateTime(now.year - 1, 12, 31));
          widget.fromDateController.text = fromDate;
          widget.toDateController.text = toDate;
          break;
      }
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.dateRangeController.text.isEmpty) {
      widget.dateRangeController.text = "This Month";
    }
  }

  @override
  Widget build(BuildContext context) {
    getDate(); // Calling getDate to ensure each time values changes when date range changes
    return Column(
      children: [
        DateDropDown(
            controller: widget.dateRangeController,
            withHeaderTitle: false,
            labelText: 'Date Range',
            // Pass current state to update values after selection
            parentSetState: setState,
            dropdownValues: [
              DateDropDownValueModel('Today', 'Today'),
              DateDropDownValueModel('This Week', 'This Week'),
              DateDropDownValueModel('This Month', 'This Month'),
              DateDropDownValueModel('Last 3 Months', 'Last 3 Months'),
              DateDropDownValueModel('Last 6 Months', 'Last 6 Months'),
              DateDropDownValueModel('Last 12 Months', 'Last 12 Months'),
              DateDropDownValueModel('This Year', 'This Year'),
              DateDropDownValueModel('Last Year', 'Last Year'),
              DateDropDownValueModel('Custom', 'Custom'),
            ]),
        const SizedBox(
          height: 15,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Flexible(
              flex: 40,
              child: DatePickerTextField(
                // Enable Ontap if date range custom only
                withOnTap: widget.dateRangeController.value.text == 'Custom',
                controller: widget.fromDateController,
                validator: widget.fromdateValidator,
                labelText: 'From Date',
              ),
            ),
            const Spacer(
              flex: 5,
            ),
            Flexible(
              flex: 40,
              child: DatePickerTextField(
                  // Enable Ontap if date range custom only
                  withOnTap: widget.dateRangeController.value.text == 'Custom',
                  controller: widget.toDateController,
                  validator: widget.todateValidator,
                  labelText: 'To Date'),
            ),
            if (widget.withSearchIcon)
              const Spacer(
                flex: 5,
              ),
            if (widget.withSearchIcon)
              Flexible(
                flex: 10,
                child: InkWell(
                  onTap: widget.searchOnTap,
                  child: const Icon(
                    Icons.search,
                    color: AppColor.primaryColor,
                  ),
                ),
              )
          ],
        )
      ],
    );
  }
}
