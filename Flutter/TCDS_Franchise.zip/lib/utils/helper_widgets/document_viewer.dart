import 'package:flutter/material.dart';
// import 'package:photo_view/photo_view.dart';
// import 'package:path_provider/path_provider.dart';

class DocumentViewer extends StatelessWidget {
  final String base64Image;
  final String fileName;
  final String mimeType;

  const DocumentViewer({super.key, 
    required this.base64Image,
    required this.fileName,
    required this.mimeType,
  });

  // Future<void> _downloadImage(BuildContext context) async {
  //   try {
  //     // Decode base64 to bytes
  //     Uint8List imageBytes = base64Decode(base64Image);
  //
  //     // Get the downloads directory
  //     final directory = await getExternalStorageDirectory();
  //     final filePath = '${directory!.path}/$fileName';
  //
  //     // Save the file
  //     final file = File(filePath);
  //     await file.writeAsBytes(imageBytes);
  //
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Downloaded to $filePath')),
  //     );
  //   } catch (e) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Download failed: $e')),
  //     );
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Document Viewer'),
        actions: const [
          // IconButton(
          //   icon: Icon(Icons.download),
          //   onPressed: () => _downloadImage(context),
          // ),
        ],
      ),
      body: const Center(
        // child: PhotoView(
        //   imageProvider: MemoryImage(base64Decode(base64Image)),
        //   backgroundDecoration: BoxDecoration(color: Colors.white),
        // ),
      ),
    );
  }
}
