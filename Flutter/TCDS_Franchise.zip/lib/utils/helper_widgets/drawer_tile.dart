import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/font_sizes.dart';
import '../../constants/colors.dart';
import 'custom_text.dart';

// ignore: must_be_immutable
class DrawerTile extends StatefulWidget {
  int selectedIndex;
  final int activeIndex;
  final String title;
  final void Function()? onTap;
  final String assetPath;

  DrawerTile({
    super.key,
    required this.selectedIndex,
    required this.activeIndex,
    required this.title,
    this.onTap,
    required this.assetPath,
  });

  @override
  State<DrawerTile> createState() => _DrawerTileState();
}

class _DrawerTileState extends State<DrawerTile> {
  @override
  Widget build(BuildContext context) {
    bool isSelected = widget.selectedIndex == widget.activeIndex;
    return Stack(
      children: [
        Container(
          // padding: widget.btmSpace ? EdgeInsets.only(bottom: 10.w) : null,
          decoration: BoxDecoration(
            color:
                isSelected ? AppColor.drawerSelectedColor : AppColor.whiteColor,
            borderRadius: BorderRadius.circular(11.r),
          ),
          child: ListTile(
            dense: true,
            minVerticalPadding: 0,
            visualDensity: VisualDensity.adaptivePlatformDensity,
            splashColor: AppColor.primary2Color.withValues(alpha: 0.5),
            leading: Image.asset(
              widget.assetPath,
              color: isSelected ? AppColor.primaryColor : AppColor.black2Color,
              height: 25.w,
              width: 25.w,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(11.r),
            ),
            // trailing: Image.asset(
            //   "assets/next.png",
            //   scale: 30.0,
            //   color: isSelected ? AppColor.primaryColor : Colors.black.withValues(alpha:0.3),
            // ),
            title: CustomText(
              text: widget.title,
              fontSize: AppFontSize.size4.sp,
              color: isSelected ? AppColor.blackColor : AppColor.blackColor,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            ),
            selected: isSelected,
            onTap: widget.onTap,
          ),
        ),
        // separator between combine tiles
        /* if (!widget.btmSpace)
          Positioned(
            bottom: 0,
            right: 0,
            left: 0,
            child: Divider(
              color: AppColor.grey2,
              thickness: 1.5,
              height: 1,
              indent: 25.w,
              endIndent: 25.w,
            ),
          )*/
      ],
    );
  }
}
