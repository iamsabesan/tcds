import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/font_sizes.dart';
import '../../constants/colors.dart';

class CustomDropdownButtonFormField extends StatefulWidget {
  final String value;
  final String hint;
  final List<CustomDropDownModel> items;
  final String? Function(String?)? validator;
  final void Function(CustomDropDownModel?)? onChanged;

  final InputDecoration decoration;

  const CustomDropdownButtonFormField({
    super.key,
    required this.value,
    this.validator,
    required this.items,
    required this.onChanged,
    this.decoration = const InputDecoration(
      border: OutlineInputBorder(),
    ),
    required this.hint,
  });

  @override
  State<CustomDropdownButtonFormField> createState() =>
      _CustomDropdownButtonFormFieldState();
}

class _CustomDropdownButtonFormFieldState
    extends State<CustomDropdownButtonFormField> {
  CustomDropDownModel? valueText;

  @override
  void initState() {
    valueText = CustomDropDownModel(
      widget.value,
      widget.value,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<CustomDropDownModel>(
      hint: Text(widget.hint),
      icon: const Icon(
        Icons.arrow_drop_down,
        color: AppColor.primaryColor,
      ),
      dropdownColor: AppColor.whiteColor,
      initialValue: valueText,
      items: widget.items.map((CustomDropDownModel value) {
        return DropdownMenuItem<CustomDropDownModel>(
          value: value,
          child: Text(
            value.value,
            style: TextStyle(
                color: AppColor.blackColor,
                fontSize: AppFontSize.size4.sp,
                fontWeight: FontWeight.w500),
          ),
        );
      }).toList(),
      onChanged: widget.onChanged,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 10.w, horizontal: 15.w),
        errorStyle: TextStyle(
          fontSize: AppFontSize.size5.sp,
          color: AppColor.redColor,
          fontWeight: FontWeight.w400,
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: AppColor.blackColor.withValues(alpha: 0.25),
            width: 1.5,
          ),
          borderRadius: BorderRadius.circular(8.r),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: AppColor.primaryColor),
          borderRadius: BorderRadius.circular(8.r),
        ),
        border: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.blackColor,
          ),
          borderRadius: BorderRadius.circular(8.r),
        ),
      ),
    );
  }
}

class CustomDropDownModel {
  final String value;
  final String valueID;

  CustomDropDownModel(
    this.value,
    this.valueID,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomDropDownModel &&
          runtimeType == other.runtimeType &&
          value == other.value &&
          valueID == other.valueID;

  @override
  int get hashCode => value.hashCode ^ valueID.hashCode;
}
