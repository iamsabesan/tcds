import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import 'forward_arrow_widget.dart';

class ExamIndentTwoLineWidget extends StatefulWidget {
  final String title;
  final String totalStudent;
  final String price;
  final String indentStudent;
  final bool withForwardArrow;
  final void Function()? onTap;

  const ExamIndentTwoLineWidget({
    super.key,
    required this.title,
    this.onTap,
    required this.totalStudent,
    required this.price,
    required this.indentStudent,
    required this.withForwardArrow,
  });

  @override
  State<ExamIndentTwoLineWidget> createState() =>
      _ExamIndentTwoLineWidgetState();
}

class _ExamIndentTwoLineWidgetState extends State<ExamIndentTwoLineWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Left Column
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: widget.title,
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                    color: AppColor.primaryColor,
                  ),
                  const SizedBox(height: 4.0),
                  Row(
                    children: [
                      Expanded(
                        child: CustomText(
                          text: "Total Student: ${widget.totalStudent}",
                          fontSize: AppFontSize.size5,
                          fontWeight: FontWeight.w400,
                          color: AppColor.blackColor,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            // Right Column
            Expanded(
              flex: 4,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: widget.price,
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                    color: AppColor.orange,
                  ),
                  SizedBox(height: 5.h),
                  CustomText(
                    text: "Indent Student: ${widget.indentStudent}",
                    fontSize: AppFontSize.size5,
                    fontWeight: FontWeight.w400,
                    color: AppColor.black2Color,
                  ),
                ],
              ),
            ),
            SizedBox(
              width: 15.w,
            ),

            if (widget.withForwardArrow)
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 8.0),
                    child: ForwardArrowWidget(
                      onTap: widget.onTap,
                    ),
                  ),
                ],
              ),
          ],
        ),
        const SizedBox(
          height: 15,
        ),
        const Divider(
          thickness: 1.0,
          height: 0,
          color: AppColor.greyColor,
        ),
      ],
    );
  }
}
