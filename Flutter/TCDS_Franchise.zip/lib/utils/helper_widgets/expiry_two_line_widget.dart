import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';
import 'custom_text.dart';

class ExpiryTwoLineWidget extends StatefulWidget {
  final String title;
  final String duration;
  final int term;
  final double progress;
  // final void Function()? onTap;
  const ExpiryTwoLineWidget({
    super.key,
    required this.title,
    // this.onTap,
    required this.duration,
    required this.term,
    required this.progress,
  });

  @override
  State<ExpiryTwoLineWidget> createState() => _ExpiryTwoLineWidgetState();
}

class _ExpiryTwoLineWidgetState extends State<ExpiryTwoLineWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Left Column

            // Right Column
            Expanded(
              flex: 4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    alignment:
                        Alignment.center, // Align both children in the center
                    children: [
                      // Circular Progress Indicator inside a SizedBox to control its size (radius)
                      SizedBox(
                        width: 70.w, // This controls the width of the circle
                        height: 70.0, // This controls the height of the circle
                        child: CircularProgressIndicator(
                          value: widget.progress,
                          backgroundColor: AppColor.grey2,
                          strokeWidth:
                              8.0, // Set the stroke width of the progress indicator
                          valueColor: const AlwaysStoppedAnimation<Color>(
                              AppColor.secondaryColor), // Color of the progress
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          CustomText(
                            text:
                                widget.term < 0 ? "0" : widget.term.toString(),
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w500,
                            color: widget.term < 0
                                ? AppColor.redColor
                                : AppColor.titleColor,
                            textAlign: TextAlign.start,
                          ),
                          CustomText(
                            text: "days",
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w400,
                            color: AppColor.blackColor,
                          ),
                        ],
                      ),
                      // Positioned Text below the Circular Progress Indicator
                      // Text(
                      //   "${widget.term} days",
                      //   style: TextStyle(
                      //     fontSize: 10.sp,
                      //     fontWeight: FontWeight.bold,
                      //     color: Colors.black, // Text color
                      //   ),
                      // ),
                    ],
                  )

                  // Stack(
                  //   alignment: Alignment.center, // Align both children in the center
                  //   children: [
                  //     // Circular Progress Indicator
                  //     CircularProgressIndicator(
                  //       value:widget.progress,
                  //
                  //       strokeWidth: 4.0, // Set the stroke width
                  //       valueColor: AlwaysStoppedAnimation<Color>(AppColor.secondaryColor), // Color of the progress
                  //     ),
                  //     // Text in the center of the circular progress indicator
                  //     Text(
                  //      "${widget.term} days",
                  //       style: TextStyle(
                  //         fontSize: 10.0,
                  //         fontWeight: FontWeight.bold,
                  //         color: Colors.black, // Text color
                  //       ),
                  //     ),
                  //   ],
                  // ),
                ],
              ),
            ),

            Expanded(
              flex: 4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: widget.title,
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w500,
                    color: AppColor.primaryColor,
                  ),
                  const SizedBox(height: 7.0),
                  CustomText(
                    text: widget.duration,
                    fontSize: 13.sp,
                    fontWeight: FontWeight.w400,
                    color: AppColor.blackColor,
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
}
