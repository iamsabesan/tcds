import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import 'forward_arrow_widget.dart';

class FeesCollectionWidget extends StatefulWidget {
  final String text1;
  final String text2;
  final String text3;
  final String? amount;
  final String? text4;
  final Color? text3Color;
  final bool withDivider;
  final bool withForwardArrow;

  // final bool isSelectActive;
  final void Function()? onTap;

  const FeesCollectionWidget({
    super.key,
    this.onTap,
    required this.text1,
    required this.text2,
    required this.text3,
    this.amount,
    this.text4,
    this.text3Color,
    required this.withDivider,
    required this.withForwardArrow,
  });

  @override
  State<FeesCollectionWidget> createState() => _FeesCollectionWidgetState();
}

class _FeesCollectionWidgetState extends State<FeesCollectionWidget> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: AppColor.white2Color,
      overlayColor: const WidgetStatePropertyAll(AppColor.white2Color),
      onTap: widget.onTap,
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.transparent,
                child: ClipOval(
                  child: Image.asset(
                    "assets/profile_picture.png",
                    fit: BoxFit.cover,
                    height: 40,
                    width: 40,
                  ),
                ),
              ),
              Expanded(
                flex: 5,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: widget.text1,
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size4.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(
                      height: 3.w,
                    ),
                    CustomText(
                      text: widget.text2,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                      fontSize: AppFontSize.size5.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 8,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomText(
                      text: widget.text3,
                      color: widget.text3Color ?? AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                      fontSize: AppFontSize.size5.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(
                      height: 3.w,
                    ),
                    CustomText(
                      text: widget.text4 ?? "₹ ${widget.amount}",
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                      fontSize: AppFontSize.size5.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              if (widget.withForwardArrow)
                Expanded(
                  flex: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: ForwardArrowWidget(
                          onTap: widget.onTap,
                        ),
                      ),
                    ],
                  ),
                ),
              SizedBox(
                height: 5.w,
              ),
            ],
          ),
          const Divider(
            thickness: 1.0,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }
}
