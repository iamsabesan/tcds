/*


import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

class AccordionFooter extends StatefulWidget {
  final String totalAmount;
  final Widget expandedContent;

  AccordionFooter({
    required this.totalAmount,
    required this.expandedContent,
  });

  @override
  _AccordionFooterState createState() => _AccordionFooterState();
}

class _AccordionFooterState extends State<AccordionFooter> {
  bool isExpanded = false;

  void toggleExpanded() {
    setState(() {
      isExpanded = !isExpanded; // Toggle the expanded state
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          // Smooth transition
          curve: Curves.easeInOut,
          height: isExpanded ? 100.h : 0.h,
          // Adjust height dynamically
          padding: EdgeInsets.symmetric(horizontal: 8.w),
          decoration: BoxDecoration(
            // color: Colors.grey[200],
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(15.w),
            ),
          ),
          child: isExpanded
              ? SingleChildScrollView(
                  child: widget.expandedContent,
                )
              : null, // Only show content if expanded
        ),
        Container(
          color: AppColor.accordionColor,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CustomText(
                  text: "Total : ",
                  fontSize: AppFontSize.size4,
                  fontWeight: FontWeight.w500,
                  color: AppColor.blackColor,
                ),
                GestureDetector(
                  onTap: toggleExpanded, // Toggle expanded state
                  child: Row(
                    children: [
                      CustomText(
                        text: widget.totalAmount,
                        fontSize: AppFontSize.size4,
                        fontWeight: FontWeight.w500,
                        color: AppColor.secondaryColor,
                      ),
                      SizedBox(
                        width: 5.w,
                      ),
                      Container(
                        padding: EdgeInsets.all(0.1.w),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColor.secondaryColor,
                        ),
                        child: Icon(
                          isExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
*/

import 'package:flutter/material.dart';

class AccordionFooter extends StatefulWidget {
  final String totalAmount; // Total amount to display
  final Widget expandedContent; // Content of the expanded section

  const AccordionFooter({
    super.key,
    required this.totalAmount,
    required this.expandedContent,
  });

  @override
  State<AccordionFooter> createState() => _AccordionFooterState();
}

class _AccordionFooterState extends State<AccordionFooter> {
  bool isExpanded = false; // To track whether the accordion is expanded or not

  void toggleAccordion() {
    setState(() {
      isExpanded = !isExpanded; // Toggle the accordion state
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Expanded Content Section
        AnimatedCrossFade(
          alignment: Alignment.bottomCenter,
          duration: const Duration(milliseconds: 300),
          firstCurve: Curves.easeInQuint,
          secondCurve: Curves.easeOutQuint,
          crossFadeState:
              isExpanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          firstChild: const SizedBox.shrink(), // Collapsed state
          secondChild: widget.expandedContent,
          /*  Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            decoration: BoxDecoration(
              color: AppColor
                  .accordionColor, // Background color for expanded content
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(16)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildFeeRow('Admission Fees', 4500),
                _buildFeeRow('Course Fees', 15000),
                _buildFeeRow('Exam Fees', 500),
              ],
            ),
          ), */
        ),
        // Header Section with the total amount
        GestureDetector(
          onTap: toggleAccordion, // Toggle accordion on tap
          child: Container(
            padding:
                const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
            color: Colors.white, // Background color for the header
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Total :',
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    Text(
                      widget.totalAmount,
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.orange,
                      ),
                    ),
                    Icon(
                      isExpanded
                          ? Icons.keyboard_arrow_down
                          : Icons.keyboard_arrow_up,
                      color: Colors.grey,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
