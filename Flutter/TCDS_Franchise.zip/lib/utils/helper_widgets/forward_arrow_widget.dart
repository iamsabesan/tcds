import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';


class ForwardArrowWidget extends StatelessWidget {
  final void Function()? onTap;
  const ForwardArrowWidget({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      radius: 8.r,
      borderRadius: BorderRadius.all(Radius.circular(12.r)),
      onTap: onTap,
      child: Icon(
        Icons.arrow_forward_ios_rounded,
        color: AppColor.black2Color,
        size: 18.w,
      ),
    );
  }
}
