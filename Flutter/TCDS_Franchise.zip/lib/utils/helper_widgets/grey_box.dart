import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';

class GreyBox extends StatelessWidget {
  final Widget child;
  final double? height;
  final double? width;
  const GreyBox({super.key, required this.child, this.height, this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
          color: AppColor.grey3,
          border: Border.all(color: AppColor.shadowBorder, width: 0.5),
          borderRadius: BorderRadius.circular(8.r),
          boxShadow: const [
            BoxShadow(
              color: AppColor.shadowBorder,
              offset: Offset(0, 0),
              blurRadius: 0.2,
              spreadRadius: 0.2,
            )
          ]),
      child: child,
    );
  }
}
