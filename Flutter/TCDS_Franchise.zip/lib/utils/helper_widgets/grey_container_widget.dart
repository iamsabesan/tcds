import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../constants/colors.dart';

class GreyContainerWidget extends StatelessWidget {
  final Widget child;

  const GreyContainerWidget({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
          right: 8
              .w), // Adjust according to your screen size or use 8.w for responsive design
      decoration: BoxDecoration(
        color: AppColor.containerGrey,
        borderRadius: BorderRadius.circular(12.r),
        // Replace with your AppColor.grey2 if defined
        boxShadow: const [
          BoxShadow(
            color: AppColor.grey2, // Shadow color
            blurRadius: 4,
            spreadRadius: 1, // Spread radius
            offset: Offset(4, 5), // Shadow offset (X and Y direction)
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(10.w),
        child: child,
      ),
      // Replace with the child widget you want inside the container
    );
  }
}
