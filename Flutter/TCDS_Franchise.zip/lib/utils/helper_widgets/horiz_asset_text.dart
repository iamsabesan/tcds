import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

class HorizAssetText extends StatelessWidget {
  final String assetPath;
  final Color? assetColor;
  final String valueText;
  final double? assetScale;
  final double? valueFontSize;
  final Color? valueTextColor;
  final FontWeight? valueFontWeight;
  final MainAxisAlignment mainAxisAlignment;
  final CrossAxisAlignment crossAxisAlignment;

  const HorizAssetText(
      {super.key,
      required this.assetPath,
      required this.valueText,
      this.valueFontSize,
      this.valueTextColor,
      this.assetColor,
      this.assetScale,
      this.valueFontWeight,
      this.mainAxisAlignment = MainAxisAlignment.start,
      this.crossAxisAlignment = CrossAxisAlignment.center});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: mainAxisAlignment,
      crossAxisAlignment: crossAxisAlignment,
      children: [
        Image.asset(
          assetPath,
          scale: assetScale ?? 15.00,
          color: assetColor,
        ),
        SizedBox(
          width: 10.w,
        ),
        Flexible(
          child: CustomText(
            text: valueText,
            fontWeight: valueFontWeight ?? FontWeight.w600,
            fontSize: valueFontSize ?? AppFontSize.size3.sp,
            color: valueTextColor ?? AppColor.secondaryColor,
          ),
        )
      ],
    );
  }
}
