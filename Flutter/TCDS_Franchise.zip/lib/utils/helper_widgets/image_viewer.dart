/*
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';

class ImageViewerPage extends StatefulWidget {
  final Image child;
  final bool dark;
  const ImageViewerPage({super.key, required this.child, required this.dark});

  @override
  State<ImageViewerPage> createState() => _ImageViewerPageState();
}

class _ImageViewerPageState extends State<ImageViewerPage> {
  @override
  void initState() {
    var brightness = widget.dark ? Brightness.light : Brightness.dark;
    var color = widget.dark ? Colors.black12 : Colors.white70;

    // SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.top]);

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: color,
      statusBarColor: color,
      statusBarBrightness: brightness,
      statusBarIconBrightness: brightness,
      systemNavigationBarDividerColor: color,
      systemNavigationBarIconBrightness: brightness,
    ));
    super.initState();
  }

  @override
  void dispose() {
    // SystemChrome.setEnabledSystemUIOverlays(SystemUiOverlay.values);
    // SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    //     // Restore your settings here...
    //     ));
    SystemChrome.restoreSystemUIOverlays();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.dark ? Colors.black : Colors.white,
      body: PopScope(
        canPop: false,
        onPopInvoked: (didPop) {
          if (didPop) {
            return;
          }
          Get.back();
        },
        child: Stack(
          children: [
            AnimatedPositioned(
              // image section
              duration: const Duration(milliseconds: 333),
              curve: Curves.fastOutSlowIn,
              top: 0,
              bottom: 0,
              left: 0,
              right: 0,
              child: InteractiveViewer(
                panEnabled: true,
                minScale: 1,
                maxScale: 5.0,
                child: FittedBox(fit: BoxFit.contain, child: widget.child),
              ),
            ),
            // back arrow to close current route
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(left: 10, top: 10),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: MaterialButton(
                    padding: const EdgeInsets.all(15),
                    elevation: 0,
                    color: widget.dark ? Colors.black12 : Colors.white70,
                    highlightElevation: 0,
                    minWidth: double.minPositive,
                    height: double.minPositive,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(100),
                    ),
                    onPressed: () {
                      debugPrint("Back button pressed");
                      Get.back();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: widget.dark ? Colors.white : Colors.black,
                      size: 25,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
*/

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/utils/helper_functions/file_download_helper.dart';

class FullScreenImageViewer extends StatelessWidget {
  final String base64Image;
  final String fileName;
  final String mimeType;

  const FullScreenImageViewer({
    super.key,
    required this.base64Image,
    required this.fileName,
    required this.mimeType,
  });

  @override
  Widget build(BuildContext context) {
    final imageBytes = base64Decode(base64Image);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Image Viewer"),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () async {
              int sdkVersion = await FileDownloadHelper.getAndroidSdkVersion();
              if (sdkVersion >= 29) {
                bool result = await FileDownloadHelper.scopedDownload(
                    fileName, base64Image, mimeType);
                FileDownloadHelper.showToast(
                    result ? "Downloaded Successfully" : "Failed to Download",
                    result ? AppColor.green : AppColor.redColor);
              } else {
                // Handle download path for legacy storage if needed
                debugPrint("Older Android version detected.");
                bool result = await FileDownloadHelper.directDownload(
                   base64Image, fileName);
                FileDownloadHelper.showToast(
                    result ? "Downloaded Successfully" : "Failed to Download",
                    result ? AppColor.green : AppColor.redColor);
              }
            },
          ),
        ],
      ),
      body: Center(
        child: Image.memory(
          imageBytes,
          fit: BoxFit.values[5],
          errorBuilder: (context, error, stackTrace) {
            return const Text("Failed to load image");
          },
        ),
      ),
    );
  }
}
