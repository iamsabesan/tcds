import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/asset_paths.dart';

import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';
import 'custom_text.dart';

class InButton extends StatelessWidget {
  final bool withArrow;
  final String? text;
  final double? textSize;
  final Color? textColor;
  final FontWeight? textWeight;
  final Color? color;
  final BorderRadius? borderRadius;
  final void Function()? onTap;
  final double? verticalPadding;

  const InButton(
      {super.key,
      this.withArrow = false,
      this.text,
      this.borderRadius,
      this.color,
      this.onTap,
      this.verticalPadding,
      this.textSize,
      this.textColor,
      this.textWeight});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: verticalPadding ?? 10.w, horizontal: 15.w),
        decoration: BoxDecoration(
            color: color ?? AppColor.primaryColor,
            borderRadius: borderRadius ?? BorderRadius.circular(8.r),
            border: Border.all(color: color ?? AppColor.primaryColor)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomText(
              text: text ?? 'Next',
              color: textColor ?? AppColor.whiteColor,
              fontSize: textSize ?? AppFontSize.size5.sp,
              fontWeight: textWeight ?? FontWeight.w500,
            ),
            if (withArrow)
              SizedBox(
                width: 15.w,
              ),
            if (withArrow)
              Image.asset(
                AssetPath.rightArrow,
                scale: 32.0,
                color: AppColor.whiteColor,
              ),
          ],
        ),
      ),
    );
  }
}
