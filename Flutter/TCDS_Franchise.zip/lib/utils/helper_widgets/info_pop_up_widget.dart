import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/in_button.dart';


class InfoPopUpWidget extends StatelessWidget {
  final String? title;
  final Widget? content;
  final void Function()? onTap;
  final bool withDefaultButton;

  const InfoPopUpWidget({
    super.key,
    required this.title,
    required this.content,
    this.onTap,
    this.withDefaultButton = true,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      contentPadding: EdgeInsets.zero,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(8.0)),
      ),
      titlePadding: EdgeInsets.zero,
      title: Container(
        height: 40.h,
        decoration: BoxDecoration(
          color: AppColor.primaryColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(8.r),
            topRight: Radius.circular(8.r),
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(8.h),
          child: Text(
            title!,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: AppFontSize.size2.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white),
          ),
        ),
      ),
      elevation: 10,
      content: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            SizedBox(
              height: 20.h,
            ),
            Image.asset(
              AssetPath.informationIcon,
              scale: 8.0,
            ),
            SizedBox(
              height: 13.h,
            ),
            content ?? const SizedBox(),
            if (withDefaultButton)
              SizedBox(
                height: 18.h,
              ),
            if (withDefaultButton)
              IntrinsicWidth(
                child: InButton(
                  text: 'OK',
                  onTap: onTap ??
                      () {
                        Get.back();
                      },
                ),
              )
          ],
        ),
      ),
    );
  }
}
