import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';

class MultiSelectDropDown extends StatefulWidget {
  final List<MultiSelectDropDownModel> dropdownValues;
  final String labelText;
  final String? errorText;
  final TextEditingController controller;
  final TextEditingController valueController;
  final TextStyle? labelStyle;
  final String? Function(String?)? validator;
  const MultiSelectDropDown(
      {super.key,
      required this.dropdownValues,
      required this.labelText,
      this.errorText,
      required this.controller,
      this.labelStyle,
      required this.valueController,
      this.validator});

  @override
  State<MultiSelectDropDown> createState() => _MultiSelectDropDownState();
}

class _MultiSelectDropDownState extends State<MultiSelectDropDown> {
  bool isListVisible = false;
  Set<String> addedValues = {};
  Set<String> addedIDs = {};

  @override
  void initState() {
    widget.valueController.clear();
    widget.controller.clear();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        CustomTextField(
          labelText: widget.labelText,
          controller: widget.controller,
          readOnly: true,
          onTap: () => setState(() => isListVisible = !isListVisible),
          validator: (val) {
            if (val!.isEmpty) {
              return 'Required';
            } else {
              return null;
            }
          },
          suffixIcon: isListVisible
              ? const Icon(
                  Icons.keyboard_arrow_up_outlined,
                  color: AppColor.blackColor,
                )
              : const Icon(
                  Icons.keyboard_arrow_down_outlined,
                  color: AppColor.blackColor,
                ),
        ),
        SizedBox(
          height: 10.w,
        ),
        if (isListVisible)
          Container(
            constraints: BoxConstraints(maxHeight: height * 0.4),
            padding: EdgeInsets.only(bottom: 40.w),
            child: ListView.builder(
              shrinkWrap: true,
              scrollDirection: Axis.vertical,
              itemCount: widget.dropdownValues.length,
              itemBuilder: (context, index) => InkWell(
                onTap: () {
                  // Add new selected values
                  //if already selected remove it
                  if (addedIDs.contains(
                      widget.dropdownValues[index].valueID.toString())) {
                    addedValues
                        .remove(widget.dropdownValues[index].value.toString());
                    addedIDs.remove(
                        widget.dropdownValues[index].valueID.toString());
                    widget.controller.text = addedValues.join(',');
                    widget.valueController.text = addedIDs.join(',');
                  } else {
                    addedValues
                        .add(widget.dropdownValues[index].value.toString());
                    addedIDs
                        .add(widget.dropdownValues[index].valueID.toString());
                    widget.controller.text = addedValues.join(',');
                    widget.valueController.text = addedIDs.join(',');
                  }
                  // Allow Only New Values
                  // if (widget.valueController.text.contains(widget
                  //         .dropdownValues[index].consignmentInwardID
                  //         .toString()) ==
                  //     false) {
                  //   // Update Controller text
                  //   widget.controller.text +=
                  //       widget.dropdownValues[index].consignmentCode +
                  //           ','.toString();
                  //   // Add Value to Value Controller
                  //   widget.valueController.text += widget
                  //           .dropdownValues[index].consignmentInwardID
                  //           .toString() +
                  //       ','.toString();
                  // }
                  setState(() {});
                  debugPrint(widget.valueController.text);
                  debugPrint(widget.controller.text);
                },
                child: Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 15.w, vertical: 15.w),
                  color: index % 2 == 0
                      ? AppColor.whiteColor
                      : AppColor.black2Color.withValues(alpha: 0.1),
                  child: Row(
                    children: [
                      if (addedIDs.contains(
                          widget.dropdownValues[index].valueID.toString()))
                        const Icon(
                          Icons.check_circle,
                          color: AppColor.primaryColor,
                        ),
                      SizedBox(
                        width: 2.5.w,
                      ),
                      CustomText(
                        text: widget.dropdownValues[index].value,
                        color: AppColor.blackColor,
                        fontSize: AppFontSize.size5.sp,
                        fontWeight: FontWeight.w500,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )
      ],
    );
  }
}

class MultiSelectDropDownModel {
  final String value;
  final String valueID;

  MultiSelectDropDownModel(this.value, this.valueID);
}
