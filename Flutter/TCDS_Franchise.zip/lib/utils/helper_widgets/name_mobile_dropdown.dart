import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/get_instance.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/fees_collection/controller/fees_collection_controller.dart';
import 'package:tcds/user_interface/fees_collection/view/fees_collection_list_screen.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'package:tcds/utils/helper_widgets/custom_textfield.dart';

class NameMobileDropDown extends StatefulWidget {
  final List<NameMobileDropDownModel> dropdownValues;
  final String labelText;
  final String? errorText;
  final TextEditingController controller;
  final TextEditingController valueController;
  final TextStyle? labelStyle;

  final String? Function(String?)? validator;
  final void Function()? onParentTap;

  const NameMobileDropDown({
    super.key,
    required this.dropdownValues,
    required this.labelText,
    this.errorText,
    required this.controller,
    this.labelStyle,
    required this.valueController,
    this.validator,
    this.onParentTap,
  });

  @override
  State<NameMobileDropDown> createState() => _NameMobileDropDownState();
}

class _NameMobileDropDownState extends State<NameMobileDropDown> {
  FeesCollectionController feesCollectionController =
      Get.find<FeesCollectionController>();

  bool isListVisible = false;
  String selectedValue = '';
  String selectedId = '';
  String selectedBatchMappingId = '';

  List<NameMobileDropDownModel> filteredValues = [];

  final FocusNode _focus = FocusNode();

  @override
  void initState() {
    widget.valueController.clear();
    filteredValues = widget.dropdownValues;
    super.initState();
  }

  void filterDropdown(String query) {
    setState(() {
      filteredValues = widget.dropdownValues
          .where((item) =>
              item.name.toLowerCase().contains(query.toLowerCase()) ||
              item.mobile.contains(query))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.sizeOf(context).height;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => setState(() => isListVisible = !isListVisible),
          child: Column(
            children: [
              CustomTextField(
                labelText: 'Name/Mobile',
                focusNode: _focus,
                readOnly: false,
                enabled: true,
                controller: widget.controller,
                onTap: () => setState(() => isListVisible = true),
                onChanged: (value) {
                  filterDropdown(value); // Filter the list based on input
                  setState(() => isListVisible = true);
                },
                hintStyle: TextStyle(
                  fontSize: AppFontSize.size4.sp,
                  color: AppColor.black2Color,
                  fontWeight: FontWeight.w400,
                ),
                validator: (val) {
                  if (val!.isEmpty) {
                    return 'Required';
                  } else {
                    return null;
                  }
                },
                suffixIcon: InkWell(
                  onTap: () => setState(() => isListVisible = !isListVisible),
                  child: Icon(
                    isListVisible
                        ? Icons.keyboard_arrow_up_outlined
                        : Icons.keyboard_arrow_down_outlined,
                    color: AppColor.blackColor,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10.h),
        if (isListVisible)
          Container(
            clipBehavior: Clip.hardEdge,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12.r),
                border: Border.all(color: AppColor.grey)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
                  color: Colors.grey.withValues(alpha: 0.2),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Student ID',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                            color: Colors.black,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Name',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                            color: Colors.black,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Mobile',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14.sp,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (filteredValues.isEmpty)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.all(10),
                      child: CustomText(
                        text: "No Data",
                      ),
                    ),
                  ),
                if (filteredValues.isNotEmpty)
                  Container(
                    clipBehavior: Clip.hardEdge,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(12.r),
                          bottomRight: Radius.circular(12.r)),
                    ),
                    // margin: EdgeInsets.symmetric(vertical: 10),
                    constraints: BoxConstraints(maxHeight: height * 0.2),
                    child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      // itemCount: widget.dropdownValues.length,
                      itemCount: filteredValues.length,
                      itemBuilder: (context, index) => InkWell(
                        onTap: () async {
                          _focus.unfocus();
                          selectedValue = filteredValues[index].name;
                          selectedId = filteredValues[index].studentID;
                          selectedBatchMappingId =
                              filteredValues[index].batchMappingId!;
                          widget.controller.text = selectedValue;
                          widget.valueController.text = selectedId;

                          PleaseWaitLoader.openDialog();
                          await feesCollectionController
                              .getFeesBalanceListWithMappingId(
                                  batchMappingId: selectedBatchMappingId);
                          PleaseWaitLoader.closeDialog();
                          setState(() => isListVisible = false);

                          debugPrint('Name: ${widget.controller.text}');
                          debugPrint(
                              'Student ID: ${widget.valueController.text}');
                          if (widget.onParentTap != null) {
                            widget.onParentTap!();
                          } else {
                            Get.to(() => FeesCollectionListScreen(
                                  filteredStudentId: selectedId,
                                ));
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 15.w, vertical: 15.h),
                          color: index % 2 == 0
                              ? Colors.white
                              : Colors.grey.withAlpha(80),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  filteredValues[index].studentID,
                                  // widget.dropdownValues[index].studentID,
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  filteredValues[index].name,
                                  // widget.dropdownValues[index].name,
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  filteredValues[index].mobile,
                                  // widget.dropdownValues[index].mobile,
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          )
      ],
    );
  }
}

class NameMobileDropDownModel {
  final String name;
  final String mobile;
  final String studentID;
  final String? batchMappingId;

  NameMobileDropDownModel(
    this.name,
    this.mobile,
    this.studentID,
    this.batchMappingId,
  );
}
