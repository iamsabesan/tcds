import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/asset_paths.dart';

import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';
import 'custom_text.dart';

class OutButton extends StatelessWidget {
  final bool withArrow;
  final String? text;
  final Color? color;
  final Color? bgColor;
  final void Function()? onTap;
  final double? verticalPadding;

  const OutButton({
    super.key,
    this.withArrow = false,
    this.text,
    this.color,
    this.onTap,
    this.bgColor,
    this.verticalPadding,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
            vertical: verticalPadding ?? 10.w, horizontal: 15.w),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(8.r),
          border:
              Border.all(color: color ?? AppColor.secondaryColor, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (withArrow)
              Image.asset(
                AssetPath.leftArrow,
                scale: 25.0,
                color: AppColor.secondaryColor,
              ),
            if (withArrow)
              SizedBox(
                width: 10.w,
              ),
            CustomText(
              text: text ?? 'Back',
              color: color ?? AppColor.secondaryColor,
              fontSize: AppFontSize.size5.sp,
              fontWeight: FontWeight.w500,
            )
          ],
        ),
      ),
    );
  }
}
