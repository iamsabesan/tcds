import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';


class PairText extends StatelessWidget {
  final String keyText;
  final Color? keyColor;
  final FontWeight? keyWeight;
  final double? keySize;
  final String? separator;
  final String valueText;
  final Color? valueColor;
  final FontWeight? valueWeight;
  final double? valueSize;
  final TextOverflow? overflow;
  final int? maxLines;
  final TextAlign textAlign;
  const PairText(
      {super.key,
      required this.keyText,
      this.keyColor,
      this.keyWeight,
      this.keySize,
      this.separator,
      required this.valueText,
      this.valueColor,
      this.valueWeight,
      this.valueSize,
      this.overflow,
      this.maxLines,
      this.textAlign = TextAlign.start});

  @override
  Widget build(BuildContext context) {
    return RichText(
        maxLines: maxLines,
        overflow: overflow ?? TextOverflow.ellipsis,
        textAlign: textAlign,
        text: TextSpan(children: [
          TextSpan(
            text: keyText,
            style: TextStyle(
              color: keyColor ?? AppColor.blackColor,
              fontWeight: keyWeight ?? FontWeight.w500,
              fontSize: keySize ?? AppFontSize.size3.sp,
            ),
          ),
          TextSpan(
              text: separator ?? ' : ',
              style: TextStyle(
                  color: keyColor ?? AppColor.black2Color,
                  fontWeight: keyWeight ?? FontWeight.w400,
                  fontSize: keySize ?? AppFontSize.size4.sp)),
          TextSpan(
              text: valueText,
              style: TextStyle(
                  color: valueColor ?? AppColor.black2Color,
                  fontWeight: valueWeight ?? FontWeight.w400,
                  fontSize: valueSize ?? AppFontSize.size3.sp))
        ]));
  }
}
