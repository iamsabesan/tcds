/*
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';
import 'package:tcds/utils/helper_widgets/pair_text.dart';

import 'custom_text.dart';

class PaymentStatusWidget extends StatefulWidget {
  final String regDate;
  final String notes;
  final String status;
  final bool withDivider;
  final bool withForwardArrow;

  // final bool isSelectActive;
  final void Function()? onTap;

  const PaymentStatusWidget({
    super.key,

    // this.isSelectActive = false,
    this.onTap,
    required this.withDivider,
    required this.withForwardArrow,
    required this.regDate,
    required this.notes,
    required this.status,
  });

  @override
  State<PaymentStatusWidget> createState() => _PaymentStatusWidgetState();
}

// Container Tile with selection

class _PaymentStatusWidgetState extends State<PaymentStatusWidget> {
  // late bool isSelectActive;

  @override
  void initState() {
    super.initState();
    // isSelectActive = widget.isSelectActive;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: AppColor.white2Color,
      overlayColor: WidgetStatePropertyAll(AppColor.white2Color),
      onTap: widget.onTap,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Column(
                children: [
                  Expanded(
                    flex: 4,
                    child: CustomText(
                      text: widget.regDate,
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500,
                      fontSize: AppFontSize.size4.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    flex: 4,
                    child: CustomText(
                      text: widget.status,
                      textAlign: TextAlign.left,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w400,
                      maxLines: 2,
                      fontSize: AppFontSize.size5.sp,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              if (widget.withForwardArrow)
                const Expanded(
                  flex: 2,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 8.0),
                        child: ForwardArrowWidget(
                            // onTap: widget.onTap,
                            ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          SizedBox(
            height: 4.w,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                flex: 8,
                child: CustomText(
                  text: widget.notes,
                  color: AppColor.blackColor,
                  fontWeight: FontWeight.w400,
                  maxLines: 2,
                  fontSize: AppFontSize.size5.sp,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5.w,
          ),
          Divider(
            thickness: 1.0,
            color: AppColor.greyColor,
          ),
        ],
      ),
    );
  }
}
*/

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';
import 'custom_text.dart';

class PaymentStatusWidget extends StatelessWidget {
  final String regDate;
  final String notes;
  final String status;
  final bool withDivider;
  final bool withForwardArrow;
  final void Function()? onTap;

  const PaymentStatusWidget({
    super.key,
    this.onTap,
    required this.withDivider,
    required this.withForwardArrow,
    required this.regDate,
    required this.notes,
    required this.status,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: AppColor.white2Color,
      overlayColor: WidgetStateProperty.all(AppColor.white2Color),
      onTap: () {
        // AppBottomSheets.payModeHistory(context: context);
      },
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 12.w),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Registration Date
                Expanded(
                  flex: 4,
                  child: CustomText(
                    text: regDate,
                    color: AppColor.primaryColor,
                    fontWeight: FontWeight.w600,
                    fontSize: AppFontSize.size4.sp,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                // Status
                Expanded(
                  flex: 4,
                  child: CustomText(
                    text: status,
                    textAlign: TextAlign.right,
                    color: AppColor.orange,
                    fontWeight: FontWeight.w500,
                    maxLines: 2,
                    fontSize: AppFontSize.size5.sp,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                // Forward Arrow (optional)
                if (withForwardArrow)
                  const Padding(
                    padding: EdgeInsets.only(left: 8.0),
                    child: ForwardArrowWidget(),
                  ),
              ],
            ),
            SizedBox(height: 5.h),
            // Notes
            Row(
              children: [
                Expanded(
                  child: CustomText(
                    text: notes,
                    color: AppColor.blackColor,
                    fontWeight: FontWeight.w400,
                    maxLines: 2,
                    fontSize: AppFontSize.size5.sp,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            SizedBox(height: 8.h),
            // Divider (optional)
            if (withDivider)
              const Divider(
                thickness: 1.0,
                color: AppColor.greyColor,
              ),
          ],
        ),
      ),
    );
  }
}
