/*
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

class PaymodeBottomSheet {
  static template({
    required BuildContext context,
    required Widget content,
    bool withDivider = true,
    bool? isDismissible,
    bool withDefaultPadding = true,
  }) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        enableDrag: true,
        isDismissible: isDismissible ?? true,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Container(
                width: double.infinity,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                decoration: BoxDecoration(
                  color: AppColor.whiteColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.elliptical(40.w, 40.w),
                    topRight: Radius.elliptical(40.w, 40.w),
                  ),
                ),
                // Contents
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 5.w,
                      width: 80.w,
                      margin: EdgeInsets.symmetric(vertical: 5.w),
                      decoration: BoxDecoration(color: AppColor.greyColor, borderRadius: BorderRadius.circular(5.r)),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 5.w, horizontal: 20.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text: 'Paymode',
                            fontSize: AppFontSize.size3,
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.close,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                    ),
                    Divider(
                      color: AppColor.greyColor,
                    ),
                    // Contents section
                    Padding(
                      padding: withDefaultPadding ? EdgeInsets.all(20.w) : const EdgeInsets.all(0),
                      child: content,
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  static payModeHistory({
    required BuildContext context,
  }) {



    Widget _buildPaymodeRow(String mode, String date, String amount) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  mode,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Text(
                  date,
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
            Text(
              amount,
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      );
    }

    Widget _buildPaymodeRowWithImage(
        BuildContext context, String mode, String date, String amount, String imagePath) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  mode,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                ),
                Text(
                  date,
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
            Row(
              children: [
                IconButton(
                  icon: Icon(Icons.image, color: Colors.blue),
                  onPressed: () {
                    // _showImageViewer(context, imagePath);
                  },
                ),
                Text(
                  amount,
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
          ],
        ),
      );
    }


    return template(
        context: context,
        content: Card(
          color: AppColor.grey3,
          margin: EdgeInsets.all(5.w),
          child: Column(
            children: [
              _buildPaymodeRow('Cash', '02/02/2024', '₹100'),
              _buildPaymodeRow('Bank Transfer', '02/02/2024', '₹5,250'),
              _buildPaymodeRowWithImage(
                  context, 'UPI', '02/02/2024', '₹100', 'assets/dummy_image.png'),
              _buildPaymodeRowWithImage(
                  context, 'Bank Remittance', '02/02/2024', '₹700', 'assets/dummy_image.png'),
              Divider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Amount Paid:',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '₹6,750',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
          ),
        ));
  }
}
*/

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/fees_collection/controller/fees_collection_controller.dart';
import 'package:tcds/user_interface/fees_collection/model/document_download.dart';
import 'package:tcds/user_interface/fees_collection/model/student_payment_history_response_model.dart';
import 'package:tcds/utils/helper_functions/file_download_helper.dart';
import 'package:tcds/utils/helper_functions/please_wait_loader.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';
import 'image_viewer.dart';

class PaymodeBottomSheet {
  static template({
    required BuildContext context,
    required Widget content,
    bool withDivider = true,
    bool? isDismissible,
    bool withDefaultPadding = true,
  }) {
    return showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        enableDrag: true,
        isDismissible: isDismissible ?? true,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.only(
                  bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Container(
                width: double.infinity,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                decoration: BoxDecoration(
                  color: AppColor.whiteColor,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.elliptical(40.w, 40.w),
                    topRight: Radius.elliptical(40.w, 40.w),
                  ),
                ),
                // Contents
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 5.w,
                      width: 80.w,
                      margin: EdgeInsets.symmetric(vertical: 5.w),
                      decoration: BoxDecoration(
                          color: AppColor.greyColor,
                          borderRadius: BorderRadius.circular(5.r)),
                    ),
                    Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 5.w, horizontal: 20.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CustomText(
                            text: 'Paymode',
                            fontSize: AppFontSize.size3,
                            fontWeight: FontWeight.w500,
                            color: AppColor.primaryColor,
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.close,
                            ),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),
                    ),
                    const Divider(
                      color: AppColor.greyColor,
                    ),
                    // Contents section
                    Padding(
                      padding: withDefaultPadding
                          ? EdgeInsets.all(20.w)
                          : const EdgeInsets.all(0),
                      child: content,
                    ),
                  ],
                ),
              ),
            ),
          );
        });
  }

  static payModeHistory({
    required BuildContext context,
    required List<Paymode> paymentDetails,
    required List<DocumentDownload> documentDownload,
    required NumberFormat currencyFormat,
  }) {
    FeesCollectionController feesCollectionController =
        Get.find<FeesCollectionController>();

    Widget paymodeRow(String mode, String date, String amount) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  text: mode,
                  fontSize: AppFontSize.size4,
                  fontWeight: FontWeight.w500,
                ),
                CustomText(
                  text: date,
                  fontSize: AppFontSize.size4,
                  fontWeight: FontWeight.w500,
                ),
              ],
            ),
            CustomText(
              text: amount,
              fontSize: AppFontSize.size4,
              fontWeight: FontWeight.w500,
            ),
          ],
        ),
      );
    }

    Widget paymodeRowWithImage(
      BuildContext context,
      String mode,
      String date,
      String amount,
      String summary,
      String documentId,
    ) {
      return Padding(
        padding: EdgeInsets.symmetric(vertical: 5.w),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              flex: 3,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: CustomText(
                          text: mode,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          fontSize: AppFontSize.size4,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      SizedBox(
                        width: 5.w,
                      ),
                      /*   if(documentId != "00000000-0000-0000-0000-000000000000")
                      GestureDetector(
                        onTap: () async {
                          PleaseWaitLoader.openDialog();
                          // Download document API
                          bool isDownloaded = await feesCollectionController.documentDownload(
                            documentID: feesCollectionController.latestDownloadedDocument[0].documentId.toString(),
                          );
                          if (!isDownloaded || feesCollectionController.latestDownloadedDocument.isEmpty) {
                            FileDownloadHelperWidget.showToast("Failed to Download", AppColor.redColor);
                            PleaseWaitLoader.closeDialog();
                            return;
                          }
                          String base64Image = feesCollectionController.latestDownloadedDocument[0].profileBase64;
                          String fileName = feesCollectionController.latestDownloadedDocument[0].fileName;
                          String mimeType = feesCollectionController.latestDownloadedDocument[0].mimeType;
                          if (fileName.isEmpty || base64Image.isEmpty) {
                            FileDownloadHelperWidget.showToast("Something went wrong", AppColor.redColor);
                            PleaseWaitLoader.closeDialog();
                            return;
                          }
                          int sdkVersion = await AndroidSdkHelper.getAndroidSdkVersion();
                          if (sdkVersion >= 29) {
                            bool result = await FileDownloadHelperWidget.downloadAndSaveFile(fileName, base64Image, mimeType);
                            FileDownloadHelperWidget.showToast(
                                result ? "Downloaded Successfully" : "Failed to Download", result ? AppColor.green : AppColor.redColor);
                          } else {
                            // Handle download path for legacy storage if needed
                            debugPrint("Older Android version detected.");
                            bool result = await FileDownloadHelperWidget.saveFileToDownload(base64Decode(base64Image), fileName);
                            FileDownloadHelperWidget.showToast(
                                result ? "Downloaded Successfully" : "Failed to Download", result ? AppColor.green : AppColor.redColor);
                          }
                          PleaseWaitLoader.closeDialog();

                          Get.to(
                                () => FullScreenImageViewer(
                              base64Image: base64Image,
                              fileName: fileName,
                              mimeType: mimeType,
                            ),
                          );
                        },
                        child: Image.asset(
                          "assets/image-search 2.png",
                          scale: 25.0,
                        ),
                      ),*/

                      if (documentId != "00000000-0000-0000-0000-000000000000")
                        GestureDetector(
                          onTap: () async {
                            PleaseWaitLoader.openDialog();

                            // Download document API
                            bool isDownloaded =
                                await feesCollectionController.documentDownload(
                              documentID: documentId,
                            );

                            PleaseWaitLoader.closeDialog();

                            if (!isDownloaded ||
                                feesCollectionController
                                    .latestDownloadedDocument.isEmpty) {
                              FileDownloadHelper.showToast(
                                  "Failed to Download", AppColor.redColor);
                              return;
                            }
                            var document = feesCollectionController
                                .latestDownloadedDocument.first;
                            String base64Image = document.profileBase64;
                            String fileName = document.fileName;
                            String mimeType = document.mimeType;

                            if (fileName.isEmpty || base64Image.isEmpty) {
                              FileDownloadHelper.showToast(
                                  "Something went wrong", AppColor.redColor);
                              return;
                            }

                            /*  int sdkVersion = await AndroidSdkHelper.getAndroidSdkVersion();

                            bool downloadSuccess;
                            if (sdkVersion >= 29) {
                              downloadSuccess = await FileDownloadHelperWidget.downloadAndSaveFile(fileName, base64Image, mimeType);
                            } else {
                              debugPrint("Older Android version detected.");
                              downloadSuccess = await FileDownloadHelperWidget.saveFileToDownload(base64Decode(base64Image), fileName);
                            }

                            FileDownloadHelperWidget.showToast(
                              downloadSuccess ? "Downloaded Successfully" : "Failed to Download",
                              downloadSuccess ? AppColor.green : AppColor.redColor,
                            );*/

                            // Navigate to full-screen image viewer
                            Get.to(
                              () => FullScreenImageViewer(
                                base64Image: base64Image,
                                fileName: fileName,
                                mimeType: mimeType,
                              ),
                            );
                          },
                          child: Image.asset(
                            "assets/image-search 2.png",
                            scale: 25.0,
                          ),
                        ),
                    ],
                  ),
                  CustomText(
                    text: date,
                    color: AppColor.black2Color,
                    fontWeight: FontWeight.w400,
                    fontSize: AppFontSize.size4,
                  )
                ],
              ),
            ),
            SizedBox(
              width: 40.w,
            ),
            Expanded(
              flex: 4,
              child: Column(
                children: [
                  CustomText(
                    text: summary,
                    // Bank Name
                    color: AppColor.black2Color,
                    fontWeight: FontWeight.w500,
                    fontSize: AppFontSize.size4,
                    maxLines: 3,
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  CustomText(
                    text: amount,
                    fontSize: AppFontSize.size4,
                    fontWeight: FontWeight.w500,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return template(
        context: context,
        content: Card(
          color: AppColor.grey3,
          margin: EdgeInsets.all(2.w),
          child: Padding(
            padding: EdgeInsets.all(10.w),
            child: Column(
              children: [
                for (var detail in paymentDetails)
                  (detail.payMode.toLowerCase().removeAllWhitespace == 'upi' ||
                          detail.payMode.toLowerCase().removeAllWhitespace ==
                              'bankremittance')
                      ? paymodeRowWithImage(
                          context,
                          detail.payMode,
                          detail.transactionDate,
                          currencyFormat.format(detail.amount),
                          detail.summary,
                          detail.documentId,
                        )
                      : paymodeRow(
                          detail.payMode,
                          detail.transactionDate,
                          currencyFormat.format(detail.amount),
                        ),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      text: 'Amount Paid:',
                      color: AppColor.primaryColor,
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.bold,
                    ),
                    CustomText(
                      text: currencyFormat.format(paymentDetails.fold<int>(
                        0,
                        (sum, item) =>
                            sum + ((item.amount as num?)?.toInt() ?? 0),
                      )),
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w500,
                      color: AppColor.green,
                    ),
                  ],
                )
              ],
            ),
          ),
        ));
  }

  /*  // Utility to parse summary and extract Bank Name and Transaction ID
  static List<String> _parseSummary(String summary) {
    RegExp regex = RegExp(r'^(.*?)(?:\s+#([A-Za-z0-9-]+))?(?:\s+Dt\..*)?$');
    final match = regex.firstMatch(summary);
    if (match != null) {
      final bankName = match.group(1)?.trim() ?? '';
      final transactionId = match.group(2)?.trim() ?? '';
      return [bankName, transactionId]
          .where((element) => element.isNotEmpty)
          .toList();
    }
    return [];
  } */

  /* static _showImageViewer(BuildContext context, String imagePath) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(imagePath), // Replace with the actual image logic.
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                // Add download functionality here
              },
              icon: const Icon(Icons.download),
              label: const Text('Download'),
            ),
          ],
        ),
      ),
    );
  } */
}
