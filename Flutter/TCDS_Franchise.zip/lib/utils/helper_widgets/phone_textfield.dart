import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/user_interface/registration/controller/registration_controller.dart';
import 'package:tcds/user_interface/registration/model/phone_code_response_model.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

import '../../constants/asset_paths.dart';
import '../../constants/colors.dart';

// ignore: must_be_immutable
class PhoneTextField extends StatefulWidget {
  final String labelText;
  final String? hintText;
  // String? errorText;
  final bool withLabelText;
  final bool? filled;
  final TextEditingController controller;
  final TextEditingController mobileCodecontroller;
  final bool obscureText;
  final bool withSuffixIcon;
  final String? Function(String?)? validator;
  final double? height;
  final bool autofocus;
  final void Function(String)? onFieldSubmitted;
  final double? assetScale;
  final TextStyle? hintStyle;
  final Color? fillColor;
  final String? errorText;
  final void Function(String?)? parentOnChanged;
  final bool withValidator;
  final void Function(String)? onChanged;
  final bool? enabled;
  // final String labelText;
  // final String hintText;
  // final String assetPath;
  // final bool withPrefixAsset;
  //
  // // String? errorText;
  // final bool withLabelText;
  // final bool? filled;
  // final TextEditingController controller;
  // final TextEditingController mobileCodecontroller;
  // final bool obscureText;
  // final bool withSuffixIcon;
  // final String? Function(String?)? validator;
  // final double? height;
  // final bool autofocus;
  // final void Function(String)? onFieldSubmitted;
  // final double? assetScale;
  // final TextStyle? hintStyle;
  // final Color? fillColor;
  // final String? errorText;
  // final void Function(String?)? parentOnChanged;
  // final bool withValidator;
  // final void Function(String)? onChanged;

  const PhoneTextField({
    super.key,
    this.hintText,
    required this.controller,
    this.validator,
    // this.errorText,
    this.withSuffixIcon = false,
    this.obscureText = false,
    this.height,
    this.autofocus = false,
    this.onFieldSubmitted,
    this.assetScale,
    required this.mobileCodecontroller,
    this.withLabelText = false,
    this.filled,
    this.hintStyle,
    this.fillColor,
    this.errorText,
    this.parentOnChanged,
    this.withValidator = true,
    required this.labelText,
    this.onChanged,
    this.enabled = true,

    // super.key,
    // required this.hintText,
    // required this.assetPath,
    // required this.controller,
    // this.validator,
    // // this.errorText,
    // this.withSuffixIcon = false,
    // this.obscureText = false,
    // this.height,
    // this.autofocus = false,
    // this.onFieldSubmitted,
    // this.assetScale,
    // required this.mobileCodecontroller,
    // this.withLabelText = false,
    // this.filled,
    // this.hintStyle,
    // this.fillColor,
    // this.withPrefixAsset = false,
    // this.errorText,
    // this.parentOnChanged,
    // this.withValidator = true,
    // required this.labelText,
    // this.onChanged,
  });

  @override
  State<PhoneTextField> createState() => _PhoneTextFieldState();
}

class _PhoneTextFieldState extends State<PhoneTextField> {
  RegistrationController registrationController =
      Get.put(RegistrationController());

  late bool obscureText;
  late FocusNode _focusNode;

  // Drop down value holder
  String? dropdownValue;

  // Default Length
  int phoneNumberLength = 10;
  String? errorText;

  @override
  void initState() {
    obscureText = widget.obscureText;
    _focusNode = FocusNode();
    _focusNode.addListener(_onFocusChange);
    if (widget.mobileCodecontroller.text.isNotEmpty) {
      dropdownValue = widget.mobileCodecontroller.text;
      try {
        PhoneCodeList codeData =
            registrationController.phoneCodesData.firstWhere(
          (element) {
            return element.phoneCode == dropdownValue;
          },
        );
        phoneNumberLength = codeData.phoneNumberLength;
        widget.mobileCodecontroller.text = codeData.phoneCode;
      } catch (e) {
        debugPrint('Phone code not found: $dropdownValue');
      }
    } else {
      dropdownValue = '+91';
      widget.mobileCodecontroller.text = dropdownValue!;
    }

    super.initState();
  }

  @override
  void dispose() {
    _focusNode.removeListener(_onFocusChange);
    _focusNode.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // title / label
        if (widget.withLabelText)
          CustomText(
            text: widget.labelText,
            fontWeight: FontWeight.w400,
            color: AppColor.black2Color,
            fontSize: AppFontSize.size4.sp,
          ),
        if (widget.withLabelText)
          SizedBox(
            height: 2.5.w,
          ),
        // textfield
        Container(
          margin: EdgeInsets.only(top: 2.w, left: 2.w),
          child: TextFormField(
            focusNode: _focusNode,
            autofocus: widget.autofocus,
            textAlign: TextAlign.start,
            keyboardType: TextInputType.number,
            controller: widget.controller,
            style: TextStyle(
                color: AppColor.blackColor,
                fontSize: AppFontSize.size4.sp,
                fontWeight: FontWeight.w500),
            // validator: widget.validator,
            autovalidateMode: AutovalidateMode.onUserInteraction,
            enabled: widget.enabled,
            onChanged: widget.onChanged,
            validator: widget.withValidator
                ? (value) {
                    if (value!.isEmpty ||
                        value.length < phoneNumberLength ||
                        value.length > phoneNumberLength) {
                      errorText = 'Mobile Number is Required';
                    } else {
                      errorText = null;
                    }
                    return errorText;
                  }
                : null,
            obscureText: obscureText,
            inputFormatters: [
              LengthLimitingTextInputFormatter(phoneNumberLength),
              FilteringTextInputFormatter.digitsOnly,
            ],
            onFieldSubmitted: widget.onFieldSubmitted,
            decoration: InputDecoration(
              floatingLabelBehavior: FloatingLabelBehavior.auto,
              labelText: widget.labelText,
              labelStyle: TextStyle(fontSize: AppFontSize.size4),
              // constraints: BoxConstraints(
              //     maxHeight: widget.height ?? 40.w, minHeight: 30.w),
              hintText: widget.hintText,
              errorText: widget.errorText,
              errorMaxLines: 3,
              errorStyle: TextStyle(
                fontSize: AppFontSize.size5.sp,
                color: AppColor.redColor,
                fontWeight: FontWeight.w400,
              ),

              prefixIcon: Padding(
                padding: EdgeInsets.only(left: 10.w, right: 10.w),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    // if (widget.withPrefixAsset)
                    Image.asset(
                      scale: widget.assetScale ?? 25.00,
                      AssetPath.mobile,
                      // color: AppColor.primaryColor,
                    ),
                    // if (widget.withPrefixAsset)

                    Obx(
                      () => Flexible(
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: screenWidth * 0.13,
                          ),
                          child: DropdownButton<String>(
                            value: dropdownValue,
                            padding: const EdgeInsets.all(0),
                            menuMaxHeight: screenHeight * 0.4,
                            isExpanded: true,
                            underline: const SizedBox(),
                            dropdownColor: AppColor.whiteColor,
                            isDense: true,
                            alignment: Alignment.center,
                            // iconSize: 0,
                            style: TextStyle(
                                color: AppColor.blackColor,
                                fontSize: AppFontSize.size4.sp,
                                fontWeight: FontWeight.w500),
                            onChanged: (String? newValue) {
                              setState(() {
                                dropdownValue = newValue;
                                widget.mobileCodecontroller.text =
                                    dropdownValue ?? '+91';
                                // Change phone number length according to the phone code
                                for (var element
                                    in registrationController.phoneCodesData) {
                                  if (element.phoneCode == dropdownValue) {
                                    phoneNumberLength =
                                        element.phoneNumberLength;
                                  }
                                }
                                debugPrint(dropdownValue);
                                debugPrint(phoneNumberLength.toString());
                              });
                            },
                            items: registrationController.phoneCodesData
                                .map<DropdownMenuItem<String>>(
                                    (PhoneCodeList value) {
                              return DropdownMenuItem<String>(
                                value: value.phoneCode,
                                alignment: Alignment.centerLeft,
                                child: SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: Text(
                                    value.phoneCode,
                                    style: TextStyle(
                                      color: AppColor.blackColor,
                                      fontWeight: FontWeight.w500,
                                      fontSize: AppFontSize.size4.sp,
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),

                            icon: Icon(
                              Icons.keyboard_arrow_down_sharp,
                              size: 25.w,
                            ),
                            // icon: const SizedBox.shrink(),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              contentPadding: EdgeInsets.only(
                left: 70.w,
                right: 10.w,
                bottom: 0.w,
                top: 10.w,
              ),

              hintStyle: widget.hintStyle ??
                  TextStyle(
                    color: AppColor.black2Color,
                    fontSize: AppFontSize.size3.sp,
                  ),
              fillColor: AppColor.grey3,
              filled: widget.filled,
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(
                  color: AppColor.grey2,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(12.r),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: AppColor.primaryColor),
                // borderSide: BorderSide(
                //   color: AppColor.grey2,
                //   width: 1.5,
                // ),
                borderRadius: BorderRadius.circular(12.r),
              ),
              border: OutlineInputBorder(
                borderSide: const BorderSide(
                  color: AppColor.grey2,
                ),
                borderRadius: BorderRadius.circular(12.r),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
