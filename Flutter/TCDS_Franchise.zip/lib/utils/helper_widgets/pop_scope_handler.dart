import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../utils/helper_functions/will_pop_confirm_exit.dart';

// USAGE : A Common widget that is used to wrap screens to prevent unexpected exit
class PopScopeHandler extends StatelessWidget {
  final Widget child;
  const PopScopeHandler({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return PopScope(
        canPop: false,
        // ignore: deprecated_member_use
        onPopInvoked: (didPop) {
          if (didPop) {
            return;
          }
          ConfirmExit.onPopScope().then((value) {
            if (value) {
              // Close the app when user presses back twice
              SystemNavigator.pop();
            }
          });
        },
        child: child);
  }
}
