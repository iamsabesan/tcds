import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';

class SingleSelectDropDown extends StatefulWidget {
  final List<SingleSelectDropDownModel> data;
  final String labelText;
  final bool withLabelText;
  final bool filled;
  final void Function(String?)? onChange;
  final TextEditingController valueController;
  final TextEditingController? valueTextController;
  final String? errorText;
  final String? Function(String?)? validator;
  final TextStyle? hintStyle;
  final TextStyle? labelStyle;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double? height;
  final void Function()? onTap;
  final bool readOnly;
  final int? maxLength;
  final String? counterText;
  final TextInputType? keyboardType;
  final int? maxLines;
  final String? hintText;
  final bool enabled;
  final void Function(SingleSelectDropDownModel?)? parentOnChangeCall;
  final bool withValidation;

  const SingleSelectDropDown({
    super.key,
    required this.labelText,
    this.errorText,
    this.validator,
    this.onChange,
    this.hintStyle,
    this.labelStyle,
    this.prefixIcon,
    this.suffixIcon,
    this.height,
    this.onTap,
    this.readOnly = false,
    this.maxLength,
    this.counterText,
    this.keyboardType,
    this.maxLines,
    this.hintText,
    required this.valueController,
    this.valueTextController,
    this.enabled = true,
    required this.data,
    this.parentOnChangeCall,
    this.withValidation = true,
    this.withLabelText = true,
    this.filled = true,
  });

  @override
  State<SingleSelectDropDown> createState() => _SingleSelectDropDownState();
}

class _SingleSelectDropDownState extends State<SingleSelectDropDown> {
  SingleSelectDropDownModel? valueText;

  // @override
  // void initState() {
  //   super.initState();

  //   if (valueText != null) {
  //     widget.valueController.text = valueText!.valueID;
  //     if (widget.valueTextController != null) {
  //       widget.valueTextController!.text = valueText!.value;
  //     }
  //   } else if (widget.data.isNotEmpty) {
  //     valueText = widget.data[0];
  //   }
  // }

  @override
  void initState() {
    super.initState();
    if (widget.valueTextController != null &&
        widget.valueTextController!.text.isNotEmpty &&
        widget.valueController.text.isNotEmpty) {
      valueText = SingleSelectDropDownModel(
        widget.valueTextController!.text,
        widget.valueController.text,
      );
    } else if (widget.valueTextController != null &&
        widget.valueTextController!.text.isNotEmpty) {
      // debugPrint(
      //     'widget.valueTextController != null && widget.valueTextController!.text.isNotEmpty');
      //  find the value valueTextController holds & ASSIGN IT TO VALUE TEXT}
      try {
        valueText = widget.data.firstWhere(
          (element) => element.value == widget.valueTextController!.text,
        );
      } catch (e) {
        // if any error occurs while finding set first element of data as initial value
        if (widget.data.isNotEmpty) {
          valueText = widget.data[0];
          widget.valueController.text = valueText!.valueID;
          if (widget.valueTextController != null) {
            widget.valueTextController!.text = valueText!.value;
          }
        }
      }
    }
    // assign first value as initial value
    else {
      if (widget.data.isNotEmpty) {
        valueText = widget.data[0];
        widget.valueController.text = valueText!.valueID;
        if (widget.valueTextController != null) {
          widget.valueTextController!.text = valueText!.value;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // title / label
        /*if (widget.withLabelText)
          CustomText(
            text: widget.labelText,
            fontWeight: FontWeight.w400,
            color: AppColor.black2Color,
            fontSize: AppFontSize.size4.sp,
          ),
        if (widget.withLabelText)
          SizedBox(
            height: 2.5.w,
          ),*/
        // dropdown field
        DropdownButtonFormField<SingleSelectDropDownModel>(
          key: UniqueKey(),

          icon: const Icon(
            Icons.keyboard_arrow_down_sharp,
            color: AppColor.blackColor,
          ),
          isExpanded: true,
          initialValue: valueText,
          // Set initial value
          items: List.generate(
            widget.data.length,
            (index) => DropdownMenuItem<SingleSelectDropDownModel>(
              enabled: true,
              value: widget.data[index], // Values start from 1
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  widget.data[index].value,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
              ),
            ),
          ),
          // focusColor: AppColor.secondaryColor.withAlpha(80),

          iconEnabledColor: AppColor.secondaryColor,
          onChanged: widget.enabled
              ? (value) {
                  setState(() {
                    valueText = value;
                    if (valueText != null) {
                      widget.valueController.text = valueText!.valueID;
                      debugPrint(widget.valueController.text);
                      if (widget.valueTextController != null) {
                        widget.valueTextController!.text = valueText!.value;
                        debugPrint(widget.valueTextController!.text);
                      }
                    }
                  });
                  // Call parent onChange if not null
                  if (widget.parentOnChangeCall != null) {
                    widget.parentOnChangeCall!(value);
                  }
                }
              : null,
          menuMaxHeight: 300.w,
          dropdownColor: AppColor.whiteColor,
          hint: Text(
            widget.hintText ?? '',
          ),

          // Optional hint text
          validator: widget.withValidation
              ? (val) {
                  if (val == null || val.value.isEmpty) {
                    return 'Required';
                  } else {
                    return null;
                  }
                }
              : null,
          style: TextStyle(
              color: AppColor.blackColor,
              fontSize: AppFontSize.size4.sp,
              fontWeight: FontWeight.w500),
          decoration: InputDecoration(
            enabled: widget.enabled,
            labelText: widget.labelText,
            labelStyle: TextStyle(
                color: AppColor.blackColor, fontSize: AppFontSize.size4.sp),
            // constraints:
            //     BoxConstraints(maxHeight: widget.height ?? 55.w, minHeight: 50.w),
            hintText: widget.hintText,
            contentPadding:
                EdgeInsets.symmetric(horizontal: 15.w, vertical: 1.w),

            counterText: widget.counterText,

            errorText: widget.errorText,
            errorMaxLines: 3,

            errorStyle: TextStyle(
              fontSize: AppFontSize.size5.sp,
              color: AppColor.redColor,
              fontWeight: FontWeight.w400,
            ),
            prefixIcon: widget.prefixIcon,
            // suffix: widget.suffixIcon,
            suffixIconConstraints:
                BoxConstraints(maxHeight: 30.w, minHeight: 20.w),
            suffixIcon: Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.w),
              child: widget.suffixIcon,
            ),
            hintStyle: widget.hintStyle ??
                TextStyle(
                  color: AppColor.black2Color,
                  fontSize: AppFontSize.size4.sp,
                  fontWeight: FontWeight.w400,
                ),
            fillColor: AppColor.whiteColor,
            filled: widget.filled,

            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Colors.black.withValues(alpha: 0.1),
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(8.r),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: AppColor.primaryColor),
              // borderSide: BorderSide(
              //   color: AppColor.grey2,
              //   width: 1.5,
              // ),
              borderRadius: BorderRadius.circular(12.r),
            ),
            border: OutlineInputBorder(
              borderSide: const BorderSide(
                color: AppColor.grey2,
              ),
              borderRadius: BorderRadius.circular(12.r),
            ),
          ),
        ),
      ],
    );
  }
}

class SingleSelectDropDownModel {
  final String value;
  final String valueID;

  SingleSelectDropDownModel(this.value, this.valueID);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SingleSelectDropDownModel &&
          runtimeType == other.runtimeType &&
          value == other.value &&
          valueID == other.valueID;

  @override
  int get hashCode => value.hashCode ^ valueID.hashCode;
}
