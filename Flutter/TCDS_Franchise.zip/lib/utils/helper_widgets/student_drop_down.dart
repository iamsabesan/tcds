/* import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../constants/colors.dart';
import '../../constants/font_sizes.dart';
import 'custom_textfield.dart';

// ignore: must_be_immutable
class StudentDropDown extends StatefulWidget {
  final List<StudentDropDownModel> dropdownValues;
  final List<String> selectedStudentIDs;
  final String labelText;
  final String? errorText;
  final TextEditingController controller;
  final TextEditingController valueController;
  final TextEditingController countController;
  final TextStyle? labelStyle;
  final bool isVisible;
  late int selectedCount;
  final String? Function(String?)? validator;
  final void Function()? onParentTap; // Callback to reset selected students
  final void Function()? resetSelectedStudents;
  final String Function()? getCountText;

  StudentDropDown({
    super.key,
    required this.dropdownValues,
    required this.selectedStudentIDs,
    required this.selectedCount,
    required this.labelText,
    this.errorText,
    required this.controller,
    this.labelStyle,
    required this.valueController,
    required this.countController,
    this.validator,
    this.onParentTap,
    required this.isVisible,
    this.resetSelectedStudents,
    this.getCountText,
  });

  @override
  State<StudentDropDown> createState() => StudentDropDownState();
}

class StudentDropDownState extends State<StudentDropDown> {
  bool isListVisible = false;
  String selectedValue = '';
  String selectedId = '';
  int selectedCount = 0;
  // List<String> selectedStudentIDs = [];
  @override
  void initState() {
    widget.valueController.clear();
    isListVisible = widget.isVisible;

    super.initState();
    // selectedStudentIDs.clear();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    // selectedCount=widget.selectedCount;
    // selectedCount=0;
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () => setState(() => isListVisible = !isListVisible),
          child: Column(
            children: [
              CustomTextField(
                labelText: 'Student',
                controller: widget.controller,
                onTap: () => setState(() => isListVisible = !isListVisible),
                enabled: false,
                autofocus: false,
                hintStyle: TextStyle(
                  fontSize: AppFontSize.size4.sp,
                  color: AppColor.black2Color,
                  fontWeight: FontWeight.w400,
                ),
                validator: (val) {
                  if (val!.isEmpty) {
                    return 'Required';
                  } else {
                    return null;
                  }
                },
                suffixIcon: isListVisible
                    ? const Icon(
                        Icons.keyboard_arrow_up_outlined,
                        color: AppColor.blackColor,
                      )
                    : const Icon(
                        Icons.keyboard_arrow_down_outlined,
                        color: AppColor.blackColor,
                      ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10.h),
        if (isListVisible)
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 10.h),
                color: Colors.grey.withOpacity(0.2),
                child: Row(
                  children: [
                    SizedBox(
                      width: 50.w,
                    ),
                    Expanded(
                      flex: 50,
                      child: Text(
                        'ID',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 50,
                      child: Text(
                        'NAME',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14.sp,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                constraints: BoxConstraints(maxHeight: height * 0.4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      constraints: BoxConstraints(maxHeight: height * 0.4),
                      child: ListView.builder(
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: widget.dropdownValues.length,
                        itemBuilder: (context, index) => InkWell(
                          onTap: () {
                            // // Set selected value
                            // selectedValue = widget.dropdownValues[index].course;
                            // selectedId = widget.dropdownValues[index].courseID;
                            // widget.controller.text = selectedValue;
                            // widget.valueController.text = selectedId;
                            //
                            // setState(() => isListVisible = false);
                            //
                            // debugPrint('Course: ${widget.controller.text}');
                            // debugPrint('Course ID: ${widget.valueController.text}');
                            // if (widget.onParentTap != null) {
                            //   widget.onParentTap!();
                            // }
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15.w, vertical: 15.h),
                            color: index % 2 == 0
                                ? Colors.white
                                : Colors.grey.withOpacity(0.1),
                            child: Row(
                              children: [
                                Checkbox(
                                  value: widget.dropdownValues[index]
                                      .isSelected, // Your custom selected state
                                  onChanged: (bool? value) async {
                                    widget.dropdownValues[index].isSelected =
                                        value ?? false;
                                    if (value == true) {
                                      widget.selectedCount++;

                                      widget.selectedStudentIDs.add(widget
                                          .dropdownValues[index]
                                          .batchMappingId);
                                    } else {
                                      if (widget.selectedCount != 0) {
                                        widget.selectedCount--;
                                      }

                                      widget.selectedStudentIDs.remove(widget
                                          .dropdownValues[index]
                                          .batchMappingId);
                                      debugPrint(
                                          "false selectedCount=${widget.selectedCount}");
                                    }
                                    widget.controller.text = widget
                                                .selectedCount ==
                                            0
                                        ? ""
                                        : widget.selectedCount == 1
                                            ? "${widget.selectedCount} Student"
                                            : "${widget.selectedCount} Students";
                                    widget.valueController.text =
                                        widget.selectedStudentIDs.join(',');
                                    widget.countController.text = widget
                                        .selectedStudentIDs.length
                                        .toString();
                                    debugPrint(widget.valueController.text);
                                    if (widget.getCountText != null) {
                                      widget.getCountText!();
                                    }
                                    //   setState(() {
                                    // });
                                  },
                                  activeColor: Colors
                                      .orange, // Sets the checkbox active (selected) color
                                  checkColor: Colors
                                      .white, // Sets the check mark color to white
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  side: const BorderSide(
                                    color: Colors
                                        .orange, // Sets the border color to orange
                                    width: 2, // Sets border width
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        12), // Makes the checkbox rounded
                                  ),
                                ),
                                Expanded(
                                  flex: 50,
                                  child: Text(
                                    widget.dropdownValues[index].studentID,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.black,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Expanded(
                                  flex: 50,
                                  child: Text(
                                    widget.dropdownValues[index].student,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      color: Colors.black,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )
      ],
    );
  }
}

class StudentDropDownModel {
  final String student;
  final String studentID;
  final String batchMappingId;
  bool isSelected;

  StudentDropDownModel(
      this.student, this.studentID, this.batchMappingId, this.isSelected);
}
 */