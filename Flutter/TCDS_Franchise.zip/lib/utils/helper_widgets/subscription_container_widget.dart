

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class SubscriptionContainerWidget extends StatelessWidget {
  final String assetName;
  final String title;
  final String subTitle;
  const SubscriptionContainerWidget(
      {super.key,
        required this.assetName,
        required this.title,
        required this.subTitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30.w,
      width: 30.w,
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.blueAccent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon
          ClipOval(

            child: Container(
              height: 40.sp, // Reduced height
              width: 40.sp, // Reduced width
              alignment: Alignment.center,
              child: Image.asset(
                assetName,
                fit: BoxFit
                    .contain, // Ensures the image fits inside the container
                scale: 3.0, // Adjust scale for better control
              ),
            ),
          ),
          const SizedBox(height: 10), // Space between icon and text
          // Title
          const Text(
            'Title',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 5), // Space between title and subtitle
          // Subtitle
          const Text(
            'Subtitle',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white70,
            ),
          ),
        ],
      ),
    );
  }
}
