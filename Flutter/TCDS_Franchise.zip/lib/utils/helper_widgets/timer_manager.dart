import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../constants/app_string.dart';
import '../../constants/shared_preference.dart';
import '../../user_interface/dashboard/controller/dashboard_controller.dart';
import '../../user_interface/renewal/ui/renewal_detail_page.dart';

class TimerManager {
  static final TimerManager _instance = TimerManager._internal();
  Timer? _timer;
  DashboardController dashboardController = Get.find<DashboardController>();
  DateTime now= DateTime.now();
  // Singleton factory constructor
  factory TimerManager() {
    return _instance;
  }

  TimerManager._internal();

  // Start the timer, calling the API every 5 minutes
  void startTimer() {
    if (_timer == null || !_timer!.isActive) {
      _timer = Timer.periodic(const Duration(minutes: 5), (timer) async {
        await dashboardController.getDashboardTotalDetails();
        DateTime approvalDate = _parseDate(  dashboardController.dashboardTotalData[0].approvalEndDate,);
        DateTime subscriptionDate = _parseDate(  dashboardController.dashboardTotalData[0].subscriptionEndDate,);
        if ((now.isAfter(approvalDate)) ||(now.isAfter(subscriptionDate))){
          SharedPreference.putBool(AppStrings.expire, true);
          Get.to(const RenewalDetailPage());
          debugPrint("Renewal Needed");
        }
      });
    }
  }

  // Cancel the timer
  void cancelTimer() {
    _timer?.cancel();
    _timer = null;
  }

  // Check if the timer is running
  bool isTimerActive() {
    return _timer?.isActive ?? false;
  }

  DateTime _parseDate(String dateStr) {
    List<String> parts = dateStr.split('-');
    int day = int.parse(parts[0]);
    int month = int.parse(parts[1]);
    int year = int.parse(parts[2]);

    // Return a DateTime object for the given date
    return DateTime(year, month, day);
  }
}
