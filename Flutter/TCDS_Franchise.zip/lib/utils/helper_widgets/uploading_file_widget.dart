import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_file/open_file.dart';
import 'package:tcds/constants/asset_paths.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_functions/common_dialogs.dart';
import 'package:tcds/utils/helper_widgets/custom_text.dart';

class UploadFileWidget extends StatefulWidget {
  final String proofType;

  const UploadFileWidget({super.key, required this.proofType});

  @override
  State<UploadFileWidget> createState() => _UploadFileWidgetState();
}

class _UploadFileWidgetState extends State<UploadFileWidget> {
  Map<String, String?> attachments = {};

  Future<void> _pickFile(String proofType) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'png', 'jpeg', 'jpg'],
    );

    if (result != null) {
      PlatformFile file = result.files.single;
      String fileExtension = file.extension?.toLowerCase() ?? '';
      // check if any extention type selected
      // check if file size exceeds 2 mb
      if (!['pdf', 'png', 'jpeg', 'jpg'].contains(fileExtension)) {
        showInformationDialog(
          context: Get.context!,
          message:
              'Invalid file type. Please select a JPG, PNG, JPEG or PDF file.',
        );
      } else if (file.size > 2 * 1024 * 1024) {
        // File size exceeds 2MB
        showInformationDialog(
            context: Get.context!,
            message: 'File size exceeds 2MB. Please choose a smaller file.');
      } else {
        String? filePath = result.files.single.path;
        debugPrint('File picked: ${file.path}');
        if (filePath != null) {
          setState(() {
            attachments[proofType] = filePath;
          });
        }
      }
    } else {
      debugPrint('No file picked');
    }
  }

  void _deleteFile(String proofType) {
    setState(() {
      attachments.remove(proofType);
    });
  }

  void _downloadFile(String filePath) {
    OpenFile.open(filePath);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 12.w),
      child: Container(
        width: double.infinity,
        height: 150,
        decoration: BoxDecoration(
          border: Border.all(
            color: AppColor.greyColor,
            style: BorderStyle.none,
          ),
          borderRadius: BorderRadius.circular(8.w),
        ),
        child: attachments[widget.proofType] == null
            ? DottedBorder(
                color: AppColor.greyColor,
                strokeWidth: 4.5,
                dashPattern: const [12, 12],
                borderType: BorderType.rRect,
                radius: Radius.circular(8.r),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: Image.asset(
                        AssetPath.uploadIcon,
                        scale: 1.0,
                      ),
                    ),
                    CustomText(
                      text: 'Choose a file',
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w500,
                    ),
                    SizedBox(height: 5.w),
                    CustomText(
                      text: 'JPG, JPEG, PNG, and PDF formats, up to 2MB',
                      fontSize: AppFontSize.size4,
                      color: AppColor.greyColor,
                      fontWeight: FontWeight.bold,
                    ),
                    SizedBox(height: 10.w),
                    InkWell(
                      onTap: () {
                        _pickFile(widget.proofType);
                      },
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          border: Border.all(
                            color: AppColor.secondaryColor,
                            width: 2.w,
                          ),
                          borderRadius: BorderRadius.circular(8.r),
                        ),
                        child: Padding(
                          padding: EdgeInsets.symmetric(horizontal: 4.w),
                          child: CustomText(
                            text: 'Browse File',
                            color: AppColor.secondaryColor,
                            fontSize: AppFontSize.size5,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.w,
                    ),
                  ],
                ),
              )
            : ListTile(
                leading: Image.asset(
                  AssetPath.fileImage,
                  scale: 1.0,
                ),
                title: Text(attachments[widget.proofType]!.split('/').last),
                trailing: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Image.asset(
                        AssetPath.cloudDownload,
                        scale: 20.0,
                      ),
                      onPressed: () =>
                          _downloadFile(attachments[widget.proofType]!),
                    ),
                    IconButton(
                      icon: Image.asset(
                        AssetPath.deleteIconWithBG,
                        scale: 1.0,
                      ),
                      onPressed: () => _deleteFile(widget.proofType),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}

class DottedBorder extends StatelessWidget {
  final Widget child;
  final Color color;
  final double strokeWidth;
  final List<double> dashPattern;
  final BorderType borderType;
  final Radius radius;

  const DottedBorder({
    super.key,
    required this.child,
    this.color = Colors.black,
    this.strokeWidth = 1.0,
    this.dashPattern = const [5, 3],
    this.borderType = BorderType.rect,
    this.radius = Radius.zero,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius.x),
      child: CustomPaint(
        painter: _DottedBorderPainter(
          color: color,
          strokeWidth: strokeWidth,
          dashPattern: dashPattern,
          borderType: borderType,
          radius: radius,
        ),
        child: child,
      ),
    );
  }
}

class _DottedBorderPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  final List<double> dashPattern;
  final BorderType borderType;
  final Radius radius;

  _DottedBorderPainter({
    required this.color,
    required this.strokeWidth,
    required this.dashPattern,
    required this.borderType,
    required this.radius,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final Path path = Path();

    switch (borderType) {
      case BorderType.rect:
        path.addRect(Rect.fromLTWH(0, 0, size.width, size.height));
        break;
      case BorderType.rRect:
        path.addRRect(RRect.fromRectAndRadius(
            Rect.fromLTWH(0, 0, size.width, size.height), radius));
        break;
    }

    final PathMetrics pathMetrics = path.computeMetrics();
    for (PathMetric pathMetric in pathMetrics) {
      double distance = 0.0;
      bool draw = true;

      while (distance < pathMetric.length) {
        // final double length = dashPattern.fold(0.0, (a, b) => a + b);
        for (final double dash in dashPattern) {
          if (distance + dash > pathMetric.length) {
            final double remaining = pathMetric.length - distance;
            if (draw) {
              canvas.drawPath(
                  pathMetric.extractPath(distance, distance + remaining),
                  paint);
            }
            distance = pathMetric.length;
            break;
          }

          if (draw) {
            canvas.drawPath(
                pathMetric.extractPath(distance, distance + dash), paint);
          }
          distance += dash;
          draw = !draw;
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

enum BorderType {
  rect,
  rRect,
}
