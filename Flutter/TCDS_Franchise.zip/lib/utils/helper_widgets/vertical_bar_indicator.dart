import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:tcds/constants/colors.dart';

class VerticalBarIndicator extends StatelessWidget {
  final int regular; // Value for the regular segment
  final int online; // Value for the online segment
  final Color regularColor;
  final Color onlineColor;
  final double barWidth;
  final double barHeight;

  const VerticalBarIndicator({
    super.key,
    required this.regular,
    required this.online,
    this.regularColor = AppColor.progressBarBlue,
    this.onlineColor = AppColor.progressBarPeach,
    this.barWidth = 12.0,
    this.barHeight = 60.0,
  });

  @override
  Widget build(BuildContext context) {
    int totalValue = regular + online;
    double regularHeight =
        totalValue == 0 ? 0 : (regular / totalValue) * barHeight;
    double onlineHeight =
        totalValue == 0 ? 0 : (online / totalValue) * barHeight;

    return Container(
      width: barWidth,
      height: barHeight,
      decoration: BoxDecoration(
        color: totalValue == 0 ? Colors.grey[100] : null,
        borderRadius: BorderRadius.circular(4.r),
      ),
      child: Stack(
        children: [
          // Regular segment (now at the top)
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              width: barWidth,
              height: regularHeight,
              decoration: BoxDecoration(
                color: regularColor,
                borderRadius: online == 0
                    ? BorderRadius.circular(4.r)
                    : BorderRadius.vertical(
                        top: Radius.circular(4.r),
                      ),
              ),
            ),
          ),
          // Online segment (now at the bottom)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: barWidth,
              height: onlineHeight,
              decoration: BoxDecoration(
                color: onlineColor,
                borderRadius: regular == 0
                    ? BorderRadius.circular(4.r)
                    : BorderRadius.vertical(
                        bottom: Radius.circular(4.r),
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
