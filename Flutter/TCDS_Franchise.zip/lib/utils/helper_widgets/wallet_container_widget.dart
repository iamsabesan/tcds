import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart'; // For responsive screen size
import '../../../../constants/colors.dart';
import 'custom_text.dart';

class WalletText extends StatelessWidget {
  final String assetName;
  final String title;
  final String subTitle;

  const WalletText(
      {super.key,
        required this.assetName,
        required this.title,
        required this.subTitle});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: ClipOval(

        child: Container(
          height: 40.sp, // Reduced height
          width: 40.sp, // Reduced width
          alignment: Alignment.center,
          child: Image.asset(
            assetName,
            fit: BoxFit
                .contain, // Ensures the image fits inside the container
            scale: 3.0, // Adjust scale for better control
          ),
        ),
      ),
      title: CustomText(
        text: title,
        color: AppColor.titleColor,
        fontWeight: FontWeight.w500,
        overflow: TextOverflow.ellipsis,
        fontSize: 12.sp,
      ),
      subtitle: CustomText(
        text: subTitle,
        color: AppColor.secondaryColor,
        fontWeight: FontWeight.w500,
        // overflow: TextOverflow.ellipsis,
        fontSize: 15.sp,
      ),
    );
  }
}
