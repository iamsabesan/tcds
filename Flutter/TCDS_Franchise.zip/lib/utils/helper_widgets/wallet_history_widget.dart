import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:tcds/constants/colors.dart';
import 'package:tcds/constants/font_sizes.dart';
import 'package:tcds/utils/helper_widgets/bullet_text.dart';
import 'package:tcds/utils/helper_widgets/forward_arrow_widget.dart';

import 'custom_text.dart';

class WalletHistoryWidget extends StatefulWidget {
  final String dateAndTime;
  final String balance;
  final String status;
  final String walletIn;
  final String purpose;
  final String walletOut;
  final bool withForwardArrow;

  const WalletHistoryWidget({
    super.key,
    required this.dateAndTime,
    required this.balance,
    required this.status,
    required this.walletIn,
    required this.walletOut,
    required this.purpose,
    required this.withForwardArrow,
  });

  @override
  State<WalletHistoryWidget> createState() => _WalletHistoryWidgetState();
}

class _WalletHistoryWidgetState extends State<WalletHistoryWidget> {
  NumberFormat currencyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 12.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left Column
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: widget.dateAndTime,
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w500,
                      color: AppColor.primaryColor,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4.w),
                    CustomText(
                      text:
                          "${currencyFormat.format(double.tryParse(widget.balance) ?? 0)} Balance",
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w400,
                      overflow: TextOverflow.ellipsis,
                      color: AppColor.blackColor,
                    ),
                    SizedBox(height: 4.w),
                    /* CustomText(
                      text: widget.purpose,
                      fontSize: AppFontSize.size4,
                      fontWeight: FontWeight.w400,
                      overflow: TextOverflow.ellipsis,
                      color: AppColor.black2Color,

                    ),*/
                  ],
                ),
              ),
              // Right Column
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomText(
                      text: widget.status,
                      fontSize: AppFontSize.size4,
                      overflow: TextOverflow.ellipsis,
                      fontWeight: FontWeight.w400,
                      color: AppColor.secondaryColor,
                    ),
                    SizedBox(height: 4.w),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        BulletText(
                          label: "In",
                          value: currencyFormat
                              .format(double.tryParse(widget.walletIn) ?? 0),
                          showRupeeSymbol: false,
                          withBullet: false,
                          fontSize: AppFontSize.size4,
                        ),
                        BulletText(
                          label: "Out",
                          value: currencyFormat
                              .format(double.tryParse(widget.walletOut) ?? 0),
                          showRupeeSymbol: false,
                          fontSize: AppFontSize.size4,
                          withBullet: true,
                        ),
                      ],
                    ),
                    SizedBox(height: 5.h),
                  ],
                ),
              ),

              SizedBox(
                width: 15.w,
              ),

              if (widget.withForwardArrow)
                const Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 8.0),
                      child: ForwardArrowWidget(
                          // onTap: widget.onTap,
                          ),
                    ),
                  ],
                ),
            ],
          ),
          CustomText(
            text: widget.purpose,
            fontSize: AppFontSize.size4.sp,
            fontWeight: FontWeight.w400,
            color: AppColor.black2Color,
          ),
          const SizedBox(
            height: 5,
          ),
          const Divider(
            thickness: 1.0,
            color: AppColor.grey,
          ),
        ],
      ),
    );
  }
}
