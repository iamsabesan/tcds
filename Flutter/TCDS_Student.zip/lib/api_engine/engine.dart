// ignore_for_file: deprecated_member_use
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:tcds_student/constants/shared_pref.dart';
import '../constants/app_string.dart';
import '../utils/helper_functions/engine_dialogue_box.dart';
import 'model/error_response_model.dart';
import 'model/http_response_model.dart';
import 'model/refresh_response_model.dart';

class Engine {
  Dio? dio;
  Dio refreshDio = Dio();

  /*This is get method calling engine.
  * For each and every get api call this function will call
  
  * and provide response to you*/
  Future<Response> get<T>(String path,
      {bool protected = true,
      Map<String, String>? headers,
      ContentType? contentType,
      ProgressCallback? onReceiveProgress}) async {
    debugPrint("get request data $path");
    dio = Dio();
    dio!.interceptors.add(
      InterceptorsWrapper(
        onRequest: (RequestOptions options, handler) async {
          // Do something before request is sent
          options.responseType = ResponseType.json;
          if (protected) {
            Map<String, String> mainHeaders = {
              "Authorization":
                  "Bearer ${SharedPref.getString(AppStrings.accessToken)}",
              AppStrings.contentType: AppStrings.contentTypeValue
            };
            options.headers = mainHeaders;
          } else {
            options.headers = headers;
          }
          return handler.next(options);
        },
        onResponse: (Response response, handler) async {
          debugPrint("Engine Response Code ${response.statusCode}");

          HttpResponseModel res = HttpResponseModel.fromJson(response.data);

          try {
            // Handle Model Validation Error (422)
            if (res.code == 422) {
              // close loader dialog if its in Open State

              ErrorResponseModel res =
                  ErrorResponseModel.fromJson(response.data);
              debugPrint("422 Response ${res.refData}");
              //Check Refdata is not empty to Throw Multiple Errors
              if (res.refData!.isNotEmpty) {
                // returnMessage will have whole errors
                String returnMessage = '';
                // Loop through all fields and descriptions
                for (var errorField in res.refData!) {
                  String field = errorField.field.toString();
                  returnMessage = returnMessage + 'Field : $field\n'.toString();
                  // Loop through all descriptions cause a field can have multiple errors
                  for (var errorDesc in errorField.description!) {
                    returnMessage = returnMessage + '\t $errorDesc'.toString();
                  }
                  //  Add lines
                  returnMessage = returnMessage + '\n\n'.toString();
                }
                await dialogueBox(isClose: false, msg: returnMessage);
              } else {
                // Show responce message
                await dialogueBox(isClose: false, msg: res.message);
              }
            } else {
              // Handle Success and throw a message if not the success code
              if (res.code == 200 || res.code == 201) {
                return handler.resolve(response);
              } else {
                await dialogueBox(isClose: false, msg: res.message);
              }
            }
          } catch (e) {
            debugPrint(e.toString());
          }
          // debugPrint("response from http engine before get${response.data}");
          // HttpResponseModel res = HttpResponseModel.fromJson(response.data);
          // debugPrint("response from http engine after get $res");
          return handler.resolve(response);
        },
        onError: (DioError e, handler) async {
          // close loader dialog if its in Open State

          if (e.response?.statusCode == 400) {
            HttpResponseModel res =
                HttpResponseModel.fromJson(e.response!.data);
            await dialogueBox(isClose: false, msg: res.message);
            return handler.next(e);
          } else if (e.response?.statusCode == 401) {
            await callRefreshToken('GET', e, handler, protected);
          } else if (e.response?.statusCode == 403) {
            HttpResponseModel res =
                HttpResponseModel.fromJson(e.response!.data);
            await dialogueBox(isClose: false, msg: res.message);
            return handler.next(e);
          } else if (e.response?.statusCode == 404) {
            if (e.response != null) {
              HttpResponseModel res =
                  HttpResponseModel.fromJson(e.response!.data);
              await dialogueBox(isClose: false, msg: res.message);
            } else {
              HttpResponseModel res =
                  HttpResponseModel.fromJson(e.response!.data);
              await dialogueBox(isClose: false, msg: res.message);
            }
            return handler.next(e);
          } else if (e.response?.statusCode != 200 ||
              e.response?.statusCode != 201) {
            await dialogueBox(
                isClose: true,
                msg: "Oops ! Something went wrong",
                isDismissible: false,
                isWillPop: false);
            // dialougeEngine.singleDialog('Error ', 'Oops ! Something went wrong',
            //     isClose: true);
            return handler.next(e);
          }
        },
      ),
    );

    Response<T> response =
        await dio!.get<T>(path, onReceiveProgress: onReceiveProgress);
    debugPrint("response from http engine${response.data}");
    return response;
  }

  Future<Response> post<T>(String path, dynamic postData,
      {bool protected = true,
      Map<String, String>? headers,
      ContentType? contentType,
      ProgressCallback? onSendProgress,
      ProgressCallback? onReceiveProgress,
      String custom = ""}) async {
    debugPrint("post request data $path post data $postData");
    dio = Dio();
    dio!.interceptors.add(
      InterceptorsWrapper(
        onRequest: (RequestOptions options, handler) async {
          // Do something before request is sent
//          options.connectTimeout = 10000;
          options.responseType = ResponseType.json;
          if (protected) {
            Map<String, String> mainHeaders = {
              "Authorization":
                  "Bearer ${SharedPref.getString(AppStrings.accessToken)}",
              AppStrings.contentType:
                  custom.isEmpty ? AppStrings.contentTypeValue : custom
            };
            options.headers = mainHeaders;
          } else {
            options.headers = headers;
          }

          // return options;
          return handler.next(options);
        },
        onResponse: (Response response, handler) async {
          debugPrint("Engine Response Code ${response.statusCode}");
          HttpResponseModel res = HttpResponseModel.fromJson(response.data);

          try {
            // Handle Model Validation Error (422)
            if (res.code == 422) {
              ErrorResponseModel res =
                  ErrorResponseModel.fromJson(response.data);
              debugPrint("422 Response ${res.refData}");
              //Check Refdata is not empty to Throw Multiple Errors
              if (res.refData!.isNotEmpty) {
                // returnMessage will have whole errors
                String returnMessage = '';
                // Loop through all fields and descriptions
                for (var errorField in res.refData!) {
                  String field = errorField.field.toString();
                  returnMessage = returnMessage + 'Field : $field\n'.toString();
                  // Loop through all descriptions cause a field can have multiple errors
                  for (var errorDesc in errorField.description!) {
                    returnMessage = returnMessage + '\t $errorDesc'.toString();
                  }
                  //  Add lines
                  returnMessage = returnMessage + '\n\n'.toString();
                }
                await dialogueBox(isClose: false, msg: returnMessage);
              } else {
                // Show responce message
                await dialogueBox(isClose: false, msg: res.message);
              }
            } else {
              // Handle Success and throw a message if not the success code
              if (res.code == 200 || res.code == 201) {
                return handler.resolve(response);
              } else {
                await dialogueBox(isClose: false, msg: res.message);
              }
            }
          } catch (e) {
            debugPrint(e.toString());
          }
          return handler.resolve(response);
        },
        onError: (DioError e, handler) async {
          if (e.response?.statusCode == 400) {
            HttpResponseModel res =
                HttpResponseModel.fromJson(e.response!.data);
            await dialogueBox(isClose: false, msg: res.message);
            return handler.next(e);
          } else if (e.response?.statusCode == 401) {
            await callRefreshToken('POST', e, handler, protected);
          } else if (e.response?.statusCode == 403) {
            HttpResponseModel res =
                HttpResponseModel.fromJson(e.response!.data);
            await dialogueBox(isClose: false, msg: res.message);
            return handler.next(e);
          } else if (e.response?.statusCode == 404) {
            debugPrint('Post 404 Error Section');
            debugPrint(e.response!.data.toString());
            // HttpResponseModel res =
            //     HttpResponseModel.fromJson(e.response!.data);
            // dialogueBox(isClose: false, msg: res.message);
            return handler.next(e);
          } else if (e.response?.statusCode == 503) {
            await dialogueBox(
                isClose: false,
                msg: "No Internet Connection",
                isWillPop: false,
                isDismissible: false);
            return handler.next(e);
          } else if (e.response?.statusCode != 200 ||
              e.response?.statusCode != 201) {
            await dialogueBox(
                isClose: true,
                msg: "Oops ! Something went wrong",
                isWillPop: false,
                isDismissible: false);
            return handler.next(e);
          }
        },
      ),
    );

    Response<T> response = await dio!.post<T>(path,
        data: postData,
        onSendProgress: onSendProgress,
        onReceiveProgress: onReceiveProgress);
    debugPrint("response from http engine${response.data}");
    return response;
  }

  // refresh token implementation
  callRefreshToken(String method, DioError e, handler, bool guest) {
    debugPrint("Refresh token call initiated");
    RequestOptions options = e.response!.requestOptions;
    options.headers.clear();
    options.headers = {
      AppStrings.contentType: AppStrings.contentTypeValue,
      'Authorization': 'Bearer ${SharedPref.getString(AppStrings.accessToken)}',
    };

    debugPrint("Header ${options.headers}");
    Map<String, String> bodyData = {
      'RefreshToken': SharedPref.getString(AppStrings.refreshToken)
    };
    debugPrint('Body data $bodyData');

    return refreshDio
        .post(AppStrings.baseUrl + AppStrings.refreshTokenUrl,
            data: bodyData, options: Options(headers: options.headers))
        .then((value) {
      RefreshResponseModel entity = RefreshResponseModel.fromJson(value.data);
      debugPrint('New Access Token : ${entity.data!.bearerToken!}');
      debugPrint('Refresh Token : ${entity.data!.refreshToken!}');
      /*Here we want set new bearer token and refresh token*/

      SharedPref.putString(AppStrings.accessToken, entity.data!.bearerToken!);
      SharedPref.putString(AppStrings.refreshToken, entity.data!.refreshToken!);

      options.headers.clear();
      options.method = method;
      Map<String, String> header = {
        "Authorization":
            "Bearer ${SharedPref.getString(AppStrings.accessToken)}",
        AppStrings.contentType: AppStrings.contentTypeValue
      };
      options.headers.addAll(header);
      debugPrint("Header ${options.headers}");
    }).catchError((onError) async {
      debugPrint("Refresh Token Exception Error : $onError");
      await SharedPref.clearAll();
      /*If any error occur in this we want clear everything
        * which is stored locally.*/
      debugPrint("All Values Cleared. Logout Successed");
      throw onError;
    })
      ..whenComplete(() {}).then((e) async {
        if (method == 'GET') {
          Response<dynamic> response = await dio!.request(options.path,
              options: Options(headers: options.headers));
          return handler.resolve(response);
        } else {
          debugPrint("Post data : ${options.data}");
          Response<dynamic> response = await dio!.request(options.path,
              options:
                  Options(headers: options.headers, method: options.method),
              data: options.data);
          return handler.resolve(response);
        }
      });
  }
}
