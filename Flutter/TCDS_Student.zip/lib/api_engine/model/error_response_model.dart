class ErrorResponseModel {
  int? code;
  String? message;
  String? detail;
  String? trace;
  List<RefData>? refData;
  String? refCommand;

  ErrorResponseModel(
      {this.code,
        this.message,
        this.detail,
        this.trace,
        this.refData,
        this.refCommand});

  ErrorResponseModel.fromJson(Map<String, dynamic> json) {
    code = json['Code'];
    message = json['Message'];
    detail = json['Detail'];
    trace = json['Trace'];
    if (json['RefData'] != null) {
      refData = <RefData>[];
      json['RefData'].forEach((v) {
        refData!.add(RefData.fromJson(v));
      });
    }
    refCommand = json['RefCommand'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Code'] = code;
    data['Message'] = message;
    data['Detail'] = detail;
    data['Trace'] = trace;
    if (refData != null) {
      data['RefData'] = refData!.map((v) => v.toJson()).toList();
    }
    data['RefCommand'] = refCommand;
    return data;
  }
}

class RefData {
  String? field;
  List<String>? description;

  RefData({this.field, this.description});

  RefData.fromJson(Map<String, dynamic> json) {
    field = json['Field'];
    description = json['Description'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Field'] = field;
    data['Description'] = description;
    return data;
  }
}
