import 'package:get/get.dart';
import '../controllers/achievers_award_controller.dart';

class AchieversAwardBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AchieversAwardController>(() => AchieversAwardController());
  }
}
