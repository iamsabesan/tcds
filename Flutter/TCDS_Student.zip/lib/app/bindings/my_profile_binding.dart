import 'package:get/get.dart';
import 'package:tcds_student/app/controllers/my_profile_controller.dart';
import '../controllers/register_controller.dart';

class MyProfileBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MyProfileController>(() => MyProfileController());
    Get.lazyPut<RegisterController>(() => RegisterController());
  }
}
