import 'package:get/get.dart';
import '../controllers/register_address_controller.dart';
import '../controllers/register_controller.dart';

class RegisterBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RegisterController>(() => RegisterController());
    Get.lazyPut<RegisterAddressController>(() => RegisterAddressController());
  }
}
