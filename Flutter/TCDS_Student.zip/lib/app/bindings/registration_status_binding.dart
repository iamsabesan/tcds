

import 'package:get/get.dart';

import '../controllers/registration_status_controller.dart';

class RegistrationStatusBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<RegistrationStatusController>(() => RegistrationStatusController());
  }
}