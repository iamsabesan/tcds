import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../models/award/image_response_model.dart';
import '../models/award/level_achievers_award.dart';
import '../models/award/level_response_model.dart';
import '../models/registeration/franchise_district.dart';
import '../models/registeration/franchise_state.dart';
import '../models/registeration/franchise_taluk.dart';

class AchieversAwardController extends GetxController {
  Engine engine = Engine();
  RxBool achieversAwardScreenLoader = false.obs;
  RxList<AchieversAwardList> awardsList = <AchieversAwardList>[].obs;
  RxList<Map<String, List<AchieversAwardList>>> groupedAwardsList =
      <Map<String, List<AchieversAwardList>>>[].obs;
  RxList<String> levelList = <String>[].obs;
  /* RxList<Country> countryList = <Country>[].obs;
  RxList<District> districtList = <District>[].obs;
  RxList<States> stateList = <States>[].obs; */
  RxList<ImageResponseModel> imageResponse = <ImageResponseModel>[].obs;

  // franchise available state,district and taluks
  RxList<FranchiseState> franchiseState = <FranchiseState>[].obs;
  RxList<FranchiseDistrict> franchiseDistrict = <FranchiseDistrict>[].obs;
  RxList<FranchiseTaluk> franchiseTaluk = <FranchiseTaluk>[].obs;

  Future<bool> getDistrictAwardsList({required dynamic body}) async {
    bool resultValue = false;
    achieversAwardScreenLoader.value = true;
    try {
      await engine
          .post(
              AppStrings.baseUrl + AppStrings.getDistrictLevelAwardsList, body)
          .then((value) async {
        // log(value.data.toString());
        AwardResponseModel model = AwardResponseModel.fromJson(value.data);
        awardsList.value = model.data;

        // after fetched awards let's loop through it for to get and store owner image as base64
        for (var i = 0; i < awardsList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: awardsList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            awardsList[i].base64Image = splitRawBase64;
          } else {
            awardsList[i].base64Image = null;
          }
        }

        // after fetched awards data completely let's filter it based on state or district
        groupedAwardsList.value = groupBy(awardsList,
                (award) => award.district.toLowerCase().removeAllWhitespace)
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedAwardsList.toString());

        achieversAwardScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  Future<bool> getStateAwardsList({required dynamic body}) async {
    bool resultValue = false;
    achieversAwardScreenLoader.value = true;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.getStateLevelAwardsList, body)
          .then((value) async {
        // log(value.data.toString());
        AwardResponseModel model = AwardResponseModel.fromJson(value.data);
        awardsList.value = model.data;
        // after fetched centres let's loop through it for to get and store owner image as base64
        for (var i = 0; i < awardsList.length; i++) {
          // fetch base64 for an owner image
          bool imageFetched =
              await getImageDetails(imgID: awardsList[i].contentUrl);
          if (imageFetched && imageResponse.isNotEmpty) {
            String splitRawBase64 = imageResponse[0].data.split(",")[1];
            awardsList[i].base64Image = splitRawBase64;
          } else {
            awardsList[i].base64Image = null;
          }
        }

        // after fetched awards data completely let's filter it based on state or district
        groupedAwardsList.value = groupBy(awardsList,
                (award) => award.state.toLowerCase().removeAllWhitespace)
            .map((key, value) => MapEntry(key, value))
            .entries
            .map((entry) => {entry.key: entry.value})
            .toList();

        // log(groupedAwardsList.toString());

        achieversAwardScreenLoader.value = false;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }
    return resultValue;
  }

  // Get image details
  Future<bool> getImageDetails({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageResponseModel model = ImageResponseModel.fromJson(value.data);
          imageResponse.clear();
          imageResponse.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }

  Future<bool> getLevel() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.levelUrl, protected: true)
          .then((value) {
        LevelResponseModel model = LevelResponseModel.fromJson(value.data);
        levelList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  /* // get country list
  Future<bool> getCountryList() async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.coutriesList, protected: true)
          .then((value) {
        CountriesModel model = CountriesModel.fromJson(value.data);
        countryList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get state list
  Future<bool> getStateList({required String countryId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.statesList + countryId,
              protected: true)
          .then((value) {
        StateModel model = StateModel.fromJson(value.data);
        stateList.value = model.data;
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

  // get district list
  Future<bool> getDistrictList({required String stateId}) async {
    bool resultValue = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.districtList + stateId,
              protected: true)
          .then((value) {
        DistrictModel model = DistrictModel.fromJson(value.data);
        districtList.clear();
        districtList.value = model.data;
        // Add an extra custom option - ALL
        districtList.insert(0, District(districtId: -1, districtName: 'ALL'));
        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  } */

  // fetch franchise state list
  Future<bool> fetchFranchiseState() async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseStates}india',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseStateModel model = FranchiseStateModel.fromJson(value.data);
          franchiseState.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseState) => $e");
    }
    return result;
  }

  // fetch franchise district list
  Future<bool> fetchFranchiseDistrict({required String stateName}) async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseDistrict}$stateName',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseDistrictModel model =
              FranchiseDistrictModel.fromJson(value.data);
          franchiseDistrict.value = model.data;
          // Add an extra custom option - ALL
          franchiseDistrict.insert(
              0, FranchiseDistrict(districtProvinceName: 'ALL'));
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseDistrict) => $e");
    }
    return result;
  }

  // fetch franchise taluk list
  Future<bool> fetchFranchiseTaluk({required String districtName}) async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseTaluk}$districtName',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseTalukModel model = FranchiseTalukModel.fromJson(value.data);
          franchiseTaluk.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseTaluk) => $e");
    }
    return result;
  }
}
