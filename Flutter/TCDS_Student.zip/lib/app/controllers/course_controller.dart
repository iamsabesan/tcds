import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../models/course_type/course_type_list_model.dart';
import '../models/course_type/login_course_detail_model.dart';

class CourseController extends GetxController {
  Engine engine = Engine();

  RxList<CourseTypeData> courseData = <CourseTypeData>[].obs;
  RxList<LoginCourseList> loginCourseData = <LoginCourseList>[].obs;
  // screen loader bools
  RxBool courseScrLoader = false.obs;
  RxBool courseScrListLoader = false.obs;

  Future<bool> fetchCourseTypeList() async {
    bool result = false;
    // courseScrLoader.value = true;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseTypeData, protected: true)
          .then(
        (value) {
          CorseTypeListModel model = CorseTypeListModel.fromJson(value.data);
          courseData.value = model.data;
          result = true;
          // courseScrLoader.value = false;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchCourseTypeList) => $e");
    }
    return result;
  }

  Future<bool> fetchLoginCourseList({required String courseTypeID}) async {
    bool result = false;
    courseScrListLoader.value = true;

    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.courseTypeIDData + courseTypeID,
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          LoginCourseListModel model =
              LoginCourseListModel.fromJson(value.data);
          loginCourseData.value = model.data;

          result = true;
          courseScrListLoader.value = false;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchLoginCourseList) => $e");
    }
    return result;
  }
}
