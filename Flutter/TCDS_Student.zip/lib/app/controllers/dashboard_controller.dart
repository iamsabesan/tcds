import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../../constants/shared_pref.dart';
import '../models/dashboard/personal_detail_model_d.dart';
import '../models/registration_status/student_enquiry_model.dart';

class DashboardController extends GetxController {
  Engine engine = Engine();

  RxList<EnquiryDetail> stdntEnquiryDetail = <EnquiryDetail>[].obs;
  RxList<PersonalInfo> personalInfoDetail = <PersonalInfo>[].obs;
  // screen loader bools
  RxBool centresScrLoader = false.obs;
  RxBool centresListLoader = false.obs;
  RxBool dashboardLoader = false.obs;

  //fetch student detail
  Future<bool> studentDetail({required String studentEnquiryId}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.userData + studentEnquiryId,
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          StudentEnquiryModel model = StudentEnquiryModel.fromJson(value.data);
          stdntEnquiryDetail.clear();
          stdntEnquiryDetail.add(model.data);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }

  Future<bool> personalDetail({required String contactID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.personalDetailUrl + contactID,
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          PersonalDetailModel model = PersonalDetailModel.fromJson(value.data);
          personalInfoDetail.clear();
          personalInfoDetail.add(model.data);

          // Save profile image to SharedPreferences for drawer persistence
          _saveProfileImageToPrefs(model.data);

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }

  // Save profile image to SharedPreferences for persistent storage
  void _saveProfileImageToPrefs(PersonalInfo personalInfo) {
    try {
      if (personalInfo.studentImages.isNotEmpty &&
          personalInfo.studentImages[0].profileBase64 != null) {
        SharedPref.putString(AppStrings.profileImage,
            personalInfo.studentImages[0].profileBase64!);
      }
    } catch (e) {
      debugPrint("Error saving profile image to preferences: $e");
    }
  }

  // account deletion request
  Future<bool> accountDeletionRequest() async {
    bool resultValue = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.accountDeletion,
              {"ContactID": SharedPref.getString(AppStrings.contactID)},
              protected: true)
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      debugPrint("Func (accountDeletionRequest) => $e");
    }

    return resultValue;
  }
}
