import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:tcds_student/api_engine/engine.dart';
import 'package:tcds_student/constants/app_string.dart';
import '../../constants/shared_pref.dart';
import '../models/dashboard/personal_detail_model_d.dart';
import '../models/login/bearer_responce_model.dart';
import '../models/login/log_in_responce_model.dart';
import '../models/login/request_otp.dart';
import '../models/registeration/otp_responce.dart';

class LoginController extends GetxController {
  Engine engine = Engine();
  RxList<PersonalInfo> personalInfoDetail = <PersonalInfo>[].obs;

  // -- OTP Screen section
  RxList<OTPData> requestedOTP = <OTPData>[].obs;
  // Resend code show helper bool
  bool isRecendCode = false;
  // Timer and total Seconds initialization
  int totalSeconds = 30;
  late Timer timer;

  //FUNCTION :  Timer Logic and Start timer
  void startTimer({dynamic setState}) {
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (totalSeconds > 0) {
        setState(() {
          totalSeconds--;
        });
      } else {
        setState(() {
          timer.cancel();
          isRecendCode = true;
        });
      }
    });
  }

  // FUNCTION : Reset Timer
  void resetTimer({dynamic setState}) {
    totalSeconds = requestedOTP.isEmpty ? 30 : requestedOTP.first.validityTime;

    isRecendCode = false;
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (totalSeconds > 0) {
        setState(() {
          totalSeconds--;
        });
      } else {
        setState(() {
          timer.cancel();
          isRecendCode = true;
        });
      }
    });
  }

  //  --

  // Request OTP
  Future<bool> requestOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.forgotOtpRequest, body,
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        OtpResponceModel model = OtpResponceModel.fromJson(value.data);
        requestedOTP.clear();
        requestedOTP.add(model.data);
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (requestOTP) => $e");
    }

    return result;
  }

  // verify OTP
  Future<bool> verifyOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.otpVerify, body,
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        int resCode = value.data["Code"];
        if (resCode == 200 || resCode == 201) {
          debugPrint("OTP Verified!!!");
          result = true;
        }
      });
    } catch (e) {
      result = false;
      debugPrint("Func (verifyOTP) => $e");
    }

    return result;
  }

  // Change New Password
  Future<bool> changeNewPassword({required body}) async {
    bool resultValue = false;
    try {
      await engine
          .post(
        AppStrings.baseUrl + AppStrings.changeNewPassword,
        body,
        protected: true,
      )
          .then((value) {
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      debugPrint("Func (changeNewPassword) => $e");
    }
    return resultValue;
  }

  //login user with credentials
  Future<bool> userLogin(
      {required String userName,
      required String password,
      bool isGuest = false}) async {
    bool result = false;
    try {
      // before call api prepare json to send
      final sendBody = {
        "loginName": userName,
        "password": password,
        "TenantID": AppStrings.baseUrl == "http://gateway.dawn.dt/"
            ? AppStrings.localTenantID
            : AppStrings.liveTenantID,
      };

      await engine
          .post(AppStrings.baseUrl + AppStrings.login, sendBody,
              protected: false)
          .then(
        (value) {
          LoginResponseModel auth = LoginResponseModel.fromJson(value.data);

          // Store required values in shared pref
          SharedPref.putString(AppStrings.accessToken, auth.data!.bearerToken!);
          SharedPref.putString(
              AppStrings.refreshToken, auth.data!.refreshToken!);
          // set login status as false when guest used
          if (isGuest) {
            SharedPref.putBool(AppStrings.isLoggedIn, false);
          } else {
            SharedPref.putBool(AppStrings.isLoggedIn, true);
          }
          // Decode Bearer Token
          Map<String, dynamic> decodedToken =
              JwtDecoder.decode(auth.data!.bearerToken!);
          debugPrint('-----\n');
          debugPrint(decodedToken.toString());
          debugPrint('-----\n');

          BearerResponseModel decryptedData =
              BearerResponseModel.fromJson(decodedToken);
          // Since mobile number is not in BearerResponseModel, we manually add it while login
          SharedPref.putString(AppStrings.mobileWithCode, userName);
          SharedPref.putString(AppStrings.profileName, decryptedData.userName);
          SharedPref.putString(
              AppStrings.contactID, decryptedData.contactId.toString());
          SharedPref.putString(AppStrings.position,
              decryptedData.authRole.join(',').replaceAll(r'"', ''));

          result = true;
          debugPrint('User Logged in');
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (userLogin) => $e");
    }
    return result;
  }

  Future<bool> personalDetail({required String contactID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.personalDetailUrl + contactID,
              protected: true)
          .then(
        (value) {
          PersonalDetailModel model = PersonalDetailModel.fromJson(value.data);
          personalInfoDetail.clear();
          personalInfoDetail.add(model.data);
          SharedPref.putString(AppStrings.rollNo, model.data.rollNumber);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }
}
