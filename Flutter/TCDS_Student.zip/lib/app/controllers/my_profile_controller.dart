import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../models/profile/course_detail_model.dart';
import '../models/profile/personal_detail_model.dart';

class MyProfileController extends GetxController {
  Engine engine = Engine();

  RxList<PersonalDetail> stdntPersonalDetail = <PersonalDetail>[].obs;
  RxList<CourseDetail> stdntCourseDetail = <CourseDetail>[].obs;
  // screen loader bools
  RxBool centresScrLoader = false.obs;
  RxBool centresListLoader = false.obs;

  //fetch student detail
  Future<bool> personalDetail({required String studentId}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.personalData + studentId,
              protected: true)
          .then(
        (value) {
          PersonalDetailModel model = PersonalDetailModel.fromJson(value.data);
          // log(jsonEncode(model.toJson()));
          stdntPersonalDetail.clear();
          stdntPersonalDetail.add(model.data);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }

  //fetch course detail
  Future<bool> courseDetail({required String batchMappingID}) async {
    bool result = false;
    try {
      await engine
          .get(
              AppStrings.baseUrl + AppStrings.courseDetailData + batchMappingID,
              protected: true)
          .then(
        (value) {
          CorseDetailModel model = CorseDetailModel.fromJson(value.data);
          stdntCourseDetail.clear();
          stdntCourseDetail.add(model.data);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }
}
