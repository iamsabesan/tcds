import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../models/common/countries.dart';
import '../models/common/district.dart';
import '../models/common/state.dart';

// due to collapse in Obx we use separate controller for address details dropdownn
class RegisterAddressController extends GetxController {
  Engine engine = Engine();

  RxList<Country> comcountries = <Country>[].obs;
  RxList<States> comstate = <States>[].obs;
  RxList<District> comdistrict = <District>[].obs;
  // RxList<Taluk> comtaluk = <Taluk>[].obs;

  RxList<Country> permcountries = <Country>[].obs;
  RxList<States> permstate = <States>[].obs;
  RxList<District> permdistrict = <District>[].obs;
  // RxList<Taluk> permtaluk = <Taluk>[].obs;

  // get countries list
  Future<bool> fetchComCountries() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.coutriesList, protected: true)
          .then(
        (value) {
          CountriesModel model = CountriesModel.fromJson(value.data);
          comcountries.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchComCountries) => $e");
    }
    return result;
  }

  // get countries list
  Future<bool> fetchPermCountries() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.coutriesList, protected: true)
          .then(
        (value) {
          CountriesModel model = CountriesModel.fromJson(value.data);
          permcountries.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchPermCountries) => $e");
    }
    return result;
  }

  // fetch state list
  Future<bool> fetchComState({required String countryID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.statesList + countryID,
              protected: true)
          .then(
        (value) {
          StateModel model = StateModel.fromJson(value.data);
          comstate.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchComState) => $e");
    }
    return result;
  }

  // fetch state list
  Future<bool> fetchPermState({required String countryID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.statesList + countryID,
              protected: true)
          .then(
        (value) {
          StateModel model = StateModel.fromJson(value.data);
          permstate.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchPermState) => $e");
    }
    return result;
  }

  // fetch district list
  Future<bool> fetchComDistrict({required String stateID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.districtList + stateID,
              protected: true)
          .then(
        (value) {
          DistrictModel model = DistrictModel.fromJson(value.data);
          comdistrict.value = model.data;

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchComDistrict) => $e");
    }
    return result;
  }

  // fetch district list
  Future<bool> fetchPermDistrict({required String stateID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.districtList + stateID,
              protected: true)
          .then(
        (value) {
          DistrictModel model = DistrictModel.fromJson(value.data);
          permdistrict.value = model.data;

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchPermDistrict) => $e");
    }
    return result;
  }

  /* // fetch taluk list
  Future<bool> fetchComTaluk({required String districtName}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.talukList + districtName,
              protected: true)
          .then(
        (value) {
          TalukModel model = TalukModel.fromJson(value.data);
          comtaluk.value = model.data;

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchComTaluk) => $e");
    }
    return result;
  }

  // fetch taluk list
  Future<bool> fetchPermTaluk({required String districtName}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.talukList + districtName,
              protected: true)
          .then(
        (value) {
          TalukModel model = TalukModel.fromJson(value.data);
          permtaluk.value = model.data;

          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchPermTaluk) => $e");
    }
    return result;
  } */
}
