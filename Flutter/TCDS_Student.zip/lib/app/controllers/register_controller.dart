import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tcds_student/api_engine/engine.dart';
import 'package:tcds_student/constants/app_string.dart';
import '../../constants/shared_pref.dart';
import '../models/common/gender_types.dart';
import '../models/common/image_responce.dart';
import '../models/common/phone_code.dart';
import '../models/registeration/centre_detail.dart';
import '../models/registeration/centres.dart';
import '../models/registeration/document_upload.dart';
import '../models/registeration/franchise_district.dart';
import '../models/registeration/franchise_state.dart';
import '../models/registeration/franchise_taluk.dart';
import '../models/registeration/how_know_tcds.dart';
import '../models/registeration/occupation.dart';
import '../models/registeration/otp_responce.dart';
import '../models/registeration/reasons_tcds.dart';
import '../models/registeration/register_purpose.dart';
import '../models/registeration/relationships.dart';
import '../models/registeration/user_creation_model.dart';

class RegisterController extends GetxController {
  Engine engine = Engine();
  RxList<KnowData> knowTCDSData = <KnowData>[].obs;
  RxList<PurposeData> purposesData = <PurposeData>[].obs;

  /* RxList<Country> countries = <Country>[].obs;
  RxList<States> state = <States>[].obs;
  RxList<District> district = <District>[].obs;
  RxList<Taluk> taluk = <Taluk>[].obs; */

  RxList<CentreData> centres = <CentreData>[].obs;
  // latest fetched image model
  RxList<ImageModel> imageResponce = <ImageModel>[].obs;
  // phone codes list
  RxList<PhoneCodeList> phoneCodesData = <PhoneCodeList>[].obs;
  // gender types
  RxList<GenderTypeData> genderTypesList = <GenderTypeData>[].obs;
  // requested otp data holder
  RxList<OTPData> requestedOTP = <OTPData>[].obs;
  // qualifications list
  // RxList<Qualification> qualificationsList = <Qualification>[].obs;
  // occupations list
  RxList<Occupation> occupationsList = <Occupation>[].obs;
  // relationships list
  RxList<Relationship> relationshipsList = <Relationship>[].obs;
  // relationship dropdown value holder
  Relationship? relationValue;
  RxList<CentreDetailData> centreDetailValue = <CentreDetailData>[].obs;
  // CenterDetailModel? centreDetailValue;
  // Reasons list for to select TCDS
  RxList<Reason> reasonsList = <Reason>[].obs;
//document upload list
  RxList<DocumentUploadData> latestUploadedDocument =
      <DocumentUploadData>[].obs;

  // screen loader bools
  RxBool centresScrLoader = false.obs;
  RxBool centresListLoader = false.obs;

  // franchise available state,district and taluks
  RxList<FranchiseState> franchiseState = <FranchiseState>[].obs;
  RxList<FranchiseDistrict> franchiseDistrict = <FranchiseDistrict>[].obs;
  RxList<FranchiseTaluk> franchiseTaluk = <FranchiseTaluk>[].obs;

  // fetch centres and course details based on given locations
  Future<bool> fetchCentres({required dynamic payload}) async {
    bool result = false;
    centresListLoader.value = true;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.centreAndCourseDetails, payload,
              protected: true)
          .then(
        (value) async {
          // log(jsonEncode(value.data));
          CentresModel model = CentresModel.fromJson(value.data);
          centres.value = model.data;
          // after fetched centres let's loop through it for to get and store owner image as base64
          for (var i = 0; i < centres.length; i++) {
            if (centres[i].ownerImage != null) {
              // fetch base64 for an owner image
              await getImageDetails(imgID: centres[i].ownerImage!.contentUrl);
              // after fetched, store it inside ownerimage model for easy reference
              if (imageResponce.isNotEmpty) {
                // split raw base64 cause data does not contain it as raw
                String splitRawBase64 = imageResponce[0].data.split(",")[1];
                centres[i].ownerImage!.fetchedBase64 = splitRawBase64;
              } else {
                // if not fetched, let's assign null to identify later
                centres[i].ownerImage!.fetchedBase64 = null;
              }
            }
          }
          result = true;
          centresListLoader.value = false;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchCentres) => $e");
    }
    return result;
  }

  // fetch franchise state list
  Future<bool> fetchFranchiseState() async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseStates}india',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseStateModel model = FranchiseStateModel.fromJson(value.data);
          franchiseState.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseState) => $e");
    }
    return result;
  }

  // fetch franchise district list
  Future<bool> fetchFranchiseDistrict({required String stateName}) async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseDistrict}$stateName',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseDistrictModel model =
              FranchiseDistrictModel.fromJson(value.data);
          franchiseDistrict.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseDistrict) => $e");
    }
    return result;
  }

  // fetch franchise taluk list
  Future<bool> fetchFranchiseTaluk({required String districtName}) async {
    bool result = false;
    try {
      await engine
          .get('${AppStrings.baseUrl}${AppStrings.franchiseTaluk}$districtName',
              protected: true)
          .then(
        (value) {
          // log(jsonEncode(value.data));
          FranchiseTalukModel model = FranchiseTalukModel.fromJson(value.data);
          franchiseTaluk.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchFranchiseTaluk) => $e");
    }
    return result;
  }

  // Get image details
  Future<bool> getImageDetails({required String imgID}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getImageDetails + imgID,
              protected: true)
          .then(
        (value) {
          ImageModel model = ImageModel.fromJson(value.data);
          imageResponce.clear();
          imageResponce.add(model);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (getImageDetails) => $e");
    }
    return result;
  }

  // Get Phone Codes
  Future<bool> getPhoneCodes() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.phoneCodeUrl, protected: true)
          .then((value) {
        PhoneCodeResponseModel model =
            PhoneCodeResponseModel.fromJson(value.data);
        phoneCodesData.value = model.data;
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getPhoneCodes) => $e");
    }

    return result;
  }

  // get gender types
  Future<bool> getGenderTypes() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.getGenderTypes, protected: true)
          .then((value) {
        GenderTypesResponseModel model =
            GenderTypesResponseModel.fromJson(value.data);
        genderTypesList.value = model.data;
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getGenderTypes) => $e");
    }

    return result;
  }

  // request OTP
  Future<bool> requestOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.otpRequest, body,
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        OtpResponceModel model = OtpResponceModel.fromJson(value.data);
        requestedOTP.clear();
        requestedOTP.add(model.data);
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (requestOTP) => $e");
    }

    return result;
  }

  // resend OTP
  Future<bool> resendOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.otpResend, body,
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        OtpResponceModel model = OtpResponceModel.fromJson(value.data);
        requestedOTP.clear();
        requestedOTP.add(model.data);
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (resendOTP) => $e");
    }

    return result;
  }

  // verify OTP
  Future<bool> verifyOTP({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.otpVerify, body,
              protected: true)
          .then((value) {
        // log(jsonEncode(value.data));
        int resCode = value.data["Code"];
        if (resCode == 200 || resCode == 201) {
          debugPrint("OTP Verified!!!");
          result = true;
        }
      });
    } catch (e) {
      result = false;
      debugPrint("Func (verifyOTP) => $e");
    }

    return result;
  }

  /*  // get qualifications data
  Future<bool> getQualifications() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.qualification, protected: true)
          .then((value) {
        QualificationModel model = QualificationModel.fromJson(value.data);
        qualificationsList.value = model.data;
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getQualifications) => $e");
    }

    return result;
  } */

  // get occupations data
  Future<bool> getOccupations() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.occupation, protected: true)
          .then((value) {
        OccupationModel model = OccupationModel.fromJson(value.data);
        occupationsList.value = model.data;
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getOccupations) => $e");
    }

    return result;
  }

  // get relationships data
  Future<bool> getRelationships() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.relationships, protected: true)
          .then((value) {
        RelationshipModel model = RelationshipModel.fromJson(value.data);
        relationshipsList.value = model.data;
        // store initial value in relation dropdown value
        if (relationshipsList.isNotEmpty) {
          relationValue = relationshipsList[0];
        } else {
          relationValue = null;
        }

        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getRelationships) => $e");
    }

    return result;
  }

  // get reasons data to select TCDS
  Future<bool> getTCDSReasons() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.reasonsTCDS, protected: true)
          .then((value) {
        ReasonTcdsModel model = ReasonTcdsModel.fromJson(value.data);
        reasonsList.value = model.data;
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (getTCDSReasons) => $e");
    }

    return result;
  }

  Future<bool> fetchCentreDetails() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.centreDetail, protected: true)
          .then(
        (value) {
          CenterDetailModel model = CenterDetailModel.fromJson(value.data);
          centreDetailValue.clear();
          centreDetailValue.add(model.data);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchCountries) => $e");
    }
    return result;
  }

  Future<bool> updateProfilePicture({
    required dynamic formData,
  }) async {
    bool resultValue = false;
    debugPrint(formData.runtimeType.toString());
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.imageUpload, formData,
              custom: "multipart/form-data", protected: true)
          .then((value) {
        debugPrint('Profile Updated Successfully');
        DocumentUploadResponseModel model =
            DocumentUploadResponseModel.fromJson(value.data);
        latestUploadedDocument.clear();
        latestUploadedDocument.add(model.data);

        resultValue = true;
      });
    } catch (e) {
      debugPrint(e.toString());
    }

    return resultValue;
  }

//user create
  Future<bool> createUser({required dynamic body}) async {
    bool result = false;
    try {
      await engine
          .post(AppStrings.baseUrl + AppStrings.createUser, body,
              protected: true)
          .then((value) {
        UserCreationModel model = UserCreationModel.fromJson(value.data);
        SharedPref.putString(AppStrings.studentEnquiryID, model.data);
        result = true;
      });
    } catch (e) {
      result = false;
      debugPrint("Func (createUser) => $e");
    }

    return result;
  }

  //fetch student detail

/*   Future<bool> studentDetail({required String studentEnquiryId}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.userData + studentEnquiryId,
              protected: true)
          .then(
        (value) {
          TalukModel model = TalukModel.fromJson(value.data);
          taluk.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  } */

  // fetch dropdown data for how you know TCDS centre
  Future<bool> fetchHowKnowTCDS() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.knowTCDSfrom, protected: true)
          .then(
        (value) {
          HowKnowTcdsModel model = HowKnowTcdsModel.fromJson(value.data);
          knowTCDSData.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchHowKnowTCDS) => $e");
    }
    return result;
  }

//  fetch dropdown data for purpose of registeration
  Future<bool> fetchPurposes() async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.purpose, protected: true)
          .then(
        (value) {
          RegisterationPurposeModel model =
              RegisterationPurposeModel.fromJson(value.data);
          purposesData.value = model.data;
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (fetchPurposes) => $e");
    }
    return result;
  }
}
