import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../api_engine/engine.dart';
import '../../constants/app_string.dart';
import '../models/registration_status/document_download.dart';
import '../models/registration_status/student_enquiry_model.dart';

class RegistrationStatusController extends GetxController {
  Engine engine = Engine();

  RxList<EnquiryDetail> stdntEnquiryDetail = <EnquiryDetail>[].obs;
  // screen loader bools
  RxBool centresScrLoader = false.obs;
  RxBool centresListLoader = false.obs;
  RxList<DocumentDownload> latestDownloadedDocument = <DocumentDownload>[].obs;

  //fetch student detail
  Future<bool> studentDetail({required String studentEnquiryId}) async {
    bool result = false;
    try {
      await engine
          .get(AppStrings.baseUrl + AppStrings.userData + studentEnquiryId,
              protected: true)
          .then(
        (value) {
          StudentEnquiryModel model = StudentEnquiryModel.fromJson(value.data);
          stdntEnquiryDetail.clear();
          stdntEnquiryDetail.add(model.data);
          result = true;
        },
      );
    } catch (e) {
      result = false;
      debugPrint("Func (studentDetail) => $e");
    }
    return result;
  }

  // document download
  Future<bool> documentDownload({required String documentID}) async {
    bool resultValue = false;
    try {
      await engine
          .get(
        AppStrings.baseUrl + AppStrings.documentDownloadBase64 + documentID,
        protected: true,
      )
          .then((value) {
        DocumentDownloadResponseModel model =
            DocumentDownloadResponseModel.fromJson(value.data);
        latestDownloadedDocument.clear();
        latestDownloadedDocument.add(model.data);
        resultValue = true;
      });
    } catch (e) {
      resultValue = false;
      debugPrint("Func (documentDownload)=> $e");
    }

    return resultValue;
  }
}
