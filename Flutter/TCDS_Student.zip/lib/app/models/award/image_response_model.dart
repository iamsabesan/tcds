// To parse this JSON data, do
//
//     final imageResponseModel = imageResponseModelFromJson(jsonString);

import 'dart:convert';

ImageResponseModel imageResponseModelFromJson(String str) => ImageResponseModel.fromJson(json.decode(str));

String imageResponseModelToJson(ImageResponseModel data) => json.encode(data.toJson());

class ImageResponseModel {
  int code;
  String message;
  String data;

  ImageResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory ImageResponseModel.fromJson(Map<String, dynamic> json) => ImageResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
