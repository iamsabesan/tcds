class AwardResponseModel {
  int code;
  String message;
  List<AchieversAwardList> data;

  AwardResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory AwardResponseModel.fromJson(Map<String, dynamic> json) =>
      AwardResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<AchieversAwardList>.from(
            json["Data"].map((x) => AchieversAwardList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class AchieversAwardList {
  String tenantBranchId;
  String contactId;
  String contactName;
  String state;
  String district;
  String area;
  String taluk;
  int totalCount;
  int rank;
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;
  String? base64Image;
  int stateCount;
  String franchiseeCode;
  String centreName;
  int purchaseRank;
  String districtRank;

  AchieversAwardList({
    required this.tenantBranchId,
    required this.contactId,
    required this.contactName,
    required this.state,
    required this.district,
    required this.area,
    required this.taluk,
    required this.totalCount,
    required this.rank,
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
    required this.stateCount,
    required this.franchiseeCode,
    required this.centreName,
    this.base64Image,
    required this.purchaseRank,
    required this.districtRank,
  });

  factory AchieversAwardList.fromJson(Map<String, dynamic> json) =>
      AchieversAwardList(
        tenantBranchId: json["TenantBranchID"],
        contactId: json["ContactID"],
        contactName: json["ContactName"],
        state: json["State"],
        district: json["District"],
        area: json["Area"],
        taluk: json["Taluk"],
        totalCount: json["TotalCount"],
        rank: json["Rank"],
        documentName: json["DocumentName"],
        fileName: json["FileName"],
        documentType: json["DocumentType"],
        contentUrl: json["ContentUrl"],
        stateCount: json["StateCount"],
        purchaseRank: json["PurchaseRank"],
        franchiseeCode: json["FranchiseeCode"],
        centreName: json["CentreName"],
        districtRank: json["DistrictRank"],
      );

  Map<String, dynamic> toJson() => {
        "TenantBranchID": tenantBranchId,
        "ContactID": contactId,
        "ContactName": contactName,
        "State": state,
        "District": district,
        "Area": area,
        "Taluk": taluk,
        "TotalCount": totalCount,
        "Rank": rank,
        "DocumentName": documentName,
        "FileName": fileName,
        "DocumentType": documentType,
        "ContentUrl": contentUrl,
        "DistrictRank": districtRank,
      };
}
