// To parse this JSON data, do
//
//     final levelResponseModel = levelResponseModelFromJson(jsonString);

import 'dart:convert';

LevelResponseModel levelResponseModelFromJson(String str) => LevelResponseModel.fromJson(json.decode(str));

String levelResponseModelToJson(LevelResponseModel data) => json.encode(data.toJson());

class LevelResponseModel {
  int code;
  String message;
  List<String> data;

  LevelResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory LevelResponseModel.fromJson(Map<String, dynamic> json) => LevelResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<String>.from(json["Data"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x)),
  };
}
