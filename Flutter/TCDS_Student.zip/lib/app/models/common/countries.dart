import 'dart:convert';

CountriesModel countriesModelFromJson(String str) =>
    CountriesModel.fromJson(json.decode(str));

String countriesModelToJson(CountriesModel data) => json.encode(data.toJson());

class CountriesModel {
  int code;
  String message;
  List<Country> data;

  CountriesModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CountriesModel.fromJson(Map<String, dynamic> json) => CountriesModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Country>.from(json["Data"].map((x) => Country.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Country {
  int countryId;
  String countryName;

  Country({
    required this.countryId,
    required this.countryName,
  });

  factory Country.fromJson(Map<String, dynamic> json) => Country(
        countryId: json["CountryID"],
        countryName: json["CountryName"],
      );

  Map<String, dynamic> toJson() => {
        "CountryID": countryId,
        "CountryName": countryName,
      };
}
