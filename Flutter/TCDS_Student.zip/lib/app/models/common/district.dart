import 'dart:convert';

DistrictModel districtModelFromJson(String str) =>
    DistrictModel.fromJson(json.decode(str));

String districtModelToJson(DistrictModel data) => json.encode(data.toJson());

class DistrictModel {
  int code;
  String message;
  List<District> data;

  DistrictModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DistrictModel.fromJson(Map<String, dynamic> json) => DistrictModel(
        code: json["Code"],
        message: json["Message"],
        data:
            List<District>.from(json["Data"].map((x) => District.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class District {
  int districtId;
  String districtName;

  District({
    required this.districtId,
    required this.districtName,
  });

  factory District.fromJson(Map<String, dynamic> json) => District(
        districtId: json["DistrictID"],
        districtName: json["DistrictName"],
      );

  Map<String, dynamic> toJson() => {
        "DistrictID": districtId,
        "DistrictName": districtName,
      };
}
