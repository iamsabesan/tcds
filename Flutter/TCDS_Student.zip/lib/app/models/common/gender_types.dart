import 'dart:convert';

GenderTypesResponseModel genderTypesResponseModelFromJson(String str) =>
    GenderTypesResponseModel.fromJson(json.decode(str));

String genderTypesResponseModelToJson(GenderTypesResponseModel data) =>
    json.encode(data.toJson());

class GenderTypesResponseModel {
  int code;
  String message;
  List<GenderTypeData> data;

  GenderTypesResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory GenderTypesResponseModel.fromJson(Map<String, dynamic> json) =>
      GenderTypesResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: List<GenderTypeData>.from(
            json["Data"].map((x) => GenderTypeData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class GenderTypeData {
  int genderId;
  String genderName;

  GenderTypeData({
    required this.genderId,
    required this.genderName,
  });

  factory GenderTypeData.fromJson(Map<String, dynamic> json) => GenderTypeData(
        genderId: json["GenderID"],
        genderName: json["GenderName"],
      );

  Map<String, dynamic> toJson() => {
        "GenderID": genderId,
        "GenderName": genderName,
      };
}
