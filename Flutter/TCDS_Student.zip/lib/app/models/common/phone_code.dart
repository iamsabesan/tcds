

import 'dart:convert';

PhoneCodeResponseModel phoneCodeResponseModelFromJson(String str) => PhoneCodeResponseModel.fromJson(json.decode(str));

String phoneCodeResponseModelToJson(PhoneCodeResponseModel data) => json.encode(data.toJson());

class PhoneCodeResponseModel {
  int code;
  String message;
  List<PhoneCodeList> data;

  PhoneCodeResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory PhoneCodeResponseModel.fromJson(Map<String, dynamic> json) => PhoneCodeResponseModel(
    code: json["Code"],
    message: json["Message"],
    data: List<PhoneCodeList>.from(json["Data"].map((x) => PhoneCodeList.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class PhoneCodeList {
  String phoneCode;
  int phoneNumberLength;

  PhoneCodeList({
    required this.phoneCode,
    required this.phoneNumberLength,
  });

  factory PhoneCodeList.fromJson(Map<String, dynamic> json) => PhoneCodeList(
    phoneCode: json["PhoneCode"],
    phoneNumberLength: json["PhoneNumberLength"],
  );

  Map<String, dynamic> toJson() => {
    "PhoneCode": phoneCode,
    "PhoneNumberLength": phoneNumberLength,
  };
}
