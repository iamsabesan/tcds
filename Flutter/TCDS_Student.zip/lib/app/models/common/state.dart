import 'dart:convert';

StateModel stateModelFromJson(String str) =>
    StateModel.fromJson(json.decode(str));

String stateModelToJson(StateModel data) => json.encode(data.toJson());

class StateModel {
  int code;
  String message;
  List<States> data;

  StateModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StateModel.fromJson(Map<String, dynamic> json) => StateModel(
        code: json["Code"],
        message: json["Message"],
        data: List<States>.from(json["Data"].map((x) => States.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class States {
  int stateProvinceId;
  String stateProvinceName;

  States({
    required this.stateProvinceId,
    required this.stateProvinceName,
  });

  factory States.fromJson(Map<String, dynamic> json) => States(
        stateProvinceId: json["StateProvinceID"],
        stateProvinceName: json["StateProvinceName"],
      );

  Map<String, dynamic> toJson() => {
        "StateProvinceID": stateProvinceId,
        "StateProvinceName": stateProvinceName,
      };
}
