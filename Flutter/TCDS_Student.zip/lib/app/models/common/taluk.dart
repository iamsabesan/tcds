import 'dart:convert';

TalukModel talukModelFromJson(String str) =>
    TalukModel.fromJson(json.decode(str));

String talukModelToJson(TalukModel data) => json.encode(data.toJson());

class TalukModel {
  int code;
  String message;
  List<Taluk> data;

  TalukModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory TalukModel.fromJson(Map<String, dynamic> json) => TalukModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Taluk>.from(json["Data"].map((x) => Taluk.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Taluk {
  String taluk;

  Taluk({
    required this.taluk,
  });

  factory Taluk.fromJson(Map<String, dynamic> json) => Taluk(
        taluk: json["Taluk"],
      );

  Map<String, dynamic> toJson() => {
        "Taluk": taluk,
      };
}
