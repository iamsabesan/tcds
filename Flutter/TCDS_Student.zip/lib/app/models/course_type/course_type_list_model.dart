// To parse this JSON data, do
//
//     final corseTypeListModel = corseTypeListModelFromJson(jsonString);

import 'dart:convert';

CorseTypeListModel corseTypeListModelFromJson(String str) => CorseTypeListModel.fromJson(json.decode(str));

String corseTypeListModelToJson(CorseTypeListModel data) => json.encode(data.toJson());

class CorseTypeListModel {
  int code;
  String message;
  List<CourseTypeData> data;

  CorseTypeListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CorseTypeListModel.fromJson(Map<String, dynamic> json) => CorseTypeListModel(
    code: json["Code"],
    message: json["Message"],
    data: List<CourseTypeData>.from(json["Data"].map((x) => CourseTypeData.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class CourseTypeData {
  String courseTypeId;
  String courseType;

  CourseTypeData({
    required this.courseTypeId,
    required this.courseType,
  });

  factory CourseTypeData.fromJson(Map<String, dynamic> json) => CourseTypeData(
    courseTypeId: json["CourseTypeID"],
    courseType: json["CourseType"],
  );

  Map<String, dynamic> toJson() => {
    "CourseTypeID": courseTypeId,
    "CourseType": courseType,
  };
}
