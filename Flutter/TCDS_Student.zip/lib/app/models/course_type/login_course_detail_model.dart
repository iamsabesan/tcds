class LoginCourseListModel {
  int code;
  String message;
  List<LoginCourseList> data;

  LoginCourseListModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory LoginCourseListModel.fromJson(Map<String, dynamic> json) =>
      LoginCourseListModel(
        code: json["Code"],
        message: json["Message"],
        data: List<LoginCourseList>.from(
            json["Data"].map((x) => LoginCourseList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class LoginCourseList {
  String courseId;
  String shortName;
  String course;
  String courseType;
  String duration;
  String durationType;
  String certificatePrintName;
  double courseFees;
  double examFees;
  double admissionFees;
  double totalFees;
  String eligibility;
  int semester;
  List<SubjectMapping> subjectMapping;

  LoginCourseList({
    required this.courseId,
    required this.shortName,
    required this.course,
    required this.courseType,
    required this.duration,
    required this.durationType,
    required this.certificatePrintName,
    required this.courseFees,
    required this.examFees,
    required this.admissionFees,
    required this.totalFees,
    required this.semester,
    required this.eligibility,
    required this.subjectMapping,
  });

  factory LoginCourseList.fromJson(Map<String, dynamic> json) =>
      LoginCourseList(
        courseId: json["CourseID"],
        shortName: json["ShortName"],
        course: json["Course"],
        courseType: json["CourseType"],
        duration: json["Duration"],
        durationType: json["DurationType"],
        certificatePrintName: json["CertificatePrintName"],
        courseFees: json["CourseFees"],
        examFees: json["ExamFees"],
        admissionFees: json["AdmissionFees"],
        totalFees: json["TotalFees"],
        semester: json["Semester"],
        eligibility: json["Eligibility"],
        subjectMapping: List<SubjectMapping>.from(
            json["SubjectMapping"].map((x) => SubjectMapping.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CourseID": courseId,
        "ShortName": shortName,
        "Course": course,
        "CourseType": courseType,
        "Duration": duration,
        "DurationType": durationType,
        "CertificatePrintName": certificatePrintName,
        "CourseFees": courseFees,
        "ExamFees": examFees,
        "AdmissionFees": admissionFees,
        "TotalFees": totalFees,
        "Semester": semester,
        "Eligibility": eligibility,
        "SubjectMapping":
            List<dynamic>.from(subjectMapping.map((x) => x.toJson())),
      };
}

class SubjectMapping {
  String courseId;
  String subjectId;
  String subjectName;
  int semester;
  int theoryMarks;
  int practicalMarks;
  int totalMarks;

  SubjectMapping({
    required this.courseId,
    required this.subjectId,
    required this.subjectName,
    required this.semester,
    required this.theoryMarks,
    required this.practicalMarks,
    required this.totalMarks,
  });

  factory SubjectMapping.fromJson(Map<String, dynamic> json) => SubjectMapping(
        courseId: json["CourseID"],
        subjectId: json["SubjectID"],
        subjectName: json["SubjectName"],
        semester: json["Semester"],
        theoryMarks: json["TheoryMarks"],
        practicalMarks: json["PracticalMarks"],
        totalMarks: json["TotalMarks"],
      );

  Map<String, dynamic> toJson() => {
        "CourseID": courseId,
        "SubjectID": subjectId,
        "SubjectName": subjectName,
        "Semester": semester,
        "TheoryMarks": theoryMarks,
        "PracticalMarks": practicalMarks,
        "TotalMarks": totalMarks,
      };
}
