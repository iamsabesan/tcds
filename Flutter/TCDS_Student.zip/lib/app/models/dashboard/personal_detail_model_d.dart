class PersonalDetailModel {
  int code;
  String message;
  PersonalInfo data;

  PersonalDetailModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory PersonalDetailModel.fromJson(Map<String, dynamic> json) =>
      PersonalDetailModel(
        code: json["Code"],
        message: json["Message"],
        data: PersonalInfo.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class PersonalInfo {
  String contactId;
  String rollNumber;
  String gender;
  String studentName;
  String dateOfBirth;
  String phoneCode;
  String phone;
  String alternatePhoneCode;
  String alternatePhone;
  String email;
  String qualification;
  String guardianType;
  String fatherName;
  String occupation;
  List<Address> address;
  List<StudentImage> studentImages;
  List<Course> courses;

  PersonalInfo({
    required this.contactId,
    required this.rollNumber,
    required this.gender,
    required this.studentName,
    required this.dateOfBirth,
    required this.phoneCode,
    required this.phone,
    required this.alternatePhoneCode,
    required this.alternatePhone,
    required this.email,
    required this.qualification,
    required this.guardianType,
    required this.fatherName,
    required this.occupation,
    required this.address,
    required this.studentImages,
    required this.courses,
  });

  factory PersonalInfo.fromJson(Map<String, dynamic> json) => PersonalInfo(
        contactId: json["ContactID"],
        rollNumber: json["RollNumber"],
        gender: json["Gender"],
        studentName: json["StudentName"],
        dateOfBirth: json["DateOfBirth"],
        phoneCode: json["PhoneCode"],
        phone: json["Phone"],
        alternatePhoneCode: json["AlternatePhoneCode"],
        alternatePhone: json["AlternatePhone"],
        email: json["Email"],
        qualification: json["Qualification"],
        guardianType: json["GuardianType"],
        fatherName: json["FatherName"],
        occupation: json["Occupation"],
        address:
            List<Address>.from(json["Address"].map((x) => Address.fromJson(x))),
        studentImages: List<StudentImage>.from(
            json["StudentImages"].map((x) => StudentImage.fromJson(x))),
        courses:
            List<Course>.from(json["Courses"].map((x) => Course.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "ContactID": contactId,
        "RollNumber": rollNumber,
        "Gender": gender,
        "StudentName": studentName,
        "DateOfBirth":
            dateOfBirth, //"${dateOfBirth.year.toString().padLeft(4, '0')}-${dateOfBirth.month.toString().padLeft(2, '0')}-${dateOfBirth.day.toString().padLeft(2, '0')}",
        "PhoneCode": phoneCode,
        "Phone": phone,
        "AlternatePhoneCode": alternatePhoneCode,
        "AlternatePhone": alternatePhone,
        "Email": email,
        "Qualification": qualification,
        "GuardianType": guardianType,
        "FatherName": fatherName,
        "Occupation": occupation,
        "Address": List<dynamic>.from(address.map((x) => x.toJson())),
        // "StudentImages":
        //     List<dynamic>.from(studentImages.map((x) => x.toJson())),
        "Courses": List<dynamic>.from(courses.map((x) => x.toJson())),
      };
}

class Address {
  String contactId;
  String addressTypeId;
  String addressType;
  String address1;
  String address2;
  String area;
  String district;
  String state;
  String country;
  String pincode;

  Address({
    required this.contactId,
    required this.addressTypeId,
    required this.addressType,
    required this.address1,
    required this.address2,
    required this.area,
    required this.district,
    required this.state,
    required this.country,
    required this.pincode,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        contactId: json["ContactID"],
        addressTypeId: json["AddressTypeID"],
        addressType: json["AddressType"],
        address1: json["Address1"],
        address2: json["Address2"],
        area: json["Area"],
        district: json["District"],
        state: json["State"],
        country: json["Country"],
        pincode: json["Pincode"],
      );

  Map<String, dynamic> toJson() => {
        "ContactID": contactId,
        "AddressTypeID": addressTypeId,
        "AddressType": addressType,
        "Address1": address1,
        "Address2": address2,
        "Area": area,
        "District": district,
        "State": state,
        "Country": country,
        "Pincode": pincode,
      };
}

class Course {
  String fullName;
  String shortName;
  String studentId;
  String batchMappingId;
  StudentCourse studentCourse;

  Course({
    required this.fullName,
    required this.shortName,
    required this.studentId,
    required this.batchMappingId,
    required this.studentCourse,
  });

  factory Course.fromJson(Map<String, dynamic> json) => Course(
        fullName: json["FullName"],
        shortName: json["ShortName"],
        studentId: json["StudentID"],
        batchMappingId: json["BatchMappingID"],
        studentCourse: StudentCourse.fromJson(json["studentCourse"]),
      );

  Map<String, dynamic> toJson() => {
        "FullName": fullName,
        "ShortName": shortName,
        "StudentID": studentId,
        "BatchMappingID": batchMappingId,
        "studentCourse": studentCourse.toJson(),
      };
}

class StudentImage {
  String contactId;
  String? profileBase64;
  String mimeType;

  StudentImage({
    required this.contactId,
    required this.profileBase64,
    required this.mimeType,
  });

  factory StudentImage.fromJson(Map<String, dynamic> json) => StudentImage(
        contactId: json["ContactID"],
        profileBase64: json["ProfileBase64"],
        mimeType: json["MIMEType"],
      );

  Map<String, dynamic> toJson() => {
        "ContactID": contactId,
        "ProfileBase64": profileBase64,
        "MIMEType": mimeType,
      };
}

class StudentCourse {
  CourseDetails course;
  Batch batch;
  List<Material> materials;
  List<Payment> payments;
  List<dynamic> marksheet;
  Certificate certificate;

  StudentCourse({
    required this.course,
    required this.batch,
    required this.materials,
    required this.payments,
    required this.marksheet,
    required this.certificate,
  });

  factory StudentCourse.fromJson(Map<String, dynamic> json) => StudentCourse(
        course: CourseDetails.fromJson(json["Course"]),
        batch: Batch.fromJson(json["Batch"]),
        materials: List<Material>.from(
            json["Materials"].map((x) => Material.fromJson(x))),
        payments: List<Payment>.from(
            json["Payments"].map((x) => Payment.fromJson(x))),
        marksheet: List<dynamic>.from(json["Marksheet"].map((x) => x)),
        certificate: Certificate.fromJson(json["Certificate"]),
      );

  Map<String, dynamic> toJson() => {
        "Course": course.toJson(),
        "Batch": batch.toJson(),
        "Materials": List<dynamic>.from(materials.map((x) => x.toJson())),
        "Payments": List<dynamic>.from(payments.map((x) => x.toJson())),
        "Marksheet": List<dynamic>.from(marksheet.map((x) => x)),
        "Certificate": certificate.toJson(),
      };
}

class Batch {
  String courseBatchId;
  String batchNumber;
  String batchType;
  String batchTrack;
  String facultyId;
  String facultyName;
  String startDate;
  String endDate;
  String startTime;
  String endTime;

  Batch({
    required this.courseBatchId,
    required this.batchNumber,
    required this.batchType,
    required this.batchTrack,
    required this.facultyId,
    required this.facultyName,
    required this.startDate,
    required this.endDate,
    required this.startTime,
    required this.endTime,
  });

  factory Batch.fromJson(Map<String, dynamic> json) => Batch(
        courseBatchId: json["CourseBatchID"],
        batchNumber: json["BatchNumber"],
        batchType: json["BatchType"],
        batchTrack: json["BatchTrack"],
        facultyId: json["FacultyID"],
        facultyName: json["FacultyName"],
        startDate: json["StartDate"],
        endDate: json["EndDate"],
        startTime: json["StartTime"],
        endTime: json["EndTime"],
      );

  Map<String, dynamic> toJson() => {
        "CourseBatchID": courseBatchId,
        "BatchNumber": batchNumber,
        "BatchType": batchType,
        "BatchTrack": batchTrack,
        "FacultyID": facultyId,
        "FacultyName": facultyName,
        "StartDate": startDate,
        "EndDate": endDate,
        "StartTime": startTime,
        "EndTime": endTime,
      };
}

class Certificate {
  String examIndentTransId;
  String certificateAndMarksheetId;
  String printType;
  String course;
  String date;
  String issuedDate;
  String status;

  Certificate({
    required this.examIndentTransId,
    required this.certificateAndMarksheetId,
    required this.printType,
    required this.course,
    required this.date,
    required this.issuedDate,
    required this.status,
  });

  factory Certificate.fromJson(Map<String, dynamic> json) => Certificate(
        examIndentTransId: json["ExamIndentTransID"],
        certificateAndMarksheetId: json["CertificateAndMarksheetID"],
        printType: json["PrintType"],
        course: json["Course"],
        date: json["Date"],
        issuedDate: json["IssuedDate"],
        status: json["Status"],
      );

  Map<String, dynamic> toJson() => {
        "ExamIndentTransID": examIndentTransId,
        "CertificateAndMarksheetID": certificateAndMarksheetId,
        "PrintType": printType,
        "Course": course,
        "Date": date,
        "IssuedDate": issuedDate,
        "Status": status,
      };
}

class CourseDetails {
  String courseBatchId;
  String courseId;
  String batchMappingId;
  String contactId;
  String course;
  String courseType;
  String duration;
  double courseFees;
  double discount;
  double totalFees;
  double paidFees;
  double balance;
  bool isActive;
  bool isCompleted;
  String reason;
  int totalSemesters;
  String status;
  String startDate;
  String endDate;
  String rollNumber;
  String studentName;
  String shortName;

  CourseDetails({
    required this.courseBatchId,
    required this.courseId,
    required this.batchMappingId,
    required this.contactId,
    required this.course,
    required this.courseType,
    required this.duration,
    required this.courseFees,
    required this.discount,
    required this.totalFees,
    required this.paidFees,
    required this.balance,
    required this.isActive,
    required this.isCompleted,
    required this.reason,
    required this.totalSemesters,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.rollNumber,
    required this.studentName,
    required this.shortName,
  });

  factory CourseDetails.fromJson(Map<String, dynamic> json) => CourseDetails(
        courseBatchId: json["CourseBatchID"],
        courseId: json["CourseID"],
        batchMappingId: json["BatchMappingID"],
        contactId: json["ContactID"],
        course: json["Course"],
        courseType: json["CourseType"],
        duration: json["Duration"],
        courseFees: json["CourseFees"],
        discount: json["Discount"],
        totalFees: json["TotalFees"],
        paidFees: json["PaidFees"],
        balance: json["Balance"],
        isActive: json["IsActive"],
        isCompleted: json["IsCompleted"],
        reason: json["Reason"],
        totalSemesters: json["TotalSemesters"],
        status: json["Status"],
        startDate: json["StartDate"],
        endDate: json["EndDate"],
        rollNumber: json["RollNumber"],
        studentName: json["StudentName"],
        shortName: json["ShortName"],
      );

  Map<String, dynamic> toJson() => {
        "CourseBatchID": courseBatchId,
        "CourseID": courseId,
        "BatchMappingID": batchMappingId,
        "ContactID": contactId,
        "Course": course,
        "CourseType": courseType,
        "Duration": duration,
        "CourseFees": courseFees,
        "Discount": discount,
        "TotalFees": totalFees,
        "PaidFees": paidFees,
        "Balance": balance,
        "IsActive": isActive,
        "IsCompleted": isCompleted,
        "Reason": reason,
        "TotalSemesters": totalSemesters,
        "Status": status,
        "StartDate": startDate,
        "EndDate": endDate,
        "RollNumber": rollNumber,
        "StudentName": studentName,
        "ShortName": shortName,
      };
}

class Material {
  String materialId;
  String materialName;
  int semester;
  String issuedDate;
  String status;
  int theoryMarks;
  int practicalMarks;
  int totalMarks;

  Material({
    required this.materialId,
    required this.materialName,
    required this.semester,
    required this.issuedDate,
    required this.status,
    required this.theoryMarks,
    required this.practicalMarks,
    required this.totalMarks,
  });

  factory Material.fromJson(Map<String, dynamic> json) => Material(
        materialId: json["MaterialID"],
        materialName: json["MaterialName"],
        semester: json["Semester"],
        issuedDate: json["IssuedDate"],
        status: json["Status"],
        theoryMarks: json["TheoryMarks"],
        practicalMarks: json["PracticalMarks"],
        totalMarks: json["TotalMarks"],
      );

  Map<String, dynamic> toJson() => {
        "MaterialID": materialId,
        "MaterialName": materialName,
        "Semester": semester,
        "IssuedDate": issuedDate,
        "Status": status,
        "TheoryMarks": theoryMarks,
        "PracticalMarks": practicalMarks,
        "TotalMarks": totalMarks,
      };
}

class Payment {
  String tenantBranchTransId;
  String transId;
  String receiptDate;
  String receiptNo;
  double amount;
  double progressPaid;
  double balance;
  String paymentType;
  String paymode;
  String keyValue;
  String summary;
  String documentId;

  Payment({
    required this.tenantBranchTransId,
    required this.transId,
    required this.receiptDate,
    required this.receiptNo,
    required this.amount,
    required this.progressPaid,
    required this.balance,
    required this.paymentType,
    required this.paymode,
    required this.keyValue,
    required this.summary,
    required this.documentId,
  });

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
        tenantBranchTransId: json["TenantBranchTransID"],
        transId: json["TransID"],
        receiptDate: json["ReceiptDate"],
        receiptNo: json["ReceiptNo"],
        amount: json["Amount"],
        progressPaid: json["ProgressPaid"],
        balance: json["Balance"],
        paymentType: json["PaymentType"],
        paymode: json["Paymode"],
        keyValue: json["KeyValue"],
        summary: json["Summary"],
        documentId: json["DocumentID"],
      );

  Map<String, dynamic> toJson() => {
        "TenantBranchTransID": tenantBranchTransId,
        "TransID": transId,
        "ReceiptDate": receiptDate,
        "ReceiptNo": receiptNo,
        "Amount": amount,
        "ProgressPaid": progressPaid,
        "Balance": balance,
        "PaymentType": paymentType,
        "Paymode": paymode,
        "KeyValue": keyValue,
        "Summary": summary,
        "DocumentID": documentId,
      };
}
