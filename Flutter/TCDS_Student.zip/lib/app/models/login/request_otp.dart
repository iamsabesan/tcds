import 'dart:convert';

RequestOtpResponseModel requestOtpResponseModelFromJson(String str) =>
    RequestOtpResponseModel.fromJson(json.decode(str));

String requestOtpResponseModelToJson(RequestOtpResponseModel data) =>
    json.encode(data.toJson());

class RequestOtpResponseModel {
  int code;
  String message;
  RequestOtpData data;

  RequestOtpResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RequestOtpResponseModel.fromJson(Map<String, dynamic> json) =>
      RequestOtpResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: RequestOtpData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class RequestOtpData {
  String otpTransId;
  int validityTime;

  RequestOtpData({
    required this.otpTransId,
    required this.validityTime,
  });

  factory RequestOtpData.fromJson(Map<String, dynamic> json) => RequestOtpData(
        otpTransId: json["OTPTransID"],
        validityTime: json["ValidityTime"],
      );

  Map<String, dynamic> toJson() => {
        "OTPTransID": otpTransId,
        "ValidityTime": validityTime,
      };
}
