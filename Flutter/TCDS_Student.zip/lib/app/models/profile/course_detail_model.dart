// To parse this JSON data, do
//
//     final corseDetailModel = corseDetailModelFromJson(jsonString);

import 'dart:convert';

CorseDetailModel corseDetailModelFromJson(String str) => CorseDetailModel.fromJson(json.decode(str));

String corseDetailModelToJson(CorseDetailModel data) => json.encode(data.toJson());

class CorseDetailModel {
  int code;
  String message;
  CourseDetail data;

  CorseDetailModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CorseDetailModel.fromJson(Map<String, dynamic> json) => CorseDetailModel(
    code: json["Code"],
    message: json["Message"],
    data: CourseDetail.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data.toJson(),
  };
}

class CourseDetail {
  Course course;
  Batch batch;
  List<Material> materials;
  List<Payment> payments;
  List<Certificate> marksheet;
  Certificate certificate;

  CourseDetail({
    required this.course,
    required this.batch,
    required this.materials,
    required this.payments,
    required this.marksheet,
    required this.certificate,
  });

  factory CourseDetail.fromJson(Map<String, dynamic> json) => CourseDetail(
    course: Course.fromJson(json["Course"]),
    batch: Batch.fromJson(json["Batch"]),
    materials: List<Material>.from(json["Materials"].map((x) => Material.fromJson(x))),
    payments: List<Payment>.from(json["Payments"].map((x) => Payment.fromJson(x))),
    marksheet: List<Certificate>.from(json["Marksheet"].map((x) => Certificate.fromJson(x))),
    certificate: Certificate.fromJson(json["Certificate"]),
  );

  Map<String, dynamic> toJson() => {
    "Course": course.toJson(),
    "Batch": batch.toJson(),
    "Materials": List<dynamic>.from(materials.map((x) => x.toJson())),
    "Payments": List<dynamic>.from(payments.map((x) => x.toJson())),
    "Marksheet": List<dynamic>.from(marksheet.map((x) => x.toJson())),
    "Certificate": certificate.toJson(),
  };
}

class Batch {
  String courseBatchId;
  String batchNumber;
  String batchType;
  String batchTrack;
  String facultyId;
  String facultyName;
  String startDate;
  String endDate;
  String startTime;
  String endTime;

  Batch({
    required this.courseBatchId,
    required this.batchNumber,
    required this.batchType,
    required this.batchTrack,
    required this.facultyId,
    required this.facultyName,
    required this.startDate,
    required this.endDate,
    required this.startTime,
    required this.endTime,
  });

  factory Batch.fromJson(Map<String, dynamic> json) => Batch(
    courseBatchId: json["CourseBatchID"],
    batchNumber: json["BatchNumber"],
    batchType: json["BatchType"],
    batchTrack: json["BatchTrack"],
    facultyId: json["FacultyID"],
    facultyName: json["FacultyName"],
    startDate: json["StartDate"],
    endDate: json["EndDate"],
    startTime: json["StartTime"],
    endTime: json["EndTime"],
  );

  Map<String, dynamic> toJson() => {
    "CourseBatchID": courseBatchId,
    "BatchNumber": batchNumber,
    "BatchType": batchType,
    "BatchTrack": batchTrack,
    "FacultyID": facultyId,
    "FacultyName": facultyName,
    "StartDate": startDate,
    "EndDate": endDate,
    "StartTime": startTime,
    "EndTime": endTime,
  };
}

class Certificate {
  String examIndentTransId;
  String certificateAndMarksheetId;
  String printType;
  String course;
  String date;
  String issuedDate;
  String status;

  Certificate({
    required this.examIndentTransId,
    required this.certificateAndMarksheetId,
    required this.printType,
    required this.course,
    required this.date,
    required this.issuedDate,
    required this.status,
  });

  factory Certificate.fromJson(Map<String, dynamic> json) => Certificate(
    examIndentTransId: json["ExamIndentTransID"],
    certificateAndMarksheetId: json["CertificateAndMarksheetID"],
    printType: json["PrintType"],
    course: json["Course"],
    date: json["Date"],
    issuedDate: json["IssuedDate"],
    status: json["Status"],
  );

  Map<String, dynamic> toJson() => {
    "ExamIndentTransID": examIndentTransId,
    "CertificateAndMarksheetID": certificateAndMarksheetId,
    "PrintType": printType,
    "Course": course,
    "Date": date,
    "IssuedDate": issuedDate,
    "Status": status,
  };
}

class Course {
  String courseBatchId;
  String courseId;
  String batchMappingId;
  String contactId;
  String course;
  String courseType;
  String duration;
  double courseFees;
  double discount;
  double totalFees;
  double paidFees;
  double balance;
  bool isActive;
  bool isCompleted;
  String reason;
  int totalSemesters;
  String status;
  String startDate;
  String endDate;
  String rollNumber;
  String studentName;

  Course({
    required this.courseBatchId,
    required this.courseId,
    required this.batchMappingId,
    required this.contactId,
    required this.course,
    required this.courseType,
    required this.duration,
    required this.courseFees,
    required this.discount,
    required this.totalFees,
    required this.paidFees,
    required this.balance,
    required this.isActive,
    required this.isCompleted,
    required this.reason,
    required this.totalSemesters,
    required this.status,
    required this.startDate,
    required this.endDate,
    required this.rollNumber,
    required this.studentName,
  });

  factory Course.fromJson(Map<String, dynamic> json) => Course(
    courseBatchId: json["CourseBatchID"],
    courseId: json["CourseID"],
    batchMappingId: json["BatchMappingID"],
    contactId: json["ContactID"],
    course: json["Course"],
    courseType: json["CourseType"],
    duration: json["Duration"],
    courseFees: json["CourseFees"],
    discount: json["Discount"],
    totalFees: json["TotalFees"],
    paidFees: json["PaidFees"],
    balance: json["Balance"],
    isActive: json["IsActive"],
    isCompleted: json["IsCompleted"],
    reason: json["Reason"],
    totalSemesters: json["TotalSemesters"],
    status: json["Status"],
    startDate: json["StartDate"],
    endDate: json["EndDate"],
    rollNumber: json["RollNumber"],
    studentName: json["StudentName"],
  );

  Map<String, dynamic> toJson() => {
    "CourseBatchID": courseBatchId,
    "CourseID": courseId,
    "BatchMappingID": batchMappingId,
    "ContactID": contactId,
    "Course": course,
    "CourseType": courseType,
    "Duration": duration,
    "CourseFees": courseFees,
    "Discount": discount,
    "TotalFees": totalFees,
    "PaidFees": paidFees,
    "Balance": balance,
    "IsActive": isActive,
    "IsCompleted": isCompleted,
    "Reason": reason,
    "TotalSemesters": totalSemesters,
    "Status": status,
    "StartDate": startDate,
    "EndDate": endDate,
    "RollNumber": rollNumber,
    "StudentName": studentName,
  };
}

class Material {
  String materialId;
  String materialName;
  int semester;
  String issuedDate;
  String status;
  int theoryMarks;
  int practicalMarks;
  int totalMarks;

  Material({
    required this.materialId,
    required this.materialName,
    required this.semester,
    required this.issuedDate,
    required this.status,
    required this.theoryMarks,
    required this.practicalMarks,
    required this.totalMarks,
  });

  factory Material.fromJson(Map<String, dynamic> json) => Material(
    materialId: json["MaterialID"],
    materialName: json["MaterialName"],
    semester: json["Semester"],
    issuedDate: json["IssuedDate"],
    status: json["Status"],
    theoryMarks: json["TheoryMarks"],
    practicalMarks: json["PracticalMarks"],
    totalMarks: json["TotalMarks"],
  );

  Map<String, dynamic> toJson() => {
    "MaterialID": materialId,
    "MaterialName": materialName,
    "Semester": semester,
    "IssuedDate": issuedDate,
    "Status": status,
    "TheoryMarks": theoryMarks,
    "PracticalMarks": practicalMarks,
    "TotalMarks": totalMarks,
  };
}

class Payment {
  String tenantBranchTransId;
  String receiptDate;
  String receiptNo;
  double amount;
  double progressPaid;
  double balance;
  String paymentType;
  String paymode;
  String keyValue;
  String summary;
  String documentId;

  Payment({
    required this.tenantBranchTransId,
    required this.receiptDate,
    required this.receiptNo,
    required this.amount,
    required this.progressPaid,
    required this.balance,
    required this.paymentType,
    required this.paymode,
    required this.keyValue,
    required this.summary,
    required this.documentId,
  });

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    tenantBranchTransId: json["TenantBranchTransID"],
    receiptDate: json["ReceiptDate"],
    receiptNo: json["ReceiptNo"],
    amount: json["Amount"],
    progressPaid: json["ProgressPaid"],
    balance: json["Balance"],
    paymentType: json["PaymentType"],
    paymode: json["Paymode"],
    keyValue: json["KeyValue"],
    summary: json["Summary"],
    documentId: json["DocumentID"],
  );

  Map<String, dynamic> toJson() => {
    "TenantBranchTransID": tenantBranchTransId,
    "ReceiptDate": receiptDate,
    "ReceiptNo": receiptNo,
    "Amount": amount,
    "ProgressPaid": progressPaid,
    "Balance": balance,
    "PaymentType": paymentType,
    "Paymode": paymode,
    "KeyValue": keyValue,
    "Summary": summary,
    "DocumentID": documentId,
  };
}
