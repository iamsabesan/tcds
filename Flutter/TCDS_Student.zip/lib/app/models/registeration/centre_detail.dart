// To parse this JSON data, do
//
//     final centerDetailModel = centerDetailModelFromJson(jsonString);

import 'dart:convert';

CenterDetailModel centerDetailModelFromJson(String str) => CenterDetailModel.fromJson(json.decode(str));

String centerDetailModelToJson(CenterDetailModel data) => json.encode(data.toJson());

class CenterDetailModel {
  int code;
  String message;
  CentreDetailData data;

  CenterDetailModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CenterDetailModel.fromJson(Map<String, dynamic> json) => CenterDetailModel(
    code: json["Code"],
    message: json["Message"],
    data: CentreDetailData.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data.toJson(),
  };
}

class CentreDetailData {
  String tenantBranchId;
  String franchiseeName;
  String contactName;
  String phoneCode;
  String phone;
  String alternatePhoneCode;
  String alternatePhone;
  String email;
  String address1;
  String address2;
  String area;
  String district;
  String status;
  String country;
  String pincode;

  CentreDetailData({
    required this.tenantBranchId,
    required this.franchiseeName,
    required this.contactName,
    required this.phoneCode,
    required this.phone,
    required this.alternatePhoneCode,
    required this.alternatePhone,
    required this.email,
    required this.address1,
    required this.address2,
    required this.area,
    required this.district,
    required this.status,
    required this.country,
    required this.pincode,
  });

  factory CentreDetailData.fromJson(Map<String, dynamic> json) => CentreDetailData(
    tenantBranchId: json["TenantBranchID"],
    franchiseeName: json["FranchiseeName"],
    contactName: json["ContactName"],
    phoneCode: json["PhoneCode"],
    phone: json["Phone"],
    alternatePhoneCode: json["AlternatePhoneCode"],
    alternatePhone: json["AlternatePhone"],
    email: json["Email"],
    address1: json["Address1"],
    address2: json["Address2"],
    area: json["Area"],
    district: json["District"],
    status: json["Status"]??"",
    country: json["Country"],
    pincode: json["Pincode"],
  );

  Map<String, dynamic> toJson() => {
    "TenantBranchID": tenantBranchId,
    "FranchiseeName": franchiseeName,
    "ContactName": contactName,
    "PhoneCode": phoneCode,
    "Phone": phone,
    "AlternatePhoneCode": alternatePhoneCode,
    "AlternatePhone": alternatePhone,
    "Email": email,
    "Address1": address1,
    "Address2": address2,
    "Area": area,
    "District": district,
    "Status": status,
    "Country": country,
    "Pincode": pincode,
  };
}
