import 'dart:convert';

CentresModel centresModelFromJson(String str) =>
    CentresModel.fromJson(json.decode(str));

String centresModelToJson(CentresModel data) => json.encode(data.toJson());

class CentresModel {
  int code;
  String message;
  List<CentreData> data;

  CentresModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory CentresModel.fromJson(Map<String, dynamic> json) => CentresModel(
        code: json["Code"],
        message: json["Message"],
        data: List<CentreData>.from(
            json["Data"].map((x) => CentreData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class CentreData {
  String tenantBranchId;
  String franchiseeCode;
  String franchiseeName;
  String contactName;
  String address1;
  String address2;
  String area;
  String district;
  String phoneCode;
  String phone;
  String alternatePhoneCode;
  String alternatePhone;
  String email;
  String state;
  String country;
  String taluk;
  String pincode;
  String latitude;
  String longitude;
  OwnerImage? ownerImage;
  List<Course> courses;

  CentreData({
    required this.tenantBranchId,
    required this.franchiseeCode,
    required this.franchiseeName,
    required this.contactName,
    required this.address1,
    required this.address2,
    required this.area,
    required this.district,
    required this.phoneCode,
    required this.phone,
    required this.alternatePhoneCode,
    required this.alternatePhone,
    required this.email,
    required this.state,
    required this.country,
    required this.taluk,
    required this.pincode,
    required this.latitude,
    required this.longitude,
    required this.ownerImage,
    required this.courses,
  });

  factory CentreData.fromJson(Map<String, dynamic> json) => CentreData(
        tenantBranchId: json["TenantBranchID"],
        franchiseeCode: json["FranchiseeCode"],
        franchiseeName: json["FranchiseeName"],
        contactName: json["ContactName"],
        address1: json["Address1"],
        address2: json["Address2"],
        area: json["Area"],
        district: json["District"],
        phoneCode: json["PhoneCode"],
        phone: json["Phone"],
        alternatePhoneCode: json["AlternatePhoneCode"],
        alternatePhone: json["AlternatePhone"],
        email: json["Email"] ?? "",
        state: json["State"],
        country: json["Country"],
        taluk: json["Taluk"],
        pincode: json["Pincode"],
        latitude: json["Latitude"],
        longitude: json["Longitude"],
        ownerImage: json["OwnerImage"] == null
            ? null
            : OwnerImage.fromJson(json["OwnerImage"]),
        courses:
            List<Course>.from(json["Courses"].map((x) => Course.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "TenantBranchID": tenantBranchId,
        "FranchiseeCode": franchiseeCode,
        "FranchiseeName": franchiseeName,
        "ContactName": contactName,
        "Address1": address1,
        "Address2": address2,
        "Area": area,
        "District": district,
        "PhoneCode": phoneCode,
        "Phone": phone,
        "AlternatePhoneCode": alternatePhoneCode,
        "AlternatePhone": alternatePhone,
        "Email": email,
        "State": state,
        "Country": country,
        "Taluk": taluk,
        "Pincode": pincode,
        "Latitude": latitude,
        "Longitude": longitude,
        "OwnerImage": ownerImage?.toJson(),
        "Courses": List<dynamic>.from(courses.map((x) => x.toJson())),
      };
}

class Course {
  String courseId;
  String courseTypeName;
  String course;
  String duration;
  double courseFees;
  int totalSemesters;
  String shortName;
  String eligibility;
  List<Subject> subjects;

  Course({
    required this.courseId,
    required this.courseTypeName,
    required this.course,
    required this.duration,
    required this.courseFees,
    required this.totalSemesters,
    required this.shortName,
    required this.eligibility,
    required this.subjects,
  });

  factory Course.fromJson(Map<String, dynamic> json) => Course(
        courseId: json["CourseID"],
        courseTypeName: json["CourseTypeName"],
        course: json["Course"],
        duration: json["Duration"],
        courseFees: json["CourseFees"],
        totalSemesters: json["TotalSemesters"],
        shortName: json["ShortName"],
        eligibility: json["Eligibility"],
        subjects: List<Subject>.from(
            json["Subjects"].map((x) => Subject.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "CourseID": courseId,
        "CourseTypeName": courseTypeName,
        "Course": course,
        "Duration": duration,
        "CourseFees": courseFees,
        "TotalSemesters": totalSemesters,
        "ShortName": shortName,
        "Eligibility": eligibility,
        "Subjects": List<dynamic>.from(subjects.map((x) => x.toJson())),
      };
}

class Subject {
  String subjectId;
  int semester;
  String subjectName;
  int theoryMark;
  int practicalMark;
  int totalMark;

  Subject({
    required this.subjectId,
    required this.semester,
    required this.subjectName,
    required this.theoryMark,
    required this.practicalMark,
    required this.totalMark,
  });

  factory Subject.fromJson(Map<String, dynamic> json) => Subject(
        subjectId: json["SubjectID"],
        semester: json["Semester"],
        subjectName: json["SubjectName"],
        theoryMark: json["TheoryMarks"],
        practicalMark: json["PracticalMarks"],
        totalMark: json["TotalMarks"],
      );

  Map<String, dynamic> toJson() => {
        "SubjectID": subjectId,
        "Semester": semester,
        "SubjectName": subjectName,
      };
}

class OwnerImage {
  String documentName;
  String fileName;
  String documentType;
  String contentUrl;
  String? fetchedBase64;

  OwnerImage({
    required this.documentName,
    required this.fileName,
    required this.documentType,
    required this.contentUrl,
  });

  factory OwnerImage.fromJson(Map<String, dynamic> json) => OwnerImage(
        documentName: json["DocumentName"],
        fileName: json["FileName"],
        documentType: json["DocumentType"],
        contentUrl: json["ContentUrl"],
      );

  Map<String, dynamic> toJson() => {
        "DocumentName": documentName,
        "FileName": fileName,
        "DocumentType": documentType,
        "ContentUrl": contentUrl,
      };
}
