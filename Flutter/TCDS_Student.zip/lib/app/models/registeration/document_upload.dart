import 'dart:convert';

DocumentUploadResponseModel documentUploadResponseModelFromJson(String str) =>
    DocumentUploadResponseModel.fromJson(json.decode(str));

String documentUploadResponseModelToJson(DocumentUploadResponseModel data) =>
    json.encode(data.toJson());

class DocumentUploadResponseModel {
  int code;
  String message;
  DocumentUploadData data;

  DocumentUploadResponseModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory DocumentUploadResponseModel.fromJson(Map<String, dynamic> json) =>
      DocumentUploadResponseModel(
        code: json["Code"],
        message: json["Message"],
        data: DocumentUploadData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class DocumentUploadData {
  String documentId;
  String documentType;
  String fileName;
  String mimeType;
  String fileExtension;
  bool isActivated;

  DocumentUploadData({
    required this.documentId,
    required this.documentType,
    required this.fileName,
    required this.mimeType,
    required this.fileExtension,
    required this.isActivated,
  });

  factory DocumentUploadData.fromJson(Map<String, dynamic> json) =>
      DocumentUploadData(
        documentId: json["DocumentID"],
        documentType: json["DocumentType"],
        fileName: json["FileName"],
        mimeType: json["MIMEType"],
        fileExtension: json["FileExtension"],
        isActivated: json["IsActivated"],
      );

  Map<String, dynamic> toJson() => {
        "DocumentID": documentId,
        "DocumentType": documentType,
        "FileName": fileName,
        "MIMEType": mimeType,
        "FileExtension": fileExtension,
        "IsActivated": isActivated,
      };
}
