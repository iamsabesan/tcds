class FranchiseDistrictModel {
  int code;
  String message;
  List<FranchiseDistrict> data;

  FranchiseDistrictModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseDistrictModel.fromJson(Map<String, dynamic> json) =>
      FranchiseDistrictModel(
        code: json["Code"],
        message: json["Message"],
        data: List<FranchiseDistrict>.from(
            json["Data"].map((x) => FranchiseDistrict.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FranchiseDistrict {
  String districtProvinceName;

  FranchiseDistrict({
    required this.districtProvinceName,
  });

  factory FranchiseDistrict.fromJson(Map<String, dynamic> json) =>
      FranchiseDistrict(
        districtProvinceName: json["DistrictProvinceName"],
      );

  Map<String, dynamic> toJson() => {
        "DistrictProvinceName": districtProvinceName,
      };
}
