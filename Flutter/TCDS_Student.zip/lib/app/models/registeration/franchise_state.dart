class FranchiseStateModel {
  int code;
  String message;
  List<FranchiseState> data;

  FranchiseStateModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseStateModel.fromJson(Map<String, dynamic> json) =>
      FranchiseStateModel(
        code: json["Code"],
        message: json["Message"],
        data: List<FranchiseState>.from(
            json["Data"].map((x) => FranchiseState.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FranchiseState {
  String stateProvinceName;

  FranchiseState({
    required this.stateProvinceName,
  });

  factory FranchiseState.fromJson(Map<String, dynamic> json) => FranchiseState(
        stateProvinceName: json["StateProvinceName"],
      );

  Map<String, dynamic> toJson() => {
        "StateProvinceName": stateProvinceName,
      };
}
