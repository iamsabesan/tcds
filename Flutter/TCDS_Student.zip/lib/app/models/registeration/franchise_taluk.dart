class FranchiseTalukModel {
  int code;
  String message;
  List<FranchiseTaluk> data;

  FranchiseTalukModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory FranchiseTalukModel.fromJson(Map<String, dynamic> json) =>
      FranchiseTalukModel(
        code: json["Code"],
        message: json["Message"],
        data: List<FranchiseTaluk>.from(
            json["Data"].map((x) => FranchiseTaluk.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class FranchiseTaluk {
  String taluk;

  FranchiseTaluk({
    required this.taluk,
  });

  factory FranchiseTaluk.fromJson(Map<String, dynamic> json) => FranchiseTaluk(
        taluk: json["Taluk"],
      );

  Map<String, dynamic> toJson() => {
        "Taluk": taluk,
      };
}
