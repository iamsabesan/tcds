class HowKnowTcdsModel {
  int code;
  String message;
  List<KnowData> data;

  HowKnowTcdsModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory HowKnowTcdsModel.fromJson(Map<String, dynamic> json) =>
      HowKnowTcdsModel(
        code: json["Code"],
        message: json["Message"],
        data:
            List<KnowData>.from(json["Data"].map((x) => KnowData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class KnowData {
  String id;
  String value;

  KnowData({
    required this.id,
    required this.value,
  });

  factory KnowData.fromJson(Map<String, dynamic> json) => KnowData(
        id: json["ID"],
        value: json["Value"],
      );

  Map<String, dynamic> toJson() => {
        "ID": id,
        "Value": value,
      };
}
