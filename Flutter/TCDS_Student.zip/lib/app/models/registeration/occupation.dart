import 'dart:convert';

OccupationModel occupationModelFromJson(String str) =>
    OccupationModel.fromJson(json.decode(str));

String occupationModelToJson(OccupationModel data) =>
    json.encode(data.toJson());

class OccupationModel {
  int code;
  String message;
  List<Occupation> data;

  OccupationModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory OccupationModel.fromJson(Map<String, dynamic> json) =>
      OccupationModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Occupation>.from(
            json["Data"].map((x) => Occupation.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Occupation {
  String occupationId;
  String occupation;

  Occupation({
    required this.occupationId,
    required this.occupation,
  });

  factory Occupation.fromJson(Map<String, dynamic> json) => Occupation(
        occupationId: json["OccupationID"],
        occupation: json["Occupation"],
      );

  Map<String, dynamic> toJson() => {
        "OccupationID": occupationId,
        "Occupation": occupation,
      };
}
