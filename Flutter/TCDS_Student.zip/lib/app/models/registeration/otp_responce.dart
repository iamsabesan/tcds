class OtpResponceModel {
  int code;
  String message;
  OTPData data;

  OtpResponceModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory OtpResponceModel.fromJson(Map<String, dynamic> json) =>
      OtpResponceModel(
        code: json["Code"],
        message: json["Message"],
        data: OTPData.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class OTPData {
  String otpTransId;
  int validityTime;

  OTPData({
    required this.otpTransId,
    required this.validityTime,
  });

  factory OTPData.fromJson(Map<String, dynamic> json) => OTPData(
        otpTransId: json["OTPTransID"],
        validityTime: json["ValidityTime"],
      );

  Map<String, dynamic> toJson() => {
        "OTPTransID": otpTransId,
        "ValidityTime": validityTime,
      };
}
