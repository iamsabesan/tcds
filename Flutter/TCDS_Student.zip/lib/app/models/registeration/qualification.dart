import 'dart:convert';

QualificationModel qualificationModelFromJson(String str) =>
    QualificationModel.fromJson(json.decode(str));

String qualificationModelToJson(QualificationModel data) =>
    json.encode(data.toJson());

class QualificationModel {
  int code;
  String message;
  List<Qualification> data;

  QualificationModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory QualificationModel.fromJson(Map<String, dynamic> json) =>
      QualificationModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Qualification>.from(
            json["Data"].map((x) => Qualification.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Qualification {
  String qualificationId;
  String qualification;

  Qualification({
    required this.qualificationId,
    required this.qualification,
  });

  factory Qualification.fromJson(Map<String, dynamic> json) => Qualification(
        qualificationId: json["QualificationID"],
        qualification: json["Qualification"],
      );

  Map<String, dynamic> toJson() => {
        "QualificationID": qualificationId,
        "Qualification": qualification,
      };
}
