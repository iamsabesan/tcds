import 'dart:convert';

ReasonTcdsModel reasonTcdsModelFromJson(String str) =>
    ReasonTcdsModel.fromJson(json.decode(str));

String reasonTcdsModelToJson(ReasonTcdsModel data) =>
    json.encode(data.toJson());

class ReasonTcdsModel {
  int code;
  String message;
  List<Reason> data;

  ReasonTcdsModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory ReasonTcdsModel.fromJson(Map<String, dynamic> json) =>
      ReasonTcdsModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Reason>.from(json["Data"].map((x) => Reason.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Reason {
  String reasonId;
  String reason;

  Reason({
    required this.reasonId,
    required this.reason,
  });

  factory Reason.fromJson(Map<String, dynamic> json) => Reason(
        reasonId: json["ReasonID"],
        reason: json["Reason"],
      );

  Map<String, dynamic> toJson() => {
        "ReasonID": reasonId,
        "Reason": reason,
      };
}
