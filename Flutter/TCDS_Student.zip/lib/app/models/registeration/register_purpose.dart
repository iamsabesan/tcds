class RegisterationPurposeModel {
  int code;
  String message;
  List<PurposeData> data;

  RegisterationPurposeModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RegisterationPurposeModel.fromJson(Map<String, dynamic> json) =>
      RegisterationPurposeModel(
        code: json["Code"],
        message: json["Message"],
        data: List<PurposeData>.from(
            json["Data"].map((x) => PurposeData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class PurposeData {
  String id;
  String value;

  PurposeData({
    required this.id,
    required this.value,
  });

  factory PurposeData.fromJson(Map<String, dynamic> json) => PurposeData(
        id: json["ID"],
        value: json["Value"],
      );

  Map<String, dynamic> toJson() => {
        "ID": id,
        "Value": value,
      };
}
