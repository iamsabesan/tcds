import 'dart:convert';

RelationshipModel relationshipModelFromJson(String str) =>
    RelationshipModel.fromJson(json.decode(str));

String relationshipModelToJson(RelationshipModel data) =>
    json.encode(data.toJson());

class RelationshipModel {
  int code;
  String message;
  List<Relationship> data;

  RelationshipModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory RelationshipModel.fromJson(Map<String, dynamic> json) =>
      RelationshipModel(
        code: json["Code"],
        message: json["Message"],
        data: List<Relationship>.from(
            json["Data"].map((x) => Relationship.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Relationship {
  String minValue;

  Relationship({
    required this.minValue,
  });

  factory Relationship.fromJson(Map<String, dynamic> json) => Relationship(
        minValue: json["MinValue"],
      );

  Map<String, dynamic> toJson() => {
        "MinValue": minValue,
      };
}
