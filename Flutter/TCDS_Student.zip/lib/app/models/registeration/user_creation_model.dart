// To parse this JSON data, do
//
//     final userCreationModel = userCreationModelFromJson(jsonString);

import 'dart:convert';

UserCreationModel userCreationModelFromJson(String str) => UserCreationModel.fromJson(json.decode(str));

String userCreationModelToJson(UserCreationModel data) => json.encode(data.toJson());

class UserCreationModel {
  int code;
  String message;
  String data;

  UserCreationModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory UserCreationModel.fromJson(Map<String, dynamic> json) => UserCreationModel(
    code: json["Code"],
    message: json["Message"],
    data: json["Data"],
  );

  Map<String, dynamic> toJson() => {
    "Code": code,
    "Message": message,
    "Data": data,
  };
}
