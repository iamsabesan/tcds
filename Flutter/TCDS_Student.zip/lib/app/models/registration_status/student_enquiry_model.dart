import 'dart:convert';

StudentEnquiryModel studentEnquiryModelFromJson(String str) =>
    StudentEnquiryModel.fromJson(json.decode(str));

String studentEnquiryModelToJson(StudentEnquiryModel data) =>
    json.encode(data.toJson());

class StudentEnquiryModel {
  int code;
  String message;
  EnquiryDetail data;

  StudentEnquiryModel({
    required this.code,
    required this.message,
    required this.data,
  });

  factory StudentEnquiryModel.fromJson(Map<String, dynamic> json) =>
      StudentEnquiryModel(
        code: json["Code"],
        message: json["Message"],
        data: EnquiryDetail.fromJson(json["Data"]),
      );

  Map<String, dynamic> toJson() => {
        "Code": code,
        "Message": message,
        "Data": data.toJson(),
      };
}

class EnquiryDetail {
  String studentEnquiryId;
  String tenantBranchId;
  String courseId;
  String course;
  String studentName;
  String gender;
  String dateOfBirth;
  String phoneCode;
  String phone;
  String alternatePhoneCode;
  String alternatePhone;
  String email;
  String qualification;
  String guardianType;
  String guardianName;
  String occupation;
  String reasonToSelect;
  String status;
  bool isRejected;
  String rejectedDate;
  String reason;
  String courseTypeName;
  String durationType;
  int duration;
  int totalSemesters;
  double courseFees;
  String documentId;
  String requestedDate;
  String shortName;
  List<Address> address;
  BranchDetail branchDetail;

  EnquiryDetail({
    required this.studentEnquiryId,
    required this.tenantBranchId,
    required this.courseId,
    required this.course,
    required this.studentName,
    required this.gender,
    required this.dateOfBirth,
    required this.phoneCode,
    required this.phone,
    required this.alternatePhoneCode,
    required this.alternatePhone,
    required this.email,
    required this.qualification,
    required this.guardianType,
    required this.guardianName,
    required this.occupation,
    required this.reasonToSelect,
    required this.status,
    required this.isRejected,
    required this.rejectedDate,
    required this.reason,
    required this.courseTypeName,
    required this.durationType,
    required this.duration,
    required this.totalSemesters,
    required this.courseFees,
    required this.documentId,
    required this.requestedDate,
    required this.shortName,
    required this.address,
    required this.branchDetail,
  });

  factory EnquiryDetail.fromJson(Map<String, dynamic> json) => EnquiryDetail(
        studentEnquiryId: json["StudentEnquiryID"],
        tenantBranchId: json["TenantBranchID"],
        courseId: json["CourseID"],
        course: json["Course"],
        studentName: json["StudentName"],
        gender: json["Gender"],
        dateOfBirth: json["DateOfBirth"],
        phoneCode: json["PhoneCode"],
        phone: json["Phone"],
        alternatePhoneCode: json["AlternatePhoneCode"],
        alternatePhone: json["AlternatePhone"],
        email: json["Email"],
        qualification: json["Qualification"],
        guardianType: json["GuardianType"],
        guardianName: json["GuardianName"],
        occupation: json["Occupation"],
        reasonToSelect: json["ReasonToSelect"],
        status: json["Status"],
        isRejected: json["IsRejected"],
        rejectedDate: json["RejectedDate"],
        reason: json["Reason"],
        courseTypeName: json["CourseTypeName"],
        durationType: json["DurationType"],
        duration: json["Duration"],
        totalSemesters: json["TotalSemesters"],
        courseFees: json["CourseFees"],
        documentId: json["DocumentID"],
        requestedDate: json["RequestedDate"],
        shortName: json["ShortName"],
        address:
            List<Address>.from(json["Address"].map((x) => Address.fromJson(x))),
        branchDetail: BranchDetail.fromJson(json["BranchDetail"]),
      );

  Map<String, dynamic> toJson() => {
        "StudentEnquiryID": studentEnquiryId,
        "TenantBranchID": tenantBranchId,
        "CourseID": courseId,
        "Course": course,
        "StudentName": studentName,
        "Gender": gender,
        "DateOfBirth": dateOfBirth,
        "PhoneCode": phoneCode,
        "Phone": phone,
        "AlternatePhoneCode": alternatePhoneCode,
        "AlternatePhone": alternatePhone,
        "Email": email,
        "Qualification": qualification,
        "GuardianType": guardianType,
        "GuardianName": guardianName,
        "Occupation": occupation,
        "ReasonToSelect": reasonToSelect,
        "Status": status,
        "IsRejected": isRejected,
        "RejectedDate": rejectedDate,
        "Reason": reason,
        "CourseTypeName": courseTypeName,
        "DurationType": durationType,
        "Duration": duration,
        "TotalSemesters": totalSemesters,
        "CourseFees": courseFees,
        "DocumentID": documentId,
        "RequestedDate": requestedDate,
        "ShortName": shortName,
        "Address": List<dynamic>.from(address.map((x) => x.toJson())),
        "BranchDetail": branchDetail.toJson(),
      };
}

class Address {
  String studentAddressId;
  String studentEnquiryId;
  String addressType;
  String address1;
  String address2;
  String area;
  String country;
  String state;
  String district;
  String pincode;

  Address({
    required this.studentAddressId,
    required this.studentEnquiryId,
    required this.addressType,
    required this.address1,
    required this.address2,
    required this.area,
    required this.country,
    required this.state,
    required this.district,
    required this.pincode,
  });

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        studentAddressId: json["StudentAddressID"] ?? "",
        studentEnquiryId: json["StudentEnquiryID"],
        addressType: json["AddressType"] ?? "",
        address1: json["Address1"],
        address2: json["Address2"] ?? "",
        area: json["Area"],
        country: json["Country"] ?? "",
        state: json["State"] ?? "",
        district: json["District"] ?? "",
        pincode: json["Pincode"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "StudentAddressID": studentAddressId,
        "StudentEnquiryID": studentEnquiryId,
        "AddressType": addressType,
        "Address1": address1,
        "Address2": address2,
        "Area": area,
        "Country": country,
        "State": state,
        "District": district,
        "Pincode": pincode,
      };
}

class BranchDetail {
  String tenantBranchId;
  String branchName;
  String contactName;
  String gender;
  String phone;
  String alternatePhone;
  String email;
  String addressTypeId;
  String addressType;
  String address1;
  String address2;
  String country;
  String state;
  String district;
  String area;
  String pincode;

  BranchDetail({
    required this.tenantBranchId,
    required this.branchName,
    required this.contactName,
    required this.gender,
    required this.phone,
    required this.alternatePhone,
    required this.email,
    required this.addressTypeId,
    required this.addressType,
    required this.address1,
    required this.address2,
    required this.country,
    required this.state,
    required this.district,
    required this.area,
    required this.pincode,
  });

  factory BranchDetail.fromJson(Map<String, dynamic> json) => BranchDetail(
        tenantBranchId: json["TenantBranchID"],
        branchName: json["BranchName"],
        contactName: json["ContactName"],
        gender: json["Gender"],
        phone: json["Phone"],
        alternatePhone: json["AlternatePhone"],
        email: json["Email"],
        addressTypeId: json["AddressTypeID"],
        addressType: json["AddressType"],
        address1: json["Address1"],
        address2: json["Address2"] ?? "",
        country: json["Country"],
        state: json["State"],
        district: json["District"],
        area: json["Area"],
        pincode: json["Pincode"],
      );

  Map<String, dynamic> toJson() => {
        "TenantBranchID": tenantBranchId,
        "BranchName": branchName,
        "ContactName": contactName,
        "Gender": gender,
        "Phone": phone,
        "AlternatePhone": alternatePhone,
        "Email": email,
        "AddressTypeID": addressTypeId,
        "AddressType": addressType,
        "Address1": address1,
        "Address2": address2,
        "Country": country,
        "State": state,
        "District": district,
        "Area": area,
        "Pincode": pincode,
      };
}
