import 'package:get/get.dart';
import 'package:tcds_student/app/bindings/login_binding.dart';
import 'package:tcds_student/app/bindings/my_profile_binding.dart';
import 'package:tcds_student/app/ui/screens/dashboard/dashboard_screen.dart';
import 'package:tcds_student/app/ui/screens/dashboard/student_course_list_page.dart';
import '../bindings/awards.dart';
import '../bindings/course_binding.dart';
import '../bindings/dashboard_binding.dart';
import '../bindings/register_binding.dart';
import '../bindings/registration_status_binding.dart';
import '../ui/screens/award/achievers_award_screen.dart';
import '../ui/screens/dashboard/my_profile.dart';
import '../ui/screens/login/login.dart';
import '../ui/screens/registeration/centre_list.dart';
import '../ui/screens/registeration/registration_status_page.dart';

class Routes {
  static const String logIn = '/login';
  static const String centreList = '/centre_list';
  static const String registrationStatus = '/registration_status';
  static const String dashBoard = '/dashBoard';
  static const String myProfile = '/myProfile';
  static const String courses = '/courses';
  static const String awards = '/awards';

  static final routesList = [
    GetPage(
      name: logIn,
      page: () => const Login(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: centreList,
      page: () => const CentreList(),
      binding: RegisterBinding(),
    ),
    GetPage(
      name: registrationStatus,
      page: () => const RegistrationStatusPage(),
      binding: RegistrationStatusBinding(),
    ),
    GetPage(
      name: dashBoard,
      page: () => const DashboardScreen(),
      binding: DashboardBinding(),
    ),
    GetPage(
      name: myProfile,
      page: () => const MyProfile(),
      binding: MyProfileBinding(),
    ),
    GetPage(
      name: courses,
      page: () => const StudentCourseListPage(),
      binding: CourseBinding(),
    ),
    GetPage(
      name: awards,
      page: () => const AchieversAwardScreen(),
      binding: AchieversAwardBinding(),
    ),
  ];
}
