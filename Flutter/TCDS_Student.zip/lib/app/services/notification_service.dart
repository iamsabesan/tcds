/* import 'dart:io';
import 'package:dio/dio.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:path_provider/path_provider.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  debugPrint("-> _firebaseMessagingBackgroundHandler  - $message ");
  // await NotificationService.instance._setupFlutterNotifications();
  await NotificationService.instance._showNotification(message);
}

// Top-level notification response handler, this will handle ontap of notification when app is not in backround (Terminated)
@pragma('vm:entry-point')
void _onDidReceiveBackgroundNotificationResponse(
    NotificationResponse response) {
  debugPrint("Notification tapped (terminated): ${response.payload}");

  // since there will be no context cause flutter will not be loaded so it won't navigate
  // instead we use initial message below
  WidgetsBinding.instance.addPostFrameCallback((_) {
    // Navigator.push(
    //   applicationCore!.navigatorKey.currentState!.context,
    //   MaterialPageRoute(
    //     builder: (context) => const NotificationScreen(),
    //   ),
    // );
  });
}

class NotificationService {
  NotificationService._();

  static final NotificationService instance = NotificationService._();
  final _messaging = FirebaseMessaging.instance;
  String? deviceToken = '';
  final _localNotifications = FlutterLocalNotificationsPlugin();
  bool _isFlutterLocalNotificationsInitialized = false;

  //  initialize
  Future<void> initialize() async {
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await _requestPermission();
    await _setupFlutterNotifications();
    await _setupMessageHandlers();

    // get FCM token
    final token = await _messaging.getToken();
    deviceToken = token;
    debugPrint('FCM Token: $token');

    // // subscribe to topic
    // subscribeToTopic("TopicNotification");
  }

  // request permission
  Future<void> _requestPermission() async {
    final settings = await _messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      // provisional: false,
      // carPlay: false,
      // announcement: false,
      // criticalAlert: false
    );
    debugPrint("Permission Status ${settings.authorizationStatus}");
  }

  // setup
  Future<void> _setupFlutterNotifications() async {
    if (_isFlutterLocalNotificationsInitialized) {
      return;
    }

    // android setup
    const channel = AndroidNotificationChannel(
      'message_now',
      "High Important Notification",
      description: "This channel is used for important notifications.",
      importance: Importance.high,
    );

    await _localNotifications
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    const initializationSettingsAndroid =
        AndroidInitializationSettings("@mipmap/ic_launcher");

    // ios setup
    const initializationSettingsDarwin = DarwinInitializationSettings();

    const initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsDarwin,
    );

    // notification setup
    await _localNotifications.initialize(
      initializationSettings,
      onDidReceiveBackgroundNotificationResponse:
          _onDidReceiveBackgroundNotificationResponse,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
    );
    _isFlutterLocalNotificationsInitialized = true;
  }

  // this function handles tap of notification when app is in foreground or backround (NOTE : Not in terminated state)
  void _onDidReceiveNotificationResponse(NotificationResponse response) {
    debugPrint("Notification tapped (fore & back): ${response.payload}");
    // Navigator.push(
    //   applicationCore!.navigatorKey.currentState!.context,
    //   MaterialPageRoute(
    //     builder: (context) => const NotificationScreen(),
    //   ),
    // );
    // navigatorKey.currentState?.push(MaterialPageRoute(
    //   builder: (context) => const NotificationList(),
    // ));
  }

  //show notification function
  Future<void> _showNotification(RemoteMessage message) async {
    final dio = Dio();
    debugPrint(
        "-> showNotification message.notification - ${message.notification} ");
    debugPrint("-> showNotification message.data  - ${message.data} ");
    RemoteNotification? notification = message.notification;
    debugPrint("-> notification  - $notification ");
    debugPrint("-> Sended Time  - ${message.sentTime} ");
    AndroidNotification? android = message.notification?.android;

    if (notification != null && android != null) {
      // Extract additional data from the message payload
      Map<String, dynamic> data = message.data;

      // if image is not empty let's show it
      String imageUrl = data['imageurl'] ?? "";

      BigPictureStyleInformation? bigPictureStyleInformation;

      if (imageUrl.isNotEmpty) {
        try {
          // get document path
          final directory = await getApplicationDocumentsDirectory();
          final filePath = '${directory.path}/temp_image.jpg';

          // call and get file
          final uri = Uri.parse(imageUrl);
          final response = await dio.getUri(
            uri,
            options: Options(responseType: ResponseType.bytes),
          );

          // on success save the image
          if (response.statusCode == 200) {
            final file = File(filePath);
            await file.writeAsBytes(response.data);

            bigPictureStyleInformation = BigPictureStyleInformation(
              FilePathAndroidBitmap(filePath),
              contentTitle: notification.title,
              summaryText: notification.body,
            );
          } else {
            debugPrint("Failed to load image, status: ${response.statusCode}");
          }
        } catch (e) {
          debugPrint("Error downloading image: $e");
        }
      }

      // show notification
      await _localNotifications.show(
        notification.hashCode,
        notification.title,
        notification.body,
        NotificationDetails(
          android: AndroidNotificationDetails(
              "message_now", "High Important Notification",
              channelDescription:
                  "This channel is used for important notifications.",
              priority: Priority.high,
              importance: Importance.high,
              icon: "@mipmap/ic_launcher",
              // icon: "notification_launcher",
              styleInformation: bigPictureStyleInformation),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        payload: message.data.toString(),
      );
    }
  }

  // setup message handlers
  Future<void> _setupMessageHandlers() async {
    debugPrint("-> _setupMessageHandlers ");
    // foreground message
    FirebaseMessaging.onMessage.listen((message) => _showNotification(message));

    // background message
    FirebaseMessaging.onMessageOpenedApp.listen(
      (message) => _handleBackgroundMessage("message"),
    );

    // opened app
    final initialMessage = await _messaging.getInitialMessage();
    if (initialMessage != null) {
      debugPrint("->initialMessage  - $initialMessage ");
      _handleBackgroundMessage("initialMessage");
    }

    // get notification details for to identify app is opened using notification tap
    final notificationDetails = await FlutterLocalNotificationsPlugin()
        .getNotificationAppLaunchDetails();

    // if it's opened using notification let's navigate to notification screen
    if (notificationDetails?.didNotificationLaunchApp ?? false) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        // navigatorKey.currentState?.push(MaterialPageRoute(
        //   builder: (context) => const NotificationList(),
        // ));
        // Navigator.push(
        //   applicationCore!.navigatorKey.currentState!.context,
        //   MaterialPageRoute(
        //     builder: (context) => const NotificationScreen(),
        //   ),
        // );
      });
    }
  }

  // backround message handler
  _handleBackgroundMessage(String message) {
    // debugPrint('BG message ${message.data}');
    // Navigator.push(
    //   applicationCore!.navigatorKey.currentState!.context,
    //   MaterialPageRoute(
    //     builder: (context) => const NotificationScreen(),
    //   ),
    // );
  }

  // subscripe to a specific topic
  Future<void> subscribeToTopic(String topic) async {
    await FirebaseMessaging.instance.subscribeToTopic(topic);
    debugPrint("Topic:$topic Subscribed");
  }
}
 */