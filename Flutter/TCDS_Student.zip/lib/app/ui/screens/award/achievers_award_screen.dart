import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/app/models/registeration/franchise_state.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../controllers/achievers_award_controller.dart';
import '../../../models/award/level_achievers_award.dart';
import '../../widgets/custom_drawer.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/pop_scope_handler.dart';
import '../../widgets/searchable_dropdown.dart';
import '../../widgets/single_dropdown.dart';

class AchieversAwardScreen extends StatefulWidget {
  const AchieversAwardScreen({super.key});

  @override
  State<AchieversAwardScreen> createState() => _AchieversAwardScreenState();
}

class _AchieversAwardScreenState extends State<AchieversAwardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  AchieversAwardController achieversAwardController =
      Get.put(AchieversAwardController());

  late String selectedYear;
  late List<String> years;

  TextEditingController stateCtrl = TextEditingController();
  TextEditingController stateTextCtrl = TextEditingController();
  TextEditingController districtTextCtrl = TextEditingController();
  TextEditingController districtCtrl = TextEditingController();
  TextEditingController levelCtrl = TextEditingController();
  TextEditingController levelTextCtrl = TextEditingController();
  TextEditingController typeCtrl = TextEditingController();
  TextEditingController typeTextCtrl = TextEditingController();

  RxBool showDistrict = false.obs;
  bool scrLoader = true;

  bool canPop = false;

  void fetchArguments() {
    try {
      canPop = Get.arguments["canPop"] ?? false;
      debugPrint("fetched arg val = $canPop");
    } catch (e) {
      debugPrint('Failed to fetch Arguments');
    }
  }

  @override
  void initState() {
    // Get passed arguments and store
    fetchArguments();
    getApiCall();

    final currentYear = DateTime.now().year;
    years =
        List.generate(currentYear - 2023, (index) => (2024 + index).toString());
    selectedYear = currentYear.toString(); // Default to current year

    super.initState();
  }

  Future<void> getApiCall() async {
    await achieversAwardController.getLevel();
    // get country id of india

    // get state list based on country india
    await achieversAwardController.fetchFranchiseState();

    if (achieversAwardController.franchiseState.isNotEmpty) {
      // fetch state 'Tamil Nadu' to set as Default state
      final FranchiseState defaultState =
          achieversAwardController.franchiseState.firstWhere(
        (element) {
          return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
              "tamilnadu";
        },
        orElse: () => achieversAwardController.franchiseState.first,
      );
      // Assign default value as TamilNadu to State
      stateTextCtrl.text = defaultState.stateProvinceName;
      stateCtrl.text =
          defaultState.stateProvinceName.toLowerCase().removeAllWhitespace;

      await achieversAwardController.fetchFranchiseDistrict(
          stateName: defaultState.stateProvinceName);
      // Get awards list based on level
      if (achieversAwardController.levelList.isNotEmpty &&
          achieversAwardController.levelList.first.removeAllWhitespace
                  .toLowerCase() ==
              "districtlevel") {
        if (achieversAwardController.franchiseDistrict.isNotEmpty) {
          achieversAwardController.getDistrictAwardsList(body: {
            "Year": selectedYear,
            "State": defaultState.stateProvinceName,
            "District": achieversAwardController
                .franchiseDistrict[0].districtProvinceName,
          });
        }
      } else {
        achieversAwardController.getStateAwardsList(body: {
          "Year": selectedYear,
          "State": defaultState.stateProvinceName,
        });
      }
    }
    setState(() {
      scrLoader = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      key: _scaffoldKey,
      drawer: canPop
          ? null
          : const CustomDrawer(
              currentIndex: 2,
            ),
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        scrolledUnderElevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        title: CustomText(
          text: 'Top Centres',
          fontSize: 18.sp,
        ),
        leading: canPop
            ? IconButton(
                icon: const Icon(Icons.arrow_back_ios_rounded),
                onPressed: () {
                  Get.back();
                },
              )
            : IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
        actions: [
          DropdownButton<String>(
            value: selectedYear,
            icon: const Icon(
              Icons.arrow_drop_down,
              color: Colors.black,
            ),
            dropdownColor: Colors.white,
            style: const TextStyle(
              color: Colors.orange,
              fontSize: 18,
            ),
            underline: Container(),
            onChanged: (String? newValue) {
              setState(() {
                selectedYear = newValue!;
              });
            },
            items: years.map<DropdownMenuItem<String>>((String year) {
              return DropdownMenuItem<String>(
                value: year,
                child: Text(
                  year,
                  style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 18,
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 15.w),
        ],
      ),
      body: PopScopeHandler(
        behavior:
            canPop ? BackBehavior.normalPop : BackBehavior.exitOnDoubleBack,
        child: scrLoader
            ? const Center(
                child: CircularProgressIndicator.adaptive(
                valueColor: AlwaysStoppedAnimation(AppColor.primaryColor),
              ))
            : Padding(
                padding: EdgeInsets.only(left: 20.w, right: 20.w, top: 25.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              valueController: levelCtrl,
                              valueTextController: levelTextCtrl,
                              items: List.generate(
                                  achieversAwardController.levelList.length,
                                  (index) => SingleSelectDropDownModel(
                                      achieversAwardController.levelList[index],
                                      achieversAwardController.levelList[index]
                                          .toLowerCase())),
                              labelText: 'Select Level',
                              parentOnChangeCall: () async {
                                if (levelCtrl.text.removeAllWhitespace ==
                                    "districtlevel") {
                                  showDistrict.value = true;

                                  districtCtrl.clear();
                                  districtTextCtrl.clear();
                                  await achieversAwardController
                                      .fetchFranchiseDistrict(
                                    stateName: stateCtrl.text,
                                  );
                                  if (achieversAwardController
                                      .franchiseDistrict.isNotEmpty) {
                                    await achieversAwardController
                                        .getDistrictAwardsList(body: {
                                      "Year": selectedYear,
                                      "State": stateTextCtrl
                                          .text.removeAllWhitespace,
                                      "District": achieversAwardController
                                          .franchiseDistrict[0]
                                          .districtProvinceName,
                                    });
                                  }
                                } else {
                                  showDistrict.value = false;

                                  achieversAwardController
                                      .getStateAwardsList(body: {
                                    "Year": selectedYear,
                                    "State":
                                        stateTextCtrl.text.removeAllWhitespace,
                                  });
                                }
                              },
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Expanded(
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              valueController: stateCtrl,
                              valueTextController: stateTextCtrl,
                              items: List.generate(
                                achieversAwardController.franchiseState.length,
                                (index) => SingleSelectDropDownModel(
                                  achieversAwardController
                                      .franchiseState[index].stateProvinceName,
                                  achieversAwardController
                                      .franchiseState[index].stateProvinceName
                                      .toLowerCase()
                                      .removeAllWhitespace,
                                ),
                              ),
                              labelText: 'Select State',
                              parentOnChangeCall: () async {
                                districtCtrl.clear();
                                districtTextCtrl.clear();
                                await achieversAwardController
                                    .fetchFranchiseDistrict(
                                  stateName: stateCtrl.text,
                                );

                                debugPrint("levelCtrl.text ${levelCtrl.text}");

                                if (levelCtrl.text.isNotEmpty &&
                                    levelCtrl.text.removeAllWhitespace ==
                                        "statelevel") {
                                  await achieversAwardController
                                      .getStateAwardsList(body: {
                                    "Year": selectedYear,
                                    "State":
                                        stateTextCtrl.text.removeAllWhitespace,
                                  });
                                } else {
                                  if (achieversAwardController
                                      .franchiseDistrict.isNotEmpty) {
                                    await achieversAwardController
                                        .getDistrictAwardsList(body: {
                                      "Year": selectedYear,
                                      "State": stateTextCtrl
                                          .text.removeAllWhitespace,
                                      "District": achieversAwardController
                                          .franchiseDistrict[0]
                                          .districtProvinceName,
                                    });
                                  }
                                }
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20.w,
                    ),
                    Obx(() {
                      final districtList =
                          achieversAwardController.franchiseDistrict;
                      return showDistrict.value
                          ? SearchableDropdown(
                              parentOnChangeCall: () async {
                                await achieversAwardController
                                    .getDistrictAwardsList(body: {
                                  "Year": selectedYear,
                                  "State":
                                      stateTextCtrl.text.removeAllWhitespace,
                                  "District":
                                      districtTextCtrl.text.removeAllWhitespace,
                                });
                              },
                              labelText: 'Select District',
                              valueController: districtCtrl,
                              valueTextController: districtTextCtrl,
                              items: List.generate(
                                districtList.length,
                                (index) => SingleSelectDropDownModel(
                                  districtList[index].districtProvinceName,
                                  districtList[index]
                                      .districtProvinceName
                                      .toLowerCase()
                                      .removeAllWhitespace,
                                ),
                              ),
                            )
                          : const SizedBox.shrink();
                    }),
                    SizedBox(height: 20.w),
                    Obx(
                      () {
                        if (achieversAwardController
                            .achieversAwardScreenLoader.value) {
                          return const Center(
                            child: CircularProgressIndicator(
                              color: AppColor.primaryColor,
                            ),
                          );
                        } else if (achieversAwardController
                            .groupedAwardsList.isEmpty) {
                          return Center(
                            child: CustomText(
                              text: "No Data available",
                              color: AppColor.primaryColor,
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          );
                        } else {
                          return Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CustomText(
                                  text:
                                      "${showDistrict.value ? "DISTRICT" : "STATE"} LEVEL RANKING",
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.bold,
                                  color: AppColor.brightRed,
                                ),
                                // total centres count
                                CustomText(
                                  text:
                                      "ALL OVER ${stateTextCtrl.text.toUpperCase()} (${showDistrict.value ? achieversAwardController.awardsList.first.stateCount : achieversAwardController.awardsList.first.totalCount})",
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                  color: AppColor.primaryColor,
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Expanded(
                                  child: ListView.builder(
                                    // padding: const EdgeInsets.symmetric(
                                    //     horizontal: 10),
                                    scrollDirection: Axis.vertical,
                                    itemCount: achieversAwardController
                                        .groupedAwardsList
                                        .length, // Show the selected state or district only
                                    itemBuilder: (context, index) {
                                      // store current data map
                                      Map<String, List<AchieversAwardList>>
                                          temp = achieversAwardController
                                              .groupedAwardsList[index];
                                      String currentKey = temp.keys.first;
                                      List<AchieversAwardList> achieversList =
                                          temp[currentKey] ?? [];

                                      debugPrint("Current Key $currentKey");
                                      return Card(
                                        color: AppColor.lightBlue,
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 8.w,
                                          ),
                                          decoration: BoxDecoration(
                                            border: Border.all(
                                              color: AppColor.grey,
                                              strokeAlign: 0.1,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(15.0),
                                          ),
                                          child: ExpansionTile(
                                            /*   initiallyExpanded: true,
                                            dense: !showDistrict.value,
                                            trailing: showDistrict.value
                                                ? null
                                                : const SizedBox(),
                                            // disable expand button while in state mode / (Since we show only one for state)
                                            enabled: showDistrict.value,
                                            tilePadding: EdgeInsets.zero,
                                            childrenPadding: EdgeInsets.zero,
                                            minTileHeight:
                                                showDistrict.value ? null : 0,
                                            backgroundColor: AppColor.lightBlue,
                                            iconColor: showDistrict.value
                                                ? AppColor.primaryColor
                                                : AppColor.lightBlue,
                                            collapsedIconColor:
                                                AppColor.blackColor,
                                            leading: showDistrict.value
                                                ? CircleAvatar(
                                                    backgroundColor:
                                                        AppColor.lightOrange,
                                                    child: CustomText(
                                                      text:
                                                          "${achieversList.first.totalCount}",
                                                      color: AppColor.orange,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  )
                                                : null, */
                                            initiallyExpanded: true,
                                            dense: !showDistrict.value,
                                            trailing: showDistrict.value
                                                ? null
                                                : const SizedBox(),
                                            // disable expand button while in state mode / (Since we show only one for state)
                                            enabled: showDistrict.value,
                                            tilePadding: EdgeInsets.zero,
                                            childrenPadding: EdgeInsets.zero,
                                            minTileHeight:
                                                showDistrict.value ? null : 0,
                                            backgroundColor: AppColor.lightBlue,
                                            iconColor: showDistrict.value
                                                ? AppColor.primaryColor
                                                : AppColor.lightBlue,
                                            collapsedIconColor:
                                                AppColor.blackColor,
                                            title: showDistrict.value
                                                ? Row(
                                                    children: [
                                                      Flexible(
                                                        child: CustomText(
                                                          text:
                                                              "${index + 1}. ${achieversList.first.district.toUpperCase()}",
                                                          color: AppColor
                                                              .blackColor,
                                                          fontSize: 14.sp,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                      CustomText(
                                                        text:
                                                            " (${achieversList.first.totalCount})",
                                                        color: AppColor
                                                            .primaryColor,
                                                        fontSize: 14.sp,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ],
                                                  )
                                                : const SizedBox(),
                                            children: List.generate(
                                                achieversList.length,
                                                (rankIndex) {
                                              return Container(
                                                margin:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 5),
                                                child: Column(
                                                  children: [
                                                    ListTile(
                                                      minVerticalPadding: 0,
                                                      contentPadding:
                                                          const EdgeInsets.all(
                                                              5),
                                                      // tileColor: AppColor.whiteColor,
                                                      leading: Container(
                                                        height: 60.w,
                                                        width: 60.w,
                                                        clipBehavior:
                                                            Clip.antiAlias,
                                                        decoration:
                                                            const BoxDecoration(
                                                                shape: BoxShape
                                                                    .circle),
                                                        // show base64 image only when it's not empty
                                                        // else show default image
                                                        child: achieversList[
                                                                        rankIndex]
                                                                    .base64Image !=
                                                                null
                                                            ? Image.memory(
                                                                base64Decode(
                                                                    achieversList[
                                                                            rankIndex]
                                                                        .base64Image!),
                                                                fit: BoxFit
                                                                    .cover,
                                                                errorBuilder: (context,
                                                                        error,
                                                                        stackTrace) =>
                                                                    Image.asset(
                                                                  AssetPath
                                                                      .userIcon,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              )
                                                            : Image.asset(
                                                                AssetPath
                                                                    .userIcon,
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),
                                                      ),
                                                      title: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .contactName,
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            fontSize: 14.sp,
                                                          ),
                                                          const SizedBox(
                                                            height: 5,
                                                          ),
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .centreName,
                                                            color: AppColor
                                                                .blackColor,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            fontSize: 14.sp,
                                                          ),
                                                          const SizedBox(
                                                            height: 5,
                                                          ),
                                                        ],
                                                      ),
                                                      subtitle: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .area,
                                                            color: AppColor
                                                                .blackColor,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize: 14.sp,
                                                          ),
                                                          const SizedBox(
                                                            height: 5,
                                                          ),
                                                          CustomText(
                                                            text: achieversList[
                                                                    rankIndex]
                                                                .taluk,
                                                            color: AppColor
                                                                .blackColor,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize: 14.sp,
                                                          ),
                                                          if (!showDistrict
                                                              .value) ...[
                                                            const SizedBox(
                                                              height: 5,
                                                            ),
                                                            CustomText(
                                                              text: achieversList[
                                                                      rankIndex]
                                                                  .district,
                                                              color: AppColor
                                                                  .blackColor,
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              maxLines: 2,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontSize: 14.sp,
                                                            ),
                                                            const SizedBox(
                                                              height: 5,
                                                            ),
                                                            CustomText(
                                                              text: achieversList[
                                                                          rankIndex]
                                                                      .franchiseeCode
                                                                      .isEmpty
                                                                  ? '-'
                                                                  : achieversList[
                                                                          rankIndex]
                                                                      .franchiseeCode,
                                                              color: AppColor
                                                                  .primaryColor,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 14.sp,
                                                            ),
                                                          ]
                                                        ],
                                                      ),
                                                      trailing: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .end,
                                                        children: [
                                                          CustomText(
                                                            text: (showDistrict
                                                                        .value &&
                                                                    districtTextCtrl
                                                                            .text
                                                                            .toLowerCase() ==
                                                                        'all')
                                                                ? achieversList[
                                                                        rankIndex]
                                                                    .districtRank
                                                                    .padLeft(
                                                                        2, "0")
                                                                : achieversList[
                                                                        rankIndex]
                                                                    .rank
                                                                    .toString()
                                                                    .padLeft(
                                                                        2, "0"),
                                                            color: Colors
                                                                .deepOrangeAccent,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 16.sp,
                                                          ),
                                                          if (showDistrict
                                                              .value)
                                                            CustomText(
                                                              text: achieversList[
                                                                          rankIndex]
                                                                      .franchiseeCode
                                                                      .isEmpty
                                                                  ? '-'
                                                                  : achieversList[
                                                                          rankIndex]
                                                                      .franchiseeCode,
                                                              color: AppColor
                                                                  .primaryColor,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              fontSize: 14.sp,
                                                            ),
                                                        ],
                                                      ),
                                                    ),
                                                    if ((achieversList.length -
                                                            1) !=
                                                        rankIndex)
                                                      const Divider(
                                                        // Divider after the subtitle
                                                        color: AppColor.grey,
                                                        thickness: 0.5,
                                                      ),
                                                  ],
                                                ),
                                              );
                                            }),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
