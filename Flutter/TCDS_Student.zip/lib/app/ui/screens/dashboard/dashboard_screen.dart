import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/widgets/pop_scope_handler.dart';
import '../../../../constants/app_string.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../../constants/shared_pref.dart';
import '../../../controllers/dashboard_controller.dart';
import '../../../routes/routes.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/custom_drawer.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  DashboardController dashBoardController = Get.find<DashboardController>();
  // late YoutubePlayerController _controller;
  bool canPop = false;

  bool isUser = false;

  DateTime now = DateTime.now();

  late String todayDate;
  late String todayDayName;

  // LIST : Quick widgets data
  late List<Map<String, dynamic>> quickWidgetData;

  @override
  void initState() {
    super.initState();
    // if only user logged in call user details API
    isUser = SharedPref.getBool(AppStrings.isLoggedIn);
    quickWidgetData = buildQuickWidgets();
    todayDate = DateFormat("dd-MM-yyyy").format(now);
    todayDayName = DateFormat('EEEE').format(now);
    dashBoardController.dashboardLoader.value = true;
    if (isUser) {
      neccessaryAPICalls();
    }
    dashBoardController.dashboardLoader.value = false;

    // const videoUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'; // Replace with your URL
    // final videoId = YoutubePlayer.convertUrlToId(videoUrl);
    // _controller = YoutubePlayerController(
    //   initialVideoId: videoId!,
    //   flags: const YoutubePlayerFlags(
    //     autoPlay: true,
    //     mute: false,
    //   ),
    // );

    // dashboardController.getDashboardData();
  }

// call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    await dashBoardController.personalDetail(
        contactID: SharedPref.getString(AppStrings.contactID));
  }

  // generate Quick Widgets data
  List<Map<String, dynamic>> buildQuickWidgets() {
    return [
      {
        "assetPath": AssetPath.centreCourseDetails,
        "title": "TCDS Centres & Course Details",
        "color": AppColor.brightGreen,
        "enabled": true,
        "routeDetails": {
          "route": Routes.centreList,
          "appBarTitle": "TCDS Centres & Courses"
        }
      },
      {
        "assetPath": AssetPath.enqRegister,
        "title": "Enquiry & Registration",
        "color": AppColor.brightOrange,
        "enabled": !isUser,
        "routeDetails": {
          "route": Routes.centreList,
          "appBarTitle": "Enquiry & Registration"
        }
      },
      {
        "assetPath": AssetPath.topCentres,
        "title": "TCDS Centres Ranking",
        // "title": "State Top 10 and District Top 3 Centres",
        "color": AppColor.brightBlue2,
        "enabled": true,
        "routeDetails": {
          "route": Routes.awards,
        }
      },
      {
        "assetPath": AssetPath.profileCertificateVerify,
        "title": "My Profile",
        "color": AppColor.brightBlue3,
        "enabled": isUser,
        "routeDetails": {
          "route": Routes.myProfile,
        }
      },
      {
        "assetPath": AssetPath.mailBox,
        "title": "Mail Box",
        "color": AppColor.brightRed,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
      {
        "assetPath": AssetPath.modelDownloads,
        "title": "Downloads", //"Downloads Model Online Exam"
        "color": AppColor.brightGrey,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
      {
        "assetPath": AssetPath.jobOpportunities,
        "title": "Job Opportunities All over Tamilnadu",
        "color": AppColor.brightLightGreen,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
      {
        "assetPath": AssetPath.businessOpportunities,
        "title": "An Unique Business Opportunities",
        "color": AppColor.brightBlue,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
      {
        "assetPath": AssetPath.theoryClass,
        "title": "Video Class for Theory",
        "color": AppColor.brightPurple,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
      {
        "assetPath": AssetPath.practicalClass,
        "title": "Video Class for Practical Lab",
        "color": AppColor.brightViolet,
        "enabled": false,
        "routeDetails": {
          "route": Routes.centreList,
        }
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    // double width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: AppColor.whiteColor,
        key: _scaffoldKey,
        appBar: AppBar(
          backgroundColor: AppColor.whiteColor,
          elevation: 4,
          scrolledUnderElevation: 4,
          surfaceTintColor: AppColor.whiteColor,
          shadowColor: AppColor.black2Color,
          leading: IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () {
              _scaffoldKey.currentState!.openDrawer();
            },
          ),
          title: CustomText(
            text: "Dashboard",
            fontSize: 20.sp,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w400,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        drawer: const CustomDrawer(
          currentIndex: 0,
        ),
        body: Obx(
          () => dashBoardController.dashboardLoader.value
              ? const Center(
                  child: CircularProgressIndicator(
                    color: AppColor.primaryColor,
                  ),
                )
              : PopScopeHandler(
                  child: Column(
                    children: [
                      // YoutubePlayer(
                      //   controller: _controller,
                      //   showVideoProgressIndicator: true,
                      //   progressIndicatorColor: Colors.red,
                      // ),
                      // _pages[_selectedIndex],
                      /*  CustomText(
              text: "Welcome Video",
              color: AppColor.primaryColor,
              fontWeight: FontWeight.w500,
              fontSize: 16.sp,
            ),
            CustomText(
              text: "Welcome to TCDS Computer Education",
              color: AppColor.blackColor,
              fontWeight: FontWeight.w400,
              fontSize: 14.sp,
            ), */
                      // date time informations box
                      Padding(
                        padding: EdgeInsets.all(20.w),
                        child: Row(
                          children: [
                            Expanded(
                                child: DateTimeBox(
                              boxColor: AppColor.red,
                              content: todayDate,
                              title: "Date",
                            )),
                            SizedBox(
                              width: 10.w,
                            ),
                            Expanded(
                                child: DateTimeBox(
                              boxColor: AppColor.brightLightGreen,
                              content: todayDayName,
                              title: "Day",
                            )),
                          ],
                        ),
                      ),

                      // Student Course card
                      if (isUser &&
                          dashBoardController.personalInfoDetail.isNotEmpty)
                        Obx(() {
                          final profDetails =
                              dashBoardController.personalInfoDetail[0];

                          return Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 20.w, vertical: 0),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColor.darkGreen,
                              // border: Border(
                              //   left: BorderSide(color: AppColor.lightGreen, width: 5),
                              // ),
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Flexible(
                                      child: CustomText(
                                        text:
                                            "${profDetails.studentName}, ${profDetails.qualification}",
                                        color: AppColor.whiteColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14.sp,
                                      ),
                                    ),
                                    Flexible(
                                      child: CustomText(
                                        text: profDetails.rollNumber,
                                        color: AppColor.whiteColor,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 12.sp,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // profile Image
                                    Container(
                                      height: 65.w,
                                      width: 65.w,
                                      clipBehavior: Clip.antiAlias,
                                      decoration: const BoxDecoration(
                                        shape: BoxShape.circle,
                                      ),
                                      child: (profDetails
                                                  .studentImages.isNotEmpty &&
                                              profDetails.studentImages[0]
                                                      .profileBase64 !=
                                                  null)
                                          ? Image.memory(
                                              base64Decode(profDetails
                                                  .studentImages[0]
                                                  .profileBase64!),
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error,
                                                      stackTrace) =>
                                                  Image.asset(
                                                AssetPath.defaultProfile,
                                                height: 65.w,
                                                width: 65.w,
                                                fit: BoxFit.cover,
                                              ),
                                            )
                                          : Image.asset(
                                              AssetPath.defaultProfile,
                                              fit: BoxFit.cover,
                                            ),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    // Student/user details
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          Row(
                                            mainAxisAlignment: profDetails
                                                    .courses.isNotEmpty
                                                ? MainAxisAlignment.spaceBetween
                                                : MainAxisAlignment.center,
                                            children: [
                                              Flexible(
                                                child: CustomText(
                                                  text: profDetails
                                                          .courses.isNotEmpty
                                                      ? profDetails
                                                          .courses[0].shortName
                                                      : "No Course enrolled",
                                                  color: AppColor.whiteColor,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 12.sp,
                                                ),
                                              ),
                                              if (profDetails
                                                  .courses.isNotEmpty)
                                                Flexible(
                                                  child: CustomText(
                                                    text:
                                                        "(${profDetails.courses.first.studentCourse.batch.startDate} - ${profDetails.courses.first.studentCourse.batch.endDate})",
                                                    color: AppColor.whiteColor,
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 10.sp,
                                                  ),
                                                ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.w,
                                          ),
                                          if (dashBoardController
                                              .personalInfoDetail[0]
                                              .courses
                                              .isNotEmpty)
                                            CustomText(
                                              text:
                                                  "(${profDetails.courses[0].fullName.toUpperCase()})",
                                              color: AppColor.whiteColor,
                                              fontWeight: FontWeight.w500,
                                              fontSize: 12.sp,
                                            ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            ),
                          );
                        }),
                      if (isUser)
                        const SizedBox(
                          height: 20,
                        ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: CustomText(
                            text: "Main Features",
                            fontWeight: FontWeight.bold,
                            fontSize: 16.sp,
                          ),
                        ),
                      ),
                      // main Features Sections
                      Expanded(
                        child: GridView.builder(
                            itemCount: quickWidgetData.length,
                            padding: EdgeInsets.all(20.w),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 2,
                                    childAspectRatio: 1.5,
                                    mainAxisSpacing: 20,
                                    crossAxisSpacing: 20),
                            itemBuilder: (context, index) {
                              final data = quickWidgetData[index];

                              return MainFeatureTile(
                                onTap: data['enabled']
                                    ? () {
                                        // if enabled, and had route details, navigate..
                                        if (data["routeDetails"] != null) {
                                          Get.toNamed(
                                              data["routeDetails"]["route"],
                                              arguments: {
                                                "appBarTitle":
                                                    data["routeDetails"]
                                                        ["appBarTitle"],
                                                "canPop": true,
                                              });
                                        }
                                      }
                                    : null,
                                color: data["color"],
                                title: data["title"],
                                assetPath: data['assetPath'],
                                enabled: data['enabled'],
                              );
                            }),
                      )
                    ],
                  ),
                ),
        ));
  }
}

// WIDGET: Main features grid tile
class MainFeatureTile extends StatelessWidget {
  final Color color;
  final String title;
  final String assetPath;
  final bool enabled;
  final void Function()? onTap;
  const MainFeatureTile(
      {super.key,
      required this.color,
      required this.title,
      required this.assetPath,
      required this.enabled,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Material(
            color: Colors.transparent,
            child: Ink(
              decoration: BoxDecoration(
                color: color,
                // color: AppColor.grey,
                // gradient: LinearGradient(colors: [
                //   color.withAlpha(110),
                //   color,
                // ]),
                border: enabled ? Border.all(color: AppColor.grey) : null,
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: InkWell(
                onTap: onTap,
                splashColor: AppColor.white2Color.withAlpha(100),
                highlightColor: AppColor.primaryColor.withAlpha(80),
                borderRadius: BorderRadius.circular(12.r),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: const BoxDecoration(
                            color: AppColor.whiteColor, shape: BoxShape.circle),
                        child: Image.asset(
                          assetPath,
                          height: 35.w,
                          width: 35.w,
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Expanded(
                          child: CustomText(
                        text: title,
                        color: AppColor.whiteColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 13.sp,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.clip,
                      )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        if (!enabled)
          Container(
            decoration: BoxDecoration(
              color: AppColor.grey.withAlpha(160),
              borderRadius: BorderRadius.circular(12.r),
            ),
          ),
      ],
    );
  }
}

// WIDGET : To show date or time informations as a Box
class DateTimeBox extends StatelessWidget {
  final String title;
  final Color boxColor;
  final String content;
  const DateTimeBox(
      {super.key,
      required this.title,
      required this.boxColor,
      required this.content});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(5),
          alignment: Alignment.center,
          color: boxColor,
          child: CustomText(
            text: title,
            color: AppColor.whiteColor,
            fontSize: 14.sp,
            fontWeight: FontWeight.w500,
          ),
        ),
        Container(
          width: double.infinity,
          alignment: Alignment.center,
          padding: const EdgeInsets.all(5),
          decoration: const BoxDecoration(
              border: Border(
            bottom: BorderSide(color: AppColor.black2Color, width: 1),
            left: BorderSide(color: AppColor.black2Color, width: 1),
            right: BorderSide(color: AppColor.black2Color, width: 1),
          )),
          child: CustomText(
            text: content,
            fontWeight: FontWeight.w400,
            color: AppColor.blackColor,
          ),
        ),
      ],
    );
  }
}
