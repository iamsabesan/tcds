import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart' hide Material;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/screens/dashboard/profile_list_tile.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import '../../../../constants/app_string.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../../constants/shared_pref.dart';
import '../../../controllers/my_profile_controller.dart';
import '../../../controllers/register_controller.dart';
import '../../../models/profile/personal_detail_model.dart' as pdm;
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/grey_container_widget.dart';
import '../../widgets/tab_container_widget.dart';

class MyProfile extends StatefulWidget {
  const MyProfile({super.key});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> with TickerProviderStateMixin {
  // find register controller
  MyProfileController profileController = Get.find<MyProfileController>();
  RegisterController registerController = Get.find<RegisterController>();
  String approvalDate = "";
  int totalTheoryMarks = 0;
  int totalPracticalMarks = 0;
  int totalTotalMarks = 0;
  File? selectedImage;
  late TabController _tabController;
  late TabController _examTabController;
  late TabController _materialTabController;
  late TabController _certificateTabController;
  Map<int, List<pdm.Material>> groupedBySemester = {};
  Map<int, Map<String, int>> semesterTotalMarks = {};

  NumberFormat currencyFormat =
      NumberFormat.currency(decimalDigits: 2, symbol: "₹", locale: "hi_IN");

  @override
  void initState() {
    neccessaryAPICalls();

    super.initState();
  }

  // call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    profileController.centresScrLoader.value = true;
    await profileController.personalDetail(
        studentId: SharedPref.getString(AppStrings
            .contactID)); //"83F1A50A-BA85-45E2-9696-061FBB10F7C5"  SharedPref.getString(AppStrings.studentEnquiryID)
    await registerController.fetchCentreDetails();

    _tabController = TabController(
        length: profileController.stdntPersonalDetail.isNotEmpty
            ? profileController.stdntPersonalDetail[0].courses.length
            : 0,
        vsync: this);
    _examTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);
    _materialTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);
    _certificateTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);

    profileController.centresScrLoader.value = false;

    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        debugPrint(_tabController.index.toString());

        // Update selected index and rebuild semester tab controllers
        setState(() {
          _selectedIndex = _tabController.index; // Update selected index

          // Dispose old controllers
          _examTabController.dispose();
          _materialTabController.dispose();
          _certificateTabController.dispose();

          // Reinitialize semester tab controllers for the new course
          final newCourse = profileController.stdntPersonalDetail.isNotEmpty &&
                  profileController.stdntPersonalDetail[0].courses.isNotEmpty &&
                  _selectedIndex <
                      profileController.stdntPersonalDetail[0].courses.length
              ? profileController.stdntPersonalDetail[0].courses[_selectedIndex]
              : null;

          final semesterCount =
              newCourse?.studentCourse.course.totalSemesters ?? 0;

          _examTabController =
              TabController(length: semesterCount, vsync: this);
          _materialTabController =
              TabController(length: semesterCount, vsync: this);
          _certificateTabController =
              TabController(length: semesterCount, vsync: this);
        });
      }
    });
    showPage = true;

    setState(() {});
  }

  // textediting controller
  TextEditingController stateTxtCtrl = TextEditingController();
  TextEditingController stateIDCtrl = TextEditingController();
  TextEditingController districtTxtCtrl = TextEditingController();
  TextEditingController districtIDCtrl = TextEditingController();
  TextEditingController talukTxtCtrl = TextEditingController();
  TextEditingController talukIDCtrl = TextEditingController();

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> registeredFormKey = GlobalKey<FormState>();
  int selectedDayIndex = 0;
  DateFormat inputFormat = DateFormat("dd-MM-yyyy");

  // Define the desired output format
  DateFormat outputFormat = DateFormat("dd/MM/yyyy");
  bool showPage = false;
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backgroundBlue,
      appBar: PreferredSize(
        preferredSize: Size(double.infinity, 140.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.only(bottom: 15.w, top: 50.w),
              decoration: const BoxDecoration(
                color: AppColor.whiteColor,
                boxShadow: [
                  BoxShadow(color: AppColor.whiteColor),
                  BoxShadow(color: AppColor.whiteColor),
                  BoxShadow(color: AppColor.whiteColor),
                  BoxShadow(
                    color: AppColor.grey,
                    offset: Offset(0, 6),
                    spreadRadius: 0.5,
                    blurRadius: 4,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(width: 20.w),
                  InkWell(
                    splashColor: AppColor.black2Color,
                    onTap: () => Get.back(),
                    child: Icon(Icons.arrow_back_ios_new_outlined, size: 30.w),
                  ),
                  SizedBox(width: 15.w),
                  Expanded(
                    child: CustomText(
                      text: "My Profile",
                      fontSize: 16.sp,
                      color: AppColor.blackColor,
                      maxLines: 1,
                      fontWeight: FontWeight.w500,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Obx(
        () => profileController.centresScrLoader.value
            ? const CustomProgressIndicator()
            : ListView(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                children: [
                  SizedBox(height: 20.w),

                  // Profile Picture
                  Center(
                    child: ClipOval(
                      child: profileController.stdntPersonalDetail.isEmpty
                          ? Image.asset(AssetPath.defaultProfile,
                              height: 70.w, width: 70.w, fit: BoxFit.cover)
                          : profileController
                                  .stdntPersonalDetail[0].studentImages.isEmpty
                              ? Image.asset(AssetPath.defaultProfile,
                                  height: 100.w,
                                  width: 100.w,
                                  fit: BoxFit.cover)
                              : Image.memory(
                                  base64Decode(profileController
                                      .stdntPersonalDetail[0]
                                      .studentImages[0]
                                      .profileBase64),
                                  height: 90.w,
                                  width: 90.w,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Image.asset(
                                    AssetPath.defaultProfile,
                                    height: 50.w,
                                    width: 50.w,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                    ),
                  ),
                  SizedBox(height: 5.w),

                  // Student Name
                  Center(
                    child: CustomText(
                      text:
                          profileController.stdntPersonalDetail[0].studentName,
                      fontSize: 17.sp,
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500,
                      maxLines: 2,
                    ),
                  ),
                  SizedBox(height: 5.w),

                  // Roll Number
                  Center(
                    child: CustomText(
                      text: profileController.stdntPersonalDetail[0].rollNumber,
                      fontSize: 16.sp,
                      color: AppColor.blackColor,
                      fontWeight: FontWeight.w500,
                      maxLines: 2,
                    ),
                  ),
                  SizedBox(height: 30.w),

                  // Personal Details Container
                  GreyContainerWidget(
                    color: AppColor.containerWhiteColor,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              flex: 50,
                              child: ProfileListTile(
                                assetName: AssetPath.gender,
                                title: 'Gender',
                                subTitle: profileController
                                    .stdntPersonalDetail[0].gender,
                              ),
                            ),
                            Expanded(
                              flex: 50,
                              child: ProfileListTile(
                                assetName: AssetPath.calender,
                                title: 'Date of Birth',
                                subTitle: DateFormat('dd-MM-yyyy').format(
                                    profileController
                                        .stdntPersonalDetail[0].dateOfBirth),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 5.w),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 50,
                              child: ProfileListTile(
                                assetName: AssetPath.stdMobile,
                                title: 'Mobile',
                                subTitle:
                                    "${profileController.stdntPersonalDetail[0].phoneCode} ${profileController.stdntPersonalDetail[0].phone}",
                              ),
                            ),
                            if (profileController.stdntPersonalDetail[0]
                                .alternatePhone.isNotEmpty)
                              Expanded(
                                flex: 50,
                                child: ProfileListTile(
                                  assetName: AssetPath.stdMobile,
                                  title: 'Alternate Mobile',
                                  subTitle:
                                      "${profileController.stdntPersonalDetail[0].alternatePhoneCode} ${profileController.stdntPersonalDetail[0].alternatePhone}",
                                ),
                              ),
                          ],
                        ),
                        SizedBox(height: 5.w),
                        ProfileListTile(
                          assetName: AssetPath.qualification,
                          title: 'Qualification',
                          subTitle: profileController
                              .stdntPersonalDetail[0].qualification,
                        ),
                        SizedBox(height: 5.w),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 50,
                              child: ProfileListTile(
                                assetName: AssetPath.person,
                                title: 'Father Name',
                                subTitle: profileController
                                    .stdntPersonalDetail[0].fatherName,
                              ),
                            ),
                            Expanded(
                              flex: 50,
                              child: ProfileListTile(
                                assetName: AssetPath.occupation,
                                title: 'Occupation',
                                subTitle: profileController
                                    .stdntPersonalDetail[0].occupation,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 30.w),

                  // Course Tabs
                  if (profileController.stdntPersonalDetail.isNotEmpty &&
                      profileController
                          .stdntPersonalDetail[0].courses.isNotEmpty)
                    TabContainerWidget(
                      color: AppColor.containerBlue,
                      child: TabBar(
                        controller: _tabController,
                        isScrollable: true,
                        tabAlignment: TabAlignment.center,
                        tabs: List<Widget>.generate(
                          profileController
                              .stdntPersonalDetail[0].courses.length,
                          (index) {
                            bool isSelected = _selectedIndex == index;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.r),
                                color: isSelected
                                    ? AppColor.whiteColor
                                    : AppColor.containerBlue,
                              ),
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 10.w),
                                child: Tab(
                                    text: profileController
                                        .stdntPersonalDetail[0]
                                        .courses[index]
                                        .fullName),
                              ),
                            );
                          },
                        ),
                        indicatorColor: Colors.transparent,
                        labelColor: AppColor.primaryColor,
                        unselectedLabelColor: Colors.grey,
                        dividerColor: Colors.transparent,
                      ),
                    ),
                  SizedBox(height: 20.w),

                  // TabBarView Content - Show only selected tab
                  ...List<Widget>.generate(
                    profileController.stdntPersonalDetail.isNotEmpty &&
                            profileController
                                .stdntPersonalDetail[0].courses.isNotEmpty
                        ? profileController
                            .stdntPersonalDetail[0].courses.length
                        : 0,
                    (courseIndex) {
                      if (courseIndex != _selectedIndex) {
                        return const SizedBox.shrink();
                      }

                      // Defensive check for course data
                      final currentCourse =
                          profileController.stdntPersonalDetail.isNotEmpty &&
                                  profileController.stdntPersonalDetail[0]
                                      .courses.isNotEmpty &&
                                  courseIndex <
                                      profileController
                                          .stdntPersonalDetail[0].courses.length
                              ? profileController
                                  .stdntPersonalDetail[0].courses[courseIndex]
                              : null;

                      if (currentCourse == null) {
                        return const SizedBox.shrink();
                      }

                      // CRITICAL: Clear and rebuild data for THIS course
                      groupedBySemester.clear();
                      semesterTotalMarks.clear();

                      // Group materials by semester for THIS COURSE
                      for (var material
                          in currentCourse.studentCourse.materials) {
                        int semester = material.semester;
                        if (!groupedBySemester.containsKey(semester)) {
                          groupedBySemester[semester] = [];
                          semesterTotalMarks[semester] = {
                            "TotalMarks": 0,
                            "TheoryMarks": 0,
                            "PracticalMarks": 0
                          };
                        }
                        groupedBySemester[semester]?.add(material);
                      }

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildCourseDetailsContainer(currentCourse),
                          SizedBox(height: 20.w),
                          _buildExamMarksContainer(currentCourse),
                          SizedBox(height: 15.w),
                          _buildFeesDetailsContainer(currentCourse),
                          SizedBox(height: 20.w),
                          _buildMaterialReceivedContainer(currentCourse),
                          if (currentCourse
                                  .studentCourse.marksheet.isNotEmpty ==
                              true) ...[
                            SizedBox(height: 15.w),
                            _buildMarkSheetContainer(currentCourse),
                          ],
                          SizedBox(height: 20.w),
                          _buildCertificateReceivedContainer(currentCourse),
                          SizedBox(height: 60.w),
                        ],
                      );
                    },
                  ),
                ],
              ),
      ),
    );
  }

// Helper Methods - Add these after build method
  Widget _buildCourseDetailsContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w),
            child: Row(
              children: [
                ClipOval(
                  child: Image.asset(AssetPath.batchImg,
                      height: 35.w, width: 35.w, fit: BoxFit.cover),
                ),
                SizedBox(width: 15.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text:
                            "${course.studentCourse.course.courseType} Course",
                        fontSize: 14.sp,
                        color: AppColor.primaryColor,
                        fontWeight: FontWeight.w500,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 10.w),
                      CustomText(
                        text: currencyFormat
                            .format(course.studentCourse.course.courseFees),
                        fontSize: 13.sp,
                        color: AppColor.black3Color,
                        fontWeight: FontWeight.w500,
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CustomText(
                      text: course.studentCourse.course.status,
                      color: AppColor.secondaryColor,
                      fontWeight: FontWeight.w500,
                    ),
                    SizedBox(height: 10.w),
                    CustomText(
                      text:
                          "${course.studentCourse.batch.batchType}/${course.studentCourse.batch.batchTrack}",
                      fontSize: 12.sp,
                      color: AppColor.black3Color,
                      fontWeight: FontWeight.w500,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              CustomText(
                text:
                    "${outputFormat.format(inputFormat.parse(course.studentCourse.batch.startDate))} - ${outputFormat.format(inputFormat.parse(course.studentCourse.batch.endDate))}",
                fontSize: 12.sp,
                color: AppColor.primaryColor,
                fontWeight: FontWeight.w500,
              ),
              CustomText(
                text:
                    "${course.studentCourse.batch.startTime} to ${course.studentCourse.batch.endTime}",
                fontSize: 12.sp,
                color: AppColor.secondaryColor,
                fontWeight: FontWeight.w500,
              ),
            ],
          ),
          const SizedBox(height: 5),
          Wrap(
            children: [
              BulletText(text: course.studentCourse.course.shortName),
              BulletText(text: course.studentCourse.course.duration),
              BulletText(
                  text:
                      "${course.studentCourse.course.totalSemesters} Semester(s)"),
              BulletText(text: course.studentCourse.course.status),
            ],
          ),
          const SizedBox(height: 5),
          CustomText(
            text: course.studentCourse.batch.facultyName,
            fontSize: 12.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
        ],
      ),
    );
  }

  Widget _buildExamMarksContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: "Exam Mark",
            fontSize: 15.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
          TabBar(
            controller: _examTabController,
            tabs: List<Widget>.generate(
              course.studentCourse.course.totalSemesters,
              (index) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 5.w),
                child: Tab(text: "Semester ${index + 1}"),
              ),
            ),
            indicatorColor: Colors.orange,
            indicatorWeight: 5,
            labelColor: AppColor.primaryColor,
            unselectedLabelColor: Colors.grey,
          ),
          SizedBox(
            height: 250.w,
            child: TabBarView(
              controller: _examTabController,
              children: List<Widget>.generate(
                course.studentCourse.course.totalSemesters,
                (semesterIndex) {
                  // Get materials for THIS semester (semesterIndex + 1 because semesters start at 1)
                  int semesterNum = semesterIndex + 1;
                  var semesterMaterials = groupedBySemester[semesterNum] ?? [];

                  if (semesterMaterials.isEmpty) {
                    return Center(
                      child: CustomText(
                        text: "No materials for Semester $semesterNum",
                        fontSize: 14.sp,
                        color: AppColor.black3Color,
                      ),
                    );
                  }

                  // Calculate totals for THIS semester
                  double totalTheory = 0;
                  double totalPractical = 0;
                  double totalTotal = 0;

                  for (var material in semesterMaterials) {
                    totalTheory += material.theoryMarks;
                    totalPractical += material.practicalMarks;
                    totalTotal += material.totalMarks;
                  }

                  return ListView(
                    physics: const ClampingScrollPhysics(),
                    padding: EdgeInsets.symmetric(horizontal: 5.w),
                    children: [
                      ...semesterMaterials.map((material) => Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: CustomText(
                                      text: material.materialName,
                                      fontSize: 14.sp,
                                      color: AppColor.primaryColor,
                                      fontWeight: FontWeight.w500,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(right: 20.w),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      children: [
                                        CustomText(
                                          text: "${material.totalMarks} marks",
                                          fontSize: 12.sp,
                                          color: AppColor.secondaryColor,
                                          fontWeight: FontWeight.w500,
                                        ),
                                        SizedBox(height: 10.w),
                                        CustomText(
                                          text:
                                              "${material.theoryMarks} (T) ● ${material.practicalMarks} (P)",
                                          fontSize: 12.sp,
                                          color: AppColor.black3Color,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const Divider(),
                            ],
                          )),
                      Row(
                        children: [
                          Expanded(
                            child: CustomText(
                              text: "Total marks:",
                              fontSize: 14.sp,
                              color: AppColor.primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 20.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                CustomText(
                                  text: "${totalTotal.toInt()} marks",
                                  fontSize: 12.sp,
                                  color: AppColor.secondaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                                CustomText(
                                  text:
                                      "${totalTheory.toInt()} Theory ● ${totalPractical.toInt()} Practical",
                                  fontSize: 12.sp,
                                  color: AppColor.black3Color,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeesDetailsContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: "Fees Details",
            fontSize: 15.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
          SizedBox(height: 20.w),
          GreyContainerWidget(
            color: AppColor.lightPurple,
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: AppColor.containerWhiteColor,
                          width: 3.w,
                        ),
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(right: 10.w),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              text: "Course Fees",
                              fontSize: 12.sp,
                              color: AppColor.titleColor,
                              fontWeight: FontWeight.w500,
                            ),
                            CustomText(
                              text: course.studentCourse.course.courseFees
                                  .toStringAsFixed(2),
                              fontSize: 14.sp,
                              color: AppColor.subTitleColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: AppColor.containerWhiteColor,
                          width: 3.w,
                        ),
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(right: 10.w),
                      child: Align(
                        alignment: Alignment.center,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            CustomText(
                              text: "Discount",
                              fontSize: 12.sp,
                              color: AppColor.titleColor,
                              fontWeight: FontWeight.w500,
                            ),
                            CustomText(
                              text: course.studentCourse.course.discountAmount
                                  .toString(),
                              fontSize: 14.sp,
                              color: AppColor.subTitleColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(right: 10.w),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          CustomText(
                            text: "Discount (%)",
                            fontSize: 12.sp,
                            color: AppColor.titleColor,
                            fontWeight: FontWeight.w500,
                          ),
                          CustomText(
                            text:
                                "${course.studentCourse.course.discount.toStringAsFixed(0)}%",
                            fontSize: 14.sp,
                            color: AppColor.subTitleColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          GreyContainerWidget(
            color: AppColor.containerBlue,
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: AppColor.containerWhiteColor,
                          width: 3.w,
                        ),
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(right: 10.w),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomText(
                              text: "Net Fees",
                              fontSize: 12.sp,
                              color: AppColor.blackColor,
                              fontWeight: FontWeight.w500,
                            ),
                            CustomText(
                              text: course.studentCourse.course.totalFees
                                  .toStringAsFixed(2),
                              fontSize: 14.sp,
                              color: AppColor.subTitleColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: AppColor.containerWhiteColor,
                          width: 3.w,
                        ),
                      ),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(right: 10.w),
                      child: Align(
                        alignment: Alignment.center,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            CustomText(
                              text: "Fees Paid",
                              fontSize: 12.sp,
                              color: AppColor.titleColor,
                              fontWeight: FontWeight.w500,
                            ),
                            CustomText(
                              text: course.studentCourse.course.paidFees
                                  .toStringAsFixed(2),
                              fontSize: 14.sp,
                              color: AppColor.subTitleColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(right: 10.w),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          CustomText(
                            text: "Fees Balance",
                            fontSize: 12.sp,
                            color: AppColor.titleColor,
                            fontWeight: FontWeight.w500,
                          ),
                          CustomText(
                            text: course.studentCourse.course.balance
                                .toStringAsFixed(2),
                            fontSize: 14.sp,
                            color: AppColor.subTitleColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20.w),
          // Payment List
          ...course.studentCourse.payments.asMap().entries.map((entry) {
            int index = entry.key;
            var payment = entry.value;
            return Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: outputFormat
                                .format(inputFormat.parse(payment.receiptDate)),
                            fontSize: 12.sp,
                            color: AppColor.secondaryColor,
                            fontWeight: FontWeight.w500,
                          ),
                          SizedBox(height: 3.w),
                          CustomText(
                            text: "#${payment.receiptNo}",
                            fontSize: 12.sp,
                            color: AppColor.black3Color,
                            fontWeight: FontWeight.w600,
                          ),
                          SizedBox(height: 3.w),
                          CustomText(
                            text: payment.paymode,
                            fontSize: 12.sp,
                            color: AppColor.black3Color,
                            fontWeight: FontWeight.w600,
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        CustomText(
                          text: currencyFormat.format(payment.amount),
                          fontSize: 12.sp,
                          color: AppColor.secondaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(height: 3.w),
                        CustomText(
                          text: payment.paymentType,
                          fontSize: 12.sp,
                          color: AppColor.black3Color,
                          fontWeight: FontWeight.w600,
                        ),
                      ],
                    ),
                  ],
                ),
                if (index != course.studentCourse.payments.length - 1)
                  const Divider(),
              ],
            );
          }),
        ],
      ),
    );
  }

  Widget _buildMaterialReceivedContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: "Material Received",
            fontSize: 15.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
          TabBar(
            controller: _materialTabController,
            tabs: List<Widget>.generate(
              course.studentCourse.course.totalSemesters,
              (index) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 5.w),
                child: Tab(text: "Semester ${index + 1}"),
              ),
            ),
            indicatorColor: Colors.orange,
            indicatorWeight: 5,
            labelColor: AppColor.primaryColor,
            unselectedLabelColor: Colors.grey,
          ),
          SizedBox(
            height: 200.w,
            child: TabBarView(
              controller: _materialTabController,
              children: List<Widget>.generate(
                course.studentCourse.course.totalSemesters,
                (semesterIndex) {
                  // Get materials for THIS semester
                  int semesterNum = semesterIndex + 1;
                  var semesterMaterials = groupedBySemester[semesterNum] ?? [];

                  if (semesterMaterials.isEmpty) {
                    return Center(
                      child: CustomText(
                        text: "No materials for Semester $semesterNum",
                        fontSize: 14.sp,
                        color: AppColor.black3Color,
                      ),
                    );
                  }

                  return ListView(
                    physics: const ClampingScrollPhysics(),
                    padding: EdgeInsets.symmetric(horizontal: 5.w),
                    children: semesterMaterials.asMap().entries.map((entry) {
                      int materialItemIndex = entry.key;
                      var material = entry.value;
                      return Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 5.w),
                            child: Row(
                              children: [
                                Expanded(
                                  child: CustomText(
                                    text:
                                        "${materialItemIndex + 1}. ${material.materialName}",
                                    fontSize: 14.sp,
                                    color: AppColor.black3Color,
                                    fontWeight: FontWeight.w500,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                CustomText(
                                  text: (material.issuedDate.isEmpty)
                                      ? "Not issued"
                                      : outputFormat.format(inputFormat
                                          .parse(material.issuedDate)),
                                  fontSize: 12.sp,
                                  color: AppColor.secondaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                              ],
                            ),
                          ),
                          if (materialItemIndex != semesterMaterials.length - 1)
                            const Divider(),
                        ],
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMarkSheetContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: "MarkSheet & Certificate",
            fontSize: 15.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
          SizedBox(height: 20.w),
          ...course.studentCourse.marksheet.asMap().entries.map((entry) {
            int testMarkIndex = entry.key;
            var material = entry.value;
            return Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: material.course.toString(),
                            fontSize: 14.sp,
                            color: AppColor.primaryColor,
                            fontWeight: FontWeight.w500,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 3.w),
                          CustomText(
                            text: "#${material.printType}",
                            fontSize: 12.sp,
                            color: AppColor.black3Color,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        CustomText(
                          text: outputFormat
                              .format(inputFormat.parse(material.date)),
                          fontSize: 12.sp,
                          color: AppColor.secondaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                        SizedBox(height: 3.w),
                        CustomText(
                          text: material.status,
                          fontSize: 12.sp,
                          color: AppColor.black3Color,
                          fontWeight: FontWeight.w500,
                        ),
                      ],
                    ),
                  ],
                ),
                if (testMarkIndex != course.studentCourse.marksheet.length - 1)
                  const Divider(),
              ],
            );
          }),
        ],
      ),
    );
  }

  Widget _buildCertificateReceivedContainer(pdm.CourseElement? course) {
    if (course == null) {
      return const SizedBox.shrink();
    }

    final certfDetail = course.studentCourse.certificate;
    final markSheetDetail = course.studentCourse.marksheet;
    bool isCertfIssued =
        (certfDetail.certificateAndMarksheetId != AppStrings.defaultGUID) &&
            (certfDetail.examIndentTransId != AppStrings.defaultGUID);

    return GreyContainerWidget(
      color: AppColor.containerWhiteColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: "Certificate / Mark Sheet Received",
            fontSize: 15.sp,
            color: AppColor.black3Color,
            fontWeight: FontWeight.w500,
          ),
          TabBar(
            controller: _certificateTabController,
            tabs: List<Widget>.generate(
              course.studentCourse.course.totalSemesters,
              (index) => Padding(
                padding: EdgeInsets.symmetric(horizontal: 5.w),
                child: Tab(text: "Semester ${index + 1}"),
              ),
            ),
            indicatorColor: Colors.orange,
            indicatorWeight: 5,
            labelColor: AppColor.primaryColor,
            unselectedLabelColor: Colors.grey,
          ),
          SizedBox(
            height: 80.w,
            child: TabBarView(
              controller: _certificateTabController,
              children: List<Widget>.generate(
                course.studentCourse.course.totalSemesters,
                (semIndex) => Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 50,
                          child: CustomText(
                            text: "1.Certificate",
                            fontWeight: FontWeight.w500,
                            color: AppColor.blackColor,
                            fontSize: 14.sp,
                          ),
                        ),
                        Expanded(
                          flex: 50,
                          child: CustomText(
                            text: isCertfIssued ? "Issued" : "Not Issued",
                            fontWeight: FontWeight.w500,
                            color: AppColor.secondaryColor,
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          flex: 50,
                          child: CustomText(
                            text: "2.Mark Sheet",
                            fontWeight: FontWeight.w500,
                            color: AppColor.blackColor,
                            fontSize: 14.sp,
                          ),
                        ),
                        Expanded(
                          flex: 50,
                          child: Builder(builder: (context) {
                            bool isSemAvailable = false;
                            pdm.Certificate? currentMSData;
                            try {
                              currentMSData =
                                  markSheetDetail.firstWhere((element) {
                                isSemAvailable = element.semester ==
                                    _certificateTabController.index + 1;
                                return isSemAvailable;
                              });
                            } catch (e) {
                              isSemAvailable = false;
                              currentMSData = null;
                            }
                            return CustomText(
                              text: (isSemAvailable && currentMSData != null)
                                  ? currentMSData.status
                                  : "Not Issued",
                              fontWeight: FontWeight.w500,
                              color: AppColor.secondaryColor,
                              fontSize: 14.sp,
                            );
                          }),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
