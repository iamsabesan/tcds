import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/screens/dashboard/profile_list_tile.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import '../../../../constants/app_string.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../../constants/shared_pref.dart';
import '../../../controllers/dashboard_controller.dart';
import '../../../controllers/my_profile_controller.dart';
import '../../../controllers/register_controller.dart';
import '../../../models/profile/personal_detail_model.dart';
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/grey_container_widget.dart';
import '../../widgets/tab_container_widget.dart';
import '../../../models/profile/personal_detail_model.dart' as pdm;

class MyProfile extends StatefulWidget {
  const MyProfile({super.key});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> with TickerProviderStateMixin {
  // find register controller
  MyProfileController profileController = Get.find<MyProfileController>();
  RegisterController registerController = Get.find<RegisterController>();
  DashboardController dashBoardController = Get.find<DashboardController>();
  String approvalDate = "";
  int totalTheoryMarks = 0;
  int totalPracticalMarks = 0;
  int totalTotalMarks = 0;
  File? selectedImage;
  late TabController _tabController;
  late TabController _examTabController;
  late TabController _materialTabController;
  late TabController _certificateTabController;
  Map<int, List<pdm.Material>> groupedBySemester = {};
  Map<int, Map<String, int>> semesterTotalMarks = {};

  NumberFormat currencyFormat =
      NumberFormat.currency(decimalDigits: 2, symbol: "₹", locale: "hi_IN");

  @override
  void initState() {
    neccessaryAPICalls();

    super.initState();
  }

  // call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    profileController.centresScrLoader.value = true;
    await profileController.personalDetail(
        studentId: SharedPref.getString(AppStrings
            .contactID)); //"83F1A50A-BA85-45E2-9696-061FBB10F7C5"  SharedPref.getString(AppStrings.studentEnquiryID)
    await registerController.fetchCentreDetails();
    // await profileController.courseDetail(
    //     batchMappingID:
    //         profileController.stdntPersonalDetail[0].courses[0].batchMappingId);
    //below has to removed based on result
    // for (var material in profileController.stdntCourseDetail[0].materials) {
    //   int semester = material.semester;
    //   if (!groupedBySemester.containsKey(semester)) {
    //     groupedBySemester[semester] = [];
    //     semesterTotalMarks[semester] = {
    //       "TotalMarks": 0,
    //       "TheoryMarks": 0,
    //       "PracticalMarks": 0
    //     };
    //   }
    //   groupedBySemester[semester]?.add(material);
    // }
    // //
    // // // Display the result
    // // debugPrint(groupedBySemester.toString());
    // semesterTotalMarks.forEach((semester, sums) {
    //   debugPrint('Semester $semester:');
    //   debugPrint('  TotalMarks: ${sums["TotalMarks"]}');
    //   debugPrint('  TheoryMarks: ${sums["TheoryMarks"]}');
    //   debugPrint('  PracticalMarks: ${sums["PracticalMarks"]}');
    // });

    _tabController = TabController(
        length: profileController.stdntPersonalDetail.isNotEmpty
            ? profileController.stdntPersonalDetail[0].courses.length
            : 0,
        vsync: this);
    _examTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);
    _materialTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);
    _certificateTabController = TabController(
        length: (profileController.stdntPersonalDetail.isNotEmpty &&
                profileController.stdntPersonalDetail[0].courses.isNotEmpty)
            ? profileController.stdntPersonalDetail[0].courses[0].studentCourse
                .course.totalSemesters
            : 0,
        vsync: this);

    profileController.centresScrLoader.value = false;

    _tabController.addListener(() async {
      if (_tabController.indexIsChanging) {
        debugPrint(_tabController.index.toString());
        // showPage = false;
        // setState(() {});
        // await profileController.courseDetail(
        //     batchMappingID: profileController.stdntPersonalDetail[0]
        //         .courses[_tabController.index].batchMappingId);
        // showPage = true;
        setState(() {
          _selectedIndex = _tabController.index; // Update selected index
        });
      }
    });
    showPage = true;

    setState(() {});
  }

  // textediting controller
  TextEditingController stateTxtCtrl = TextEditingController();
  TextEditingController stateIDCtrl = TextEditingController();
  TextEditingController districtTxtCtrl = TextEditingController();
  TextEditingController districtIDCtrl = TextEditingController();
  TextEditingController talukTxtCtrl = TextEditingController();
  TextEditingController talukIDCtrl = TextEditingController();

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> registeredFormKey = GlobalKey<FormState>();
  int selectedDayIndex = 0;
  DateFormat inputFormat = DateFormat("dd-MM-yyyy");

  // Define the desired output format
  DateFormat outputFormat = DateFormat("dd/MM/yyyy");
  bool showPage = false;
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backgroundBlue,
      appBar: PreferredSize(
          preferredSize: Size(double.infinity, 140.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.only(bottom: 15.w, top: 50.w),
                decoration: const BoxDecoration(
                  color: AppColor.whiteColor,
                  boxShadow: [
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(color: AppColor.whiteColor),
                    BoxShadow(
                        color: AppColor.grey,
                        offset: Offset(0, 6),
                        spreadRadius: 0.5,
                        blurRadius: 4),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 20.w,
                    ),
                    InkWell(
                      splashColor: AppColor.black2Color,
                      onTap: () {
                        Get.back();
                      },
                      child: Icon(
                        Icons.arrow_back_ios_new_outlined,
                        size: 30.w,
                      ),
                    ),
                    SizedBox(
                      width: 15.w,
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: "My Profile",
                            fontSize: 16.sp,
                            color: AppColor.blackColor,
                            maxLines: 1,
                            fontWeight: FontWeight.w500,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )),
      body: Obx(
        () => profileController.centresScrLoader.value
            ? const CustomProgressIndicator()
            : StatefulBuilder(builder: (context, confirmDetailsState) {
                return Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: ListView(
                    children: [
                      SizedBox(
                        height: 20.w,
                      ),
                      // profile picture
                      Center(
                        child: ClipOval(
                          // show base64 image only when it's not empty
                          // else show default image
                          child: dashBoardController.personalInfoDetail.isEmpty
                              ? Image.asset(
                                  AssetPath.defaultProfile,
                                  height: 70.w,
                                  width: 70.w,
                                  fit: BoxFit.cover,
                                )
                              : dashBoardController.personalInfoDetail[0]
                                      .studentImages.isEmpty
                                  ? Image.asset(
                                      AssetPath.defaultProfile,
                                      height: 100.w,
                                      width: 100.w,
                                      fit: BoxFit.cover,
                                    )
                                  : dashBoardController.personalInfoDetail[0]
                                              .studentImages[0].profileBase64 !=
                                          null
                                      ? Image.memory(
                                          base64Decode(dashBoardController
                                              .personalInfoDetail[0]
                                              .studentImages[0]
                                              .profileBase64!),
                                          height: 90.w,
                                          width: 90.w,
                                          fit: BoxFit.cover,
                                          errorBuilder:
                                              (context, error, stackTrace) =>
                                                  Image.asset(
                                            AssetPath.defaultProfile,
                                            height: 50.w,
                                            width: 50.w,
                                            fit: BoxFit.cover,
                                          ),
                                        )
                                      : Image.asset(
                                          AssetPath.defaultProfile,
                                          height: 50.w,
                                          width: 50.w,
                                          fit: BoxFit.cover,
                                        ),
                        ),
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      // profile picture
                      Center(
                        child: CustomText(
                          text: profileController
                              .stdntPersonalDetail[0].studentName,
                          fontSize: 17.sp,
                          color: AppColor.primaryColor,
                          fontWeight: FontWeight.w500,
                          maxLines: 2,
                        ),
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      // profile picture
                      Center(
                        child: CustomText(
                          text: profileController
                              .stdntPersonalDetail[0].rollNumber,
                          fontSize: 16.sp,
                          color: AppColor.blackColor,
                          fontWeight: FontWeight.w500,
                          maxLines: 2,
                        ),
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      GreyContainerWidget(
                        color: AppColor.containerWhiteColor,
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  flex: 50,
                                  child: ProfileListTile(
                                    assetName: AssetPath.gender,
                                    title: 'Gender',
                                    subTitle: profileController
                                        .stdntPersonalDetail[0].gender,
                                  ),
                                ),
                                Expanded(
                                  flex: 50,
                                  child: ProfileListTile(
                                    assetName: AssetPath.calender,
                                    title: 'Date of Birth',
                                    subTitle: DateFormat('dd-MM-yyyy').format(
                                        profileController.stdntPersonalDetail[0]
                                            .dateOfBirth),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 5.w,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 50,
                                  child: ProfileListTile(
                                      assetName: AssetPath.stdMobile,
                                      title: 'Mobile',
                                      subTitle:
                                          "${profileController.stdntPersonalDetail[0].phoneCode} ${profileController.stdntPersonalDetail[0].phone}" //'+91 ${mobileCtrl.text}',

                                      ),
                                ),
                                if (profileController.stdntPersonalDetail[0]
                                    .alternatePhone.isNotEmpty)
                                  Expanded(
                                    flex: 50,
                                    child: ProfileListTile(
                                        assetName: AssetPath.stdMobile,
                                        title: 'Alternate Mobile',
                                        subTitle:
                                            "${profileController.stdntPersonalDetail[0].alternatePhoneCode} ${profileController.stdntPersonalDetail[0].alternatePhone}" //'+91 ${mobileCtrl.text}',        //'+91 ${altMobCtrl.text}',

                                        ),
                                  ),
                              ],
                            ),
                            SizedBox(
                              height: 5.w,
                            ),
                            /*   ProfileListTile(
                                assetName: AssetPath.mail,
                                title: 'Email ID',
                                subTitle: profileController
                                    .stdntPersonalDetail[0]
                                    .email //emailCtrl.text,
                                ),
                            SizedBox(
                              height: 5.w,
                            ), */
                            ProfileListTile(
                                assetName: AssetPath.qualification,
                                title: 'Qualification',
                                subTitle: profileController
                                    .stdntPersonalDetail[0]
                                    .qualification //qualificationCtrl.text,
                                ),
                            SizedBox(
                              height: 5.w,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  flex: 50,
                                  child: ProfileListTile(
                                      assetName: AssetPath.person,
                                      title: 'Father Name',
                                      subTitle: profileController
                                          .stdntPersonalDetail[0]
                                          .fatherName // parentNameCtrl.text,

                                      ),
                                ),
                                Expanded(
                                  flex: 50,
                                  child: ProfileListTile(
                                      assetName: AssetPath.occupation,
                                      title: 'Occupation',
                                      subTitle: profileController
                                          .stdntPersonalDetail[0].occupation),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 30.w,
                      ),

                      if (profileController
                          .stdntPersonalDetail[0].courses.isNotEmpty)
                        TabContainerWidget(
                          color: AppColor.containerBlue,
                          child: Column(
                            children: [
                              TabBar(
                                controller: _tabController,
                                tabs: List<Widget>.generate(
                                  profileController
                                      .stdntPersonalDetail[0].courses.length,
                                  (index) {
                                    bool isSelected = _selectedIndex == index;
                                    return AnimatedContainer(
                                      duration: const Duration(
                                          milliseconds:
                                              300), // Smooth transition
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(10.r),
                                        color: isSelected
                                            ? AppColor
                                                .whiteColor // Highlight selected with your primary color
                                            : AppColor
                                                .containerBlue, // Default color for unselected tabs
                                      ),
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10.w),
                                        child: Tab(
                                          text: profileController
                                              .stdntPersonalDetail[0]
                                              .courses[index]
                                              .fullName,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                indicatorColor: Colors
                                    .transparent, // This hides the default tab indicator
                                labelColor: AppColor
                                    .primaryColor, // Change text color when tab is selected
                                unselectedLabelColor: Colors
                                    .grey, // Change text color when tab is unselected
                                dividerColor: Colors.transparent,
                              )
                            ],
                          ),
                        ),
                      SizedBox(
                        height: 20.w,
                      ),
                      Column(
                        children: [
                          SizedBox(
                            height: 500.w,
                            // Adjust the height for TabBarView
                            child: TabBarView(
                              controller: _tabController,
                              children: List<Widget>.generate(
                                profileController
                                    .stdntPersonalDetail[0].courses.length,
                                (courseIndex) {
                                  groupedBySemester.clear();
                                  semesterTotalMarks.clear();
                                  for (var material in profileController
                                      .stdntPersonalDetail[0]
                                      .courses[0]
                                      .studentCourse
                                      .materials) {
                                    int semester = material.semester;
                                    if (!groupedBySemester
                                        .containsKey(semester)) {
                                      groupedBySemester[semester] = [];
                                      semesterTotalMarks[semester] = {
                                        "TotalMarks": 0,
                                        "TheoryMarks": 0,
                                        "PracticalMarks": 0
                                      };
                                    }
                                    groupedBySemester[semester]?.add(material);
                                  }

                                  /* semesterTotalMarks.forEach((semester, sums) {
                                    debugPrint('Semester $semester:');
                                    debugPrint(
                                        '  TotalMarks: ${sums["TotalMarks"]}');
                                    debugPrint(
                                        '  TheoryMarks: ${sums["TheoryMarks"]}');
                                    debugPrint(
                                        '  PracticalMarks: ${sums["PracticalMarks"]}');
                                  }); */
                                  return SingleChildScrollView(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        GreyContainerWidget(
                                          color: AppColor.containerWhiteColor,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.symmetric(
                                                    horizontal: 5.w),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    ClipOval(
                                                      child: Image.asset(
                                                        AssetPath.batchImg,
                                                        height: 35.w,
                                                        width: 35.w,
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 15.w,
                                                    ),
                                                    Expanded(
                                                      child: Column(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          CustomText(
                                                            text:
                                                                "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.course.courseType} Course",
                                                            fontSize: 14.sp,
                                                            color: AppColor
                                                                .primaryColor,
                                                            maxLines: 1,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                          SizedBox(
                                                            height: 10.w,
                                                          ),
                                                          CustomText(
                                                            text: currencyFormat.format(
                                                                profileController
                                                                    .stdntPersonalDetail[
                                                                        0]
                                                                    .courses[
                                                                        courseIndex]
                                                                    .studentCourse
                                                                    .course
                                                                    .courseFees),
                                                            fontSize: 13.sp,
                                                            color: AppColor
                                                                .black3Color,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .end,
                                                      children: [
                                                        CustomText(
                                                          text: profileController
                                                              .stdntPersonalDetail[
                                                                  0]
                                                              .courses[
                                                                  courseIndex]
                                                              .studentCourse
                                                              .course
                                                              .status,
                                                          color: AppColor
                                                              .secondaryColor,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                        SizedBox(
                                                          height: 10.w,
                                                        ),
                                                        CustomText(
                                                          text:
                                                              "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.batchType}/${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.batchTrack}",
                                                          fontSize: 12.sp,
                                                          color: AppColor
                                                              .black3Color,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const Divider(),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  CustomText(
                                                    text:
                                                        "${outputFormat.format(inputFormat.parse(profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.startDate))} - ${outputFormat.format(inputFormat.parse(profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.endDate))}",
                                                    fontSize: 12.sp,
                                                    color:
                                                        AppColor.primaryColor,
                                                    maxLines: 1,
                                                    fontWeight: FontWeight.w500,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                  CustomText(
                                                    text:
                                                        "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.startTime} to ${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.batch.endTime}",
                                                    fontSize: 12.sp,
                                                    color:
                                                        AppColor.secondaryColor,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              Wrap(
                                                children: [
                                                  BulletText(
                                                      text: profileController
                                                          .stdntPersonalDetail[
                                                              0]
                                                          .courses[courseIndex]
                                                          .studentCourse
                                                          .course
                                                          .shortName),
                                                  BulletText(
                                                      text: profileController
                                                          .stdntPersonalDetail[
                                                              0]
                                                          .courses[courseIndex]
                                                          .studentCourse
                                                          .course
                                                          .duration),
                                                  BulletText(
                                                      text:
                                                          "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.course.totalSemesters} Semester(s)"),
                                                  BulletText(
                                                      text: profileController
                                                          .stdntPersonalDetail[
                                                              0]
                                                          .courses[courseIndex]
                                                          .studentCourse
                                                          .course
                                                          .eligibility),
                                                ],
                                              ),
                                              const SizedBox(
                                                height: 5,
                                              ),
                                              /*  CustomText(
                                                            text:
                                                                "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.course.duration} ● ${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.course.totalSemesters} Semester(s)",
                                                            fontSize: 12.sp,
                                                            color: AppColor
                                                                .black3Color,
                                                            maxLines: 2,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ), */

                                              CustomText(
                                                text: profileController
                                                    .stdntPersonalDetail[0]
                                                    .courses[courseIndex]
                                                    .studentCourse
                                                    .batch
                                                    .facultyName,
                                                fontSize: 12.sp,
                                                color: AppColor.black3Color,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 20.w,
                                        ),
                                        GreyContainerWidget(
                                          color: AppColor.containerWhiteColor,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                text: "Exam Mark",
                                                fontSize: 15.sp,
                                                color: AppColor.black3Color,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              TabBar(
                                                controller: _examTabController,
                                                tabs: List<Widget>.generate(
                                                  profileController
                                                      .stdntPersonalDetail[0]
                                                      .courses[courseIndex]
                                                      .studentCourse
                                                      .course
                                                      .totalSemesters,
                                                  (index) {
                                                    return Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 5.w),
                                                      child: Tab(
                                                        text:
                                                            "Semester ${index + 1}",
                                                        // Assuming 'name' is a field in your course object
                                                      ),
                                                    );
                                                  },
                                                ),
                                                indicatorColor: Colors.orange,
                                                indicatorWeight: 5,
                                                labelColor:
                                                    AppColor.primaryColor,
                                                unselectedLabelColor:
                                                    Colors.grey,
                                              ),
                                              SizedBox(
                                                height: 225.w,
                                                child: TabBarView(
                                                    controller:
                                                        _examTabController,
                                                    children: List<
                                                            Widget>.generate(
                                                        profileController
                                                            .stdntPersonalDetail[
                                                                0]
                                                            .courses[
                                                                courseIndex]
                                                            .studentCourse
                                                            .course
                                                            .totalSemesters,
                                                        (examIndex) {
                                                      return ListView(
                                                        // physics:
                                                        //     const NeverScrollableScrollPhysics(),
                                                        children: List.generate(
                                                            groupedBySemester
                                                                .length,
                                                            (index) {
                                                          var group =
                                                              groupedBySemester
                                                                  .values
                                                                  .elementAt(
                                                                      selectedDayIndex);

                                                          // Sum up the marks for each group
                                                          totalTheoryMarks = 0;
                                                          totalPracticalMarks =
                                                              0;
                                                          totalTotalMarks = 0;

                                                          for (var material
                                                              in group) {
                                                            totalTheoryMarks +=
                                                                material
                                                                    .theoryMarks;
                                                            totalPracticalMarks +=
                                                                material
                                                                    .practicalMarks;
                                                            totalTotalMarks +=
                                                                material
                                                                    .totalMarks;
                                                          }

                                                          return Padding(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        5.w),
                                                            child: Column(
                                                              children: [
                                                                ...group.map(
                                                                    (material) {
                                                                  return Column(
                                                                    children: [
                                                                      Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.start,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          Expanded(
                                                                            child:
                                                                                Column(
                                                                              mainAxisAlignment: MainAxisAlignment.center,
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              children: [
                                                                                CustomText(
                                                                                  text: material.materialName,
                                                                                  fontSize: 14.sp,
                                                                                  color: AppColor.primaryColor,
                                                                                  maxLines: 1,
                                                                                  fontWeight: FontWeight.w500,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding:
                                                                                EdgeInsets.only(right: 20.w),
                                                                            child:
                                                                                Align(
                                                                              alignment: Alignment.topRight,
                                                                              child: Column(
                                                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                                                children: [
                                                                                  CustomText(
                                                                                    text: "${material.totalMarks} marks",
                                                                                    fontSize: 12.sp,
                                                                                    color: AppColor.secondaryColor,
                                                                                    fontWeight: FontWeight.w500,
                                                                                  ),
                                                                                  SizedBox(
                                                                                    height: 10.w,
                                                                                  ),
                                                                                  CustomText(
                                                                                    text: "${material.theoryMarks} (T) ● ${material.practicalMarks} (P)",
                                                                                    fontSize: 12.sp,
                                                                                    color: AppColor.black3Color,
                                                                                    fontWeight: FontWeight.w500,
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                      const Divider(),
                                                                    ],
                                                                  );
                                                                }),
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          CustomText(
                                                                            text:
                                                                                "Total marks:",
                                                                            fontSize:
                                                                                14.sp,
                                                                            color:
                                                                                AppColor.primaryColor,
                                                                            maxLines:
                                                                                1,
                                                                            fontWeight:
                                                                                FontWeight.w500,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsets.only(
                                                                          right:
                                                                              20.w),
                                                                      child:
                                                                          Align(
                                                                        alignment:
                                                                            Alignment.topRight,
                                                                        child:
                                                                            Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          children: [
                                                                            CustomText(
                                                                              text: "$totalTotalMarks marks",
                                                                              fontSize: 12.sp,
                                                                              color: AppColor.secondaryColor,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                            CustomText(
                                                                              text: "$totalTheoryMarks Theory ● $totalPracticalMarks Practical",
                                                                              fontSize: 12.sp,
                                                                              color: AppColor.black3Color,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                        }),
                                                      );
                                                    })),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 15.w,
                                        ),
                                        GreyContainerWidget(
                                          color: AppColor.containerWhiteColor,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                text: "Fees Details",
                                                fontSize: 15.sp,
                                                color: AppColor.black3Color,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              SizedBox(
                                                height: 20.w,
                                              ),
                                              GreyContainerWidget(
                                                color: AppColor.lightPurple,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Flexible(
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border(
                                                            right: BorderSide(
                                                              color: AppColor
                                                                  .containerWhiteColor
                                                              // Set underline color to orange
                                                              ,
                                                              // Bottom border color
                                                              width: 3.w
                                                              // Set thickness of the underline when selected
                                                              , // Bottom border thickness
                                                            ),
                                                          ),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  right: 10.w),
                                                          child: Align(
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                CustomText(
                                                                  text:
                                                                      "Course Fees",
                                                                  fontSize:
                                                                      12.sp,
                                                                  color: AppColor
                                                                      .titleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                                CustomText(
                                                                  text: profileController
                                                                      .stdntPersonalDetail[
                                                                          0]
                                                                      .courses[
                                                                          courseIndex]
                                                                      .studentCourse
                                                                      .course
                                                                      .courseFees
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  fontSize:
                                                                      14.sp,
                                                                  color: AppColor
                                                                      .subTitleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border(
                                                            right: BorderSide(
                                                              color: AppColor
                                                                  .containerWhiteColor
                                                              // Set underline color to orange
                                                              ,
                                                              // Bottom border color
                                                              width: 3.w
                                                              // Set thickness of the underline when selected
                                                              , // Bottom border thickness
                                                            ),
                                                          ),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  right: 10.w),
                                                          child: Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                CustomText(
                                                                  text:
                                                                      "Discount",
                                                                  fontSize:
                                                                      12.sp,
                                                                  color: AppColor
                                                                      .titleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                                CustomText(
                                                                  text: profileController
                                                                      .stdntPersonalDetail[
                                                                          0]
                                                                      .courses[
                                                                          courseIndex]
                                                                      .studentCourse
                                                                      .course
                                                                      .discountAmount
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  fontSize:
                                                                      14.sp,
                                                                  color: AppColor
                                                                      .subTitleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                right: 10.w),
                                                        child: Align(
                                                          alignment: Alignment
                                                              .centerRight,
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            children: [
                                                              CustomText(
                                                                text:
                                                                    "Discount (%)",
                                                                fontSize: 12.sp,
                                                                color: AppColor
                                                                    .titleColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                              CustomText(
                                                                text:
                                                                    "${profileController.stdntPersonalDetail[0].courses[courseIndex].studentCourse.course.discount.toStringAsFixed(0)}%",
                                                                fontSize: 14.sp,
                                                                color: AppColor
                                                                    .subTitleColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 10,
                                              ),
                                              GreyContainerWidget(
                                                color: AppColor.containerBlue,
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Flexible(
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border(
                                                            right: BorderSide(
                                                              color: AppColor
                                                                  .containerWhiteColor,
                                                              width: 3.w,
                                                            ),
                                                          ),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  right: 10.w),
                                                          child: Align(
                                                            alignment: Alignment
                                                                .centerLeft,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                CustomText(
                                                                  text:
                                                                      "Net Fees",
                                                                  fontSize:
                                                                      12.sp,
                                                                  color: AppColor
                                                                      .blackColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                                CustomText(
                                                                  text: profileController
                                                                      .stdntPersonalDetail[
                                                                          0]
                                                                      .courses[
                                                                          courseIndex]
                                                                      .studentCourse
                                                                      .course
                                                                      .totalFees
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  fontSize:
                                                                      14.sp,
                                                                  color: AppColor
                                                                      .subTitleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Container(
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border(
                                                            right: BorderSide(
                                                              color: AppColor
                                                                  .containerWhiteColor
                                                              // Set underline color to orange
                                                              ,
                                                              // Bottom border color
                                                              width: 3.w
                                                              // Set thickness of the underline when selected
                                                              , // Bottom border thickness
                                                            ),
                                                          ),
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              EdgeInsets.only(
                                                                  right: 10.w),
                                                          child: Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: [
                                                                CustomText(
                                                                  text:
                                                                      "Fees Paid",
                                                                  fontSize:
                                                                      12.sp,
                                                                  color: AppColor
                                                                      .titleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                                CustomText(
                                                                  text: profileController
                                                                      .stdntPersonalDetail[
                                                                          0]
                                                                      .courses[
                                                                          courseIndex]
                                                                      .studentCourse
                                                                      .course
                                                                      .paidFees
                                                                      .toStringAsFixed(
                                                                          2),
                                                                  fontSize:
                                                                      14.sp,
                                                                  color: AppColor
                                                                      .subTitleColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                right: 10.w),
                                                        child: Align(
                                                          alignment: Alignment
                                                              .centerRight,
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                            children: [
                                                              CustomText(
                                                                text:
                                                                    "Fees Balance",
                                                                fontSize: 12.sp,
                                                                color: AppColor
                                                                    .titleColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                              CustomText(
                                                                text: profileController
                                                                    .stdntPersonalDetail[
                                                                        0]
                                                                    .courses[
                                                                        courseIndex]
                                                                    .studentCourse
                                                                    .course
                                                                    .balance
                                                                    .toStringAsFixed(
                                                                        2),
                                                                fontSize: 14.sp,
                                                                color: AppColor
                                                                    .subTitleColor,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(
                                                height: 20.w,
                                              ),
                                              Builder(builder: (context) {
                                                var group = profileController
                                                    .stdntPersonalDetail[0]
                                                    .courses[courseIndex]
                                                    .studentCourse
                                                    .payments;

                                                // Sum up the marks for each group
                                                totalTheoryMarks = 0;
                                                totalPracticalMarks = 0;
                                                totalTotalMarks = 0;
                                                return Padding(
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 5.w),
                                                    child: Column(
                                                      children: [
                                                        ...group.asMap().map(
                                                            (index, material) {
                                                          return MapEntry(
                                                            index,
                                                            Column(
                                                              children: [
                                                                Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Column(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        crossAxisAlignment:
                                                                            CrossAxisAlignment.start,
                                                                        children: [
                                                                          CustomText(
                                                                            text:
                                                                                outputFormat.format(inputFormat.parse(material.receiptDate)),
                                                                            fontSize:
                                                                                12.sp,
                                                                            color:
                                                                                AppColor.secondaryColor,
                                                                            fontWeight:
                                                                                FontWeight.w500,
                                                                          ),
                                                                          SizedBox(
                                                                            height:
                                                                                3.w,
                                                                          ),
                                                                          CustomText(
                                                                            text:
                                                                                "#${material.receiptNo}",
                                                                            fontSize:
                                                                                12.sp,
                                                                            color:
                                                                                AppColor.black3Color,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                          ),
                                                                          SizedBox(
                                                                            height:
                                                                                3.w,
                                                                          ),
                                                                          CustomText(
                                                                            text:
                                                                                material.paymode,
                                                                            fontSize:
                                                                                12.sp,
                                                                            color:
                                                                                AppColor.black3Color,
                                                                            fontWeight:
                                                                                FontWeight.w600,
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                    Padding(
                                                                      padding: EdgeInsets.only(
                                                                          right:
                                                                              20.w),
                                                                      child:
                                                                          Align(
                                                                        alignment:
                                                                            Alignment.topRight,
                                                                        child:
                                                                            Column(
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.end,
                                                                          children: [
                                                                            CustomText(
                                                                              text: currencyFormat.format(material.amount),
                                                                              fontSize: 12.sp,
                                                                              color: AppColor.secondaryColor,
                                                                              fontWeight: FontWeight.w500,
                                                                            ),
                                                                            SizedBox(
                                                                              height: 3.w,
                                                                            ),
                                                                            CustomText(
                                                                              text: material.paymentType,
                                                                              fontSize: 12.sp,
                                                                              color: AppColor.black3Color,
                                                                              fontWeight: FontWeight.w600,
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                                // Add Divider only if it's not the last item
                                                                if (index !=
                                                                    group.length -
                                                                        1)
                                                                  const Divider(),
                                                              ],
                                                            ),
                                                          );
                                                        }).values,
                                                      ],
                                                    ));
                                              }),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 20.w,
                                        ),
                                        GreyContainerWidget(
                                          color: AppColor.containerWhiteColor,
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                text: "Material Received",
                                                fontSize: 15.sp,
                                                color: AppColor.black3Color,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              TabBar(
                                                controller:
                                                    _materialTabController,
                                                tabs: List<Widget>.generate(
                                                  profileController
                                                      .stdntPersonalDetail[0]
                                                      .courses[courseIndex]
                                                      .studentCourse
                                                      .course
                                                      .totalSemesters,
                                                  (index) {
                                                    return Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 5.w),
                                                      child: Tab(
                                                        text:
                                                            "Semester ${index + 1}",
                                                        // Assuming 'name' is a field in your course object
                                                      ),
                                                    );
                                                  },
                                                ),
                                                indicatorColor: Colors.orange,
                                                indicatorWeight: 5,
                                                labelColor:
                                                    AppColor.primaryColor,
                                                unselectedLabelColor:
                                                    Colors.grey,
                                              ),
                                              SizedBox(
                                                height: 150.w,
                                                child: TabBarView(
                                                  controller:
                                                      _materialTabController,
                                                  children:
                                                      List<Widget>.generate(
                                                    profileController
                                                        .stdntPersonalDetail[0]
                                                        .courses[courseIndex]
                                                        .studentCourse
                                                        .course
                                                        .totalSemesters,
                                                    (index) {
                                                      return ListView(
                                                        children: List.generate(
                                                            groupedBySemester
                                                                .length,
                                                            (semIndex) {
                                                          var group =
                                                              groupedBySemester
                                                                  .values
                                                                  .elementAt(
                                                                      selectedDayIndex);

                                                          /*     // Sum up the marks for each group
                                                          totalTheoryMarks = 0;
                                                          totalPracticalMarks =
                                                              0;
                                                          totalTotalMarks = 0;

                                                          for (var material
                                                              in group) {
                                                            totalTheoryMarks +=
                                                                material
                                                                    .theoryMarks;
                                                            totalPracticalMarks +=
                                                                material
                                                                    .practicalMarks;
                                                            totalTotalMarks +=
                                                                material
                                                                    .totalMarks;
                                                          } */

                                                          return Padding(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                    horizontal:
                                                                        5.w),
                                                            child: Column(
                                                              children:
                                                                  List.generate(
                                                                group.length,
                                                                (materialItemIndex) {
                                                                  final material =
                                                                      group[
                                                                          materialItemIndex];
                                                                  return Column(
                                                                    children: [
                                                                      Padding(
                                                                        padding:
                                                                            EdgeInsets.symmetric(vertical: 5.w),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.start,
                                                                          crossAxisAlignment:
                                                                              CrossAxisAlignment.start,
                                                                          children: [
                                                                            Expanded(
                                                                              child: Column(
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                                children: [
                                                                                  CustomText(
                                                                                    text: "${materialItemIndex + 1}.${material.materialName}",
                                                                                    fontSize: 14.sp,
                                                                                    color: AppColor.black3Color,
                                                                                    maxLines: 1,
                                                                                    fontWeight: FontWeight.w500,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: EdgeInsets.only(right: 20.w),
                                                                              child: Align(
                                                                                alignment: Alignment.topRight,
                                                                                child: Column(
                                                                                  crossAxisAlignment: CrossAxisAlignment.end,
                                                                                  children: [
                                                                                    CustomText(
                                                                                      text: material.issuedDate == "" ? "Not issued" : outputFormat.format(inputFormat.parse(material.issuedDate)),
                                                                                      fontSize: 12.sp,
                                                                                      color: AppColor.secondaryColor,
                                                                                      fontWeight: FontWeight.w500,
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                      const Divider(),
                                                                    ],
                                                                  );
                                                                },
                                                              ),
                                                            ),
                                                          );
                                                        }),
                                                      );
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        if (profileController
                                            .stdntPersonalDetail[0]
                                            .courses[courseIndex]
                                            .studentCourse
                                            .marksheet
                                            .isNotEmpty)
                                          SizedBox(
                                            height: 15.w,
                                          ),
                                        if (profileController
                                            .stdntPersonalDetail[0]
                                            .courses[courseIndex]
                                            .studentCourse
                                            .marksheet
                                            .isNotEmpty)
                                          GreyContainerWidget(
                                            color: AppColor.containerWhiteColor,
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomText(
                                                  text:
                                                      "MarkSheet & Certificate",
                                                  fontSize: 15.sp,
                                                  color: AppColor.black3Color,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                SizedBox(
                                                  height: 20.w,
                                                ),
                                                Column(
                                                  children: List.generate(
                                                      profileController
                                                          .stdntPersonalDetail[
                                                              0]
                                                          .courses[courseIndex]
                                                          .studentCourse
                                                          .marksheet
                                                          .length, (markIndex) {
                                                    var group = profileController
                                                        .stdntPersonalDetail[0]
                                                        .courses[courseIndex]
                                                        .studentCourse
                                                        .marksheet;

                                                    // Sum up the marks for each group

                                                    return Padding(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    5.w),
                                                        child: Column(
                                                          children: [
                                                            ...group.asMap().map(
                                                                (testMarkIndex,
                                                                    material) {
                                                              return MapEntry(
                                                                testMarkIndex,
                                                                Column(
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      children: [
                                                                        Expanded(
                                                                          child:
                                                                              Column(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.center,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            children: [
                                                                              CustomText(
                                                                                text: material.course.toString(),
                                                                                fontSize: 14.sp,
                                                                                color: AppColor.primaryColor,
                                                                                maxLines: 1,
                                                                                fontWeight: FontWeight.w500,
                                                                                overflow: TextOverflow.ellipsis,
                                                                              ),
                                                                              SizedBox(
                                                                                height: 3.w,
                                                                              ),
                                                                              CustomText(
                                                                                text: "#${material.printType}",
                                                                                fontSize: 12.sp,
                                                                                color: AppColor.black3Color,
                                                                                fontWeight: FontWeight.w500,
                                                                              ),
                                                                              SizedBox(
                                                                                height: 3.w,
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              EdgeInsets.only(right: 20.w),
                                                                          child:
                                                                              Align(
                                                                            alignment:
                                                                                Alignment.topRight,
                                                                            child:
                                                                                Column(
                                                                              crossAxisAlignment: CrossAxisAlignment.end,
                                                                              children: [
                                                                                CustomText(
                                                                                  text: outputFormat.format(inputFormat.parse(material.date)),
                                                                                  fontSize: 12.sp,
                                                                                  color: AppColor.secondaryColor,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                                SizedBox(
                                                                                  height: 3.w,
                                                                                ),
                                                                                CustomText(
                                                                                  text: material.status,
                                                                                  fontSize: 12.sp,
                                                                                  color: AppColor.black3Color,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    // Add Divider only if it's not the last item
                                                                    if (testMarkIndex !=
                                                                        group.length -
                                                                            1)
                                                                      const Divider(),
                                                                  ],
                                                                ),
                                                              );
                                                            }).values,
                                                          ],
                                                        ));
                                                  }),
                                                ),
                                              ],
                                            ),
                                          ),
                                        SizedBox(
                                          height: 20.w,
                                        ),
                                        // Materials & certificate issued
                                        GreyContainerWidget(
                                            child: Builder(builder: (context) {
                                          // check is cerificate and marksheet(s) issued.
                                          final certfDetail = profileController
                                              .stdntPersonalDetail[0]
                                              .courses[courseIndex]
                                              .studentCourse
                                              .certificate;
                                          final markSheetDetail =
                                              profileController
                                                  .stdntPersonalDetail[0]
                                                  .courses[courseIndex]
                                                  .studentCourse
                                                  .marksheet;
                                          bool isCertfIssued = (certfDetail
                                                      .certificateAndMarksheetId !=
                                                  AppStrings.defaultGUID) &&
                                              (certfDetail.examIndentTransId !=
                                                  AppStrings.defaultGUID);

                                          return Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CustomText(
                                                text:
                                                    "Certificate / Mark Sheet Received",
                                                fontSize: 15.sp,
                                                color: AppColor.black3Color,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              TabBar(
                                                controller:
                                                    _certificateTabController,
                                                tabs: List<Widget>.generate(
                                                  profileController
                                                      .stdntPersonalDetail[0]
                                                      .courses[courseIndex]
                                                      .studentCourse
                                                      .course
                                                      .totalSemesters,
                                                  (index) {
                                                    // _certificateTabController =
                                                    //     TabController(
                                                    //         length: profileController
                                                    //             .stdntPersonalDetail[
                                                    //                 0]
                                                    //             .courses[
                                                    //                 courseIndex]
                                                    //             .studentCourse
                                                    //             .course
                                                    //             .totalSemesters,
                                                    //         vsync: this);
                                                    return Padding(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 5.w),
                                                      child: Tab(
                                                        text:
                                                            "Semester ${index + 1}",
                                                        // Assuming 'name' is a field in your course object
                                                      ),
                                                    );
                                                  },
                                                ),
                                                indicatorColor: Colors.orange,
                                                indicatorWeight: 5,
                                                labelColor:
                                                    AppColor.primaryColor,
                                                unselectedLabelColor:
                                                    Colors.grey,
                                              ),
                                              SizedBox(
                                                height: 80.w,
                                                child: TabBarView(
                                                  controller:
                                                      _certificateTabController,
                                                  children: [
                                                    Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceEvenly,
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              flex: 50,
                                                              child: CustomText(
                                                                text:
                                                                    "1.Certificate",
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: AppColor
                                                                    .blackColor,
                                                                fontSize: 14.sp,
                                                              ),
                                                            ),
                                                            Expanded(
                                                              flex: 50,
                                                              child: CustomText(
                                                                text: isCertfIssued
                                                                    ? "Issued"
                                                                    : "Not Issued",
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: AppColor
                                                                    .secondaryColor,
                                                                fontSize: 14.sp,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              flex: 50,
                                                              child: CustomText(
                                                                text:
                                                                    "2.Mark Sheet",
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                color: AppColor
                                                                    .blackColor,
                                                                fontSize: 14.sp,
                                                              ),
                                                            ),
                                                            Expanded(
                                                              flex: 50,
                                                              child: Builder(
                                                                  builder:
                                                                      (context) {
                                                                // check for is the current sem is in marksheet list
                                                                bool
                                                                    isSemAvailable =
                                                                    false;
                                                                Certificate?
                                                                    currentMSData;
                                                                // get the current sem marksheet data
                                                                try {
                                                                  currentMSData =
                                                                      markSheetDetail
                                                                          .firstWhere(
                                                                    (element) {
                                                                      isSemAvailable = element
                                                                              .semester ==
                                                                          _certificateTabController.index +
                                                                              1;
                                                                      return isSemAvailable;
                                                                    },
                                                                  );
                                                                } catch (e) {
                                                                  // if Bad State or any other unexpected error
                                                                  isSemAvailable =
                                                                      false;
                                                                  currentMSData =
                                                                      null;
                                                                }
                                                                return CustomText(
                                                                  text: (isSemAvailable &&
                                                                          currentMSData !=
                                                                              null)
                                                                      ? currentMSData
                                                                          .status
                                                                      : "Not Issued",
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  color: AppColor
                                                                      .secondaryColor,
                                                                  fontSize:
                                                                      14.sp,
                                                                );
                                                              }),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                            ],
                                          );
                                        })),
                                        SizedBox(
                                          height: 60.w,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                    ],
                  ),
                );
              }),
      ),
    );
  }
}
