

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../constants/colors.dart';
import '../../widgets/custom_text.dart';

class ProfileListTile extends StatelessWidget {
  final String assetName;
  final String title;
  final String subTitle;

  const ProfileListTile(
      {super.key,
        required this.assetName,
        required this.title,
        required this.subTitle});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Image.asset(
        assetName,
        height: 23.w,
        width: 23.w,
        fit: BoxFit.cover,
      ),
      title: CustomText(
        text: title,
        color: AppColor.titleColor,
        fontWeight: FontWeight.w400,
        overflow: TextOverflow.ellipsis,
        fontSize: 15.sp,
      ),
      subtitle: CustomText(
        text: subTitle,
        color: AppColor.subTitleColor,
        fontWeight: FontWeight.w500,
        // overflow: TextOverflow.ellipsis,
        fontSize: 15.sp,
      ),
    );
  }
}
