import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import '../../../../constants/colors.dart';
import '../../../controllers/course_controller.dart';
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/pop_scope_handler.dart';
import '../../widgets/single_dropdown.dart';
import 'course_semester_detail_page.dart';
import '../../widgets/custom_drawer.dart';

class StudentCourseListPage extends StatefulWidget {
  const StudentCourseListPage({super.key});

  @override
  State<StudentCourseListPage> createState() => _StudentCourseListPageState();
}

class _StudentCourseListPageState extends State<StudentCourseListPage> {
  // find register controller
  CourseController courseController = Get.find<CourseController>();
  TextEditingController courseTxtCtrl = TextEditingController();
  TextEditingController courseIDCtrl = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  NumberFormat currenyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);

  bool canPop = false;

  void fetchArguments() {
    try {
      canPop = Get.arguments["canPop"] ?? false;
      debugPrint("fetched arg val = $canPop");
    } catch (e) {
      debugPrint('Failed to fetch Arguments');
    }
  }

  @override
  void initState() {
    // Get passed arguments and store
    fetchArguments();
    neccessaryAPICalls();

    super.initState();
  }

  // call api's that required to show this screen
  // Future<void> neccessaryAPICalls() async {
  //   await courseController.fetchCourseTypeList();
  //   await courseController.fetchLoginCourseList(
  //       courseTypeID: courseController.courseData[0].courseTypeId.toString());
  // }

  Future<void> neccessaryAPICalls() async {
    setState(() {
      courseController.courseScrLoader.value = true;
    });
    courseController.courseData.clear();
    // Fetch the course type list
    await courseController.fetchCourseTypeList();

    // Ensure courseData is not empty before proceeding
    if (courseController.courseData.isNotEmpty) {
      // await courseController.fetchLoginCourseList(
      //   courseTypeID: courseController.courseData[0].courseTypeId.toString(),
      // );
    } else {
      // Handle the case where no course data is available
      Get.snackbar(
        "Error",
        "No course types available. Please check your network or try again later.",
        snackPosition: SnackPosition.BOTTOM,
      );
    }
    // using setstate due to Obx conflict
    setState(() {
      courseController.courseScrLoader.value = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return PopScopeHandler(
      behavior: canPop ? BackBehavior.normalPop : BackBehavior.exitOnDoubleBack,
      child: Scaffold(
        backgroundColor: AppColor.whiteColor,
        key: _scaffoldKey,
        appBar: AppBar(
          backgroundColor: AppColor.whiteColor,
          elevation: 4,
          scrolledUnderElevation: 4,
          surfaceTintColor: AppColor.whiteColor,
          shadowColor: AppColor.black2Color,
          leading: canPop
              ? IconButton(
                  icon: const Icon(Icons.arrow_back_ios_rounded),
                  onPressed: () {
                    Get.back();
                  },
                )
              : IconButton(
                  icon: const Icon(Icons.menu),
                  onPressed: () {
                    _scaffoldKey.currentState!.openDrawer();
                  },
                ),
          title: CustomText(
            text: "Courses",
            fontSize: 18.sp,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w400,
          ),
        ),
        drawer: canPop
            ? null
            : const CustomDrawer(
                currentIndex: 1,
              ),
        body: courseController.courseScrLoader.value
            ? const CustomProgressIndicator()
            : Padding(
                padding: EdgeInsets.only(right: 20.w, left: 20.w, top: 30.w),
                child: Column(
                  children: [
                    // filter dropdowns

                    // Obx(
                    //   () =>
                    SingleSelectDropDown(
                      key: UniqueKey(),
                      labelText: "Course Type",
                      valueController: courseIDCtrl,
                      valueTextController: courseTxtCtrl,
                      data: List.generate(
                        courseController.courseData.length,
                        (index) {
                          return SingleSelectDropDownModel(
                              courseController.courseData[index].courseType,
                              courseController.courseData[index].courseTypeId);
                        },
                      ),
                      parentOnChangeCall: () async {
                        await courseController.fetchLoginCourseList(
                            courseTypeID: courseIDCtrl.text);
                      },
                    ),
                    // ),

                    SizedBox(
                      height: 30.w,
                    ),

                    // centre list
                    Expanded(
                        child: Obx(
                      () => courseController.courseScrListLoader.value
                          ? const CustomProgressIndicator()
                          : courseController.loginCourseData.isEmpty
                              ? const Center(
                                  child: CustomText(
                                    text: "No Data found",
                                  ),
                                )
                              : ListView.builder(
                                  itemCount:
                                      courseController.loginCourseData.length,
                                  itemBuilder: (context, index) {
                                    return InkWell(
                                      overlayColor:
                                          const WidgetStatePropertyAll(
                                              AppColor.whiteColor),
                                      onTap: () {
                                        Get.to(() => CourseSemesterDetailPage(
                                            courseDetail: courseController
                                                .loginCourseData[index]));
                                      },
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // course details
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Expanded(
                                                child: CustomText(
                                                  text: courseController
                                                      .loginCourseData[index]
                                                      .course,
                                                  color: AppColor.primaryColor,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16.sp,
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                              CustomText(
                                                text: currenyFormat.format(
                                                    courseController
                                                        .loginCourseData[index]
                                                        .courseFees),
                                                color: AppColor.secondaryColor,
                                                fontSize: 16.sp,
                                                fontWeight: FontWeight.w500,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              SizedBox(
                                                width: 10.w,
                                              ),
                                              Icon(
                                                Icons.arrow_forward_ios_rounded,
                                                color: AppColor.black3Color,
                                                size: 20.w,
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10.w,
                                          ),
                                          Wrap(
                                            children: [
                                              BulletText(
                                                  text: courseController
                                                      .loginCourseData[index]
                                                      .shortName),
                                              BulletText(
                                                  text: courseController
                                                      .loginCourseData[index]
                                                      .duration),
                                              BulletText(
                                                  text:
                                                      "${courseController.loginCourseData[index].semester} Semester"),
                                              BulletText(
                                                  text: courseController
                                                      .loginCourseData[index]
                                                      .eligibility),
                                            ],
                                          ),
                                          /*  CustomText(
                                            text:
                                                "${courseController.loginCourseData[index].shortName} ⚫ ${courseController.loginCourseData[index].duration} ⚫ ${courseController.loginCourseData[index].semester} Semester",
                                            fontWeight: FontWeight.w400,
                                            color: AppColor.black3Color,
                                          ), */

                                          SizedBox(
                                            height: 10.w,
                                          ),

                                          // divider
                                          const Divider(
                                            color: AppColor.grey,
                                          ),
                                          SizedBox(
                                            height: 10.w,
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                    ))
                  ],
                ),
              ),
      ),
    );
  }
}
