import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/app/controllers/login_controller.dart';
import 'package:tcds_student/app/routes/routes.dart';
import 'package:tcds_student/app/ui/widgets/custom_text.dart';
import 'package:tcds_student/app/ui/widgets/in_button.dart';
import 'package:tcds_student/app/ui/widgets/pop_scope_handler.dart';
import 'package:tcds_student/constants/colors.dart';
import 'package:tcds_student/utils/helper_functions/dialogs.dart';
import 'package:tcds_student/utils/widgets/back_button.dart';

import '../../widgets/custom_textfield.dart';

class ChangePassword extends StatefulWidget {
  final String mobile;
  final String mobileCode;
  const ChangePassword({
    super.key,
    required this.mobile,
    required this.mobileCode,
  });

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  // find signin controller
  LoginController logInGetCtrl = Get.find<LoginController>();
  // textediting controllers
  TextEditingController newPwTxtCtrl = TextEditingController();
  TextEditingController confirmPwTxtCtrl = TextEditingController();

  // obscure
  bool newPwObscure = true;
  bool confirmPwObscure = true;

  // form key
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.sizeOf(context).height;

    return PopScopeHandler(
      child: Scaffold(
        backgroundColor: AppColor.whiteColor,
        resizeToAvoidBottomInset: true,
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(height: height * 0.1),
              /*  Align(
                alignment: Alignment.centerLeft,
                child: CustomBackArrowButton(
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              SizedBox(height: 30.w), */
              Align(
                alignment: Alignment.centerLeft,
                child: CustomText(
                  text: "Change Password",
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w600,
                  color: AppColor.secondaryColor,
                ),
              ),
              SizedBox(height: 30.w),
              Expanded(
                child: Form(
                  key: _formKey,
                  child: ListView(
                    children: [
                      SizedBox(height: 20.w),
                      cpTextField(
                        obscure: newPwObscure,
                        pwTxtCtrl: newPwTxtCtrl,
                        labeltext: "New Password",
                        onTap: () {
                          setState(() {
                            newPwObscure = !newPwObscure;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "New password is required";
                          }

                          bool pwdResult = RegExp(
                            r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#_\$&*~]).{8,}$',
                          ).hasMatch(value);

                          if (!pwdResult) {
                            return "Minimum 8 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character";
                          }

                          return null;
                        },
                      ),
                      SizedBox(height: 20.w),
                      cpTextField(
                        obscure: confirmPwObscure,
                        pwTxtCtrl: confirmPwTxtCtrl,
                        labeltext: "Confirm Password",
                        onTap: () {
                          setState(() {
                            confirmPwObscure = !confirmPwObscure;
                          });
                        },
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Confirm Password is Required';
                          } else if (newPwTxtCtrl.text != value) {
                            return 'Password & Confirm Password does not match';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(height: height * 0.1),
                      InButton(
                        color: AppColor.secondaryColor,
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            bool isNewPassUpdated =
                                await logInGetCtrl.changeNewPassword(
                              body: {
                                "OTPTransID": logInGetCtrl.requestedOTP.isEmpty
                                    ? ""
                                    : logInGetCtrl.requestedOTP.first.otpTransId
                                        .toString(),
                                "NewPassword": newPwTxtCtrl.text,
                                // "Email": widget.emaill,
                                "Phone": widget.mobile,
                                "PhoneCode": widget.mobileCode
                              },
                            );

                            if (isNewPassUpdated) {
                              successAlertDialog(
                                Get.context!,
                                content:
                                    "Password updated successfully.\nPlease log in to continue.",
                                onPressed: () {
                                  Get.back();
                                  Get.offAllNamed(Routes.logIn);
                                },
                              );
                            }
                          }
                        },
                        text: 'Change Password',
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // custom change password
  Widget cpTextField({
    required bool obscure,
    required TextEditingController pwTxtCtrl,
    String? labeltext,
    void Function()? onTap,
    String? Function(String?)? validator,
  }) {
    return CustomTextField(
      controller: pwTxtCtrl,
      keyboardType: TextInputType.text,
      labelText: labeltext ?? "New Password",
      obscureText: obscure,
      validator: validator,
      inputFormatters: [LengthLimitingTextInputFormatter(25)],
      suffixIcon: GestureDetector(
        onTap: onTap,
        child: obscure
            ? const Icon(Icons.remove_red_eye_outlined)
            : const Icon(Icons.remove_red_eye_rounded),
      ),
    );
  }
}
