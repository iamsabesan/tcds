import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/app/controllers/login_controller.dart';
import 'package:tcds_student/constants/colors.dart';
import 'package:tcds_student/utils/widgets/back_button.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/custom_textfield.dart';
import '../../widgets/in_button.dart';
import '../../widgets/phone_textfield.dart';
import 'otp_verify.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  // find login controller
  LoginController logInGetCtrl = Get.find<LoginController>();

  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();

  // formkey to validate fields
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.sizeOf(context).height;
    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: AppColor.whiteColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: Form(
          key: formKey,
          child: ListView(
            children: [
              SizedBox(height: height * 0.1),
              Align(
                alignment: Alignment.centerLeft,
                child: CustomBackArrowButton(
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              SizedBox(height: 30.w),
              Align(
                alignment: Alignment.centerLeft,
                child: CustomText(
                  text: "Forgot Password?",
                  fontSize: 25.sp,
                  fontWeight: FontWeight.w500,
                  color: AppColor.secondaryColor,
                ),
              ),
              SizedBox(height: 10.w),
              Align(
                alignment: Alignment.centerLeft,
                child: CustomText(
                  text:
                      "Enter your registered mobile number to receive a Verification code",
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w400,
                  color: AppColor.blackColor,
                ),
              ),
              SizedBox(height: height * 0.1),
              /* CustomTextField(
                labelText: "Email",
                autofocus: true,
                controller: emailIDCtrl,
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value != null && isEmail(value)) {
                    return null;
                  } else {
                    return "Enter an valid email";
                  }
                },
              ), */
              PhoneTextField(
                  controller: mobileCtrl,
                  mobileCodecontroller: mobileCodeCtrl,
                  labelText: "Mobile"),
              SizedBox(height: height * 0.3),
              InButton(
                onTap: () async {
                  if (formKey.currentState!.validate()) {
                    // request otp
                    bool isRequested = await logInGetCtrl.requestOTP(
                      body: {
                        "phone": mobileCtrl.text,
                        "phoneCode": mobileCodeCtrl.text
                      },
                    );
                    if (isRequested) {
                      Get.to(() => OtpScreen(
                            mobile: mobileCtrl.text,
                            mobileCode: mobileCodeCtrl.text,
                          ));
                    }
                  }
                },
                color: AppColor.secondaryColor,
                text: "Continue",
                textSize: 16.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
