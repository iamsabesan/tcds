import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/app/controllers/login_controller.dart';
import 'package:tcds_student/app/controllers/register_controller.dart';
import 'package:tcds_student/app/ui/screens/login/forgot_password.dart';
import 'package:tcds_student/app/ui/widgets/custom_text.dart';
import 'package:tcds_student/app/ui/widgets/custom_textfield.dart';
import 'package:tcds_student/app/ui/widgets/pop_scope_handler.dart';
import 'package:tcds_student/constants/app_string.dart';
import 'package:tcds_student/constants/asset_paths.dart';
import 'package:tcds_student/constants/colors.dart';
import '../../../../constants/shared_pref.dart';
import '../../../routes/routes.dart';
import '../../widgets/phone_textfield.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  // password obscure icon
  bool obscureIcon = true;

  // login fields controller
  // TextEditingController emailIDCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController passwordCtrl = TextEditingController();

  /* // regex func for to check email
  bool isEmail(String value) {
    String pattern =
        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9]+\.[a-zA-Z]+";
    RegExp regex = RegExp(pattern);
    return regex.hasMatch(value);
  } */

  // formkey to validate fields
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  // find login controller
  LoginController loginController = Get.find<LoginController>();
  RegisterController registerController = Get.put(RegisterController());

  // call guest to access phone codes
  Future<void> callGuest() async {
// call guest to access some basic api's
    isGuestCalled = await loginController.userLogin(
        userName: AppStrings.guestUser,
        password: AppStrings.guestPassword,
        isGuest: true);

    if (isGuestCalled) {
      await registerController.getPhoneCodes();
    }
  }

  // helper to identify is guest called
  bool isGuestCalled = false;

  @override
  void initState() {
    super.initState();
    callGuest();
  }

  @override
  Widget build(BuildContext context) {
    return PopScopeHandler(
      child: Scaffold(
          backgroundColor: AppColor.whiteColor,
          body: SingleChildScrollView(
            child: Center(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Form(
                  key: formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 100.w,
                      ),
                      // logo's
                      Image.asset(
                        AssetPath.registerNoLogo,
                        scale: 7,
                      ),
                      SizedBox(
                        height: 10.w,
                      ),
                      Image.asset(
                        AssetPath.tcdsLogo,
                        scale: 2.4,
                      ),
                      SizedBox(
                        height: 40.w,
                      ),
                      //
                      // login textfields
                      Align(
                        alignment: Alignment.centerLeft,
                        child: CustomText(
                          text: "Welcome Back !",
                          fontSize: 25.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColor.secondaryColor,
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: CustomText(
                          text: "Please login to Continue",
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w500,
                          color: AppColor.black3Color,
                        ),
                      ),
                      SizedBox(
                        height: 60.w,
                      ),
                      /*  CustomTextField(
                        labelText: "Email ID",
                        autofocus: true,
                        controller: emailIDCtrl,
                        prefixIcon: Icon(
                          Icons.mail_rounded,
                          color: AppColor.black2Color,
                        ),
                        validator: (value) {
                          if (value != null && isEmail(value)) {
                            return null;
                          } else {
                            return "Enter a valid email";
                          }
                        },
                      ), */

                      PhoneTextField(
                          controller: mobileCtrl,
                          mobileCodecontroller: mobileCodeCtrl,
                          labelText: "Mobile"),
                      SizedBox(
                        height: 50.w,
                      ),

                      CustomTextField(
                        labelText: 'Password',
                        controller: passwordCtrl,
                        obscureText: obscureIcon,
                        prefixIcon: const Icon(
                          Icons.lock,
                          color: AppColor.black2Color,
                        ),
                        validator: (value) {
                          if (value != null && value.isEmpty) {
                            return "Required";
                          }
                          return null;
                        },
                        inputFormatters: [LengthLimitingTextInputFormatter(25)],
                        suffixIcon: GestureDetector(
                          onTap: () {
                            setState(() {
                              obscureIcon = !obscureIcon;
                            });
                          },
                          child: Image.asset(
                            obscureIcon
                                ? AssetPath.eyeInvisible
                                : AssetPath.eveVisible,
                            scale: 20.0,
                            color: AppColor.black2Color,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: InkWell(
                            onTap: () {
                              Get.to(() => const ForgotPassword());
                            },
                            child: CustomText(
                              text: "Forgot Password?",
                              color: AppColor.primaryColor,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 60.w,
                      ),

                      // login button
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(25.r),
                              splashColor: AppColor.primaryColor,
                              onTap: () async {
                                // validate login fields
                                if (formKey.currentState!.validate()) {
                                  // call api
                                  bool response =
                                      await loginController.userLogin(
                                          userName:
                                              "${mobileCodeCtrl.text}-${mobileCtrl.text}",
                                          // emailIDCtrl.text,
                                          password: passwordCtrl.text);

                                  if (response) {
                                    Get.toNamed(Routes.dashBoard);
                                  }
                                }
                              },
                              child: Container(
                                alignment: Alignment.center,
                                padding: EdgeInsets.symmetric(
                                    horizontal: 15.w, vertical: 15.w),
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                    color: AppColor.primaryColor,
                                    borderRadius: BorderRadius.circular(30.r)),
                                child: CustomText(
                                  text: "Login",
                                  color: AppColor.whiteColor,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          // register
                          Expanded(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(25.r),
                              splashColor: AppColor.primaryColor,
                              onTap: () async {
                                if (isGuestCalled) {
                                  SharedPref.putBool(
                                      AppStrings.isLoggedIn, false);
                                  //  Navigate to dashboard as Guest
                                  Get.offAllNamed(Routes.dashBoard);
                                }
                              },
                              child: Container(
                                alignment: Alignment.center,
                                padding: EdgeInsets.symmetric(
                                    vertical: 15.w, horizontal: 15.w),
                                clipBehavior: Clip.antiAlias,
                                decoration: BoxDecoration(
                                    color:
                                        AppColor.secondaryColor.withAlpha(100),
                                    borderRadius: BorderRadius.circular(30.r)),
                                child: CustomText(
                                  text: "Register",
                                  color: AppColor.secondaryColor,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20.w,
                      ),
                      /*     Center(
                        child: SizedBox(
                          width: width * 0.4,
                          child: Row(
                            children: [
                              Flexible(
                                child: Divider(
                                  endIndent: 5,
                                  color: AppColor.grey,
                                  thickness: 1,
                                ),
                              ),
                              CustomText(
                                text: "Or",
                                color: AppColor.grey,
                                fontWeight: FontWeight.w500,
                              ),
                              Flexible(
                                child: Divider(
                                  indent: 5,
                                  color: AppColor.grey,
                                  thickness: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // register button
                      RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "Is this your first time?  ",
                              style: TextStyle(
                                  color: AppColor.blackColor,
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14.sp),
                            ),
                            TextSpan(
                              text: "Enquiry & Register",
                              recognizer: TapGestureRecognizer()
                                ..onTap = () async {
                                  PleaseWaitLoader.openDialog();
                                  // before navigation, let's call guest login to call further api
                                  bool res = await loginController.userLogin(
                                      userName: AppStrings.guestUser,
                                      password: AppStrings.guestPassword);
                                  PleaseWaitLoader.closeDialog();
                                  if (res) {
                                    SharedPref.putBool(
                                        AppStrings.isLoggedIn, false);
                                    //  Navigate to dashboard as Guest
                                    Get.offAllNamed(Routes.dashBoard);
                                  }
                                },
                              style: TextStyle(
                                color: AppColor.secondaryColor,
                                fontWeight: FontWeight.w600,
                                fontSize: 16.sp,
                                decoration: TextDecoration.underline,
                              ),
                            ),
                          ],
                        ),
                      ), */
                    ],
                  ),
                ),
              ),
            ),
          )),
    );
  }
}
