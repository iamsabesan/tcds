import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/constants/colors.dart';
import 'package:tcds_student/utils/helper_functions/dialogs.dart';
import 'package:tcds_student/utils/widgets/back_button.dart';

import '../../../controllers/login_controller.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/custom_textfield.dart';
import '../../widgets/in_button.dart';
import 'change_password.dart';
import 'timer_recent_section.dart';

class OtpScreen extends StatefulWidget {
  final String mobile;
  final String mobileCode;
  const OtpScreen({super.key, required this.mobile, required this.mobileCode});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  // find signin controller
  LoginController logInGetCtrl = Get.find<LoginController>();

  TextEditingController verifyCodeTxtCtrl = TextEditingController();
  // formkey to validate fields
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  // Recend On Tap
  void Function()? resendOnTap() {
    setState(() {
      logInGetCtrl.timer.cancel();
      logInGetCtrl.startTimer(setState: setState);
    });
    return null;
  }

  @override
  void initState() {
    // set seconds for timer
    logInGetCtrl.totalSeconds = logInGetCtrl.requestedOTP.isNotEmpty
        ? logInGetCtrl.requestedOTP[0].validityTime
        : 10;
    logInGetCtrl.isRecendCode = false;
    super.initState();
  }

  @override
  void dispose() {
    logInGetCtrl.timer.cancel();
    logInGetCtrl.isRecendCode = false;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.sizeOf(context).height;
    final mobile = widget.mobile;
    final maskedMobile = mobile.length > 6
        ? '${mobile.substring(0, 3)}****${mobile.substring(mobile.length - 3)}'
        : mobile;

    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: Form(
          key: formKey,
          child: ListView(
            children: [
              SizedBox(height: height * 0.1),
              Align(
                alignment: Alignment.centerLeft,
                child: CustomBackArrowButton(
                  onTap: () {
                    Get.back();
                  },
                ),
              ),
              SizedBox(height: 30.w),

              Align(
                alignment: Alignment.centerLeft,
                child: CustomText(
                  text: "Verify it's you",
                  fontSize: 25.sp,
                  fontWeight: FontWeight.w600,
                  color: AppColor.secondaryColor,
                ),
              ),
              SizedBox(height: 10.w),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "We send a code to ( $maskedMobile ). Enter it here to verify your identity",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    color: AppColor.blackColor,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              SizedBox(height: height * 0.1),
              CustomTextField(
                labelText: "Verification Code",
                controller: verifyCodeTxtCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(6),
                  FilteringTextInputFormatter.digitsOnly,
                ],
                validator: (val) {
                  if (val != null && val.isEmpty) {
                    return "Required";
                  } else if (val != null && val.length < 6) {
                    return "Please enter the 6 Digit verification code";
                  } else {
                    return null;
                  }
                },
              ),

              SizedBox(height: 20.w),

              // Timer Section
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 10.w),
                child: TimerAndRecendCode(
                  recentCodeOnTap: () async {
                    bool isResendGetted = await logInGetCtrl.requestOTP(
                      body: {
                        "phone": widget.mobile,
                        "phoneCode": widget.mobileCode
                      },
                    );
                    if (isResendGetted) {
                      resendOnTap();
                    }
                  },
                ),
              ),
              SizedBox(height: height * 0.1),

              // Verify OTP Button
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 25.w),
                child: InButton(
                  color: AppColor.secondaryColor,
                  onTap: () async {
                    if (formKey.currentState!.validate()) {
                      bool isOTPVerified = await logInGetCtrl.verifyOTP(body: {
                        if (logInGetCtrl.requestedOTP.isNotEmpty)
                          "SMSOTPTransID":
                              logInGetCtrl.requestedOTP[0].otpTransId,
                        "SMSOTPCode": verifyCodeTxtCtrl.text,
                      }
                          /*  {
                          "OTPTransID": logInGetCtrl.requestedOTP.isEmpty
                              ? ""
                              : logInGetCtrl.requestedOTP.first.otpTransId
                                  .toString(),
                          "OTPType": "ForgotPassword",
                          "OTPCode": verifyCodeTxtCtrl.text,
                        }, */
                          );

                      if (isOTPVerified) {
                        if (!context.mounted) return;
                        /*  successAlertDialog(
                          context,
                          content: "OTP Verified Successfully...",
                          autoClose: true,
                          autoCloseDuration: const Duration(seconds: 3),
                          onPressed: () {
                            Get.to(() => ChangePassword(
                                  mobile: widget.mobile,
                                  mobileCode: widget.mobileCode,
                                ));
                          },
                        ); */

                        await successAlertDialog(
                          context,
                          content:
                              "Verification successful.\nProceed to create a new password.",
                          onPressed: () {
                            Get.back();
                            Get.offAll(() => ChangePassword(
                                  mobile: widget.mobile,
                                  mobileCode: widget.mobileCode,
                                ));
                          },
                        );
                      }
                    }
                  },
                  text: 'Verify',
                ),
              ),
              SizedBox(height: 60.w),
            ],
          ),
        ),
      ),
    );
  }

  final authOutlineInputBorder = OutlineInputBorder(
    borderSide: const BorderSide(color: AppColor.grey2),
    borderRadius: BorderRadius.all(Radius.circular(12.r)),
  );
}
