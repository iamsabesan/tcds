import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/constants/colors.dart';

import '../../../controllers/login_controller.dart';
import '../../widgets/custom_text.dart';

class TimerAndRecendCode extends StatefulWidget {
  const TimerAndRecendCode({super.key, this.recentCodeOnTap});
  final void Function()? recentCodeOnTap;

  @override
  State<TimerAndRecendCode> createState() => _TimerAndRecendCodeState();
}

class _TimerAndRecendCodeState extends State<TimerAndRecendCode> {
  LoginController otpObject = Get.find<LoginController>();

  @override
  void initState() {
    super.initState();
    otpObject.startTimer(setState: setState);
  }

  String _formatTime(int remainingSeconds) {
    int minutes = remainingSeconds ~/ 60;
    int seconds = remainingSeconds % 60;

    String formattedMinutes = minutes.toString().padLeft(2, '0');
    String formattedSeconds = seconds.toString().padLeft(2, '0');

    return "$formattedMinutes:$formattedSeconds";
  }

  @override
  void dispose() {
    otpObject.timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint('Timer Screen');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Align(
          alignment: Alignment.centerRight,
          child: CustomText(
            text: '${_formatTime(otpObject.totalSeconds)} sec',
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
            fontSize: 14.sp,
          ),
        ),
        SizedBox(height: 60.w),
        CustomText(
          text: 'Haven\'t received Code ?',
          color: AppColor.blackColor,
          fontWeight: FontWeight.w400,
          fontSize: 12.sp,
        ),
        SizedBox(height: 10.w),
        GestureDetector(
          onTap: otpObject.isRecendCode
              ? () {
                  widget.recentCodeOnTap!();
                  otpObject.resetTimer(setState: setState);
                }
              : null,
          child: CustomText(
            text: 'Resend Code',
            color:
                otpObject.isRecendCode ? AppColor.primaryColor : AppColor.grey,
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
