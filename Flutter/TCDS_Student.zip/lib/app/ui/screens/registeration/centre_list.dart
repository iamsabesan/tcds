import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:tcds_student/app/controllers/dashboard_controller.dart';
import 'package:tcds_student/app/controllers/register_controller.dart';
import 'package:tcds_student/app/ui/widgets/custom_text.dart';
import 'package:tcds_student/constants/app_string.dart';
import 'package:tcds_student/constants/asset_paths.dart';
import 'package:tcds_student/constants/colors.dart';
import 'package:tcds_student/constants/shared_pref.dart';
import '../../../models/registeration/franchise_district.dart';
import '../../../models/registeration/franchise_state.dart';
import '../../../models/registeration/franchise_taluk.dart';
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/searchable_dropdown.dart';
import '../../widgets/single_dropdown.dart';
import 'course_list.dart';
import 'get_map_view.dart';

class CentreList extends StatefulWidget {
  const CentreList({
    super.key,
  });

  @override
  State<CentreList> createState() => _CentreListState();
}

class _CentreListState extends State<CentreList> {
  // find register controller
  RegisterController registerController = Get.find<RegisterController>();
  DashboardController dashboardGetCtrl = Get.find<DashboardController>();

  // Change appbar title dynamically based on from pages
  String? appBarTitle;

  @override
  void initState() {
    // Get dynamic appBar title to show
    appBarTitle = Get.arguments["appBarTitle"];
    debugPrint("AppBar Title $appBarTitle");

    // call necessary API calls
    neccessaryAPICalls();

    super.initState();
  }

  // call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    registerController.centresScrLoader.value = true;
    // clear controller lists
    registerController.franchiseState.clear();
    registerController.franchiseDistrict.clear();
    registerController.franchiseTaluk.clear();

    // IF: user LOGGED IN, get his address and show results based on that
    bool isLogged = SharedPref.getBool(AppStrings.isLoggedIn);
    if (isLogged && dashboardGetCtrl.personalInfoDetail.isNotEmpty) {
      debugPrint('Found User');
      final userAddress =
          dashboardGetCtrl.personalInfoDetail.first.address.first;

      // fetch States of India
      await registerController.fetchFranchiseState();

      // find user state
      if (registerController.franchiseState.isNotEmpty) {
        FranchiseState userState = registerController.franchiseState.firstWhere(
          (element) {
            return element.stateProvinceName
                    .toLowerCase()
                    .removeAllWhitespace ==
                userAddress.state.toLowerCase().removeAllWhitespace;
          },
          orElse: () {
            return registerController.franchiseState.firstWhere(
              (item) =>
                  item.stateProvinceName.toLowerCase().removeAllWhitespace ==
                  "tamilnadu",
            );
          },
        );
        stateTxtCtrl.text = userState.stateProvinceName;
        stateIDCtrl.text =
            userState.stateProvinceName.toLowerCase().removeAllWhitespace;
        // fetch Districts of the State
        await registerController.fetchFranchiseDistrict(
            stateName: userState.stateProvinceName.toString());
      }
      // find user district
      if (registerController.franchiseDistrict.isNotEmpty) {
        FranchiseDistrict userDistrict =
            registerController.franchiseDistrict.firstWhere(
          (element) {
            return element.districtProvinceName
                    .toLowerCase()
                    .removeAllWhitespace ==
                userAddress.district.toLowerCase().removeAllWhitespace;
          },
          orElse: () {
            return registerController.franchiseDistrict.first;
          },
        );
        districtTxtCtrl.text = userDistrict.districtProvinceName;
        districtIDCtrl.text =
            userDistrict.districtProvinceName.toString().removeAllWhitespace;
        // fetch Taluks of the District
        await registerController.fetchFranchiseTaluk(
            districtName: userDistrict.districtProvinceName);
      }

      // NOTE : For now "Taluk not added" to the "User Address Responce"
      // find user taluk
      if (registerController.franchiseTaluk.isNotEmpty) {
        FranchiseTaluk userTaluk = registerController.franchiseTaluk.first;
        // registerController.taluk.firstWhere(
        //   (element) {
        //     return element.taluk.toLowerCase().removeAllWhitespace ==
        //         userAddress.taluk.toLowerCase().removeAllWhitespace;
        //   },
        // );
        talukTxtCtrl.text = userTaluk.taluk;
        talukIDCtrl.text = userTaluk.taluk.toLowerCase().removeAllWhitespace;
      }

      // after got all fields that required to fetch centres let's get it
      await registerController.fetchCentres(payload: {
        if (registerController.franchiseState.isNotEmpty)
          "state": stateTxtCtrl.text,
        if (registerController.franchiseDistrict.isNotEmpty)
          "district": districtTxtCtrl.text,
        if (registerController.franchiseTaluk.isNotEmpty)
          "taluk": talukTxtCtrl.text,
      });

      registerController.centresScrLoader.value = false;
      // later required api calls
      studentDetailAPICalls();

      return;
    }

    debugPrint('Found Guest');

    // ELSE: just an enquiry as "Guest"

    // fetch States of India
    await registerController.fetchFranchiseState();
    FranchiseState state = registerController.franchiseState.firstWhere(
      (element) {
        return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
            "tamilnadu";
      },
      orElse: () => registerController.franchiseState.first,
    );
    stateTxtCtrl.text = state.stateProvinceName;
    stateIDCtrl.text = state.stateProvinceName.toString().removeAllWhitespace;
    await registerController.fetchFranchiseDistrict(
        stateName: state.stateProvinceName);
    await registerController.fetchFranchiseTaluk(
        districtName:
            registerController.franchiseDistrict[0].districtProvinceName);

    // after got all fields that required to fetch centres let's get it
    await registerController.fetchCentres(payload: {
      if (registerController.franchiseState.isNotEmpty)
        "state": registerController.franchiseState[0].stateProvinceName,
      if (registerController.franchiseDistrict.isNotEmpty)
        "district":
            registerController.franchiseDistrict[0].districtProvinceName,
      if (registerController.franchiseTaluk.isNotEmpty)
        "taluk": registerController.franchiseTaluk[0].taluk
    });

    registerController.centresScrLoader.value = false;
    // later required api calls
    studentDetailAPICalls();
  }

  // call api's that required to show student details page
  Future<void> studentDetailAPICalls() async {
    registerController.fetchHowKnowTCDS();
    registerController.fetchPurposes();
    registerController.getPhoneCodes();
    registerController.getGenderTypes();
    // registerController.getQualifications();
    registerController.getRelationships();
    registerController.getOccupations();
    registerController.getTCDSReasons();
    registerController.fetchCentreDetails();
  }

  // textediting controller
  TextEditingController stateTxtCtrl = TextEditingController();
  TextEditingController stateIDCtrl = TextEditingController();
  TextEditingController districtTxtCtrl = TextEditingController();
  TextEditingController districtIDCtrl = TextEditingController();
  TextEditingController talukTxtCtrl = TextEditingController();
  TextEditingController talukIDCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        leading: InkWell(
          splashColor: AppColor.black2Color,
          onTap: () {
            Get.back();
          },
          child: Icon(
            Icons.arrow_back_ios_new_outlined,
            size: 30.w,
          ),
        ),
        title: CustomText(
          text: appBarTitle ?? "Registration",
          fontSize: 20.sp,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w400,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: Obx(
        () => registerController.centresScrLoader.value
            ? const CustomProgressIndicator()
            : Column(
                children: [
                  // if page opeens from using Enquiry & Registration
                  if (appBarTitle != null &&
                      appBarTitle?.toLowerCase() == "enquiry & registration")
                    /* const CustomText(
                      text: "SPECIAL DISCOUNT & CASH BACK OFFER AVAILABLE",
                      fontWeight: FontWeight.w500,
                      color: AppColor.darkPink,
                    ), */
                    Container(
                      width: double.infinity,
                      alignment: Alignment.center,
                      padding: EdgeInsets.all(20.w),
                      color: AppColor.violet,
                      child: CustomText(
                        text: "SPECIAL DISCOUNT\nOFFERS AVAILABLE...",
                        color: AppColor.whiteColor,
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  const SizedBox(
                    height: 20,
                  ),
                  // filter dropdowns
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Obx(
                      () => SearchableDropdown(
                        labelText: "State",
                        valueController: stateIDCtrl,
                        valueTextController: stateTxtCtrl,
                        items: List.generate(
                          registerController.franchiseState.length,
                          (index) {
                            return SingleSelectDropDownModel(
                                registerController
                                    .franchiseState[index].stateProvinceName,
                                registerController
                                    .franchiseState[index].stateProvinceName
                                    .toLowerCase());
                          },
                        ),
                        parentOnChangeCall: () async {
                          districtIDCtrl.clear();
                          districtTxtCtrl.clear();
                          await registerController.fetchFranchiseDistrict(
                              stateName: stateIDCtrl.text);
                          talukIDCtrl.clear();
                          talukTxtCtrl.clear();
                          await registerController.fetchFranchiseTaluk(
                              districtName: registerController
                                  .franchiseDistrict[0].districtProvinceName);

                          if (registerController.franchiseTaluk.isNotEmpty) {
                            // assign new fetched taluk values to controllers
                            String fetchedTaluk =
                                registerController.franchiseTaluk[0].taluk;
                            talukTxtCtrl.text = fetchedTaluk;
                            talukIDCtrl.text = fetchedTaluk.toLowerCase();
                          }

                          await registerController.fetchCentres(payload: {
                            if (stateTxtCtrl.text.isNotEmpty)
                              "state": stateTxtCtrl.text,
                            if (registerController.franchiseDistrict.isNotEmpty)
                              "district": registerController
                                  .franchiseDistrict[0].districtProvinceName,
                            if (registerController.franchiseTaluk.isNotEmpty)
                              "taluk":
                                  registerController.franchiseTaluk[0].taluk
                          });
                        },
                      ),
                    ),
                  ),

                  SizedBox(
                    height: 20.w,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 45,
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              labelText: "District",
                              valueController: districtIDCtrl,
                              valueTextController: districtTxtCtrl,
                              items: List.generate(
                                registerController.franchiseDistrict.length,
                                (index) {
                                  return SingleSelectDropDownModel(
                                      registerController
                                          .franchiseDistrict[index]
                                          .districtProvinceName,
                                      registerController
                                          .franchiseDistrict[index]
                                          .districtProvinceName
                                          .toLowerCase());
                                },
                              ),
                              parentOnChangeCall: () async {
                                talukIDCtrl.clear();
                                talukTxtCtrl.clear();
                                await registerController.fetchFranchiseTaluk(
                                    districtName: districtTxtCtrl.text);

                                await registerController.fetchCentres(payload: {
                                  if (stateTxtCtrl.text.isNotEmpty)
                                    "state": stateTxtCtrl.text,
                                  if (districtTxtCtrl.text.isNotEmpty)
                                    "district": districtTxtCtrl.text,
                                  if (registerController
                                      .franchiseTaluk.isNotEmpty)
                                    "taluk": registerController
                                        .franchiseTaluk[0].taluk
                                });
                              },
                            ),
                          ),
                        ),
                        const Spacer(
                          flex: 5,
                        ),
                        Expanded(
                          flex: 45,
                          child: Obx(
                            () => SearchableDropdown(
                              // key: UniqueKey(),
                              labelText: "Taluk",
                              valueController: talukIDCtrl,
                              valueTextController: talukTxtCtrl,
                              items: List.generate(
                                registerController.franchiseTaluk.length,
                                (index) {
                                  return SingleSelectDropDownModel(
                                      registerController
                                          .franchiseTaluk[index].taluk,
                                      registerController
                                          .franchiseTaluk[index].taluk
                                          .toLowerCase());
                                },
                              ),
                              parentOnChangeCall: () async {
                                await registerController.fetchCentres(payload: {
                                  if (stateTxtCtrl.text.isNotEmpty)
                                    "state": stateTxtCtrl.text,
                                  if (districtTxtCtrl.text.isNotEmpty)
                                    "district": districtTxtCtrl.text,
                                  if (talukTxtCtrl.text.isNotEmpty)
                                    "taluk": talukTxtCtrl.text
                                });
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 30.w,
                  ),

                  // centre list
                  Expanded(
                      child: Obx(
                    () => registerController.centresListLoader.value
                        ? const CustomProgressIndicator()
                        : registerController.centres.isEmpty
                            ? const Center(
                                child: CustomText(
                                  text: "No Data found",
                                ),
                              )
                            : ListView.builder(
                                itemCount: registerController.centres.length,
                                itemBuilder: (context, index) {
                                  // centre data
                                  final centre =
                                      registerController.centres[index];

                                  return InkWell(
                                    splashColor: Colors.white,
                                    onTap: () async {
                                      Get.to(() => CourseList(
                                            centreDetail: centre,
                                            franchiseLocation: centre.taluk,
                                            franchiseName:
                                                centre.franchiseeName,
                                            courseList: centre.courses,
                                            // show register button when comees from Enquiry & Registration
                                            withRegister:
                                                appBarTitle?.toLowerCase() ==
                                                    "enquiry & registration",
                                          ));
                                    },
                                    child: Column(
                                      children: [
                                        Column(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 20.w,
                                                  vertical: 10.w),
                                              color: AppColor.grey2,
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  CustomText(
                                                    text: centre.contactName,
                                                    color: AppColor.blackColor,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 14.sp,
                                                  ),
                                                  CustomText(
                                                    text:
                                                        '${centre.phoneCode} ${centre.phone}',
                                                    fontSize: 12.sp,
                                                    fontWeight: FontWeight.w600,
                                                    color: AppColor.blackColor,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            // Divider(
                                            //   color: AppColor.brightOrange,
                                            //   thickness: 0.4,
                                            //   height: 6,
                                            // ),
                                            Padding(
                                              padding: EdgeInsets.symmetric(
                                                  horizontal: 20.w,
                                                  vertical: 10.w),
                                              child: Row(
                                                children: [
                                                  // Column(
                                                  //   children: [
                                                  Container(
                                                    height: 60.w,
                                                    width: 60.w,
                                                    clipBehavior: Clip.hardEdge,
                                                    decoration:
                                                        const BoxDecoration(
                                                      shape: BoxShape.circle,
                                                    ),
                                                    child: ((centre
                                                                .ownerImage !=
                                                            null))
                                                        ? Image.memory(
                                                            base64Decode(centre
                                                                .ownerImage!
                                                                .fetchedBase64!),
                                                            fit: BoxFit.cover,
                                                            errorBuilder: (context,
                                                                    error,
                                                                    stackTrace) =>
                                                                Image.asset(
                                                              AssetPath
                                                                  .defaultProfile,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          )
                                                        : Image.asset(
                                                            AssetPath
                                                                .defaultProfile,
                                                            fit: BoxFit.cover,
                                                          ),
                                                  ),
                                                  // const SizedBox(
                                                  //   height: 10,
                                                  // ),
                                                  // CustomText(
                                                  //   text:
                                                  //       '${centre.phoneCode} ${centre.phone}',
                                                  //   fontSize: 12.sp,
                                                  //   color: AppColor.blackColor,
                                                  // ),
                                                  //   ],
                                                  // ),
                                                  SizedBox(
                                                    width: 10.w,
                                                  ),
                                                  Expanded(
                                                      child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      // CustomText(
                                                      //   text: centre.contactName,
                                                      //   color: AppColor.blackColor,
                                                      //   fontWeight: FontWeight.w600,
                                                      //   fontSize: 14.sp,
                                                      // ),
                                                      // const SizedBox(
                                                      //   height: 5,
                                                      // ),
                                                      CustomText(
                                                        text: centre
                                                            .franchiseeName,
                                                        color: AppColor
                                                            .primaryColor,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        fontSize: 14.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      CustomText(
                                                        text: centre.address1,
                                                        color:
                                                            AppColor.blackColor,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 14.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      if (centre
                                                          .address2.isNotEmpty)
                                                        CustomText(
                                                          text: centre.address2,
                                                          color: AppColor
                                                              .blackColor,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontSize: 14.sp,
                                                        ),
                                                      if (centre
                                                          .address2.isNotEmpty)
                                                        const SizedBox(
                                                          height: 5,
                                                        ),
                                                      CustomText(
                                                        text: centre.area,
                                                        color: AppColor
                                                            .primaryColor,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: 14.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      CustomText(
                                                        text: centre.taluk,
                                                        color:
                                                            AppColor.blackColor,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize: 14.sp,
                                                      ),
                                                    ],
                                                  )),
                                                  Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      CustomText(
                                                        text: "COURSES",
                                                        color:
                                                            AppColor.darkPink,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontSize: 14.sp,
                                                      ),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      InkWell(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.r),
                                                        onTap: () {
                                                          Get.to(
                                                              () => GetMapView(
                                                                    position: LatLng(
                                                                        double.parse(centre
                                                                            .latitude),
                                                                        double.parse(
                                                                            centre.longitude)),
                                                                    centreDetail:
                                                                        centre,
                                                                  ));
                                                          // Get.to(() =>MapPage(centreDetail: widget.centreDetail,));
                                                        },
                                                        child: Image.asset(
                                                          AssetPath
                                                              .locationOrange,
                                                          height: 35.w,
                                                          width: 35.w,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  // Icon(
                                                  //   Icons.arrow_forward_ios_rounded,
                                                  //   color: AppColor.black3Color,
                                                  //   size: 20.w,
                                                  // ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        const Divider(
                                          color: AppColor.grey,
                                          height: 0,
                                        )
                                      ],
                                    ),
                                  );
                                },
                              ),
                  ))
                ],
              ),
      ),
    );
  }
}
