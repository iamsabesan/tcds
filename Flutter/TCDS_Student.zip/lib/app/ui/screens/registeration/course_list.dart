import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import 'package:tcds_student/app/ui/widgets/searchable_dropdown.dart';
import 'package:tcds_student/app/ui/widgets/single_dropdown.dart';
import '../../../../constants/colors.dart';
import '../../../models/registeration/centres.dart';
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/custom_text.dart';
import 'course_semester_details.dart';

class CourseList extends StatefulWidget {
  final List<Course> courseList;
  final String franchiseName;
  final String franchiseLocation;
  final CentreData centreDetail;
  final bool withRegister;

  const CourseList(
      {super.key,
      required this.courseList,
      required this.franchiseName,
      required this.franchiseLocation,
      required this.centreDetail,
      this.withRegister = true});

  @override
  State<CourseList> createState() => _CourseListState();
}

class _CourseListState extends State<CourseList> {
  // loaders
  bool _scrLoader = true;
  bool _filterLoader = false;

  List<String> courseTypes = [];
  TextEditingController courseTypeTxtCtrl = TextEditingController();
  TextEditingController courseTypeIDTxtCtrl = TextEditingController();
  List<Course> selectedTypeCourses = [];

  @override
  void initState() {
    super.initState();
    // get available course types to create filter
    Set<String> tempTypeHolder = {};
    for (var element in widget.courseList) {
      tempTypeHolder.add(element.courseTypeName);
    }

    // get courses which match initial index of courseTypes
    selectedTypeCourses = widget.courseList
        .where(
          (element) => element.courseTypeName == tempTypeHolder.first,
        )
        .toList();

    // assign grouped course types to courseTypes list
    courseTypes = tempTypeHolder.toList();

    setState(() {
      _scrLoader = false;
    });
    debugPrint('''
  Course Types = $courseTypes
  selectedTypeCourses= $selectedTypeCourses
''');
  }

  NumberFormat currenyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        scrolledUnderElevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        leading: InkWell(
          splashColor: AppColor.black2Color,
          onTap: () {
            Get.back();
          },
          child: Icon(
            Icons.arrow_back_ios_new_outlined,
            size: 30.w,
          ),
        ),
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              text: widget.franchiseName,
              fontSize: 16.sp,
              color: AppColor.blackColor,
              fontWeight: FontWeight.w500,
              overflow: TextOverflow.ellipsis,
            ),
            CustomText(
              text: widget.franchiseLocation,
              fontSize: 14.sp,
              color: AppColor.black3Color,
              fontWeight: FontWeight.w400,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
      body: _scrLoader
          ? const CustomProgressIndicator()
          : widget.courseList.isEmpty
              ? const Center(
                  child: CustomText(
                    text: "No Data found",
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(20.w),
                      child: SearchableDropdown(
                        labelText: "Course type",
                        valueController: courseTypeIDTxtCtrl,
                        valueTextController: courseTypeTxtCtrl,
                        items: List.generate(
                          courseTypes.length,
                          (index) => SingleSelectDropDownModel(
                              courseTypes[index],
                              courseTypes[index].toLowerCase()),
                        ),
                        parentOnChangeCall: () {
                          // On change of course type, get related courses
                          setState(() => _filterLoader = true);
                          // get courses which match courseTypeTxtCtrl
                          selectedTypeCourses = widget.courseList
                              .where(
                                (element) =>
                                    element.courseTypeName ==
                                    courseTypeTxtCtrl.text,
                              )
                              .toList();

                          debugPrint(
                              "selectedTypeCourses $selectedTypeCourses");
                          Future.delayed(
                            const Duration(seconds: 1),
                            () {
                              setState(() => _filterLoader = false);
                            },
                          );
                        },
                      ),
                    ),
                    Expanded(
                      child: _filterLoader
                          ? const CustomProgressIndicator()
                          : selectedTypeCourses.isEmpty
                              ? const Center(
                                  child: CustomText(
                                    text: "No Data found",
                                  ),
                                )
                              : ListView.builder(
                                  itemCount: selectedTypeCourses.length,
                                  padding: EdgeInsets.only(
                                      left: 20.w,
                                      right: 20.w,
                                      top: 20.w,
                                      bottom: 100.w),
                                  itemBuilder: (context, index) {
                                    final int totalSems =
                                        selectedTypeCourses[index]
                                            .totalSemesters;

                                    return InkWell(
                                      overlayColor:
                                          const WidgetStatePropertyAll(
                                              AppColor.whiteColor),
                                      onTap: () {
                                        Get.to(() => CourseSemesterDetails(
                                              courseDetail:
                                                  selectedTypeCourses[index],
                                              centreDetail: widget.centreDetail,
                                              withRegister: widget.withRegister,
                                            ));
                                      },
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // course details
                                          Row(
                                            children: [
                                              Expanded(
                                                child: CustomText(
                                                  text:
                                                      selectedTypeCourses[index]
                                                          .course,
                                                  color: AppColor.primaryColor,
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 16.sp,
                                                ),
                                              ),
                                              CustomText(
                                                text: currenyFormat.format(
                                                    selectedTypeCourses[index]
                                                        .courseFees),
                                                color: AppColor.secondaryColor,
                                                fontSize: 16.sp,
                                                fontWeight: FontWeight.w500,
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              SizedBox(
                                                width: 10.w,
                                              ),
                                              Icon(
                                                Icons.arrow_forward_ios_rounded,
                                                color: AppColor.black3Color,
                                                size: 20.w,
                                              ),
                                            ],
                                          ),

                                          SizedBox(
                                            height: 10.w,
                                          ),
                                          Wrap(
                                            children: [
                                              BulletText(
                                                  text:
                                                      selectedTypeCourses[index]
                                                          .shortName),
                                              BulletText(
                                                  text:
                                                      selectedTypeCourses[index]
                                                          .duration),
                                              BulletText(
                                                  text:
                                                      "$totalSems ${totalSems == 1 ? "Semester" : "Semesters"}"),
                                              BulletText(
                                                  text:
                                                      selectedTypeCourses[index]
                                                          .eligibility),
                                            ],
                                          ),
                                          // CustomText(
                                          //   text:
                                          //       "${selectedTypeCourses[index].shortName} ⚫ ${selectedTypeCourses[index].duration} ⚫ $totalSems ${totalSems == 1 ? "Semester" : "Semesters"}",
                                          //   fontWeight: FontWeight.w400,
                                          //   color: AppColor.black3Color,
                                          //   fontSize: 14.sp,
                                          // ),
                                          SizedBox(
                                            height: 5.w,
                                          ),
                                          // divider
                                          const Divider(
                                            color: AppColor.grey,
                                          ),
                                          SizedBox(
                                            height: 10.w,
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                    ),
                  ],
                ),
    );
  }
}
