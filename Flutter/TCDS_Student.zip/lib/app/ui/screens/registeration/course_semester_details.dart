import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import 'package:tcds_student/app/ui/widgets/in_button.dart';
import '../../../../constants/colors.dart';
import '../../../models/registeration/centres.dart';
import '../../widgets/custom_text.dart';
import 'get_details_page.dart';

class CourseSemesterDetails extends StatefulWidget {
  final Course courseDetail;
  final CentreData centreDetail;
  final bool withRegister;
  const CourseSemesterDetails(
      {super.key,
      required this.courseDetail,
      required this.centreDetail,
      this.withRegister = true});

  @override
  State<CourseSemesterDetails> createState() => _CourseSemesterDetailsState();
}

class _CourseSemesterDetailsState extends State<CourseSemesterDetails> {
  String? appBarTitle;
  late Course courseDetails;

  NumberFormat currenyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);

  @override
  void initState() {
    super.initState();
    courseDetails = widget.courseDetail;
    groupSemesterWise();
  }

  String getOrdinalSuffix(int number) {
    if (number % 10 == 1 && number % 100 != 11) {
      return '${number}st';
    } else if (number % 10 == 2 && number % 100 != 12) {
      return '${number}nd';
    } else if (number % 10 == 3 && number % 100 != 13) {
      return '${number}rd';
    } else {
      return '${number}th';
    }
  }

  // group data helper
  Map<int, List<Subject>> groupedSemester = {};
  List<int> semesterKeys = [];

  // group semesters to combine subjects
  void groupSemesterWise() {
    final subjectsData = courseDetails.subjects;
    for (var data in subjectsData) {
      // check is already added
      final bool isAlreadyIn = groupedSemester[data.semester] != null;
      if (isAlreadyIn) {
        groupedSemester[data.semester]?.add(data);
      } else {
        groupedSemester[data.semester] = [data];
      }
    }
    semesterKeys = groupedSemester.keys.toList();
    debugPrint("groupedSemester $groupedSemester");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        scrolledUnderElevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        leading: InkWell(
          splashColor: AppColor.black2Color,
          onTap: () {
            Get.back();
          },
          child: Icon(
            Icons.arrow_back_ios_new_outlined,
            size: 30.w,
          ),
        ),
        titleSpacing: 0,
        title: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomText(
                    text: courseDetails.course,
                    fontSize: 16.sp,
                    color: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(
                    height: 4.w,
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        BulletText(text: courseDetails.shortName),
                        BulletText(text: courseDetails.duration),
                        BulletText(
                            text:
                                "${courseDetails.totalSemesters} ${courseDetails.totalSemesters == 1 ? "Semester" : "Semesters"}"),
                        BulletText(text: courseDetails.eligibility),
                      ],
                    ),
                  ),
                  // CustomText(
                  //   text:
                  //       "${courseDetails.shortName} ⚫ ${courseDetails.duration} ⚫ ${courseDetails.totalSemesters} ${courseDetails.totalSemesters == 1 ? "Semester" : "Semesters"}",
                  //   fontSize: 12.sp,
                  //   color: AppColor.black3Color,
                  //   fontWeight: FontWeight.w400,
                  //   maxLines: 2,
                  //   overflow: TextOverflow.ellipsis,
                  // ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.only(right: 15.w),
              child: Align(
                alignment: Alignment.centerRight,
                child: CustomText(
                  text: currenyFormat.format(courseDetails.courseFees),
                  color: AppColor.secondaryColor,
                  fontWeight: FontWeight.w500,
                  fontSize: 14.sp,
                ),
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          /* // semester details
          Expanded(
            child: ListView.builder(
              itemCount: groupedSemester.keys.length,
              padding: EdgeInsets.only(
                  top: 20.w, bottom: 100.w, left: 20.w, right: 20.w),
              itemBuilder: (context, index) {
                final List<Subject>? subjects =
                    groupedSemester[semesterKeys[index]];
                return Container(
                  margin: EdgeInsets.only(bottom: 20.w),
                  child: ListTile(
                    tileColor: AppColor.grey2,
                    style: ListTileStyle.drawer,
                    title: CustomText(
                      text:
                          "${courseDetails.shortName} (${getOrdinalSuffix(semesterKeys[index])} Semester)",
                      color: AppColor.primaryColor,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.sp,
                    ),
                    subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: List.generate(
                          // get subjects length based on key/semester
                          (subjects?.length) ?? 0,
                          (subjIndex) {
                            // get current subject
                            final Subject? currSubjt = subjects?[subjIndex];
                            if (currSubjt == null) {
                              return const SizedBox();
                            }
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              child: CustomText(
                                text: currSubjt.subjectName,
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w400,
                                fontSize: 14.sp,
                              ),
                            );
                          },
                        )),
                  ),
                );
              },
            ),
          ), */
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: groupedSemester.keys.length,
              itemBuilder: (context, index) {
                final int key = (index + 1);
                final List<Subject> value = groupedSemester[key] ?? [];
                return _buildSemesterList(
                    semester: '${getOrdinalSuffix((index + 1))} Semester',
                    subjects: value,
                    shortName: courseDetails.shortName
                    // subjects: value.map((subject) {
                    //   return {
                    //     "name": subject.subjectName,
                    //     "theory": subject.theoryMarks,
                    //     "practical": subject.practicalMarks,
                    //   };
                    // }).toList(),
                    );
              },
            ),
          ),
          // register button
          if (widget.withRegister)
            Padding(
              padding: EdgeInsets.only(bottom: 15.w),
              child: SizedBox(
                width: 150.w,
                child: InButton(
                  text: "Register",
                  onTap: () {
                    Get.to(() => GetDetailsPage(
                          courseDetail: courseDetails,
                          centreDetail: widget.centreDetail,
                        ));
                  },
                ),
              ),
            )
        ],
      ),
    );
  }
}

Widget _buildSemesterList({
  required String semester,
  required List<Subject> subjects,
  required String shortName,
}) {
  int totalTheory = subjects.fold(0, (sum, item) => sum + (item.theoryMark));
  int totalPractical =
      subjects.fold(0, (sum, item) => sum + (item.practicalMark));

  int totalMarks = totalTheory + totalPractical;

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      CustomText(
        text: "$shortName ($semester)",
        fontSize: 14.sp,
        fontWeight: FontWeight.w600,
        color: AppColor.primaryColor,
      ),
      const SizedBox(
        height: 10,
      ),
      ...subjects.mapIndexed((index, subject) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: CustomText(
                      text: "${index + 1}. ${subject.subjectName}",
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Flexible(
                    child: CustomText(
                      text:
                          '${subject.theoryMark} (T)  ${subject.practicalMark} (P) ',
                      fontSize: 12.sp,
                      color: AppColor.black2Color,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  // CustomText(
                  //   text:
                  //       '${subject.theoryMarks + subject.practicalMarks} Marks',
                  //   fontSize: AppFontSize.size5.sp,
                  //   color: AppColor.orange,
                  //   fontWeight: FontWeight.w600,
                  // ),
                ],
              ),
              // SizedBox(height: 5.w),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.end,
              //   children: [
              //     Flexible(
              //       child: CustomText(
              //         text:
              //             '${subject.theoryMarks} Theory • ${subject.practicalMarks} Practical',
              //         fontSize: AppFontSize.size5.sp,
              //         color: AppColor.black2Color,
              //         fontWeight: FontWeight.w500,
              //       ),
              //     ),
              //   ],
              // ),
              const Divider(
                thickness: 0.5,
              ),
            ],
          ),
        );
      }),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const CustomText(
            text: 'Total Marks:',
            fontWeight: FontWeight.w500,
            color: AppColor.primaryColor,
          ),
          CustomText(
            text: '$totalMarks Marks',
            fontWeight: FontWeight.w600,
            color: AppColor.blackColor,
          ),
        ],
      ),
      SizedBox(height: 5.w),
      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          CustomText(
            text: '$totalTheory Theory • $totalPractical Practical',
            fontSize: 15.sp,
            color: AppColor.black2Color,
            fontWeight: FontWeight.w500,
          ),
        ],
      ),
      SizedBox(
        height: 40.w,
      )
    ],
  );
}
