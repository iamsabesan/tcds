import 'dart:async';
import 'dart:io';
import 'package:dio/dio.dart' as dio;
import 'package:http_parser/http_parser.dart' as media;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import 'package:tcds_student/app/ui/widgets/in_button.dart';
import 'package:tcds_student/app/ui/widgets/out_button.dart';
import 'package:tcds_student/constants/asset_paths.dart';
import 'package:tcds_student/utils/please_wait_loader.dart';
import '../../../../constants/colors.dart';
import '../../../controllers/register_address_controller.dart';
import '../../../controllers/register_controller.dart';
import '../../../models/common/countries.dart';
import '../../../models/common/state.dart';
import '../../../models/registeration/centres.dart';
import '../../../models/registeration/relationships.dart';
import '../../../routes/routes.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/custom_textfield.dart';
import '../../widgets/date_picker_textfield.dart';
import '../../widgets/grey_container_widget.dart';
import '../../widgets/phone_textfield.dart';
import '../../widgets/searchable_dropdown.dart';
import '../../widgets/single_dropdown.dart';
import '../../widgets/stepper.dart';
import 'list_tile.dart';

class GetDetailsPage extends StatefulWidget {
  final Course courseDetail;
  final CentreData centreDetail;
  const GetDetailsPage(
      {super.key, required this.courseDetail, required this.centreDetail});

  @override
  State<GetDetailsPage> createState() => _GetDetailsPageState();
}

class _GetDetailsPageState extends State<GetDetailsPage>
    with SingleTickerProviderStateMixin {
  // find register controller
  RegisterController registerController = Get.find<RegisterController>();
  // find register address controller
  RegisterAddressController registerAddressController =
      Get.put(RegisterAddressController());
  NumberFormat currencyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);

  // tab bar view controller
  TabController? tabController;

  // Student details fields
  final FocusNode _relationshipFocus = FocusNode();
  File? selectedImage;
  final RxInt _secondsRemaining = 0.obs;
  late Timer _timer;
  TextEditingController nameCtrl = TextEditingController();
  TextEditingController choiceCtrl = TextEditingController();
  TextEditingController choiceIDCtrl = TextEditingController();
  TextEditingController howKnowTCDSCtrl = TextEditingController();
  TextEditingController howKnowTCDSIDCtrl = TextEditingController();
  TextEditingController genderCtrl = TextEditingController();
  TextEditingController genderIDCtrl = TextEditingController();
  TextEditingController dobCtrl = TextEditingController();
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();
  TextEditingController altMobCodeCtrl = TextEditingController();
  TextEditingController altMobCtrl = TextEditingController();
  // TextEditingController emailCtrl = TextEditingController();
  TextEditingController verifyOTPCtrl = TextEditingController();
  TextEditingController qualificationCtrl = TextEditingController();
  TextEditingController qualificationIDCtrl = TextEditingController();
  TextEditingController parentNameDDCtrl = TextEditingController();
  TextEditingController parentNameDDIDCtrl = TextEditingController();
  TextEditingController parentNameCtrl = TextEditingController();
  TextEditingController occupationCtrl = TextEditingController();
  TextEditingController occupationIDCtrl = TextEditingController();
  TextEditingController reasonCtrl = TextEditingController();
  TextEditingController reasonIDCtrl = TextEditingController();

  // show verification code field helper
  bool showVerificationCode = false;
  // check whether otp verified or not
  RxBool doesOTPVerified = false.obs;

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> studentEmailForm = GlobalKey<FormState>();
  GlobalKey<FormState> studentVerifyEmailForm = GlobalKey<FormState>();
  GlobalKey<FormState> communicationValidForm = GlobalKey<FormState>();
  GlobalKey<FormState> permValidForm = GlobalKey<FormState>();
  GlobalKey<FormState> studentDetailValidForm = GlobalKey<FormState>();

  // -- Student details fields

// Address details fields
  // form key
  GlobalKey<FormState> addressDetailsForm = GlobalKey<FormState>();
  // -- Communication address fields
  TextEditingController comAddress1Ctrl = TextEditingController();
  TextEditingController comAddress2Ctrl = TextEditingController();
  TextEditingController comTalukCtrl = TextEditingController();
  TextEditingController comAreaCtrl = TextEditingController();
  TextEditingController comCountryCtrl = TextEditingController();
  TextEditingController comCountryIDCtrl = TextEditingController();
  TextEditingController comStateCtrl = TextEditingController();
  TextEditingController comStateIDCtrl = TextEditingController();
  TextEditingController comDistrictCtrl = TextEditingController();
  TextEditingController comDistrictIDCtrl = TextEditingController();
  TextEditingController comPinCodeCtrl = TextEditingController();

  // // address details page helpers
  // List<Country> comCountries = <Country>[];
  // List<States> comState = <States>[];
  // List<District> comDistrict = <District>[];
  // List<Country> permCountries = <Country>[];
  // List<States> permState = <States>[];
  // List<District> permDistrict = <District>[];

  // -- Permanent address fields
  TextEditingController permAddress1Ctrl = TextEditingController();
  TextEditingController permAddress2Ctrl = TextEditingController();
  TextEditingController permTalukCtrl = TextEditingController();
  TextEditingController permAreaCtrl = TextEditingController();
  TextEditingController permCountryCtrl = TextEditingController();
  TextEditingController permCountryIDCtrl = TextEditingController();
  TextEditingController permStateCtrl = TextEditingController();
  TextEditingController permStateIDCtrl = TextEditingController();
  TextEditingController permDistrictCtrl = TextEditingController();
  TextEditingController permDistrictIDCtrl = TextEditingController();
  TextEditingController permPinCodeCtrl = TextEditingController();

  // -- Address details fields
  bool _isChecked = false;

  // // Your choice fields data
  // List<String> yourChoices = [
  //   "For JOB Purpose",
  //   'For Own Business',
  //   'For my Higher Studies',
  //   'Improve my Computer Knowledge'
  // ];

  // // data for how you know TCDS centre
  // List<String> howKnowTcds = [
  //   'Notice & Poster',
  //   'Door Canvassing',
  //   'Friends / Relatives / Schools / Colleges',
  //   'Website',
  //   'Facebook or Instagram Advertisement.',
  //   'Youtube Advertisement.'
  // ];

  @override
  void initState() {
    addressDetailAPICalls();
    tabController = TabController(length: 3, vsync: this, initialIndex: 0);
    // default assign
    _timer = Timer(
      const Duration(seconds: 30),
      () {},
    );
    super.initState();
  }

  @override
  void dispose() {
    tabController?.dispose();
    if (_timer.isActive) {
      _timer.cancel();
    }
    super.dispose();
  }

  // call api's that required to show address details page
  Future<void> addressDetailAPICalls() async {
    await registerAddressController.fetchComCountries();

    // get country id of india
    Country india = registerAddressController.comcountries.firstWhere(
      (element) {
        return element.countryName.toLowerCase() == "india";
      },
    );
    comCountryCtrl.text = india.countryName;
    comCountryIDCtrl.text = india.countryId.toString();
    permCountryCtrl.text = india.countryName;
    permCountryIDCtrl.text = india.countryId.toString();

    // call address details state and district
    await registerAddressController.fetchComState(
        countryID: india.countryId.toString());

    await registerAddressController.fetchPermState(
        countryID: india.countryId.toString());

    States stateCom = registerAddressController.comstate.firstWhere(
      (element) {
        return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
            "tamilnadu";
      },
    );
    States statePerm = registerAddressController.permstate.firstWhere(
      (element) {
        return element.stateProvinceName.toLowerCase().removeAllWhitespace ==
            "tamilnadu";
      },
    );
    comStateCtrl.text = stateCom.stateProvinceName;
    comStateIDCtrl.text = stateCom.stateProvinceId.toString();
    permStateCtrl.text = statePerm.stateProvinceName;
    permStateIDCtrl.text = statePerm.stateProvinceId.toString();
    comDistrictIDCtrl.clear();
    comDistrictCtrl.clear();
    permDistrictIDCtrl.clear();
    permDistrictCtrl.clear();

    if (registerAddressController.comstate.isNotEmpty) {
      await registerAddressController.fetchComDistrict(
          stateID: comStateIDCtrl.text);
      await registerAddressController.fetchPermDistrict(
          stateID: permStateIDCtrl.text);
    }

    // if (registerAddressController.comdistrict.isNotEmpty) {
    //   String districtName =
    //       registerAddressController.comdistrict[0].districtName;
    //   await registerAddressController.fetchComTaluk(districtName: districtName);
    //   await registerAddressController.fetchPermTaluk(
    //       districtName: districtName);
    // }

    registerAddressController.fetchPermCountries();
  }

  // layer function for navigation
  void navigateIndex(int index) {
    tabController?.animateTo(index);
    setState(() {});
  }

  void _startTimer({required int seconds}) {
    _secondsRemaining.value = seconds;
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_secondsRemaining.value > 0) {
        _secondsRemaining.value--;
      } else {
        timer.cancel();
      }
    });
  }

  final ImagePicker picker = ImagePicker();

  // Function to pick images and check file size limit
  Future<void> pickImage() async {
    final pickedFiles = await showModalBottomSheet<XFile>(
      context: context,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: const Icon(
                Icons.camera_alt,
              ),
              title: CustomText(
                text: 'Take a picture',
                fontSize: 16.sp,
              ),
              onTap: () async {
                try {
                  final cameraImage =
                      await picker.pickImage(source: ImageSource.camera);
                  Get.back(result: cameraImage);
                } catch (e) {
                  debugPrint("Error taking picture: $e");
                }
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.photo_library,
              ),
              title: CustomText(
                text: 'Choose from gallery',
                fontSize: 16.sp,
              ),
              onTap: () async {
                try {
                  Get.back(
                      result:
                          await picker.pickImage(source: ImageSource.gallery));
                } catch (e) {
                  debugPrint("Error while choose: $e");
                }
              },
            ),
          ],
        );
      },
    );

    if (pickedFiles != null) {
      // Convert XFile to File and check file size limit
      File file = File(pickedFiles.path);

      // Check for large files
      bool hasLargeFile = file.lengthSync() > 2 * 1024 * 1024;
      if (hasLargeFile) {
        Fluttertoast.showToast(
            msg: "File size exceeds 2MB. Please choose a smaller file.",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: AppColor.primaryColor,
            textColor: AppColor.whiteColor,
            fontSize: 14);
      } else {
        selectedImage = file;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        scrolledUnderElevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        leading: InkWell(
          splashColor: AppColor.black2Color,
          onTap: () {
            Get.back();
          },
          child: Icon(
            Icons.arrow_back_ios_new_outlined,
            size: 30.w,
          ),
        ),
        title: CustomText(
          text: "Enquiry & Registration",
          fontSize: 20.sp,
          color: AppColor.blackColor,
          fontWeight: FontWeight.w400,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ),
      body: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            SizedBox(
              height: 20.w,
            ),
            const CustomText(
              text: "SPECIAL DISCOUNT & CASH BACK OFFER AVAILABLE",
              fontWeight: FontWeight.w500,
              color: AppColor.darkPink,
            ),
            SizedBox(
              height: 10.w,
            ),
            // stepper widget
            stepper(stepCount: (tabController?.index ?? 0) + 1),
            SizedBox(
              height: 10.w,
            ),
            // tab bar view based on stepper widget
            Expanded(
              child: TabBarView(
                  physics: const NeverScrollableScrollPhysics(),
                  controller: tabController,
                  children: [
                    studentDetails(),
                    addressDetails(),
                    confirmDetails(),
                  ]),
            )
          ],
        ),
      ),
    );
  }

  Widget studentDetails() {
    return StatefulBuilder(builder: (context, studentDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: studentDetailsForm,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // profile picture
                InkWell(
                    onTap: () async {
                      await pickImage();
                      // refresh student details state
                      studentDetailsState(() {});
                    },
                    child: selectedImage == null
                        ? Stack(
                            children: [
                              Image.asset(
                                AssetPath.uploadProfile,
                                scale: 4,
                              ),
                              Positioned(
                                bottom: 5.w,
                                right: 5.w,
                                child: Image.asset(
                                  AssetPath.cameraFrame,
                                  scale: 18,
                                ),
                              ),
                            ],
                          )
                        : Stack(
                            children: [
                              ClipOval(
                                child: Image.file(
                                  selectedImage!,
                                  width: 130.w,
                                  height: 130.w,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                bottom: 5.w,
                                right: 5.w,
                                child: Image.asset(
                                  AssetPath.cameraFrame,
                                  scale: 18,
                                ),
                              ),
                            ],
                          )),

                SizedBox(
                  height: 30.w,
                ),

                CustomTextField(
                  labelText: "Name",
                  controller: nameCtrl,
                  validator: (val) {
                    if (val != null && val.isEmpty) {
                      return 'Required';
                    } else {
                      return null;
                    }
                  },
                ),

                SizedBox(
                  height: 30.w,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      flex: 50,
                      child: Obx(
                        () => SingleSelectDropDown(
                          key: UniqueKey(),
                          labelText: 'Gender',
                          valueController: genderIDCtrl,
                          valueTextController: genderCtrl,
                          validator: (val) {
                            if (val != null && val.isEmpty) {
                              return 'Required';
                            } else {
                              return null;
                            }
                          },
                          // to clear focus
                          focusNode: FocusNode(),
                          data: List.generate(
                            registerController.genderTypesList.length,
                            (index) => SingleSelectDropDownModel(
                                registerController
                                    .genderTypesList[index].genderName,
                                registerController
                                    .genderTypesList[index].genderId
                                    .toString()),
                          ),
                        ),
                      ),
                    ),
                    const Spacer(
                      flex: 5,
                    ),
                    Expanded(
                      flex: 45,
                      child: DatePickerTextField(
                        labelText: 'Date of Birth',
                        controller: dobCtrl,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Required';
                          }
                          return null;
                        },
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 30.w,
                ),

                // send code to mobile number
                if (!showVerificationCode)
                  Container(
                    padding: EdgeInsets.all(20.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.grey),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Column(
                      children: [
                        Form(
                          key: studentEmailForm,
                          child: PhoneTextField(
                              controller: mobileCtrl,
                              mobileCodecontroller: mobileCodeCtrl,
                              labelText: "Mobile"),
                          // CustomTextField(
                          //   labelText: "Email",
                          //  controller: emailCtrl,
                          //   validator: (value) {
                          //     if (value == null || value.isEmpty) {
                          //       return 'Required';
                          //     } else if (!RegExp(
                          //             r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                          //         .hasMatch(value)) {
                          //       return "Invalid email address";
                          //     }
                          //     return null;
                          //   },
                          // ),
                        ),
                        SizedBox(
                          height: 30.w,
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            width: 100.w,
                            child: InButton(
                              onTap: () async {
                                // first validate email field has valid value
                                if (studentEmailForm.currentState!.validate()) {
                                  PleaseWaitLoader.openDialog();
                                  // if valid mail
                                  bool doesOTPRequested =
                                      await registerController.requestOTP(
                                          body: {
                                        "phone": mobileCtrl.text,
                                        "phoneCode": mobileCodeCtrl.text
                                      });
                                  PleaseWaitLoader.closeDialog();
                                  if (doesOTPRequested) {
                                    studentDetailsState(() {
                                      // change [showVerificationCode] value
                                      showVerificationCode =
                                          !showVerificationCode;
                                    });

                                    // assign fetched otp time to [_secondsRemaining]
                                    _secondsRemaining.value = registerController
                                            .requestedOTP.isNotEmpty
                                        ? registerController
                                            .requestedOTP[0].validityTime
                                        : 30;
                                    // [_startTimer] after expiry time fetched
                                    _startTimer(
                                      seconds: _secondsRemaining.value,
                                    );
                                  }
                                }
                                //
                              },
                              horizPad: 5.w,
                              text: 'Send Code',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                // verify email
                if (showVerificationCode)
                  Container(
                    padding: EdgeInsets.all(20.w),
                    decoration: BoxDecoration(
                      border: Border.all(color: AppColor.grey),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // change mail address
                        RichText(
                            text: TextSpan(children: [
                          TextSpan(
                              text: "${mobileCtrl.text}  ",
                              style: TextStyle(
                                color: AppColor.blackColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 14.sp,
                              )),
                          TextSpan(
                              text: "Change",
                              recognizer: TapGestureRecognizer()
                                ..onTap = () {
                                  _timer.cancel();
                                  // change otp to not verified
                                  doesOTPVerified.value = false;
                                  // clear verification code controllers
                                  verifyOTPCtrl.clear();

                                  studentDetailsState(() {
                                    // change [showVerificationCode] value
                                    showVerificationCode =
                                        !showVerificationCode;
                                  });
                                },
                              style: TextStyle(
                                decoration: TextDecoration.underline,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 14.sp,
                              )),
                        ])),
                        SizedBox(
                          height: 30.w,
                        ),

                        // verify otp field
                        Form(
                          key: studentVerifyEmailForm,
                          child: CustomTextField(
                            labelText: "Verification Code",
                            controller: verifyOTPCtrl,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              return null;
                            },
                          ),
                        ),

                        // resend and timer
                        Obx(
                          () => Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              TextButton(
                                onPressed: _secondsRemaining.value == 0
                                    ? () async {
                                        // stop timer
                                        _timer.cancel();

                                        // request new otp
                                        PleaseWaitLoader.openDialog();
                                        bool doesOTPResended =
                                            await registerController.resendOTP(
                                                body: {
                                              "phone": mobileCtrl.text,
                                              "phoneCode": mobileCodeCtrl.text
                                            });
                                        PleaseWaitLoader.closeDialog();

                                        // if otp resended sucessfully
                                        if (doesOTPResended) {
                                          doesOTPVerified.value = false;
                                          verifyOTPCtrl.clear();
                                          // assign fetched otp time to [_secondsRemaining]
                                          _secondsRemaining.value =
                                              registerController
                                                      .requestedOTP.isNotEmpty
                                                  ? registerController
                                                      .requestedOTP[0]
                                                      .validityTime
                                                  : 30;
                                          // [_startTimer] after expiry time fetched
                                          _startTimer(
                                            seconds: _secondsRemaining.value,
                                          );
                                        }
                                      }
                                    : null,
                                child: CustomText(
                                  text: "Resend",
                                  color: _secondsRemaining.value == 0
                                      ? AppColor.primaryColor
                                      : AppColor.grey,
                                ),
                              ),
                              CustomText(
                                text: _secondsRemaining.value > 0
                                    ? "Resend in ${_secondsRemaining.value} s"
                                    : "You can resend now",
                                color: AppColor.grey,
                              ),
                            ],
                          ),
                        ),

                        SizedBox(
                          height: 20.w,
                        ),

                        // verify button
                        Obx(
                          () => Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              width: 100.w,
                              child: InButton(
                                color: doesOTPVerified.value
                                    ? AppColor.grey
                                    : AppColor.primaryColor,
                                onTap: !doesOTPVerified.value
                                    ? () async {
                                        if (studentVerifyEmailForm.currentState!
                                            .validate()) {
                                          // verify  otp
                                          PleaseWaitLoader.openDialog();
                                          doesOTPVerified.value =
                                              await registerController
                                                  .verifyOTP(body: {
                                            if (registerController
                                                .requestedOTP.isNotEmpty)
                                              "SMSOTPTransID":
                                                  registerController
                                                      .requestedOTP[0]
                                                      .otpTransId,
                                            "SMSOTPCode": verifyOTPCtrl.text,
                                          });
                                          debugPrint("Run");
                                          PleaseWaitLoader.closeDialog();

                                          // if otp verified sucessfully
                                          if (doesOTPVerified.value) {
                                            // Get.snackbar(
                                            //   'Verification',
                                            //   'Mobile Verification success',
                                            //   colorText: AppColor.whiteColor,
                                            //   padding: EdgeInsets.all(15.w),
                                            //   backgroundColor:
                                            //       AppColor.primaryColor,
                                            // );
                                            Fluttertoast.showToast(
                                                msg:
                                                    "Mobile Verification success",
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.TOP,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor:
                                                    AppColor.primaryColor,
                                                textColor: AppColor.whiteColor,
                                                fontSize: 14);
                                            // stop timer
                                            _timer.cancel();
                                            // assign '0' to [_secondsRemaining]
                                            _secondsRemaining.value = 0;
                                          }
                                        }
                                      }
                                    : null,
                                horizPad: 5.w,
                                text: 'Verify',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                SizedBox(
                  height: 30.w,
                ),
                PhoneTextField(
                    withValidator: false,
                    controller: altMobCtrl,
                    mobileCodecontroller: altMobCodeCtrl,
                    labelText: "Alternate Mobile"),

                SizedBox(
                  height: 30.w,
                ),
                // qualification textfield
                CustomTextField(
                  labelText: "Qualification",
                  controller: qualificationCtrl,
                  validator: (val) {
                    if (val != null && val.isEmpty) {
                      return 'Required';
                    } else {
                      return null;
                    }
                  },
                ),
                /* // qualification dropdown
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: 'Qualification',
                    valueController: qualificationIDCtrl,
                    valueTextController: qualificationCtrl,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registerController.qualificationsList.length,
                      (index) => SingleSelectDropDownModel(
                          registerController
                              .qualificationsList[index].qualification,
                          registerController
                              .qualificationsList[index].qualificationId
                              .toString()),
                    ),
                  ),
                ), */
                SizedBox(
                  height: 30.w,
                ),
                // realtionship field with dropdown
                CustomTextField(
                  focusNode: _relationshipFocus,
                  labelText: registerController.relationValue == null
                      ? "Relationship"
                      : registerController.relationValue!.minValue,
                  controller: parentNameCtrl,
                  validator: (val) {
                    if (val != null && val.isEmpty) {
                      return 'Required';
                    } else {
                      return null;
                    }
                  },
                  prefixIcon: Obx(
                    () => Container(
                      padding: EdgeInsets.only(left: 10.w),
                      constraints: BoxConstraints(
                        maxWidth: 100.w,
                      ),
                      child: Center(
                        child: DropdownButton<Relationship>(
                          value: registerController.relationValue,
                          padding: const EdgeInsets.all(0),
                          menuMaxHeight: 250.w,
                          isExpanded: true,
                          underline: const SizedBox(),
                          dropdownColor: AppColor.whiteColor,
                          isDense: true,
                          alignment: Alignment.center,
                          // iconSize: 0,
                          style: TextStyle(
                              color: AppColor.black2Color,
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w500),
                          onChanged: (Relationship? newValue) {
                            setState(() {
                              registerController.relationValue = newValue;
                            });
                          },
                          items: registerController.relationshipsList
                              .map<DropdownMenuItem<Relationship>>(
                                  (Relationship value) {
                            return DropdownMenuItem<Relationship>(
                              value: value,
                              alignment: Alignment.centerLeft,
                              child: SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Text(
                                  value.minValue,
                                  style: TextStyle(
                                    color: AppColor.black2Color,
                                    fontWeight: FontWeight.w500,
                                    fontSize: 14.sp,
                                  ),
                                ),
                              ),
                            );
                          }).toList(),

                          icon: Icon(
                            Icons.keyboard_arrow_down_sharp,
                            size: 25.w,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),

                // occupation dropdown
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    labelText: 'Occupation',
                    // to clear focus
                    focusNode: FocusNode(),
                    valueController: occupationIDCtrl,
                    valueTextController: occupationCtrl,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registerController.occupationsList.length,
                      (index) => SingleSelectDropDownModel(
                          registerController.occupationsList[index].occupation,
                          registerController.occupationsList[index].occupationId
                              .toString()),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                // reason to select TCDS - dropdown
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    // to clear focus
                    focusNode: FocusNode(),
                    labelText: 'Reason to select TCDS',
                    valueController: reasonIDCtrl,
                    valueTextController: reasonCtrl,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registerController.reasonsList.length,
                      (index) => SingleSelectDropDownModel(
                          registerController.reasonsList[index].reason,
                          registerController.reasonsList[index].reasonId
                              .toString()),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                // student details
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    // to clear focus
                    focusNode: FocusNode(),
                    labelText: 'How you Knew TCDS Centre ?',
                    valueController: howKnowTCDSIDCtrl,
                    valueTextController: howKnowTCDSCtrl,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registerController.knowTCDSData.length,
                      (index) => SingleSelectDropDownModel(
                          registerController.knowTCDSData[index].value,
                          registerController.knowTCDSData[index].id),
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                // student details
                Obx(
                  () => SingleSelectDropDown(
                    key: UniqueKey(),
                    // to clear focus
                    focusNode: FocusNode(),
                    labelText: 'Purpose of your Computer Study',
                    valueController: choiceIDCtrl,
                    valueTextController: choiceCtrl,
                    validator: (val) {
                      if (val != null && val.isEmpty) {
                        return 'Required';
                      } else {
                        return null;
                      }
                    },
                    data: List.generate(
                      registerController.purposesData.length,
                      (index) => SingleSelectDropDownModel(
                          registerController.purposesData[index].value,
                          registerController.purposesData[index].id),
                    ),
                  ),
                ),
                SizedBox(
                  height: 60.w,
                ),

                // next button
                SizedBox(
                  width: 150.w,
                  child: InButton(
                    withArrow: true,
                    onTap: () {
                      // validate all fields
                      bool emailValidated =
                          studentEmailForm.currentState?.validate() ?? false;
                      bool verifyCodeValidated =
                          studentVerifyEmailForm.currentState?.validate() ??
                              false;
                      bool studentDetailsValidated =
                          studentDetailsForm.currentState!.validate();

                      debugPrint(
                          "studentDetailsValidated $studentDetailsValidated");
                      debugPrint("emailValidated $emailValidated");
                      debugPrint("verifyCodeValidated $verifyCodeValidated");

                      if (selectedImage == null) {
                        //
                        /* Get.snackbar(
                          'Student Details',
                          'Please upload your profile picture to proceed.',
                          colorText: AppColor.whiteColor,
                          padding: EdgeInsets.all(15.w),
                          backgroundColor: AppColor.primaryColor,
                        ); */
                        Fluttertoast.showToast(
                            msg:
                                "Please upload your profile picture to proceed.",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.TOP,
                            timeInSecForIosWeb: 1,
                            backgroundColor: AppColor.primaryColor,
                            textColor: AppColor.whiteColor,
                            fontSize: 14);
                      } else if (!doesOTPVerified.value) {
                        /*  Get.snackbar(
                          'Student Details',
                          'Please enter your email address and verify it to proceed.',
                          colorText: AppColor.whiteColor,
                          padding: EdgeInsets.all(15.w),
                          backgroundColor: AppColor.primaryColor,
                        ); */
                        Fluttertoast.showToast(
                            msg:
                                "Please enter your mobile number and verify it to proceed.",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.TOP,
                            timeInSecForIosWeb: 1,
                            backgroundColor: AppColor.primaryColor,
                            textColor: AppColor.whiteColor,
                            fontSize: 14);
                        //
                      } else if (studentDetailsValidated &&
                          doesOTPVerified.value &&
                          selectedImage != null) {
                        debugPrint('Student Details Validated!! ');
                        // if all fields are validated successfully navigate to Address Details
                        navigateIndex(1);
                      } else {
                        debugPrint('No Conditions matches...');
                        /*    Get.snackbar(
                          'Student Details',
                          'It seems some fields are incomplete. Please check and fill them correctly.',
                          colorText: AppColor.whiteColor,
                          padding: EdgeInsets.all(15.w),
                          backgroundColor: AppColor.primaryColor,
                        ); */
                        Fluttertoast.showToast(
                            msg:
                                "It seems some fields are incomplete. Please check and fill them correctly.",
                            toastLength: Toast.LENGTH_SHORT,
                            gravity: ToastGravity.TOP,
                            timeInSecForIosWeb: 1,
                            backgroundColor: AppColor.primaryColor,
                            textColor: AppColor.whiteColor,
                            fontSize: 14);
                      }
                    },
                  ),
                ),

                SizedBox(
                  height: 30.w,
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // address details
  Widget addressDetails() {
    return StatefulBuilder(builder: (context, addressDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Form(
                key: communicationValidForm,
                child: StatefulBuilder(builder: (context, comSetState) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomText(
                        text: 'Communication Address',
                        fontSize: 16.sp,
                        color: AppColor.primaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      // student details
                      CustomTextField(
                        labelText: "Address 1",
                        controller: comAddress1Ctrl,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      CustomTextField(
                        labelText: "Address 2",
                        controller: comAddress2Ctrl,
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        children: [
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Area",
                              controller: comAreaCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: Obx(
                              () => SearchableDropdown(
                                labelText: 'Country',
                                valueController: comCountryIDCtrl,
                                valueTextController: comCountryCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                items: List.generate(
                                  registerAddressController.comcountries.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .comcountries[index].countryName,
                                      registerAddressController
                                          .comcountries[index].countryId
                                          .toString()),
                                ),
                                parentOnChangeCall: () async {
                                  registerAddressController.comstate.clear();
                                  registerAddressController.comdistrict.clear();
                                  await registerAddressController.fetchComState(
                                      countryID: comCountryIDCtrl.text);

                                  // if any state available
                                  if (registerAddressController
                                      .comstate.isNotEmpty) {
                                    comStateIDCtrl.text =
                                        registerAddressController
                                            .comstate[0].stateProvinceId
                                            .toString();
                                    comStateCtrl.text =
                                        registerAddressController
                                            .comstate[0].stateProvinceName;

                                    await registerAddressController
                                        .fetchComDistrict(
                                            stateID: registerAddressController
                                                .comstate[0].stateProvinceId
                                                .toString());

                                    // if have any district, assign
                                    if (registerAddressController
                                        .comdistrict.isNotEmpty) {
                                      comDistrictIDCtrl.text =
                                          registerAddressController
                                              .comdistrict[0].districtId
                                              .toString();
                                      comDistrictCtrl.text =
                                          registerAddressController
                                              .comdistrict[0].districtName;
                                    } else {
                                      comDistrictIDCtrl.text = "";
                                      comDistrictCtrl.text = "";
                                    }

                                    /*  if (registerAddressController
                                        .comdistrict.isNotEmpty) {
                                      await registerAddressController
                                          .fetchComTaluk(
                                              districtName:
                                                  registerAddressController
                                                      .comdistrict[0]
                                                      .districtName);
                                    } */
                                  } else {
                                    comStateIDCtrl.text = "";
                                    comStateCtrl.text = "";
                                    comDistrictIDCtrl.text = "";
                                    comDistrictCtrl.text = "";
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: Obx(
                              () => SearchableDropdown(
                                labelText: 'State',
                                valueController: comStateIDCtrl,
                                valueTextController: comStateCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                items: List.generate(
                                  registerAddressController.comstate.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .comstate[index].stateProvinceName,
                                      registerAddressController
                                          .comstate[index].stateProvinceId
                                          .toString()),
                                ),
                                parentOnChangeCall: () async {
                                  registerAddressController.comdistrict.clear();

                                  await registerAddressController
                                      .fetchComDistrict(
                                          stateID: comStateIDCtrl.text);

                                  if (registerAddressController
                                      .comdistrict.isNotEmpty) {
                                    comDistrictIDCtrl.text =
                                        registerAddressController
                                            .comdistrict[0].districtId
                                            .toString();
                                    comDistrictCtrl.text =
                                        registerAddressController
                                            .comdistrict[0].districtName;
                                  } else {
                                    comDistrictIDCtrl.text = "";
                                    comDistrictCtrl.text = "";
                                  }
                                },
                              ),
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: Obx(() {
                              return SearchableDropdown(
                                key: UniqueKey(),
                                labelText: 'District',
                                valueController: comDistrictIDCtrl,
                                valueTextController: comDistrictCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                items: List.generate(
                                  registerAddressController.comdistrict.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .comdistrict[index].districtName,
                                      registerAddressController
                                          .comdistrict[index].districtId
                                          .toString()),
                                ),
                              );
                            }),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Taluk",
                              controller: comTalukCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Pincode",
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(6),
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              controller: comPinCodeCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                }
                                if (val!.length < 6) {
                                  return '6 digit pincode required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                        ],
                      ),

                      SizedBox(
                        height: 30.w,
                      ),
                    ],
                  );
                }),
              ),
              Form(
                key: permValidForm,
                child: StatefulBuilder(builder: (context, permSetState) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CustomText(
                        text: 'Permanent Address',
                        fontSize: 16.sp,
                        color: AppColor.primaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                      SizedBox(
                        height: 10.w,
                      ),
                      Row(
                        mainAxisSize: MainAxisSize
                            .min, // Ensures the row only takes up as much space as needed
                        children: <Widget>[
                          const CustomText(
                            text: 'Same as Communication Address',
                          ),
                          Checkbox(
                            value: _isChecked, // Checkbox state
                            onChanged: (bool? value) {
                              if (communicationValidForm.currentState!
                                  .validate()) {
                                _isChecked = value ?? false;
                                if (_isChecked) {
                                  permAddress1Ctrl.text = comAddress1Ctrl.text;
                                  permAddress2Ctrl.text = comAddress2Ctrl.text;
                                  permAreaCtrl.text = comAreaCtrl.text;
                                  permCountryCtrl.text = comCountryCtrl.text;
                                  permTalukCtrl.text = comTalukCtrl.text;
                                  registerAddressController.permcountries =
                                      registerAddressController.comcountries;
                                  registerAddressController.permstate =
                                      registerAddressController.comstate;
                                  registerAddressController.permdistrict =
                                      registerAddressController.comdistrict;
                                  permCountryIDCtrl.text =
                                      comCountryIDCtrl.text;
                                  permStateCtrl.text = comStateCtrl.text;
                                  permStateIDCtrl.text = comStateIDCtrl.text;
                                  permDistrictCtrl.text = comDistrictCtrl.text;
                                  permDistrictIDCtrl.text =
                                      comDistrictIDCtrl.text;
                                  permPinCodeCtrl.text = comPinCodeCtrl.text;
                                } else {
                                  permAddress1Ctrl.clear();
                                  permAddress2Ctrl.clear();
                                  permAreaCtrl.clear();
                                  permPinCodeCtrl.clear();
                                }
                                setState(() {});
                              }
                            },
                          ), // Text next to the checkbox
                        ],
                      ),
                      // student details
                      SizedBox(
                        height: 10.w,
                      ),
                      CustomTextField(
                        labelText: "Address 1",
                        controller: permAddress1Ctrl,
                        validator: (val) {
                          if (val != null && val.isEmpty) {
                            return 'Required';
                          } else {
                            return null;
                          }
                        },
                      ),
                      SizedBox(
                        height: 30.w,
                      ),

                      CustomTextField(
                        labelText: "Address 2",
                        controller: permAddress2Ctrl,
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        children: [
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Area",
                              controller: permAreaCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: Obx(
                              () => SearchableDropdown(
                                labelText: 'Country',
                                valueController: permCountryIDCtrl,
                                valueTextController: permCountryCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                items: List.generate(
                                  registerAddressController
                                      .permcountries.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .permcountries[index].countryName,
                                      registerAddressController
                                          .permcountries[index].countryId
                                          .toString()),
                                ),
                                parentOnChangeCall: () async {
                                  registerAddressController.permstate.clear();
                                  registerAddressController.permdistrict
                                      .clear();
                                  await registerAddressController
                                      .fetchPermState(
                                          countryID: permCountryIDCtrl.text);

                                  // if any state available
                                  if (registerAddressController
                                      .permstate.isNotEmpty) {
                                    permStateIDCtrl.text =
                                        registerAddressController
                                            .permstate[0].stateProvinceId
                                            .toString();
                                    permStateCtrl.text =
                                        registerAddressController
                                            .permstate[0].stateProvinceName;

                                    await registerAddressController
                                        .fetchPermDistrict(
                                            stateID: registerAddressController
                                                .permstate[0].stateProvinceId
                                                .toString());

                                    if (registerAddressController
                                        .permdistrict.isNotEmpty) {
                                      permDistrictIDCtrl.text =
                                          registerAddressController
                                              .permdistrict[0].districtId
                                              .toString();
                                      permDistrictCtrl.text =
                                          registerAddressController
                                              .permdistrict[0].districtName;
                                    } else {
                                      permDistrictIDCtrl.text = "";
                                      permDistrictCtrl.text = "";
                                    }

                                    /*   if (registerAddressController
                                        .permdistrict.isNotEmpty) {
                                      await registerAddressController
                                          .fetchPermTaluk(
                                              districtName:
                                                  registerAddressController
                                                      .permdistrict[0]
                                                      .districtName);
                                    } */
                                  } else {
                                    permStateIDCtrl.text = "";
                                    permStateCtrl.text = "";
                                    permDistrictIDCtrl.text = "";
                                    permDistrictCtrl.text = "";
                                  }
                                },
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: Obx(
                              () => SearchableDropdown(
                                labelText: 'State',
                                valueController: permStateIDCtrl,
                                valueTextController: permStateCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                items: List.generate(
                                  registerAddressController.permstate.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .permstate[index].stateProvinceName,
                                      registerAddressController
                                          .permstate[index].stateProvinceId
                                          .toString()),
                                ),
                                parentOnChangeCall: () async {
                                  registerAddressController.permdistrict
                                      .clear();

                                  await registerAddressController
                                      .fetchPermDistrict(
                                          stateID: permStateIDCtrl.text);
                                  if (registerAddressController
                                      .permdistrict.isNotEmpty) {
                                    permDistrictIDCtrl.text =
                                        registerAddressController
                                            .permdistrict[0].districtId
                                            .toString();
                                    permDistrictCtrl.text =
                                        registerAddressController
                                            .permdistrict[0].districtName;
                                  } else {
                                    permDistrictIDCtrl.text = "";
                                    permDistrictCtrl.text = "";
                                  }

                                  /*  if (registerAddressController
                                      .permdistrict.isNotEmpty) {
                                    await registerAddressController
                                        .fetchPermTaluk(
                                            districtName:
                                                registerAddressController
                                                    .permdistrict[0]
                                                    .districtName);
                                  } */
                                },
                              ),
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: Obx(
                              () => SearchableDropdown(
                                labelText: 'District',
                                valueController: permDistrictIDCtrl,
                                valueTextController: permDistrictCtrl,
                                validator: (val) {
                                  if (val != null && val.isEmpty) {
                                    return 'Required';
                                  } else {
                                    return null;
                                  }
                                },
                                /*  parentOnChangeCall: () async {
                                  permTalukIDCtrl.clear();
                                  permTalukCtrl.clear();
                                  registerAddressController.permtaluk.clear();

                                  if (registerAddressController
                                      .permdistrict.isNotEmpty) {
                                    await registerAddressController
                                        .fetchPermTaluk(
                                            districtName:
                                                permDistrictCtrl.text);
                                  }
                                }, */
                                items: List.generate(
                                  registerAddressController.permdistrict.length,
                                  (index) => SingleSelectDropDownModel(
                                      registerAddressController
                                          .permdistrict[index].districtName,
                                      registerAddressController
                                          .permdistrict[index].districtId
                                          .toString()),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Taluk",
                              controller: permTalukCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                          const Spacer(
                            flex: 5,
                          ),
                          Expanded(
                            flex: 50,
                            child: CustomTextField(
                              labelText: "Pincode",
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(6),
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              controller: permPinCodeCtrl,
                              validator: (val) {
                                if (val != null && val.isEmpty) {
                                  return 'Required';
                                } else {
                                  return null;
                                }
                              },
                            ),
                          ),
                        ],
                      ),

                      SizedBox(
                        height: 30.w,
                      ),
                      // previous & next button
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 150.w,
                            child: OutButton(
                              onTap: () {
                                navigateIndex(0);
                              },
                              text: 'Previous',
                              color: AppColor.secondaryColor,
                              withArrow: true,
                            ),
                          ),
                          SizedBox(
                            width: 20.w,
                          ),
                          SizedBox(
                            width: 150.w,
                            child: InButton(
                              color: AppColor.primaryColor,
                              withArrow: true,
                              onTap: () {
                                if ((communicationValidForm.currentState!
                                        .validate()) &&
                                    (permValidForm.currentState!.validate())) {
                                  navigateIndex(2);
                                }
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 30.w,
                      ),
                    ],
                  );
                }),
              ),
            ],
          ),
        ),
      );
    });
  }

  // confirm details tab
  Widget confirmDetails() {
    return StatefulBuilder(builder: (context, confirmDetailsState) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Form(
            key: studentDetailsForm,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomText(
                  text: 'Student Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 30.w,
                ),
                // profile picture
                Center(
                  child: InkWell(
                      onTap: () async {},
                      child: selectedImage == null
                          ? Stack(
                              children: [
                                Image.asset(
                                  AssetPath.uploadProfile,
                                  scale: 4,
                                ),
                              ],
                            )
                          : Stack(
                              children: [
                                ClipOval(
                                  child: Image.file(
                                    selectedImage!,
                                    width: 130.w,
                                    height: 130.w,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ],
                            )),
                ),
                SizedBox(
                  height: 10.w,
                ),
                // profile picture
                Center(
                  child: CustomText(
                    text: nameCtrl.text,
                    fontSize: 14.sp,
                    color: AppColor.blackColor,
                    fontWeight: FontWeight.w500,
                    maxLines: 2,
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.gender,
                              title: 'Gender',
                              subTitle: genderCtrl.text,
                            ),
                          ),
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.calender,
                              title: 'Date of Birth',
                              subTitle: dobCtrl.text,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.mobile,
                              title: 'Mobile',
                              subTitle: '+91 ${mobileCtrl.text}',
                            ),
                          ),
                          if (altMobCtrl.text.isNotEmpty)
                            Expanded(
                              flex: 50,
                              child: CentreListTile(
                                assetName: AssetPath.mobile,
                                title: 'Alternate Mobile',
                                subTitle: '+91 ${altMobCtrl.text}',
                              ),
                            ),
                        ],
                      ),
                      /*   SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.mail,
                        title: 'Email ID',
                        subTitle: emailCtrl.text,
                      ), */
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.qualification,
                        title: 'Qualification',
                        subTitle: qualificationCtrl.text,
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.person,
                              title: 'Father Name',
                              subTitle: parentNameCtrl.text,
                            ),
                          ),
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.occupation,
                              title: 'Occupation',
                              subTitle: occupationCtrl.text,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Address Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      CentreListTile(
                        assetName: AssetPath.location,
                        title: 'Communication Address',
                        subTitle:
                            '${comAddress1Ctrl.text} ${comAddress2Ctrl.text}\n${comAreaCtrl.text}\n${comDistrictCtrl.text} ${comStateCtrl.text}\n${comCountryCtrl.text}-${comPinCodeCtrl.text}',
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.location,
                        title: 'Permanent Address',
                        subTitle:
                            '${permAddress1Ctrl.text} ${permAddress2Ctrl.text}\n${permAreaCtrl.text}\n${permDistrictCtrl.text} ${permStateCtrl.text}\n${permCountryCtrl.text}-${permPinCodeCtrl.text}',
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Course Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 20.w,
                          ),
                          SizedBox(
                            width: 15.w,
                          ),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomText(
                                  text: widget.courseDetail.course,
                                  fontSize: 14.sp,
                                  color: AppColor.blackColor,
                                  maxLines: 1,
                                  fontWeight: FontWeight.w500,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Wrap(
                                  children: [
                                    BulletText(
                                        text: widget.courseDetail.shortName),
                                    BulletText(
                                        text: widget.courseDetail.duration),
                                    BulletText(
                                        text:
                                            "${widget.courseDetail.totalSemesters} ${widget.courseDetail.totalSemesters == 1 ? "Semester" : "Semesters"}"),
                                    BulletText(
                                        text: widget.courseDetail.eligibility),
                                  ],
                                ),
                                /* CustomText(
                                  text:
                                      "${widget.courseDetail.shortName} ⚫ ${widget.courseDetail.duration} ⚫ ${widget.courseDetail.totalSemesters}  ${widget.courseDetail.totalSemesters == 1 ? "Semester" : "Semesters"}",
                                  fontSize: 12.sp,
                                  color: AppColor.black3Color,
                                  maxLines: 2,
                                  fontWeight: FontWeight.w400,
                                  overflow: TextOverflow.ellipsis,
                                ), */
                              ],
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 15.w),
                            child: Align(
                              alignment: Alignment.topRight,
                              child: CustomText(
                                text: currencyFormat
                                    .format(widget.courseDetail.courseFees),
                                color: AppColor.secondaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                CustomText(
                  text: 'Center Details',
                  fontSize: 16.sp,
                  color: AppColor.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
                SizedBox(
                  height: 15.w,
                ),
                GreyContainerWidget(
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomText(
                            text: widget.centreDetail.franchiseeName,
                            fontSize: 14.sp,
                            color: AppColor.blackColor,
                            maxLines: 1,
                            fontWeight: FontWeight.w500,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                      const Divider(),
                      CentreListTile(
                        assetName: AssetPath.owner,
                        title: 'Name',
                        subTitle: widget.centreDetail.franchiseeName,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 50,
                            child: CentreListTile(
                              assetName: AssetPath.mobile,
                              title: 'Mobile',
                              subTitle: '+91 ${widget.centreDetail.phone}',
                            ),
                          ),
                          if (widget.centreDetail.alternatePhone.isNotEmpty)
                            Expanded(
                              flex: 50,
                              child: CentreListTile(
                                assetName: AssetPath.mobile,
                                title: 'Alternate Mobile',
                                subTitle:
                                    '+91${widget.centreDetail.alternatePhone}',
                              ),
                            ),
                        ],
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.mail, title: 'Email ID',
                        subTitle: widget.centreDetail.email, //  need mail id
                      ),
                      SizedBox(
                        height: 5.w,
                      ),
                      CentreListTile(
                        assetName: AssetPath.location,
                        title: 'Communication Address',
                        subTitle:
                            '${widget.centreDetail.address1} ${widget.centreDetail.address2}\n${widget.centreDetail.area}\n${widget.centreDetail.district} ${comStateCtrl.text}\n${widget.centreDetail.district}-${widget.centreDetail.pincode} ',
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 30.w,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 150.w,
                      child: OutButton(
                        onTap: () {
                          navigateIndex(1);
                        },
                        text: 'Back',
                        color: AppColor.secondaryColor,
                      ),
                    ),
                    SizedBox(
                      width: 20.w,
                    ),
                    SizedBox(
                      width: 150.w,
                      child: InButton(
                        color: AppColor.primaryColor,
                        text: 'Submit',
                        onTap: () async {
                          // variable to send documnt id's as list
                          String? imageID;

                          File file = File(selectedImage!.path);
                          debugPrint(file.path);
                          List<String> parts = file.path.split("/");

                          String fileName = parts.last;
                          debugPrint(fileName);
                          debugPrint('File name $fileName');
                          String extention =
                              file.path.split('.').last.toLowerCase();
                          debugPrint('Extention $extention');

                          // Convert the selected file as form data to send
                          dio.FormData formData = dio.FormData.fromMap({
                            "EntityName": "Profile",
                            "DocumentFile":
                                // file
                                await dio.MultipartFile.fromFile(
                              file.path,
                              filename: fileName,
                              contentType: media.MediaType(
                                extention.toLowerCase() == 'pdf'
                                    ? 'application'
                                    : 'image',
                                extention,
                              ),
                            )
                          });

                          debugPrint('Form data ${formData.boundary}');

                          // Open please wait loader
                          PleaseWaitLoader.openDialog();
                          // Calling Profile Upload Api
                          await registerController
                              .updateProfilePicture(formData: formData)
                              .then(
                            (value) async {
                              // Close please wait loader
                              PleaseWaitLoader.closeDialog();

                              if (value) {
                                imageID = registerController
                                    .latestUploadedDocument[0].documentId;
                              }
                            },
                          );

                          ///gapppp//
                          DateFormat inputFormat = DateFormat("dd-MM-yyyy");
                          DateTime parsedDate = inputFormat.parse(dobCtrl.text);

                          // Format the date into the desired format
                          DateFormat outputFormat = DateFormat("yyyy-MM-dd");
                          String outputDate = outputFormat.format(parsedDate);

                          final Map<String, dynamic> requestBody = {
                            "TenantBranchID":
                                widget.centreDetail.tenantBranchId,
                            "CourseID": widget.courseDetail.courseId,
                            "StudentName": nameCtrl.text,
                            "Gender": genderCtrl.text,
                            "DateOfBirth": outputDate,
                            "PhoneCode": mobileCodeCtrl.text,
                            "Phone": mobileCtrl.text,
                            if (altMobCtrl.text.isNotEmpty)
                              "AlternatePhoneCode": altMobCodeCtrl.text,
                            if (altMobCtrl.text.isNotEmpty)
                              "AlternatePhone": altMobCtrl.text,
                            // "Email": emailCtrl.text,
                            "Qualification": qualificationCtrl.text,
                            "GuardianType": registerController.relationValue ==
                                    null
                                ? ""
                                : registerController.relationValue!.minValue,
                            "GuardianName": parentNameCtrl.text,
                            "Occupation": occupationCtrl.text,
                            "ReasonToSelect": reasonCtrl.text,
                            "DocumentID": imageID,
                            "SMSOTPTransID":
                                registerController.requestedOTP[0].otpTransId,
                            "ReferBy": howKnowTCDSCtrl.text,
                            "Purpose": choiceCtrl.text,
                            "Address": [
                              {
                                "AddressType": "Communication Address",
                                "Address1": comAddress1Ctrl.text,
                                if (comAddress2Ctrl.text.isNotEmpty)
                                  "Address2": comAddress2Ctrl.text,
                                "Country": comCountryCtrl.text,
                                "State": comStateCtrl.text,
                                "District": comDistrictCtrl.text,
                                "Area": comAreaCtrl.text,
                                "Pincode": comPinCodeCtrl.text,
                                "Taluk": comTalukCtrl.text
                              },
                              {
                                "AddressType": "Permanent Address",
                                "Address1": permAddress1Ctrl.text,
                                if (permAddress2Ctrl.text.isNotEmpty)
                                  "Address2": permAddress2Ctrl.text,
                                "Country": permCountryCtrl.text,
                                "State": permStateCtrl.text,
                                "District": permDistrictCtrl.text,
                                "Area": permAreaCtrl.text,
                                "Pincode": comPinCodeCtrl.text,
                                "Taluk": permTalukCtrl.text
                              }
                            ]
                          };
                          // log(jsonEncode(requestBody));

                          bool value = await registerController.createUser(
                              body: requestBody);
                          debugPrint(value.toString());
                          if (value) {
                            Get.toNamed(Routes.registrationStatus);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30.w,
                ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // stepper widget
  Widget stepper({required int stepCount}) {
    return Row(
      children: [
        // show stepper widgets with some conditions to match stepper effect
        Flexible(
          child: StepperPattern(
            title: "Student Details",
            isActive: stepCount == 1,
            stepNumber: "1",
            leftDividerColor: null,
            rightDividerColor: stepCount > 1 ? AppColor.primaryColor : null,
            withLeftDivider: false,
          ),
        ),
        Flexible(
          child: StepperPattern(
            title: "Address Details",
            isActive: stepCount == 2,
            leftDividerColor: stepCount > 1 ? AppColor.primaryColor : null,
            rightDividerColor: stepCount > 2 ? AppColor.primaryColor : null,
            stepNumber: "2",
          ),
        ),
        Flexible(
          child: StepperPattern(
            title: "Confirmation",
            isActive: stepCount == 3,
            leftDividerColor: stepCount > 2 ? AppColor.primaryColor : null,
            rightDividerColor: null,
            stepNumber: "3",
            withRightDivider: false,
          ),
        ),
      ],
    );
  }
}
