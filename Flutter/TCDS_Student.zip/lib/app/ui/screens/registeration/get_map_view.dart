import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../models/registeration/centres.dart';
import '../../widgets/custom_text.dart';
import 'list_tile.dart';

class GetMapView extends StatefulWidget {
  final LatLng position;
  final CentreData centreDetail;
  const GetMapView(
      {super.key, required this.position, required this.centreDetail});

  @override
  State<GetMapView> createState() => _GetMapViewState();
}

class _GetMapViewState extends State<GetMapView> {
  late LatLng getUserPosition;

  Future<void> getMapData(context) async {
    var permission = await Permission.location.status;
    if (permission.isGranted) {
      final result = await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => GetMapView(
            position: getUserPosition,
            centreDetail: widget.centreDetail,
          ),
        ),
      );
      setState(() {
        getUserPosition = result;
      });

      markers.add(
        Marker(
          markerId: const MarkerId(''),
          position: LatLng(getUserPosition.latitude, getUserPosition.longitude),
        ),
      );
    } else {
      await Permission.location.request().isGranted;
    }
    if (!mounted) return;
    setState(() {});
  }

  Set<Marker> markers = {};
  bool isLocated = false;
  final Completer<GoogleMapController> mapController =
      Completer<GoogleMapController>();
  late LatLng markPosition;

  @override
  void initState() {
    markers.clear();
    markers.add(
      Marker(
        markerId: const MarkerId('User Location'),
        icon: BitmapDescriptor.defaultMarker,
        position: LatLng(widget.position.latitude, widget.position.longitude),
      ),
    );
    markPosition = widget.position;
    setState(() {});

    super.initState();
  }

  double height = 0;

  @override
  Widget build(BuildContext context) {
    if (height == 0) {
      height = MediaQuery.sizeOf(context).height;
    }
    // ignore: deprecated_member_use
    return WillPopScope(
      onWillPop: () {
        return Future.value(true);
      },
      child: Scaffold(
        extendBody: true,
        appBar: AppBar(
          backgroundColor: AppColor.whiteColor,
          leading: InkWell(
            splashColor: AppColor.black2Color,
            onTap: () {
              Get.back();
            },
            child: Icon(
              Icons.arrow_back_ios_new_outlined,
              size: 30.w,
            ),
          ),
          title: CustomText(
            text: "TCDS Computer Education",
            fontSize: 16.sp,
            color: AppColor.blackColor,
            fontWeight: FontWeight.w500,
            overflow: TextOverflow.ellipsis,
          ),
        ),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: GoogleMap(
                  markers: markers,
                  myLocationButtonEnabled: true,
                  myLocationEnabled: false,
                  buildingsEnabled: false,
                  cameraTargetBounds: CameraTargetBounds.unbounded,
                  onTap: (mark) async {
                    // markers.clear();
                    // Marker m = Marker(
                    //   markerId: const MarkerId('1'),
                    //   position: mark,
                    //   icon: BitmapDescriptor.defaultMarker,
                    // );
                    // markers.add(m);
                    // setState(() {
                    //   markPosition = mark;
                    // });
                  },
                  mapType: MapType.normal,
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      widget.position.latitude,
                      widget.position.longitude,
                    ),
                    zoom: 15.0,
                  ),
                  onMapCreated: (GoogleMapController gmController) async {
                    mapController.complete(gmController);
                    // if (widget.position == null) {
                    //   Position position = await Geolocator.getCurrentPosition();
                    //   final GoogleMapController controllerMap =
                    //       await mapController.future;
                    //   controllerMap.animateCamera(
                    //     CameraUpdate.newCameraPosition(
                    //       CameraPosition(
                    //         target:
                    //             LatLng(position.latitude, position.longitude),
                    //         zoom: 15.0,
                    //       ),
                    //     ),
                    //   );
                    //   markers.add(
                    //     Marker(
                    //       markerId: const MarkerId(''),
                    //       position: LatLng(
                    //         position.latitude,
                    //         position.longitude,
                    //       ),
                    //     ),
                    //   );
                    //   markPosition =
                    //       LatLng(position.latitude, position.longitude);
                    // }
                    setState(() {});
                  },
                ),
              ),
              Container(
                constraints: BoxConstraints(maxHeight: height * 0.5),
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CentreListTile(
                      assetName: AssetPath.location,
                      title: 'Communication Address',
                      subTitle:
                          '${widget.centreDetail.franchiseeName}\n${widget.centreDetail.address1} ${widget.centreDetail.address2}\n${widget.centreDetail.area}\n${widget.centreDetail.district},${widget.centreDetail.state}\n${widget.centreDetail.district}-${widget.centreDetail.pincode} ',
                    ),
                    CentreListTile(
                      assetName: AssetPath.mobile,
                      title: 'Mobile',
                      subTitle: '+91 ${widget.centreDetail.phone}',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
