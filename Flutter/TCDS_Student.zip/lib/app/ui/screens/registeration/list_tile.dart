import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart'; // For responsive screen size
import '../../../../constants/colors.dart';
import '../../widgets/custom_text.dart';

class CentreListTile extends StatelessWidget {
  final String assetName;
  final String title;
  final String subTitle;

  const CentreListTile(
      {super.key,
      required this.assetName,
      required this.title,
      required this.subTitle});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: ClipOval(
        child: Image.asset(
          assetName,
          height: 27.w,
          width: 27.w,
          fit: BoxFit.cover,
        ),
      ),
      title: CustomText(
        text: title,
        color: AppColor.titleColor,
        fontWeight: FontWeight.w400,
        overflow: TextOverflow.ellipsis,
        fontSize: 15.sp,
      ),
      subtitle: CustomText(
        text: subTitle,
        color: AppColor.subTitleColor,
        fontWeight: FontWeight.w500,
        // overflow: TextOverflow.ellipsis,
        fontSize: 15.sp,
      ),
    );
  }
}
