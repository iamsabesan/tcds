// import 'package:flutter/material.dart';
// import 'package:flutter_map/flutter_map.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:latlong2/latlong.dart';
// import 'package:location/location.dart';
//
// import '../../../../constants/asset_paths.dart';
// import '../../../../constants/colors.dart';
// import '../../../models/registeration/centres.dart';
// import '../../widgets/custom_text.dart';
// import 'list_tile.dart';
//
// class MapPage extends StatefulWidget {
//   final CentreData centreDetail;
//   const MapPage({super.key, required this.centreDetail});
//
//   @override
//   State<MapPage> createState() => _MapPageState();
// }
//
// class _MapPageState extends State<MapPage> {
//   MapController mapController = MapController();
//   Location location = Location();
//   bool _serviceEnabled = false;
//   PermissionStatus? _permissionGranted;
//   LocationData? _locationData;
//   LatLng _currentPosition = LatLng(13.056100, 80.256000); // Default position
//
//   @override
//   void initState() {
//     super.initState();
//     initLocation();
//   }
//
//   // Initialize the location service and get the initial position
//   Future<void> initLocation() async {
//     _serviceEnabled = await location.serviceEnabled();
//     if (!_serviceEnabled) {
//       _serviceEnabled = await location.requestService();
//       if (!_serviceEnabled) {
//         return;
//       }
//     }
//
//     _permissionGranted = await location.hasPermission();
//     if (_permissionGranted == PermissionStatus.denied) {
//       _permissionGranted = await location.requestPermission();
//       if (_permissionGranted != PermissionStatus.granted) {
//         return;
//       }
//     }
//
//     _locationData = await location.getLocation();
//     setState(() {
//       _currentPosition = LatLng(_locationData?.latitude ?? 0, _locationData?.longitude ?? 0);
//       log('Initial location: $_currentPosition');
//       mapController.move(_currentPosition, 16); // Move map to initial position
//     });
//
//     // Listen for location changes and update the position
//     location.onLocationChanged.listen((LocationData currentLocation) {
//       setState(() {
//         _currentPosition = LatLng(currentLocation.latitude ?? 0, currentLocation.longitude ?? 0);
//         log('Updated location: $_currentPosition');
//         mapController.move(_currentPosition, 16); // Move map to updated position
//       });
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColor.whiteColor,
//
//       appBar: AppBar(
//         backgroundColor: AppColor.whiteColor,
//         leading:  InkWell(
//                         splashColor: AppColor.black2Color,
//                         onTap: () {
//                           Get.back();
//                         },
//                         child: Icon(
//                           Icons.arrow_back_ios_new_outlined,
//                           size: 30.w,
//                         ),
//                       ),
//         title:  CustomText(
//                     text: "Map",
//                     fontSize: 16.sp,
//                     color: AppColor.blackColor,
//                     fontWeight: FontWeight.w500,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//       ),
//       body: Column(
//         children: [
//           Expanded(
//             flex: 70,
//             child: Stack(
//               children: [
//                 FlutterMap(
//                   mapController: mapController,
//                   options: MapOptions(
//                     initialZoom: 14,
//
//                   ),
//                   children: [
//                     TileLayer(
//                       urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
//                       userAgentPackageName: "com.example.tcds_student",
//                       subdomains: ['a', 'b', 'c'],
//                     ),
//                     MarkerLayer(
//                       markers: [
//                         Marker(
//                           point: _currentPosition,
//                           width: 40.0,
//                           height: 40.0,
//                           child: FlutterLogo(),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           Expanded(
//             flex: 25,
//             child: SizedBox(
//               child: Padding(
//                 padding:  EdgeInsets.symmetric(horizontal: 20.w),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     CentreListTile(assetName: AssetPath.location, title: 'Communication Address', subTitle: '${widget.centreDetail.address1} ${widget.centreDetail.address2}    \n ${widget.centreDetail.area} \n ${widget.centreDetail.district} ${widget.centreDetail.state} \n ${widget.centreDetail.district}-${widget.centreDetail.pincode} ',),
//
//                     CentreListTile(assetName: AssetPath.mobile, title: 'Mobile', subTitle: '+91 ${widget.centreDetail.phone}', ),
//
//                   ],
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
