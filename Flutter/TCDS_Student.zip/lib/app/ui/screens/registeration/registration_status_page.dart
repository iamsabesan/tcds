import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:tcds_student/app/controllers/registration_status_controller.dart';
import 'package:tcds_student/app/ui/widgets/bullet_text.dart';
import '../../../../constants/app_string.dart';
import '../../../../constants/asset_paths.dart';
import '../../../../constants/colors.dart';
import '../../../../constants/shared_pref.dart';
import '../../../routes/routes.dart';
import '../../widgets/custom_progress_indicator.dart';
import '../../widgets/custom_text.dart';
import '../../widgets/grey_container_widget.dart';
import '../../widgets/in_button.dart';
import 'list_tile.dart';

class RegistrationStatusPage extends StatefulWidget {
  const RegistrationStatusPage({super.key});

  @override
  State<RegistrationStatusPage> createState() => _RegistrationStatusPageState();
}

class _RegistrationStatusPageState extends State<RegistrationStatusPage> {
  // find register controller
  RegistrationStatusController registerStatusController =
      Get.find<RegistrationStatusController>();
  String approvalDate = "";

  NumberFormat currencyFormat =
      NumberFormat.currency(locale: "hi_IN", symbol: "₹", decimalDigits: 2);

  File? selectedImage;
  String pickedImage = "";
  @override
  void initState() {
    neccessaryAPICalls();
    super.initState();
  }

  // call api's that required to show this screen
  Future<void> neccessaryAPICalls() async {
    registerStatusController.centresScrLoader.value = true;
    await registerStatusController.studentDetail(
        studentEnquiryId: SharedPref.getString(AppStrings.studentEnquiryID));
    await registerStatusController.documentDownload(
        documentID: registerStatusController.stdntEnquiryDetail[0].documentId);
    if (registerStatusController.latestDownloadedDocument.isNotEmpty) {
      pickedImage =
          registerStatusController.latestDownloadedDocument[0].profileBase64;
    }
    // Parse the input string into a DateTime object
    DateTime dateTime = DateFormat("dd-MM-yyyy hh:mm:ss a")
        .parse(registerStatusController.stdntEnquiryDetail[0].requestedDate);

    // Format the DateTime object to just the date
    approvalDate = DateFormat("dd-MM-yyyy").format(dateTime);

    // Output the formatted date

    //SharedPref.getString(AppStrings.studentEnquiryID)
    // get country id of india
    registerStatusController.centresScrLoader.value = false;
    // later required api calls
    setState(() {});
  }

  // textediting controller
  TextEditingController stateTxtCtrl = TextEditingController();
  TextEditingController stateIDCtrl = TextEditingController();
  TextEditingController districtTxtCtrl = TextEditingController();
  TextEditingController districtIDCtrl = TextEditingController();
  TextEditingController talukTxtCtrl = TextEditingController();
  TextEditingController talukIDCtrl = TextEditingController();

  // form keys
  GlobalKey<FormState> studentDetailsForm = GlobalKey<FormState>();
  GlobalKey<FormState> registeredFormKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColor.whiteColor,
        elevation: 4,
        scrolledUnderElevation: 4,
        surfaceTintColor: AppColor.whiteColor,
        shadowColor: AppColor.black2Color,
        // titleSpacing: 0,
        title: Row(
          children: [
            Expanded(
              child: CustomText(
                text: "Student Registration",
                fontSize: 16.sp,
                color: AppColor.blackColor,
                maxLines: 1,
                fontWeight: FontWeight.w500,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (registerStatusController.stdntEnquiryDetail.isNotEmpty)
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Obx(
                    () => CustomText(
                      text: registerStatusController
                                  .stdntEnquiryDetail[0].status !=
                              "Registered"
                          ? registerStatusController
                              .stdntEnquiryDetail[0].status
                          : "",
                      fontSize: 12.sp,
                      color: registerStatusController
                                  .stdntEnquiryDetail[0].status ==
                              "Admission Pending"
                          ? AppColor.secondaryColor
                          : AppColor.red,
                      // maxLines: 1,
                      fontWeight: FontWeight.w500,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  CustomText(
                    text:
                        registerStatusController.stdntEnquiryDetail[0].status !=
                                "Registered"
                            ? approvalDate
                            : "",
                    fontSize: 12.sp,
                    color: AppColor.black3Color,
                    maxLines: 2,
                    fontWeight: FontWeight.w400,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            SizedBox(width: 10.w),
          ],
        ),
      ),
      body: Obx(
        () => registerStatusController.centresScrLoader.value
            ? const CustomProgressIndicator()
            : registerStatusController.stdntEnquiryDetail[0].status ==
                    "Registered"
                ? StatefulBuilder(builder: (context, confirmDetailsState) {
                    return Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: Form(
                          key: registeredFormKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const SizedBox(
                                height: 20,
                              ),
                              GreyContainerWidget(
                                child: Column(
                                  children: [
                                    Image.asset(
                                      AssetPath.tcdsLogo,
                                      scale: 5,
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),

                                    // login textfields
                                    Align(
                                      alignment: Alignment.center,
                                      child: CustomText(
                                        text: "Welcome Back !",
                                        fontSize: 25.sp,
                                        fontWeight: FontWeight.w500,
                                        color: AppColor.secondaryColor,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 20.w,
                                    ),
                                    CustomText(
                                      text:
                                          "Your login password is sent to your registered mobile number",
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w400,
                                      textAlign: TextAlign.center,
                                      color: AppColor.blackColor,
                                    ),
                                    SizedBox(
                                      height: 30.w,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          width: 150.w,
                                          child: InButton(
                                            color: AppColor.primaryColor,
                                            text: 'Login',
                                            onTap: () {
                                              SharedPref.putString(
                                                  AppStrings.studentEnquiryID,
                                                  "");
                                              Get.toNamed(Routes.logIn);
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 30.w,
                              ),
                              if (registerStatusController
                                  .stdntEnquiryDetail[0].isRejected)
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 150.w,
                                      child: InButton(
                                        color: AppColor.primaryColor,
                                        text: 'Login',
                                        onTap: () {
                                          Get.toNamed(Routes.logIn);
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              SizedBox(
                                height: 30.w,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  })
                : StatefulBuilder(builder: (context, confirmDetailsState) {
                    return Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.vertical,
                        child: Form(
                          key: studentDetailsForm,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              const SizedBox(
                                height: 20,
                              ),
                              if (registerStatusController
                                  .stdntEnquiryDetail[0].isRejected)
                                Row(
                                  children: [
                                    Expanded(
                                      child: GreyContainerWidget(
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            CustomText(
                                              text: "Reason",
                                              fontSize: 14.sp,
                                              color: AppColor.blackColor,
                                              maxLines: 1,
                                              fontWeight: FontWeight.w500,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            CustomText(
                                              text: registerStatusController
                                                  .stdntEnquiryDetail[0].reason,
                                              fontSize: 12.sp,
                                              color: AppColor.black3Color,
                                              maxLines: 2,
                                              fontWeight: FontWeight.w400,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              if (registerStatusController
                                  .stdntEnquiryDetail[0].isRejected)
                                SizedBox(
                                  height: 30.w,
                                ),
                              CustomText(
                                text: 'Student Details',
                                fontSize: 16.sp,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                              SizedBox(
                                height: 20.w,
                              ),
                              // profile picture
                              Center(
                                child: InkWell(
                                    onTap: () async {},
                                    child: pickedImage == ""
                                        ? Stack(
                                            children: [
                                              Image.asset(
                                                AssetPath.uploadProfile,
                                                scale: 4,
                                              ),
                                            ],
                                          )
                                        : Stack(
                                            children: [
                                              ClipOval(
                                                child: Image.memory(
                                                  base64Decode(pickedImage),
                                                  height: 120.w,
                                                  width: 120.w,
                                                  fit: BoxFit.cover,
                                                  errorBuilder: (context, error,
                                                          stackTrace) =>
                                                      Image.asset(
                                                    AssetPath.defaultProfile,
                                                    height: 100.w,
                                                    width: 100.w,
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          )),
                              ),
                              SizedBox(
                                height: 20.w,
                              ),
                              // profile picture
                              Center(
                                child: CustomText(
                                  text: registerStatusController
                                      .stdntEnquiryDetail[0].studentName,
                                  fontSize: 14.sp,
                                  color: AppColor.blackColor,
                                  fontWeight: FontWeight.w500,
                                  maxLines: 2,
                                ),
                              ),
                              SizedBox(
                                height: 30.w,
                              ),
                              GreyContainerWidget(
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                            assetName: AssetPath.gender,
                                            title: 'Gender',
                                            subTitle: registerStatusController
                                                .stdntEnquiryDetail[0].gender,
                                          ),
                                        ),
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                            assetName: AssetPath.calender,
                                            title: 'Date of Birth',
                                            subTitle: registerStatusController
                                                .stdntEnquiryDetail[0]
                                                .dateOfBirth,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                              assetName: AssetPath.mobile,
                                              title: 'Mobile',
                                              subTitle:
                                                  "${registerStatusController.stdntEnquiryDetail[0].phoneCode} ${registerStatusController.stdntEnquiryDetail[0].phone}" //'+91 ${mobileCtrl.text}',

                                              ),
                                        ),
                                        if (registerStatusController
                                            .stdntEnquiryDetail[0]
                                            .alternatePhone
                                            .isNotEmpty)
                                          Expanded(
                                            flex: 50,
                                            child: CentreListTile(
                                                assetName: AssetPath.mobile,
                                                title: 'Alternate Mobile',
                                                subTitle:
                                                    "${registerStatusController.stdntEnquiryDetail[0].alternatePhoneCode} ${registerStatusController.stdntEnquiryDetail[0].alternatePhone}" //'+91 ${mobileCtrl.text}',        //'+91 ${altMobCtrl.text}',

                                                ),
                                          ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    // CentreListTile(
                                    //     assetName: AssetPath.mail,
                                    //     title: 'Email ID',
                                    //     subTitle: registerStatusController
                                    //         .stdntEnquiryDetail[0]
                                    //         .email //emailCtrl.text,
                                    //     ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    CentreListTile(
                                        assetName: AssetPath.qualification,
                                        title: 'Qualification',
                                        subTitle: registerStatusController
                                            .stdntEnquiryDetail[0]
                                            .qualification //qualificationCtrl.text,
                                        ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                              assetName: AssetPath.person,
                                              title: 'Father Name',
                                              subTitle: registerStatusController
                                                  .stdntEnquiryDetail[0]
                                                  .guardianName // parentNameCtrl.text,

                                              ),
                                        ),
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                              assetName: AssetPath.occupation,
                                              title: 'Occupation',
                                              subTitle: registerStatusController
                                                  .stdntEnquiryDetail[0]
                                                  .occupation),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 30.w,
                              ),
                              CustomText(
                                text: 'Address Details',
                                fontSize: 16.sp,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                              SizedBox(
                                height: 15.w,
                              ),
                              GreyContainerWidget(
                                child: Column(
                                  children: [
                                    CentreListTile(
                                      assetName: AssetPath.location,
                                      title: 'Communication Address',
                                      subTitle:
                                          '${registerStatusController.stdntEnquiryDetail[0].address[0].address1} ${registerStatusController.stdntEnquiryDetail[0].address[0].address2}\n${registerStatusController.stdntEnquiryDetail[0].address[0].area}\n${registerStatusController.stdntEnquiryDetail[0].address[0].district} ${registerStatusController.stdntEnquiryDetail[0].address[0].state}\n${registerStatusController.stdntEnquiryDetail[0].address[0].country}-${registerStatusController.stdntEnquiryDetail[0].address[0].pincode}',
                                    ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.location,
                                      title: 'Permanent Address',
                                      subTitle:
                                          '${registerStatusController.stdntEnquiryDetail[0].address[1].address1} ${registerStatusController.stdntEnquiryDetail[0].address[1].address2}\n${registerStatusController.stdntEnquiryDetail[0].address[1].area}\n${registerStatusController.stdntEnquiryDetail[0].address[1].district} ${registerStatusController.stdntEnquiryDetail[0].address[1].state}\n${registerStatusController.stdntEnquiryDetail[0].address[1].country}-${registerStatusController.stdntEnquiryDetail[0].address[1].pincode}',
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 30.w,
                              ),
                              CustomText(
                                text: 'Course Details',
                                fontSize: 16.sp,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                              SizedBox(
                                height: 15.w,
                              ),
                              if (registerStatusController
                                  .stdntEnquiryDetail.isNotEmpty)
                                GreyContainerWidget(
                                  child: Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomText(
                                                  text: registerStatusController
                                                      .stdntEnquiryDetail[0]
                                                      .course,
                                                  fontSize: 14.sp,
                                                  color: AppColor.blackColor,
                                                  maxLines: 1,
                                                  fontWeight: FontWeight.w500,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Wrap(
                                                  children: [
                                                    BulletText(
                                                        text: registerStatusController
                                                            .stdntEnquiryDetail[
                                                                0]
                                                            .shortName),
                                                    BulletText(
                                                        text: registerStatusController
                                                            .stdntEnquiryDetail[
                                                                0]
                                                            .courseTypeName),
                                                    BulletText(
                                                        text:
                                                            "${registerStatusController.stdntEnquiryDetail[0].duration} ${registerStatusController.stdntEnquiryDetail[0].durationType}"),
                                                    BulletText(
                                                        text:
                                                            "${registerStatusController.stdntEnquiryDetail[0].totalSemesters} Semester(s)"),
                                                  ],
                                                ),
                                                /*  CustomText(
                                                text:
                                                    "⚫ ${registerStatusController.stdntEnquiryDetail[0].shortName}  ⚫ ${registerStatusController.stdntEnquiryDetail[0].courseTypeName} ⚫ ${registerStatusController.stdntEnquiryDetail[0].duration} ${registerStatusController.stdntEnquiryDetail[0].durationType}\n⚫ ${registerStatusController.stdntEnquiryDetail[0].totalSemesters} Semester(s)",
                                                fontSize: 12.sp,
                                                color: AppColor.black3Color,
                                                maxLines: 3,
                                                fontWeight: FontWeight.w400,
                                                overflow: TextOverflow.ellipsis,
                                              ), */
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsets.only(right: 15.w),
                                            child: Align(
                                              alignment: Alignment.topRight,
                                              child: CustomText(
                                                text: currencyFormat.format(
                                                    registerStatusController
                                                        .stdntEnquiryDetail[0]
                                                        .courseFees),
                                                color: AppColor.secondaryColor,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              SizedBox(
                                height: 30.w,
                              ),
                              CustomText(
                                text: 'Center Details',
                                fontSize: 16.sp,
                                color: AppColor.primaryColor,
                                fontWeight: FontWeight.w500,
                              ),
                              SizedBox(
                                height: 15.w,
                              ),
                              GreyContainerWidget(
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        CustomText(
                                          text: registerStatusController
                                              .stdntEnquiryDetail[0]
                                              .branchDetail
                                              .branchName,
                                          fontSize: 14.sp,
                                          color: AppColor.blackColor,
                                          maxLines: 1,
                                          fontWeight: FontWeight.w500,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                    ),
                                    const Divider(),
                                    CentreListTile(
                                      assetName: AssetPath.owner,
                                      title: 'Name',
                                      subTitle: registerStatusController
                                          .stdntEnquiryDetail[0]
                                          .branchDetail
                                          .contactName,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          flex: 50,
                                          child: CentreListTile(
                                            assetName: AssetPath.defaultProfile,
                                            title: 'Mobile',
                                            subTitle: registerStatusController
                                                .stdntEnquiryDetail[0]
                                                .branchDetail
                                                .phone,
                                          ),
                                        ),
                                        if (registerStatusController
                                            .stdntEnquiryDetail[0]
                                            .branchDetail
                                            .alternatePhone
                                            .isNotEmpty)
                                          Expanded(
                                            flex: 50,
                                            child: CentreListTile(
                                              assetName:
                                                  AssetPath.defaultProfile,
                                              title: 'Alternate Mobile',
                                              subTitle: registerStatusController
                                                  .stdntEnquiryDetail[0]
                                                  .branchDetail
                                                  .alternatePhone,
                                            ),
                                          ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.mail,
                                      title: 'Email ID',
                                      subTitle: registerStatusController
                                          .stdntEnquiryDetail[0]
                                          .branchDetail
                                          .email, //  need mail id
                                    ),
                                    SizedBox(
                                      height: 5.w,
                                    ),
                                    CentreListTile(
                                      assetName: AssetPath.location,
                                      title: 'Communication Address',
                                      subTitle:
                                          '${registerStatusController.stdntEnquiryDetail[0].branchDetail.address1} ${registerStatusController.stdntEnquiryDetail[0].branchDetail.address2}\n${registerStatusController.stdntEnquiryDetail[0].branchDetail.area}\n${registerStatusController.stdntEnquiryDetail[0].branchDetail.district}, ${registerStatusController.stdntEnquiryDetail[0].branchDetail.state}\n${registerStatusController.stdntEnquiryDetail[0].branchDetail.country}-${registerStatusController.stdntEnquiryDetail[0].branchDetail.pincode} ',
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 30.w,
                              ),
                              if (registerStatusController
                                  .stdntEnquiryDetail[0].isRejected)
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 150.w,
                                      child: InButton(
                                        color: AppColor.primaryColor,
                                        text: 'Re-apply',
                                        onTap: () {
                                          Get.toNamed(Routes.logIn);
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              SizedBox(
                                height: 30.w,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
      ),
    );
  }
}
