import 'package:flutter/material.dart';
import '../../../constants/colors.dart';
import 'custom_text.dart';

class BulletText extends StatelessWidget {
  final String text;
  final double fontSize;
  const BulletText({super.key, required this.text, this.fontSize = 12});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(
          Icons.circle,
          size: 10,
          color: AppColor.primaryColor,
        ),
        const SizedBox(width: 5.0),
        CustomText(
          text: text,
          fontSize: fontSize,
          fontWeight: FontWeight.w400,
          color: AppColor.blackColor,
        ),
        const SizedBox(width: 5.0),
      ],
    );
  }
}
