import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../controllers/dashboard_controller.dart';
import 'account_deletion_textfield.dart';
import 'custom_text.dart';
import 'custom_textfield.dart';
import 'in_button.dart';
import 'out_button.dart';

// Mobile Show Dialog

showAccountDeletionDialog({
  required BuildContext context,
  required DashboardController dashBoardController,
}) async {
  TextEditingController mobileCodeCtrl = TextEditingController();
  TextEditingController mobileCtrl = TextEditingController();

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  return await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        scrollable: true,
        backgroundColor: Colors.white,
        shadowColor: AppColor.black2Color,
        titlePadding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 20.w),
        elevation: 0,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 20.w,
        ),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.r)),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Expanded(
              child: Divider(
                endIndent: 15,
                indent: 4,
                color: AppColor.black2Color,
                thickness: 0.8,
              ),
            ),
            CustomText(
              text: 'TCDS Computer Education',
              color: AppColor.secondaryColor,
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
            const Expanded(
              child: Divider(
                endIndent: 4,
                indent: 15,
                color: AppColor.black2Color,
                thickness: 0.8,
              ),
            ),
          ],
        ),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomText(
                text:
                    'Enter your mobile number to submit account deletion request',
                color: AppColor.black2Color,
                fontWeight: FontWeight.w400,
                textAlign: TextAlign.center,
                fontSize: 14.sp,
              ),
              SizedBox(
                height: 25.w,
              ),
              AccountDeletionTextField(
                hintText: "",
                assetPath: AssetPath.mobile,
                controller: mobileCtrl,
                mobileCodecontroller: mobileCodeCtrl,
                assetColor: AppColor.secondaryColor,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Mobile Number is Required";
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 30.w,
              ),
            ],
          ),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          IntrinsicWidth(
            stepWidth: 35.w,
            child: InButton(
              color: AppColor.primaryColor,
              onTap: () async {
                if (formKey.currentState!.validate()) {
                  bool res = await dashBoardController.accountDeletionRequest();
                  if (res) {
                    Get.back();
                    showSuccessDialog(
                        context: Get.context!,
                        message:
                            'Your request for account deletion has been Successfully submitted');
                  }
                }
              },
              text: 'Submit',
            ),
          )
        ],
      );
    },
  );
}

// Successful Show Dialog
showSuccessDialog({
  required BuildContext context,
  required String message,
}) async {
  return await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: Colors.white,
        shadowColor: AppColor.black2Color,
        titlePadding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 20.w),
        elevation: 0,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 20.w,
        ),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.r)),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Expanded(
              child: Divider(
                endIndent: 15,
                indent: 4,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
            CustomText(
              text: 'TCDS Computer Education',
              color: AppColor.secondaryColor,
              fontSize: 15.sp,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
            const Expanded(
              child: Divider(
                endIndent: 4,
                indent: 15,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              Icons.check_circle,
              color: AppColor.greenColor,
              size: 90.w,
            ),
            SizedBox(
              height: 20.w,
            ),
            CustomText(
              text: message,
              color: AppColor.black2Color,
              fontWeight: FontWeight.w500,
              textAlign: TextAlign.center,
              fontSize: 15.sp,
            ),
            SizedBox(
              height: 60.w,
            ),
          ],
        ),
      );
    },
  );
}

// Request account deletion dialog

showInformationDialog({
  required BuildContext context,
  required String message,
}) async {
  return await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: Colors.white,
        shadowColor: AppColor.black2Color,
        titlePadding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 20.w),
        elevation: 0,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 10.w,
        ),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.r)),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Expanded(
              child: Divider(
                endIndent: 15,
                indent: 4,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
            CustomText(
              text: 'TCDS Computer Education',
              color: AppColor.secondaryColor,
              fontSize: 15.sp,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
            const Expanded(
              child: Divider(
                endIndent: 4,
                indent: 15,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              AssetPath.mail,
              scale: 1.00,
            ),
            SizedBox(
              height: 20.w,
            ),
            CustomText(
              text: message,
              color: AppColor.black2Color,
              fontWeight: FontWeight.w500,
              textAlign: TextAlign.center,
              fontSize: 15.sp,
            ),
            SizedBox(
              height: 50.w,
            ),
          ],
        ),
      );
    },
  );
}

// show confirmation dialog
showConfirmationDialog({
  required BuildContext context,
  required String message,
  String? outButtonText,
  void Function()? outButtonOnTap,
  String? inButtonText,
  void Function()? inButtonOnTap,
}) async {
  return await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        backgroundColor: Colors.white,
        shadowColor: AppColor.black2Color,
        titlePadding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 20.w),
        elevation: 0,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 10.w,
        ),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.r)),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Expanded(
              child: Divider(
                endIndent: 15,
                indent: 4,
                color: AppColor.black2Color,
                thickness: 0.8,
              ),
            ),
            CustomText(
              text: 'TCDS Computer Education',
              color: AppColor.secondaryColor,
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
            const Expanded(
              child: Divider(
                endIndent: 4,
                indent: 15,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              AssetPath.question,
              scale: 1.00,
            ),
            SizedBox(
              height: 20.w,
            ),
            CustomText(
              text: message,
              color: AppColor.black2Color,
              fontWeight: FontWeight.w500,
              textAlign: TextAlign.center,
              fontSize: 15.sp,
            ),
            SizedBox(
              height: 20.w,
            ),
          ],
        ),
        actionsAlignment: MainAxisAlignment.start,
        actions: [
          Row(
            children: [
              Expanded(
                flex: 45,
                child: OutButton(
                  text: outButtonText ?? 'No',
                  onTap: outButtonOnTap,
                  color: AppColor.primaryColor,
                ),
              ),
              const Spacer(
                flex: 10,
              ),
              Expanded(
                flex: 45,
                child: InButton(
                  text: inButtonText ?? 'Yes',
                  onTap: inButtonOnTap,
                  color: AppColor.primaryColor,
                ),
              ),
            ],
          )
        ],
      );
    },
  );
}

showDialogOnGettingReason({
  required BuildContext context,
  String? outButtonText,
  void Function()? outButtonOnTap,
  String? inButtonText,
  void Function()? inButtonOnTap,
}) async {
  TextEditingController notesCtrl = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  return await showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        scrollable: true,
        backgroundColor: Colors.white,
        shadowColor: AppColor.black2Color,
        titlePadding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 20.w),
        elevation: 0,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 20.w,
        ),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11.r)),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Expanded(
              child: Divider(
                endIndent: 15,
                indent: 4,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
            CustomText(
              text: 'Mall Net India',
              color: AppColor.secondaryColor,
              fontSize: 15.sp,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
            const Expanded(
              child: Divider(
                endIndent: 4,
                indent: 15,
                color: AppColor.black2Color,
                thickness: 0.5,
              ),
            ),
          ],
        ),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomText(
                text: 'Notes',
                color: AppColor.black2Color,
                fontWeight: FontWeight.w500,
                textAlign: TextAlign.center,
                fontSize: 15.sp,
              ),
              SizedBox(
                height: 5.w,
              ),
              CustomTextField(
                hintText: 'Enter the reason for changing your prime policy',
                hintStyle: TextStyle(color: AppColor.redColor, fontSize: 14.sp),
                labelText: '',
                maxLines: 4,
                controller: notesCtrl,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Please enter a reason for changing the policy';
                  }
                  return null;
                },
              ),
              SizedBox(
                height: 30.w,
              ),
            ],
          ),
        ),
        actionsAlignment: MainAxisAlignment.start,
        actions: [
          Row(
            children: [
              Expanded(
                flex: 45,
                child: OutButton(
                    text: outButtonText ?? 'Cancel',
                    onTap: () {
                      Get.back();
                    }),
              ),
              const Spacer(
                flex: 10,
              ),
              Expanded(
                flex: 45,
                child: InButton(
                  text: inButtonText ?? 'Submit',
                  // onTap: inButtonOnTap,
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      Get.back();
                      Future.delayed(
                        const Duration(milliseconds: 150),
                        () {
                          // Get.to(() => ChangePrimePolicyScreen(reason: notesCtrl.text));
                        },
                      );
                    }
                  },
                ),
                /* ElevatedButton(
                  child: Text("Submit"),
                  onPressed: () {
                    if (formKey.currentState?.validate() ?? true) {
                      Get.back();
                      Get.to(() => ChangePrimePolicyScreen(reason: notesCtrl.text));
                    }
                  },
                ),*/
              ),
            ],
          )
        ],
      );
    },
  );
}
