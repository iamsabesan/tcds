import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../../constants/app_string.dart';
import '../../../constants/asset_paths.dart';
import '../../../constants/colors.dart';
import '../../../constants/shared_pref.dart';
import '../../controllers/dashboard_controller.dart';
import '../../routes/routes.dart';
import 'common_dialogs.dart';
import 'custom_text.dart';
import 'drawer_tile.dart';

class CustomDrawer extends StatefulWidget {
  final int currentIndex;

  const CustomDrawer({
    super.key,
    required this.currentIndex,
  });

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  late int selectedIndex;
  DashboardController? dashBoardController;

  // Get stored profile image from SharedPreferences
  String? get storedProfileImage =>
      SharedPref.getString(AppStrings.profileImage);
  bool get hasStoredProfileImage =>
      storedProfileImage != null && storedProfileImage!.isNotEmpty;

  // is User logged in or in guest mode
  bool isUser = false;

  String profileName = '';
  String rollno = '';
  String mobile = '';

  @override
  void initState() {
    isUser = SharedPref.getBool(AppStrings.isLoggedIn);
    // Try to get DashboardController, but don't crash if it's not available
    try {
      dashBoardController = Get.find<DashboardController>();
    } catch (e) {
      dashBoardController = null;
      debugPrint("DashboardController not found: $e");
    }
    profileName = SharedPref.getString(AppStrings.profileName);
    rollno = SharedPref.getString(AppStrings.rollNo);
    mobile = SharedPref.getString(AppStrings.mobileWithCode);
    menuData = [
      {
        "text": 'Dashboard',
        "icon": AssetPath.dashboard,
        "path": Routes.dashBoard,
      },
      if (isUser)
        {
          "text": 'Course',
          "icon": AssetPath.courses,
          "path": Routes.courses,
        },
      {
        "text": 'Franchisee Rank',
        "icon": AssetPath.topCentres,
        "path": Routes.awards,
      },
    ];
    selectedIndex = widget.currentIndex;
    super.initState();
  }

  List<Map<String, dynamic>> menuData = [];

  // check empty and return '-'
  String checkEmpty(String val) {
    if (val.isEmpty) return '-';
    return val;
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppColor.whiteColor,
      child: Column(
        children: [
          // Drawer Header with Background Image
          Container(
            width: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  AssetPath.backgroundLogo,
                ), // Path to logo_with_background.png
                fit: BoxFit.fill,
              ),
            ),
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: 12.w,
              ),
              child: SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ClipOval(
                      // Priority: 1) Stored profile image from SharedPreferences
                      //          2) Current dashboard controller data
                      //          3) Default profile image
                      child: hasStoredProfileImage
                          ? Image.memory(
                              base64Decode(storedProfileImage!),
                              height: 65.w,
                              width: 65.w,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Image.asset(
                                AssetPath.defaultProfile,
                                height: 65.w,
                                width: 65.w,
                                fit: BoxFit.cover,
                              ),
                            )
                          : (dashBoardController != null &&
                                  dashBoardController!
                                      .personalInfoDetail.isNotEmpty &&
                                  dashBoardController!.personalInfoDetail[0]
                                      .studentImages.isNotEmpty &&
                                  dashBoardController!.personalInfoDetail[0]
                                          .studentImages[0].profileBase64 !=
                                      null)
                              ? Image.memory(
                                  base64Decode(dashBoardController!
                                      .personalInfoDetail[0]
                                      .studentImages[0]
                                      .profileBase64!),
                                  height: 65.w,
                                  width: 65.w,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      Image.asset(
                                    AssetPath.defaultProfile,
                                    height: 65.w,
                                    width: 65.w,
                                    fit: BoxFit.cover,
                                  ),
                                )
                              : Image.asset(
                                  AssetPath.defaultProfile,
                                  height: 50.w,
                                  width: 50.w,
                                  fit: BoxFit.cover,
                                ),
                    ),
                    SizedBox(
                      height: 10.w,
                    ),
                    InkWell(
                      // Show profile only if logged in as user
                      onTap: isUser
                          ? () {
                              Get.toNamed(Routes.myProfile);
                            }
                          : null,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: CustomText(
                                  text: checkEmpty(profileName),
                                  color: AppColor.whiteColor,
                                  fontSize: 20.sp,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              if (isUser)
                                Icon(
                                  Icons.arrow_forward_ios_outlined,
                                  color: AppColor.whiteColor,
                                  size: 16.sp,
                                )
                            ],
                          ),
                          if (rollno.isNotEmpty && isUser)
                            CustomText(
                              text: checkEmpty(rollno),
                              color: AppColor.whiteColor,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                            ),
                          if (rollno.isNotEmpty)
                            SizedBox(
                              height: 10.w,
                            ),
                          if (mobile.isNotEmpty && isUser)
                            CustomText(
                              text: checkEmpty(mobile),
                              color: AppColor.whiteColor,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                            ),
                          SizedBox(
                            height: 10.w,
                          ),
                        ],
                      ),
                    ), // Get.toNamed(Routes.centreList, arguments: {
                    //   "appBarTitle": "TCDS Centres & Courses"
                    // });
                  ],
                ),
              ),
            ),
          ),
          SizedBox(
            height: 15.w,
          ),
          // Drawer Items
          Expanded(
            child: Container(
              color: AppColor.whiteColor,
              child: Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      itemCount: menuData.length,
                      itemBuilder: (context, index) {
                        return DrawerTile(
                          selectedIndex: selectedIndex,
                          activeIndex: index,
                          title: menuData[index]['text'],
                          assetPath: menuData[index]['icon'],
                          onTap: () {
                            if (selectedIndex != index) {
                              setState(() {
                                selectedIndex = index;
                              });
                              // Navigate to the selected route
                              String path = menuData[index]['path'];
                              Get.offAllNamed(path, arguments: {
                                "canPop": false,
                              });
                            }
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),

          if (isUser)
            DrawerTile(
              selectedIndex: selectedIndex,
              activeIndex: menuData.length,
              // Unique index
              title: 'Delete Account',
              assetPath: AssetPath.delete,
              onTap: () {
                setState(() {
                  selectedIndex = menuData.length;
                });
                // Only show dialog if controller is available
                if (dashBoardController != null) {
                  showAccountDeletionDialog(
                      context: context,
                      dashBoardController: dashBoardController!);
                } else {
                  // Show alternative dialog or message when controller is not available
                  showInformationDialog(
                    context: context,
                    message:
                        'Dashboard data is not available. Please try again later.',
                  );
                }
              },
            ),

          // Logout
          DrawerTile(
            selectedIndex: selectedIndex,
            activeIndex: menuData.length + 1,
            // Unique index
            title: isUser ? 'Logout' : "Exit",
            assetPath: AssetPath.logout,
            onTap: () {
              setState(() {
                selectedIndex = menuData.length + 1;
              });
              showConfirmationDialog(
                context: context,
                message:
                    isUser ? 'Are you sure to Logout?' : 'Do you want to exit?',
                outButtonOnTap: () {
                  Get.back();
                },
                inButtonOnTap: () {
                  SharedPref.putBool(AppStrings.isLoggedIn, false);
                  // Clear stored profile image when logging out
                  SharedPref.remove(AppStrings.profileImage);
                  // Clear all stored values and navigate to login screen
                  // LocalStorage.clearAll();
                  Get.offAllNamed(Routes.logIn);
                },
              );
            },
          ),
          const SizedBox(
            height: 20,
          )
        ],
      ),
    );
  }
}
