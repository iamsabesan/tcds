import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../constants/colors.dart';

class CustomTextField extends StatefulWidget {
  final String labelText;
  final String? errorText;
  final TextEditingController controller;
  final List<TextInputFormatter>? inputFormatters;
  final bool obscureText;
  final String? Function(String?)? validator;
  final TextStyle? hintStyle;
  final TextStyle? labelStyle;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double? height;
  final void Function()? onTap;
  final bool readOnly;
  final int? maxLength;
  final String? counterText;
  final TextInputType? keyboardType;
  final bool autofocus;
  final int? maxLines;
  final String? hintText;
  final double? verticalPadding;
  final bool? enabled;
  final void Function(String)? onChanged;
  final FocusNode? focusNode;
  final void Function()? onEditingComplete;
  final void Function(String?)? onSaved;
  const CustomTextField({
    super.key,
    required this.labelText,
    required this.controller,
    this.validator,
    this.errorText,
    this.inputFormatters,
    this.obscureText = false,
    this.hintStyle,
    this.prefixIcon,
    this.suffixIcon,
    this.height,
    this.onTap,
    this.labelStyle,
    this.readOnly = false,
    this.maxLength,
    this.counterText,
    this.keyboardType,
    this.autofocus = false,
    this.maxLines = 1,
    this.hintText,
    this.verticalPadding,
    this.enabled = true,
    this.onChanged,
    this.focusNode,
    this.onEditingComplete,
    this.onSaved,
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      autovalidateMode: AutovalidateMode.onUserInteraction,
      focusNode: widget.focusNode,
      controller: widget.controller,
      enabled: widget.enabled,
      validator: widget.validator,
      readOnly: widget.readOnly,
      autofocus: widget.autofocus,
      keyboardType: widget.keyboardType,
      obscureText: widget.obscureText,
      maxLength: widget.maxLength,
      inputFormatters: widget.inputFormatters,
      onFieldSubmitted: (value) {},
      onTap: widget.onTap,
      maxLines: widget.maxLines,
      onEditingComplete: widget.onEditingComplete,
      onSaved: widget.onSaved,
      onChanged: widget.onChanged ??
          (val) {
            widget.validator;
          },
      style: TextStyle(
          color: AppColor.black2Color,
          fontSize: 14.sp,
          fontWeight: FontWeight.w500),
      decoration: InputDecoration(
        // constraints:
        //     BoxConstraints(maxHeight: widget.height ?? 55.w, minHeight: 50.w),
        hintText: widget.hintText,
        contentPadding: EdgeInsets.symmetric(
            horizontal: 15.w, vertical: widget.verticalPadding ?? 1.w),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        floatingLabelAlignment: FloatingLabelAlignment.start,
        counterText: widget.counterText,
        floatingLabelStyle: widget.labelStyle ??
            TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                color: AppColor.blackColor),
        labelText: widget.labelText,
        labelStyle: widget.labelStyle ??
            TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                color: AppColor.blackColor),
        errorText: widget.errorText,
        errorMaxLines: 3,
        errorStyle: TextStyle(
          fontSize: 12.sp,
          color: AppColor.redColor,
          fontWeight: FontWeight.w400,
        ),
        prefixIcon: widget.prefixIcon,
        // suffix: widget.suffixIcon,
        suffixIconConstraints: BoxConstraints(maxHeight: 30.w, minHeight: 20.w),
        suffixIcon: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10.w),
          child: widget.suffixIcon,
        ),
        hintStyle: widget.hintStyle ??
            TextStyle(
              color: AppColor.black2Color,
              fontSize: 12.sp,
              fontWeight: FontWeight.w400,
            ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
            width: 1.00,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: AppColor.secondaryColor),
          // borderSide: BorderSide(
          //   color: AppColor.grey2,
          //   width: 1.5,
          // ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        border: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
      ),
    );
  }
}
