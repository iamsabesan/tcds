import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import '../../../constants/colors.dart';

class DatePickerTextField extends StatefulWidget {
  final String labelText;
  final bool filled;
  final bool withLabelText;
  final String? errorText;
  final TextStyle? labelStyle;
  final DateTime? lastDate;
  final TextEditingController controller;
  final double? height;
  final double? fontSize;
  final double? verticalPadding;
  final bool withOnTap;
  final void Function()? parentOnTap;
  final void Function(String)? onChanged;
  final String? Function(String?)? validator;

  const DatePickerTextField({
    super.key,
    required this.controller,
    this.height,
    this.fontSize,
    this.verticalPadding,
    this.withOnTap = true,
    this.validator,
    required this.labelText,
    this.errorText,
    this.labelStyle,
    this.withLabelText = true,
    this.parentOnTap,
    this.onChanged,
    this.filled = false,
    this.lastDate,
  });

  @override
  State<DatePickerTextField> createState() => _DatePickerTextFieldState();
}

class _DatePickerTextFieldState extends State<DatePickerTextField> {
  DateTime selectedDate = DateTime.now();

  // date picker
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1880, 1),
      lastDate: widget.lastDate ?? DateTime.now(),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        widget.controller.text = DateFormat('dd-MM-yyyy').format(selectedDate);
      });
      // if Parent Set State is not null call it to refresh
      if (widget.parentOnTap != null) {
        // calling parent widget setState to reflect data that need to changed after date got selected
        widget.parentOnTap!();
      }
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      readOnly: true,
      validator: widget.validator,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      onTap: () => widget.withOnTap ? _selectDate(context) : null,
      onChanged: widget.onChanged,
      style: TextStyle(
          color: AppColor.black2Color,
          fontSize: 14.sp,
          fontWeight: FontWeight.w500),
      decoration: InputDecoration(
        // constraints:
        //     BoxConstraints(maxHeight: widget.height ?? 50.w, minHeight: 45.w),
        contentPadding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 1.w),

        errorText: widget.errorText,
        errorMaxLines: 3,
        errorStyle: TextStyle(
          fontSize: 12.sp,
          color: AppColor.redColor,
          fontWeight: FontWeight.w400,
        ),
        floatingLabelBehavior: FloatingLabelBehavior.always,
        floatingLabelAlignment: FloatingLabelAlignment.start,
        floatingLabelStyle: widget.labelStyle ??
            TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                color: AppColor.blackColor),
        labelText: widget.labelText,
        labelStyle: widget.labelStyle ??
            TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                color: AppColor.blackColor),
        fillColor: AppColor.grey,
        filled: widget.filled,
        suffixIcon: GestureDetector(
          onTap: () => widget.withOnTap ? _selectDate(context) : null,
          // child: Image.asset(AssetPath.calendarIcon),
          child: const Icon(
            Icons.calendar_month_rounded,
            color: AppColor.primaryColor,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
            width: 1.00,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: AppColor.secondaryColor),
          // borderSide: BorderSide(
          //   color: AppColor.grey2,
          //   width: 1.5,
          // ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        border: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
      ),
    );
  }
}
