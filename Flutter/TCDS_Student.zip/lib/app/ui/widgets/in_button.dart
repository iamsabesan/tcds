import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../constants/colors.dart';
import 'custom_text.dart';

class InButton extends StatelessWidget {
  final bool withArrow;
  final String? text;
  final Color? color;
  final double? vertPad;
  final double? horizPad;
  final void Function()? onTap;
  final double? textSize;
  final Color? textColor;
  const InButton(
      {super.key,
      this.withArrow = false,
      this.text,
      this.color,
      this.onTap,
      this.vertPad,
      this.horizPad,
      this.textSize,
      this.textColor});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(
            vertical: vertPad ?? 10.w, horizontal: horizPad ?? 20.w),
        decoration: BoxDecoration(
            color: color ?? AppColor.primaryColor,
            borderRadius: BorderRadius.circular(5.r),
            border: Border.all(color: color ?? AppColor.primaryColor)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomText(
              text: text ?? 'Next',
              color: textColor ?? AppColor.whiteColor,
              fontSize: textSize ?? 14.sp,
              fontWeight: FontWeight.w500,
            ),
            if (withArrow)
              SizedBox(
                width: 10.w,
              ),
            if (withArrow)
              Icon(
                Icons.arrow_forward_ios_outlined,
                color: AppColor.whiteColor,
                size: 15.w,
              ),
          ],
        ),
      ),
    );
  }
}
