import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../constants/colors.dart';
import 'custom_text.dart';

class OutButton extends StatelessWidget {
  final bool withArrow;
  final String? text;
  final Color? color;
  final void Function()? onTap;

  const OutButton({
    super.key,
    this.withArrow = false,
    this.text,
    this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10.w, horizontal: 20.w),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5.r),
            border: Border.all(color: color ?? AppColor.primaryColor)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (withArrow)
              Icon(
                Icons.arrow_back_ios_new_rounded,
                color: color ?? AppColor.primaryColor,
                size: 15.w,
              ),
            if (withArrow)
              SizedBox(
                width: 10.w,
              ),
            CustomText(
              text: text ?? 'Back',
              color: color ?? AppColor.primaryColor,
              fontSize: 12.sp,
              fontWeight: FontWeight.w500,
            )
          ],
        ),
      ),
    );
  }
}
