import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../../constants/colors.dart';
import '../../controllers/register_controller.dart';
import '../../models/common/phone_code.dart';

// ignore: must_be_immutable
class PhoneTextField extends StatefulWidget {
  final String labelText;
  final String? hintText;
  // String? errorText;
  final bool withLabelText;
  final bool? filled;
  final TextEditingController controller;
  final TextEditingController mobileCodecontroller;
  final bool obscureText;
  final bool withSuffixIcon;
  final String? Function(String?)? validator;
  final double? height;
  final bool autofocus;
  final void Function(String)? onFieldSubmitted;
  final double? assetScale;
  final TextStyle? hintStyle;
  final Color? fillColor;
  final String? errorText;
  final void Function(String?)? parentOnChanged;
  final bool withValidator;
  final void Function(String)? onChanged;

  const PhoneTextField({
    super.key,
    this.hintText,
    required this.controller,
    this.validator,
    // this.errorText,
    this.withSuffixIcon = false,
    this.obscureText = false,
    this.height,
    this.autofocus = false,
    this.onFieldSubmitted,
    this.assetScale,
    required this.mobileCodecontroller,
    this.withLabelText = false,
    this.filled,
    this.hintStyle,
    this.fillColor,
    this.errorText,
    this.parentOnChanged,
    this.withValidator = true,
    required this.labelText,
    this.onChanged,
  });

  @override
  State<PhoneTextField> createState() => _PhoneTextFieldState();
}

class _PhoneTextFieldState extends State<PhoneTextField> {
  // find RegisterController to get phone codes
  late RegisterController registerController;

  late bool obscureText;
  late FocusNode _focusNode;
  // Drop down value holder
  String? dropdownValue;
  // Default Length
  int phoneNumberLength = 10;
  String? errorText;

  @override
  void initState() {
    super.initState();
    initializeController();
    obscureText = widget.obscureText;
    _focusNode = FocusNode();
    _focusNode.addListener(_onFocusChange);
    if (widget.mobileCodecontroller.text.isNotEmpty) {
      dropdownValue = widget.mobileCodecontroller.text;
      try {
        PhoneCodeList codeData = registerController.phoneCodesData.firstWhere(
          (element) {
            return element.phoneCode == dropdownValue;
          },
        );
        phoneNumberLength = codeData.phoneNumberLength;
        widget.mobileCodecontroller.text = codeData.phoneCode;
      } catch (e) {
        debugPrint('Phone code not found: $dropdownValue');
      }
    } else {
      dropdownValue = '+91';
      widget.mobileCodecontroller.text = dropdownValue!;
    }
  }

  // initialize register controller
  void initializeController() {
    try {
      registerController = Get.find<RegisterController>();
    } catch (e) {
      registerController = Get.put(RegisterController());
    }
  }

  @override
  void dispose() {
    _focusNode.removeListener(_onFocusChange);
    _focusNode.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return TextFormField(
      focusNode: _focusNode,
      autofocus: widget.autofocus,
      textAlign: TextAlign.start,
      controller: widget.controller,
      style: TextStyle(
          color: AppColor.black2Color,
          fontSize: 14.sp,
          fontWeight: FontWeight.w500),
      // validator: widget.validator,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      onChanged: widget.onChanged,
      validator: widget.withValidator
          ? (value) {
              if (value!.isEmpty ||
                  value.length < phoneNumberLength ||
                  value.length > phoneNumberLength) {
                errorText = 'Required';
              } else {
                errorText = null;
              }
              return errorText;
            }
          : null,
      obscureText: obscureText,
      inputFormatters: [
        LengthLimitingTextInputFormatter(phoneNumberLength),
        FilteringTextInputFormatter.digitsOnly,
      ],
      onFieldSubmitted: widget.onFieldSubmitted,
      decoration: InputDecoration(
        floatingLabelBehavior: FloatingLabelBehavior.always,
        floatingLabelAlignment: FloatingLabelAlignment.start,
        floatingLabelStyle: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w500,
            color: AppColor.blackColor),
        labelText: widget.labelText,
        labelStyle: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w500,
            color: AppColor.blackColor),
        errorText: widget.errorText,
        errorMaxLines: 3,
        errorStyle: TextStyle(
          fontSize: 12.sp,
          color: AppColor.redColor,
          fontWeight: FontWeight.w400,
        ),
        prefixIcon: Obx(
          () => Container(
            padding: EdgeInsets.only(left: 10.w),
            constraints: BoxConstraints(
              maxWidth: screenWidth * 0.20,
            ),
            child: Center(
              child: DropdownButton<String>(
                value: dropdownValue,
                padding: const EdgeInsets.all(0),
                menuMaxHeight: screenHeight * 0.4,
                isExpanded: true,
                underline: const SizedBox(),
                dropdownColor: AppColor.whiteColor,
                isDense: true,
                alignment: Alignment.center,
                // iconSize: 0,
                style: TextStyle(
                    color: AppColor.black2Color,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500),
                onChanged: (String? newValue) {
                  setState(() {
                    dropdownValue = newValue ?? '+91';
                    widget.mobileCodecontroller.text = dropdownValue ?? '+91';
                    // Change phone number length according to the phone code
                    for (var element in registerController.phoneCodesData) {
                      if (element.phoneCode == dropdownValue) {
                        phoneNumberLength = element.phoneNumberLength;
                      }
                    }
                    debugPrint(dropdownValue);
                    debugPrint(phoneNumberLength.toString());
                  });
                },
                items: registerController.phoneCodesData
                    .map<DropdownMenuItem<String>>((PhoneCodeList value) {
                  return DropdownMenuItem<String>(
                    value: value.phoneCode,
                    alignment: Alignment.centerLeft,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Text(
                        value.phoneCode,
                        style: TextStyle(
                          color: AppColor.black2Color,
                          fontWeight: FontWeight.w500,
                          fontSize: 14.sp,
                        ),
                      ),
                    ),
                  );
                }).toList(),

                icon: Icon(
                  Icons.keyboard_arrow_down_sharp,
                  size: 25.w,
                ),
                // icon: const SizedBox.shrink(),
              ),
            ),
          ),
        ),
        contentPadding: EdgeInsets.only(
          left: 10.w,
          right: 10.w,
          bottom: 0.w,
          top: 10.w,
        ),
        fillColor: AppColor.grey,
        filled: widget.filled,
        hintStyle: widget.hintStyle ??
            TextStyle(
              color: AppColor.black2Color,
              fontSize: 12.sp,
              fontWeight: FontWeight.w400,
            ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
            width: 1.00,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: AppColor.secondaryColor),
          // borderSide: BorderSide(
          //   color: AppColor.grey2,
          //   width: 1.5,
          // ),
          borderRadius: BorderRadius.circular(6.r),
        ),
        border: OutlineInputBorder(
          borderSide: const BorderSide(
            color: AppColor.grey,
          ),
          borderRadius: BorderRadius.circular(6.r),
        ),
      ),
    );
  }
}
