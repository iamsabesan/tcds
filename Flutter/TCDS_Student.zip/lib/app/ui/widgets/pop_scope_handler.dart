import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:tcds_student/utils/helper_functions/will_pop_confirm_exit.dart';

enum BackBehavior {
  normalPop,
  exitOnDoubleBack,
}

// USAGE : A Common widget that is used to wrap screens to prevent unexpected exit
class PopScopeHandler extends StatefulWidget {
  final Widget child;
  final BackBehavior behavior;

  const PopScopeHandler({
    super.key,
    required this.child,
    this.behavior = BackBehavior.exitOnDoubleBack,
  });

  @override
  State<PopScopeHandler> createState() => _PopScopeHandlerState();
}

class _PopScopeHandlerState extends State<PopScopeHandler> {
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: widget.behavior == BackBehavior.normalPop,
      onPopInvokedWithResult: (didPop, result) {
        debugPrint(widget.behavior == BackBehavior.normalPop
            ? "normalPop"
            : "exitOnDoubleBack");
        if (didPop) return;

        if (widget.behavior == BackBehavior.exitOnDoubleBack) {
          ConfirmExit.onPopScope().then((value) {
            if (value) {
              // Close the app when user presses back twice
              SystemNavigator.pop();
            }
          });
        }
      },
      child: widget.child,
    );
  }
}
