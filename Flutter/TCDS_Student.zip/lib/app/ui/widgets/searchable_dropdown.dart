import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../constants/colors.dart';
import 'single_dropdown.dart';

/// this widget is used when you want to use a custom searchable dropdown
/// it uses a custom model SingleSelectDropDownModel
/// it has a parentOnChangeCall that is used to call setState of parent widget
/// it has valueController that stores id and valueTextController that stores the visible text
class SearchableDropdown extends StatefulWidget {
  final String labelText;
  final bool withLabelText;
  final bool filled;
  final void Function(String?)? onChange;
  final TextEditingController valueController;
  final TextEditingController valueTextController;
  final String? errorText;
  final String? Function(String?)? validator;
  final TextStyle? hintStyle;
  final TextStyle? labelStyle;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final double? height;
  final void Function()? onTap;
  final bool readOnly;
  final int? maxLength;
  final String? counterText;
  final TextInputType? keyboardType;
  final int? maxLines;
  final String? hintText;
  final bool enabled;
  final void Function()? parentOnChangeCall;
  final bool withValidation;
  final List<SingleSelectDropDownModel> items;

  const SearchableDropdown({
    super.key,
    required this.labelText,
    this.errorText,
    this.validator,
    this.onChange,
    this.hintStyle,
    this.labelStyle,
    this.prefixIcon,
    this.suffixIcon,
    this.height,
    this.onTap,
    this.readOnly = false,
    this.maxLength,
    this.counterText,
    this.keyboardType,
    this.maxLines,
    this.hintText,
    required this.valueController,
    required this.valueTextController,
    this.enabled = true,
    this.parentOnChangeCall,
    this.withValidation = true,
    this.withLabelText = true,
    this.filled = true,
    required this.items,
  });

  @override
  State<SearchableDropdown> createState() => _SearchableDropdownState();
}

class _SearchableDropdownState extends State<SearchableDropdown> {
  /// Using [OverlayPortalController] to place menu items as Layer
  final OverlayPortalController _overlayCtrlr = OverlayPortalController();

  /// [LayerLink] which is an helper to place DD childs beneath DD
  final _link = LayerLink();

  /// with [GlobalKey] we get the size of button
  final GlobalKey _buttonKey = GlobalKey();
  double? _generalWidth;

  // Dropdown's open close state identifier
  bool visibleState = false;

  // show items
  List<SingleSelectDropDownModel> filteredItems = [];

  // Data holder
  SingleSelectDropDownModel? valueText;

  final FocusNode _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    debugPrint("Init - ${widget.valueController.text}");
    debugPrint("Init - ${widget.valueTextController.text}");

    _focusNode.addListener(() {
      if (!_focusNode.hasFocus && _overlayCtrlr.isShowing) {
        setState(() {
          visibleState = false;
          FocusScope.of(context).unfocus();
        });
        _overlayCtrlr.hide();
      }
    });

    filteredItems = widget.items;
    // Initial data assign logic if any controller is not empty
    if ((widget.valueTextController.text).isNotEmpty &&
        widget.valueController.text.isNotEmpty) {
      valueText = SingleSelectDropDownModel(
        widget.valueTextController.text,
        widget.valueController.text,
      );
    } else {
      final text = widget.valueTextController.text;
      if (text.isNotEmpty) {
        valueText = widget.items.firstWhere(
          (e) => e.value == text,
          orElse: () => widget.items.first,
        );
      } else {
        valueText = widget.items.isNotEmpty ? widget.items.first : null;
      }

      widget.valueTextController.text = valueText?.value ?? '';
      widget.valueController.text = valueText?.valueID ?? '';
      debugPrint("Init end - ${widget.valueController.text}");
      debugPrint("Init end - ${widget.valueTextController.text}");
    }
  }

  @override
  void didUpdateWidget(covariant SearchableDropdown oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Since we initialize [filteredItems] once in Init,whenever we change the items list it will does not reflect
    // when items changed let's assign it to [filteredItems]
    if (widget.items != oldWidget.items ||
        widget.valueTextController.text != oldWidget.valueTextController.text ||
        widget.valueController.text != oldWidget.valueController.text) {
      setState(() {
        filteredItems = widget.items;
        // Initial data assign logic if any controller is not empty
        if (filteredItems.isNotEmpty &&
            (widget.valueTextController.text).isNotEmpty &&
            widget.valueController.text.isNotEmpty) {
          valueText = SingleSelectDropDownModel(
            widget.valueTextController.text,
            widget.valueController.text,
          );
        } else {
          // Assign initial value
          valueText = widget.items.isNotEmpty ? widget.items.first : null;
          if (valueText != null) {
            widget.valueTextController.text = valueText?.value ?? '';
            widget.valueController.text = valueText?.valueID ?? '';
          }
        }
      });
    }
  }

  @override
  void dispose() {
    debugPrint('*SearchableDropdown disposed');
    _focusNode.dispose();
    filteredItems.clear();

    super.dispose();
  }

  // Icon- OnTap logic
  void onTap() {
    if (!mounted) return;
    setState(() => visibleState = !visibleState);
    _overlayCtrlr.toggle();

    final box = _buttonKey.currentContext?.findRenderObject();
    if (box is RenderBox) {
      _generalWidth = box.size.width;
    }
  }

  // TextField type On Submit actions
  void submitOnTap(String? val) {
    setState(() {
      if (_overlayCtrlr.isShowing) {
        final matched = widget.items.firstWhere(
          (e) => e.value == val,
          orElse: () =>
              filteredItems.isNotEmpty ? filteredItems[0] : widget.items.first,
        );

        widget.valueTextController.text = matched.value;
        widget.valueController.text = matched.valueID;
        valueText = matched;

        widget.parentOnChangeCall?.call();
        _overlayCtrlr.toggle();
      } else {
        widget.valueTextController.text = "";
      }

      visibleState = false;
      filteredItems = widget.items;
    });
  }

  // actions while type in textfield
  void Function(String)? onChanged(String? val) {
    if (!mounted) return null;

    if (!_overlayCtrlr.isShowing) {
      _overlayCtrlr.show();
      visibleState = true;
    }

    final query = val?.toLowerCase();
    final newFiltered = (query == null || query.isEmpty)
        ? widget.items
        : widget.items
            .where((item) => item.value.toLowerCase().contains(query))
            .toList();

    if (filteredItems != newFiltered) {
      setState(() => filteredItems = newFiltered);
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _link,
      child: OverlayPortal(
        controller: _overlayCtrlr,
        overlayChildBuilder: (context) {
          return GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () {
              // Close dropdown when tapping outside
              _overlayCtrlr.hide();
              setState(() => visibleState = false);
              FocusScope.of(context).unfocus();
            },
            child: CompositedTransformFollower(
              link: _link,
              targetAnchor: Alignment.bottomLeft,
              child: Align(
                alignment: AlignmentDirectional.topStart,
                child: MenuWidget(
                  items: filteredItems,
                  width: _generalWidth,
                  onItemSelected: (value) {
                    // allow if new value
                    if (widget.valueTextController.text != value.value) {
                      FocusScope.of(context).unfocus();
                      widget.valueTextController.text = value.value;
                      widget.valueController.text = value.valueID;
                      valueText = value;
                      _overlayCtrlr.hide();
                      setState(() => visibleState = false);
                      widget.parentOnChangeCall?.call();
                    }
                  },
                ),
              ),
            ),
          );
        },
        child: SizedBox(
          width: _generalWidth,
          child: TextFormField(
            focusNode: _focusNode,
            key: _buttonKey,
            controller: widget.valueTextController,
            autofocus: false,
            keyboardType: TextInputType.text,
            onFieldSubmitted: submitOnTap,
            onChanged: onChanged,
            readOnly: widget.readOnly,
            textAlignVertical: TextAlignVertical.center,
            style: TextStyle(
              color: AppColor.blackColor,
              fontSize: 14.sp,
              fontWeight: FontWeight.w500,
            ),
            validator: widget.withValidation
                ? (val) => (val == null || val.isEmpty) ? 'Required' : null
                : null,
            decoration: InputDecoration(
              contentPadding: const EdgeInsets.all(10),
              enabled: widget.enabled,
              labelText: widget.labelText,
              labelStyle: widget.labelStyle ??
                  const TextStyle(color: AppColor.blackColor),
              hintText: widget.hintText,
              counterText: widget.counterText,
              errorText: widget.errorText,
              errorMaxLines: 3,
              errorStyle: TextStyle(
                fontSize: 12.sp,
                color: AppColor.redColor,
                fontWeight: FontWeight.w400,
              ),
              suffixIcon: InkWell(
                onTap: onTap,
                borderRadius: BorderRadius.circular(10),
                overlayColor: WidgetStatePropertyAll(Colors.pink[100]),
                child: AnimatedRotation(
                  turns: visibleState ? 0.5 : 0.0,
                  duration: const Duration(milliseconds: 200),
                  child: const Icon(Icons.arrow_drop_down_rounded,
                      color: Colors.black54, size: 30),
                ),
              ),
              hintStyle: widget.hintStyle ??
                  TextStyle(
                    color: AppColor.black2Color,
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w400,
                  ),
              fillColor: AppColor.whiteColor,
              filled: widget.filled,
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: Colors.black.withValues(alpha: 0.1),
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(8.r),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: AppColor.primaryColor),
                borderRadius: BorderRadius.circular(12.r),
              ),
              border: OutlineInputBorder(
                borderSide: const BorderSide(color: AppColor.grey2),
                borderRadius: BorderRadius.circular(12.r),
              ),
              isDense: true,
            ),
          ),
        ),
      ),
    );
  }
}

class MenuWidget extends StatelessWidget {
  final double? width;
  final double? height;
  final List<SingleSelectDropDownModel> items;
  final ValueChanged<SingleSelectDropDownModel>? onItemSelected;

  const MenuWidget({
    super.key,
    this.width,
    this.height,
    required this.items,
    this.onItemSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: 5),
      constraints: BoxConstraints(maxHeight: height ?? 200),
      child: Material(
        child: Ink(
          width: width ?? double.infinity,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              side: const BorderSide(width: 1.5, color: Colors.black26),
              borderRadius: BorderRadius.circular(12),
            ),
            shadows: const [
              BoxShadow(
                color: Colors.grey,
                blurRadius: 20,
                offset: Offset(0, 15),
                spreadRadius: -20,
              ),
            ],
          ),
          child: items.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text("No items found."),
                )
              : ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    return InkWell(
                      overlayColor: const WidgetStatePropertyAll(Colors.grey),
                      onTap: () => onItemSelected?.call(item),
                      child: Container(
                        alignment: Alignment.centerLeft,
                        padding: const EdgeInsets.all(10),
                        child: Text(item.value),
                      ),
                    );
                  },
                ),
        ),
      ),
    );
  }
}
