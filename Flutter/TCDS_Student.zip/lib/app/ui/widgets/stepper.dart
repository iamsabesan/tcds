import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../../constants/colors.dart';
import 'custom_text.dart';

class StepperPattern extends StatelessWidget {
  final bool isActive;
  final String stepNumber;
  final String title;
  final bool withLeftDivider;
  final bool withRightDivider;
  final Color? leftDividerColor;
  final Color? rightDividerColor;
  const StepperPattern(
      {super.key,
      required this.isActive,
      required this.stepNumber,
      this.withLeftDivider = true,
      this.withRightDivider = true,
      required this.title,
      this.leftDividerColor,
      this.rightDividerColor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CustomText(
          text: title,
          color: isActive ? AppColor.secondaryColor : AppColor.black3Color,
          fontWeight: isActive ? FontWeight.w500 : FontWeight.w400,
        ),
        SizedBox(
          height: 10.w,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            withLeftDivider
                ? Flexible(
                    child: Divider(
                      color: leftDividerColor ?? AppColor.grey,
                      thickness: 2,
                      endIndent: 10,
                    ),
                  )
                : const Flexible(
                    child: Divider(
                      color: Colors.transparent,
                      thickness: 2,
                      endIndent: 10,
                    ),
                  ),
            isActive
                ? Stack(
                    alignment: Alignment.center,
                    children: [
                      // Outer Circle (Ring)
                      Container(
                        height: 45.w,
                        width: 45.w,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColor.primaryColor,
                            width: 2.0,
                          ),
                        ),
                      ),
                      // Space Circle
                      Container(
                        height: 40.w,
                        width: 40.w,
                        decoration: const BoxDecoration(
                          color: Colors.transparent,
                          shape: BoxShape.circle,
                        ),
                      ),
                      // Inner Circle
                      Container(
                        height: 35.w,
                        width: 35.w,
                        decoration: const BoxDecoration(
                          color: AppColor.primaryColor,
                          shape: BoxShape.circle,
                        ),
                        child: Center(
                          child: CustomText(
                            text: stepNumber,
                            fontWeight: FontWeight.w500,
                            color: AppColor.whiteColor,
                            fontSize: 16.sp,
                          ),
                        ),
                      ),
                    ],
                  )
                : Container(
                    height: 35.w,
                    width: 35.w,
                    decoration: const BoxDecoration(
                      color: AppColor.grey2,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: CustomText(
                        text: stepNumber,
                        fontWeight: FontWeight.w500,
                        color: AppColor.black2Color,
                        fontSize: 16.sp,
                      ),
                    ),
                  ),
            withRightDivider
                ? Flexible(
                    child: Divider(
                      color: rightDividerColor ?? AppColor.grey,
                      thickness: 2,
                      indent: 10,
                    ),
                  )
                : const Flexible(
                    child: Divider(
                      color: Colors.transparent,
                      thickness: 2,
                    ),
                  ),
          ],
        )
      ],
    );
  }
}
