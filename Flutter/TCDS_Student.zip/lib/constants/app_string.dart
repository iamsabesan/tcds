class AppStrings {
  // App Basic Constants
  static const String appName = "TCDS";
  // static String baseUrl = "http://gateway.dawn.dt/"; // debug URL
  //   static const String baseUrl = "http://192.168.1.10:8084/"; // debug URL
  static const String baseUrl =
      "https://gateway.boxoftech.int.in/"; // release URL
  static const String gatewayUrl = "";
  static const String databaseName = "TCDS";
  static const String contentType = "content-type";
  static const String contentTypeValue = "application/json";
  static const String guestToken = "GuestToken";
  static const String guestRefreshToken = "GuestRefreshToken";
  static const String refreshTokenValue = "RefreshTokenValue";
  static const String success = 'success';
  static const String failure = 'failure';
  static const String accessToken = 'accessToken';
  static const String refreshToken = "refreshToken";
  static const String otpTransactionId = "otpTransactionId";
  static const String otpValidTime = "otpValidTime";
  static const String tenantName = 'tenantName';
  static const String profileName = 'profileName';
  static const String position = 'position';
  static const String isLoggedIn = "isLoggedIn";
  static const String contactID = "contactID";
  static const String deviceToken = "deviceToken";
  // static const String platformID = "E1DAE8DF-4C2A-4031-B22D-6B115C438B93";
  static const String liveTenantID = "98392E8C-A6FC-48D6-873D-5A6C7C514B94";
  static const String localTenantID = "F4CBB9FC-7804-4046-98D1-2346C1676100";
  static const String defaultGUID = "00000000-0000-0000-0000-000000000000";
  static const String studentEnquiryID = "studentEnquiryID";
  static const String rollNo = "rollNo";
  static const String mobileWithCode = "mobileWithCode";
  static const String profileImage = "profileImage";

  // Guest login
  static const String guestUser = 'tcdsguest@gmail.com';
  static const String guestPassword = 'India_123';

  // Endpoints
  static const String refreshTokenUrl = "authorize/token/renew-for-tenant";
  static const String accountDeletion = "user-service/user/delete/account";
  static const String login = "identity-service/v1/login-by-tenant";

  static const String changeNewPassword =
      "user-service/v1/audit/user/new-password";
  static const String coutriesList = "common/country";
  static const String statesList = "common/state/";
  static const String districtList = "common/district/";
  static const String talukList =
      "icloud-franchisee/v1/franchisee/taluk/list?district=";
  static const String centreAndCourseDetails =
      "icloud-franchisee/v1/franchisee/mobile-course-details";
  static const String getImageDetails = "icloud-franchisee/v1/franchisee/";
  static const String phoneCodeUrl = "common/phoneCode";
  static const String getGenderTypes = "common/gender";
  /* static const String otpRequest =
      "icloud-franchisee/v1/franchisee/registration/otp/request"; */
  static const String otpRequest = "icloud-admission/v1/student/otp/request";
  static const String forgotOtpRequest =
      "icloud-admission/v1/student/forgot/otp/request";
  /*  static const String otpResend =
      "icloud-franchisee/v1/franchisee/email/otp/resend"; */
  static const String otpResend = "icloud-admission/v1/student/sms/otp/resend";
  // static const String otpVerify = "icloud-franchisee/v1/franchisee/otp/verify";
  static const String otpVerify = "icloud-admission/v1/student/otp/verify";
  static const String qualification =
      "icloud-admission/v1/student/qualification/list";
  static const String occupation =
      "icloud-admission/v1/student/occupation/list";
  static const String relationships =
      "icloud-franchisee/v1/franchisee/relationship/list";
  static const String reasonsTCDS =
      "icloud-admission/v1/student/reason/dropdown";
  static const String centreDetail =
      "icloud-franchisee/v1/franchisee/help-support";
  static const String imageUpload =
      "icloud-franchisee/v1/franchisee/image/upload";
  static const String createUser = "icloud-admission/v1/student/enquiry/create";
  static const String userData =
      "icloud-admission/v1/student/enquiry?studentEnquiryID=";
  static const String personalData =
      "icloud-admission/v1/student/getbyid?contactID=";
  static const String courseDetailData =
      "icloud-admission/v1/student/course/detail?batchMappingID=";
  static const String courseTypeData = "icloud-academic/v1/course/type/list";
  static const String courseTypeIDData =
      "icloud-academic/v1/course/list/byfranchisee?courseTypeID=";
  static const String personalDetailUrl =
      "icloud-admission/v1/student/getbyid?contactID=";
  static const String documentDownloadBase64 =
      "document-service/document/base64/";
  static const String knowTCDSfrom =
      "icloud-admission/v1/student/referby/dropdown";
  static const String purpose = "icloud-admission/v1/student/purpose/dropdown";
  // franchise avail states & district
  static const String franchiseStates =
      "icloud-franchisee/v1/franchisee/state/list?country=";
  static const String franchiseDistrict =
      "icloud-franchisee/v1/franchisee/district/list?state=";
  static const String franchiseTaluk =
      "icloud-franchisee/v1/franchisee/taluk/list?district=";
  // achievers award
  static const String getDistrictLevelAwardsList =
      "icloud-franchisee/v1/franchisee/district-level/achievers";
  static const String getStateLevelAwardsList =
      "icloud-franchisee/v1/franchisee/state-level/achievers";
  static const String levelUrl = "icloud-franchisee/v1/franchisee/level/status";
}
