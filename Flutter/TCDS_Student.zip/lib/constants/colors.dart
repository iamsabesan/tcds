import 'package:flutter/material.dart';

class AppColor {
  static const Color primaryColor = Color.fromRGBO(40, 110, 152, 1);
  static const Color secondaryColor = Color.fromRGBO(255, 113, 1, 1);
  static const Color whiteColor = Colors.white;
  static const Color white2Color = Color.fromRGBO(251, 251, 255, 1);
  static const Color black2Color = Color.fromRGBO(115, 115, 115, 1);
  static const Color subTitleColor = Color.fromRGBO(53, 53, 53, 1);
  static const Color titleColor = Color.fromRGBO(89, 89, 89, 1);
  static const Color black3Color = Color.fromRGBO(78, 78, 78, 1);
  static const Color blackColor = Colors.black;
  static const Color redColor = Colors.red;
  static const Color greenColor = Colors.green;
  static const Color grey = Color.fromRGBO(204, 204, 204, 1);
  static const Color grey2 = Color.fromRGBO(247, 248, 250, 1);
  static const Color red = Color.fromRGBO(255, 41, 41, 1);
  static const Color selectedColor = Color.fromRGBO(220, 242, 255, 1);
  static const Color selectedWidget = Color.fromRGBO(40, 110, 152, 1);
  static const Color backgroundBlue = Color.fromRGBO(242, 244, 252, 1);
  static const Color containerWhiteColor = Color.fromRGBO(255, 255, 255, 1);
  static const Color containerBlue = Color.fromRGBO(216, 238, 251, 1);
  static const Color darkGreen = Color.fromRGBO(85, 111, 110, 1);
  static const Color darkGreenLightShade = Color.fromRGBO(138, 185, 183, 1);
  static const Color darkPink = Color.fromRGBO(213, 11, 139, 1);
  static const Color violet = Color.fromRGBO(174, 30, 163, 1);
  static const Color lightOrange = Color.fromRGBO(254, 224, 200, 1);
  static const Color orange = Colors.orange;
  static const Color lightBlue = Color.fromRGBO(247, 248, 252, 1);
  static const Color lightPurple = Color.fromRGBO(228, 175, 234, 1);

// Dashboard tile colors
  static const Color brightGreen = Color.fromRGBO(0, 167, 89, 1);
  static const Color brightOrange = Color.fromRGBO(242, 126, 0, 1);
  static const Color brightRed = Color.fromRGBO(221, 43, 28, 1);
  static const Color brightGrey = Color.fromRGBO(147, 163, 173, 1);
  static const Color brightLightGreen = Color.fromRGBO(115, 197, 16, 1);
  static const Color brightBlue = Color.fromRGBO(73, 161, 214, 1);
  static const Color brightPurple = Color.fromRGBO(173, 73, 140, 1);
  static const Color brightViolet = Color.fromRGBO(82, 100, 138, 1);
  static const Color brightBlue2 = Color.fromRGBO(0, 147, 203, 1);
  static const Color brightBlue3 = Color.fromRGBO(123, 150, 209, 1);
}
