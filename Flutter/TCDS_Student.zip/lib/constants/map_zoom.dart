class MapZoom {
  static double zoom = 18.0;
  static double zoom11 = 11.0;
  static double zoom15 = 15.0;
  static double outZoom = 14.0;
  static double allMarkerZoom = 12.0;
}
