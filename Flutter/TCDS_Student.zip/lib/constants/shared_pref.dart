import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../app/routes/routes.dart';

class SharedPref {
  static SharedPreferences? _prefs;

  static init() async {
    await SharedPreferences.getInstance().then((value) {
      _prefs = value;
    });
  }

  static putString(String key, String value) {
    if (_prefs != null) _prefs!.setString(key, value);
  }

  static String getString(String key) {
    return _prefs == null ? "" : _prefs!.getString(key) ?? "";
  }

  static putBool(String key, bool value) {
    if (_prefs != null) _prefs!.setBool(key, value);
  }

  static void remove(String key) {
    if (_prefs != null) _prefs!.remove(key);
  }

  static bool getBool(String key) {
    return _prefs == null ? false : _prefs!.getBool(key) ?? false;
  }

  static clearAll() async {
    await _prefs!.clear();
    Get.offAllNamed(Routes.logIn);
  }
}
