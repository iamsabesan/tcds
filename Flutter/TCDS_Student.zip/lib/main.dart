import 'dart:async';
// import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/constants/shared_pref.dart';
import 'app/routes/routes.dart';
// import 'app/services/notification_service.dart';
import 'constants/app_string.dart';
import 'constants/colors.dart';

Future<void> main() async {
  // Ensure that Flutter is initialized.
  WidgetsFlutterBinding.ensureInitialized();

  // // initialize firebase
  // await Firebase.initializeApp();
  // // initialize single-ton notification service
  // await NotificationService.instance.initialize();

  // Wait for Local Storage
  await initLocalStorage();

  runApp(const MyApp());
}

// Init Local Storage
initLocalStorage() async {
  await SharedPref.init();
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String enquiryId = SharedPref.getString(AppStrings.studentEnquiryID);
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));
    return ScreenUtilInit(
      designSize: const Size(412, 892),
      child: GetMaterialApp(
        title: 'TCDS',
        // navigatorKey: navigatorKey,
        debugShowCheckedModeBanner: false,
        initialRoute: SharedPref.getBool(AppStrings.isLoggedIn)
            ? Routes.dashBoard
            : enquiryId == ""
                ? Routes.logIn
                : Routes.registrationStatus,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: AppColor.primaryColor),
          dialogTheme:
              const DialogThemeData(backgroundColor: AppColor.whiteColor),
        ),
        getPages: Routes.routesList,
      ),
    );
  }
}
