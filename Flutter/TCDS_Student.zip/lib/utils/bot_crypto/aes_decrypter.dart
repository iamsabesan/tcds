library bot_crypto;

import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;
import 'package:encrypt/encrypt.dart' as enc;
import 'dart:typed_data';

///  A Class that provide functions for to encrypt & decrypt values using AES algorithm
///
///  with specified default key and iv values
class BotCrypto {
  /// Default Values of padding & Mode
  static const String padding = 'PKCS7';
  static const enc.AESMode mode = enc.AESMode.cbc;

  /// Changable Key,IV Value
  static String keyValue = 'BOXOFTECH@2022@415';
  static String ivValue = 'podaparathesino1';

  /// Decrypt Function that requires encrypted text and key,iv as optional parameters then return decrypted text
  static String decryptData({
    required String encryptedText,
    String? keyParam,
    String? ivParam,
  }) {
    String decryptedString;

    /// Convert the key string to UTF-8 bytes
    List<int> keyBytes = utf8.encode(keyParam ?? keyValue);

    /// Calculate the MD5 hash of the key bytes
    crypto.Digest md5Hash = crypto.md5.convert(keyBytes);

    /// Convert the MD5 hash bytes to a Unit8List Key
    final md5Key = enc.Key(Uint8List.fromList(md5Hash.bytes));

    ///  Create a IV by using given parameter or default value
    final iv = enc.IV.fromUtf8(ivParam ?? ivValue);

    try {
      /// Decryption
      final decrypter =
          enc.Encrypter(enc.AES(md5Key, mode: mode, padding: padding));
      final decrypted = decrypter.decryptBytes(enc.Encrypted.from64(

              /// Replace chipherText cause while encrypting the text got replaced vice versa like below
              encryptedText.replaceAll('@@', '/').replaceAll('__', '+').trim()),
          iv: iv);
      decryptedString = utf8.decode(decrypted);
    } on Exception catch (e) {
      decryptedString = e.toString();
    }

    return decryptedString;
  }

  /// Encrypting Function that requires a String to encrypt and return it with optional params key and iv
  static String encryptData({
    required String encryptingText,
    String? keyParam,
    String? ivParam,
  }) {
    /// Convert the key string to UTF-8 bytes
    List<int> keyBytes = utf8.encode(keyParam ?? keyValue);

    /// Calculate the MD5 hash of the key bytes
    crypto.Digest md5Hash = crypto.md5.convert(keyBytes);

    /// Convert the MD5 hash bytes to a Unit8List Key
    final md5Key = enc.Key(Uint8List.fromList(md5Hash.bytes));

    ///  Create a IV by using given parameter or default value
    final iv = enc.IV.fromUtf8(ivParam ?? ivValue);

    try {
      /// Encryption
      String plainText = encryptingText;
      final encrypter =
          enc.Encrypter(enc.AES(md5Key, mode: mode, padding: padding));
      final encrypted = encrypter.encrypt(plainText, iv: iv);

      /// Replace '/' with '@@' & '+' with '__' and return encrypted text
      encryptingText =
          encrypted.base64.replaceAll('/', '@@').replaceAll('+', '__');
    } on Exception catch (e) {
      encryptingText = e.toString();
    }

    return encryptingText;
  }
}
