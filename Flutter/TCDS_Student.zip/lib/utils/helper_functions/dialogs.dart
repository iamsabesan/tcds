import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:tcds_student/app/ui/widgets/custom_text.dart';
import 'package:tcds_student/app/ui/widgets/in_button.dart';

import '../../constants/colors.dart';

Future<void> successAlertDialog(
  BuildContext context, {
  required String content,
  VoidCallback? onPressed,
  bool autoClose = false,
  Duration? autoCloseDuration,
}) {
  return showDialog(
    context: context,
    barrierDismissible: false, // must press button to close
    builder: (context) {
      if (autoClose) {
        Future.delayed(autoCloseDuration ?? const Duration(seconds: 3), () {
          Get.back();
        });
      }

      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green, size: 28),
            SizedBox(width: 8),
            Text("Success"),
          ],
        ),
        content: Text(content, style: const TextStyle(fontSize: 14)),
        actions: [
          if (onPressed != null)
            TextButton(
              onPressed: onPressed,
              child: const Text(
                "OK",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ),
        ],
      );
    },
  );
}

Future logOutDialog(
  BuildContext context, {
  void Function()? noOnTap,
  void Function()? yesOnTap,
}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.logout_rounded,
              size: 65.w,
              color: AppColor.secondaryColor,
            ),
            SizedBox(height: 20.w),
            CustomText(
              text: "Are you sure to logout ?",
              color: AppColor.blackColor,
              fontWeight: FontWeight.w500,
              fontSize: 14.sp,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: InButton(
                  onTap: () => Get.back(),
                  text: "Cancel",
                  color: AppColor.grey2,
                  textColor: AppColor.blackColor,
                ),
              ),
              SizedBox(width: 10.w),
              Flexible(
                child: InButton(
                  onTap: yesOnTap,
                  text: "Yes, Logout",
                  color: AppColor.secondaryColor,
                  textColor: AppColor.whiteColor,
                ),
              ),
            ],
          ),
        ],
      );
    },
  );
}

Future infoAlertDialog(
  BuildContext context, {
  Widget? contentAsWidget,
  String? content,
  List<Widget>? actions,
}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            Icon(
              Icons.info_rounded,
              size: 65.w,
              color: AppColor.secondaryColor,
            ),
            SizedBox(height: 20.w),
            if (contentAsWidget != null) contentAsWidget,
            if (contentAsWidget != null) SizedBox(height: 20.w),
            if (content != null && contentAsWidget == null)
              CustomText(
                text: content,
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              ),
          ],
        ),
        actions: actions,
      );
    },
  );
}

Future warningAlertDialog(
  BuildContext context, {
  Widget? contentAsWidget,
  String? content,
  List<Widget>? actions,
}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.warning_amber_rounded, size: 65.w, color: Colors.amber),
            SizedBox(height: 20.w),
            if (contentAsWidget != null) contentAsWidget,
            if (contentAsWidget != null) SizedBox(height: 20.w),
            if (content != null && contentAsWidget == null)
              CustomText(
                text: content,
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              ),
          ],
        ),
        actions: actions,
      );
    },
  );
}


/* import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';


//  --> This file contains template of dialogs
Future successAlertDialog(BuildContext context,
    {Widget? contentAsWidget,
    String? content,
    List<Widget>? actions,
    void Function()? onPressed}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                onPressed: onPressed ??
                    () {
                      Get.back();
                    },
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            // Image.asset(
            //   AssetPath.successCheckCircle,
            //   height: 65.w,
            //   width: 65.w,
            // ),
            // SizedBox(
            //   height: 20.w,
            // ),
            if (contentAsWidget != null) contentAsWidget,
            if (contentAsWidget != null)
              SizedBox(
                height: 20.w,
              ),
            if (content != null && contentAsWidget == null)
              CustomText(
                text: content,
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              )
          ],
        ),
        actions: actions,
      );
    },
  );
}

Future infoAlertDialog(BuildContext context,
    {Widget? contentAsWidget, String? content, List<Widget>? actions}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(Icons.close_rounded),
              ),
            ),
            Image.asset(
              AssetPath.info,
              height: 65.w,
              width: 65.w,
            ),
            SizedBox(
              height: 20.w,
            ),
            if (contentAsWidget != null) contentAsWidget,
            if (contentAsWidget != null)
              SizedBox(
                height: 20.w,
              ),
            if (content != null && contentAsWidget == null)
              CustomText(
                text: content,
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              )
          ],
        ),
        actions: actions,
      );
    },
  );
}

Future warningAlertDialog(BuildContext context,
    {Widget? contentAsWidget, String? content, List<Widget>? actions}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              AssetPath.warning,
              height: 65.w,
              width: 65.w,
            ),
            SizedBox(
              height: 20.w,
            ),
            if (contentAsWidget != null) contentAsWidget,
            if (contentAsWidget != null)
              SizedBox(
                height: 20.w,
              ),
            if (content != null && contentAsWidget == null)
              CustomText(
                text: content,
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              )
          ],
        ),
        actions: actions,
      );
    },
  );
}

Future accountDeletionDialog(BuildContext context,
    {void Function()? cancelOnTap, void Function()? submitOnTap}) {
  TextEditingController mobileNumberTxtCtrl = TextEditingController();
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Form(
          key: formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                AssetPath.warning,
                height: 65.w,
                width: 65.w,
              ),
              SizedBox(
                height: 20.w,
              ),
              CustomText(
                text:
                    "Enter your registered mobile number for account deletion request",
                color: AppColor.blackColor,
                fontWeight: FontWeight.w500,
                fontSize: 14.sp,
                textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 30.w,
              ),
              CustomTextField(
                labelText: "Mobile Number",
                controller: mobileNumberTxtCtrl,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(10),
                ],
                validator: (val) {
                  if (val != null && val.isEmpty) {
                    return "Required";
                  } else if (val != null && val.length < 10) {
                    return "Invalid Mobile Number";
                  } else {
                    return null;
                  }
                },
              ),
              SizedBox(
                height: 10.w,
              ),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: InButton(
                  onTap: cancelOnTap,
                  text: "Cancel",
                  color: AppColor.secondary2,
                  textColor: AppColor.secondaryColor,
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
              Flexible(
                child: InButton(
                  onTap: () {
                    if (formKey.currentState!.validate()) {
                      if (submitOnTap != null) {
                        submitOnTap();
                      }
                    }
                  },
                  text: "Submit",
                  color: AppColor.secondaryColor,
                  textColor: AppColor.secondary2,
                ),
              ),
            ],
          ),
        ],
      );
    },
  );
}

Future logOutDialog(BuildContext context,
    {void Function()? noOnTap, void Function()? yesOnTap}) {
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        alignment: Alignment.center,
        content: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              AssetPath.warning,
              height: 65.w,
              width: 65.w,
            ),
            SizedBox(
              height: 20.w,
            ),
            CustomText(
              text: "Are you sure to logout ?",
              color: AppColor.blackColor,
              fontWeight: FontWeight.w500,
              fontSize: 14.sp,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Flexible(
                child: InButton(
                  onTap: noOnTap,
                  text: "No, don't",
                  color: AppColor.secondary2,
                  textColor: AppColor.secondaryColor,
                ),
              ),
              SizedBox(
                width: 10.w,
              ),
              Flexible(
                child: InButton(
                  onTap: yesOnTap,
                  text: "Yes, Logout",
                  color: AppColor.secondaryColor,
                  textColor: AppColor.secondary2,
                ),
              ),
            ],
          ),
        ],
      );
    },
  );
}
 */