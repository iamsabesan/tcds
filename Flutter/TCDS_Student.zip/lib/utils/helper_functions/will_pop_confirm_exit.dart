import 'package:fluttertoast/fluttertoast.dart';
import '../../constants/colors.dart';

class ConfirmExit {
  static DateTime? currentBackPressTime;
// Function that will ask user to confirm exit
  static Future<bool> onPopScope() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > const Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(
          msg: "Press once again to Exit",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: AppColor.primaryColor,
          textColor: AppColor.whiteColor,
          fontSize: 14);
      return Future.value(false);
    }
    return Future.value(true);
  }
}
