import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../../constants/colors.dart';
import '../app/ui/widgets/custom_text.dart';

class PleaseWaitLoader {
  // dialogContext will hold Common Context
  static BuildContext? dialogContext = Get.context;

  // closeDialog will Pop the dialog using dialogContext
  static closeDialog() {
    Get.back();
  }

  // Show Please Wait Loader dialog...
  static openDialog() {
    return showDialog(
        context: dialogContext!,
        barrierDismissible: false,
        builder: (context) => PopScope(
              canPop: false,
              child: ClipRRect(
                clipBehavior: Clip.antiAliasWithSaveLayer,
                borderRadius: BorderRadius.circular(15.r),
                child: Dialog(
                  backgroundColor: AppColor.white2Color,
                  child: Container(
                    padding:
                        EdgeInsets.symmetric(vertical: 30.w, horizontal: 5.w),
                    child: IntrinsicWidth(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const CircularProgressIndicator(
                            color: AppColor.secondaryColor,
                          ),
                          SizedBox(
                            height: 15.w,
                          ),
                          CustomText(
                            text: 'Please Wait...',
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w500,
                            color: AppColor.blackColor,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ));
  }
}
