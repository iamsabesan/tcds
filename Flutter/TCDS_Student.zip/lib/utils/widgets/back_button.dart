import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/colors.dart';

class CustomBackArrowButton extends StatelessWidget {
  final void Function()? onTap;
  const CustomBackArrowButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        padding: EdgeInsets.all(6.w),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.r),
          border: Border.all(color: AppColor.grey),
        ),
        child: Icon(
          Icons.arrow_back_ios_new_rounded,
          color: AppColor.blackColor,
          size: 20.w,
        ),
      ),
    );
  }
}
